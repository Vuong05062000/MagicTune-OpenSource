'use client';

import React, { useState } from 'react';
import {
  X,
  User as UserIcon,
  Mail,
  Phone,
  KeyRound,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Link as LinkIcon,
  Save,
  LogOut,
  Smartphone,
  Crown
} from 'lucide-react';
import { auth, recordUserActivity, googleProvider, facebookProvider, DEFAULT_APP_SETTINGS } from '@/lib/firebase/config';
import {
  updateProfile,
  updateEmail,
  updatePassword,
  linkWithPopup,
  unlink,
  User
} from 'firebase/auth';

interface UserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User | null;
  onLogout: () => void;
}

export function UserProfileModal({
  isOpen,
  onClose,
  currentUser,
  onLogout
}: UserProfileModalProps) {
  const [displayName, setDisplayName] = useState(currentUser?.displayName || '');
  const [email, setEmail] = useState(currentUser?.email || '');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  if (!isOpen || !currentUser) return null;

  const notify = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(null), 4000);
  };

  // 1. Cập nhật tên hiển thị
  const handleUpdateName = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!displayName.trim()) return;
    setLoading(true);
    setErrorMsg(null);

    try {
      await updateProfile(currentUser, { displayName: displayName.trim() });
      recordUserActivity('Cập nhật tên tài khoản', displayName.trim());
      notify('Đã cập nhật tên tài khoản thành công!');
    } catch (err: any) {
      setErrorMsg(err.message || 'Không thể cập nhật họ tên.');
    } finally {
      setLoading(false);
    }
  };

  // 2. Cập nhật Email
  const handleUpdateEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || email === currentUser.email) return;
    setLoading(true);
    setErrorMsg(null);

    try {
      await updateEmail(currentUser, email.trim());
      recordUserActivity('Cập nhật địa chỉ email', email.trim());
      notify('Đã cập nhật email mới thành công!');
    } catch (err: any) {
      setErrorMsg(
        err.code === 'auth/requires-recent-login'
          ? 'Hành động bảo mật: Vui lòng đăng xuất và đăng nhập lại trước khi đổi email.'
          : err.message || 'Không thể cập nhật email.'
      );
    } finally {
      setLoading(false);
    }
  };

  // 3. Đổi mật khẩu
  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPassword || newPassword.length < 6) {
      setErrorMsg('Mật khẩu mới phải có ít nhất 6 ký tự.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setErrorMsg('Mật khẩu xác nhận không trùng khớp.');
      return;
    }
    setLoading(true);
    setErrorMsg(null);

    try {
      await updatePassword(currentUser, newPassword);
      recordUserActivity('Đổi mật khẩu tài khoản');
      setNewPassword('');
      setConfirmPassword('');
      notify('Đổi mật khẩu tài khoản thành công!');
    } catch (err: any) {
      setErrorMsg(
        err.code === 'auth/requires-recent-login'
          ? 'Hành động bảo mật: Vui lòng đăng xuất và đăng nhập lại trước khi đổi mật khẩu.'
          : err.message || 'Không thể đổi mật khẩu.'
      );
    } finally {
      setLoading(false);
    }
  };

  // 4. Liên kết / Hủy liên kết Google
  const handleLinkGoogle = async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      await linkWithPopup(currentUser, googleProvider);
      recordUserActivity('Liên kết tài khoản Google');
      notify('Đã liên kết tài khoản Google thành công!');
    } catch (err: any) {
      setErrorMsg(err.message || 'Không thể liên kết Google.');
    } finally {
      setLoading(false);
    }
  };

  // 5. Liên kết / Hủy liên kết Facebook
  const handleLinkFacebook = async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      await linkWithPopup(currentUser, facebookProvider);
      recordUserActivity('Liên kết tài khoản Facebook');
      notify('Đã liên kết tài khoản Facebook thành công!');
    } catch (err: any) {
      setErrorMsg(err.message || 'Không thể liên kết Facebook.');
    } finally {
      setLoading(false);
    }
  };

  // Kiểm tra provider đã liên kết
  const providers = currentUser.providerData.map((p) => p.providerId);
  const isGoogleLinked = providers.includes('google.com');
  const isFacebookLinked = providers.includes('facebook.com');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-lg rounded-3xl bg-[#0D1629] border border-cyan-500/30 p-6 shadow-2xl relative text-slate-100 max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="flex items-center space-x-3 mb-6 pb-4 border-b border-cyan-500/20">
          <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-[#00F0FF]">
            <UserIcon className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white flex items-center space-x-2">
              <span>Hồ Sơ &amp; Quản Lý Tài Khoản</span>
            </h2>
            <div className="flex items-center space-x-2 mt-0.5">
              <span className="text-xs text-slate-400">
                UID: <span className="font-mono text-cyan-400">{currentUser.uid}</span>
              </span>
              {(() => {
                let isVip = false;
                if (typeof window !== 'undefined') {
                  try {
                    const saved = localStorage.getItem('magictune_admin_settings');
                    const vipList = saved ? (JSON.parse(saved).vipUsers || []) : (DEFAULT_APP_SETTINGS.vipUsers || []);
                    const userKey = (currentUser.email || currentUser.uid).toLowerCase();
                    isVip = vipList.includes(userKey) || userKey === 'admin@example.com';
                  } catch (e) {}
                }
                return isVip ? (
                  <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-black uppercase flex items-center space-x-1">
                    <Crown className="w-3 h-3 text-amber-400" />
                    <span>Thành Viên VIP Trọn Đời</span>
                  </span>
                ) : (
                  <span className="px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700 text-[10px] font-semibold">
                    Tài khoản chuẩn
                  </span>
                );
              })()}
            </div>
          </div>
        </div>

        {errorMsg && (
          <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center space-x-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="mb-4 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center space-x-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>{successMsg}</span>
          </div>
        )}

        <div className="space-y-6 text-xs">
          {/* Phần 1: Tên hiển thị */}
          <form onSubmit={handleUpdateName} className="space-y-2 bg-[#0A0F1D] p-3.5 rounded-2xl border border-slate-800">
            <label className="block text-slate-300 font-bold">Họ và Tên / Biệt Danh:</label>
            <div className="flex items-center space-x-2">
              <input
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                placeholder="Nhập tên của bạn"
                className="flex-1 bg-[#111A2E] border border-cyan-500/20 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-cyan-400"
              />
              <button
                type="submit"
                disabled={loading}
                className="px-3.5 py-2 rounded-xl bg-cyan-500 text-black font-bold hover:bg-cyan-400 transition-all shrink-0"
              >
                Lưu Tên
              </button>
            </div>
          </form>

          {/* Phần 2: Email */}
          <form onSubmit={handleUpdateEmail} className="space-y-2 bg-[#0A0F1D] p-3.5 rounded-2xl border border-slate-800">
            <label className="block text-slate-300 font-bold">Địa Chỉ Email:</label>
            <div className="flex items-center space-x-2">
              <div className="relative flex-1">
                <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="email@example.com"
                  className="w-full bg-[#111A2E] border border-cyan-500/20 rounded-xl pl-9 pr-3 py-2 text-white focus:outline-none focus:border-cyan-400"
                />
              </div>
              <button
                type="submit"
                disabled={loading || email === currentUser.email}
                className="px-3.5 py-2 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 font-bold transition-all disabled:opacity-40 shrink-0"
              >
                Đổi Email
              </button>
            </div>
          </form>

          {/* Phần 3: Số điện thoại (nếu có) */}
          <div className="bg-[#0A0F1D] p-3.5 rounded-2xl border border-slate-800 flex items-center justify-between">
            <div>
              <span className="block text-slate-300 font-bold">Số Điện Thoại (SMS OTP):</span>
              <span className="text-slate-400 font-mono text-[11px]">
                {currentUser.phoneNumber || 'Chưa liên kết số điện thoại'}
              </span>
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400">
              {currentUser.phoneNumber ? 'Đã xác minh' : 'Tùy chọn'}
            </span>
          </div>

          {/* Phần 4: Đổi mật khẩu */}
          <form onSubmit={handleChangePassword} className="space-y-3 bg-[#0A0F1D] p-3.5 rounded-2xl border border-slate-800">
            <span className="block text-slate-300 font-bold flex items-center space-x-1.5">
              <KeyRound className="w-3.5 h-3.5 text-[#00F0FF]" />
              <span>Đổi Mật Khẩu Đăng Nhập:</span>
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Mật khẩu mới (ít nhất 6 ký tự)"
                className="w-full bg-[#111A2E] border border-cyan-500/20 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-cyan-400"
              />
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Nhập lại mật khẩu mới"
                className="w-full bg-[#111A2E] border border-cyan-500/20 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-cyan-400"
              />
            </div>
            <button
              type="submit"
              disabled={loading || !newPassword}
              className="w-full py-2 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 border border-purple-500/40 font-bold transition-all disabled:opacity-40"
            >
              Cập Nhật Mật Khẩu
            </button>
          </form>

          {/* Phần 5: Liên kết tài khoản đăng nhập (Google & Facebook) */}
          <div className="bg-[#0A0F1D] p-3.5 rounded-2xl border border-slate-800 space-y-3">
            <span className="block text-slate-300 font-bold flex items-center space-x-1.5">
              <LinkIcon className="w-3.5 h-3.5 text-emerald-400" />
              <span>Liên Kết Đăng Nhập Đa Kênh:</span>
            </span>

            <div className="flex flex-col sm:flex-row items-center justify-between gap-2 p-2.5 rounded-xl bg-[#111A2E] border border-slate-700/80">
              <div className="flex items-center space-x-2">
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                </svg>
                <span className="font-semibold text-white">Tài khoản Google</span>
              </div>
              {isGoogleLinked ? (
                <span className="px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 text-[11px] font-bold border border-emerald-500/30">
                  Đã liên kết
                </span>
              ) : (
                <button
                  type="button"
                  onClick={handleLinkGoogle}
                  disabled={loading}
                  className="px-3 py-1 rounded-lg bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/30 text-[11px] font-bold"
                >
                  Kết Nối Google
                </button>
              )}
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-between gap-2 p-2.5 rounded-xl bg-[#111A2E] border border-slate-700/80">
              <div className="flex items-center space-x-2">
                <svg className="w-4 h-4 fill-[#1877F2]" viewBox="0 0 24 24">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                </svg>
                <span className="font-semibold text-white">Tài khoản Facebook</span>
              </div>
              {isFacebookLinked ? (
                <span className="px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 text-[11px] font-bold border border-emerald-500/30">
                  Đã liên kết
                </span>
              ) : (
                <button
                  type="button"
                  onClick={handleLinkFacebook}
                  disabled={loading}
                  className="px-3 py-1 rounded-lg bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/30 text-[11px] font-bold"
                >
                  Kết Nối Facebook
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between">
          <button
            onClick={() => {
              onLogout();
              onClose();
            }}
            className="flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 font-bold transition-all"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Đăng Xuất</span>
          </button>

          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-bold transition-all"
          >
            Đóng
          </button>
        </div>
      </div>
    </div>
  );
}
