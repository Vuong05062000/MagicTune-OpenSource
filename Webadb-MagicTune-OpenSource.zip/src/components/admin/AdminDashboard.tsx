'use client';

import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Globe,
  Image as ImageIcon,
  UserPlus,
  Trash2,
  Save,
  CheckCircle2,
  AlertCircle,
  LogOut,
  ArrowLeft,
  KeyRound,
  Mail,
  Smartphone,
  Activity,
  Users,
  Lock,
  Search,
  Filter,
  RefreshCw,
  Database,
  Cloud,
  Terminal,
  Play,
  FileText,
  CreditCard,
  QrCode,
  Eye,
  Megaphone,
  Bell,
  Code,
  Layout,
  Crown,
  Sparkles,
  Check,
  UploadCloud,
  Plus,
  Layers,
  Monitor,
  Tablet,
  ExternalLink,
  Zap,
  CheckSquare,
  Square,
  Clock,
  CheckCircle,
  XCircle,
  MessageSquare,
  Calendar,
  Layers as LayersIcon
} from 'lucide-react';
import {
  auth,
  db,
  DEFAULT_APP_SETTINGS,
  AppGlobalSettings,
  SUPER_ADMIN_EMAILS,
  SUPER_ADMIN_PHONES,
  UserActivityLog,
  fetchLiveSettingsFromFirestore,
  saveLiveSettingsToFirestore,
  fetchLiveActivityLogsFromFirestore,
  fetchRealUsersFromFirestore,
  requestPushNotificationPermission,
  FCM_VAPID_KEY,
  purgeOldFirebaseData,
  getTodayDateKey,
  getStartOfTodayTimestamp,
  parseToEpochMs,
  formatVietnamDateTime,
  getRelativeTimeString
} from '@/lib/firebase/config';
import { collection, getDocs, updateDoc, doc, query, orderBy, limit } from 'firebase/firestore';
import {
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  User
} from 'firebase/auth';
import { Pagination } from '@/components/common/Pagination';
import { ScrollToTop } from '@/components/common/ScrollToTop';
import { UserDetailModal } from './UserDetailModal';

interface AdminDashboardProps {
  onBackToHome: () => void;
}

const ADMIN_BILLING_FEATURES: Array<{
  lockKey: keyof AppGlobalSettings['features'];
  priceKey: keyof AppGlobalSettings['featurePrices'];
  label: string;
}> = [
  { lockKey: 'ultraFixPushLocked', priceKey: 'ultraFixPush', label: 'Fix Trễ FB, Gmail, Zalo (0s)' },
  { lockKey: 'chinaRomFixLocked', priceKey: 'chinaRomFix', label: 'Mục 1: Fix Máy Nội Địa (China)' },
  { lockKey: 'globalBugsLocked', priceKey: 'globalBugs', label: 'Mục 2: Lỗi Toàn Cầu (Auto/Pin)' },
  { lockKey: 'shizukuBridgeLocked', priceKey: 'shizukuBridge', label: 'Mục 3: Cầu Nối Shizuku Engine' },
  { lockKey: 'debloatLocked', priceKey: 'debloat', label: 'Mục 4: Gỡ Ứng Dụng Rác' },
  { lockKey: 'localizationLocked', priceKey: 'localization', label: 'Mục 5: GMS & Việt Hóa' },
  { lockKey: 'performanceLocked', priceKey: 'performance', label: 'Mục 6: 120Hz & Tối Ưu Màn Hình' },
  { lockKey: 'noAdbLocked', priceKey: 'noAdb', label: 'Mục 7: Fix Trực Tiếp Không ADB' },
  { lockKey: 'multiBrandLocked', priceKey: 'multiBrand', label: 'Mục 8: Fix Đa Hãng Android' },
  { lockKey: 'apkInstallLocked', priceKey: 'apkInstall', label: 'Mục 9: Cài APK / APKS Web' },
  { lockKey: 'hardwareLocked', priceKey: 'hardware', label: 'Mục 10: Kiểm Tra Phần Cứng' },
  { lockKey: 'bankFixLocked', priceKey: 'bankFix', label: 'Mục 11: Sửa Lỗi Ứng Dụng Tài Chính' },
];

const ADB_PRESET_SCRIPTS: Array<{ name: string; desc: string; script: string }> = [
  {
    name: 'Kiểm Tra Doze & Whitelist',
    desc: 'Xem danh sách ứng dụng được miễn trừ ngủ đông Doze Mode.',
    script: 'dumpsys deviceidle whitelist\ndumpsys power | grep -E "mWakefulness|mInteractive"',
  },
  {
    name: 'Tối Ưu Push 0s Phổ Quát',
    desc: 'Đưa ứng dụng nhắn tin/OTP về Standby Bucket ACTIVE & cho phép chạy ngầm.',
    script:
      'cmd appops set com.facebook.orca RUN_IN_BACKGROUND allow\ncmd appops set com.zing.zalo RUN_IN_BACKGROUND allow\nam set-standby-bucket com.google.android.gm active',
  },
  {
    name: 'Kiểm Tra Pin & Nhiệt Độ',
    desc: 'Truy xuất mức pin, điện áp và nhiệt độ thiết bị theo thời gian thực.',
    script: 'dumpsys battery | grep -E "level|status|temperature|voltage"',
  },
  {
    name: 'Kiểm Tra Thông Số Màn Hình',
    desc: 'Đọc độ phân giải, DPI hiện tại và tần số quét tối đa.',
    script: 'wm size\nwm density\nsettings get system peak_refresh_rate',
  },
];

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onBackToHome }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Các tab quản trị viên chính thức (Tab 1 -> Tab 8)
  const [adminTab, setAdminTab] = useState<
    'logs' | 'users' | 'seo_adsense' | 'fcm_push' | 'settings' | 'billing' | 'adb_remote' | 'custom_apk'
  >('logs');

  // Phân trang
  const [logPage, setLogPage] = useState(1);
  const [logPageSize, setLogPageSize] = useState(15);
  const [userPage, setUserPage] = useState(1);
  const [userPageSize, setUserPageSize] = useState(10);
  const [pendingPaymentPage, setPendingPaymentPage] = useState(1);
  const pendingPaymentPageSize = 5;
  const [customApkPage, setCustomApkPage] = useState(1);
  const customApkPageSize = 6;

  // Quản lý người dùng thật
  const [searchUser, setSearchUser] = useState('');
  const [userRoleFilter, setUserRoleFilter] = useState<'all' | 'vip' | 'admin' | 'registered'>('all');
  const [userListViewMode, setUserListViewMode] = useState<'compact' | 'detailed'>('compact');
  const [selectedUserIds, setSelectedUserIds] = useState<string[]>([]);
  const [bulkActionSuccess, setBulkActionSuccess] = useState<string | null>(null);
  const [dbUsers, setDbUsers] = useState<any[]>([]);
  const [selectedUserDetail, setSelectedUserDetail] = useState<any | null>(null);

  // Logs từ Firestore (Chỉ người dùng thật & quản trị viên)
  const [activityLogs, setActivityLogs] = useState<UserActivityLog[]>([]);
  const [logFilter, setLogFilter] = useState<'all' | 'registered' | 'admin'>('all');
  const [searchLog, setSearchLog] = useState('');
  const [isLoadingLogs, setIsLoadingLogs] = useState(false);

  // Cấu hình từ Firestore
  const [settings, setSettings] = useState<AppGlobalSettings>(DEFAULT_APP_SETTINGS);
  const [newAdminEmail, setNewAdminEmail] = useState('');
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Script ADB Console
  const [customScript, setCustomScript] = useState('');
  const [scriptOutput, setScriptOutput] = useState('');

  // Push Test
  const [pushSentSuccess, setPushSentSuccess] = useState(false);

  // Điều chỉnh hàng loạt phí tính năng
  const [bulkPriceInput, setBulkPriceInput] = useState<number>(30000);
  const [bulkNote, setBulkNote] = useState<string | null>(null);
  const [isPurging, setIsPurging] = useState(false);
  const [purgeNotice, setPurgeNotice] = useState<string | null>(null);

  // Danh sách thông báo chuyển tiền đang chờ duyệt
  const [pendingPayments, setPendingPayments] = useState<any[]>([]);

  // Quản lý kho APK tải lên
  const [newApkName, setNewApkName] = useState('');
  const [newApkVersion, setNewApkVersion] = useState('1.0.0');
  const [newApkSize, setNewApkSize] = useState('15 MB');
  const [newApkUrl, setNewApkUrl] = useState('');
  const [newApkCategory, setNewApkCategory] = useState<'Utility' | 'Shizuku' | 'MicroG' | 'Google Services' | 'Keyboard'>('Utility');
  const [newApkDesc, setNewApkDesc] = useState('');
  const [newApkRecommended, setNewApkRecommended] = useState('Mọi dòng điện thoại Android (MagicOS, HyperOS, One UI...)');

  const reloadAllDataFromFirestore = async () => {
    setIsLoadingLogs(true);
    try {
      const [liveSettings, liveLogs, realUsers] = await Promise.all([
        fetchLiveSettingsFromFirestore(),
        fetchLiveActivityLogsFromFirestore(true), // CHỈ LẤY DỮ LIỆU TRONG NGÀY
        fetchRealUsersFromFirestore()
      ]);
      setSettings(liveSettings);
      const startOfToday = getStartOfTodayTimestamp();
      // Chỉ nạp nhật ký người dùng thật trong ngày hôm nay, loại bỏ hoàn toàn anonymous và các ngày cũ
      setActivityLogs(liveLogs.filter(l => (l.userType === 'registered' || l.userType === 'admin') && !l.userId?.startsWith('anon_') && l.createdAt >= startOfToday));
      setDbUsers(realUsers.filter(u => !u.userId?.startsWith('anon_')));

      // Nạp danh sách giao dịch chuyển khoản từ payment_transactions (tối ưu chi phí đọc)
      try {
        const qPayments = query(collection(db, 'payment_transactions'), limit(100));
        const snap = await getDocs(qPayments);
        const list = snap.docs.map(d => ({ id: d.id, ...d.data() }));
        // Sắp xếp mới nhất lên đầu
        list.sort((a: any, b: any) => (b.createdAt || 0) - (a.createdAt || 0));
        setPendingPayments(list);
      } catch (pe) {
        console.warn('Chưa có bộ sưu tập payment_transactions hoặc chạy offline:', pe);
      }
    } catch (err) {
      console.error('Lỗi nạp dữ liệu Firestore:', err);
    } finally {
      setIsLoadingLogs(false);
    }
  };

  const handlePurgeOldData = async () => {
    if (isPurging) return;
    const confirm = window.confirm(
      '⚠️ XÁC NHẬN DỌN DẸP TIẾT KIỆM CHI PHÍ:\n\nHệ thống sẽ dọn sạch toàn bộ Nhật ký hoạt động, Báo cáo lỗi ADB và các phiên QR của các ngày trước, chỉ giữ lại dữ liệu hôm nay.\n\n(Dữ liệu tài khoản người dùng và cấu hình hệ thống luôn được bảo toàn tuyệt đối 100%).\n\nBạn có muốn tiếp tục?'
    );
    if (!confirm) return;

    setIsPurging(true);
    setPurgeNotice('Đang dọn dẹp các tài liệu cũ trên Firestore để tối ưu chi phí...');
    try {
      const res = await purgeOldFirebaseData();
      setPurgeNotice(res.message);
      await reloadAllDataFromFirestore();
      setTimeout(() => setPurgeNotice(null), 8000);
    } catch (err: any) {
      setPurgeNotice(`Lỗi dọn dẹp: ${err.message || err}`);
    } finally {
      setIsPurging(false);
    }
  };

  useEffect(() => {
    reloadAllDataFromFirestore();
    // Tự động dọn dẹp dữ liệu các ngày cũ chạy ngầm khi Admin mở trang để giải phóng dung lượng Firestore
    purgeOldFirebaseData().catch((e) => console.debug('[Tác vụ dọn dẹp ngầm]', e));

    const unsub = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
      setAuthLoading(false);
    });
    return () => unsub();
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setIsLoggingIn(true);

    try {
      await signInWithEmailAndPassword(auth, email.trim(), password);
    } catch (err: any) {
      setLoginError(
        err.message || 'Email hoặc mật khẩu quản trị viên không chính xác. Vui lòng thử lại.'
      );
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (e) {}
    setCurrentUser(null);
  };

  const handleSaveSettings = async () => {
    await saveLiveSettingsToFirestore(settings);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 4000);
  };

  const handleAddAdmin = () => {
    if (!newAdminEmail || settings.adminList.includes(newAdminEmail)) return;
    setSettings((prev) => ({
      ...prev,
      adminList: [...prev.adminList, newAdminEmail.trim().toLowerCase()]
    }));
    setNewAdminEmail('');
  };

  const handleRemoveAdmin = (targetEmail: string) => {
    if (targetEmail === 'admin@example.com') {
      alert('Không thể xóa Super Admin gốc!');
      return;
    }
    setSettings((prev) => ({
      ...prev,
      adminList: prev.adminList.filter((e) => e !== targetEmail)
    }));
  };

  const handleTestPushNotification = async () => {
    await requestPushNotificationPermission();
    setPushSentSuccess(true);
    setTimeout(() => setPushSentSuccess(false), 4000);
  };

  const handleAddCustomApk = () => {
    if (!newApkName.trim() || !newApkUrl.trim()) {
      alert('Vui lòng nhập tên ứng dụng và đường link tải tệp APK!');
      return;
    }
    const newApkItem: any = {
      id: 'custom-' + Date.now(),
      name: newApkName.trim(),
      version: newApkVersion.trim() || '1.0.0',
      size: newApkSize.trim() || '15 MB',
      downloadUrl: newApkUrl.trim(),
      category: newApkCategory,
      description: newApkDesc.trim() || 'Ứng dụng đã qua kiểm duyệt bảo mật bởi Ban Quản Trị.',
      recommendedFor: newApkRecommended.trim() || 'Mọi dòng điện thoại Android',
      sha256: 'custom-verified-secure'
    };

    setSettings((prev) => ({
      ...prev,
      customApkList: [...(prev.customApkList || []), newApkItem]
    }));

    setNewApkName('');
    setNewApkUrl('');
    setNewApkDesc('');
    alert(`Đã thêm "${newApkItem.name}" vào danh sách! Hãy nhấn "Lưu Thay Đổi Cấu Hình" để công khai cho người dùng.`);
  };

  // Cấp VIP hàng loạt
  const handleBulkGrantVip = async () => {
    if (selectedUserIds.length === 0) return;
    const curVip = new Set((settings.vipUsers || []).map((k) => k.toLowerCase()));
    curVip.add('admin@example.com');

    selectedUserIds.forEach((id) => {
      const u = processedUserList.find((item) => item.userId === id);
      const userKey = (u?.email || id).toLowerCase();
      curVip.add(userKey);
    });

    const updatedVip = Array.from(curVip);
    const newSettings = { ...settings, vipUsers: updatedVip };
    setSettings(newSettings);
    await saveLiveSettingsToFirestore(newSettings);
    setBulkActionSuccess(`Đã cấp VIP thành công cho ${selectedUserIds.length} tài khoản đã chọn!`);
    setSelectedUserIds([]);
    setTimeout(() => setBulkActionSuccess(null), 5000);
  };

  // Thu hồi VIP hàng loạt
  const handleBulkRevokeVip = async () => {
    if (selectedUserIds.length === 0) return;
    const targetKeys = new Set(
      selectedUserIds.map((id) => {
        const u = processedUserList.find((item) => item.userId === id);
        return (u?.email || id).toLowerCase();
      })
    );

    const updatedVip = (settings.vipUsers || []).filter(
      (k) => !targetKeys.has(k.toLowerCase()) || k.toLowerCase() === 'admin@example.com'
    );
    const newSettings = { ...settings, vipUsers: updatedVip };
    setSettings(newSettings);
    await saveLiveSettingsToFirestore(newSettings);
    setBulkActionSuccess(`Đã thu hồi quyền VIP của ${selectedUserIds.length} tài khoản!`);
    setSelectedUserIds([]);
    setTimeout(() => setBulkActionSuccess(null), 5000);
  };

  // Chọn hoặc bỏ chọn tất cả trang hiện tại
  const handleToggleSelectAll = (currentPageUserIds: string[]) => {
    const allSelected = currentPageUserIds.every((id) => selectedUserIds.includes(id));
    if (allSelected) {
      setSelectedUserIds((prev) => prev.filter((id) => !currentPageUserIds.includes(id)));
    } else {
      setSelectedUserIds((prev) => Array.from(new Set([...prev, ...currentPageUserIds])));
    }
  };

  const handleDeleteCustomApk = (id: string) => {
    setSettings((prev) => ({
      ...prev,
      customApkList: (prev.customApkList || []).filter((item: any) => item.id !== id)
    }));
  };

  const renderApkLinksConfigCard = () => (
    <div className="p-3.5 rounded-xl bg-emerald-950/30 border border-emerald-500/30 space-y-3">
      <div className="text-xs font-bold text-emerald-300 flex items-center space-x-1.5">
        <Smartphone className="w-4 h-4 shrink-0" />
        <span>Link Tải App MagicTune APK (Google Drive &amp; GitHub)</span>
      </div>

      <div>
        <label className="block text-[11px] font-semibold text-emerald-200 mb-1">
          Link Tải Từ Google Drive:
        </label>
        <input
          type="url"
          placeholder="https://drive.google.com/drive/folders/..."
          value={settings.magicTuneApkUrl || ''}
          onChange={(e) => setSettings({ ...settings, magicTuneApkUrl: e.target.value })}
          className="w-full bg-[#0A0F1D] border border-emerald-500/40 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-emerald-400"
        />
      </div>

      <div>
        <label className="block text-[11px] font-semibold text-cyan-200 mb-1">
          Link Tải Từ GitHub Releases:
        </label>
        <input
          type="url"
          placeholder="https://github.com/username/MagicTune/releases"
          value={settings.magicTuneGithubApkUrl || ''}
          onChange={(e) => setSettings({ ...settings, magicTuneGithubApkUrl: e.target.value })}
          className="w-full bg-[#0A0F1D] border border-cyan-500/40 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-cyan-400"
        />
      </div>

      <p className="text-[10px] text-slate-400 leading-relaxed">
        Cả 2 đường dẫn được hiển thị song song tại ô tải MagicTune APK đầu trang (Mobile &amp; PC) và hộp thoại của nút Cài App trên Header. Nhấn nút Lưu Cấu Hình để áp dụng ngay.
      </p>
    </div>
  );

  const filteredLogs = activityLogs.filter((log) => {
    const matchSearch =
      log.action.toLowerCase().includes(searchLog.toLowerCase()) ||
      (log.details || '').toLowerCase().includes(searchLog.toLowerCase()) ||
      (log.userEmail || '').toLowerCase().includes(searchLog.toLowerCase()) ||
      log.userId.toLowerCase().includes(searchLog.toLowerCase());

    if (logFilter === 'all') return matchSearch;
    return matchSearch && log.userType === logFilter;
  });

  // Tổng hợp định danh người dùng thật (đã đăng ký & admin), loại trừ hoàn toàn người dùng ẩn danh
  const realUserIds = new Set<string>();
  activityLogs.forEach((l) => {
    if ((l.userType === 'registered' || l.userType === 'admin') && !l.userId?.startsWith('anon_')) {
      realUserIds.add(l.userId);
    }
  });
  dbUsers.forEach((u) => {
    if (u.userId && !u.userId.startsWith('anon_')) {
      realUserIds.add(u.userId);
    }
  });

  const totalRealUsers = realUserIds.size;
  const majorActionsCount = activityLogs.length;
  const adminCount = settings.adminList.length;
  const vipUsersCount = (settings.vipUsers || []).length;
  const pendingReviewCount = pendingPayments.filter((p) => p.status !== 'approved').length;

  // Gom nhóm và xử lý danh sách người dùng thật từ dbUsers và activityLogs
  // eslint-disable-next-line react-hooks/preserve-manual-memoization
  const processedUserList = React.useMemo(() => {
    const userMap: Record<
      string,
      {
        userId: string;
        displayName: string;
        email?: string;
        phone?: string;
        photoURL?: string;
        role: 'admin' | 'registered';
        emailVerified?: boolean;
        primaryProvider: string;
        linkedProviders: string[];
        providerDetails?: any[];
        deviceModel?: string;
        actionCount: number;
        lastActive: string;
        lastAction: string;
        lastLoginAt?: number;
        createdAt?: number;
        lastActiveTimestamp: number;
        historyLogs: UserActivityLog[];
      }
    > = {};

    dbUsers.forEach((u) => {
      if (!u.userId || u.userId.startsWith('anon_')) return;
      const emailLower = (u.email || '').toLowerCase();
      const isAdmin = u.role === 'admin' || settings.adminList.includes(emailLower);

      let provider = u.primaryProvider;
      if (!provider) {
        if (u.linkedProviders?.includes('google.com')) provider = 'google';
        else if (u.linkedProviders?.includes('facebook.com')) provider = 'facebook';
        else if (u.linkedProviders?.includes('phone')) provider = 'phone';
        else if (u.linkedProviders?.includes('password')) provider = 'password';
        else provider = u.email ? 'email' : 'google';
      }

      // Tính timestamp hoạt động chuẩn xác từ Firestore
      const activeMs = parseToEpochMs(u.lastActive);
      const loginMs = parseToEpochMs(u.lastLoginAt);
      const createdMs = parseToEpochMs(u.createdAt);
      const bestActiveTs = Math.max(activeMs, loginMs, createdMs);

      userMap[u.userId] = {
        userId: u.userId,
        displayName: u.displayName || (u.email ? u.email.split('@')[0] : 'Chưa cập nhật tên'),
        email: u.email,
        phone: u.phone,
        photoURL: u.photoURL,
        role: isAdmin ? 'admin' : 'registered',
        emailVerified: u.emailVerified,
        primaryProvider: provider,
        linkedProviders: u.linkedProviders || (u.email ? ['password'] : []),
        providerDetails: u.providerDetails || [],
        deviceModel: (u.lastDeviceModel && u.lastDeviceModel !== 'HONOR Device') ? u.lastDeviceModel : '',
        actionCount: 0,
        lastActive: bestActiveTs > 0 ? formatVietnamDateTime(bestActiveTs) : 'Chưa rõ',
        lastAction: 'Đã đăng ký tài khoản',
        lastLoginAt: loginMs > 0 ? loginMs : undefined,
        createdAt: createdMs > 0 ? createdMs : undefined,
        lastActiveTimestamp: bestActiveTs,
        historyLogs: []
      };
    });

    activityLogs.forEach((log) => {
      const id = log.userId;
      if (!id || id.startsWith('anon_') || log.userType === 'anonymous') return;

      const emailLower = (log.userEmail || '').toLowerCase();
      const isAdmin = log.userType === 'admin' || settings.adminList.includes(emailLower);

      // Ưu tiên createdAt (số ms epoch). Nếu thiếu mới dùng regex parse từ timestamp vi-VN
      const logTs = (typeof log.createdAt === 'number' && log.createdAt > 0)
        ? log.createdAt
        : parseToEpochMs(log.timestamp);

      if (!userMap[id]) {
        let inferredProvider = 'email';
        if (log.action.includes('Google')) inferredProvider = 'google';
        else if (log.action.includes('Facebook')) inferredProvider = 'facebook';
        else if (log.action.includes('SMS') || log.action.includes('OTP')) inferredProvider = 'phone';
        else if (log.action.includes('QR')) inferredProvider = 'qr';

        userMap[id] = {
          userId: id,
          displayName: log.userEmail ? log.userEmail.split('@')[0] : (log.phoneNumber || 'Chưa cập nhật tên'),
          email: log.userEmail,
          phone: log.phoneNumber,
          role: isAdmin ? 'admin' : 'registered',
          emailVerified: false,
          primaryProvider: inferredProvider,
          linkedProviders: inferredProvider ? [inferredProvider] : [],
          deviceModel: (log.deviceModel && log.deviceModel !== 'HONOR Device') ? log.deviceModel : '',
          actionCount: 0,
          lastActive: logTs > 0 ? formatVietnamDateTime(logTs) : (log.timestamp || 'Chưa rõ'),
          lastAction: log.action || 'Hoạt động',
          lastLoginAt: undefined,
          createdAt: logTs > 0 ? logTs : undefined,
          lastActiveTimestamp: logTs,
          historyLogs: []
        };
      }

      userMap[id].actionCount += 1;
      userMap[id].historyLogs.push(log);
      if (!userMap[id].email && log.userEmail) userMap[id].email = log.userEmail;
      if (!userMap[id].phone && log.phoneNumber) userMap[id].phone = log.phoneNumber;
      if (log.deviceModel && log.deviceModel !== 'HONOR Device') {
        userMap[id].deviceModel = log.deviceModel;
      }

      // Giữ mốc createdAt là thời điểm sớm nhất ghi nhận được về người dùng này
      if (logTs > 0) {
        if (!userMap[id].createdAt || logTs < userMap[id].createdAt) {
          userMap[id].createdAt = logTs;
        }
      }

      // CHỈ cập nhật lastActive và lastAction nếu log này có thời gian MỚI HƠN hoặc BẰNG mốc hiện tại
      // Tuyệt đối không để log cũ hơn trong danh sách ghi đè lên thao tác mới nhất của user!
      if (logTs >= userMap[id].lastActiveTimestamp) {
        userMap[id].lastActiveTimestamp = logTs;
        userMap[id].lastActive = formatVietnamDateTime(logTs);
        if (log.action) userMap[id].lastAction = log.action;
      }
    });

    // Sắp xếp lại danh sách lịch sử thao tác của từng người dùng từ mới nhất -> cũ nhất
    Object.values(userMap).forEach((u) => {
      if (u.historyLogs.length > 1) {
        u.historyLogs.sort((a, b) => {
          const tsA = (typeof a.createdAt === 'number' && a.createdAt > 0) ? a.createdAt : parseToEpochMs(a.timestamp);
          const tsB = (typeof b.createdAt === 'number' && b.createdAt > 0) ? b.createdAt : parseToEpochMs(b.timestamp);
          return tsB - tsA;
        });
      }
    });

    const vipSet = new Set((settings.vipUsers || []).map((k) => k.toLowerCase()));
    vipSet.add('admin@example.com');

    return Object.values(userMap)
      .filter((u) => {
        const query = searchUser.toLowerCase();
        const matchText =
          (u.displayName || '').toLowerCase().includes(query) ||
          (u.email || '').toLowerCase().includes(query) ||
          (u.phone || '').includes(query) ||
          u.userId.toLowerCase().includes(query) ||
          (u.deviceModel || '').toLowerCase().includes(query);

        if (!matchText) return false;

        const userKey = (u.email || u.userId).toLowerCase();
        const isVip = vipSet.has(userKey) || (u.email || '').toLowerCase() === 'admin@example.com';

        if (userRoleFilter === 'vip') return isVip;
        if (userRoleFilter === 'admin') return u.role === 'admin';
        if (userRoleFilter === 'registered') return u.role === 'registered';
        return true;
      })
      .sort((a, b) => b.lastActiveTimestamp - a.lastActiveTimestamp);
  }, [dbUsers, activityLogs, searchUser, userRoleFilter, settings.adminList, settings.vipUsers]);

  if (authLoading) {
    return (
      <div className="min-h-screen bg-[#0A0F1D] flex flex-col items-center justify-center p-4">
        <div className="w-10 h-10 border-3 border-cyan-400 border-t-transparent rounded-full animate-spin mb-3" />
        <p className="text-xs text-slate-400 font-mono">Đang kiểm tra quyền quản trị viên...</p>
      </div>
    );
  }

  const userEmailLower = (currentUser?.email || '').toLowerCase();
  const userPhone = currentUser?.phoneNumber || '';
  const isUserAdmin = Boolean(
    currentUser && (
      SUPER_ADMIN_EMAILS.includes(userEmailLower) ||
      (settings.adminList || []).map((e) => e.toLowerCase()).includes(userEmailLower) ||
      (userPhone && SUPER_ADMIN_PHONES.includes(userPhone))
    )
  );

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-[#0A0F1D] flex items-center justify-center p-4">
        <div className="relative w-full max-w-md rounded-2xl border border-cyan-500/30 bg-[#111A2E]/95 backdrop-blur-xl p-8 shadow-2xl shadow-cyan-950/40">
          <button
            onClick={onBackToHome}
            className="flex items-center space-x-1.5 text-xs text-slate-400 hover:text-white mb-6 transition-all"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Quay lại trang chủ MagicTune</span>
          </button>

          <div className="flex items-center space-x-3 mb-6">
            <div className="p-3 rounded-2xl bg-gradient-to-tr from-[#00F0FF] to-[#8B5CF6] text-black">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white tracking-wide">Quản Trị Viên MagicTune</h2>
              <p className="text-xs text-slate-400">Firebase Cloud Firestore Live Database</p>
            </div>
          </div>

          {loginError && (
            <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{loginError}</span>
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Email Quản Trị:</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@example.com"
                  className="w-full bg-[#0A0F1D] border border-cyan-500/20 rounded-xl pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Mật khẩu Quản trị viên:</label>
              <div className="relative">
                <KeyRound className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Nhập mật khẩu an toàn"
                  className="w-full bg-[#0A0F1D] border border-cyan-500/20 rounded-xl pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoggingIn}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#00F0FF] to-blue-600 hover:from-cyan-400 text-black font-extrabold text-xs transition-all shadow-lg shadow-cyan-500/25 flex items-center justify-center space-x-2"
            >
              {isLoggingIn ? (
                <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
              ) : (
                <span>Đăng Nhập Quản Trị</span>
              )}
            </button>
          </form>
        </div>
      </div>
    );
  }

  // Khóa phân quyền: Ngăn chặn tuyệt đối người dùng thường truy cập trái phép vào Bảng Quản Trị
  if (currentUser && !isUserAdmin) {
    return (
      <div className="min-h-screen bg-[#0A0F1D] flex items-center justify-center p-4">
        <div className="relative w-full max-w-md rounded-2xl border border-rose-500/30 bg-[#111A2E]/95 backdrop-blur-xl p-8 shadow-2xl shadow-rose-950/40 text-center">
          <div className="w-16 h-16 mx-auto rounded-3xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 mb-5 shadow-lg shadow-rose-500/20">
            <Lock className="w-8 h-8" />
          </div>

          <h2 className="text-xl font-bold text-white mb-2">Truy Cập Bị Từ Chối</h2>
          <p className="text-xs text-rose-300 font-mono mb-4">403 Forbidden • Yêu cầu đặc quyền Admin</p>

          <p className="text-xs text-slate-300 leading-relaxed mb-6">
            Tài khoản <strong className="text-cyan-300">{currentUser.email || currentUser.phoneNumber || currentUser.uid}</strong> hiện tại không nằm trong danh sách Quản Trị Viên được ủy quyền của hệ thống MagicTune.
          </p>

          <div className="space-y-3">
            <button
              onClick={onBackToHome}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:brightness-110 text-black font-bold text-xs flex items-center justify-center space-x-2 transition-all shadow-md"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Quay Lại Trang Chủ MagicTune</span>
            </button>

            <button
              onClick={handleLogout}
              className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold flex items-center justify-center space-x-1.5 transition-all border border-slate-700"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Đăng xuất để đổi tài khoản khác</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0A0F1D] text-slate-100 flex flex-col font-sans">
      {/* Top Header: Thanh điều hướng rút gọn, tinh giản */}
      <header className="sticky top-0 z-40 border-b border-cyan-500/20 bg-[#0A0F1D]/90 backdrop-blur-xl">
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 h-14 sm:h-16 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <button
              onClick={onBackToHome}
              className="px-3 py-1.5 rounded-xl bg-[#111A2E] hover:bg-slate-800 text-slate-300 hover:text-white transition-all text-xs font-semibold flex items-center space-x-1.5 border border-slate-700/60"
            >
              <ArrowLeft className="w-4 h-4 text-[#00F0FF]" />
              <span>Về Trang Chủ</span>
            </button>
          </div>

          <div className="flex items-center space-x-3">
            <div className="text-right hidden sm:block">
              <div className="text-xs font-semibold text-white">{currentUser.email}</div>
              <div className="text-[10px] text-[#00F0FF] font-mono">Super Administrator</div>
            </div>
            <button
              onClick={handleLogout}
              className="px-3 py-1.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 text-xs font-semibold flex items-center space-x-1.5 transition-all"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Đăng xuất</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Container với Banner Tiêu Đề ĐẦU TRANG */}
      <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 pt-5 w-full space-y-4">
        {/* BANNER TÊN TRANG QUẢN TRỊ ĐẦU TRANG NỘI DUNG */}
        <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-[#111A2E]/95 via-[#0D182E]/90 to-[#111A2E]/95 border border-cyan-500/30 shadow-2xl backdrop-blur-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center space-x-3.5 sm:space-x-4">
            <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-gradient-to-tr from-[#00F0FF] via-cyan-400 to-[#8B5CF6] p-0.5 flex items-center justify-center shadow-lg shadow-cyan-500/25 shrink-0">
              <div className="w-full h-full rounded-[14px] bg-[#0A0F1D] overflow-hidden flex items-center justify-center">
                <img src="/icon.png" alt="MagicTune Admin" className="w-full h-full object-cover" />
              </div>
            </div>
            <div className="min-w-0">
              <div className="flex items-center space-x-2 flex-wrap gap-y-1">
                <h1 className="text-xl sm:text-2xl md:text-3xl font-black text-white tracking-wide leading-tight">
                  Bảng Điều Khiển Quản Trị {settings.appName || 'MagicTune'}
                </h1>
                <span className="text-xs px-2 py-0.5 rounded-lg bg-gradient-to-r from-cyan-500/20 to-blue-500/20 text-[#00F0FF] border border-cyan-500/40 font-mono font-black tracking-wider shadow-sm">
                  Super Admin
                </span>
                <span className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 text-[10px] font-mono">
                  <Cloud className="w-3 h-3 text-emerald-400" />
                  <span>Cloud Firestore Live</span>
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 mt-1 font-medium leading-relaxed">
                Hệ thống quản trị tập trung: Quản lý người dùng thật, cấp quyền VIP, đối soát chuyển khoản, cấu hình sàn & theo dõi nhật ký hoạt động.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2 shrink-0 self-start md:self-center flex-wrap gap-2">
            <button
              onClick={handlePurgeOldData}
              disabled={isPurging}
              className="px-3.5 py-2 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/30 text-xs font-bold transition-all flex items-center space-x-1.5 shadow-sm active:scale-95"
              title="Dọn sạch nhật ký và lỗi lệnh các ngày cũ để tiết kiệm tối đa chi phí Firestore"
            >
              <Trash2 className={`w-3.5 h-3.5 ${isPurging ? 'animate-bounce text-amber-400' : ''}`} />
              <span>{isPurging ? 'Đang Dọn...' : 'Dọn Sạch Dữ Liệu Ngày Cũ'}</span>
            </button>

            <button
              onClick={reloadAllDataFromFirestore}
              disabled={isLoadingLogs}
              className="px-3.5 py-2 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 text-[#00F0FF] border border-cyan-500/30 text-xs font-bold transition-all flex items-center space-x-1.5 shadow-sm active:scale-95"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoadingLogs ? 'animate-spin' : ''}`} />
              <span>Đồng Bộ Dữ Liệu</span>
            </button>
          </div>
        </div>

        {/* Thông báo kết quả dọn dẹp tiết kiệm chi phí */}
        {purgeNotice && (
          <div className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-500/20 via-cyan-500/15 to-emerald-500/20 border border-amber-500/40 text-xs text-amber-200 flex items-center justify-between shadow-lg animate-in fade-in">
            <div className="flex items-center space-x-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{purgeNotice}</span>
            </div>
            <button onClick={() => setPurgeNotice(null)} className="text-slate-400 hover:text-white text-xs font-bold ml-2">
              ✕
            </button>
          </div>
        )}

        {/* Main Stats Banner */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
          <div className="p-4 rounded-xl bg-[#111A2E] border border-cyan-500/15">
            <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
              <span>Tổng người dùng thật</span>
              <Users className="w-4 h-4 text-[#00F0FF]" />
            </div>
            <div className="text-2xl font-black text-white">{totalRealUsers}</div>
            <div className="text-[10px] text-cyan-400 mt-0.5">Tài khoản Google / Email / SĐT thật</div>
          </div>

          <div className="p-4 rounded-xl bg-[#111A2E] border border-cyan-500/15">
            <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
              <span>Hoạt động trọng yếu</span>
              <Activity className="w-4 h-4 text-purple-400" />
            </div>
            <div className="text-2xl font-black text-purple-300">{majorActionsCount}</div>
            <div className="text-[10px] text-purple-400 mt-0.5">Đã lọc bỏ thao tác vãng lai & ẩn danh</div>
          </div>

          <div className="p-4 rounded-xl bg-[#111A2E] border border-cyan-500/15">
            <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
              <span>Thành viên VIP đã cấp</span>
              <Crown className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-2xl font-black text-amber-300">{vipUsersCount}</div>
            <div className="text-[10px] text-amber-400 mt-0.5">Mở khóa toàn bộ chức năng cao cấp</div>
          </div>

          <div className="p-4 rounded-xl bg-[#111A2E] border border-cyan-500/15 cursor-pointer hover:border-cyan-500/50 transition-all" onClick={() => setAdminTab('billing')}>
            <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
              <span>Giao dịch &amp; Quản trị</span>
              <CreditCard className="w-4 h-4 text-cyan-400" />
            </div>
            <div className="text-2xl font-black text-cyan-300">{pendingReviewCount} chờ / {adminCount} QTV</div>
            <div className="text-[10px] text-cyan-400 mt-0.5">Nhấn để kiểm tra thu phí &amp; kho APK</div>
          </div>
        </div>

        {/* Navigation Tabs Dạng Menu Lưới (8 Tab chính thức gọn gàng) */}
        <div className="grid grid-cols-2 sm:grid-cols-4 xl:grid-cols-8 gap-2 pb-2">
          <button
            onClick={() => setAdminTab('logs')}
            className={`flex items-center space-x-2 p-2.5 rounded-2xl text-xs font-bold transition-all text-left border ${
              adminTab === 'logs'
                ? 'bg-[#00F0FF] text-black border-cyan-300 shadow-md shadow-cyan-500/25 scale-[1.02]'
                : 'bg-[#111A2E]/80 text-slate-300 border-slate-700/80 hover:border-slate-500 hover:bg-[#16223d]'
            }`}
          >
            <Activity className="w-4 h-4 shrink-0 text-[#00F0FF] group-hover:text-cyan-300" />
            <div className="truncate min-w-0">
              <span className="block text-[9px] font-black uppercase opacity-70">Tab 1</span>
              <span className="truncate block font-semibold text-[11px]">Nhật Ký (Logs)</span>
            </div>
          </button>

          <button
            onClick={() => setAdminTab('users')}
            className={`flex items-center space-x-2 p-2.5 rounded-2xl text-xs font-bold transition-all text-left border ${
              adminTab === 'users'
                ? 'bg-gradient-to-r from-emerald-400 to-teal-500 text-black border-emerald-300 shadow-md shadow-emerald-500/25 scale-[1.02]'
                : 'bg-[#111A2E]/80 text-emerald-400 border-emerald-500/30 hover:border-emerald-400 hover:bg-[#16223d]'
            }`}
          >
            <Users className="w-4 h-4 shrink-0" />
            <div className="truncate min-w-0">
              <span className="block text-[9px] font-black uppercase opacity-70">Tab 2</span>
              <span className="truncate block font-semibold text-[11px]">Quản Lý User / VIP</span>
            </div>
          </button>

          <button
            onClick={() => setAdminTab('seo_adsense')}
            className={`flex items-center space-x-2 p-2.5 rounded-2xl text-xs font-bold transition-all text-left border ${
              adminTab === 'seo_adsense'
                ? 'bg-gradient-to-r from-[#00F0FF] to-blue-500 text-black border-cyan-300 shadow-md shadow-cyan-500/25 scale-[1.02]'
                : 'bg-[#111A2E]/80 text-amber-400 border-amber-500/30 hover:border-amber-400 hover:bg-[#16223d]'
            }`}
          >
            <Megaphone className="w-4 h-4 shrink-0" />
            <div className="truncate min-w-0">
              <span className="block text-[9px] font-black uppercase opacity-70">Tab 3</span>
              <span className="truncate block font-semibold text-[11px]">SEO &amp; AdSense</span>
            </div>
          </button>

          <button
            onClick={() => setAdminTab('fcm_push')}
            className={`flex items-center space-x-2 p-2.5 rounded-2xl text-xs font-bold transition-all text-left border ${
              adminTab === 'fcm_push'
                ? 'bg-[#8B5CF6] text-white border-purple-300 shadow-md shadow-purple-500/25 scale-[1.02]'
                : 'bg-[#111A2E]/80 text-purple-400 border-purple-500/30 hover:border-purple-400 hover:bg-[#16223d]'
            }`}
          >
            <Bell className="w-4 h-4 shrink-0" />
            <div className="truncate min-w-0">
              <span className="block text-[9px] font-black uppercase opacity-70">Tab 4</span>
              <span className="truncate block font-semibold text-[11px]">Thông Báo FCM</span>
            </div>
          </button>

          <button
            onClick={() => setAdminTab('settings')}
            className={`flex items-center space-x-2 p-2.5 rounded-2xl text-xs font-bold transition-all text-left border ${
              adminTab === 'settings'
                ? 'bg-[#00F0FF] text-black border-cyan-300 shadow-md shadow-cyan-500/25 scale-[1.02]'
                : 'bg-[#111A2E]/80 text-slate-300 border-slate-700/80 hover:border-slate-500 hover:bg-[#16223d]'
            }`}
          >
            <Globe className="w-4 h-4 shrink-0" />
            <div className="truncate min-w-0">
              <span className="block text-[9px] font-black uppercase opacity-70">Tab 5</span>
              <span className="truncate block font-semibold text-[11px]">Cài Đặt Thương Hiệu</span>
            </div>
          </button>

          <button
            onClick={() => setAdminTab('billing')}
            className={`flex items-center space-x-2 p-2.5 rounded-2xl text-xs font-bold transition-all text-left border ${
              adminTab === 'billing'
                ? 'bg-gradient-to-r from-amber-400 to-orange-500 text-black border-amber-300 shadow-md shadow-amber-500/25 scale-[1.02]'
                : 'bg-[#111A2E]/80 text-amber-300 border-amber-500/30 hover:border-amber-400 hover:bg-[#16223d]'
            }`}
          >
            <CreditCard className="w-4 h-4 shrink-0" />
            <div className="truncate min-w-0">
              <span className="block text-[9px] font-black uppercase opacity-70">Tab 6</span>
              <span className="truncate block font-semibold text-[11px]">Thu Phí &amp; Ngân Hàng</span>
            </div>
          </button>

          <button
            onClick={() => setAdminTab('adb_remote')}
            className={`flex items-center space-x-2 p-2.5 rounded-2xl text-xs font-bold transition-all text-left border ${
              adminTab === 'adb_remote'
                ? 'bg-[#8B5CF6] text-white border-purple-300 shadow-md shadow-purple-500/25 scale-[1.02]'
                : 'bg-[#111A2E]/80 text-purple-400 border-purple-500/30 hover:border-purple-400 hover:bg-[#16223d]'
            }`}
          >
            <Terminal className="w-4 h-4 shrink-0" />
            <div className="truncate min-w-0">
              <span className="block text-[9px] font-black uppercase opacity-70">Tab 7</span>
              <span className="truncate block font-semibold text-[11px]">Script ADB Console</span>
            </div>
          </button>

          <button
            onClick={() => setAdminTab('custom_apk')}
            className={`flex items-center space-x-2 p-2.5 rounded-2xl text-xs font-bold transition-all text-left border ${
              adminTab === 'custom_apk'
                ? 'bg-gradient-to-r from-cyan-400 to-emerald-400 text-black border-cyan-300 shadow-md shadow-cyan-500/25 scale-[1.02]'
                : 'bg-[#111A2E]/80 text-cyan-300 border-cyan-500/30 hover:border-cyan-400 hover:bg-[#16223d]'
            }`}
          >
            <UploadCloud className="w-4 h-4 shrink-0 text-cyan-400" />
            <div className="truncate min-w-0">
              <span className="block text-[9px] font-black uppercase opacity-70">Tab 8</span>
              <span className="truncate block font-semibold text-[11px]">Kho APK &amp; Tải Lên</span>
            </div>
          </button>
        </div>
      </div>

      {/* Main Tab Views */}
      <main className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-6 flex-1 w-full space-y-6">
        {saveSuccess && (
          <div className="p-4 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-semibold flex items-center space-x-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>Đã đồng bộ và lưu dữ liệu thành công lên Cloud Firestore!</span>
          </div>
        )}

        {/* TAB 1: LOGS HÀNH ĐỘNG */}
        {adminTab === 'logs' && (
          <div className="p-6 rounded-2xl bg-[#111A2E]/90 border border-cyan-500/20 shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-800 gap-3">
              <div>
                <h3 className="text-base font-bold text-white flex items-center space-x-2 flex-wrap gap-y-1">
                  <Activity className="w-5 h-5 text-[#00F0FF]" />
                  <span>Nhật Ký Hoạt Động Trong Ngày (Hôm Nay: {getTodayDateKey()})</span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 font-sans font-bold">
                    ⚡ Tiết kiệm chi phí: Chỉ nạp dữ liệu hôm nay
                  </span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Chỉ lưu và hiển thị nhật ký hoạt động của người dùng thật &amp; quản trị viên trong ngày hôm nay. Dữ liệu các ngày trước được dọn sạch để tối ưu 100% chi phí đọc/ghi và lưu trữ Firebase.
                </p>
              </div>

              <div className="flex items-center space-x-2 flex-wrap gap-2">
                <button
                  onClick={handlePurgeOldData}
                  disabled={isPurging}
                  className="px-3 py-1.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/30 text-xs font-bold flex items-center space-x-1.5 transition-all shadow-sm"
                  title="Dọn sạch nhật ký các ngày cũ"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>{isPurging ? 'Đang dọn...' : 'Dọn Sạch Ngày Cũ'}</span>
                </button>

                <button
                  onClick={reloadAllDataFromFirestore}
                  disabled={isLoadingLogs}
                  className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center space-x-1.5 transition-all"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isLoadingLogs ? 'animate-spin text-[#00F0FF]' : ''}`} />
                  <span>{isLoadingLogs ? 'Đang đồng bộ...' : 'Tải lại từ Firestore'}</span>
                </button>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
              <div className="relative w-full sm:w-96 flex-1">
                <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={searchLog}
                  onChange={(e) => setSearchLog(e.target.value)}
                  placeholder="Tìm theo hành động, email, IP, ID thiết bị..."
                  className="w-full bg-[#0A0F1D] border border-cyan-500/20 rounded-xl pl-10 pr-3.5 py-2 text-xs sm:text-sm text-white focus:outline-none focus:border-cyan-400 shadow-inner"
                />
              </div>

              <div className="grid grid-cols-3 sm:flex items-center gap-1.5 w-full sm:w-auto">
                {(['all', 'registered', 'admin'] as const).map((t) => (
                  <button
                    key={t}
                    onClick={() => setLogFilter(t)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold capitalize text-center transition-all ${
                      logFilter === t
                        ? 'bg-[#00F0FF] text-black shadow-md shadow-cyan-500/20'
                        : 'bg-slate-800/80 text-slate-400 hover:text-white'
                    }`}
                  >
                    {t === 'all'
                      ? 'Tất cả hoạt động thật'
                      : t === 'registered'
                      ? 'Thành viên thật'
                      : 'Quản trị viên'}
                  </button>
                ))}
              </div>
            </div>

            <div className="rounded-xl border border-cyan-500/15 overflow-hidden bg-[#0A0F1D]/80">
              <div className="max-h-[500px] overflow-y-auto divide-y divide-slate-800/80 font-mono text-xs">
                {filteredLogs.length === 0 ? (
                  <div className="p-8 text-center text-slate-500 italic">
                    Chưa có nhật ký hoạt động nào. Hãy thử thực hiện các thao tác trên ứng dụng để xem log đẩy về Firestore!
                  </div>
                ) : (
                  filteredLogs
                    .slice((logPage - 1) * logPageSize, logPage * logPageSize)
                    .map((log) => (
                    <div
                      key={log.id}
                      className="p-3.5 hover:bg-[#111A2E]/70 transition-all flex flex-col md:flex-row md:items-center justify-between gap-2"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2 flex-wrap gap-y-1">
                          <span className="text-slate-400 font-mono text-[11px]">{formatVietnamDateTime(log.createdAt || log.timestamp)}</span>
                          {(log.createdAt || log.timestamp) && (
                            <span className="text-slate-500 text-[10px] font-mono">
                              ({getRelativeTimeString(log.createdAt || log.timestamp)})
                            </span>
                          )}
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-sans font-bold ${
                              log.userType === 'admin'
                                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                                : log.userType === 'registered'
                                ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                                : 'bg-slate-800 text-slate-400 border border-slate-700'
                            }`}
                          >
                            {log.userType === 'admin'
                              ? 'Admin'
                              : log.userType === 'registered'
                              ? 'Thành viên'
                              : 'Ẩn danh'}
                          </span>
                          <span className="text-[#00F0FF] font-sans font-semibold">
                            {typeof log.userEmail === 'object'
                              ? (log.userEmail as any)?.actorRole || JSON.stringify(log.userEmail)
                              : String(log.userEmail || log.phoneNumber || log.userId || '')}
                          </span>
                          {log.deviceModel && (
                            <span className="text-[10px] text-slate-400 bg-slate-900 px-1.5 py-0.5 rounded">
                              {typeof log.deviceModel === 'object' ? JSON.stringify(log.deviceModel) : String(log.deviceModel)}
                            </span>
                          )}
                        </div>
                        <div className="font-sans font-bold text-white text-xs">
                          {typeof log.action === 'object'
                            ? (log.action as any)?.actorRole || JSON.stringify(log.action)
                            : String(log.action || '')}
                        </div>
                        {log.details && (
                          <div className="text-[11px] text-slate-400 font-sans">
                            {typeof log.details === 'object'
                              ? (log.details as any)?.actorRole || JSON.stringify(log.details)
                              : String(log.details || '')}
                          </div>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Điều khiển phân trang cho Logs */}
            <Pagination
              currentPage={logPage}
              totalItems={filteredLogs.length}
              pageSize={logPageSize}
              onPageChange={(page) => setLogPage(page)}
            />
          </div>
        )}

        {/* TAB 2: QUẢN LÝ TÀI KHOẢN NGƯỜI DÙNG */}
        {adminTab === 'users' && (
          <div className="p-6 rounded-2xl bg-[#111A2E]/90 border border-cyan-500/20 shadow-xl space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-800 gap-3">
              <div className="flex items-center space-x-2.5">
                <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
                  <Users className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white tracking-wide">
                    Quản Lý Danh Sách Người Dùng Thật &amp; Phân Quyền
                  </h3>
                  <p className="text-xs text-slate-400">
                    Tra cứu tài khoản đăng ký thật (Google/Facebook/SĐT/Email), phân quyền Quản trị viên và cấp VIP
                  </p>
                </div>
              </div>

              {/* Tìm kiếm & Lọc */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full sm:w-auto">
                <div className="relative w-full sm:w-64">
                  <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchUser}
                    onChange={(e) => setSearchUser(e.target.value)}
                    placeholder="Tìm email, SĐT, UID..."
                    className="w-full bg-[#0A0F1D] border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs sm:text-sm text-white focus:outline-none focus:border-cyan-400"
                  />
                </div>

                {/* Chế độ hiển thị danh sách: Gọn gàng (Thẻ chi tiết) vs Bảng cổ điển */}
                <div className="flex items-center bg-[#0A0F1D] border border-slate-700 rounded-xl p-0.5">
                  <button
                    onClick={() => setUserListViewMode('compact')}
                    className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center space-x-1 ${
                      userListViewMode === 'compact'
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                        : 'text-slate-400 hover:text-white'
                    }`}
                    title="Hiển thị dạng thẻ chi tiết gọn gàng tối ưu cho điện thoại"
                  >
                    <Layout className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Gọn gàng</span>
                  </button>
                  <button
                    onClick={() => setUserListViewMode('detailed')}
                    className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center space-x-1 ${
                      userListViewMode === 'detailed'
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                        : 'text-slate-400 hover:text-white'
                    }`}
                    title="Hiển thị dạng bảng toàn diện"
                  >
                    <Layers className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Bảng</span>
                  </button>
                </div>
              </div>
            </div>

            {/* TAB DANH SÁCH RIÊNG: TẤT CẢ, DANH SÁCH VIP, QUẢN TRỊ VIÊN, THÀNH VIÊN */}
            <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 scrollbar-thin">
              <button
                onClick={() => { setUserRoleFilter('all'); setUserPage(1); }}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all flex items-center space-x-1.5 ${
                  userRoleFilter === 'all'
                    ? 'bg-cyan-500 text-black shadow-md shadow-cyan-500/30'
                    : 'bg-[#0A0F1D] text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                <Users className="w-3.5 h-3.5" />
                <span>Tất cả người dùng ({dbUsers.length || activityLogs.length})</span>
              </button>

              <button
                onClick={() => { setUserRoleFilter('vip'); setUserPage(1); }}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-extrabold shrink-0 transition-all flex items-center space-x-1.5 ${
                  userRoleFilter === 'vip'
                    ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-black shadow-md shadow-amber-500/30'
                    : 'bg-[#0A0F1D] text-amber-300/80 hover:text-amber-300 border border-amber-500/30 hover:border-amber-500/50'
                }`}
              >
                <Crown className="w-3.5 h-3.5 text-amber-400" />
                <span>⭐ Danh Sách VIP ({new Set([...(settings.vipUsers || []).map(k => k.toLowerCase()), 'admin@example.com']).size})</span>
              </button>

              <button
                onClick={() => { setUserRoleFilter('admin'); setUserPage(1); }}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all flex items-center space-x-1.5 ${
                  userRoleFilter === 'admin'
                    ? 'bg-purple-500 text-white shadow-md shadow-purple-500/30'
                    : 'bg-[#0A0F1D] text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Ban Quản Trị ({settings.adminList.length})</span>
              </button>

              <button
                onClick={() => { setUserRoleFilter('registered'); setUserPage(1); }}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all flex items-center space-x-1.5 ${
                  userRoleFilter === 'registered'
                    ? 'bg-emerald-500 text-black shadow-md shadow-emerald-500/30'
                    : 'bg-[#0A0F1D] text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Thành viên đăng ký</span>
              </button>
            </div>

            {/* THANH THAO TÁC CẤP / THU HỒI VIP HÀNG LOẠT KHI CHỌN */}
            {selectedUserIds.length > 0 && (
              <div className="p-3 rounded-xl bg-gradient-to-r from-amber-500/15 via-cyan-500/15 to-purple-500/15 border border-amber-500/40 flex flex-wrap items-center justify-between gap-3 animate-fadeIn">
                <div className="flex items-center space-x-2 text-xs font-bold text-white">
                  <CheckSquare className="w-4 h-4 text-amber-400" />
                  <span>
                    Đã chọn <span className="text-amber-300 font-mono text-sm">{selectedUserIds.length}</span> tài khoản
                  </span>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={handleBulkGrantVip}
                    className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-black font-extrabold text-xs shadow-md shadow-amber-500/20 flex items-center space-x-1.5 transition-all"
                  >
                    <Crown className="w-3.5 h-3.5" />
                    <span>Cấp VIP Hàng Loạt</span>
                  </button>

                  <button
                    onClick={handleBulkRevokeVip}
                    className="px-3 py-1.5 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 font-bold text-xs flex items-center space-x-1.5 transition-all"
                  >
                    <XCircle className="w-3.5 h-3.5" />
                    <span>Thu Hồi VIP</span>
                  </button>

                  <button
                    onClick={() => setSelectedUserIds([])}
                    className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white text-xs font-semibold transition-all"
                  >
                    Bỏ chọn
                  </button>
                </div>
              </div>
            )}

            {bulkActionSuccess && (
              <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center space-x-2 animate-fadeIn">
                <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{bulkActionSuccess}</span>
              </div>
            )}

            {/* BẢNG YÊU CẦU ĐỐI SOÁT CHUYỂN KHOẢN (DUYỆT TIỀN & CẤP VIP TỰ ĐỘNG) */}
            <div className="p-4 rounded-xl bg-[#0A0F1D] border border-amber-500/30 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2 text-amber-400 text-xs font-bold uppercase tracking-wide">
                  <CreditCard className="w-4 h-4" />
                  <span>Danh Sách Người Dùng Báo Đã Chuyển Tiền Mua VIP ({pendingPayments.filter(p => p.status === 'pending_review').length} chờ duyệt)</span>
                </div>
                <button
                  onClick={reloadAllDataFromFirestore}
                  className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] flex items-center space-x-1"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span>Làm mới</span>
                </button>
              </div>

              {pendingPayments.length === 0 ? (
                <div className="text-slate-500 text-xs italic py-2 text-center bg-slate-900/40 rounded-lg">
                  Chưa có giao dịch chuyển khoản nào cần đối soát. Khi người dùng bấm &quot;Tôi Đã Chuyển Tiền Xong&quot;, yêu cầu sẽ lập tức xuất hiện tại đây.
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs text-slate-300">
                    <thead className="text-[10px] uppercase text-slate-400 border-b border-slate-800">
                      <tr>
                        <th className="py-2 px-3">Thời gian</th>
                        <th className="py-2 px-3">Người chuyển</th>
                        <th className="py-2 px-3">Số tiền</th>
                        <th className="py-2 px-3">Nội dung</th>
                        <th className="py-2 px-3">Trạng thái</th>
                        <th className="py-2 px-3 text-right">Duyệt cấp VIP</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                      {pendingPayments
                        .slice((pendingPaymentPage - 1) * pendingPaymentPageSize, pendingPaymentPage * pendingPaymentPageSize)
                        .map((pay) => {
                        const targetKey = (pay.userEmail && pay.userEmail !== 'N/A') ? pay.userEmail.toLowerCase() : pay.userId?.toLowerCase();
                        const isGrantedVip = (settings.vipUsers || []).includes(targetKey);

                        const handleApproveAndGrantVip = async () => {
                          // 1. Thêm vào danh sách VIP
                          if (targetKey && !isGrantedVip) {
                            const updatedVip = [...(settings.vipUsers || []), targetKey];
                            const newSettings = { ...settings, vipUsers: updatedVip };
                            setSettings(newSettings);
                            await saveLiveSettingsToFirestore(newSettings);
                          }
                          // 2. Cập nhật trạng thái Firestore của transaction
                          try {
                            await updateDoc(doc(db, 'payment_transactions', pay.id), {
                              status: 'approved',
                              approvedAt: Date.now()
                            });
                          } catch (e) {}
                          // 3. Cập nhật state nội bộ
                          setPendingPayments(prev =>
                            prev.map(p => p.id === pay.id ? { ...p, status: 'approved' } : p)
                          );
                        };

                        return (
                          <tr key={pay.id} className="hover:bg-slate-800/40">
                            <td className="py-2.5 px-3 text-slate-400">{pay.timestamp || 'Mới đây'}</td>
                            <td className="py-2.5 px-3 font-sans font-bold text-white">
                              {pay.userEmail && pay.userEmail !== 'N/A' ? pay.userEmail : pay.userId}
                            </td>
                            <td className="py-2.5 px-3 text-amber-400 font-bold">
                              {(pay.amount || 199000).toLocaleString('vi-VN')} đ
                            </td>
                            <td className="py-2.5 px-3 text-cyan-300 font-bold">{pay.transferContent}</td>
                            <td className="py-2.5 px-3">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-sans font-bold ${
                                pay.status === 'approved'
                                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                                  : 'bg-amber-500/20 text-amber-300 border border-amber-500/30 animate-pulse'
                              }`}>
                                {pay.status === 'approved' ? 'Đã duyệt VIP' : 'Chờ kiểm tra'}
                              </span>
                            </td>
                            <td className="py-2.5 px-3 text-right">
                              {pay.status !== 'approved' ? (
                                <button
                                  onClick={handleApproveAndGrantVip}
                                  className="px-3 py-1 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-[11px] font-sans shadow-md shadow-emerald-500/20 transition-all"
                                >
                                  Khớp Tiền & Cấp VIP Ngay
                                </button>
                              ) : (
                                <span className="text-emerald-400 text-[11px] font-sans font-semibold flex items-center justify-end space-x-1">
                                  <CheckCircle2 className="w-3.5 h-3.5" />
                                  <span>Đã Cấp Thành Công</span>
                                </span>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                  <div className="p-2 border-t border-slate-800">
                    <Pagination
                      currentPage={pendingPaymentPage}
                      totalItems={pendingPayments.length}
                      pageSize={pendingPaymentPageSize}
                      onPageChange={(page) => setPendingPaymentPage(page)}
                    />
                  </div>
                </div>
              )}
            </div>

            {/* DANH SÁCH NGƯỜI DÙNG: CHẾ ĐỘ THẺ GỌN GÀNG (TỐI ƯU ĐIỆN THOẠI) HOẶC BẢNG CỔ ĐIỂN */}
            {userListViewMode === 'compact' ? (
              <div className="space-y-3">
                {/* Thanh chọn tất cả ở chế độ thẻ */}
                <div className="flex items-center justify-between px-3 py-2 bg-[#0A0F1D] rounded-xl border border-slate-800 text-xs">
                  <button
                    onClick={() => {
                      const currentPageIds = processedUserList
                        .slice((userPage - 1) * userPageSize, userPage * userPageSize)
                        .map((u) => u.userId);
                      handleToggleSelectAll(currentPageIds);
                    }}
                    className="flex items-center space-x-2 text-slate-300 hover:text-white transition-colors"
                  >
                    {processedUserList
                      .slice((userPage - 1) * userPageSize, userPage * userPageSize)
                      .every((u) => selectedUserIds.includes(u.userId)) &&
                    processedUserList.length > 0 ? (
                      <CheckSquare className="w-4 h-4 text-cyan-400" />
                    ) : (
                      <Square className="w-4 h-4 text-slate-500" />
                    )}
                    <span className="font-semibold">Chọn tất cả trên trang này</span>
                  </button>

                  <span className="text-[11px] text-slate-400 font-mono">
                    Hiển thị {Math.min(userPage * userPageSize, processedUserList.length)} / {processedUserList.length}
                  </span>
                </div>

                {processedUserList.length === 0 ? (
                  <div className="p-8 text-center text-slate-500 italic bg-[#0A0F1D] rounded-2xl border border-slate-800">
                    Không tìm thấy tài khoản người dùng nào phù hợp.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {processedUserList
                      .slice((userPage - 1) * userPageSize, userPage * userPageSize)
                      .map((u) => {
                        const userKey = (u.email || u.userId).toLowerCase();
                        const isSuperAdmin = (u.email || '').toLowerCase() === 'admin@example.com';
                        const isCurrentAdmin = u.role === 'admin' || settings.adminList.includes((u.email || '').toLowerCase());
                        const isVip = (settings.vipUsers || []).includes(userKey) || isSuperAdmin;
                        const isSelected = selectedUserIds.includes(u.userId);

                        const toggleVipUser = () => {
                          setSettings((prev) => {
                            const curVip = prev.vipUsers || [];
                            const updated = isVip
                              ? curVip.filter((k) => k !== userKey)
                              : [...curVip, userKey];
                            return { ...prev, vipUsers: updated };
                          });
                        };

                        const rawDisplayName =
                          u.displayName && u.displayName.trim() && u.displayName !== 'Chưa cập nhật tên'
                            ? u.displayName
                            : (u.email ? u.email.split('@')[0] : 'Chưa cập nhật họ tên');

                        const lastDeviceText =
                          u.deviceModel && u.deviceModel.trim() && u.deviceModel !== 'HONOR Device'
                            ? u.deviceModel
                            : 'Không rõ thiết bị';

                        return (
                          <div
                            key={u.userId}
                            className={`p-3.5 rounded-2xl border transition-all ${
                              isSelected
                                ? 'bg-cyan-950/20 border-cyan-500/60 shadow-lg shadow-cyan-950/40'
                                : isVip
                                ? 'bg-[#0E172B] border-amber-500/30 hover:border-amber-500/50'
                                : 'bg-[#0E172B] border-slate-800/80 hover:border-cyan-500/30'
                            }`}
                          >
                            {/* Dòng 1: Chọn + Avatar + Tên + Badge VIP & Role */}
                            <div className="flex items-start justify-between gap-2">
                              <div className="flex items-start space-x-2.5 min-w-0">
                                <button
                                  onClick={() => {
                                    setSelectedUserIds((prev) =>
                                      isSelected ? prev.filter((id) => id !== u.userId) : [...prev, u.userId]
                                    );
                                  }}
                                  className="mt-1 text-slate-500 hover:text-cyan-400 shrink-0"
                                >
                                  {isSelected ? (
                                    <CheckSquare className="w-4 h-4 text-cyan-400" />
                                  ) : (
                                    <Square className="w-4 h-4" />
                                  )}
                                </button>

                                {u.photoURL ? (
                                  <img
                                    src={u.photoURL}
                                    alt={rawDisplayName}
                                    className="w-10 h-10 rounded-full border border-cyan-500/40 object-cover shrink-0"
                                  />
                                ) : (
                                  <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-cyan-500 to-purple-600 flex items-center justify-center text-sm font-black text-white shrink-0 shadow">
                                    {(rawDisplayName || 'U')[0].toUpperCase()}
                                  </div>
                                )}

                                <div className="min-w-0">
                                  <div className="flex items-center space-x-1.5 flex-wrap">
                                    <span className="font-bold text-white text-xs sm:text-sm truncate max-w-[150px] sm:max-w-[200px]">
                                      {rawDisplayName}
                                    </span>
                                    {isVip && (
                                      <span className="px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[9px] font-black uppercase flex items-center space-x-0.5">
                                        <Crown className="w-2.5 h-2.5 text-amber-400" />
                                        <span>VIP</span>
                                      </span>
                                    )}
                                  </div>
                                  <div className="text-[11px] text-cyan-300 font-mono truncate max-w-[210px]">
                                    {u.email || u.phone || 'Chưa liên kết email/SĐT'}
                                  </div>
                                </div>
                              </div>

                              {/* Badge Vai trò */}
                              <span
                                className={`px-2 py-0.5 rounded-full text-[9px] font-bold border shrink-0 ${
                                  isSuperAdmin
                                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                                    : isCurrentAdmin
                                    ? 'bg-purple-500/20 text-purple-300 border-purple-500/30'
                                    : isVip
                                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                                    : 'bg-slate-800 text-slate-300 border-slate-700'
                                }`}
                              >
                                {isSuperAdmin ? 'Super Admin' : isCurrentAdmin ? 'Admin' : isVip ? 'VIP' : 'Thành viên'}
                              </span>
                            </div>

                            {/* Dòng 2: HOẠT ĐỘNG CUỐI CÙNG HIỆN RÕ RÀNG RA NGOÀI THẺ */}
                            <div className="mt-2.5 p-2 rounded-xl bg-[#0A0F1D]/80 border border-slate-800/80 flex items-center justify-between text-[11px]">
                              <div className="flex items-center space-x-1.5 min-w-0 text-slate-300">
                                <Clock className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                                <span className="font-semibold text-slate-400 shrink-0">Hoạt động cuối:</span>
                                <span className="text-white font-medium truncate" title={u.lastAction}>
                                  {u.lastAction || 'Đăng ký tài khoản'}
                                </span>
                              </div>
                              <div className="text-right shrink-0 ml-2">
                                <span className="text-[10px] text-cyan-300 font-mono">
                                  {u.lastActive || 'Chưa rõ'}
                                </span>
                                {u.lastActiveTimestamp > 0 && (
                                  <div className="text-[9px] text-slate-400 font-mono">
                                    {getRelativeTimeString(u.lastActiveTimestamp)}
                                  </div>
                                )}
                              </div>
                            </div>

                            {/* Dòng 3: Thiết bị & Lượt hoạt động & Provider */}
                            <div className="mt-2 flex items-center justify-between text-[10px] text-slate-400 flex-wrap gap-1">
                              <div className="flex items-center space-x-1 truncate max-w-[170px]">
                                <Smartphone className="w-3 h-3 text-cyan-400 shrink-0" />
                                <span className="truncate">{lastDeviceText}</span>
                              </div>

                              <div className="flex items-center space-x-2">
                                <span className="text-slate-500 font-mono">
                                  Lượt: <span className="text-cyan-300 font-bold">{u.actionCount}</span>
                                </span>

                                <span className="px-1.5 py-0.2 rounded bg-slate-800/80 text-slate-300 border border-slate-700/60 uppercase text-[9px] font-mono">
                                  {u.primaryProvider || 'Auth'}
                                </span>
                              </div>
                            </div>

                            {/* Dòng 4: Nút bấm thao tác (Chi tiết, Cấp VIP, Admin) */}
                            <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between gap-1.5">
                              <button
                                onClick={() => setSelectedUserDetail(u)}
                                className="flex-1 py-1.5 rounded-lg bg-cyan-500/15 hover:bg-cyan-500/25 text-cyan-300 border border-cyan-500/30 text-xs font-bold transition-all flex items-center justify-center space-x-1"
                              >
                                <Eye className="w-3.5 h-3.5" />
                                <span>Chi Tiết</span>
                              </button>

                              {!isSuperAdmin && (
                                <button
                                  onClick={toggleVipUser}
                                  className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center space-x-1 ${
                                    isVip
                                      ? 'bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/30'
                                      : 'bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30'
                                  }`}
                                >
                                  <Crown className="w-3.5 h-3.5" />
                                  <span>{isVip ? 'Thu Hồi VIP' : 'Cấp VIP'}</span>
                                </button>
                              )}

                              {u.email && !isSuperAdmin && (
                                <button
                                  onClick={() => {
                                    if (isCurrentAdmin) {
                                      handleRemoveAdmin(u.email!);
                                    } else {
                                      setSettings((prev) => ({
                                        ...prev,
                                        adminList: [...prev.adminList, u.email!.trim().toLowerCase()]
                                      }));
                                    }
                                  }}
                                  className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
                                    isCurrentAdmin
                                      ? 'bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/30'
                                      : 'bg-purple-500/15 hover:bg-purple-500/25 text-purple-300 border border-purple-500/30'
                                  }`}
                                  title={isCurrentAdmin ? 'Hạ quyền quản trị viên' : 'Thăng quyền quản trị viên'}
                                >
                                  {isCurrentAdmin ? 'Hạ Admin' : 'Thăng Admin'}
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      })}
                  </div>
                )}

                {/* Phân trang danh sách */}
                <div className="p-2 bg-[#0A0F1D] rounded-xl border border-slate-800">
                  <Pagination
                    currentPage={userPage}
                    totalItems={processedUserList.length}
                    pageSize={userPageSize}
                    onPageChange={(page) => setUserPage(page)}
                  />
                </div>
              </div>
            ) : (
              /* CHẾ ĐỘ BẢNG CỔ ĐIỂN */
              <div className="overflow-x-auto rounded-xl border border-slate-800">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-[#0A0F1D] text-slate-400 uppercase font-mono text-[11px] border-b border-slate-800">
                    <tr>
                      <th className="px-3 py-3 w-8">
                        <button
                          onClick={() => {
                            const currentPageIds = processedUserList
                              .slice((userPage - 1) * userPageSize, userPage * userPageSize)
                              .map((u) => u.userId);
                            handleToggleSelectAll(currentPageIds);
                          }}
                          className="text-slate-400 hover:text-white"
                        >
                          {processedUserList
                            .slice((userPage - 1) * userPageSize, userPage * userPageSize)
                            .every((u) => selectedUserIds.includes(u.userId)) &&
                          processedUserList.length > 0 ? (
                            <CheckSquare className="w-4 h-4 text-cyan-400" />
                          ) : (
                            <Square className="w-4 h-4" />
                          )}
                        </button>
                      </th>
                      <th className="px-4 py-3">Họ tên &amp; Tài khoản</th>
                      <th className="px-4 py-3">Đăng nhập &amp; Liên kết</th>
                      <th className="px-4 py-3">Thiết bị cuối</th>
                      <th className="px-4 py-3">Vai trò</th>
                      <th className="px-4 py-3">Hoạt động cuối</th>
                      <th className="px-4 py-3 text-right">Thao tác</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/80">
                    {processedUserList.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="px-4 py-8 text-center text-slate-500 italic">
                          Không tìm thấy tài khoản người dùng nào phù hợp.
                        </td>
                      </tr>
                    ) : (
                      processedUserList
                        .slice((userPage - 1) * userPageSize, userPage * userPageSize)
                        .map((u) => {
                          const userKey = (u.email || u.userId).toLowerCase();
                          const isSuperAdmin = (u.email || '').toLowerCase() === 'admin@example.com';
                          const isCurrentAdmin = u.role === 'admin' || settings.adminList.includes((u.email || '').toLowerCase());
                          const isVip = (settings.vipUsers || []).includes(userKey) || isSuperAdmin;
                          const isSelected = selectedUserIds.includes(u.userId);

                          const toggleVipUser = () => {
                            setSettings((prev) => {
                              const curVip = prev.vipUsers || [];
                              const updated = isVip
                                ? curVip.filter((k) => k !== userKey)
                                : [...curVip, userKey];
                              return { ...prev, vipUsers: updated };
                            });
                          };

                          const rawDisplayName = u.displayName && u.displayName.trim() && u.displayName !== 'Chưa cập nhật tên'
                            ? u.displayName
                            : (u.email ? u.email.split('@')[0] : 'Chưa cập nhật họ tên');

                          const lastDeviceText = u.deviceModel && u.deviceModel.trim() && u.deviceModel !== 'HONOR Device'
                            ? u.deviceModel
                            : 'Không rõ';

                          return (
                            <tr key={u.userId} className={`hover:bg-slate-800/40 transition-colors ${isSelected ? 'bg-cyan-950/20' : ''}`}>
                              {/* Chọn hàng loạt */}
                              <td className="px-3 py-3">
                                <button
                                  onClick={() => {
                                    setSelectedUserIds((prev) =>
                                      isSelected ? prev.filter((id) => id !== u.userId) : [...prev, u.userId]
                                    );
                                  }}
                                  className="text-slate-500 hover:text-cyan-400"
                                >
                                  {isSelected ? (
                                    <CheckSquare className="w-4 h-4 text-cyan-400" />
                                  ) : (
                                    <Square className="w-4 h-4" />
                                  )}
                                </button>
                              </td>

                              {/* Cột 1: Họ tên & Định danh */}
                              <td className="px-4 py-3">
                                <div className="flex items-center space-x-2.5">
                                  {u.photoURL ? (
                                    <img
                                      src={u.photoURL}
                                      alt={rawDisplayName}
                                      className="w-8 h-8 rounded-full border border-cyan-500/40 object-cover shrink-0"
                                    />
                                  ) : (
                                    <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-cyan-500 to-purple-600 flex items-center justify-center text-xs font-black text-white shrink-0 shadow">
                                      {(rawDisplayName || 'U')[0].toUpperCase()}
                                    </div>
                                  )}
                                  <div className="min-w-0">
                                    <div className="flex items-center space-x-1.5 flex-wrap">
                                      <span className="font-bold text-white text-xs truncate max-w-[160px]">
                                        {rawDisplayName}
                                      </span>
                                      {isVip && (
                                        <span className="px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[9px] font-black uppercase flex items-center space-x-0.5">
                                          <Crown className="w-2.5 h-2.5 text-amber-400" />
                                          <span>VIP</span>
                                        </span>
                                      )}
                                    </div>
                                    <div className="text-[11px] text-cyan-300 font-mono truncate max-w-[180px]">
                                      {u.email || u.phone || 'Không có email'}
                                    </div>
                                    <div className="text-[9px] text-slate-500 font-mono truncate max-w-[160px]">
                                      UID: {u.userId.substring(0, 16)}...
                                    </div>
                                  </div>
                                </div>
                              </td>

                              {/* Cột 2: Đăng nhập & Liên kết */}
                              <td className="px-4 py-3">
                                <div className="space-y-1">
                                  <div>
                                    {u.primaryProvider === 'google' || u.primaryProvider === 'google.com' ? (
                                      <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-full bg-red-500/15 text-red-300 border border-red-500/30 text-[10px] font-semibold">
                                        <span className="font-black text-red-400">G</span>
                                        <span>Google</span>
                                      </span>
                                    ) : u.primaryProvider === 'facebook' || u.primaryProvider === 'facebook.com' ? (
                                      <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-full bg-blue-500/15 text-blue-300 border border-blue-500/30 text-[10px] font-semibold">
                                        <span className="font-black text-blue-400">f</span>
                                        <span>Facebook</span>
                                      </span>
                                    ) : u.primaryProvider === 'phone' ? (
                                      <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 text-[10px] font-semibold">
                                        <Smartphone className="w-2.5 h-2.5 text-emerald-400" />
                                        <span>SMS OTP</span>
                                      </span>
                                    ) : (
                                      <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-full bg-purple-500/15 text-purple-300 border border-purple-500/30 text-[10px] font-semibold">
                                        <KeyRound className="w-2.5 h-2.5 text-purple-400" />
                                        <span>Email/Pass</span>
                                      </span>
                                    )}
                                  </div>
                                </div>
                              </td>

                              {/* Cột 3: Thiết bị cuối */}
                              <td className="px-4 py-3">
                                {lastDeviceText !== 'Không rõ' ? (
                                  <div className="flex items-center space-x-1.5 text-cyan-300 font-mono text-[11px] font-bold">
                                    <Smartphone className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                                    <span className="truncate max-w-[140px]">{lastDeviceText}</span>
                                  </div>
                                ) : (
                                  <span className="text-slate-500 font-mono text-xs italic">
                                    Không rõ
                                  </span>
                                )}
                              </td>

                              {/* Cột 4: Vai trò */}
                              <td className="px-4 py-3">
                                <span
                                  className={`inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                                    isSuperAdmin
                                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                                      : isCurrentAdmin
                                      ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30'
                                      : isVip
                                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                                      : 'bg-purple-500/20 text-purple-300 border-purple-500/30'
                                  }`}
                                >
                                  {isSuperAdmin && <ShieldCheck className="w-3 h-3 text-amber-400" />}
                                  {isCurrentAdmin && !isSuperAdmin && <ShieldCheck className="w-3 h-3 text-cyan-400" />}
                                  {isVip && !isCurrentAdmin && <Crown className="w-3 h-3 text-emerald-400" />}
                                  <span>
                                    {isSuperAdmin
                                      ? 'Super Admin'
                                      : isCurrentAdmin
                                      ? 'Quản Trị Viên'
                                      : isVip
                                      ? 'Thành Viên VIP'
                                      : 'Thành Viên'}
                                  </span>
                                </span>
                              </td>

                              {/* Cột 5: Hoạt động cuối */}
                              <td className="px-4 py-3 text-[11px] text-slate-400">
                                <div className="text-[11px] text-white font-semibold truncate max-w-[180px]" title={u.lastAction}>
                                  {u.lastAction}
                                </div>
                                <div className="text-[10px] text-cyan-300 font-mono flex items-center space-x-1.5 mt-0.5">
                                  <span>{u.lastActive}</span>
                                  {u.lastActiveTimestamp > 0 && (
                                    <span className="text-[9px] text-slate-400">({getRelativeTimeString(u.lastActiveTimestamp)})</span>
                                  )}
                                </div>
                              </td>

                              {/* Cột 6: Thao tác */}
                              <td className="px-4 py-3 text-right space-x-1.5 whitespace-nowrap">
                                <button
                                  onClick={() => setSelectedUserDetail(u)}
                                  className="px-2.5 py-1 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 text-xs font-bold transition-all inline-flex items-center space-x-1"
                                >
                                  <Eye className="w-3.5 h-3.5" />
                                  <span>Chi Tiết</span>
                                </button>

                                {!isSuperAdmin && (
                                  <button
                                    onClick={toggleVipUser}
                                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all inline-flex items-center space-x-1 ${
                                      isVip
                                        ? 'bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40'
                                        : 'bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40'
                                    }`}
                                  >
                                    <Crown className="w-3 h-3" />
                                    <span>{isVip ? 'Thu Hồi VIP' : 'Cấp VIP'}</span>
                                  </button>
                                )}

                                {u.email && !isSuperAdmin && (
                                  <button
                                    onClick={() => {
                                      if (isCurrentAdmin) {
                                        handleRemoveAdmin(u.email!);
                                      } else {
                                        setSettings((prev) => ({
                                          ...prev,
                                          adminList: [...prev.adminList, u.email!.trim().toLowerCase()]
                                        }));
                                      }
                                    }}
                                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                                      isCurrentAdmin
                                        ? 'bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40'
                                        : 'bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border border-purple-500/40'
                                    }`}
                                  >
                                    {isCurrentAdmin ? 'Hạ Admin' : 'Thăng Admin'}
                                  </button>
                                )}
                              </td>
                            </tr>
                          );
                        })
                    )}
                  </tbody>
                </table>

                {/* Phân trang */}
                <div className="p-2 bg-[#0A0F1D]">
                  <Pagination
                    currentPage={userPage}
                    totalItems={processedUserList.length}
                    pageSize={userPageSize}
                    onPageChange={(page) => setUserPage(page)}
                  />
                </div>
              </div>
            )}
            {/* Hộp thêm Quản Trị Viên mới */}
            <div className="p-4 rounded-xl bg-[#0A0F1D] border border-cyan-500/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h4 className="text-xs font-bold text-white flex items-center space-x-1.5">
                  <UserPlus className="w-4 h-4 text-emerald-400" />
                  <span>Gán Thêm Quản Trị Viên (Admin) Qua Email</span>
                </h4>
                <p className="text-[11px] text-slate-400">
                  Tài khoản được gán quyền sẽ thấy nút Quản Trị trên thanh Menu và chỉnh sửa được toàn bộ cấu hình sàn
                </p>
              </div>

              <div className="flex items-center space-x-2">
                <input
                  type="email"
                  value={newAdminEmail}
                  onChange={(e) => setNewAdminEmail(e.target.value)}
                  placeholder="admin.moi@gmail.com"
                  className="bg-[#111A2E] border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-400 w-52 sm:w-60"
                />
                <button
                  onClick={handleAddAdmin}
                  className="px-3 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-xs transition-all shrink-0"
                >
                  Thêm Admin
                </button>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={handleSaveSettings}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 text-black font-extrabold text-xs flex items-center space-x-2 shadow-lg shadow-emerald-500/20 hover:scale-[1.01] active:scale-[0.99] transition-all"
              >
                <Save className="w-4 h-4 text-black" />
                <span>Lưu Thay Đổi Cấp Quyền VIP &amp; Phân Quyền Người Dùng Lên Firestore</span>
              </button>
            </div>
          </div>
        )}

        {/* TAB 3: SEO, GOOGLE ADSENSE & ADS.TXT */}
        {adminTab === 'seo_adsense' && (
          <div className="p-6 rounded-2xl bg-[#111A2E]/90 border border-cyan-500/20 shadow-xl space-y-6">
            <div className="flex items-center space-x-2 text-[#00F0FF] text-sm font-bold pb-2 border-b border-slate-800">
              <Megaphone className="w-5 h-5 text-amber-400" />
              <span>Quản Lý SEO Toàn Sàn, Google AdSense &amp; Tệp Xác Minh (Ads.txt)</span>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Thẻ Meta SEO */}
              <div className="space-y-4">
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center space-x-1.5">
                  <Globe className="w-4 h-4 text-[#00F0FF]" />
                  <span>Cấu Hình Link Tải App MagicTune APK &amp; SEO Toàn Trang</span>
                </h4>

                {renderApkLinksConfigCard()}

                <div>
                  <label className="block text-xs text-slate-400 mb-1">Tiêu đề SEO (Meta Title):</label>
                  <input
                    type="text"
                    value={settings.seo?.metaTitle || ''}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        seo: { ...settings.seo, metaTitle: e.target.value }
                      })
                    }
                    className="w-full bg-[#0A0F1D] border border-cyan-500/20 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div>
                  <label className="block text-xs text-slate-400 mb-1">Mô tả SEO (Meta Description):</label>
                  <textarea
                    rows={3}
                    value={settings.seo?.metaDescription || ''}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        seo: { ...settings.seo, metaDescription: e.target.value }
                      })
                    }
                    className="w-full bg-[#0A0F1D] border border-cyan-500/20 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div>
                  <label className="block text-xs text-slate-400 mb-1">Từ khóa SEO (Keywords):</label>
                  <input
                    type="text"
                    value={settings.seo?.metaKeywords || ''}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        seo: { ...settings.seo, metaKeywords: e.target.value }
                      })
                    }
                    className="w-full bg-[#0A0F1D] border border-cyan-500/20 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Google Site Verification:</label>
                    <input
                      type="text"
                      value={settings.seo?.googleSiteVerification || ''}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          seo: { ...settings.seo, googleSiteVerification: e.target.value }
                        })
                      }
                      className="w-full bg-[#0A0F1D] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Bing Site Verification:</label>
                    <input
                      type="text"
                      value={settings.seo?.bingSiteVerification || ''}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          seo: { ...settings.seo, bingSiteVerification: e.target.value }
                        })
                      }
                      className="w-full bg-[#0A0F1D] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Google AdSense & Ads.txt */}
              <div className="space-y-4">
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center space-x-1.5">
                  <FileText className="w-4 h-4 text-amber-400" />
                  <span>Google AdSense &amp; Tệp Xác Minh Ads.txt</span>
                </h4>

                <div>
                  <label className="block text-xs text-slate-400 mb-1">Mã Nhà Xuất Bản AdSense (ca-pub-xxx):</label>
                  <input
                    type="text"
                    value={settings.seo?.googleAdsenseClient || ''}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        seo: { ...settings.seo, googleAdsenseClient: e.target.value }
                      })
                    }
                    placeholder="ca-pub-4256214784202059"
                    className="w-full bg-[#0A0F1D] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Mã Đơn Vị Quảng Cáo Cột Trái (Sidebar Slot ID):</label>
                    <input
                      type="text"
                      value={settings.seo?.adSlotSidebar || ''}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          seo: { ...settings.seo, adSlotSidebar: e.target.value }
                        })
                      }
                      placeholder="Để trống khi dùng Auto Ads (hoặc nhập Slot ID thật)"
                      className="w-full bg-[#0A0F1D] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Mã Đơn Vị Quảng Cáo Dưới (Bottom Slot ID):</label>
                    <input
                      type="text"
                      value={settings.seo?.adSlotBottom || ''}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          seo: { ...settings.seo, adSlotBottom: e.target.value }
                        })
                      }
                      placeholder="Để trống khi dùng Auto Ads (hoặc nhập Slot ID thật)"
                      className="w-full bg-[#0A0F1D] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs text-slate-400">Nội dung tệp /ads.txt:</label>
                    <a
                      href="/ads.txt"
                      target="_blank"
                      className="text-[11px] text-[#00F0FF] hover:underline"
                    >
                      Xem trang /ads.txt trực tiếp
                    </a>
                  </div>
                  <textarea
                    rows={4}
                    value={settings.seo?.adsTxtContent || ''}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        seo: { ...settings.seo, adsTxtContent: e.target.value }
                      })
                    }
                    className="w-full bg-[#0A0F1D] border border-cyan-500/20 rounded-xl p-3 text-xs text-cyan-300 font-mono focus:outline-none focus:border-cyan-400"
                  />
                  <p className="text-[11px] text-slate-500 mt-1">
                    Cấu hình này tự động xuất bản tại đường dẫn gốc <code>/ads.txt</code> để Google thu thập dữ liệu xác thực quyền sở hữu website.
                  </p>
                </div>

                <div>
                  <label className="block text-xs text-slate-400 mb-1">Thẻ Header Tùy Chỉnh (Custom Head Tags / Scripts):</label>
                  <textarea
                    rows={3}
                    value={settings.seo?.customHeadTags || ''}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        seo: { ...settings.seo, customHeadTags: e.target.value }
                      })
                    }
                    placeholder="<!-- Dán mã script Google Analytics / Tag Manager -->"
                    className="w-full bg-[#0A0F1D] border border-slate-700 rounded-xl p-3 text-xs text-purple-300 font-mono"
                  />
                </div>
              </div>
            </div>

            <button
              onClick={handleSaveSettings}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#00F0FF] to-blue-600 hover:from-cyan-400 text-black font-extrabold text-xs flex items-center space-x-2"
            >
              <Save className="w-4 h-4 text-black" />
              <span>Lưu Cài Đặt SEO &amp; AdSense Lên Firestore</span>
            </button>
          </div>
        )}

        {/* TAB 3: THÔNG BÁO ĐẨY (FCM PUSH) & QR AUTH */}
        {adminTab === 'fcm_push' && (
          <div className="p-6 rounded-2xl bg-[#111A2E]/90 border border-purple-500/20 shadow-xl space-y-6">
            <div className="flex items-center space-x-2 text-purple-300 text-sm font-bold pb-2 border-b border-slate-800">
              <Bell className="w-5 h-5" />
              <span>Cấu Hình Thông Báo Đẩy (FCM Push) &amp; Đăng Nhập QR Code</span>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Push Notification FCM Settings */}
              <div className="space-y-4">
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center space-x-1.5">
                  <Bell className="w-4 h-4 text-purple-400" />
                  <span>Cấu Hình Khóa Đẩy Web Push (VAPID Key)</span>
                </h4>

                <div>
                  <label className="block text-xs text-slate-400 mb-1">VAPID Key (Web Push Certificate):</label>
                  <textarea
                    rows={3}
                    value={settings.fcm?.vapidKey || ''}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        fcm: { ...settings.fcm, vapidKey: e.target.value }
                      })
                    }
                    className="w-full bg-[#0A0F1D] border border-purple-500/30 rounded-xl p-3 text-xs text-purple-300 font-mono focus:outline-none focus:border-cyan-400"
                  />
                  <div className="text-[11px] text-slate-500 mt-1">
                    Đã cấu hình mã VAPID chính thức: <code>{FCM_VAPID_KEY ? FCM_VAPID_KEY.slice(0, 12) + "..." : "Chưa cấu hình"}</code>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-3">
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Tiêu đề thông báo mẫu:</label>
                    <input
                      type="text"
                      value={settings.fcm?.welcomePushTitle || ''}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          fcm: { ...settings.fcm, welcomePushTitle: e.target.value }
                        })
                      }
                      className="w-full bg-[#0A0F1D] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Nội dung thông báo mẫu:</label>
                    <input
                      type="text"
                      value={settings.fcm?.welcomePushBody || ''}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          fcm: { ...settings.fcm, welcomePushBody: e.target.value }
                        })
                      }
                      className="w-full bg-[#0A0F1D] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                    />
                  </div>
                </div>

                <div className="pt-2 flex items-center space-x-3">
                  <button
                    onClick={handleTestPushNotification}
                    className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center space-x-1.5 shadow-md shadow-purple-900/30"
                  >
                    <Bell className="w-4 h-4" />
                    <span>Thử Gửi Thông Báo Đẩy Lên Trình Duyệt</span>
                  </button>

                  {pushSentSuccess && (
                    <span className="text-xs text-emerald-400 font-semibold flex items-center space-x-1">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Đã kích hoạt Push thành công!</span>
                    </span>
                  )}
                </div>
              </div>

              {/* QR Auth Mechanism */}
              <div className="space-y-4">
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center space-x-1.5">
                  <QrCode className="w-4 h-4 text-[#00F0FF]" />
                  <span>Cơ Chế Đăng Nhập Nhanh Qua QR (QR Auth)</span>
                </h4>

                <div className="p-4 rounded-xl bg-[#0A0F1D] border border-cyan-500/20 text-xs text-slate-300 space-y-2.5">
                  <div className="font-bold text-[#00F0FF]">Cách Thức Hoạt Động Của QR Auth:</div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    1. Người dùng trên máy tính (PC) mở bảng đăng nhập, chọn tab <strong>&quot;Quét QR&quot;</strong>.
                  </p>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    2. Hệ thống tự động khởi tạo phiên bảo mật tạm thời (kèm mã hash thời gian thực) lưu tại Firestore collection <code>qr_sessions</code>.
                  </p>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    3. Người dùng dùng điện thoại đã đăng nhập tài khoản quét mã QR để mở trang xác thực <code className="text-cyan-300">/auth/qr-confirm</code>.
                  </p>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    4. Khi bấm <strong>&quot;Cho phép đăng nhập trên PC&quot;</strong>, máy tính sẽ lập tức nhận tín hiệu qua Firestore Snapshot Listener và tự động đăng nhập không cần gõ mật khẩu!
                  </p>
                </div>

                <div className="p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-[11px] text-cyan-300">
                  ✅ Trạng thái module QR Auth: <strong>Hoạt Động 100%</strong> kết nối trực tiếp với Firestore Realtime Listener.
                </div>
              </div>
            </div>

            <button
              onClick={handleSaveSettings}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 text-white font-extrabold text-xs flex items-center space-x-2"
            >
              <Save className="w-4 h-4 text-white" />
              <span>Lưu Cấu Hình FCM Push Lên Firestore</span>
            </button>
          </div>
        )}

        {/* TAB 5: CÀI ĐẶT THƯƠNG HIỆU & CHÂN TRANG */}
        {adminTab === 'settings' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              <div className="p-6 rounded-2xl bg-[#111A2E]/90 border border-cyan-500/20 shadow-xl space-y-4">
                <div className="flex items-center space-x-2 text-[#00F0FF] text-sm font-bold pb-2 border-b border-slate-800">
                  <Globe className="w-4 h-4" />
                  <span>Cấu Hình Tên Ứng Dụng, Slogan &amp; Tên Miền</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Tên Ứng Dụng:</label>
                    <input
                      type="text"
                      value={settings.appName || ''}
                      onChange={(e) => setSettings({ ...settings, appName: e.target.value })}
                      className="w-full bg-[#0A0F1D] border border-cyan-500/20 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Tên Miền (Domain):</label>
                    <input
                      type="text"
                      value={settings.appDomain || ''}
                      onChange={(e) => setSettings({ ...settings, appDomain: e.target.value })}
                      className="w-full bg-[#0A0F1D] border border-cyan-500/20 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs text-slate-400 mb-1">Slogan Ứng Dụng:</label>
                  <input
                    type="text"
                    value={settings.appSlogan || ''}
                    onChange={(e) => setSettings({ ...settings, appSlogan: e.target.value })}
                    className="w-full bg-[#0A0F1D] border border-cyan-500/20 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                  />
                </div>

                {renderApkLinksConfigCard()}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Phạm vi Android hỗ trợ:</label>
                    <input
                      type="text"
                      value={settings.androidSupport?.supportedAndroidRange || ''}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          androidSupport: {
                            ...settings.androidSupport,
                            supportedAndroidRange: e.target.value,
                            supportedMagicOsRange: settings.androidSupport?.supportedMagicOsRange || 'MagicOS',
                            supportedOsListText: settings.androidSupport?.supportedOsListText || ''
                          }
                        })
                      }
                      className="w-full bg-[#0A0F1D] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Mô tả danh sách OS hỗ trợ:</label>
                    <input
                      type="text"
                      value={settings.androidSupport?.supportedOsListText || ''}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          androidSupport: {
                            ...settings.androidSupport,
                            supportedAndroidRange: settings.androidSupport?.supportedAndroidRange || 'Android',
                            supportedMagicOsRange: settings.androidSupport?.supportedMagicOsRange || 'MagicOS',
                            supportedOsListText: e.target.value
                          }
                        })
                      }
                      className="w-full bg-[#0A0F1D] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                    />
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    onClick={handleSaveSettings}
                    className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#00F0FF] to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-bold text-xs shadow-lg shadow-cyan-500/25 flex items-center space-x-2 transition-all"
                  >
                    <Save className="w-4 h-4" />
                    <span>Lưu Cấu Hình Hệ Thống</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Cột phải Tab 5: Cấu Hình Chân Trang & Hỗ Trợ */}
            <div className="lg:col-span-1 space-y-6">
              <div className="p-6 rounded-2xl bg-[#111A2E]/90 border border-cyan-500/20 shadow-xl space-y-4">
                <div className="flex items-center space-x-2 text-purple-300 text-sm font-bold pb-2 border-b border-slate-800">
                  <Layout className="w-4 h-4 text-purple-400" />
                  <span>Chân Trang (Footer) &amp; Hỗ Trợ</span>
                </div>

                <label className="flex items-center justify-between p-3 rounded-xl bg-[#0A0F1D] border border-slate-800 cursor-pointer">
                  <span className="text-xs font-semibold text-slate-200">Hiển thị Chân trang (Footer)</span>
                  <input
                    type="checkbox"
                    checked={settings.footer?.showFooter !== false}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        footer: { ...settings.footer, showFooter: e.target.checked }
                      })
                    }
                    className="accent-cyan-400 w-4 h-4"
                  />
                </label>

                <label className="flex items-center justify-between p-3 rounded-xl bg-[#0A0F1D] border border-slate-800 cursor-pointer">
                  <span className="text-xs font-semibold text-slate-200">Hiển thị Miễn trừ trách nhiệm</span>
                  <input
                    type="checkbox"
                    checked={settings.footer?.showDisclaimer !== false}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        footer: { ...settings.footer, showDisclaimer: e.target.checked }
                      })
                    }
                    className="accent-cyan-400 w-4 h-4"
                  />
                </label>

                <label className="flex items-center justify-between p-3 rounded-xl bg-[#0A0F1D] border border-slate-800 cursor-pointer">
                  <span className="text-xs font-semibold text-slate-200">Hiện Tab Hỗ Trợ Admin trên Chat AI</span>
                  <input
                    type="checkbox"
                    checked={settings.showSupportAdminTab !== false}
                    onChange={(e) =>
                      setSettings({ ...settings, showSupportAdminTab: e.target.checked })
                    }
                    className="accent-purple-400 w-4 h-4"
                  />
                </label>

                <div>
                  <label className="block text-xs text-slate-400 mb-1">Dòng bản quyền (Copyright):</label>
                  <input
                    type="text"
                    value={settings.footer?.customCopyrightText || ''}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        footer: { ...settings.footer, customCopyrightText: e.target.value }
                      })
                    }
                    className="w-full bg-[#0A0F1D] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs text-slate-400 mb-1">Thông tin liên hệ ở Footer:</label>
                  <input
                    type="text"
                    value={settings.footer?.contactInfo || ''}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        footer: { ...settings.footer, contactInfo: e.target.value }
                      })
                    }
                    className="w-full bg-[#0A0F1D] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs text-slate-400 mb-1">Nội dung Tuyên bố miễn trừ:</label>
                  <textarea
                    rows={3}
                    value={settings.footer?.customDisclaimerText || ''}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        footer: { ...settings.footer, customDisclaimerText: e.target.value }
                      })
                    }
                    className="w-full bg-[#0A0F1D] border border-slate-700 rounded-xl p-2.5 text-xs text-slate-300"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: THU PHÍ, TÀI KHOẢN NHẬN CHUYỂN KHOẢN & KHÓA TÍNH NĂNG */}
        {adminTab === 'billing' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Cấu hình thu phí & Tài khoản nhận tiền */}
              <div className="p-6 rounded-2xl bg-[#111A2E]/90 border border-amber-500/25 shadow-xl space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <div className="flex items-center space-x-2 text-amber-300 text-sm font-bold">
                    <CreditCard className="w-5 h-5 text-amber-400" />
                    <span>Cấu Hình Thu Phí &amp; Gói VIP</span>
                  </div>
                  <label className="flex items-center space-x-2 cursor-pointer px-3 py-1.5 rounded-xl bg-[#0A0F1D] border border-amber-500/30">
                    <span className="text-xs font-bold text-white">Bật Thu Phí</span>
                    <input
                      type="checkbox"
                      checked={settings.monetization?.enabled === true}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          monetization: { ...settings.monetization, enabled: e.target.checked }
                        })
                      }
                      className="accent-amber-400 w-4 h-4"
                    />
                  </label>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Giá Gói VIP Trọn Đời (VNĐ):</label>
                    <input
                      type="number"
                      min={0}
                      step={1000}
                      value={settings.monetization?.vipMembershipVnd ?? 199000}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          monetization: {
                            ...settings.monetization,
                            vipMembershipVnd: parseInt(e.target.value, 10) || 0
                          }
                        })
                      }
                      className="w-full bg-[#0A0F1D] border border-amber-500/30 rounded-xl px-3 py-2 text-xs text-amber-300 font-mono font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Giá Mở Khóa Lẻ Mặc Định (VNĐ):</label>
                    <input
                      type="number"
                      min={0}
                      step={1000}
                      value={settings.monetization?.pricePerFixVnd ?? 50000}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          monetization: {
                            ...settings.monetization,
                            pricePerFixVnd: parseInt(e.target.value, 10) || 0
                          }
                        })
                      }
                      className="w-full bg-[#0A0F1D] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono"
                    />
                  </div>
                </div>

                <div className="pt-2 space-y-3 border-t border-slate-800">
                  <div className="text-xs font-bold text-cyan-300">Thông Tin Tài Khoản Nhận Thanh Toán</div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Tên Đơn Vị / Tổ Chức Phát Hành:</label>
                    <input
                      type="text"
                      placeholder="Nhập tên tổ chức phát hành tài khoản..."
                      value={settings.monetization?.bankInfo?.bankName || ''}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          monetization: {
                            ...settings.monetization,
                            bankInfo: { ...settings.monetization?.bankInfo, bankName: e.target.value }
                          }
                        })
                      }
                      className="w-full bg-[#0A0F1D] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                    />
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs text-slate-400 mb-1">Số Tài Khoản:</label>
                      <input
                        type="text"
                        placeholder="Nhập số tài khoản..."
                        value={settings.monetization?.bankInfo?.accountNumber || ''}
                        onChange={(e) =>
                          setSettings({
                            ...settings,
                            monetization: {
                              ...settings.monetization,
                              bankInfo: { ...settings.monetization?.bankInfo, accountNumber: e.target.value }
                            }
                          })
                        }
                        className="w-full bg-[#0A0F1D] border border-slate-700 rounded-xl px-3 py-2 text-xs text-cyan-300 font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-400 mb-1">Chủ Tài Khoản:</label>
                      <input
                        type="text"
                        placeholder="CHU TAI KHOAN"
                        value={settings.monetization?.bankInfo?.accountHolder || ''}
                        onChange={(e) =>
                          setSettings({
                            ...settings,
                            monetization: {
                              ...settings.monetization,
                              bankInfo: { ...settings.monetization?.bankInfo, accountHolder: e.target.value }
                            }
                          })
                        }
                        className="w-full bg-[#0A0F1D] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white uppercase"
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-2 flex flex-wrap gap-2">
                  <button
                    onClick={handleSaveSettings}
                    className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 hover:from-amber-300 text-black font-black text-xs flex items-center space-x-2 shadow-lg shadow-amber-500/20"
                  >
                    <Save className="w-4 h-4 text-black" />
                    <span>Lưu Cấu Hình Thu Phí</span>
                  </button>
                </div>
              </div>

              {/* Khóa tính năng & Bảng giá từng module */}
              <div className="p-6 rounded-2xl bg-[#111A2E]/90 border border-cyan-500/20 shadow-xl space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
                  <div className="flex items-center space-x-2 text-[#00F0FF] text-sm font-bold">
                    <Lock className="w-4 h-4" />
                    <span>Khóa &amp; Định Giá Từng Module</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="number"
                      min={0}
                      step={5000}
                      value={bulkPriceInput}
                      onChange={(e) => setBulkPriceInput(parseInt(e.target.value, 10) || 0)}
                      className="w-24 bg-[#0A0F1D] border border-slate-700 rounded-lg px-2 py-1 text-xs text-amber-300 font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        const updatedPrices = { ...settings.featurePrices };
                        ADMIN_BILLING_FEATURES.forEach((f) => {
                          updatedPrices[f.priceKey] = bulkPriceInput;
                        });
                        setSettings({ ...settings, featurePrices: updatedPrices });
                        setBulkNote(`Đã áp dụng đồng giá ${bulkPriceInput.toLocaleString('vi-VN')}đ cho toàn bộ module (nhớ bấm Lưu).`);
                        setTimeout(() => setBulkNote(null), 5000);
                      }}
                      className="px-2.5 py-1 rounded-lg bg-cyan-500/15 hover:bg-cyan-500/25 text-cyan-300 border border-cyan-500/30 text-[11px] font-bold"
                    >
                      Áp Dụng Hàng Loạt
                    </button>
                  </div>
                </div>

                {bulkNote && (
                  <div className="p-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs">
                    {bulkNote}
                  </div>
                )}

                <div className="max-h-[380px] overflow-y-auto space-y-2 pr-1">
                  {ADMIN_BILLING_FEATURES.map((feat) => {
                    const isLocked = Boolean(settings.features?.[feat.lockKey]);
                    const priceVal = settings.featurePrices?.[feat.priceKey] ?? 0;
                    return (
                      <div
                        key={feat.priceKey}
                        className="flex items-center justify-between gap-2 p-2.5 rounded-xl bg-[#0A0F1D] border border-slate-800 text-xs"
                      >
                        <label className="flex items-center space-x-2 min-w-0 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={isLocked}
                            onChange={(e) =>
                              setSettings({
                                ...settings,
                                features: { ...settings.features, [feat.lockKey]: e.target.checked }
                              })
                            }
                            className="accent-amber-400 w-4 h-4 shrink-0"
                          />
                          <span className="truncate font-semibold text-slate-200">{feat.label}</span>
                        </label>
                        <div className="flex items-center space-x-1.5 shrink-0">
                          <input
                            type="number"
                            min={0}
                            step={1000}
                            value={priceVal}
                            onChange={(e) =>
                              setSettings({
                                ...settings,
                                featurePrices: {
                                  ...settings.featurePrices,
                                  [feat.priceKey]: parseInt(e.target.value, 10) || 0
                                }
                              })
                            }
                            className="w-24 bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-right text-xs text-amber-300 font-mono"
                          />
                          <span className="text-[10px] text-slate-500">đ</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Danh sách giao dịch chuyển khoản đang chờ kiểm tra */}
            <div className="p-6 rounded-2xl bg-[#111A2E]/90 border border-amber-500/25 shadow-xl space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center space-x-2 text-amber-300 text-sm font-bold">
                  <Crown className="w-4 h-4 text-amber-400" />
                  <span>Đối Soát Giao Dịch Chuyển Khoản ({pendingReviewCount} chờ duyệt)</span>
                </div>
                <button
                  onClick={reloadAllDataFromFirestore}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center space-x-1.5"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Làm Mới</span>
                </button>
              </div>

              {pendingPayments.length === 0 ? (
                <div className="p-6 text-center text-xs text-slate-500 italic bg-[#0A0F1D] rounded-xl border border-slate-800">
                  Hiện chưa có giao dịch nào được gửi lên hệ thống.
                </div>
              ) : (
                <div className="space-y-2">
                  {pendingPayments
                    .slice((pendingPaymentPage - 1) * pendingPaymentPageSize, pendingPaymentPage * pendingPaymentPageSize)
                    .map((pay) => {
                      const targetKey = (pay.userEmail && pay.userEmail !== 'N/A') ? pay.userEmail.toLowerCase() : pay.userId?.toLowerCase();
                      const isApproved = pay.status === 'approved';
                      return (
                        <div key={pay.id} className="p-3 rounded-xl bg-[#0A0F1D] border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                          <div className="space-y-0.5">
                            <div className="font-bold text-white">{pay.userEmail && pay.userEmail !== 'N/A' ? pay.userEmail : pay.userId}</div>
                            <div className="text-[11px] text-slate-400 font-mono">
                              {(pay.amount || 199000).toLocaleString('vi-VN')} đ • {pay.transferContent || 'VIP'} • {pay.timestamp || 'Mới đây'}
                            </div>
                          </div>
                          {isApproved ? (
                            <span className="text-emerald-400 font-bold text-xs flex items-center space-x-1">
                              <CheckCircle2 className="w-4 h-4" />
                              <span>Đã Duyệt VIP</span>
                            </span>
                          ) : (
                            <button
                              onClick={async () => {
                                if (targetKey && !(settings.vipUsers || []).includes(targetKey)) {
                                  const newSettings = { ...settings, vipUsers: [...(settings.vipUsers || []), targetKey] };
                                  setSettings(newSettings);
                                  await saveLiveSettingsToFirestore(newSettings);
                                }
                                try {
                                  await updateDoc(doc(db, 'payment_transactions', pay.id), {
                                    status: 'approved',
                                    approvedAt: Date.now()
                                  });
                                } catch (e) {}
                                setPendingPayments((prev) => prev.map((p) => (p.id === pay.id ? { ...p, status: 'approved' } : p)));
                              }}
                              className="px-3 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-bold text-xs"
                            >
                              Duyệt &amp; Cấp VIP
                            </button>
                          )}
                        </div>
                      );
                    })}
                  <Pagination
                    currentPage={pendingPaymentPage}
                    totalItems={pendingPayments.length}
                    pageSize={pendingPaymentPageSize}
                    onPageChange={(page) => setPendingPaymentPage(page)}
                  />
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 7: SCRIPT ADB CONSOLE & MẪU LỆNH KỸ THUẬT */}
        {adminTab === 'adb_remote' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-1 p-6 rounded-2xl bg-[#111A2E]/90 border border-purple-500/20 shadow-xl space-y-4">
              <div className="flex items-center space-x-2 text-purple-300 text-sm font-bold pb-2 border-b border-slate-800">
                <Code className="w-4 h-4 text-purple-400" />
                <span>Bộ Script ADB Chuẩn AOSP</span>
              </div>
              <div className="space-y-2.5">
                {ADB_PRESET_SCRIPTS.map((preset) => (
                  <button
                    key={preset.name}
                    type="button"
                    onClick={() => {
                      setCustomScript(preset.script);
                      setScriptOutput(`Đã nạp mẫu "${preset.name}". Nhấn "Kiểm Tra Cú Pháp" hoặc sao chép để chạy trên ADB Cockpit.`);
                    }}
                    className="w-full text-left p-3 rounded-xl bg-[#0A0F1D] hover:bg-slate-800/80 border border-purple-500/20 hover:border-purple-400/50 transition-all space-y-1"
                  >
                    <div className="text-xs font-bold text-purple-300">{preset.name}</div>
                    <div className="text-[11px] text-slate-400 leading-snug">{preset.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            <div className="lg:col-span-2 p-6 rounded-2xl bg-[#111A2E]/90 border border-cyan-500/20 shadow-xl space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <div className="flex items-center space-x-2 text-[#00F0FF] text-sm font-bold">
                  <Terminal className="w-4 h-4" />
                  <span>Trình Soạn Thảo &amp; Kiểm Tra Lệnh ADB Shell</span>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
                  Dry-Run Validator
                </span>
              </div>

              <textarea
                rows={8}
                value={customScript}
                onChange={(e) => setCustomScript(e.target.value)}
                placeholder="Nhập mỗi dòng 1 lệnh adb shell (ví dụ: dumpsys deviceidle whitelist)..."
                className="w-full bg-[#0A0F1D] border border-cyan-500/25 rounded-xl p-3.5 text-xs text-cyan-200 font-mono focus:outline-none focus:border-cyan-400"
              />

              <div className="flex flex-wrap items-center gap-2.5">
                <button
                  type="button"
                  onClick={() => {
                    const lines = customScript
                      .split('\n')
                      .map((l) => l.trim())
                      .filter(Boolean);
                    if (lines.length === 0) {
                      setScriptOutput('⚠️ Vui lòng nhập ít nhất 1 lệnh ADB shell trước khi kiểm tra.');
                      return;
                    }
                    const blocked = lines.filter((l) => /\b(rm\s+-rf|format|wipe|flash\s+userdata)\b/i.test(l));
                    if (blocked.length > 0) {
                      setScriptOutput(`❌ Phát hiện lệnh nguy hiểm bị chặn:\n${blocked.join('\n')}`);
                      return;
                    }
                    setScriptOutput(
                      `✅ Cú pháp hợp lệ (${lines.length} lệnh sẵn sàng chạy qua WebUSB):\n` +
                        lines.map((l, i) => `${i + 1}. adb shell ${l.replace(/^adb\s+shell\s+/i, '')}`).join('\n')
                    );
                  }}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-indigo-600 hover:from-purple-500 text-white font-bold text-xs flex items-center space-x-1.5"
                >
                  <Play className="w-3.5 h-3.5" />
                  <span>Kiểm Tra Cú Pháp</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    if (!customScript.trim()) return;
                    navigator.clipboard.writeText(customScript);
                    setScriptOutput('✅ Đã sao chép toàn bộ script ADB vào bộ nhớ tạm!');
                  }}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs"
                >
                  Sao Chép Script
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setCustomScript('');
                    setScriptOutput('');
                  }}
                  className="px-3.5 py-2 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/30 font-bold text-xs"
                >
                  Xóa Trắng
                </button>
              </div>

              {scriptOutput && (
                <pre className="p-3.5 rounded-xl bg-[#070B16] border border-slate-800 text-xs font-mono text-emerald-300 whitespace-pre-wrap max-h-56 overflow-y-auto">
                  {scriptOutput}
                </pre>
              )}
            </div>
          </div>
        )}

        {/* TAB 8: KHO APK & QUẢN LÝ LINK TẢI MAGICTUNE APK */}
        {adminTab === 'custom_apk' && (
          <div className="space-y-6">
            {/* Cấu hình 2 nguồn tải MagicTune APK (Google Drive & GitHub) */}
            <div className="p-6 rounded-2xl bg-[#111A2E]/90 border border-emerald-500/25 shadow-xl space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
                <div className="flex items-center space-x-2 text-emerald-300 text-sm font-bold">
                  <Smartphone className="w-5 h-5 text-emerald-400" />
                  <span>Cấu Hình Link Tải MagicTune Tool APK (Google Drive &amp; GitHub)</span>
                </div>
                <button
                  onClick={handleSaveSettings}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 text-slate-950 font-black text-xs flex items-center space-x-1.5 shadow-md"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Lưu Link Tải Ngay</span>
                </button>
              </div>
              {renderApkLinksConfigCard()}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Form thêm APK mới vào Mục 9 */}
              <div className="lg:col-span-1 p-6 rounded-2xl bg-[#111A2E]/90 border border-cyan-500/20 shadow-xl space-y-4">
                <div className="flex items-center space-x-2 text-[#00F0FF] text-sm font-bold pb-2 border-b border-slate-800">
                  <Plus className="w-4 h-4" />
                  <span>Thêm Ứng Dụng Vào Kho Mục 9</span>
                </div>

                <div>
                  <label className="block text-xs text-slate-400 mb-1">Tên Ứng Dụng APK:</label>
                  <input
                    type="text"
                    placeholder="Ví dụ: Shizuku v13.5.4"
                    value={newApkName}
                    onChange={(e) => setNewApkName(e.target.value)}
                    className="w-full bg-[#0A0F1D] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Phiên Bản:</label>
                    <input
                      type="text"
                      value={newApkVersion}
                      onChange={(e) => setNewApkVersion(e.target.value)}
                      className="w-full bg-[#0A0F1D] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Dung Lượng:</label>
                    <input
                      type="text"
                      value={newApkSize}
                      onChange={(e) => setNewApkSize(e.target.value)}
                      className="w-full bg-[#0A0F1D] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs text-slate-400 mb-1">Phân Loại:</label>
                  <select
                    value={newApkCategory}
                    onChange={(e) => setNewApkCategory(e.target.value as any)}
                    className="w-full bg-[#0A0F1D] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                  >
                    <option value="Utility">Utility (Tiện ích)</option>
                    <option value="Shizuku">Shizuku</option>
                    <option value="MicroG">MicroG</option>
                    <option value="Google Services">Google Services</option>
                    <option value="Keyboard">Keyboard (Bàn phím)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs text-slate-400 mb-1">Đường Link Tải Tệp APK / GitHub / Drive:</label>
                  <input
                    type="url"
                    placeholder="https://github.com/... hoặc https://drive.google.com/..."
                    value={newApkUrl}
                    onChange={(e) => setNewApkUrl(e.target.value)}
                    className="w-full bg-[#0A0F1D] border border-cyan-500/30 rounded-xl px-3 py-2 text-xs text-cyan-300 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs text-slate-400 mb-1">Thiết Bị Khuyên Dùng:</label>
                  <input
                    type="text"
                    value={newApkRecommended}
                    onChange={(e) => setNewApkRecommended(e.target.value)}
                    className="w-full bg-[#0A0F1D] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs text-slate-400 mb-1">Mô Tả Ngắn:</label>
                  <textarea
                    rows={2}
                    placeholder="Mô tả chức năng và hướng dẫn cài đặt..."
                    value={newApkDesc}
                    onChange={(e) => setNewApkDesc(e.target.value)}
                    className="w-full bg-[#0A0F1D] border border-slate-700 rounded-xl p-2.5 text-xs text-white"
                  />
                </div>

                <button
                  type="button"
                  onClick={handleAddCustomApk}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-400 to-emerald-400 hover:brightness-110 text-black font-black text-xs flex items-center justify-center space-x-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>Thêm Vào Danh Sách Kho APK</span>
                </button>
              </div>

              {/* Danh sách Kho APK hiện có */}
              <div className="lg:col-span-2 p-6 rounded-2xl bg-[#111A2E]/90 border border-cyan-500/20 shadow-xl space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
                  <div className="flex items-center space-x-2 text-white text-sm font-bold">
                    <UploadCloud className="w-4 h-4 text-cyan-400" />
                    <span>Danh Sách Kho APK Tùy Chỉnh ({(settings.customApkList || []).length} tệp)</span>
                  </div>
                  <button
                    onClick={handleSaveSettings}
                    className="px-4 py-2 rounded-xl bg-[#00F0FF] hover:bg-cyan-300 text-black font-extrabold text-xs flex items-center space-x-1.5"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>Lưu Kho APK Lên Firestore</span>
                  </button>
                </div>

                {(settings.customApkList || []).length === 0 ? (
                  <div className="p-10 text-center text-xs text-slate-500 italic bg-[#0A0F1D] rounded-xl border border-slate-800">
                    Chưa có tệp APK tùy chỉnh nào được thêm vào Mục 9. Bạn có thể thêm ở khung bên trái rồi nhấn &quot;Lưu Kho APK Lên Firestore&quot;.
                  </div>
                ) : (
                  <div className="space-y-3">
                    {(settings.customApkList || [])
                      .slice((customApkPage - 1) * customApkPageSize, customApkPage * customApkPageSize)
                      .map((apk: any) => (
                        <div
                          key={apk.id}
                          className="p-4 rounded-xl bg-[#0A0F1D] border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                        >
                          <div className="min-w-0 space-y-1">
                            <div className="flex items-center space-x-2 flex-wrap gap-y-1">
                              <span className="font-bold text-white text-sm">{apk.name}</span>
                              <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 font-mono">
                                v{apk.version} • {apk.size}
                              </span>
                              <span className="text-[10px] px-2 py-0.5 rounded bg-purple-500/15 text-purple-300 border border-purple-500/30">
                                {apk.category}
                              </span>
                            </div>
                            <div className="text-[11px] text-slate-400">{apk.description}</div>
                            <div className="text-[11px] font-mono text-emerald-400 truncate">{apk.downloadUrl}</div>
                          </div>

                          <div className="flex items-center space-x-2 shrink-0">
                            <a
                              href={apk.downloadUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs font-semibold flex items-center space-x-1"
                            >
                              <ExternalLink className="w-3.5 h-3.5" />
                              <span>Mở Link</span>
                            </a>
                            <button
                              type="button"
                              onClick={() => handleDeleteCustomApk(apk.id)}
                              className="p-1.5 rounded-lg bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/30"
                              title="Xóa khỏi danh sách"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))}

                    <Pagination
                      currentPage={customApkPage}
                      totalItems={(settings.customApkList || []).length}
                      pageSize={customApkPageSize}
                      onPageChange={(page) => setCustomApkPage(page)}
                    />
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </main>
      <ScrollToTop />
    </div>
  );
};