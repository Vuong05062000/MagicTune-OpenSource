import type { Metadata } from 'next';
import { PolicyPageLayout } from '@/components/common/PolicyPageLayout';

export const metadata: Metadata = {
  title: 'Chính Sách Bảo Mật (Privacy Policy) | MagicTune',
  description:
    'Chính sách bảo mật, quyền riêng tư người dùng, cơ chế xử lý WebUSB/ADB cục bộ và thông tin cookie quảng cáo Google AdSense tại MagicTune.',
  alternates: {
    canonical: 'https://magictune.web.app/privacy/',
  },
};

export default function PrivacyPolicyPage() {
  return (
    <PolicyPageLayout
      title="Chính Sách Bảo Mật (Privacy Policy)"
      subtitle="Cập nhật lần cuối: 26/11/2026 • Áp dụng cho website https://magictune.web.app và các tiện ích liên quan của MagicTune."
      activePath="/privacy/"
    >
      <section className="space-y-2">
        <h2 className="text-lg font-bold text-white">1. Nguyên tắc bảo vệ dữ liệu cá nhân</h2>
        <p>
          MagicTune tôn trọng tuyệt đối quyền riêng tư của người dùng. Toàn bộ tác vụ kết nối và cấu hình thiết bị Android qua WebUSB / ADB (Android Debug Bridge) đều chạy trực tiếp giữa trình duyệt trên máy của bạn và thiết bị của bạn thông qua cổng USB hợp chuẩn Google Chrome / Microsoft Edge.
        </p>
        <p>
          Hệ thống <strong>không thu thập, không lưu trữ và không truyền tải</strong> tin nhắn, danh bạ, hình ảnh, mật khẩu, tài liệu cá nhân hay dữ liệu nhạy cảm trên điện thoại của bạn lên bất kỳ máy chủ bên ngoài nào.
        </p>
      </section>

      <section className="space-y-2">
        <h2 className="text-lg font-bold text-white">2. Thông tin kỹ thuật và tài khoản tùy chọn</h2>
        <ul className="list-disc list-inside space-y-1.5 text-slate-300">
          <li>
            <strong>Sử dụng không cần đăng nhập:</strong> Bạn có thể sử dụng toàn bộ công cụ tối ưu WebADB mà không cần tạo tài khoản.
          </li>
          <li>
            <strong>Đăng nhập tùy chọn (Firebase Authentication):</strong> Nếu bạn chọn đăng nhập bằng Email/Google/Số điện thoại để đồng bộ hồ sơ hỗ trợ, chỉ thông tin định danh cơ bản (UID, Email hoặc tên hiển thị) được lưu trữ an toàn trên hạ tầng Google Firebase.
          </li>
          <li>
            <strong>Lưu trữ cục bộ trình duyệt (LocalStorage / IndexedDB):</strong> Giao diện lưu tùy chọn nền Sáng/Tối và khóa xác thực RSA WebADB cục bộ ngay trên trình duyệt của bạn để lần cắm cáp tiếp theo không cần xác nhận lại từ đầu. Bạn có thể xóa dữ liệu này bất cứ lúc nào.
          </li>
        </ul>
      </section>

      <section className="space-y-2">
        <h2 className="text-lg font-bold text-white">3. Google AdSense và Cookie quảng cáo của bên thứ ba</h2>
        <p>
          Website <span className="font-mono text-cyan-400">https://magictune.web.app</span> sử dụng dịch vụ quảng cáo <strong>Google AdSense</strong> (Mã nhà xuất bản: <span className="font-mono">pub-4256214784202059</span>) để duy trì chi phí máy chủ, tên miền và phát triển công cụ miễn phí cho cộng đồng.
        </p>
        <ul className="list-disc list-inside space-y-1.5 text-slate-300">
          <li>
            Các nhà cung cấp bên thứ ba, bao gồm Google, sử dụng cookie (bao gồm cookie DoubleClick / DART) để phân phát quảng cáo dựa trên lượt truy cập trước đây của người dùng vào trang web này hoặc các trang web khác trên Internet.
          </li>
          <li>
            Việc Google sử dụng cookie quảng cáo cho phép Google và các đối tác hiển thị quảng cáo phù hợp với sở thích của người dùng khi truy cập MagicTune và các website khác.
          </li>
          <li>
            Người dùng có thể quản lý hoặc tắt quảng cáo được cá nhân hóa bất cứ lúc nào bằng cách truy cập{' '}
            <a
              href="https://adssettings.google.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-cyan-400 underline hover:text-cyan-300"
            >
              Cài đặt quảng cáo của Google (adssettings.google.com)
            </a>{' '}
            hoặc kiểm soát cookie bên thứ ba tại{' '}
            <a
              href="https://www.aboutads.info/choices/"
              target="_blank"
              rel="noopener noreferrer"
              className="text-cyan-400 underline hover:text-cyan-300"
            >
              aboutads.info/choices
            </a>
            .
          </li>
        </ul>
      </section>

      <section className="space-y-2">
        <h2 className="text-lg font-bold text-white">4. Liên kết ngoài và dịch vụ bên thứ ba</h2>
        <p>
          Website có thể chứa liên kết tới Google Drive, tài liệu Android Open Source Project (AOSP) hoặc trang hỗ trợ kỹ thuật chính thức. MagicTune không kiểm soát và không chịu trách nhiệm đối với chính sách bảo mật của các trang web bên thứ ba khi bạn rời khỏi tên miền chính thức của chúng tôi.
        </p>
      </section>

      <section className="space-y-2">
        <h2 className="text-lg font-bold text-white">5. Quyền của người dùng &amp; Thông tin liên hệ</h2>
        <p>
          Bạn có quyền yêu cầu truy cập, chỉnh sửa hoặc xóa bỏ hoàn toàn dữ liệu tài khoản đã đăng ký trên hệ thống. Mọi thắc mắc về Chính sách Bảo mật xin vui lòng liên hệ trực tiếp qua email quản trị:{' '}
          <a
            href="mailto:contact@magictune.web.app"
            className="text-cyan-400 underline hover:text-cyan-300 font-semibold"
          >
            contact@magictune.web.app
          </a>
          .
        </p>
      </section>
    </PolicyPageLayout>
  );
}
