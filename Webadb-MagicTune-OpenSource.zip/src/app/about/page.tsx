import type { Metadata } from 'next';
import Link from 'next/link';
import { PolicyPageLayout } from '@/components/common/PolicyPageLayout';

export const metadata: Metadata = {
  title: 'Giới Thiệu (About MagicTune) | MagicTune',
  description:
    'Tìm hiểu về MagicTune — nền tảng WebADB trực tuyến miễn phí giúp tối ưu Android, xử lý trễ thông báo và hướng dẫn kỹ thuật chuyên sâu.',
  alternates: {
    canonical: 'https://magictune.web.app/about/',
  },
};

export default function AboutPage() {
  return (
    <PolicyPageLayout
      title="Giới Thiệu Về MagicTune"
      subtitle="Nền tảng WebADB trực tuyến phi lợi nhuận hỗ trợ tối ưu hóa và khắc phục triệt để lỗi thông báo trên các thiết bị Android hiện đại."
      activePath="/about/"
    >
      <section className="space-y-2">
        <h2 className="text-lg font-bold text-white">1. Sứ mệnh của MagicTune</h2>
        <p>
          Nhiều dòng điện thoại Android — đặc biệt là các thiết bị chạy giao diện tùy biến sâu như MagicOS, HyperOS, OriginOS, ColorOS hay One UI — thường áp dụng cơ chế tiết kiệm pin cực đoan khiến thông báo tin nhắn, email công việc hoặc cảnh báo quan trọng bị chậm từ vài phút đến hàng giờ khi tắt màn hình.
        </p>
        <p>
          MagicTune được xây dựng nhằm đơn giản hóa các bước chẩn đoán và cấu hình chuẩn Google AOSP (<em>DeviceIdle Whitelist, App Standby Bucket ACTIVE, thiết lập quyền thông báo và cầu nối Shizuku</em>) ngay trên trình duyệt web mà không cần cài đặt công cụ phức tạp hay can thiệp Root làm mất bảo hành máy.
        </p>
      </section>

      <section className="space-y-2">
        <h2 className="text-lg font-bold text-white">2. Công nghệ cốt lõi &amp; Tính minh bạch</h2>
        <ul className="list-disc list-inside space-y-1.5 text-slate-300">
          <li>
            <strong>Chuẩn WebUSB trực tiếp trên trình duyệt:</strong> Giao tiếp thẳng từ Chrome / Edge trên máy tính hoặc điện thoại OTG tới thiết bị Android qua khóa RSA do chính người dùng phê duyệt trên màn hình điện thoại.
          </li>
          <li>
            <strong>Nhật ký lệnh hiển thị công khai (ADB Cockpit):</strong> Mọi câu lệnh thực thi đều hiển thị rõ ràng trong khung Terminal thời gian thực để người dùng và kỹ thuật viên dễ dàng kiểm chứng.
          </li>
          <li>
            <strong>Kho kiến thức kỹ thuật thực tiễn:</strong> Website cung cấp hướng dẫn chi tiết về cơ chế Android Doze Mode, cách nhận biết và xử lý xung đột tiến trình nền an toàn cho cộng đồng người dùng Android tại Việt Nam.
          </li>
        </ul>
      </section>

      <section className="space-y-2">
        <h2 className="text-lg font-bold text-white">3. Cam kết vận hành &amp; Hỗ trợ</h2>
        <p>
          Toàn bộ tính năng WebADB trên website đang được cung cấp miễn phí cho cộng đồng. Chi phí hạ tầng được duy trì thông qua tài trợ tự nguyện và quảng cáo minh bạch tuân thủ chính sách Google AdSense.
        </p>
        <p>
          Nếu bạn cần hỗ trợ kỹ thuật hoặc đóng góp cải tiến cho MagicTune, vui lòng xem{' '}
          <Link href="/contact/" className="text-cyan-400 underline hover:text-cyan-300 font-semibold">
            trang Liên Hệ
          </Link>{' '}
          hoặc gửi thư về{' '}
          <a href="mailto:contact@magictune.web.app" className="text-cyan-400 underline hover:text-cyan-300 font-semibold">
            contact@magictune.web.app
          </a>
          .
        </p>
      </section>
    </PolicyPageLayout>
  );
}
