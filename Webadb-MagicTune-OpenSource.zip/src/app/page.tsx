'use client';

import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  Usb,
  Terminal,
  Zap,
  Globe,
  Trash2,
  Gauge,
  Power,
  Sparkles,
  Globe2,
  Radio,
  Settings2,
  User as UserIcon,
  LogOut,
  ShieldCheck,
  HelpCircle,
  Flame,
  Menu,
  X,
  Sun,
  Moon,
  CreditCard,
  MessageSquare,
  Crown,
  UploadCloud,
  Cpu,
  Cast,
  Bot,
  AlertTriangle,
  Smartphone,
  ChevronRight,
  Eye,
  ExternalLink
} from 'lucide-react';
import Link from 'next/link';

import { adbDriver, AdbDeviceState } from '@/lib/adb/web-usb-driver';
import { DeviceProfiler } from '@/lib/adb/honor-scripts';
import { DeviceInfoCard } from '@/components/dashboard/DeviceInfoCard';
import { NotificationFixer } from '@/components/modules/NotificationFixer';
import { DebloatEngine } from '@/components/modules/DebloatEngine';
import { LocalizationHub } from '@/components/modules/LocalizationHub';
import { PerformanceTweaks } from '@/components/modules/PerformanceTweaks';
import { ChinaRomTweaks } from '@/components/modules/ChinaRomTweaks';
import { GlobalBugFixer } from '@/components/modules/GlobalBugFixer';
import { ShizukuWlanBridge } from '@/components/modules/ShizukuWlanBridge';
import { DirectOnDeviceFixer } from '@/components/modules/DirectOnDeviceFixer';
import { MultiBrandAndroidFixer } from '@/components/modules/MultiBrandAndroidFixer';
import { WebApkInstaller } from '@/components/modules/WebApkInstaller';
import { HardwareDiagnostics } from '@/components/modules/HardwareDiagnostics';
import { BankFixerModule } from '@/components/modules/BankFixerModule';
import { APP_RELEASE_VERSION } from '@/lib/version';
import { deviceDataCache } from '@/lib/cache/device-data-cache';
import { AdbConsole } from '@/components/terminal/AdbConsole';
import { SplashScreen } from '@/components/common/SplashScreen';
import { QuickShareButton } from '@/components/common/QuickShareButton';
import { ConnectionGuideModal } from '@/components/modals/ConnectionGuideModal';
import { SupportChatModal } from '@/components/modals/SupportChatModal';
import { AdBanner } from '@/components/common/AdBanner';
import { ScrollToTop } from '@/components/common/ScrollToTop';
import { KnowledgeHubSection } from '@/components/common/KnowledgeHubSection';
import {
  auth,
  DEFAULT_APP_SETTINGS,
  AppGlobalSettings,
  SUPER_ADMIN_EMAILS,
  SUPER_ADMIN_PHONES,
  recordUserActivity,
  syncUserProfileToFirestore,
  fetchLiveSettingsFromFirestore
} from '@/lib/firebase/config';
import { onAuthStateChanged, signOut, User } from 'firebase/auth';

const MODULE_TABS = [
  { id: 'notifications', label: 'Fix Trễ FB, Gmail, Zalo (0s)', shortLabel: 'Fix Thông Báo', icon: Zap, badge: 'ƯU TIÊN' },
  { id: 'chinarom', label: 'Fix Máy Nội Địa (China)', shortLabel: 'China ROM', icon: Globe2, badge: 'Mục 1' },
  { id: 'globalbugs', label: 'Lỗi Toàn Cầu (Auto/Pin)', shortLabel: 'Lỗi Toàn Cầu', icon: Flame, badge: 'Mục 2' },
  { id: 'shizuku', label: 'Cầu Nối Shizuku Engine', shortLabel: 'Shizuku', icon: Radio, badge: 'Mục 3' },
  { id: 'debloat', label: 'Gỡ Ứng Dụng Rác', shortLabel: 'Gỡ App Rác', icon: Trash2, badge: 'Mục 4' },
  { id: 'localization', label: 'GMS & Việt Hóa', shortLabel: 'GMS / Tiếng Việt', icon: Globe, badge: 'Mục 5' },
  { id: 'performance', label: '120Hz & Tối Ưu Màn Hình', shortLabel: '120Hz & DPI', icon: Gauge, badge: 'Mục 6' },
  { id: 'no_adb', label: 'Fix Trực Tiếp Không ADB', shortLabel: 'Không Cần ADB', icon: Sparkles, badge: 'Mục 7' },
  { id: 'multibrand', label: 'Fix Đa Hãng Android', shortLabel: 'Đa Hãng', icon: Smartphone, badge: 'Mục 8' },
  { id: 'apk_install', label: 'Cài APK / APKS Web', shortLabel: 'Cài APK Web', icon: UploadCloud, badge: 'Mục 9' },
  { id: 'hardware', label: 'Kiểm Tra Phần Cứng', shortLabel: 'Phần Cứng', icon: Cpu, badge: 'Mục 10' },
  { id: 'bank_fix', label: 'Sửa Lỗi Ngân Hàng', shortLabel: 'Sửa App Bank', icon: ShieldCheck, badge: 'Mục 11' }
] as const;

export default function HomePage() {
  const [showSplash, setShowSplash] = useState(false);

  useEffect(() => {
    // Chỉ hiển thị màn hình khởi động 1 lần duy nhất trong mỗi phiên làm việc
    if (typeof window !== 'undefined') {
      const alreadyShown = sessionStorage.getItem('magictune_splash_shown');
      if (!alreadyShown) {
        setShowSplash(true);
        sessionStorage.setItem('magictune_splash_shown', 'true');
      }
    }
  }, []);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAdminUser, setIsAdminUser] = useState(false);

  const [deviceState, setDeviceState] = useState<AdbDeviceState>({
    connectionState: 'disconnected'
  });
  const [profiler, setProfiler] = useState<DeviceProfiler | null>(null);
  const [detectedBrandId, setDetectedBrandId] = useState<string>('honor_huawei');
  const [activeTab, setActiveTab] = useState<
    | 'notifications'
    | 'chinarom'
    | 'globalbugs'
    | 'shizuku'
    | 'debloat'
    | 'localization'
    | 'performance'
    | 'no_adb'
    | 'multibrand'
    | 'apk_install'
    | 'bank_fix'
    | 'hardware'
  >('notifications');
  const [mobileNavTab, setMobileNavTab] = useState<'tools' | 'device' | 'terminal' | 'menu'>('tools');
  const [isGuideOpen, setIsGuideOpen] = useState(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [isSupportModalOpen, setIsSupportModalOpen] = useState(false);
  const [isInspecting, setIsInspecting] = useState(false);
  const [showConsole, setShowConsole] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');

  // Quản lý hiển thị: Tự động phát hiện PC (Máy tính) vs Mobile (Điện thoại)
  const [isMobileDevice, setIsMobileDevice] = useState<boolean>(false);
  const [isAppleIOS, setIsAppleIOS] = useState<boolean>(false);

  // Chế độ mô phỏng góc nhìn Người Dùng Thật (Dành cho Quản Trị Viên)
  const [isPreviewAsUser, setIsPreviewAsUser] = useState(false);
  const [previewRole, setPreviewRole] = useState<'guest' | 'user'>('guest');
  const [isPreviewIframe, setIsPreviewIframe] = useState(false);
  // Trạng thái VIP mô phỏng (Admin trải nghiệm quy trình gia hạn VIP thành công siêu tốc)
  const [isSimulatedVipActive, setIsSimulatedVipActive] = useState(false);
  // Dialog xác nhận mở link tải MagicTune Tool APK từ nút Cài App trên Header
  const [isApkConfirmModalOpen, setIsApkConfirmModalOpen] = useState(false);
  // Host hiện tại trên trình duyệt (chỉ cập nhật sau mount để tránh Hydration mismatch)
  const [currentHost, setCurrentHost] = useState('magictune.web.app');

  useEffect(() => {
    if (typeof window === 'undefined') return;
    setCurrentHost(window.location.host);
    const params = new URLSearchParams(window.location.search);
    if (params.get('preview_as_user') === 'true') {
      setIsPreviewAsUser(true);
    }
    if (params.get('preview_role') === 'user') {
      setPreviewRole('user');
    } else if (params.get('preview_role') === 'guest') {
      setPreviewRole('guest');
    }
    if (params.get('preview_iframe') === 'true' || window.self !== window.top) {
      setIsPreviewIframe(true);
    }
    if (params.get('open_payment') === 'true') {
      setIsPaymentModalOpen(true);
    }
    const devParam = params.get('preview_device');
    if (devParam === 'mobile') {
      setIsMobileDevice(true);
    } else if (devParam === 'desktop') {
      setIsMobileDevice(false);
    }
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined') return;

    const detectDevice = () => {
      const params = new URLSearchParams(window.location.search);
      const devParam = params.get('preview_device');
      if (devParam === 'mobile') {
        setIsMobileDevice(true);
        return;
      }
      if (devParam === 'desktop') {
        setIsMobileDevice(false);
        return;
      }

      const ua = navigator.userAgent || '';
      setIsAppleIOS(/iPad|iPhone|iPod/.test(ua));

      // 1. Nhận diện chính xác hệ điều hành Máy tính (Windows, macOS, Linux Desktop, ChromeOS PC)
      const isDesktopOS = /Windows NT|Macintosh|Mac OS X|Linux x86_64|X11|CrOS/i.test(ua) && !/Android|iPhone|iPod|iPad|Mobile/i.test(ua);
      
      if (isDesktopOS) {
        localStorage.removeItem('magictune_device_mode');
        setIsMobileDevice(window.innerWidth < 640);
        return;
      }

      // 2. Nhận diện thiết bị di động thực tế (smartphone Android, iOS, điện thoại...)
      const isMobileUA = /Android|iPhone|iPod|BlackBerry|IEMobile|Opera Mini|Mobile/i.test(ua);
      const isSmallScreen = window.innerWidth < 1024;
      const hasTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;

      setIsMobileDevice(isMobileUA || (isSmallScreen && hasTouch));
    };

    detectDevice();

    const handleResize = () => {
      const ua = navigator.userAgent || '';
      const isDesktopOS = /Windows NT|Macintosh|Mac OS X|Linux x86_64|X11|CrOS/i.test(ua) && !/Android|iPhone|iPod|iPad|Mobile/i.test(ua);
      if (isDesktopOS) {
        setIsMobileDevice(window.innerWidth < 640);
      } else {
        setIsMobileDevice(window.innerWidth < 1024);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const savedTheme = localStorage.getItem('magictune_theme') as 'dark' | 'light' | null;
      if (savedTheme) {
        setTheme(savedTheme);
        if (savedTheme === 'light') {
          document.documentElement.classList.add('light');
          document.body.classList.add('light');
        } else {
          document.documentElement.classList.remove('light');
          document.body.classList.remove('light');
        }
      }
    }
  }, []);

  const toggleTheme = () => {
    const nextTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(nextTheme);
    if (typeof window !== 'undefined') {
      localStorage.setItem('magictune_theme', nextTheme);
      if (nextTheme === 'light') {
        document.documentElement.classList.add('light');
        document.body.classList.add('light');
      } else {
        document.documentElement.classList.remove('light');
        document.body.classList.remove('light');
      }
    }
  };

  const [settings, setSettings] = useState<AppGlobalSettings>(DEFAULT_APP_SETTINGS);

  useEffect(() => {
    // Tải cấu hình từ localStorage và Firestore sau khi mount (tránh Hydration mismatch)
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('magictune_admin_settings');
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (parsed.appName && parsed.appName.toLowerCase().includes('magicos')) {
            parsed.appName = 'MagicTune';
          }
          if (parsed.appSlogan && parsed.appSlogan.toLowerCase().includes('magicos')) {
            parsed.appSlogan = 'Bộ công cụ WebADB tối ưu hóa & Fix lỗi đa hệ điều hành Android.';
          }
          if (parsed.appDomain && (parsed.appDomain === 'magictune.app' || parsed.appDomain === 'magictune.com')) {
            parsed.appDomain = window.location.host || 'magictune.web.app';
          }
          if (parsed.footer?.customCopyrightText?.includes('magictune.app')) {
            parsed.footer.customCopyrightText = parsed.footer.customCopyrightText.replace(/magictune\.app/g, parsed.appDomain || window.location.host || 'magictune.web.app');
          }
          setSettings((prev) => ({ ...prev, ...parsed }));
        } catch (e) {}
      }
    }
    fetchLiveSettingsFromFirestore().then((live) => {
      if (live) {
        if (live.appDomain && (live.appDomain === 'magictune.app' || live.appDomain === 'magictune.com')) {
          live.appDomain = typeof window !== 'undefined' ? (window.location.host || 'magictune.web.app') : 'magictune.web.app';
        }
        if (live.footer?.customCopyrightText?.includes('magictune.app')) {
          live.footer.customCopyrightText = live.footer.customCopyrightText.replace(/magictune\.app/g, live.appDomain || 'magictune.web.app');
        }
        setSettings(live);
      }
    }).catch(() => {});
  }, []);

  const runAutoInspector = useCallback(async () => {
    setIsInspecting(true);
    try {
      const inspectScript = `echo "===INSPECT_START==="; getprop ro.product.model; echo "___DIV___"; getprop ro.product.manufacturer; echo "___DIV___"; getprop ro.product.brand; echo "___DIV___"; getprop ro.config.marketing_name; echo "___DIV___"; getprop ro.build.version.magic; echo "___DIV___"; getprop ro.build.display.id; echo "___DIV___"; getprop ro.build.version.release; echo "___DIV___"; getprop ro.board.platform; echo "___DIV___"; getprop ro.boot.hwc; echo "___DIV___"; getprop ro.miui.ui.version.name; echo "___DIV___"; getprop ro.vivo.os.build.version; echo "___DIV___"; getprop ro.build.version.opporom; echo "___DIV___"; pm list packages com.google.android.gms; echo "___DIV___"; pm list packages moe.shizuku.privileged.api; echo "___DIV___"; pm list packages com.hihonor.powergenie; echo "___DIV___"; pm list packages com.hihonor.bastet.service; echo "___DIV___"; wm density; echo "___DIV___"; settings get system peak_refresh_rate; echo "___DIV___"; dumpsys battery; echo "===INSPECT_END===";`;

      const rawOut = await adbDriver.executeCommand(inspectScript, { silent: true });

      const startTag = '===INSPECT_START===';
      const endTag = '===INSPECT_END===';
      const startIdx = rawOut.indexOf(startTag);
      const endIdx = rawOut.indexOf(endTag);
      const cleanData = (startIdx !== -1 && endIdx !== -1)
        ? rawOut.slice(startIdx + startTag.length, endIdx)
        : rawOut;

      const parts = cleanData.split('___DIV___').map((p) => p.trim());
      const model = parts[0] || '';
      const manufacturer = parts[1] || '';
      const brand = parts[2] || '';
      const marketingName = parts[3] || '';
      const magicVer = parts[4] || '';
      const displayId = parts[5] || '';
      const androidVer = parts[6] || '';
      const platform = parts[7] || '';
      const hwc = parts[8] || '';
      const miuiVer = parts[9] || '';
      const vivoVer = parts[10] || '';
      const oppoVer = parts[11] || '';
      const gmsOut = parts[12] || '';
      const shizukuOut = parts[13] || '';
      const pgOut = parts[14] || '';
      const bastetOut = parts[15] || '';
      const densityOut = parts[16] || '';
      const refreshOut = parts[17] || '';
      const batteryOut = parts[18] || '';

      // Tự động nhận diện thương hiệu thiết bị chính xác
      const fullText = `${manufacturer} ${brand} ${model} ${magicVer} ${displayId} ${miuiVer} ${vivoVer} ${oppoVer}`.toUpperCase();
      if (fullText.includes('HONOR') || fullText.includes('HUAWEI') || magicVer) {
        setDetectedBrandId('honor_huawei');
      } else if (fullText.includes('XIAOMI') || fullText.includes('REDMI') || fullText.includes('POCO') || miuiVer) {
        setDetectedBrandId('xiaomi');
      } else if (fullText.includes('SAMSUNG')) {
        setDetectedBrandId('samsung');
      } else if (fullText.includes('OPPO') || fullText.includes('REALME') || fullText.includes('ONEPLUS') || oppoVer) {
        setDetectedBrandId('oppo_realme_oneplus');
      } else if (fullText.includes('VIVO') || fullText.includes('IQOO') || vivoVer) {
        setDetectedBrandId('vivo_iqoo');
      } else if (fullText.includes('PIXEL') || fullText.includes('GOOGLE')) {
        setDetectedBrandId('universal_android');
      } else {
        setDetectedBrandId('universal_android');
      }

      // Nhận diện mã vùng xuất xưởng (Region)
      let region: DeviceProfiler['region'] = 'UNKNOWN';
      const cleanHwc = hwc.toLowerCase();
      const cleanDisplay = displayId.toLowerCase();
      if (cleanHwc.includes('cn') || cleanDisplay.includes('c00') || cleanDisplay.includes('cn') || cleanDisplay.includes('al00') || cleanDisplay.includes('an00')) {
        region = 'CN';
      } else if (cleanHwc.includes('eu') || cleanDisplay.includes('c431') || cleanDisplay.includes('c432')) {
        region = 'GLOBAL_EEA';
      } else {
        region = 'UNKNOWN';
      }

      // Nhận diện SoC Chipset
      let chipset: DeviceProfiler['chipset'] = 'Unknown';
      const cleanPlat = platform.toLowerCase();
      if (cleanPlat.includes('sm') || cleanPlat.includes('qcom') || cleanPlat.includes('taro') || cleanPlat.includes('kalama') || cleanPlat.includes('pineapple') || cleanPlat.includes('cliffs')) {
        chipset = 'Snapdragon';
      } else if (cleanPlat.includes('mt') || cleanPlat.includes('k6') || cleanPlat.includes('dimensity')) {
        chipset = 'MediaTek';
      } else if (cleanPlat.includes('kirin') || cleanPlat.includes('hi36') || cleanPlat.includes('hi62')) {
        chipset = 'Kirin';
      } else {
        chipset = 'Unknown';
      }

      let marketName = marketingName || model;
      if (!marketName || marketName.length < 2) marketName = model;

      let batteryLevel: number | null = null;
      let batteryTemp: number | null = null;
      if (batteryOut) {
        const levelMatch = batteryOut.match(/level:\s*(\d+)/i);
        if (levelMatch) {
          const parsedLevel = parseInt(levelMatch[1], 10);
          if (parsedLevel > 0 && parsedLevel <= 100) {
            batteryLevel = parsedLevel;
          }
        }
        const tempMatch = batteryOut.match(/temperature:\s*(\d+)/i);
        if (tempMatch) {
          const rawTemp = parseInt(tempMatch[1], 10);
          batteryTemp = rawTemp > 100 ? Math.round(rawTemp / 10) : rawTemp;
        }
      }

      const gmsInstalled = gmsOut.includes('package:com.google.android.gms');
      const shizukuInstalled = shizukuOut.includes('moe.shizuku.privileged.api');
      const powerGenieStatus: DeviceProfiler['powerGenieStatus'] = pgOut.includes('com.hihonor.powergenie') ? 'enabled' : 'not_found';
      const bastetStatus: DeviceProfiler['bastetStatus'] = bastetOut.includes('com.hihonor.bastet.service') ? 'enabled' : 'not_found';

      let currentDensity: number | null = null;
      const densityMatch = densityOut.match(/density:\s*(\d+)/i);
      if (densityMatch) currentDensity = parseInt(densityMatch[1], 10);

      let currentRefreshRate: number | null = null;
      const parsedHz = parseFloat(refreshOut);
      if (!isNaN(parsedHz) && parsedHz > 0) currentRefreshRate = Math.round(parsedHz);

      setProfiler({
        model: model.trim() || 'Android Device',
        marketName: marketName.trim() || model.trim() || 'Android Phone',
        magicosVersion: displayId.trim() || magicVer.trim() || 'Android OS',
        androidVersion: androidVer.trim() || 'Android',
        region,
        chipset,
        batteryLevel,
        batteryTemp,
        gmsInstalled,
        powerGenieStatus,
        bastetStatus,
        shizukuInstalled,
        currentDensity,
        currentRefreshRate
      });

      recordUserActivity('Trích xuất thông số thiết bị thực tế', `${marketName || model} (Android ${androidVer})`);
    } catch (err) {
      console.error('Lỗi phân tích thiết bị', err);
    } finally {
      setIsInspecting(false);
    }
  }, []);

  useEffect(() => {
    if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').catch((err) => {
        console.warn('SW register error', err);
      });
    }

    // Lắng nghe trạng thái đăng nhập
    const unsubAuth = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
      if (user) {
        if (!user.isAnonymous) {
          syncUserProfileToFirestore(user);
        }
        const emailLower = (user.email || '').toLowerCase();
        let adminList = settings.adminList;
        const saved = localStorage.getItem('magictune_admin_settings');
        if (saved) {
          try {
            adminList = JSON.parse(saved).adminList || adminList;
          } catch (e) {}
        }

        const isSuperAdmin = Boolean(
          SUPER_ADMIN_EMAILS.includes(emailLower) ||
          adminList.includes(emailLower) ||
          (user.phoneNumber && SUPER_ADMIN_PHONES.includes(user.phoneNumber))
        );

        setIsAdminUser(isSuperAdmin);
      } else {
        setIsAdminUser(false);
      }
    });

    // Lắng nghe WebUSB state
    const unsubscribeDriver = adbDriver.onStateChange((state) => {
      setDeviceState(state);
      if (state.connectionState === 'connected') {
        deviceDataCache.setCurrentDevice(state.serialNumber || state.productName || 'connected_device');
        runAutoInspector();
        recordUserActivity('Kết nối thiết bị ADB', state.productName || 'Honor Magic');
      } else if (state.connectionState === 'disconnected') {
        deviceDataCache.setCurrentDevice(null);
        setProfiler(null);
      }
    });

    return () => {
      unsubAuth();
      unsubscribeDriver();
    };
  }, [settings.adminList, runAutoInspector]);

  const handleConnectUsb = async () => {
    await adbDriver.requestDevice();
  };

  const handleForceNewRsaKey = async () => {
    await adbDriver.forceNewRsaKeyAndReconnect();
  };

  const handleDisconnect = async () => {
    await adbDriver.disconnect();
  };

  const handleLogout = async () => {
    await signOut(auth);
    recordUserActivity('Đăng xuất tài khoản');
    setCurrentUser(null);
    setIsAdminUser(false);
  };

  const isConnected = deviceState.connectionState === 'connected';

  // Quyền Quản trị viên hiệu lực (Tự động ẩn đi khi đang trong Chế độ Trải nghiệm Người Dùng)
  const effectiveIsAdmin = isAdminUser && !isPreviewAsUser;
  // Tài khoản người dùng hiển thị (Nếu ở chế độ Khách vãng lai, hiển thị như chưa đăng nhập)
  const effectiveCurrentUser = (isPreviewAsUser && previewRole === 'guest') ? null : currentUser;

  const [showAllModules, setShowAllModules] = useState(false);

  // Nhận diện thương hiệu đang hoạt động (CHỈ khi đã cắm cáp kết nối thật qua USB ADB)
  const currentBrandId = useMemo(() => {
    if (isConnected) {
      return detectedBrandId || 'honor_huawei';
    }
    return 'all';
  }, [isConnected, detectedBrandId]);

  const brandMetadata = useMemo(() => {
    switch (currentBrandId) {
      case 'honor_huawei':
        return { name: 'HONOR / HUAWEI', os: 'MagicOS & EMUI', color: 'text-[#00F0FF]' };
      case 'xiaomi':
        return { name: 'XIAOMI / REDMI / POCO', os: 'HyperOS & MIUI', color: 'text-amber-400' };
      case 'samsung':
        return { name: 'SAMSUNG GALAXY', os: 'One UI', color: 'text-blue-400' };
      case 'oppo_realme_oneplus':
        return { name: 'OPPO / REALME / ONEPLUS', os: 'ColorOS / Realme UI', color: 'text-emerald-400' };
      case 'vivo_iqoo':
        return { name: 'VIVO / IQOO', os: 'OriginOS / FuntouchOS', color: 'text-cyan-400' };
      case 'universal_android':
        return { name: 'GOOGLE PIXEL / ANDROID AOSP', os: 'Pixel UI / AOSP', color: 'text-purple-400' };
      default:
        return { name: 'MỌI THIẾT BỊ ANDROID', os: 'Universal System', color: 'text-cyan-300' };
    }
  }, [currentBrandId]);

  // Lọc chuẩn xác các tính năng cho thiết bị đã kết nối, ẩn đi tính năng thừa của các hãng khác
  const visibleTabs = useMemo(() => {
    const isDeviceFoldable = Boolean(
      profiler?.model &&
      /fold|flip|magic v|mix fold|mix flip|x fold|x flip|find n|oneplus open|mate x|pocket/i.test(
        `${profiler?.marketName || ''} ${profiler?.model || ''}`
      )
    );

    const baseList = (showAllModules || currentBrandId === 'all')
      ? MODULE_TABS
      : MODULE_TABS.filter((tab) => {
          // 1. Máy Honor / Huawei: Ẩn tab multibrand (vì đã có bộ công cụ MagicOS chuyên sâu riêng)
          if (currentBrandId === 'honor_huawei') {
            if (tab.id === 'multibrand') return false;
            return true;
          }

          // 2. Các hãng khác (Xiaomi, Samsung, Oppo, Vivo, Pixel...):
          // Tuyệt đối ẩn các tính năng đặc thù của Honor:
          // - chinarom: Fix Máy Nội Địa MagicOS (HiBoard, YOYO, Honor Mall)
          // - globalbugs: Lỗi Toàn Cầu MagicOS (Android Auto MagicOS, Dexopt pin)
          // - debloat: Gỡ App Rác MagicOS (40+ gói com.hihonor.*)
          if (tab.id === 'chinarom' || tab.id === 'globalbugs' || tab.id === 'debloat') {
            return false;
          }

          // 3. Samsung: Ẩn Localization vì One UI mặc định đã tích hợp sẵn full tiếng Việt & Google
          if (currentBrandId === 'samsung' && tab.id === 'localization') {
            return false;
          }

          return true;
        });

    return baseList.map((tab) => {
      // Đổi tên tab đa hãng thành thương hiệu chính xác để giao diện sắc bén, chuyên nghiệp
      if (tab.id === 'multibrand') {
        switch (currentBrandId) {
          case 'xiaomi':
            return {
              ...tab,
              label: 'Tối Ưu HyperOS & Xiaomi',
              shortLabel: 'HyperOS & MIUI',
              badge: 'XIAOMI'
            };
          case 'samsung':
            return {
              ...tab,
              label: 'Tối Ưu One UI Galaxy',
              shortLabel: 'One UI Galaxy',
              badge: 'SAMSUNG'
            };
          case 'oppo_realme_oneplus':
            return {
              ...tab,
              label: 'Tối Ưu ColorOS & Realme',
              shortLabel: 'ColorOS / Realme',
              badge: 'COLOROS'
            };
          case 'vivo_iqoo':
            return {
              ...tab,
              label: 'Tối Ưu OriginOS & Vivo',
              shortLabel: 'OriginOS & iQOO',
              badge: 'ORIGINOS'
            };
          case 'universal_android':
            return {
              ...tab,
              label: 'Tối Ưu Android Gốc (AOSP)',
              shortLabel: 'AOSP / Pixel',
              badge: 'AOSP'
            };
          default:
            return tab;
        }
      }
      if (tab.id === 'performance') {
        return {
          ...tab,
          label: isDeviceFoldable ? '120Hz & DPI Màn Gập' : '120Hz & Tối Ưu Màn Hình',
          shortLabel: isDeviceFoldable ? '120Hz & DPI Gập' : '120Hz & DPI'
        };
      }
      return tab;
    });
  }, [showAllModules, currentBrandId, profiler]);

  // Đảm bảo tab đang hoạt động luôn nằm trong danh sách visibleTabs
  useEffect(() => {
    if (!visibleTabs.some((t) => t.id === activeTab)) {
      if (visibleTabs.length > 0) {
        const brandTab = visibleTabs.find((t) => t.id === 'multibrand');
        if (brandTab && currentBrandId !== 'honor_huawei') {
          setActiveTab('multibrand');
        } else {
          setActiveTab(visibleTabs[0].id as any);
        }
      }
    }
  }, [visibleTabs, activeTab, currentBrandId]);

  const renderActiveModule = () => {
    switch (activeTab) {
      case 'chinarom':
        return <ChinaRomTweaks isConnected={isConnected} isChinaRom={profiler?.region === 'CN'} />;
      case 'globalbugs':
        return <GlobalBugFixer isConnected={isConnected} />;
      case 'notifications':
        return <NotificationFixer isConnected={isConnected} detectedBrandId={currentBrandId} isAdmin={isAdminUser} />;
      case 'shizuku':
        return <ShizukuWlanBridge isConnected={isConnected} shizukuInstalled={profiler?.shizukuInstalled} />;
      case 'debloat':
        return <DebloatEngine isConnected={isConnected} />;
      case 'localization':
        return (
          <LocalizationHub
            isConnected={isConnected}
            gmsInstalled={profiler?.gmsInstalled}
            customApks={settings.customApkList || []}
          />
        );
      case 'performance':
        return (
          <PerformanceTweaks
            isConnected={isConnected}
            currentDensity={profiler?.currentDensity}
            currentRefreshRate={profiler?.currentRefreshRate}
            profiler={profiler}
          />
        );
      case 'no_adb':
        return <DirectOnDeviceFixer />;
      case 'multibrand':
        return (
          <MultiBrandAndroidFixer
            isConnected={isConnected}
            detectedBrandId={currentBrandId}
          />
        );
      case 'apk_install':
        return <WebApkInstaller isConnected={isConnected} />;
      case 'hardware':
        return <HardwareDiagnostics isConnected={isConnected} />;
      case 'bank_fix':
        return <BankFixerModule isConnected={isConnected} />;
      default:
        return null;
    }
  };

  return (
    <>
      {/* Splash Screen */}
      {showSplash && (
        <SplashScreen
          appName={settings.appName}
          appSlogan={settings.appSlogan}
          onComplete={() => setShowSplash(false)}
        />
      )}

      {/* Toàn bộ website miễn phí 100% mã nguồn mở - Không yêu cầu đăng nhập */}

      <div className={`min-h-screen flex flex-col font-sans transition-colors duration-200 ${
        theme === 'light'
          ? 'bg-[#F8FAFC] text-slate-800'
          : 'bg-[#0A0F1D] text-slate-100'
      }`}>
        {/* Floating Top Banner khi Quản trị viên đang ở Chế Độ Trải Nghiệm Giao Diện Người Dùng */}
        {isPreviewAsUser && !isPreviewIframe && (
          <div className="sticky top-0 z-50 bg-gradient-to-r from-cyan-600 via-blue-600 to-indigo-700 text-white px-3 sm:px-6 py-2 text-xs font-bold shadow-xl border-b border-cyan-400 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center space-x-2">
              <Eye className="w-4 h-4 text-cyan-200 animate-pulse shrink-0" />
              <span>
                👁️ Trải nghiệm góc nhìn: <span className="underline decoration-cyan-300 font-extrabold">Người Dùng (100% Miễn Phí Không Cần Pro)</span> • Đã ẩn toàn bộ quyền Admin
              </span>
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setIsMobileDevice((prev) => !prev)}
                className="px-2.5 py-1 rounded-lg bg-black/30 hover:bg-black/50 text-white border border-white/20 text-[11px] font-semibold transition-all"
              >
                {isMobileDevice ? '💻 Xem Giao Diện Máy Tính' : '📱 Xem Giao Diện Điện Thoại'}
              </button>
              <Link
                href="/admin"
                className="px-3 py-1 rounded-lg bg-amber-400 hover:bg-amber-300 text-black text-[11px] font-black flex items-center space-x-1 shadow-md transition-all"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-black" />
                <span>Quay Lại Quản Trị</span>
              </Link>
            </div>
          </div>
        )}

        {/* Header Bar: Xếp hàng ngay ngắn, đồng đều kích thước trên Mobile, Tablet/iPad và Desktop */}
        <header className={`sticky top-0 z-40 border-b transition-colors duration-200 ${
          theme === 'light'
            ? 'border-slate-200 bg-white/95 backdrop-blur-xl shadow-sm'
            : 'border-cyan-500/20 bg-[#0A0F1D]/95 backdrop-blur-xl'
        }`}>
          <div className="max-w-[1600px] mx-auto px-2.5 sm:px-4 lg:px-8 py-2 min-h-14 sm:min-h-16 flex flex-wrap sm:flex-nowrap items-center justify-between gap-2">
            {/* Logo & App Brand */}
            <div className="flex items-center gap-2 min-w-0 shrink-0">
              <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-tr from-[#00F0FF] to-[#8B5CF6] p-0.5 flex items-center justify-center shadow-md shadow-cyan-500/20 shrink-0">
                <div className={`w-full h-full rounded-[9px] flex items-center justify-center ${
                  theme === 'light' ? 'bg-white border border-slate-200' : 'bg-[#0A0F1D]'
                }`}>
                  <Zap className="w-4 h-4 text-[#00F0FF]" />
                </div>
              </div>
              <div className="flex items-center gap-1.5 min-w-0">
                <span className="text-[10px] sm:text-[11px] font-mono text-cyan-400 font-bold tracking-tight truncate max-w-[115px] sm:max-w-[160px] md:max-w-none">
                  {settings.appDomain && settings.appDomain !== 'magictune.app' ? settings.appDomain : currentHost}
                </span>
                <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-cyan-500/15 text-[#00F0FF] border border-cyan-500/30 font-mono font-bold shrink-0 whitespace-nowrap">
                  {APP_RELEASE_VERSION}
                </span>
              </div>
            </div>

            {/* Desktop & Tablet/iPad Action Controls */}
            <div className={`${isMobileDevice ? 'hidden' : 'flex'} items-center gap-1.5 lg:gap-2 flex-nowrap shrink-0`}>
              {isConnected ? (
                <div className="flex items-center gap-1.5 shrink-0">
                  <div className="h-9 flex items-center gap-1.5 px-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-[11px] whitespace-nowrap">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse shrink-0" />
                    <span className="truncate max-w-[85px] md:max-w-[120px] font-semibold">{deviceState.productName || 'Android'}</span>
                    {profiler?.batteryLevel !== null && profiler?.batteryLevel !== undefined ? (
                      <span className="text-[10px] text-cyan-300 font-mono bg-cyan-500/10 px-1.5 py-0.5 rounded border border-cyan-500/20">
                        {profiler.batteryLevel}%{profiler.batteryTemp ? ` • ${profiler.batteryTemp}°C` : ''}
                      </span>
                    ) : (
                      <span className="hidden md:inline text-[10px] text-emerald-300 font-semibold bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">
                        Đã kết nối
                      </span>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={handleDisconnect}
                    className="h-9 px-2.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 text-[11px] font-bold inline-flex items-center justify-center gap-1 transition-all whitespace-nowrap shrink-0"
                    title="Ngắt kết nối USB"
                    aria-label="Ngắt kết nối USB"
                  >
                    <Power className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                    <span className="hidden lg:inline">Ngắt</span>
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={handleConnectUsb}
                  className="h-9 px-2.5 md:px-3.5 rounded-xl bg-gradient-to-r from-[#00F0FF] to-blue-600 hover:from-cyan-400 text-black font-extrabold text-[11px] sm:text-xs inline-flex items-center justify-center gap-1.5 shadow-md shadow-cyan-500/20 transition-all hover:scale-[1.02] active:scale-[0.98] whitespace-nowrap shrink-0"
                  title="Kết nối cáp USB với điện thoại"
                >
                  <Usb className="w-3.5 h-3.5 text-black shrink-0" />
                  <span className="hidden md:inline">Kết Nối Cáp USB</span>
                  <span className="md:hidden">Cắm USB</span>
                </button>
              )}

              {/* Nút Đổi Nền Sáng / Tối (Dark / Light Mode) */}
              <button
                type="button"
                onClick={toggleTheme}
                className={`min-w-9 h-9 px-2.5 rounded-xl border text-[11px] font-bold inline-flex items-center justify-center gap-1.5 transition-all whitespace-nowrap shrink-0 ${
                  theme === 'light'
                    ? 'bg-amber-100 hover:bg-amber-200 text-amber-700 border-amber-300 shadow-sm'
                    : 'bg-[#111A2E] hover:bg-slate-800 text-amber-300 border-cyan-500/20'
                }`}
                title={theme === 'light' ? 'Chuyển sang nền Tối (Cyberpunk Dark)' : 'Chuyển sang nền Sáng (Clean Light)'}
                aria-label={theme === 'light' ? 'Chuyển sang nền Tối' : 'Chuyển sang nền Sáng'}
              >
                {theme === 'light' ? (
                  <>
                    <Moon className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                    <span className="hidden xl:inline">Nền Tối</span>
                  </>
                ) : (
                  <>
                    <Sun className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span className="hidden xl:inline">Nền Sáng</span>
                  </>
                )}
              </button>

              {/* Nút Chat AI / Hỗ Trợ */}
              <button
                type="button"
                onClick={() => setIsSupportModalOpen(true)}
                className="min-w-9 h-9 px-2.5 rounded-xl bg-purple-500/15 hover:bg-purple-500/25 text-purple-300 border border-purple-500/30 text-[11px] font-bold transition-all inline-flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0"
                title="Hỗ trợ kỹ thuật 24/7 với AI"
                aria-label="Hỗ trợ kỹ thuật 24/7"
              >
                <MessageSquare className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                <span className="hidden lg:inline">Hỗ Trợ</span>
              </button>

              {/* Nút Hướng Dẫn */}
              <button
                type="button"
                onClick={() => setIsGuideOpen(true)}
                className="min-w-9 h-9 px-2.5 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 text-[#00F0FF] border border-cyan-500/30 text-[11px] font-bold transition-all inline-flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0"
                title="Xem hướng dẫn kết nối"
                aria-label="Hướng dẫn kết nối"
              >
                <HelpCircle className="w-3.5 h-3.5 shrink-0" />
                <span className="hidden xl:inline">Hướng Dẫn</span>
              </button>

              {/* Nút Cài App (Mở Dialog xác nhận tải MagicTune Tool APK) & Chia sẻ */}
              <button
                type="button"
                onClick={() => setIsApkConfirmModalOpen(true)}
                className="min-w-9 h-9 px-2.5 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/40 text-[11px] font-bold transition-all inline-flex items-center justify-center gap-1.5 active:scale-95 shadow-sm shadow-emerald-500/10 whitespace-nowrap shrink-0"
                title="Tải xuống MagicTune Tool APK"
                aria-label="Tải xuống MagicTune Tool APK"
              >
                <Smartphone className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span className="hidden md:inline">Cài App</span>
              </button>
              <QuickShareButton compact />

              {/* Huy hiệu 100% Miễn Phí & Link GitHub Open Source */}
              <a
                href={settings.magicTuneGithubRepoUrl || "https://github.com/Vuong05062000/MagicTune-OpenSource"}
                target="_blank"
                rel="noopener noreferrer"
                className="h-9 px-3 rounded-xl bg-gradient-to-r from-emerald-500/15 via-cyan-500/15 to-emerald-500/15 hover:from-emerald-500/25 hover:to-cyan-500/25 border border-emerald-500/35 text-[11px] font-black text-emerald-300 inline-flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 shadow-sm transition-all active:scale-95"
                title="Dự án mã nguồn mở - Xem trên GitHub (https://github.com/Vuong05062000/MagicTune-OpenSource)"
              >
                <Sparkles className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>100% Miễn Phí • GitHub</span>
              </a>

              {/* Nút Xem Giao Diện Khách (Dành cho Quản Trị Viên) */}
              {effectiveIsAdmin && (
                <button
                  type="button"
                  onClick={() => {
                    setIsPreviewAsUser(true);
                    setPreviewRole('guest');
                  }}
                  className="min-w-9 h-9 px-2.5 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 text-[#00F0FF] border border-cyan-500/30 text-[11px] font-bold transition-all inline-flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0"
                  title="Xem giao diện người dùng như một khách vãng lai"
                  aria-label="Xem giao diện khách"
                >
                  <Eye className="w-3.5 h-3.5 text-[#00F0FF] shrink-0" />
                  <span className="hidden xl:inline">Xem UI Khách</span>
                </button>
              )}

              {/* Nút Quản Trị */}
              {effectiveIsAdmin && (
                <Link
                  href="/admin"
                  className="h-9 px-2.5 rounded-xl bg-gradient-to-r from-amber-500/20 to-orange-500/20 hover:from-amber-500/30 text-amber-300 border border-amber-500/40 text-[11px] font-bold transition-all inline-flex items-center justify-center gap-1.5 animate-pulse whitespace-nowrap shrink-0"
                >
                  <ShieldCheck className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>Quản Trị</span>
                </Link>
              )}
            </div>

            {/* Mobile & Compact Tablet Header Right Controls (Khi isMobileDevice = true) */}
            <div className={`${isMobileDevice ? 'flex' : 'hidden'} items-center gap-1.5 shrink-0`}>
              {/* Nút Trợ lý AI & Hỗ trợ kỹ thuật 24/7 */}
              <button
                type="button"
                onClick={() => setIsSupportModalOpen(true)}
                className="h-8 sm:h-9 px-2 sm:px-2.5 rounded-xl bg-purple-500/15 hover:bg-purple-500/25 text-purple-300 border border-purple-500/30 active:scale-95 transition-all inline-flex items-center justify-center gap-1 shadow-sm whitespace-nowrap shrink-0"
                title="Mở Trợ lý AI & Hỗ trợ kỹ thuật 24/7"
              >
                <Sparkles className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                <span className="text-[11px] font-bold text-purple-300">Trợ Lý AI</span>
              </button>

              {isConnected ? (
                <div className="flex items-center gap-1 shrink-0">
                  <button
                    type="button"
                    onClick={() => setMobileNavTab('device')}
                    className="h-8 sm:h-9 inline-flex items-center gap-1.5 px-2 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-[11px] font-semibold whitespace-nowrap"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse shrink-0" />
                    <span className="truncate max-w-[75px]">{deviceState.productName || 'Android'}</span>
                    {profiler?.batteryLevel !== null && profiler?.batteryLevel !== undefined ? (
                      <span className="text-[10px] text-cyan-300 font-mono bg-cyan-500/15 px-1 rounded">
                        {profiler.batteryLevel}%
                      </span>
                    ) : (
                      <span className="text-[10px] text-emerald-300 font-semibold bg-emerald-500/15 px-1 rounded">
                        Online
                      </span>
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={handleDisconnect}
                    className="h-8 w-8 sm:h-9 sm:w-9 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/30 transition-all inline-flex items-center justify-center shrink-0"
                    title="Ngắt kết nối"
                    aria-label="Ngắt kết nối"
                  >
                    <Power className="w-3.5 h-3.5 text-rose-400" />
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={handleConnectUsb}
                  className="h-8 sm:h-9 px-2 sm:px-2.5 rounded-xl bg-gradient-to-r from-[#00F0FF] to-blue-600 text-black font-extrabold text-[11px] inline-flex items-center justify-center gap-1 shadow-md shadow-cyan-500/20 active:scale-95 transition-all whitespace-nowrap shrink-0"
                  title="Kết nối cáp USB"
                >
                  <Usb className="w-3.5 h-3.5 text-black shrink-0" />
                  <span>Cắm Cáp USB</span>
                </button>
              )}

              {/* Theme toggle: Nền sáng / tối */}
              <button
                type="button"
                onClick={toggleTheme}
                className={`h-8 w-8 sm:h-9 sm:w-9 rounded-xl border active:scale-95 transition-all inline-flex items-center justify-center shrink-0 ${
                  theme === 'light'
                    ? 'bg-amber-100 text-amber-700 border-amber-300'
                    : 'bg-[#111A2E] text-amber-300 border-cyan-500/20'
                }`}
                title={theme === 'light' ? 'Chuyển sang nền Tối' : 'Chuyển sang nền Sáng'}
                aria-label={theme === 'light' ? 'Chuyển sang nền Tối' : 'Chuyển sang nền Sáng'}
              >
                {theme === 'light' ? <Moon className="w-3.5 h-3.5 text-amber-600" /> : <Sun className="w-3.5 h-3.5 text-amber-400" />}
              </button>
            </div>
          </div>
        </header>


        {/* Main Content Area */}
        <main className={`max-w-[1600px] mx-auto px-3 sm:px-6 lg:px-8 py-3 sm:py-6 flex-1 w-full ${
          isMobileDevice ? 'pb-36' : 'pb-8'
        }`}>
          {(!isMobileDevice || mobileNavTab === 'tools') && (
            <>
          {/* BANNER THƯƠNG HIỆU & TÊN ỨNG DỤNG ĐẦU TRANG NỘI DUNG (HERO APP TITLE) */}
          <div className="mb-4 sm:mb-6 p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-[#111A2E]/95 via-[#0D182E]/90 to-[#111A2E]/95 border border-cyan-500/30 shadow-2xl backdrop-blur-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center space-x-3.5 sm:space-x-4">
              <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-gradient-to-tr from-[#00F0FF] via-cyan-400 to-[#8B5CF6] p-0.5 flex items-center justify-center shadow-lg shadow-cyan-500/25 shrink-0">
                <div className={`w-full h-full rounded-[14px] flex items-center justify-center ${
                  theme === 'light' ? 'bg-white' : 'bg-[#0A0F1D]'
                }`}>
                  <Zap className="w-6 h-6 sm:w-7 sm:h-7 text-[#00F0FF]" />
                </div>
              </div>
              <div className="min-w-0">
                <div className="flex items-center space-x-2 flex-wrap gap-y-1">
                  <h1 className={`text-xl sm:text-2xl md:text-3xl font-black tracking-wide leading-tight ${
                    theme === 'light' ? 'text-slate-900' : 'text-white'
                  }`}>
                    {settings.appName}
                  </h1>
                  <span className="text-xs px-2 py-0.5 rounded-lg bg-gradient-to-r from-cyan-500/20 to-blue-500/20 text-[#00F0FF] border border-cyan-500/40 font-mono font-black tracking-wider shadow-sm shadow-cyan-500/20">
                    {APP_RELEASE_VERSION}
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30 font-semibold uppercase">
                    Universal Android Toolkit
                  </span>
                  {!settings.monetization?.enabled && (
                    <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold flex items-center space-x-1 shadow-sm">
                      <span>🎁 Miễn Phí 100% Mọi Tính Năng</span>
                    </span>
                  )}
                </div>
                <p className="text-xs sm:text-sm text-slate-300 mt-1 font-medium leading-relaxed">
                  {settings.appSlogan || 'Bộ công cụ WebADB tối ưu hóa & Fix lỗi đa hệ điều hành Android.'}
                </p>
                <div className="text-[11px] font-mono text-cyan-400/80 mt-1 flex items-center space-x-1.5 flex-wrap">
                  <span className="text-slate-400">Hỗ trợ:</span>
                  <span className="text-cyan-300 font-semibold">{settings.androidSupport?.supportedOsListText || 'MagicOS, HyperOS, One UI, ColorOS, OriginOS, Pixel'}</span>
                  <span className="text-slate-500">•</span>
                  <span className="text-emerald-400 font-semibold">{settings.androidSupport?.supportedAndroidRange || 'Android 8.0 - 17+'}</span>
                </div>
              </div>
            </div>

            {/* Quick Action Badges */}
            <div className="flex items-center space-x-2 shrink-0 self-start md:self-center">
              <button
                onClick={() => setIsSupportModalOpen(true)}
                className="px-3 py-2 rounded-xl bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border border-purple-500/40 text-xs font-bold transition-all flex items-center space-x-1.5 shadow-sm active:scale-95"
              >
                <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                <span>Hỗ Trợ Kỹ Thuật AI</span>
              </button>
              <button
                onClick={() => setIsGuideOpen(true)}
                className="px-3 py-2 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 text-[#00F0FF] border border-cyan-500/30 text-xs font-bold transition-all flex items-center space-x-1.5 active:scale-95"
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>Hướng Dẫn</span>
              </button>
            </div>
          </div>

          {/* Ô TẢI APP MAGICTUNE APK NỔI BẬT ĐẦU TRANG (HIỂN THỊ TRÊN CẢ ĐIỆN THOẠI & MÁY TÍNH) */}
          <div className="mb-4 sm:mb-6 p-4 rounded-2xl bg-gradient-to-r from-emerald-950/80 via-[#0F1B33] to-cyan-950/80 border border-emerald-500/40 shadow-xl shadow-emerald-500/10 flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div className="flex items-center space-x-3">
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-emerald-400 to-cyan-500 p-0.5 shrink-0 shadow-md shadow-emerald-500/25">
                <div className="w-full h-full rounded-[10px] bg-[#0A0F1D] flex items-center justify-center">
                  <Smartphone className="w-5 h-5 text-emerald-400" />
                </div>
              </div>
              <div>
                <div className="flex items-center space-x-1.5 flex-wrap gap-y-1">
                  <span className="text-sm font-black text-white">Tải App MagicTune APK</span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold">
                    Dùng Thử Miễn Phí
                  </span>
                </div>
                <p className="text-[11px] sm:text-xs text-slate-300 mt-0.5 leading-snug">
                  Cài trực tiếp lên điện thoại Android &amp; Honor — Fix thông báo, tối ưu máy không cần PC.
                </p>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full lg:w-auto shrink-0">
              <a
                href={settings.magicTuneApkUrl || DEFAULT_APP_SETTINGS.magicTuneApkUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto shrink-0 py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 font-black text-xs shadow-lg shadow-emerald-500/25 flex items-center justify-center space-x-2 transition-all active:scale-[0.98]"
              >
                <UploadCloud className="w-4 h-4 rotate-180 shrink-0" />
                <span>Tải từ Google Drive</span>
                <ChevronRight className="w-4 h-4 shrink-0" />
              </a>

              <a
                href={settings.magicTuneGithubApkUrl || DEFAULT_APP_SETTINGS.magicTuneGithubApkUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto shrink-0 py-2.5 px-4 rounded-xl bg-[#0A0F1D] hover:bg-slate-800 text-slate-100 border border-cyan-500/40 font-black text-xs shadow-lg shadow-slate-950/30 flex items-center justify-center space-x-2 transition-all active:scale-[0.98]"
              >
                <svg className="w-4 h-4 fill-current shrink-0" viewBox="0 0 24 24" aria-hidden="true">
                  <path d="M12 .5C5.65.5.5 5.65.5 12c0 5.08 3.29 9.39 7.86 10.91.58.1.79-.25.79-.56 0-.28-.01-1.02-.02-2-3.2.7-3.88-1.54-3.88-1.54-.52-1.33-1.28-1.69-1.28-1.69-1.05-.72.08-.7.08-.7 1.16.08 1.77 1.19 1.77 1.19 1.03 1.76 2.7 1.25 3.36.96.1-.75.4-1.25.73-1.54-2.55-.29-5.24-1.28-5.24-5.68 0-1.26.45-2.28 1.19-3.09-.12-.29-.52-1.46.11-3.05 0 0 .97-.31 3.18 1.18a11.05 11.05 0 0 1 5.79 0c2.21-1.49 3.18-1.18 3.18-1.18.63 1.59.23 2.76.11 3.05.74.81 1.19 1.83 1.19 3.09 0 4.41-2.69 5.39-5.25 5.67.41.36.78 1.06.78 2.14 0 1.54-.01 2.79-.01 3.17 0 .31.21.67.8.56A11.51 11.51 0 0 0 23.5 12C23.5 5.65 18.35.5 12 .5z" />
                </svg>
                <span>Tải từ GitHub</span>
                <ChevronRight className="w-4 h-4 shrink-0" />
              </a>
            </div>
          </div>

            </>
          )}

          {/* CẢNH BÁO XÁC THỰC RSA TOKEN KHI ĐIỆN THOẠI CHƯA BẤM CHO PHÉP */}
          {(deviceState.connectionState === 'unauthorized' || deviceState.connectionState === 'authorizing') && (
            <div className="mb-4 sm:mb-6 p-4 sm:p-5 rounded-2xl bg-amber-500/15 border-2 border-amber-500/50 shadow-xl shadow-amber-500/10">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div className="flex items-start space-x-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center shrink-0 text-amber-400">
                    <AlertTriangle className="w-6 h-6 animate-bounce" />
                  </div>
                  <div>
                    <h3 className="text-sm sm:text-base font-extrabold text-white flex items-center space-x-2">
                      <span>{deviceState.connectionState === 'authorizing' ? 'Đang Chờ Xác Thực RSA Token...' : 'Điện Thoại Chưa Được Cấp Quyền ADB!'}</span>
                      <span className="text-[10px] bg-amber-500 text-black font-black px-2 py-0.5 rounded-full uppercase">Cần Chú Ý</span>
                    </h3>
                    <p className="text-xs text-amber-200 mt-1 leading-relaxed">
                      Vui lòng <strong>mở sáng màn hình điện thoại</strong> của bạn, tìm thông báo <em>&quot;Cho phép gỡ lỗi USB từ máy tính này?&quot;</em>, tích chọn ô <strong>&quot;Luôn cho phép&quot;</strong> và bấm <strong>[CHO PHÉP / OK]</strong>.
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-2 w-full sm:w-auto shrink-0 flex-wrap gap-y-2">
                  <button
                    onClick={handleConnectUsb}
                    className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 hover:from-amber-300 text-black font-extrabold text-xs shadow-md shadow-amber-500/20 active:scale-95 transition-all"
                  >
                    Đã Bấm OK, Thử Kết Nối Lại
                  </button>
                  <button
                    onClick={handleForceNewRsaKey}
                    className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-400 via-teal-400 to-blue-500 hover:from-cyan-300 text-black font-black text-xs shadow-md shadow-cyan-500/25 active:scale-95 transition-all flex items-center justify-center space-x-1.5"
                    title="Xóa khóa RSA cũ, sinh cặp khóa mới tinh và ép điện thoại Android bật lại bảng Cho phép gỡ lỗi USB"
                  >
                    <Zap className="w-4 h-4 text-black fill-current shrink-0" />
                    <span>Ép Hiện Bảng Cho Phép (RSA Mới)</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* CẢNH BÁO THÔNG MINH CHO NGƯỜI DÙNG TRUY CẬP TỪ IPHONE / IPAD (APPLE IOS) */}
          {isAppleIOS && (
            <div className="mb-4 sm:mb-6 p-4 rounded-2xl bg-purple-950/40 border border-purple-500/40 text-purple-200 shadow-lg flex items-start space-x-3">
              <div className="w-9 h-9 rounded-xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center shrink-0 text-purple-300 font-bold text-lg">
                🍎
              </div>
              <div className="space-y-1">
                <div className="text-xs sm:text-sm font-extrabold text-white flex items-center space-x-2">
                  <span>Bạn Đang Truy Cập Từ Thiết Bị Apple iOS (iPhone / iPad)</span>
                  <span className="text-[9px] bg-purple-500/30 text-purple-200 px-2 py-0.5 rounded-full font-mono font-semibold">Chỉ Xem / Hướng Dẫn</span>
                </div>
                <p className="text-xs text-purple-200/90 leading-relaxed">
                  Trình duyệt Safari và hệ điều hành iOS không hỗ trợ API WebUSB theo chính sách của Apple. Để cắm cáp kết nối và tối ưu hóa điện thoại Android, bạn hãy mở <strong>{settings.appDomain && settings.appDomain !== 'magictune.app' ? settings.appDomain : currentHost}</strong> trên <strong>Máy tính PC/Laptop</strong> (Chrome, Edge, Cốc Cốc) hoặc trên một chiếc <strong>điện thoại Android</strong> khác qua cáp OTG.
                </p>
              </div>
            </div>
          )}

          {/* DESKTOP DASHBOARD INTERFACE (Hiển thị cho máy tính PC / Laptop) */}
          <div className={`${!isMobileDevice ? 'grid' : 'hidden'} grid-cols-1 lg:grid-cols-12 gap-6 items-start`}>
            {/* Cột trái: Device Card + Console */}
            <div className="lg:col-span-4 space-y-6">
              <DeviceInfoCard
                profiler={profiler}
                isConnected={isConnected}
                onRefresh={runAutoInspector}
                isInspecting={isInspecting}
                onOpenGuide={() => setIsGuideOpen(true)}
                supportedAndroidRange={settings.androidSupport?.supportedAndroidRange}
                onSelectTab={setActiveTab}
              />

              {/* Shizuku Banner */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-purple-950/30 to-[#111A2E] border border-purple-500/20 text-xs">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2 text-purple-300 font-bold">
                    <Radio className="w-4 h-4" />
                    <span>Cầu Nối Shizuku Engine</span>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 font-mono">
                    Sẵn sàng
                  </span>
                </div>
                <p className="text-slate-400 text-[11px] leading-relaxed mb-3">
                  Khởi động Shizuku Server để tự động thực thi các quyền hạn cấp cao ngay trên máy không cần cắm lại cáp máy tính.
                </p>
                <button
                  onClick={() => setActiveTab('shizuku')}
                  className="w-full py-1.5 rounded-lg bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 border border-purple-500/30 text-xs font-semibold flex items-center justify-center space-x-1 transition-all"
                >
                  <span>Mở Cầu Nối Shizuku</span>
                </button>
              </div>

              {/* Sidebar Ad Placement */}
              <AdBanner
                client={settings.seo?.googleAdsenseClient || 'ca-pub-4256214784202059'}
                slot={settings.seo?.adSlotSidebar}
                format="rectangle"
              />

              {/* Console */}
              {showConsole && (
                <div>
                  <AdbConsole isAdmin={isAdminUser} />
                </div>
              )}
            </div>

            {/* Cột phải: Modules */}
            <div className="lg:col-span-8 space-y-6">
              {/* Thanh Thông Báo Lọc Thông Minh Theo Thiết Bị */}
              {currentBrandId !== 'all' && (
                <div className="flex flex-col sm:flex-row sm:items-center justify-between p-3 rounded-2xl bg-gradient-to-r from-cyan-950/40 via-[#111A2E] to-blue-950/30 border border-cyan-500/35 text-xs gap-2.5 shadow-lg shadow-cyan-950/20">
                  <div className="flex items-center space-x-2.5 min-w-0">
                    <div className="w-8 h-8 rounded-xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-[#00F0FF] shrink-0">
                      <Sparkles className="w-4 h-4 text-[#00F0FF]" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center space-x-2">
                        <span className="font-bold text-white text-xs sm:text-sm truncate">
                          {isConnected ? 'Thiết Bị Đang Kết Nối:' : 'Thiết Bị Nhận Diện:'}{' '}
                          <span className={`font-black ${brandMetadata.color}`}>{brandMetadata.name}</span>
                        </span>
                        <span className="hidden sm:inline-block text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-mono font-bold shrink-0">
                          {showAllModules ? 'Hiện Tất Cả' : 'Đã Lọc Chuẩn 100%'}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 truncate mt-0.5">
                        {showAllModules
                          ? 'Đang hiển thị toàn bộ danh mục của tất cả các hãng Android.'
                          : `Đã tự động ẩn các tính năng thừa, chỉ hiển thị ${visibleTabs.length} công cụ tương thích chuẩn xác cho ${brandMetadata.os}.`}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => setShowAllModules(!showAllModules)}
                    className="px-3 py-1.5 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 hover:text-white border border-cyan-500/30 text-xs font-bold transition-all shrink-0 self-start sm:self-auto"
                  >
                    {showAllModules ? 'Chỉ Hiện Tính Năng Máy Này' : 'Hiện Toàn Bộ Tính Năng'}
                  </button>
                </div>
              )}

              {/* Desktop Filtered Module Grid Menu */}
              <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-2 sm:gap-2.5 pb-2">
                {visibleTabs.map((tab) => {
                  const Icon = tab.icon;
                  const isActive = activeTab === tab.id;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id as any)}
                      className={`flex items-center space-x-2 sm:space-x-2.5 p-2.5 sm:p-3 rounded-2xl text-xs font-bold transition-all text-left border overflow-hidden min-w-0 ${
                        isActive
                          ? 'bg-gradient-to-r from-[#00F0FF] to-blue-500 text-black border-cyan-400 shadow-lg shadow-cyan-500/25 scale-[1.01]'
                          : theme === 'light'
                            ? 'bg-white text-slate-800 border-slate-200 hover:border-cyan-500 hover:bg-slate-50 shadow-sm'
                            : 'bg-[#111A2E]/80 text-slate-300 border-slate-700 hover:border-cyan-500/40 hover:bg-[#16223d]'
                      }`}
                    >
                      <Icon className={`w-4 h-4 shrink-0 ${
                        isActive ? 'text-black' : theme === 'light' ? 'text-cyan-700' : 'text-cyan-400'
                      }`} />
                      <div className="min-w-0">
                        <span className={`block text-[10px] sm:text-[11px] font-black uppercase tracking-wider leading-none mb-1 ${
                          isActive ? 'text-black opacity-80' : theme === 'light' ? 'text-cyan-800 font-bold' : 'text-cyan-400 opacity-80'
                        }`}>
                          {tab.badge}
                        </span>
                        <span className={`line-clamp-2 leading-tight block font-semibold text-[11px] sm:text-xs ${
                          isActive ? 'text-black' : theme === 'light' ? 'text-slate-900' : 'text-slate-200'
                        }`}>
                          {tab.label}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Module Active Display */}
              <div>{renderActiveModule()}</div>
            </div>
          </div>

          {/* Cẩm Nang Kiến Thức & AdBanner Trải Rộng Toàn Khung (Desktop) */}
          {!isMobileDevice && (
            <div className="mt-6 space-y-6">
              <AdBanner
                client={settings.seo?.googleAdsenseClient || 'ca-pub-4256214784202059'}
                slot={settings.seo?.adSlotBottom}
                format="horizontal"
              />
              <KnowledgeHubSection />
            </div>
          )}

          {/* MOBILE APP INTERFACE (Hiển thị cho điện thoại smartphone) */}
          <div className={`${isMobileDevice ? 'block' : 'hidden'} max-w-lg mx-auto space-y-3.5 pb-12`}>
            {/* TAB 1: CÔNG CỤ (TOOLS) */}
            {mobileNavTab === 'tools' && (
              <div className="space-y-3">
                {/* Connection Status Card if disconnected on Mobile - Tập Trung Kết Nối Cáp USB */}
                {!isConnected && (
                  <div className="p-3.5 rounded-2xl bg-gradient-to-r from-cyan-950/40 via-blue-950/30 to-[#111A2E] border border-cyan-500/30 space-y-2.5 shadow-md">
                    <div className="flex items-center space-x-2.5">
                      <div className="w-10 h-10 rounded-2xl border border-cyan-500/40 bg-cyan-500/15 flex items-center justify-center shrink-0 shadow-md text-[#00F0FF]">
                        <Usb className="w-5 h-5" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-bold text-white flex items-center space-x-1.5 truncate">
                          <span>Chưa Kết Nối Cáp USB</span>
                          <span className="text-[9px] px-1.5 py-0.2 rounded-full font-mono font-bold border border-amber-500/40 bg-amber-500/15 text-amber-300 shrink-0">
                            Yêu Cầu Cáp
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-300 leading-snug mt-0.5">
                          Cắm cáp USB nối điện thoại với máy tính để bắt đầu tối ưu
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 gap-2 pt-1">
                      <button
                        onClick={handleConnectUsb}
                        className="w-full flex items-center justify-between p-2.5 rounded-xl bg-gradient-to-r from-[#00F0FF] to-blue-600 text-black text-xs font-extrabold active:scale-[0.98] transition-all shadow-md shadow-cyan-500/20"
                      >
                        <div className="flex items-center space-x-2.5">
                          <Usb className="w-4 h-4 text-black shrink-0" />
                          <span>Cắm Cáp &amp; Kết Nối USB Ngay</span>
                        </div>
                        <ChevronRight className="w-4 h-4 text-black shrink-0" />
                      </button>

                      <button
                        onClick={() => setIsGuideOpen(true)}
                        className="w-full flex items-center justify-between p-2.5 rounded-xl bg-cyan-500/15 border border-cyan-500/40 text-cyan-300 text-xs font-bold active:scale-[0.98] transition-all"
                      >
                        <div className="flex items-center space-x-2.5">
                          <HelpCircle className="w-4 h-4 text-[#00F0FF] shrink-0" />
                          <span>Hướng Dẫn Bật Gỡ Lỗi USB (1 Phút)</span>
                        </div>
                        <ChevronRight className="w-4 h-4 text-cyan-400 shrink-0" />
                      </button>

                      <button
                        onClick={() => setActiveTab('shizuku')}
                        className="w-full flex items-center justify-between p-2.5 rounded-xl bg-purple-500/15 border border-purple-500/40 text-purple-300 text-xs font-bold active:scale-[0.98] transition-all"
                      >
                        <div className="flex items-center space-x-2.5">
                          <Radio className="w-4 h-4 text-purple-400 shrink-0" />
                          <span>Cầu Nối Shizuku Engine</span>
                        </div>
                        <ChevronRight className="w-4 h-4 text-purple-400 shrink-0" />
                      </button>

                      <button
                        onClick={() => setActiveTab('no_adb')}
                        className="w-full flex items-center justify-between p-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 text-xs font-bold active:scale-[0.98] transition-all"
                      >
                        <div className="flex items-center space-x-2.5">
                          <div className="w-8 h-8 rounded-lg bg-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0">
                            <Sparkles className="w-4 h-4" />
                          </div>
                          <div className="text-left">
                            <div className="text-white text-xs font-bold">Fix Trực Tiếp (Không Cần Bật Gỡ Lỗi)</div>
                            <div className="text-[10px] text-emerald-300 font-normal">Mã lệnh USSD &amp; Cài đặt hệ thống 1-chạm</div>
                          </div>
                        </div>
                        <ChevronRight className="w-4 h-4 text-emerald-400 shrink-0" />
                      </button>
                    </div>
                    <div className="text-[10px] text-slate-400 text-center font-mono pt-0.5">
                      💡 Muốn dùng cáp USB? Hãy mở trang web trên Máy Tính (PC/Laptop).
                    </div>
                  </div>
                )}

                {/* DANH SÁCH MENU CHỨC NĂNG TRÊN ĐIỆN THOẠI - THIẾT KẾ 1 CỘT RỘNG RÃI, KHÔNG TRÀN MÀN HÌNH */}
                <div className="space-y-2">
                  {/* Thanh Thông Báo Lọc Thông Minh Trên Mobile */}
                  {currentBrandId !== 'all' && (
                    <div className="p-3 rounded-2xl bg-gradient-to-r from-cyan-950/40 via-[#111A2E] to-blue-950/30 border border-cyan-500/30 text-xs space-y-2 shadow-md">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2 min-w-0">
                          <Sparkles className="w-3.5 h-3.5 text-[#00F0FF] shrink-0" />
                          <span className="text-[11px] font-bold text-white truncate">
                            {isConnected ? 'Thiết Bị Đã Kết Nối:' : 'Thiết Bị Của Bạn:'}{' '}
                            <span className={`font-black ${brandMetadata.color}`}>{brandMetadata.name}</span>
                          </span>
                        </div>
                        <span className="text-[9px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-mono font-bold shrink-0">
                          {showAllModules ? 'Tất cả' : 'Đã lọc'}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-cyan-500/15">
                        <span>{showAllModules ? 'Hiện toàn bộ công cụ' : `Chỉ hiện ${visibleTabs.length} tính năng cho máy này`}</span>
                        <button
                          onClick={() => setShowAllModules(!showAllModules)}
                          className="text-[#00F0FF] font-bold underline"
                        >
                          {showAllModules ? 'Chỉ hiện máy này' : 'Hiện tất cả'}
                        </button>
                      </div>
                    </div>
                  )}

                  <div className="flex items-center justify-between px-1 text-[11px] text-slate-400 font-semibold">
                    <span>{visibleTabs.length} Danh Mục Chức Năng (1 Cột)</span>
                    <span className="text-cyan-400 font-mono text-[10px]">
                      {visibleTabs.find((t) => t.id === activeTab)?.label}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 gap-2 py-0.5">
                    {visibleTabs.map((tab) => {
                      const Icon = tab.icon;
                      const isActive = activeTab === tab.id;
                      return (
                        <div key={tab.id} className="space-y-1.5">
                          <button
                            onClick={() => setActiveTab(tab.id as any)}
                            className={`w-full flex items-center justify-between p-2.5 rounded-xl text-xs font-bold transition-all border ${
                              isActive
                                ? 'bg-gradient-to-r from-[#00F0FF] to-blue-500 text-black border-cyan-300 shadow-md shadow-cyan-500/25 ring-1 ring-cyan-300'
                                : 'bg-[#111A2E]/90 text-slate-200 border-slate-700/80 hover:border-cyan-500/40 hover:bg-[#16223d]'
                            }`}
                          >
                            <div className="flex items-center space-x-2.5 min-w-0">
                              <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${isActive ? 'bg-black/20 text-black' : 'bg-cyan-500/10 text-cyan-400'}`}>
                                <Icon className="w-4 h-4" />
                              </div>
                              <div className="text-left min-w-0">
                                <div className="truncate text-xs font-bold leading-tight">{tab.label}</div>
                                <div className={`text-[10px] truncate ${isActive ? 'text-black/80 font-medium' : 'text-slate-400'}`}>
                                  {tab.shortLabel}
                                </div>
                              </div>
                            </div>
                            <div className="flex items-center space-x-1.5 shrink-0 ml-2">
                              <span className={`text-[10px] px-2 py-0.5 rounded-md font-mono ${isActive ? 'bg-black/20 text-black font-semibold' : 'bg-slate-800 text-cyan-300 border border-slate-700'}`}>
                                {tab.badge}
                              </span>
                              <ChevronRight className={`w-3.5 h-3.5 transition-transform duration-200 ${isActive ? 'rotate-90 text-black' : 'text-slate-500'}`} />
                            </div>
                          </button>

                          {/* Khi tab này đang chọn: hiển thị nội dung module ngay bên dưới (Accordion 1 cột tiện lợi) */}
                          {isActive && (
                            <div className="pt-1 pb-2">
                              {renderActiveModule()}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* TAB 2: THIẾT BỊ (DEVICE) */}
            {mobileNavTab === 'device' && (
              <div className="space-y-3.5">
                <DeviceInfoCard
                  profiler={profiler}
                  isConnected={isConnected}
                  onRefresh={runAutoInspector}
                  isInspecting={isInspecting}
                  onOpenGuide={() => setIsGuideOpen(true)}
                  supportedAndroidRange={settings.androidSupport?.supportedAndroidRange}
                  onSelectTab={(tabId) => {
                    setActiveTab(tabId);
                    setMobileNavTab('tools');
                  }}
                />

                {/* Shizuku Card */}
                <div className="p-4 rounded-2xl bg-gradient-to-br from-purple-950/30 to-[#111A2E] border border-purple-500/20 text-xs">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2 text-purple-300 font-bold">
                      <Radio className="w-4 h-4" />
                      <span>Cầu Nối Shizuku Engine</span>
                    </div>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 font-mono">
                      Sẵn sàng
                    </span>
                  </div>
                  <p className="text-slate-400 text-[11px] leading-relaxed mb-3">
                    Khởi động Shizuku Server để tự động thực thi các quyền hạn cấp cao ngay trên máy không cần cắm lại cáp máy tính.
                  </p>
                  <button
                    onClick={() => { setActiveTab('shizuku'); setMobileNavTab('tools'); }}
                    className="w-full py-2 rounded-xl bg-purple-600/25 hover:bg-purple-600/35 text-purple-200 border border-purple-500/30 text-xs font-bold flex items-center justify-center space-x-1 transition-all"
                  >
                    <span>Mở Cầu Nối Shizuku</span>
                  </button>
                </div>
              </div>
            )}

            {/* TAB 3: TERMINAL */}
            {mobileNavTab === 'terminal' && (
              <div className="space-y-3.5">
                <AdbConsole isAdmin={isAdminUser} className="shadow-none border-cyan-500/30" />
              </div>
            )}

            {/* TAB 4: TIỆN ÍCH / MENU */}
            {mobileNavTab === 'menu' && (
              <div className="space-y-3">
                {/* Thẻ Thông Tin 100% Miễn Phí Mã Nguồn Mở */}
                <div className="p-4 rounded-2xl bg-gradient-to-r from-[#111A2E]/95 via-[#0D182E]/90 to-[#111A2E]/95 border border-emerald-500/30 flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                      <Sparkles className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-sm font-bold text-white flex items-center gap-1.5">
                        <span>MagicTune WebADB</span>
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono font-bold">100% Free</span>
                      </div>
                      <div className="text-[11px] text-slate-400">
                        Mã nguồn mở GitHub • Hoàn toàn miễn phí, không cần đăng nhập
                      </div>
                    </div>
                  </div>
                  <a
                    href={settings.magicTuneGithubApkUrl || DEFAULT_APP_SETTINGS.magicTuneGithubApkUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-bold flex items-center gap-1"
                  >
                    <span>GitHub</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>

                {/* Settings list items */}
                <div className="rounded-2xl bg-[#111A2E]/90 border border-cyan-500/20 divide-y divide-slate-800/80 overflow-hidden text-xs font-medium">
                  <button
                    onClick={toggleTheme}
                    className="w-full p-3.5 flex items-center justify-between text-left hover:bg-slate-800/50 transition-colors"
                  >
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center">
                        {theme === 'light' ? <Moon className="w-4 h-4 text-amber-600" /> : <Sun className="w-4 h-4 text-amber-400" />}
                      </div>
                      <span className="text-slate-200">Giao diện (Sáng / Tối)</span>
                    </div>
                    <span className="text-[11px] text-cyan-400 font-semibold font-mono">
                      {theme === 'light' ? 'Nền Sáng' : 'Nền Tối Cyber'}
                    </span>
                  </button>

                  <button
                    onClick={() => setIsGuideOpen(true)}
                    className="w-full p-3.5 flex items-center justify-between text-left hover:bg-slate-800/50 transition-colors"
                  >
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 rounded-xl bg-cyan-500/10 text-[#00F0FF] flex items-center justify-center">
                        <HelpCircle className="w-4 h-4" />
                      </div>
                      <span className="text-slate-200">Hướng Dẫn Kết Nối Từng Bước</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-500" />
                  </button>

                  <button
                    onClick={() => setIsSupportModalOpen(true)}
                    className="w-full p-3.5 flex items-center justify-between text-left hover:bg-slate-800/50 transition-colors"
                  >
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 rounded-xl bg-purple-500/10 text-purple-400 flex items-center justify-center">
                        <MessageSquare className="w-4 h-4" />
                      </div>
                      <span className="text-slate-200">Trợ Lý AI &amp; Hỗ Trợ Kỹ Thuật</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-500" />
                  </button>

                  {effectiveIsAdmin && (
                    <>
                      <Link
                        href="/admin"
                        className="w-full p-3.5 flex items-center justify-between text-left hover:bg-slate-800/50 transition-colors"
                      >
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-300 flex items-center justify-center">
                            <ShieldCheck className="w-4 h-4 text-amber-400" />
                          </div>
                          <span className="text-amber-300 font-bold">Bảng Quản Trị Hệ Thống (/admin)</span>
                        </div>
                        <ChevronRight className="w-4 h-4 text-slate-500" />
                      </Link>

                      <button
                        onClick={() => {
                          setIsPreviewAsUser(true);
                          setPreviewRole('guest');
                          setMobileMenuOpen(false);
                        }}
                        className="w-full p-3.5 flex items-center justify-between text-left hover:bg-slate-800/50 transition-colors"
                      >
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-300 flex items-center justify-center">
                            <Eye className="w-4 h-4 text-[#00F0FF]" />
                          </div>
                          <span className="text-cyan-300 font-bold">Xem UI Khách Hàng (Mô Phỏng)</span>
                        </div>
                        <ChevronRight className="w-4 h-4 text-slate-500" />
                      </button>
                    </>
                  )}
                </div>

                {/* Download APK and Share */}
                <div className="grid grid-cols-2 gap-2.5 pt-1">
                  <button
                    onClick={() => setIsApkConfirmModalOpen(true)}
                    className="w-full py-2.5 px-3 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/40 text-xs font-bold transition-all flex items-center justify-center space-x-1.5 active:scale-95"
                  >
                    <Smartphone className="w-4 h-4 text-emerald-400" />
                    <span>Cài App APK</span>
                  </button>
                  <QuickShareButton fullWidth />
                </div>

                {/* Version & Info Card */}
                <div className="p-3.5 rounded-2xl bg-[#0A0F1D]/80 border border-slate-800 text-[11px] text-slate-400 text-center space-y-1">
                  <div className="font-bold text-slate-300">{settings.appName} {APP_RELEASE_VERSION} Universal</div>
                  <div>WebADB Toolkit for Modern Android</div>
                </div>

                {/* Knowledge Hub on Mobile Menu */}
                <KnowledgeHubSection />
              </div>
            )}

            {/* Khoảng đệm đáy an toàn trên Mobile */}
            <div
              className={
                isMobileDevice && settings.footer?.showFooter === false
                  ? 'h-28 w-full shrink-0'
                  : 'h-4 w-full shrink-0'
              }
              aria-hidden="true"
            />
          </div>
        </main>

        {/* NATIVE MOBILE BOTTOM NAVIGATION BAR (Chỉ hiển thị trên thiết bị Di Động) */}
        {isMobileDevice && (
          <nav className="fixed bottom-0 left-0 right-0 z-50 border-t pb-safe bg-[#0A0F1D]/95 border-cyan-500/20 text-slate-400 shadow-[0_-4px_25px_rgba(0,0,0,0.5)] backdrop-blur-2xl">
            <div className="grid grid-cols-4 h-16 max-w-lg mx-auto px-2">
              {/* Tab 1: Công Cụ */}
              <button
                onClick={() => setMobileNavTab('tools')}
                className={`flex flex-col items-center justify-center space-y-1 transition-all ${
                  mobileNavTab === 'tools'
                    ? 'text-[#00F0FF] font-extrabold'
                    : 'text-slate-400 hover:text-slate-200 font-medium'
                }`}
              >
                <div className={`p-1 rounded-xl transition-all ${
                  mobileNavTab === 'tools' ? 'bg-cyan-500/15' : ''
                }`}>
                  <Zap className="w-5 h-5" />
                </div>
                <span className="text-[10px] tracking-tight">Công Cụ</span>
              </button>

              {/* Tab 2: Thiết Bị */}
              <button
                onClick={() => setMobileNavTab('device')}
                className={`flex flex-col items-center justify-center space-y-1 transition-all ${
                  mobileNavTab === 'device'
                    ? 'text-[#00F0FF] font-extrabold'
                    : 'text-slate-400 hover:text-slate-200 font-medium'
                }`}
              >
                <div className={`p-1 rounded-xl transition-all ${
                  mobileNavTab === 'device' ? 'bg-cyan-500/15' : ''
                }`}>
                  <Smartphone className="w-5 h-5" />
                </div>
                <span className="text-[10px] tracking-tight">Thiết Bị</span>
              </button>

              {/* Tab 3: Terminal */}
              <button
                onClick={() => setMobileNavTab('terminal')}
                className={`flex flex-col items-center justify-center space-y-1 transition-all ${
                  mobileNavTab === 'terminal'
                    ? 'text-[#00F0FF] font-extrabold'
                    : 'text-slate-400 hover:text-slate-200 font-medium'
                }`}
              >
                <div className={`p-1 rounded-xl transition-all ${
                  mobileNavTab === 'terminal' ? 'bg-cyan-500/15' : ''
                }`}>
                  <Terminal className="w-5 h-5" />
                </div>
                <span className="text-[10px] tracking-tight">Terminal</span>
              </button>

              {/* Tab 4: Tiện Ích */}
              <button
                onClick={() => setMobileNavTab('menu')}
                className={`flex flex-col items-center justify-center space-y-1 transition-all ${
                  mobileNavTab === 'menu'
                    ? 'text-[#00F0FF] font-extrabold'
                    : 'text-slate-400 hover:text-slate-200 font-medium'
                }`}
              >
                <div className={`p-1 rounded-xl transition-all ${
                  mobileNavTab === 'menu' ? 'bg-cyan-500/15' : ''
                }`}>
                  <Menu className="w-5 h-5" />
                </div>
                <span className="text-[10px] tracking-tight">Tiện Ích</span>
              </button>
            </div>
          </nav>
        )}

        {/* Footer: Hiển thị trên cả Desktop, Tablet và Mobile để đảm bảo minh bạch thông tin & chính sách AdSense */}
        {settings.footer?.showFooter !== false && (
          <footer className={`border-t py-6 sm:py-8 ${isMobileDevice ? 'pb-28 mt-6' : 'mt-12'} transition-colors duration-200 ${
            theme === 'light'
              ? 'border-slate-200 bg-white text-slate-600'
              : 'border-cyan-500/15 bg-[#070B16] text-slate-400'
          }`}>
            <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 space-y-4">
              <div className={`flex flex-col md:flex-row items-center justify-between gap-3 text-xs pb-4 border-b ${
                theme === 'light' ? 'border-slate-200' : 'border-slate-800/80'
              }`}>
                <div className="flex items-center space-x-2 text-center md:text-left">
                  <span className={`font-bold tracking-wide ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>
                    {(settings.footer?.customCopyrightText || `${settings.appName} — ${settings.appDomain || 'magictune.web.app'}`).replace(/magictune\.app/g, settings.appDomain && settings.appDomain !== 'magictune.app' ? settings.appDomain : currentHost)}
                  </span>
                </div>

                {/* Liên kết chính sách bắt buộc chuẩn Google AdSense */}
                <nav aria-label="Thông tin và chính sách website" className="flex flex-wrap items-center justify-center gap-x-4 gap-y-2 text-[11px] font-semibold">
<Link href="/about" className={`hover:underline ${theme === 'light' ? 'text-slate-700 hover:text-cyan-700' : 'text-slate-300 hover:text-[#00F0FF]'}`}>
                    Giới Thiệu
                  </Link>
                  <Link href="/privacy" className={`hover:underline ${theme === 'light' ? 'text-slate-700 hover:text-cyan-700' : 'text-slate-300 hover:text-[#00F0FF]'}`}>
                    Chính Sách Bảo Mật
                  </Link>
                  <Link href="/terms" className={`hover:underline ${theme === 'light' ? 'text-slate-700 hover:text-cyan-700' : 'text-slate-300 hover:text-[#00F0FF]'}`}>
                    Điều Khoản Sử Dụng
                  </Link>
                  <Link href="/contact" className={`hover:underline ${theme === 'light' ? 'text-slate-700 hover:text-cyan-700' : 'text-slate-300 hover:text-[#00F0FF]'}`}>
                    Liên Hệ
                  </Link>
                  <Link href="/admin" className={`hover:underline ${theme === 'light' ? 'text-slate-700 hover:text-cyan-700' : 'text-slate-300 hover:text-[#00F0FF]'}`}>
                    Quản Trị
                  </Link>
                </nav>

                <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 text-[11px]">
                  <span className={theme === 'light' ? 'text-blue-600 font-semibold' : 'text-[#00F0FF]'}>PWA Ngoại Tuyến</span>
                  <span>•</span>
                  <span className={theme === 'light' ? 'text-purple-600 font-semibold' : 'text-[#8B5CF6]'}>Shizuku [Xingchen &amp; Rikka]</span>
                  <span>•</span>
                  <span>{settings.footer?.contactInfo || 'Tài khoản: contact@magictune.web.app'}</span>
                </div>
              </div>

              {settings.footer?.showDisclaimer !== false && (
                <div className={`rounded-xl p-4 text-[11px] leading-relaxed border ${
                  theme === 'light'
                    ? 'bg-slate-50 border-slate-200 text-slate-500'
                    : 'bg-[#0A0F1D] border-slate-800/90 text-slate-400'
                }`}>
                  <p className={`font-semibold mb-1 ${theme === 'light' ? 'text-slate-700' : 'text-slate-300'}`}>
                    Tuyên bố miễn trừ trách nhiệm (Legal Disclaimer):
                  </p>
                  <p className="italic">
                    {settings.footer?.customDisclaimerText ||
                      `${settings.appName} là dự án mã nguồn mở phi lợi nhuận do cộng đồng người dùng phát triển nhằm mục đích hỗ trợ kỹ thuật và tối ưu hóa trải nghiệm thiết bị. ${settings.appName} hoàn toàn độc lập, không trực thuộc, không được ủy quyền, tài trợ hoặc có bất kỳ liên kết chính thức nào với Honor Device Co., Ltd hay tập đoàn Huawei.`}
                  </p>
                </div>
              )}
            </div>
          </footer>
        )}



        {/* Modal Hướng dẫn kết nối cho người mới / người lớn tuổi */}
        <ConnectionGuideModal
          isOpen={isGuideOpen}
          onClose={() => setIsGuideOpen(false)}
        />

        {/* Hệ thống 100% miễn phí không cần đăng nhập hay thanh toán VIP */}

        {/* Modal Hỗ Trợ Đa Kênh: Chat AI Nội Bộ & Gặp Trực Tiếp Admin */}
        <SupportChatModal
          isOpen={isSupportModalOpen}
          onClose={() => setIsSupportModalOpen(false)}
          adminContact={{
            email: settings.adminList?.[0] || 'contact@magictune.web.app',
            phone: settings.monetization?.bankInfo?.accountNumber || '0123456789'
          }}
          isMonetizationEnabled={settings.monetization?.enabled === true}
          showAdminTab={settings.showSupportAdminTab !== false}
        />

        {/* Dialog Xác Nhận Mở Link Tải MagicTune Tool APK */}
        {isApkConfirmModalOpen && (
          <div role="dialog" aria-modal="true" aria-label="Tải MagicTune Tool APK" className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
            <div className="w-full max-w-md rounded-3xl bg-[#0D1629] border border-emerald-500/40 shadow-2xl shadow-emerald-500/20 p-5 sm:p-6 space-y-4">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center space-x-3">
                  <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-emerald-400 to-cyan-500 p-0.5 shrink-0 shadow-lg shadow-emerald-500/25">
                    <div className="w-full h-full rounded-[14px] bg-[#0A0F1D] flex items-center justify-center">
                      <Smartphone className="w-5 h-5 text-emerald-400" />
                    </div>
                  </div>
                  <div>
                    <h3 className="text-base font-black text-white">Tải MagicTune Tool APK</h3>
                    <span className="inline-block mt-0.5 text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold">
                      Dùng Thử Miễn Phí Trên Android
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => setIsApkConfirmModalOpen(false)}
                  aria-label="Đóng hộp thoại tải APK"
                  className="p-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-all"
                  title="Đóng"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="p-3.5 rounded-2xl bg-[#0A0F1D] border border-slate-800 space-y-2.5 text-xs text-slate-300 leading-relaxed">
                <p>
                  Chọn nguồn tải file cài đặt <strong className="text-white">MagicTune Tool APK</strong> dành cho điện thoại Android &amp; Honor:
                </p>
                <div className="space-y-1.5">
                  <div className="p-2 rounded-xl bg-slate-900/90 border border-emerald-500/30 text-[11px] font-mono text-emerald-300 break-all">
                    <span className="font-sans font-bold text-slate-400 mr-1.5">Google Drive:</span>
                    {settings.magicTuneApkUrl || DEFAULT_APP_SETTINGS.magicTuneApkUrl}
                  </div>
                  <div className="p-2 rounded-xl bg-slate-900/90 border border-cyan-500/30 text-[11px] font-mono text-cyan-300 break-all">
                    <span className="font-sans font-bold text-slate-400 mr-1.5">GitHub Releases:</span>
                    {settings.magicTuneGithubApkUrl || DEFAULT_APP_SETTINGS.magicTuneGithubApkUrl}
                  </div>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row sm:items-center justify-end gap-2 pt-1">
                <button
                  onClick={() => setIsApkConfirmModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-all order-3 sm:order-1"
                >
                  Hủy Bỏ
                </button>
                <a
                  href={settings.magicTuneGithubApkUrl || DEFAULT_APP_SETTINGS.magicTuneGithubApkUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => setIsApkConfirmModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-[#111A2E] hover:bg-slate-800 text-white border border-cyan-500/40 font-black text-xs flex items-center justify-center space-x-2 transition-all active:scale-95 order-2"
                >
                  <svg className="w-4 h-4 fill-current shrink-0" viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M12 .5C5.65.5.5 5.65.5 12c0 5.08 3.29 9.39 7.86 10.91.58.1.79-.25.79-.56 0-.28-.01-1.02-.02-2-3.2.7-3.88-1.54-3.88-1.54-.52-1.33-1.28-1.69-1.28-1.69-1.05-.72.08-.7.08-.7 1.16.08 1.77 1.19 1.77 1.19 1.03 1.76 2.7 1.25 3.36.96.1-.75.4-1.25.73-1.54-2.55-.29-5.24-1.28-5.24-5.68 0-1.26.45-2.28 1.19-3.09-.12-.29-.52-1.46.11-3.05 0 0 .97-.31 3.18 1.18a11.05 11.05 0 0 1 5.79 0c2.21-1.49 3.18-1.18 3.18-1.18.63 1.59.23 2.76.11 3.05.74.81 1.19 1.83 1.19 3.09 0 4.41-2.69 5.39-5.25 5.67.41.36.78 1.06.78 2.14 0 1.54-.01 2.79-.01 3.17 0 .31.21.67.8.56A11.51 11.51 0 0 0 23.5 12C23.5 5.65 18.35.5 12 .5z" />
                  </svg>
                  <span>Tải Từ GitHub</span>
                </a>
                <a
                  href={settings.magicTuneApkUrl || DEFAULT_APP_SETTINGS.magicTuneApkUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => setIsApkConfirmModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 font-black text-xs shadow-lg shadow-emerald-500/25 flex items-center justify-center space-x-2 transition-all active:scale-95 order-1 sm:order-3"
                >
                  <UploadCloud className="w-4 h-4 rotate-180 shrink-0" />
                  <span>Tải Google Drive</span>
                </a>
              </div>
            </div>
          </div>
        )}

        {/* Nút Cuộn Nhanh Lên Đầu Trang (Global Smooth Scroll) */}
        <ScrollToTop />
      </div>
    </>
  );
}
