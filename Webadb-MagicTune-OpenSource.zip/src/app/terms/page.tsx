import type { Metadata } from 'next';
import { PolicyPageLayout } from '@/components/common/PolicyPageLayout';

export const metadata: Metadata = {
  title: 'Điều Khoản Sử Dụng (Terms of Service) | MagicTune',
  description:
    'Điều khoản sử dụng, phạm vi hỗ trợ kỹ thuật, quyền sở hữu trí tuệ và tuyên bố miễn trừ trách nhiệm khi sử dụng công cụ WebADB MagicTune.',
  alternates: {
    canonical: 'https://magictune.web.app/terms/',
  },
};

export default function TermsOfServicePage() {
  return (
    <PolicyPageLayout
      title="Điều Khoản Sử Dụng (Terms of Service)"
      subtitle="Cập nhật lần cuối: 26/11/2026 • Quy định sử dụng dịch vụ và tài liệu kỹ thuật trên https://magictune.web.app."
      activePath="/terms/"
    >
      <section className="space-y-2">
        <h2 className="text-lg font-bold text-white">1. Chấp thuận điều khoản</h2>
        <p>
          Khi truy cập và sử dụng website <span className="font-mono text-cyan-400">https://magictune.web.app</span>, bạn xác nhận đã đọc, hiểu và đồng ý tuân thủ các điều khoản sử dụng dưới đây. Nếu bạn không đồng ý với bất kỳ nội dung nào, vui lòng ngừng sử dụng công cụ.
        </p>
      </section>

      <section className="space-y-2">
        <h2 className="text-lg font-bold text-white">2. Mục đích và phạm vi sử dụng hợp pháp</h2>
        <p>
          MagicTune là bộ công cụ kỹ thuật dựa trên giao thức Android Debug Bridge (ADB) và WebUSB API nhằm hỗ trợ người dùng cá nhân tối ưu hóa trải nghiệm hệ điều hành Android hợp pháp trên thiết bị thuộc quyền sở hữu của mình (khắc phục trễ thông báo, điều chỉnh DPI, kích hoạt Shizuku, gỡ ứng dụng rác không cần thiết).
        </p>
        <p>
          Người dùng <strong>nghiêm cấm</strong> sử dụng tài liệu hoặc công cụ vào mục đích xâm nhập trái phép, can thiệp thiết bị không thuộc quyền sở hữu hoặc vi phạm pháp luật hiện hành.
        </p>
      </section>

      <section className="space-y-2">
        <h2 className="text-lg font-bold text-white">3. Trách nhiệm sao lưu và thao tác kỹ thuật</h2>
        <ul className="list-disc list-inside space-y-1.5 text-slate-300">
          <li>
            Trước khi thực hiện các tùy chỉnh sâu (gỡ ứng dụng hệ thống hoặc thay đổi tham số hiển thị), người dùng nên đọc kỹ mô tả từng mục và sao lưu dữ liệu quan trọng nếu cần thiết.
          </li>
          <li>
            Việc cấp quyền <em>Gỡ lỗi USB (USB Debugging)</em> trên điện thoại hoàn toàn do người dùng tự quyết định và xác nhận trực tiếp trên màn hình thiết bị.
          </li>
        </ul>
      </section>

      <section className="space-y-2">
        <h2 className="text-lg font-bold text-white">4. Tuyên bố độc lập và miễn trừ trách nhiệm</h2>
        <p>
          MagicTune là dự án cộng đồng hoạt động độc lập, không trực thuộc, không được tài trợ, ủy quyền hay liên kết chính thức với Google LLC, Honor Device Co., Ltd, Huawei, Xiaomi, Samsung, OPPO hay vivo. Mọi nhãn hiệu thiết bị và hệ điều hành được nhắc đến chỉ nhằm mục đích mô tả tính tương thích kỹ thuật.
        </p>
        <p>
          Công cụ được cung cấp theo nguyên trạng (&ldquo;as is&rdquo;). Ban quản trị không chịu trách nhiệm đối với bất kỳ thiệt hại gián tiếp nào phát sinh từ việc người dùng tự ý thay đổi cấu hình vượt ngoài hướng dẫn.
        </p>
      </section>

      <section className="space-y-2">
        <h2 className="text-lg font-bold text-white">5. Thay đổi điều khoản &amp; Liên hệ</h2>
        <p>
          Chúng tôi có thể cập nhật Điều khoản Sử dụng định kỳ để phù hợp với quy định pháp luật và cập nhật kỹ thuật Android mới. Mọi góp ý hoặc báo cáo vi phạm bản quyền vui lòng gửi về{' '}
          <a
            href="mailto:contact@magictune.web.app"
            className="text-cyan-400 underline hover:text-cyan-300 font-semibold"
          >
            contact@magictune.web.app
          </a>
          .
        </p>
      </section>
    </PolicyPageLayout>
  );
}
