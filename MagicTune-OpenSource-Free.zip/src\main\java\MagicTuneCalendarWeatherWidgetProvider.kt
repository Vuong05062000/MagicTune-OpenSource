package com.example.core.widget
import com.example.core.i18n.AppLanguageManager.tr

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.view.View
import android.widget.RemoteViews
import android.widget.Toast
import com.example.MainActivity
import com.example.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MagicTuneCalendarWeatherWidgetProvider : AppWidgetProvider() {

    override fun onAppWidgetOptionsChanged(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: android.os.Bundle?) {
        super.onAppWidgetOptionsChanged(context, appWidgetManager, appWidgetId, newOptions)
        updateWidget(context, appWidgetManager, appWidgetId)
    }

    companion object {
        const val ACTION_CALENDAR_WEATHER_REFRESH = "com.example.core.widget.ACTION_CALENDAR_WEATHER_REFRESH"
        const val ACTION_WEATHER_24H_NEXT = "com.example.core.widget.ACTION_WEATHER_24H_NEXT"
        const val ACTION_WEATHER_24H_PREV = "com.example.core.widget.ACTION_WEATHER_24H_PREV"
        const val ACTION_WEATHER_7D_NEXT = "com.example.core.widget.ACTION_WEATHER_7D_NEXT"
        const val ACTION_WEATHER_7D_PREV = "com.example.core.widget.ACTION_WEATHER_7D_PREV"
        const val ACTION_WEATHER_RESET_SCROLL = "com.example.core.widget.ACTION_WEATHER_RESET_SCROLL"
        const val ACTION_WEATHER_TOGGLE_MODE = "com.example.core.widget.ACTION_WEATHER_TOGGLE_MODE"
        const val ACTION_WEATHER_WIDGET_NOOP = "com.example.core.widget.ACTION_WEATHER_WIDGET_NOOP"

        private const val PREFS_NAME = VietnamClimateEngine.PREFS_NAME
        private const val KEY_SELECTED_LOCATION = VietnamClimateEngine.KEY_LOCATION
        private const val KEY_PAGE_24H = "forecast_page_24h"
        private const val KEY_PAGE_7D = "forecast_page_7d"
        private const val KEY_WIDGET_CLOCK_MODE = "widget_weather_clock_mode"

        private const val EXTRA_MANUAL_REFRESH = "extra_manual_refresh"

        private val widgetSyncScope = CoroutineScope(kotlinx.coroutines.SupervisorJob() + Dispatchers.IO)

        private var lastAutoLocation: String? = null
        private var lastAutoAttemptMs = 0L

        @Synchronized
        private fun reserveAutoFetch(context: Context, location: String, maxAgeMs: Long): Boolean {
            val now = android.os.SystemClock.elapsedRealtime()
            if (location == lastAutoLocation && now - lastAutoAttemptMs < 5 * 60_000L) return false
            if (!VietnamClimateEngine.isWeatherCacheStale(context, location, maxAgeMs)) return false
            lastAutoLocation = location
            lastAutoAttemptMs = now
            return true
        }

        /**
         * Được gọi trực tiếp từ bên trong ứng dụng ngay khi người dùng chọn khu vực mới:
         * 1. Cập nhật ngay lập tức tên khu vực trên toàn bộ Widget (0ms)
         * 2. Chạy ngầm không thể hủy (SupervisorJob) để lấy thời tiết thực tế mới nhất của đúng khu vực vừa chọn
         * 3. Ngay khi có nhiệt độ thực tế từ API, đẩy trực tiếp lên toàn bộ Widget ngoài màn hình chính & đồng bộ vào App
         */
        fun syncNewLocationWeatherNow(
            context: Context,
            newLocation: String,
            onSynced: ((VietnamClimateEngine.WeatherResult) -> Unit)? = null
        ) {
            val appCtx = context.applicationContext ?: context
            try {
                appCtx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    .edit()
                    .putString(KEY_SELECTED_LOCATION, newLocation)
                    .putInt(KEY_PAGE_24H, 0)
                    .putInt(KEY_PAGE_7D, 0)
                    .apply()
            } catch (_: Throwable) {}

            // Bước 1: Cập nhật ngay tên khu vực vừa chọn lên Widget
            try {
                val awm = AppWidgetManager.getInstance(appCtx)
                val cn = ComponentName(appCtx, MagicTuneCalendarWeatherWidgetProvider::class.java)
                val ids = awm.getAppWidgetIds(cn)
                for (id in ids) {
                    updateWidget(appCtx, awm, id)
                }
            } catch (_: Throwable) {}

            // Bước 2: Chạy ngầm tải thời tiết thực tế mới nhất của khu vực vừa chọn & đẩy thẳng lên Widget
            widgetSyncScope.launch {
                try {
                    val live = VietnamClimateEngine.fetchLiveWeatherAsync(appCtx, newLocation)
                    val awm = AppWidgetManager.getInstance(appCtx)
                    val cn = ComponentName(appCtx, MagicTuneCalendarWeatherWidgetProvider::class.java)
                    val ids = awm.getAppWidgetIds(cn)
                    for (id in ids) {
                        updateWidget(appCtx, awm, id)
                    }
                    if (onSynced != null) {
                        kotlinx.coroutines.withContext(Dispatchers.Main) {
                            onSynced(live)
                        }
                    }
                } catch (_: Throwable) {}
            }
        }

        /**
         * Được gọi trực tiếp từ bên trong ứng dụng ngay khi người dùng chọn khu vực mới
         * để cập nhật tức thì toàn bộ widget bên ngoài màn hình chính.
         */
        fun notifyWidgetUpdate(context: Context, triggerNetworkSync: Boolean = true) {
            val appCtx = context.applicationContext ?: context
            try {
                val awm = AppWidgetManager.getInstance(appCtx)
                val cn = ComponentName(appCtx, MagicTuneCalendarWeatherWidgetProvider::class.java)
                val ids = awm.getAppWidgetIds(cn)
                for (id in ids) {
                    updateWidget(appCtx, awm, id)
                }
                if (triggerNetworkSync && ids.isNotEmpty()) {
                    val loc = getSelectedLocation(appCtx)
                    widgetSyncScope.launch {
                        try {
                            // SIÊU TIẾT KIỆM ĐIỆN CHO WIDGET: Chỉ tải mạng khi cache đã quá 30 phút, tiêu thụ dòng điện cực nhỏ
                            if (reserveAutoFetch(appCtx, loc, maxAgeMs = 30 * 60_000L)) {
                                VietnamClimateEngine.fetchLiveWeatherAsync(appCtx, loc)
                                val awmAfter = AppWidgetManager.getInstance(appCtx)
                                val idsAfter = awmAfter.getAppWidgetIds(ComponentName(appCtx, MagicTuneCalendarWeatherWidgetProvider::class.java))
                                for (id in idsAfter) {
                                    updateWidget(appCtx, awmAfter, id)
                                }
                            }
                        } catch (_: Throwable) {}
                    }
                }
            } catch (_: Throwable) {}
        }

        private fun getDistinctSkyClarityIcon(icon: String, condition: String): String {
            return when {
                icon == "🌙" -> "🌌"
                icon == "☀️" -> "🌤️"
                icon == "🌤️" -> "⛅"
                condition.contains("quang", ignoreCase = true) && icon == "🌙" -> "🌌"
                condition.contains("quang", ignoreCase = true) -> "🌤️"
                else -> icon
            }
        }

        private const val KEY_SHOW_LOCATION = "custom_show_location"
        private const val KEY_SHOW_SOLAR_DATE = "custom_show_solar_date"
        private const val KEY_SHOW_LUNAR_DATE = "custom_show_lunar_date"
        private const val KEY_SHOW_LUNAR_CAN_CHI = "custom_show_lunar_can_chi"
        private const val KEY_SHOW_CLOCK_SECONDS = "custom_show_clock_seconds"
        private const val KEY_SHOW_WEATHER_CONDITION = "custom_show_weather_condition"
        private const val KEY_SHOW_RAIN_PERCENT = "custom_show_rain_percent"
        private const val KEY_SHOW_WEATHER_SUB = "custom_show_weather_sub"
        private const val KEY_SHOW_HOURLY_24H = "custom_show_hourly_24h"
        private const val KEY_SHOW_DAILY_7D = "custom_show_daily_7d"
        private const val KEY_SHOW_CLOCK_7DAY_STRIP = "custom_show_clock_7day_strip"

        private const val KEY_SCALE_CLOCK_PCT = "custom_scale_clock_pct"
        private const val KEY_SCALE_TEMP_PCT = "custom_scale_temp_pct"
        private const val KEY_SCALE_DATE_LUNAR_PCT = "custom_scale_date_lunar_pct"
        private const val KEY_SCALE_WEATHER_INFO_PCT = "custom_scale_weather_info_pct"
        private const val KEY_SCALE_FORECAST_STRIP_PCT = "custom_scale_forecast_strip_pct"
        private const val KEY_SCALE_OVERALL_GLOBAL_PCT = "custom_scale_overall_global_pct"
        private const val KEY_SCALE_CLOCK_SECONDS_PCT = "custom_scale_clock_seconds_pct"
        private const val KEY_SCALE_LUNAR_CAN_CHI_PCT = "custom_scale_lunar_can_chi_pct"
        private const val KEY_SCALE_WEATHER_SUB_PCT = "custom_scale_weather_sub_pct"
        private const val KEY_SHOW_CLOCK_BACKGROUND = "custom_show_clock_background"
        private const val KEY_CLOCK_FONT_FAMILY = "custom_clock_font_family"

        @androidx.compose.runtime.Immutable
        data class WeatherWidgetCustomConfig(
            val showClockBackground: Boolean = true,
            val clockFontFamily: String = "DEFAULT",
            val showLocation: Boolean = true,
            val showSolarDate: Boolean = true,
            val showLunarDate: Boolean = true,
            val showLunarCanChi: Boolean = false,
            // Seconds repaint the launcher widget every second. Keep the default at minute
            // precision; users who explicitly enabled seconds retain that saved preference.
            val showClockSeconds: Boolean = false,
            val showWeatherCondition: Boolean = true,
            val showRainPercent: Boolean = true,
            val showWeatherSubDetails: Boolean = false,
            val showHourly24h: Boolean = true,
            val showDaily7d: Boolean = false,
            val showClock7DayStrip: Boolean = false,
            val clockScalePct: Int = 150,
            val tempScalePct: Int = 100,
            val dateLunarScalePct: Int = 100,
            val weatherInfoScalePct: Int = 100,
            val forecastStripScalePct: Int = 100,
            val overallGlobalScalePct: Int = 160,
            val secondsScalePct: Int = 100,
            val canChiScalePct: Int = 100,
            val weatherSubScalePct: Int = 100
        ) {
            val isDefault: Boolean
                get() = showClockBackground && clockFontFamily == "DEFAULT" &&
                    showLocation && showSolarDate && showLunarDate && showLunarCanChi &&
                    !showClockSeconds && showWeatherCondition && showRainPercent && showWeatherSubDetails &&
                    showHourly24h && showDaily7d && showClock7DayStrip &&
                    clockScalePct == 100 && tempScalePct == 100 && dateLunarScalePct == 100 &&
                    weatherInfoScalePct == 100 && forecastStripScalePct == 100 &&
                    overallGlobalScalePct == 100 && secondsScalePct == 100 &&
                    canChiScalePct == 100 && weatherSubScalePct == 100

            val hasEnlargedTextOverflowWarning: Boolean
                get() = clockScalePct > 105 || tempScalePct > 105 || dateLunarScalePct > 105 ||
                    weatherInfoScalePct > 105 || forecastStripScalePct > 105 ||
                    overallGlobalScalePct > 105 || secondsScalePct > 105 ||
                    canChiScalePct > 105 || weatherSubScalePct > 105

            val maxScalePct: Int
                get() = maxOf(
                    clockScalePct, tempScalePct, dateLunarScalePct,
                    weatherInfoScalePct, forecastStripScalePct, overallGlobalScalePct,
                    secondsScalePct, canChiScalePct, weatherSubScalePct
                )
        }

        fun loadCustomConfig(context: Context): WeatherWidgetCustomConfig {
            val prefs = (context.applicationContext ?: context).getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            return WeatherWidgetCustomConfig(
                showClockBackground = prefs.getBoolean(KEY_SHOW_CLOCK_BACKGROUND, true),
                clockFontFamily = prefs.getString(KEY_CLOCK_FONT_FAMILY, "DEFAULT") ?: "DEFAULT",
                showLocation = prefs.getBoolean(KEY_SHOW_LOCATION, true),
                showSolarDate = prefs.getBoolean(KEY_SHOW_SOLAR_DATE, true),
                showLunarDate = prefs.getBoolean(KEY_SHOW_LUNAR_DATE, true),
                showLunarCanChi = prefs.getBoolean(KEY_SHOW_LUNAR_CAN_CHI, false),
                showClockSeconds = prefs.getBoolean(KEY_SHOW_CLOCK_SECONDS, false),
                showWeatherCondition = prefs.getBoolean(KEY_SHOW_WEATHER_CONDITION, true),
                showRainPercent = prefs.getBoolean(KEY_SHOW_RAIN_PERCENT, true),
                showWeatherSubDetails = prefs.getBoolean(KEY_SHOW_WEATHER_SUB, false),
                showHourly24h = prefs.getBoolean(KEY_SHOW_HOURLY_24H, true),
                showDaily7d = prefs.getBoolean(KEY_SHOW_DAILY_7D, false),
                showClock7DayStrip = prefs.getBoolean(KEY_SHOW_CLOCK_7DAY_STRIP, false),
                clockScalePct = prefs.getInt(KEY_SCALE_CLOCK_PCT, 150).coerceIn(60, 160),
                tempScalePct = prefs.getInt(KEY_SCALE_TEMP_PCT, 100).coerceIn(60, 160),
                dateLunarScalePct = prefs.getInt(KEY_SCALE_DATE_LUNAR_PCT, 100).coerceIn(60, 160),
                weatherInfoScalePct = prefs.getInt(KEY_SCALE_WEATHER_INFO_PCT, 100).coerceIn(60, 160),
                forecastStripScalePct = prefs.getInt(KEY_SCALE_FORECAST_STRIP_PCT, 100).coerceIn(60, 160),
                overallGlobalScalePct = prefs.getInt(KEY_SCALE_OVERALL_GLOBAL_PCT, 160).coerceIn(60, 160),
                secondsScalePct = prefs.getInt(KEY_SCALE_CLOCK_SECONDS_PCT, 100).coerceIn(60, 160),
                canChiScalePct = prefs.getInt(KEY_SCALE_LUNAR_CAN_CHI_PCT, 100).coerceIn(60, 160),
                weatherSubScalePct = prefs.getInt(KEY_SCALE_WEATHER_SUB_PCT, 100).coerceIn(60, 160)
            )
        }

        fun saveCustomConfig(context: Context, config: WeatherWidgetCustomConfig) {
            val appCtx = context.applicationContext ?: context
            appCtx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
                .putBoolean(KEY_SHOW_CLOCK_BACKGROUND, config.showClockBackground)
                .putString(KEY_CLOCK_FONT_FAMILY, config.clockFontFamily)
                .putBoolean(KEY_SHOW_LOCATION, config.showLocation)
                .putBoolean(KEY_SHOW_SOLAR_DATE, config.showSolarDate)
                .putBoolean(KEY_SHOW_LUNAR_DATE, config.showLunarDate)
                .putBoolean(KEY_SHOW_LUNAR_CAN_CHI, config.showLunarCanChi)
                .putBoolean(KEY_SHOW_CLOCK_SECONDS, config.showClockSeconds)
                .putBoolean(KEY_SHOW_WEATHER_CONDITION, config.showWeatherCondition)
                .putBoolean(KEY_SHOW_RAIN_PERCENT, config.showRainPercent)
                .putBoolean(KEY_SHOW_WEATHER_SUB, config.showWeatherSubDetails)
                .putBoolean(KEY_SHOW_HOURLY_24H, config.showHourly24h)
                .putBoolean(KEY_SHOW_DAILY_7D, config.showDaily7d)
                .putBoolean(KEY_SHOW_CLOCK_7DAY_STRIP, config.showClock7DayStrip)
                .putInt(KEY_SCALE_CLOCK_PCT, config.clockScalePct.coerceIn(60, 160))
                .putInt(KEY_SCALE_TEMP_PCT, config.tempScalePct.coerceIn(60, 160))
                .putInt(KEY_SCALE_DATE_LUNAR_PCT, config.dateLunarScalePct.coerceIn(60, 160))
                .putInt(KEY_SCALE_WEATHER_INFO_PCT, config.weatherInfoScalePct.coerceIn(60, 160))
                .putInt(KEY_SCALE_FORECAST_STRIP_PCT, config.forecastStripScalePct.coerceIn(60, 160))
                .putInt(KEY_SCALE_OVERALL_GLOBAL_PCT, config.overallGlobalScalePct.coerceIn(60, 160))
                .putInt(KEY_SCALE_CLOCK_SECONDS_PCT, config.secondsScalePct.coerceIn(60, 160))
                .putInt(KEY_SCALE_LUNAR_CAN_CHI_PCT, config.canChiScalePct.coerceIn(60, 160))
                .putInt(KEY_SCALE_WEATHER_SUB_PCT, config.weatherSubScalePct.coerceIn(60, 160))
                .apply()
            notifyWidgetUpdate(appCtx, triggerNetworkSync = false)
        }

        fun resetCustomConfigToDefault(context: Context): WeatherWidgetCustomConfig {
            val defaultCfg = WeatherWidgetCustomConfig()
            saveCustomConfig(context, defaultCfg)
            return defaultCfg
        }

        fun updateWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
            try {
                val views = RemoteViews(context.packageName, R.layout.widget_calendar_weather)
                val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                val isClockMode = prefs.getBoolean(KEY_WIDGET_CLOCK_MODE, true)
                val customCfg = loadCustomConfig(context)
                val options = appWidgetManager.getAppWidgetOptions(appWidgetId)
                val widgetHeightDp = options?.getInt(if (context.resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE) AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT else AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 115) ?: 115
                val fontScale = context.resources.configuration.fontScale.coerceAtLeast(1f)
                // Reserve the taller touch controls before budgeting space for scaled text.
                val effectiveHeightDp = (widgetHeightDp - 32f).coerceAtLeast(0f) / fontScale
                val compactHeight = effectiveHeightDp < 170f
                val compactFontScale = 1f
                val widgetHeightScale = 1f

                val globalScale = (customCfg.overallGlobalScalePct / 100f).coerceIn(0.60f, 1.60f)
                val clockScale = ((customCfg.clockScalePct / 100f) * globalScale).coerceIn(0.55f, 1.80f)
                val responsiveClockScale = (clockScale * widgetHeightScale).coerceIn(0.55f / compactFontScale, 1.80f)
                val secondsScale = ((customCfg.secondsScalePct / 100f) * globalScale * widgetHeightScale).coerceIn(0.55f / compactFontScale, 1.80f)
                val tempScale = ((customCfg.tempScalePct / 100f) * globalScale * widgetHeightScale).coerceIn(0.55f / compactFontScale, 1.80f)
                val dateScale = ((customCfg.dateLunarScalePct / 100f) * globalScale * widgetHeightScale).coerceIn(0.55f / compactFontScale, 1.80f)
                val canChiScale = ((customCfg.canChiScalePct / 100f) * globalScale * widgetHeightScale).coerceIn(0.55f / compactFontScale, 1.80f)
                val infoScale = ((customCfg.weatherInfoScalePct / 100f) * globalScale * widgetHeightScale).coerceIn(0.55f / compactFontScale, 1.80f)
                val weatherSubScale = ((customCfg.weatherSubScalePct / 100f) * globalScale * widgetHeightScale).coerceIn(0.55f / compactFontScale, 1.80f)
                val stripScale = ((customCfg.forecastStripScalePct / 100f) * globalScale * widgetHeightScale).coerceIn(0.55f / compactFontScale, 1.80f)

                views.setViewVisibility(
                    R.id.widget_mode_forecast_container,
                    if (isClockMode) View.GONE else View.VISIBLE
                )
                views.setViewVisibility(
                    R.id.widget_mode_clock_container,
                    if (isClockMode) View.VISIBLE else View.GONE
                )

                // 0. BẬT / TẮT NỀN ĐỒNG HỒ (Trong suốt 100% vs Nền kính mờ bo tròn)
                val rootBg = if (customCfg.showClockBackground) {
                    WidgetBackgroundOpacityHelper.resolveDrawable(context, WidgetBackgroundOpacityHelper.BgStyle.GLASS)
                } else 0
                views.setInt(R.id.widget_calendar_weather_root, "setBackgroundResource", rootBg)

                val clockBoxBg = 0
                views.setInt(R.id.widget_clock_time_container, "setBackgroundResource", clockBoxBg)

                // Áp dụng ẩn / hiện từng mục theo tùy chỉnh của người dùng
                views.setViewVisibility(R.id.widget_location_text, if (customCfg.showLocation) View.VISIBLE else View.GONE)
                views.setViewVisibility(R.id.widget_clock_location, if (customCfg.showLocation) View.VISIBLE else View.GONE)
                views.setViewVisibility(R.id.widget_solar_date_time, if (customCfg.showSolarDate) View.VISIBLE else View.INVISIBLE)
                views.setViewVisibility(R.id.widget_clock_solar_date, if (customCfg.showSolarDate) View.VISIBLE else View.GONE)
                views.setViewVisibility(R.id.widget_lunar_date, if (customCfg.showLunarDate) View.VISIBLE else View.INVISIBLE)
                views.setViewVisibility(R.id.widget_clock_lunar_date, if (customCfg.showLunarDate) View.VISIBLE else View.GONE)
                views.setViewVisibility(R.id.widget_clock_lunar_extra, if (customCfg.showLunarCanChi && !compactHeight) View.VISIBLE else View.GONE)
                // Khi độ to đồng hồ được chỉnh lớn hơn mức mặc định (> 100%), tự động ẩn số giây (:ss) cho gọn thay vì bóp hẹp số giây
                val shouldShowClockSeconds = customCfg.showClockSeconds && customCfg.clockScalePct <= 100
                views.setViewVisibility(R.id.widget_clock_mini_seconds, if (shouldShowClockSeconds) View.VISIBLE else View.GONE)
                views.setViewVisibility(R.id.widget_clock_weather_condition, if (customCfg.showWeatherCondition) View.VISIBLE else View.GONE)
                views.setViewVisibility(R.id.widget_clock_rain_percent, if (customCfg.showRainPercent && !compactHeight) View.VISIBLE else View.GONE)
                views.setViewVisibility(R.id.widget_clock_weather_sub, if (customCfg.showWeatherSubDetails && !compactHeight) View.VISIBLE else View.GONE)

                views.setViewVisibility(R.id.widget_forecast_row_24h_header, if (customCfg.showHourly24h) View.VISIBLE else View.GONE)
                views.setViewVisibility(R.id.widget_forecast_row_24h_slots, if (customCfg.showHourly24h) View.VISIBLE else View.GONE)
                views.setViewVisibility(R.id.widget_forecast_row_7d_header, if (customCfg.showDaily7d && !compactHeight) View.VISIBLE else View.GONE)
                views.setViewVisibility(R.id.widget_forecast_row_7d_slots, if (customCfg.showDaily7d && !compactHeight) View.VISIBLE else View.GONE)
                views.setViewVisibility(R.id.widget_clock_row_7day_strip, if (customCfg.showClock7DayStrip && !compactHeight) View.VISIBLE else View.GONE)

                // Dynamic text size adjustment based on widget width + user custom scale
                val minWidth = options?.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH) ?: 250
                val baseBigTimeSize = if (minWidth < 230) 30f else 44f
                val clockWidthCap = (((minWidth - 24) * 0.52f - 12) / 3.1f).coerceIn(24f, 60f)
                val baseSecondsSize = if (minWidth < 180) 8.5f else if (minWidth < 230) 10f else 12f
                val spUnit = android.util.TypedValue.COMPLEX_UNIT_SP

                // Đổi font chữ của đồng hồ theo ý thích người dùng (6 phông: Mặc định, Digital, Serif, Condensed, Black, Light)
                val fontClocks = listOf(
                    "DEFAULT" to (R.id.widget_clock_big_time to R.id.widget_clock_mini_seconds),
                    "DIGITAL" to (R.id.widget_clock_big_time_digital to R.id.widget_clock_mini_seconds_digital),
                    "SERIF" to (R.id.widget_clock_big_time_serif to R.id.widget_clock_mini_seconds_serif),
                    "CONDENSED" to (R.id.widget_clock_big_time_condensed to R.id.widget_clock_mini_seconds_condensed),
                    "BLACK" to (R.id.widget_clock_big_time_black to R.id.widget_clock_mini_seconds_black),
                    "LIGHT" to (R.id.widget_clock_big_time_light to R.id.widget_clock_mini_seconds_light)
                )

                val chosenFont = customCfg.clockFontFamily.uppercase()
                val activePair = fontClocks.firstOrNull { it.first == chosenFont }?.second
                    ?: (R.id.widget_clock_big_time to R.id.widget_clock_mini_seconds)

                for ((_, pair) in fontClocks) {
                    val (bId, sId) = pair
                    if (pair == activePair) {
                        views.setViewVisibility(bId, View.VISIBLE)
                        views.setViewVisibility(sId, if (shouldShowClockSeconds) View.VISIBLE else View.GONE)
                        views.setTextViewTextSize(bId, spUnit, (baseBigTimeSize * responsiveClockScale).coerceAtMost(clockWidthCap / fontScale))
                        views.setTextViewTextSize(sId, spUnit, baseSecondsSize * secondsScale)
                        views.setBoolean(bId, "setSingleLine", true)
                        views.setBoolean(sId, "setSingleLine", true)
                        views.setInt(bId, "setMaxLines", 1)
                        views.setInt(sId, "setMaxLines", 1)
                    } else {
                        views.setViewVisibility(bId, View.GONE)
                        views.setViewVisibility(sId, View.GONE)
                    }
                }

                views.setTextViewTextSize(R.id.widget_weather_temp, spUnit, 12.5f * tempScale)
                views.setTextViewTextSize(R.id.widget_clock_temp_big, spUnit, (28f * tempScale).coerceIn(22f / compactFontScale, 34f / compactFontScale))

                views.setTextViewTextSize(R.id.widget_solar_date_time, spUnit, 10.3f * dateScale)
                views.setTextViewTextSize(R.id.widget_lunar_date, spUnit, 9.4f * dateScale)
                views.setTextViewTextSize(R.id.widget_clock_solar_date, spUnit, (11f * dateScale).coerceIn(10f / compactFontScale, 12f / compactFontScale))
                views.setTextViewTextSize(R.id.widget_clock_lunar_date, spUnit, (11f * dateScale).coerceIn(10f / compactFontScale, 12f / compactFontScale))
                views.setTextViewTextSize(R.id.widget_clock_lunar_extra, spUnit, 8.1f * canChiScale)

                views.setTextViewTextSize(R.id.widget_location_text, spUnit, 10.5f * infoScale)
                views.setTextViewTextSize(R.id.widget_clock_location, spUnit, (10f * infoScale).coerceIn(10f / compactFontScale, 11f / compactFontScale))
                views.setTextViewTextSize(R.id.widget_clock_weather_condition, spUnit, (11f * infoScale).coerceIn(10f / compactFontScale, 12f / compactFontScale))
                views.setTextViewTextSize(R.id.widget_clock_rain_percent, spUnit, (11f * infoScale).coerceIn(10f / compactFontScale, 12f / compactFontScale))
                views.setTextViewTextSize(R.id.widget_clock_weather_sub, spUnit, 8.1f * weatherSubScale)

                views.setTextViewTextSize(R.id.w24_title, spUnit, 10f * stripScale)
                views.setTextViewTextSize(R.id.w7d_title, spUnit, 10f * stripScale)
                views.setTextViewText(R.id.w24_title, tr("⏰ DỰ BÁO THEO GIỜ (24H)"))
                views.setTextViewText(R.id.w7d_title, tr("📅 DỰ BÁO 7 NGÀY TỚI"))
                views.setTextViewText(R.id.widget_btn_reset_scroll, tr("↺ Hiện tại"))
                views.setTextViewText(R.id.widget_btn_toggle_mode, tr("🕒 Đồng hồ"))
                views.setTextViewText(R.id.widget_clock_btn_reset, tr("↺ Hiện tại"))
                views.setTextViewText(R.id.widget_clock_btn_toggle_mode, tr("🌤️ Thời tiết"))
                views.setTextViewTextSize(R.id.widget_clock_mini_app_name, spUnit, (10f * infoScale).coerceIn(10f / compactFontScale, 11f / compactFontScale))
                views.setBoolean(R.id.widget_clock_mini_app_name, "setSingleLine", true)
                views.setInt(R.id.widget_clock_mini_app_name, "setMaxLines", 1)

                // Đảm bảo toàn bộ văn bản tự động xuống dòng đầy đủ, tuyệt đối không viết tắt thành dấu 3 chấm (...)
                // đặc biệt khi ở chế độ phóng to / gọn gàng / tối giản
                val multiLineTextIds = intArrayOf(
                    R.id.widget_solar_date_time,
                    R.id.widget_location_text,
                    R.id.widget_lunar_date,
                    R.id.widget_clock_solar_date,
                    R.id.widget_clock_lunar_date,
                    R.id.widget_clock_lunar_extra,
                    R.id.widget_clock_location,
                    R.id.widget_clock_weather_condition,
                    R.id.widget_clock_rain_percent,
                    R.id.widget_clock_weather_sub
                )
                for (tvId in multiLineTextIds) {
                    views.setBoolean(tvId, "setSingleLine", false)
                    views.setInt(tvId, "setMaxLines", 4)
                }

                val now = Date()
                val calNow = Calendar.getInstance().apply { time = now }
                val dateFormat = SimpleDateFormat("EEEE, dd/MM/yyyy", Locale("vi", "VN"))
                val solarStr = dateFormat.format(now).replaceFirstChar { it.uppercase() }

                val lunarStr = getLunarDateString(now)
                val lunarObj = VietnameseLunarCalendar.convertSolar2Lunar(
                    calNow.get(Calendar.DAY_OF_MONTH),
                    calNow.get(Calendar.MONTH) + 1,
                    calNow.get(Calendar.YEAR)
                )
                val fullLocation = getSelectedLocation(context)
                val weatherData = VietnamClimateEngine.getCachedOrInitialWeather(context, fullLocation)

                // =========================================================================
                // CẬP NHẬT DỮ LIỆU GIAO DIỆN 1: DỰ BÁO THỜI TIẾT (24H & 7 NGÀY)
                // =========================================================================
                views.setTextViewText(R.id.widget_solar_date_time, solarStr)
                views.setTextViewText(R.id.widget_location_text, fullLocation)
                views.setTextViewText(R.id.widget_lunar_date, tr("🏮 Âm: $lunarStr"))
                views.setTextViewText(R.id.widget_weather_temp, weatherData.tempDisplay)

                val page24h = prefs.getInt(KEY_PAGE_24H, 0)
                val page7d = prefs.getInt(KEY_PAGE_7D, 0)
                val isScrolled = page24h != 0 || page7d != 0
                views.setTextViewText(R.id.widget_btn_reset_scroll, "↺")
                views.setTextColor(
                    R.id.widget_btn_reset_scroll,
                    if (isScrolled) Color.parseColor("#FBBF24") else Color.parseColor("#E0F2FE")
                )
                views.setTextViewText(R.id.widget_btn_toggle_mode, tr("🕒 Đồng hồ"))
                views.setTextViewText(R.id.widget_btn_calendar_refresh, "🔄")

                val offset24 = (page24h % 6) * 4
                val hourlySlots = (0 until 4).map { i ->
                    val slot = weatherData.hourlyForecast.getOrNull((offset24 + i) % weatherData.hourlyForecast.size)
                    SlotData(
                        timeOrDay = slot?.hourLabel ?: "--:--",
                        icon = slot?.icon ?: "☀️",
                        temp = slot?.temp ?: "${weatherData.currentTemp}°C"
                    )
                }
                views.setTextViewText(R.id.w24_title, tr("⏰ DỰ BÁO THEO GIỜ (24H)"))
                populate24hSlots(views, hourlySlots, stripScale, tempScale)

                val offset7d = (page7d % 2) * 3
                val dailySlots = (0 until 4).map { i ->
                    val slot = weatherData.dailyForecast.getOrNull(offset7d + i)
                    SlotData(
                        timeOrDay = slot?.dayName ?: tr("Ngày tới"),
                        icon = slot?.icon ?: "☀️",
                        temp = if (slot != null) "${slot.minTemp}°~${slot.maxTemp}°" else "${weatherData.currentTemp}°"
                    )
                }
                views.setTextViewText(R.id.w7d_title, tr("📅 DỰ BÁO 7 NGÀY TỚI"))
                populate7dSlots(views, dailySlots, stripScale, tempScale)

                // =========================================================================
                // CẬP NHẬT DỮ LIỆU GIAO DIỆN 2: ĐỒNG HỒ LỚN + THỜI TIẾT + LỊCH 7 NGÀY
                // =========================================================================
                views.setTextViewText(R.id.widget_clock_mini_app_name, "⚡ Magictune Weather")
                views.setTextViewText(R.id.widget_clock_btn_reset, "↺")
                views.setTextViewText(R.id.widget_clock_btn_toggle_mode, tr("Dự báo"))
                views.setTextViewText(R.id.widget_clock_btn_refresh, "🔄")

                views.setTextViewText(R.id.widget_clock_solar_date, solarStr)
                val leapTag = if (lunarObj.isLeapMonth) tr(" (Nhuận)") else ""
                val compactLunar = String.format(Locale.US, "%02d/%02d", lunarObj.day, lunarObj.month)
                views.setTextViewText(
                    R.id.widget_clock_lunar_date,
                    tr("🏮 Âm: $compactLunar$leapTag • ${lunarObj.yearCanChi}")
                )
                val holiday = VietnameseLunarCalendar.getHolidayName(
                    calNow.get(Calendar.DAY_OF_MONTH),
                    calNow.get(Calendar.MONTH) + 1,
                    lunarObj
                )
                val lunarExtraText = if (!holiday.isNullOrBlank()) {
                    tr("🎉 $holiday • Ngày ${lunarObj.dayCanChi}")
                } else {
                    tr("✨ Ngày ${lunarObj.dayCanChi} • Tháng ${lunarObj.monthCanChi}")
                }
                views.setTextViewText(R.id.widget_clock_lunar_extra, lunarExtraText)

                // Cột phải giao diện đồng hồ: Khu vực + Nhiệt độ to rõ ở hàng riêng + Độ quang đãng hàng riêng + Dòng mưa % hàng riêng
                views.setTextViewText(R.id.widget_clock_location, fullLocation)
                views.setTextViewText(R.id.widget_clock_temp_big, weatherData.tempDisplay)
                val clarityIcon = getDistinctSkyClarityIcon(weatherData.icon, weatherData.condition)
                views.setTextViewText(
                    R.id.widget_clock_weather_condition,
                    "$clarityIcon " + tr(weatherData.condition)
                )

                val rainPct = weatherData.rainProbability.coerceIn(0, 100)
                val rainStatus = when {
                    rainPct >= 65 || weatherData.icon in listOf("🌧️", "⛈️") -> tr("Đang có mưa")
                    rainPct >= 40 || weatherData.icon == "🌦️" -> tr("Có thể mưa rải rác")
                    weatherData.icon == "☀️" || weatherData.icon == "🌤️" -> tr("Đang nắng ráo")
                    weatherData.icon == "🌙" -> tr("Đêm tạnh ráo")
                    else -> tr("Trời dịu mát")
                }
                views.setTextViewText(
                    R.id.widget_clock_rain_percent,
                    tr("☔ Khả năng mưa: ${rainPct}% ($rainStatus)")
                )
                views.setTextColor(
                    R.id.widget_clock_rain_percent,
                    if (rainPct >= 50) Color.parseColor("#38BDF8") else Color.parseColor("#FCD34D")
                )

                val todayDaily = weatherData.dailyForecast.firstOrNull()
                val minMaxStr = if (todayDaily != null) {
                    "${todayDaily.minTemp}°~${todayDaily.maxTemp}°C"
                } else {
                    "${weatherData.currentTemp - 3}°~${weatherData.currentTemp + 2}°C"
                }
                val uvShort = weatherData.uvIndex.substringBefore(" ").trim()
                views.setTextViewText(
                    R.id.widget_clock_weather_sub,
                    tr("🌡️ $minMaxStr • 💧 Ẩm: ${weatherData.humidity}% • 🌬️ Gió ${weatherData.windSpeed}km/h • UV $uvShort")
                )

                // Hàng dưới cùng: Lịch Thứ Dương Âm 7 Ngày (Thứ 2 -> Chủ Nhật)
                populate7DaySolarLunarStrip(views, calNow, stripScale)

                // =========================================================================
                // GÁN SỰ KIỆN NÚT BẤM (PENDING INTENTS)
                // =========================================================================
                // 0. Khóa nền Widget bằng Broadcast rỗng (No-Op) để ghi đè mọi sự kiện cũ trong bộ nhớ đệm Launcher
                //    và ngăn tuyệt đối việc chạm vào vùng trống / đồng hồ / nhiệt độ làm nhảy vào ứng dụng!
                val noopIntent = Intent(context, MagicTuneCalendarWeatherWidgetProvider::class.java).apply {
                    action = ACTION_WEATHER_WIDGET_NOOP
                }
                val pendingNoop = PendingIntent.getBroadcast(
                    context,
                    8900 + appWidgetId,
                    noopIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_calendar_weather_root, pendingNoop)
                views.setOnClickPendingIntent(R.id.widget_mode_forecast_container, pendingNoop)
                views.setOnClickPendingIntent(R.id.widget_mode_clock_container, pendingNoop)
                views.setOnClickPendingIntent(R.id.widget_clock_mini_app_name, pendingNoop)
                views.setOnClickPendingIntent(R.id.widget_clock_time_container, pendingNoop)
                for ((_, pair) in fontClocks) {
                    views.setOnClickPendingIntent(pair.first, pendingNoop)
                    views.setOnClickPendingIntent(pair.second, pendingNoop)
                }
                views.setOnClickPendingIntent(R.id.widget_clock_temp_big, pendingNoop)
                views.setOnClickPendingIntent(R.id.widget_weather_temp, pendingNoop)

                // 1. CHỈ mở ứng dụng (Tab Thời Tiết) khi người dùng ấn trực tiếp vào dòng chữ tên khu vực
                val intentApp = Intent(context, MainActivity::class.java).apply {
                    `package` = context.packageName
                    action = "com.example.ACTION_OPEN_WEATHER_TAB"
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    putExtra("TARGET_TAB", "WEATHER")
                }
                val pendingApp = PendingIntent.getActivity(
                    context, 8100 + appWidgetId, intentApp,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_location_text, pendingApp)
                views.setOnClickPendingIntent(R.id.widget_clock_location, pendingApp)

                // 2. Nút làm mới (cập nhật thời tiết thực tế từ mạng) ở cả 2 giao diện
                val intentRefresh = Intent(context, MagicTuneCalendarWeatherWidgetProvider::class.java).apply {
                    action = ACTION_CALENDAR_WEATHER_REFRESH
                    putExtra(EXTRA_MANUAL_REFRESH, true)
                }
                val pendingRefresh = PendingIntent.getBroadcast(
                    context, 1, intentRefresh,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_btn_calendar_refresh, pendingRefresh)
                views.setOnClickPendingIntent(R.id.widget_clock_btn_refresh, pendingRefresh)

                // 3. Nút cuộn 24h
                val pi24Next = PendingIntent.getBroadcast(
                    context, 11,
                    Intent(context, MagicTuneCalendarWeatherWidgetProvider::class.java).apply { action = ACTION_WEATHER_24H_NEXT },
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.w24_btn_next, pi24Next)

                val pi24Prev = PendingIntent.getBroadcast(
                    context, 12,
                    Intent(context, MagicTuneCalendarWeatherWidgetProvider::class.java).apply { action = ACTION_WEATHER_24H_PREV },
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.w24_btn_prev, pi24Prev)

                // 4. Nút cuộn 7 ngày
                val pi7dNext = PendingIntent.getBroadcast(
                    context, 21,
                    Intent(context, MagicTuneCalendarWeatherWidgetProvider::class.java).apply { action = ACTION_WEATHER_7D_NEXT },
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.w7d_btn_next, pi7dNext)

                val pi7dPrev = PendingIntent.getBroadcast(
                    context, 22,
                    Intent(context, MagicTuneCalendarWeatherWidgetProvider::class.java).apply { action = ACTION_WEATHER_7D_PREV },
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.w7d_btn_prev, pi7dPrev)

                // 5. Nút Hiện tại ở cả 2 giao diện -> Đưa hàng cuộn (24H & 7 ngày) và lịch về hiện tại nhanh
                val piResetScroll = PendingIntent.getBroadcast(
                    context, 31,
                    Intent(context, MagicTuneCalendarWeatherWidgetProvider::class.java).apply { action = ACTION_WEATHER_RESET_SCROLL },
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_btn_reset_scroll, piResetScroll)
                views.setOnClickPendingIntent(R.id.widget_clock_btn_reset, piResetScroll)

                // 6. Nút chuyển đổi linh hoạt giữa 2 giao diện (Thời tiết <-> Đồng hồ) bên cạnh nút Hiện tại
                val piToggleMode = PendingIntent.getBroadcast(
                    context, 41,
                    Intent(context, MagicTuneCalendarWeatherWidgetProvider::class.java).apply { action = ACTION_WEATHER_TOGGLE_MODE },
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_btn_toggle_mode, piToggleMode)
                views.setOnClickPendingIntent(R.id.widget_clock_btn_toggle_mode, piToggleMode)

                appWidgetManager.updateAppWidget(appWidgetId, views)
            } catch (_: Throwable) {}
        }

        private data class SlotData(val timeOrDay: String, val icon: String, val temp: String)

        private fun populate24hSlots(
            views: RemoteViews,
            slots: List<SlotData>,
            stripScale: Float = 1f,
            tempScale: Float = 1f
        ) {
            val timeIds = intArrayOf(R.id.w24_time_1, R.id.w24_time_2, R.id.w24_time_3, R.id.w24_time_4)
            val iconIds = intArrayOf(R.id.w24_icon_1, R.id.w24_icon_2, R.id.w24_icon_3, R.id.w24_icon_4)
            val tempIds = intArrayOf(R.id.w24_temp_1, R.id.w24_temp_2, R.id.w24_temp_3, R.id.w24_temp_4)
            val spUnit = android.util.TypedValue.COMPLEX_UNIT_SP

            for (i in 0 until 4) {
                if (i < slots.size) {
                    val s = slots[i]
                    views.setTextViewText(timeIds[i], s.timeOrDay)
                    views.setTextViewText(iconIds[i], s.icon)
                    views.setTextViewText(tempIds[i], s.temp)
                    views.setTextViewTextSize(timeIds[i], spUnit, 8.5f * stripScale)
                    views.setTextViewTextSize(iconIds[i], spUnit, 10.8f * stripScale)
                    views.setTextViewTextSize(tempIds[i], spUnit, 10f * tempScale)
                }
            }
        }

        private fun populate7dSlots(
            views: RemoteViews,
            slots: List<SlotData>,
            stripScale: Float = 1f,
            tempScale: Float = 1f
        ) {
            val timeIds = intArrayOf(R.id.w7d_time_1, R.id.w7d_time_2, R.id.w7d_time_3, R.id.w7d_time_4)
            val iconIds = intArrayOf(R.id.w7d_icon_1, R.id.w7d_icon_2, R.id.w7d_icon_3, R.id.w7d_icon_4)
            val tempIds = intArrayOf(R.id.w7d_temp_1, R.id.w7d_temp_2, R.id.w7d_temp_3, R.id.w7d_temp_4)
            val spUnit = android.util.TypedValue.COMPLEX_UNIT_SP

            for (i in 0 until 4) {
                if (i < slots.size) {
                    val s = slots[i]
                    views.setTextViewText(timeIds[i], s.timeOrDay)
                    views.setTextViewText(iconIds[i], s.icon)
                    views.setTextViewText(tempIds[i], s.temp)
                    views.setTextViewTextSize(timeIds[i], spUnit, 8.5f * stripScale)
                    views.setTextViewTextSize(iconIds[i], spUnit, 10.8f * stripScale)
                    views.setTextViewTextSize(tempIds[i], spUnit, 9.2f * tempScale)
                }
            }
        }

        private fun populate7DaySolarLunarStrip(
            views: RemoteViews,
            todayCal: Calendar,
            stripScale: Float = 1f
        ) {
            val colIds = intArrayOf(
                R.id.wc_day_col_1, R.id.wc_day_col_2, R.id.wc_day_col_3,
                R.id.wc_day_col_4, R.id.wc_day_col_5, R.id.wc_day_col_6, R.id.wc_day_col_7
            )
            val dowIds = intArrayOf(
                R.id.wc_dow_1, R.id.wc_dow_2, R.id.wc_dow_3,
                R.id.wc_dow_4, R.id.wc_dow_5, R.id.wc_dow_6, R.id.wc_dow_7
            )
            val solarIds = intArrayOf(
                R.id.wc_solar_1, R.id.wc_solar_2, R.id.wc_solar_3,
                R.id.wc_solar_4, R.id.wc_solar_5, R.id.wc_solar_6, R.id.wc_solar_7
            )
            val lunarIds = intArrayOf(
                R.id.wc_lunar_1, R.id.wc_lunar_2, R.id.wc_lunar_3,
                R.id.wc_lunar_4, R.id.wc_lunar_5, R.id.wc_lunar_6, R.id.wc_lunar_7
            )
            val spUnit = android.util.TypedValue.COMPLEX_UNIT_SP

            val todayYear = todayCal.get(Calendar.YEAR)
            val todayMonth = todayCal.get(Calendar.MONTH) + 1
            val todayDay = todayCal.get(Calendar.DAY_OF_MONTH)
            val dow = todayCal.get(Calendar.DAY_OF_WEEK)
            val offsetFromMonday = if (dow == Calendar.SUNDAY) 6 else (dow - Calendar.MONDAY)

            val mondayCal = (todayCal.clone() as Calendar).apply {
                add(Calendar.DAY_OF_YEAR, -offsetFromMonday)
            }

            for (i in 0 until 7) {
                val cellCal = (mondayCal.clone() as Calendar).apply {
                    add(Calendar.DAY_OF_YEAR, i)
                }
                val sDay = cellCal.get(Calendar.DAY_OF_MONTH)
                val sMonth = cellCal.get(Calendar.MONTH) + 1
                val sYear = cellCal.get(Calendar.YEAR)
                val isToday = (sDay == todayDay && sMonth == todayMonth && sYear == todayYear)

                val lunar = VietnameseLunarCalendar.convertSolar2Lunar(sDay, sMonth, sYear)
                val dowLabel = if (i == 6) "CN" else "T${i + 2}"
                val lunarLabel = if (isToday || lunar.day == 1 || i == 0) {
                    "${lunar.day}/${lunar.month}"
                } else {
                    "${lunar.day}"
                }

                views.setTextViewText(dowIds[i], tr(dowLabel))
                views.setTextViewText(solarIds[i], sDay.toString())
                views.setTextViewText(lunarIds[i], lunarLabel)
                views.setTextViewTextSize(dowIds[i], spUnit, 8.5f * stripScale)
                views.setTextViewTextSize(solarIds[i], spUnit, 10.5f * stripScale)
                views.setTextViewTextSize(lunarIds[i], spUnit, 8.5f * stripScale)

                val bgRes = when {
                    isToday -> R.drawable.widget_calendar_today_cell_bg
                    lunar.day == 1 || lunar.day == 15 -> R.drawable.widget_calendar_special_cell_bg
                    else -> 0
                }
                views.setInt(colIds[i], "setBackgroundResource", bgRes)

                val dowColor = when {
                    isToday -> Color.parseColor("#38BDF8")
                    i == 6 -> Color.parseColor("#FB7185")
                    i == 5 -> Color.parseColor("#FBBF24")
                    else -> Color.parseColor("#94A3B8")
                }
                val solarColor = when {
                    isToday -> Color.parseColor("#FFFFFF")
                    i == 6 -> Color.parseColor("#FDA4AF")
                    else -> Color.parseColor("#E2E8F0")
                }
                val lunarColor = when {
                    lunar.day == 1 || lunar.day == 15 -> Color.parseColor("#F87171")
                    isToday -> Color.parseColor("#FDE047")
                    else -> Color.parseColor("#FBBF24")
                }

                views.setTextColor(dowIds[i], dowColor)
                views.setTextColor(solarIds[i], solarColor)
                views.setTextColor(lunarIds[i], lunarColor)
            }
        }

        private fun getSelectedLocation(context: Context): String {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            return prefs.getString(KEY_SELECTED_LOCATION, "Phường Kim Mã, Ba Đình, Hà Nội") ?: "Phường Kim Mã, Ba Đình, Hà Nội"
        }

        private fun getLunarDateString(date: Date): String {
            return VietnameseLunarCalendar.formatCompactLunar(date)
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val appCtx = context.applicationContext ?: context
        if (appWidgetIds.isEmpty()) return
        val idsCopy = appWidgetIds.copyOf()
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                for (id in idsCopy) {
                    updateWidget(appCtx, appWidgetManager, id)
                }
                val loc = getSelectedLocation(appCtx)
                if (reserveAutoFetch(appCtx, loc, maxAgeMs = 6 * 60 * 60_000L)) {
                    // Widget tự làm mới thời tiết tối đa mỗi 6 giờ; nút Làm mới vẫn cập nhật ngay theo yêu cầu.
                    // Giới hạn chặt 6.5s để tuyệt đối không vượt ngưỡng 10s Broadcast ANR khi mạng chập chờn
                    kotlinx.coroutines.withTimeoutOrNull(6_500L) {
                        VietnamClimateEngine.fetchLiveWeatherAsync(appCtx, loc)
                    }
                    for (id in idsCopy) {
                        updateWidget(appCtx, appWidgetManager, id)
                    }
                }
            } catch (_: Throwable) {
            } finally {
                try { pendingResult.finish() } catch (_: Throwable) {}
            }
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val action = intent.action ?: return
        if (action == ACTION_WEATHER_WIDGET_NOOP) return
        val appCtx = context.applicationContext ?: context
        val awm = AppWidgetManager.getInstance(appCtx)
        val ids = awm.getAppWidgetIds(ComponentName(appCtx, MagicTuneCalendarWeatherWidgetProvider::class.java))
        val prefs = appCtx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        when (action) {
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED -> {
                val pendingResult = goAsync()
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        for (id in ids) updateWidget(appCtx, awm, id)
                    } catch (_: Throwable) {
                    } finally {
                        try { pendingResult.finish() } catch (_: Throwable) {}
                    }
                }
            }
            ACTION_CALENDAR_WEATHER_REFRESH -> {
                val isManual = intent.getBooleanExtra(EXTRA_MANUAL_REFRESH, true)
                val pendingResult = goAsync()
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        for (id in ids) updateWidget(appCtx, awm, id)
                        val loc = getSelectedLocation(appCtx)
                        if (!isManual && (ids.isEmpty() || !reserveAutoFetch(appCtx, loc, 6 * 60 * 60_000L))) return@launch
                        val live = kotlinx.coroutines.withTimeoutOrNull(6_500L) {
                            VietnamClimateEngine.fetchLiveWeatherAsync(appCtx, loc)
                        }
                        for (id in ids) updateWidget(appCtx, awm, id)
                        if (isManual) {
                            val msg = if (live?.isLiveData == true) {
                                tr("🌤️ Đã cập nhật thời tiết thực tế mới nhất!")
                            } else {
                                tr("⚠️ Chưa có mạng, đang dùng dữ liệu đã lưu")
                            }
                            withContext(Dispatchers.Main) {
                                try {
                                    Toast.makeText(appCtx, msg, Toast.LENGTH_SHORT).show()
                                } catch (_: Throwable) {}
                            }
                        }
                    } catch (_: Throwable) {
                    } finally {
                        try { pendingResult.finish() } catch (_: Throwable) {}
                    }
                }
            }
            ACTION_WEATHER_24H_NEXT -> {
                val cur = prefs.getInt(KEY_PAGE_24H, 0)
                prefs.edit().putInt(KEY_PAGE_24H, (cur + 1) % 6).apply()
                for (id in ids) updateWidget(context, awm, id)
            }
            ACTION_WEATHER_24H_PREV -> {
                val cur = prefs.getInt(KEY_PAGE_24H, 0)
                val prev = if (cur - 1 < 0) 5 else cur - 1
                prefs.edit().putInt(KEY_PAGE_24H, prev).apply()
                for (id in ids) updateWidget(context, awm, id)
            }
            ACTION_WEATHER_7D_NEXT -> {
                val cur = prefs.getInt(KEY_PAGE_7D, 0)
                prefs.edit().putInt(KEY_PAGE_7D, (cur + 1) % 2).apply()
                for (id in ids) updateWidget(context, awm, id)
            }
            ACTION_WEATHER_7D_PREV -> {
                val cur = prefs.getInt(KEY_PAGE_7D, 0)
                val prev = if (cur - 1 < 0) 1 else cur - 1
                prefs.edit().putInt(KEY_PAGE_7D, prev).apply()
                for (id in ids) updateWidget(context, awm, id)
            }
            ACTION_WEATHER_RESET_SCROLL -> {
                prefs.edit()
                    .putInt(KEY_PAGE_24H, 0)
                    .putInt(KEY_PAGE_7D, 0)
                    .apply()
                for (id in ids) updateWidget(context, awm, id)
            }
            ACTION_WEATHER_TOGGLE_MODE -> {
                val curMode = prefs.getBoolean(KEY_WIDGET_CLOCK_MODE, true)
                prefs.edit().putBoolean(KEY_WIDGET_CLOCK_MODE, !curMode).apply()
                for (id in ids) updateWidget(context, awm, id)
            }
        }
    }
}
