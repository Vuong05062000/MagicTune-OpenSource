# AGENTS.md — Dự án MagicTune (Android/Kotlin/Compose)

## 1. Cấu trúc nguồn sau khi giải nén zip
- File nén `uploads/Apk-MagicTune-OpenSource.zip` dùng **backslash** làm phân cách thư mục. Khi giải nén trên Linux, các file Java bị gộp thành tên file chứa gạch chéo ngược ở gốc (ví dụ `src\main\java\Foo.kt`) thay vì thư mục thực `src/main/java/`.
- `build.gradle.kts` mong đợi `java.srcDirs("src/main/java")`. Nếu giải nén lại zip, phải chạy lại bước cấu trúc thư mục (di chuyển `src\main\java\*.kt` → `src/main/java/*.kt`) trước khi build,否则 Gradle sẽ không tìm thấy nguồn.

## 2. Hoàn toàn miễn phí (không mất phí duy trì người dùng & admin)
- `src/main/java/LicenseManager.kt`:
  - `isAppFreeMode()` → luôn `true`
  - `isProActivated()` → luôn `true`
  - `isAccountProActivated()` → luôn `true`
  → Tất cả tính năng mở khóa, không tiêu lượt dùng thử, không chặn `runAction`, admin không phải trả phí duy trì.
- `src/main/java/SetupScreen.kt`: thẻ mua Pro (`ProLicenseCard`, 50k–100kđ) đã thay bằng thẻ thông báo "Tất cả tính năng đã mở khóa miễn phí — không mất phí duy trì".
- `src/main/java/MainActivity.kt`: đã xóa block hiển thị `UpgradeProRequiredDialog`.
- **Đã xóa mã chết:** `HeaderSection.kt`, `ProLicenseCard.kt`, `UpgradeProRequiredDialog.kt`, `SmsPaymentReceiver.kt`, `reorganize_src.py` (không còn dùng sau khi chuyển sang miễn phí + bottom nav).

## 3. Widget pin (battery widget)
- `src/main/java/BatteryInfoReader.kt`: thêm `getSmoothBatteryPct(context, realPct, isCharging)` — khi sạc, phần trăm hiển thị tăng dần từng tí một (cộng 0.06 mỗi lần làm mới, khép ở giá thực) và lưu vào prefs.
- `src/main/java/MagicTuneBatteryWidgetProvider.kt` & `MagicTuneSimpleBatteryWidgetProvider.kt`:
  - Khi sạc: hiển thị `%` có 2 số thập phân (ví dụ `86.35%`) thay vì integer nhảy lẹ.
  - Đã xóa mọi hiển thị `%.1fW` (công suất sạc) khi sạc.
  - Khi không sạc: hiển thị `%` nguyên (chính xác theo BatteryManager).
- `src/main/java/core/widget/BatteryWidgetRefreshReceiver.kt` (mới): AlarmManager làm mới cả 2 widget pin định kỳ 1 phút, chỉ bật khi cắm sạc.
- `AndroidManifest.xml`: đã đăng ký `BatteryWidgetRefreshReceiver`.
- `MainActivity.kt`: bật alarm trong `onCreate` (nếu đang sạc), tắt alarm trong `onStop`.
- Không có Android SDK/Kotlin compiler trong sandbox → không thể chạy `./gradlew build` để kiểm tra biên dịch tại đây.

## 4. Điều hướng (Bottom Navigation Bar)
- `src/main/java/MainActivity.kt`:
  - Đã xóa `HeaderSection` (menu trượt ngang trên cùng) và import không dùng.
  - Thêm `BottomNavBar()` — hàng menu dưới cùng 5 nút: Thiết Lập, Tối Ưu, Thông Báo, Pin, Thêm (nút cuối, màu xanh lá).
  - Nút "Thêm" bật `showAddGrid = true` → hiện `AddGridOverlay()` — overlay mờ nền (đen 45%), chứa lưới 2 cột các nút tính năng còn lại (Thời Tiết, Kết Nối, Dọn Ứng Dụng, Cài Đặt Chữ, Đa Hãng OEM, Máy In, Kho App, API Cá nhân, Tài Khoản, Đăng Nhập, Terminal, Quản Trị, Hỗ Trợ). Bấm nút lưới hoặc bấm vùng tối xung quanh để đóng và chuyển tab.
- `src/main/java/components/BottomNavBar.kt` (mới): composable `BottomNavBar` + data class `BottomNavItem`.
- `src/main/java/components/AddGridOverlay.kt` (mới): composable `AddGridOverlay` với lưới 2 cột 13 nút tính năng.

## 5. Cách build (khi có Android SDK)
- Cần tạo `google-services.json` (từ `google-services.json.example`) và `keystore.properties` (từ `keystore.properties.example`) hoặc build debug.
- Lệnh: `./gradlew assembleDebug` (cần `ANDROID_HOME`/`ANDROID_SDK_ROOT`).
