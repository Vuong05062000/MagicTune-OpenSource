package com.example.core.i18n

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Collections

object AppLanguageManager {
    private const val PREFS_NAME = "magictune_lang_prefs"
    private const val KEY_ENGLISH = "english_enabled"

    var isEnglish by mutableStateOf(false)
        private set

    @Volatile
    private var initialized = false

    private val translationCache: MutableMap<String, String> = Collections.synchronizedMap(
        object : LinkedHashMap<String, String>(512, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean = size > 1500
        }
    )

    fun init(context: Context) {
        if (initialized) return
        synchronized(this) {
            if (initialized) return
            initialized = true
            try {
                val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                isEnglish = prefs.getBoolean(KEY_ENGLISH, false)
            } catch (_: Throwable) {}
        }
    }

    fun isEnglish(context: Context): Boolean {
        if (!initialized) init(context)
        return isEnglish
    }

    fun toggle(context: Context) {
        val next = !isEnglish
        isEnglish = next
        initialized = true
        translationCache.clear()
        try {
            context.applicationContext
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_ENGLISH, next)
                .apply()
        } catch (_: Throwable) {}
        refreshAllAppWidgets(context)
    }

    private fun refreshAllAppWidgets(context: Context) {
        val appCtx = context.applicationContext ?: context
        val actions = listOf(
            "com.example.core.widget.ACTION_WIDGET_FORCE_REFRESH",
            "com.example.core.widget.ACTION_SIMPLE_BATTERY_REFRESH"
        )
        for (act in actions) {
            try {
                appCtx.sendBroadcast(Intent(act).setPackage(appCtx.packageName))
            } catch (_: Throwable) {}
        }
        val providerClasses = listOf(
            "com.example.core.widget.MagicTuneMemoryWidgetProvider",
            "com.example.core.widget.MagicTuneCalendarWeatherWidgetProvider",
            "com.example.core.widget.MagicTunePerpetualCalendarWidgetProvider",
            "com.example.core.widget.MagicTuneAppSearchWidgetProvider",
            "com.example.core.widget.MagicTunePrinterWidgetProvider"
        )
        val awm = try { AppWidgetManager.getInstance(appCtx) } catch (_: Throwable) { null } ?: return
        for (clsName in providerClasses) {
            try {
                val cls = Class.forName(clsName)
                val ids = awm.getAppWidgetIds(ComponentName(appCtx, cls))
                if (ids.isNotEmpty()) {
                    val intent = Intent(AppWidgetManager.ACTION_APPWIDGET_UPDATE).apply {
                        component = ComponentName(appCtx, cls)
                        putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                    }
                    appCtx.sendBroadcast(intent)
                }
            } catch (_: Throwable) {}
        }
    }

    fun tr(vi: String, en: String): String = if (isEnglish) en else vi

    fun tr(context: Context, vi: String, en: String): String {
        if (!initialized) init(context)
        return if (isEnglish) en else vi
    }

    fun tr(text: String): String {
        if (!isEnglish || text.isEmpty()) return text
        EXACT_VI_TO_EN[text]?.let { return it }
        translationCache[text]?.let { return it }
        val translated = translateByRules(text)
        translationCache[text] = translated
        return translated
    }

    fun tr(context: Context, text: String): String {
        if (!initialized) init(context)
        return tr(text)
    }

    private val viPrefixRegex = Regex("[àáảãạăằắẳẵặâầấẩẫậèéẻẽẹêềếểễệìíỉĩịòóỏõọôồốổỗộơờớởỡợùúủũụưừứửữựỳýỷỹỵđÀÁẢÃẠĂẰẮẲẴẶÂẦẤẨẪẬÈÉẺẼẸÊỀẾỂỄỆÌÍỈĨỊÒÓỎÕỌÔỒỐỔỖỘƠỜỚỞỠỢÙÚỦŨỤƯỪỨỬỮỰỲÝỶỸỴĐ]")

    private val compiledPhraseRules: List<Pair<Regex, String>> by lazy {
        PHRASE_VI_TO_EN.map { (vi, en) ->
            Regex("(?iu)(?<!\\p{L})${Regex.escape(vi)}(?!\\p{L})") to en
        }
    }

    private fun translateByRules(input: String): String {
        if (!viPrefixRegex.containsMatchIn(input)) return input
        var s = input
            .replace("[Ô #", "[Tile #")
            .replace("Ô #", "Tile #")
        for ((regex, en) in compiledPhraseRules) {
            if (regex.containsMatchIn(s)) {
                s = regex.replace(s, Regex.escapeReplacement(en))
            }
        }
        return s
    }

    private val EXACT_VI_TO_EN: Map<String, String> = mapOf(
        // Header & Navigation
        "Magictune Tool Miễn Phí Cho Android" to "Magictune Tool Free For Android",
        "Nền tối" to "Dark",
        "Trắng ngà" to "Ivory",
        "Kết nối" to "Connect",
        "Đã nối" to "Connected",
        "Hoàn tác" to "Revert",
        "An toàn" to "Safety",
        "Xuất APK" to "Export APK",
        "Hỗ trợ" to "Support",
        "Đủ quyền" to "Permitted",
        "Cấp quyền" to "Grant",
        "Tìm tên hoặc số ô (#00–#64, Pin 2x2...)" to "Search name or tile (#00–#64, Battery 2x2...)",
        "Tìm kiếm" to "Search",
        "Thiết Lập" to "Setup",
        "Tối Ưu" to "Optimize",
        "Thông Báo" to "Alerts",
        "Pin" to "Battery",
        "Thêm" to "More",
        "Thêm Tính Năng" to "More Features",
        "Chọn tính năng muốn mở" to "Choose a feature to open",
        "Thời Tiết" to "Weather",
        "Kết Nối" to "Connect",
        "Dọn Ứng Dụng" to "Debloat Apps",
        "Cài Đặt Chữ" to "Gestures",
        "Đa Hãng OEM" to "OEM Fix",
        "Máy In" to "Printer",
        "Kho App" to "App Store",
        "API Cá nhân" to "API Keys",
        "API Cá Nhân" to "Personal API",
        "Hỗ Trợ" to "Support",
        "Ủng hộ tác giả bằng tình cảm ❤️" to "Support the author ❤️",
        "Đăng ký YT" to "Subscribe YT",
        "Follow FB" to "Follow FB",
        "Bấm vùng tối xung quanh để đóng" to "Tap dimmed area to close",
        "An Toàn & Quyền Riêng Tư" to "Safety & Privacy",
        "AN TOÀN & QUYỀN RIÊNG TƯ" to "SAFETY & PRIVACY",
        "Xác nhận" to "Confirm",
        "Hủy" to "Cancel",
        "Đóng" to "Close",
        "Hoàn Tất" to "Done",
        "(Đã đủ quyền)" to "(All granted)",
        "(Để sau)" to "(Later)",
        "Bật" to "On",
        "Tắt" to "Off",
        "Đang chạy" to "Running",
        "Sẵn sàng" to "Ready",
        "Chưa kết nối" to "Not connected",
        "Đã kết nối" to "Connected",
        "Áp dụng" to "Apply",
        "Khôi phục" to "Restore",
        "Làm mới" to "Refresh",
        "Xóa" to "Clear",
        "Sao chép" to "Copy",
        "Lưu" to "Save",
        "Mở" to "Open",

        // Battery & Widgets
        "🔋 Đang dùng Pin" to "🔋 On Battery",
        "⚡ Sạc Ngâm Bù Ion 100%" to "⚡ Ion Trickle Charge 100%",
        "Tốt (Good)" to "Good",
        "Đang xả pin" to "Discharging",
        "Sạc nhanh" to "Fast Charge",
        "Siêu nhanh" to "Super Fast",
        "Sạc thường" to "Normal Charge",
        "Đang tính thời gian đầy..." to "Calculating time to full...",
        "Đã ngắt dòng an toàn" to "Charge safely stopped",
        "Đã no 100% thực tế • Hãy rút sạc" to "Fully saturated 100% • Unplug charger",
        "Đang nạp tiếp đến khi dòng về ≤ 1W" to "Trickle charging until ≤ 1W",
        "Nạp bù ion" to "Ion trickle charge",
        "Làm mới" to "Refresh",
        "Hạ nhiệt" to "Cool Down",
        "Cài đặt hệ thống" to "System Settings",
        "Bộ nhớ & Tiện ích" to "Memory & Tools",
        "Tìm Ứng Dụng & Ghi chú" to "App Search & Notes",
        "Gõ tên app hoặc bấm Bảng Vẽ..." to "Type app name or tap Draw...",
        "Vẽ chữ" to "Draw",
        "Đang nạp..." to "Charging...",

        // Main Screens & Titles
        "✅ Tất cả tính năng đã mở khóa miễn phí — không mất phí duy trì" to "✅ All features unlocked for free — zero subscription or cloud fees",
        "Lối Tắt AI Phân Tích Hao Pin & Siêu Tiết Kiệm Điện" to "AI Battery Drain Doctor & Ultra Power Saver",
        "ADB Shell Runner Pro" to "ADB Shell Runner",
        "Cửa Sổ Lệnh Đã Sẵn Sàng" to "Command Terminal Ready",
        "Xóa log" to "Clear logs",
        "Chạy lệnh" to "Run command",
        "Reset Khóa RSA" to "Reset RSA Keys",
        "Đổi vị trí" to "Change location",
        "Lịch Vạn Niên" to "Perpetual Calendar",
        "Cài Đặt Widget Thời Tiết" to "Weather Widget Settings",
        "Kiểm Soát Quyền Riêng Tư Cảm Biến Sâu" to "Deep Sensor Privacy Control",
        "📷 Khóa Camera" to "📷 Lock Camera",
        "🔓 Mở Camera" to "🔓 Unlock Camera",
        "🎙️ Khóa Micro" to "🎙️ Lock Mic",
        "🔓 Mở Micro" to "🔓 Unlock Mic",
        "📍 Khóa Vị Trí" to "📍 Lock Location",
        "🔓 Mở Vị Trí" to "🔓 Unlock Location",
        "📋 Chặn Đọc Copy" to "📋 Block Clipboard",
        "🔓 Mở Bộ Nhớ" to "🔓 Allow Clipboard",
        "Wi-Fi / LAN (9100)" to "Wi-Fi / LAN (9100)",
        "Bluetooth SPP" to "Bluetooth SPP",
        "Xác nhận xóa ứng dụng" to "Confirm App Removal",
        "Xóa Ngay" to "Delete Now",
        "Hủy Tải" to "Cancel Download",
        "Thu hồi hoàn tác" to "Revert changes"
    )

    // Ordered from longest to shortest for clean phrase substitution
    private val PHRASE_VI_TO_EN: List<Pair<String, String>> = listOf(
        "Ủng hộ tác giả bằng tình cảm" to "Support the author",
        "Tất cả tính năng đã mở khóa miễn phí" to "All features unlocked for free",
        "không mất phí duy trì" to "no maintenance fees",
        "Kiểm soát quyền riêng tư cảm biến cấp độ sâu" to "Deep sensor privacy control",
        "Kiểm Soát Quyền Riêng Tư Cảm Biến Sâu" to "Deep Sensor Privacy Control",
        "Khóa cứng Camera, Microphone, Vị trí GPS và Bộ nhớ tạm (Clipboard) chống nghe lén & theo dõi ngầm." to "System-level lock for Camera, Microphone, GPS Location, and Clipboard against background tracking.",
        "Dự báo thời tiết theo giờ (24 giờ tới tại" to "Hourly forecast (next 24h in",
        "Dự báo thời tiết 7 ngày tới" to "7-day weather forecast",
        "Kết nối Không Dây WLAN" to "Wireless ADB (WLAN)",
        "Kết nối LAN từ PC / LADB:" to "LAN connect from PC / LADB:",
        "Gõ 6 số (hoặc Cổng 6_Số, VD: 38475 123456)" to "Enter 6-digit PIN (or Port PIN, e.g. 38475 123456)",
        "Tự động điền hoặc gõ 5 số cổng (VD: 38475)" to "Auto-filled or enter 5-digit port (e.g. 38475)",
        "Cổng tự động điền khi bật Gỡ lỗi Wi-Fi" to "Port auto-filled when Wireless Debugging is enabled",
        "Thu hồi ủy quyền gỡ lỗi USB" to "Revoke USB debugging authorizations",
        "Cài đặt nhà phát triển" to "Developer Options",
        "Ẩn Trạng Thái Nhà Phát Triển" to "Hide Developer Mode Status",
        "Chặn Quảng Cáo Toàn Diện" to "System-wide AdBlocker",
        "Đo xả Sáng/Tắt màn" to "Screen-On/Off drain rate",
        "Sáng màn:" to "Screen On:",
        "Tắt màn chờ:" to "Screen Off:",
        "Sáng màn" to "Screen On",
        "Tắt màn chờ" to "Standby",
        "Tắt màn" to "Screen Off",
        "Đầy 100%" to "100% in",
        "No pin" to "Full saturation",
        "Nạp bù ion" to "Ion trickle",
        "Đang tính thời gian đầy" to "Estimating time to full",
        "Đã no 100% thực tế" to "Fully saturated 100%",
        "Hãy rút sạc" to "Unplug charger",
        "Siêu Tiết Kiệm Pin" to "Ultra Battery Saver",
        "Tiết Kiệm Pin" to "Battery Saver",
        "Siêu tiết kiệm pin" to "Ultra battery saver",
        "Tiết kiệm pin" to "Battery saver",
        "Độ phân giải" to "Resolution",
        "Tần số quét" to "Refresh rate",
        "Vân tay" to "Fingerprint",
        "Cường lực dày" to "Thick screen protector",
        "Cảm ứng" to "Touch sensitivity",
        "Máy In Nhiệt" to "Thermal Printer",
        "Máy in nhiệt" to "Thermal printer",
        "Kho Ứng Dụng" to "App Store",
        "Kho ứng dụng" to "App store",
        "Dọn Ứng Dụng" to "App Debloater",
        "Dọn ứng dụng" to "App debloater",
        "Ứng dụng chạy ngầm" to "Background apps",
        "Chạy ngầm" to "Background",
        "Đóng băng" to "Freeze",
        "Khôi phục" to "Restore",
        "Hoàn tác" to "Revert",
        "Gỡ bỏ" to "Uninstall",
        "Gỡ cài đặt" to "Uninstall",
        "Cài đặt" to "Settings",
        "Cài đè" to "Install",
        "Gỡ lỗi Wi-Fi" to "Wireless Debugging",
        "Gỡ lỗi USB" to "USB Debugging",
        "Kết nối" to "Connect",
        "Đã kết nối" to "Connected",
        "Ngắt kết nối" to "Disconnect",
        "Chưa kết nối" to "Disconnected",
        "Chẩn đoán" to "Diagnostics",
        "Kiểm tra" to "Check",
        "Làm mới" to "Refresh",
        "Hạ nhiệt" to "Cool Down",
        "Nhiệt độ" to "Temperature",
        "Dung lượng" to "Capacity",
        "Thời lượng" to "Duration",
        "Ước tính" to "Estimated",
        "Thông báo" to "Notifications",
        "Quyền riêng tư" to "Privacy",
        "Bảo mật" to "Security",
        "An toàn" to "Safety",
        "Hệ thống" to "System",
        "Ứng dụng" to "Apps",
        "Màn hình chính" to "Home screen",
        "Màn hình" to "Screen",
        "Âm thanh" to "Audio",
        "Tai nghe" to "Headphones",
        "Loa ngoài" to "Speaker",
        "Xe hơi" to "Car",
        "Ngân hàng" to "Banking",
        "Bộ nhớ tạm" to "Clipboard",
        "Bộ nhớ" to "Storage",
        "Tự động hóa" to "Automation",
        "Tự động" to "Auto",
        "Tăng tốc" to "Boost",
        "Tối ưu hóa" to "Optimization",
        "Tối ưu" to "Optimize",
        "Hỗ trợ trực tuyến" to "Live Support",
        "Hỗ trợ" to "Support",
        "Tìm kiếm" to "Search",
        "Chọn tệp" to "Pick file",
        "Chọn file" to "Pick file",
        "Xem trước" to "Preview",
        "Khổ giấy" to "Paper size",
        "Cắt giấy" to "Cut paper",
        "Độ đậm" to "Density",
        "Căn lề" to "Margins",
        "Vẽ chữ" to "Draw letter",
        "Mở nhanh" to "Quick launch",
        "Nút nguồn" to "Power button",
        "Nhấn đúp" to "Double press",
        "Đa hãng" to "Multi-OEM",
        "Trợ năng" to "Accessibility",
        "Quyền hạn" to "Permissions",
        "Cấp quyền" to "Grant permission",
        "Đủ quyền" to "Granted",
        "Sao chép" to "Copy",
        "Đã sao chép" to "Copied",
        "Thành công" to "Succeeded",
        "Thất bại" to "Failed",
        "Cảnh báo" to "Warning",
        "Xác nhận" to "Confirm",
        "Đồng ý" to "Agree",
        "Đang tải" to "Loading",
        "Đang chạy" to "Running",
        "Đang xử lý" to "Processing",
        "Chưa có" to "None",
        "Sẵn sàng" to "Ready",
        "Bấm vào" to "Tap",
        "Bấm để" to "Tap to",
        "Bấm" to "Tap",
        "Hiện tại" to "Current",
        "Mặc định" to "Default",
        "Tùy chỉnh" to "Custom",
        "Miễn phí" to "Free",
        "Thủ công" to "Manual",
        "Hoạt ảnh" to "Animation",
        "Nóng máy" to "Overheating",
        "Hao pin" to "Battery drain",
        "Sạc pin" to "Charging",
        "Vị trí" to "Location",
        "Thời tiết" to "Weather",
        "Độ ẩm" to "Humidity",
        "Tốc độ gió" to "Wind speed",
        "Tầm nhìn" to "Visibility",
        "Chỉ số UV" to "UV Index",
        "Áp suất" to "Pressure",
        "Chất lượng không khí" to "Air Quality",
        "Lịch âm" to "Lunar calendar",
        "Âm lịch" to "Lunar",
        "Dương lịch" to "Solar",
        "Tháng Nhuận" to "Leap Month",
        "Nhuận" to "Leap",
        "Ngày" to "Day",
        "Tháng" to "Month",
        "Năm" to "Year",
        "Giờ" to "Hour",
        "Phút" to "Min",
        "giây" to "s",
        "phút" to "m",
        "giờ" to "h",
        "Cấp độ" to "Level",
        "Chế độ" to "Mode",
        "Trạng thái" to "Status",
        "Chi tiết" to "Details",
        "Danh sách" to "List",
        "Thiết bị" to "Device",
        "Cảm biến" to "Sensors",
        "Dịch vụ" to "Service",
        "Tiến trình" to "Process",
        "Đóng" to "Close",
        "Hủy" to "Cancel",
        "Lưu" to "Save",
        "Xóa" to "Clear",
        "Bật" to "Enable",
        "Tắt" to "Disable",
        "Khóa" to "Lock",
        "Mở" to "Open",
        "và" to "and",
        "của" to "of",
        "cho" to "for",
        "trên" to "on",
        "từ" to "from",
        "với" to "with",
        "tại" to "at"
    )
}
