package com.example.core.widget

import com.example.core.i18n.AppLanguageManager.tr

import com.example.core.perf.ScreenPowerOptimizer
import com.example.MainActivity
import com.example.core.license.LicenseManager

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewTreeObserver
import android.view.WindowManager
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.example.core.service.NoAccessibilityScreenEngine
import com.example.core.shell.ShellEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale
import android.media.MediaPlayer
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToLong

/**
 * Công cụ Dịch Màn Hình Tức Thì 100% Bằng GOOGLE DỊCH (`translate.googleapis.com`)
 * Kết hợp Quy Đổi Tiền Tệ Tự Động sang VNĐ (Tệ ¥/RMB/CNY, Đô la $, Won ₩, Yên 円, Euro €...)
 * và Lớp Phủ Xuyên Thấu "CUỘN ĐẾN ĐÂU DỊCH ĐẾN ĐÓ" chuyên dụng cho Taobao, 1688, Tmall, Pinduoduo & App Ngoại Ngữ.
 *
 * Lưu ý kiến trúc:
 * - TUYỆT ĐỐI KHÔNG DÙNG GROQ AI ở đây (Groq chỉ dành riêng cho Chatbot Hỗ Trợ Người Dùng & Đọc Bill).
 * - Tốc độ phản hồi cực nhanh (~80-150ms cho trang mới, 0ms cho các dòng đã lưu trong bộ nhớ đệm khi cuộn lên/xuống).
 * - Kích thước chữ bản dịch nhỏ gọn (8.5sp - 9.5sp) nhỏ hơn văn bản gốc và tự động né nhau (Collision Avoidance).
 */
object GoogleScreenTranslator {

    private val translationCacheLock = Any()
    private val translationCache = object : LinkedHashMap<String, String>(256, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean = size > 1500
    }
    private val inFlightTexts = ConcurrentHashMap.newKeySet<String>()

    // =========================================================================
    // BỘ ĐỆM MẠNG THÍCH ỨNG & THỜI GIAN HỒI (ADAPTIVE NETWORK COOLDOWN 8s - 15s)
    // Tự động kéo dài thời gian hồi và áp dụng Exponential Backoff để khống chế
    // mức tiêu thụ radio mạng (4G/5G/Wi-Fi) dưới ngưỡng khắt khe < 50 mAh/giờ.
    // =========================================================================
    private val networkAttemptCooldown = ConcurrentHashMap<String, Long>()
    private val consecutiveFailures = ConcurrentHashMap<String, Int>()

    private const val BASE_NETWORK_COOLDOWN_MS = 8_000L       // Tăng từ 4s lên 8s làm mặc định
    private const val THROTTLED_NETWORK_COOLDOWN_MS = 14_000L  // 14s khi đang tiết lưu hoặc pin < 20%
    private const val MAX_BACKOFF_COOLDOWN_MS = 30_000L        // Tối đa 30s khi liên tục không có văn bản mới

    fun getEffectiveNetworkCooldownMs(): Long {
        return if (com.example.core.perf.PowerBudgetGuard.isThrottleActive()) {
            THROTTLED_NETWORK_COOLDOWN_MS
        } else {
            BASE_NETWORK_COOLDOWN_MS
        }
    }

    fun isNetworkCooldownActive(key: String): Boolean {
        val lastAttempt = networkAttemptCooldown[key] ?: return false
        val now = System.currentTimeMillis()
        val fails = consecutiveFailures[key] ?: 0
        // Exponential backoff: cooldown * (1.0 + fails * 0.5), tối đa 30s
        val cooldown = (getEffectiveNetworkCooldownMs() * (1.0 + (fails * 0.5))).toLong().coerceAtMost(MAX_BACKOFF_COOLDOWN_MS)
        if (now - lastAttempt < cooldown) {
            return true
        }
        networkAttemptCooldown.remove(key)
        return false
    }

    fun recordNetworkAttempt(key: String, wasSuccessful: Boolean = true) {
        networkAttemptCooldown[key] = System.currentTimeMillis()
        if (wasSuccessful) {
            consecutiveFailures.remove(key)
        } else {
            val prev = consecutiveFailures[key] ?: 0
            consecutiveFailures[key] = (prev + 1).coerceAtMost(5)
        }
        if (networkAttemptCooldown.size > 800) {
            val cutoff = System.currentTimeMillis() - MAX_BACKOFF_COOLDOWN_MS
            networkAttemptCooldown.entries.removeIf { it.value < cutoff }
            consecutiveFailures.entries.removeIf { !networkAttemptCooldown.containsKey(it.key) }
        }
    }

    private fun getCachedTranslation(key: String): String? =
        synchronized(translationCacheLock) { translationCache[key] }

    private fun hasCachedTranslation(key: String): Boolean =
        synchronized(translationCacheLock) { translationCache.containsKey(key) }

    private fun putCachedTranslation(key: String, value: String) {
        synchronized(translationCacheLock) { translationCache[key] = value }
    }

    // Tỷ giá quy đổi xấp xỉ sang VNĐ phục vụ mua sắm quốc tế (Taobao, 1688, Amazon, Hàn, Nhật...)
    private const val RATE_CNY_TO_VND = 3550.0     // 1 Nhân dân tệ (¥ / 元 / RMB) ≈ 3.550đ
    private const val RATE_USD_TO_VND = 25400.0    // 1 USD ($) ≈ 25.400đ
    private const val RATE_KRW_TO_VND = 18.5       // 1 Won Hàn Quốc (₩ / 원) ≈ 18.5đ
    private const val RATE_JPY_TO_VND = 170.0      // 1 Yên Nhật (円 / JPY) ≈ 170đ
    private const val RATE_EUR_TO_VND = 27500.0    // 1 Euro (€) ≈ 27.500đ
    private const val RATE_GBP_TO_VND = 32500.0    // 1 Bảng Anh (£) ≈ 32.500đ
    private const val RATE_THB_TO_VND = 740.0      // 1 Baht Thái (฿) ≈ 740đ
    private const val RATE_TWD_TO_VND = 790.0      // 1 Đài tệ (NT$) ≈ 790đ

    // Từ điển thuật ngữ mua sắm Taobao / 1688 / Tmall / Pinduoduo giúp dịch tức thì 0ms và chuẩn ngữ cảnh mua hàng
    private val ecommerceQuickGlossary = listOf(
        "加入购物车" to "Thêm vào giỏ",
        "立即购买" to "Mua ngay",
        "立即抢购" to "Săn ngay",
        "领券购买" to "Nhận mã & Mua",
        "券后价" to "Giá sau mã",
        "券后" to "Sau mã",
        "到手价" to "Giá về tay",
        "折后价" to "Giá sau giảm",
        "活动价" to "Giá KM",
        "批发价" to "Giá sỉ",
        "包邮" to "Freeship",
        "满减" to "Giảm theo đơn",
        "运费险" to "BH vận chuyển",
        "退货宝" to "Hỗ trợ trả hàng",
        "七天无理由退换" to "Đổi trả 7 ngày",
        "7天无理由退货" to "Đổi trả 7 ngày",
        "48小时内发货" to "Giao trong 48h",
        "24小时内发货" to "Giao trong 24h",
        "已售" to "Đã bán ",
        "万人付款" to " vạn người mua",
        "人付款" to " người mua",
        "人已买" to " người đã mua",
        "回头客" to "Khách quay lại",
        "好评率" to "Tỷ lệ khen",
        "好评" to "Đánh giá tốt",
        "宝贝评价" to "Đánh giá SP",
        "查看全部" to "Xem tất cả",
        "进店逛逛" to "Vào xem shop",
        "进店" to "Vào shop",
        "店铺" to "Cửa hàng",
        "客服" to "CSKH",
        "收藏" to "Lưu",
        "购物车" to "Giỏ hàng",
        "我的淘宝" to "Taobao của tôi",
        "猜你喜欢" to "Gợi ý cho bạn",
        "百亿补贴" to "Trợ giá tỷ tệ",
        "官方旗舰店" to "Shop Chính Hãng",
        "旗舰店" to "Flagship Store",
        "起批" to "Sỉ từ",
        "成交" to "Đã giao dịch",
        "复购率" to "Tỷ lệ mua lại",
        "件起批" to " sp sỉ",
        "选择规格" to "Chọn phân loại",
        "规格" to "Phân loại",
        "参数" to "Thông số",
        "详情" to "Chi tiết",
        "评价" to "Đánh giá",
        "推荐" to "Đề xuất",
        "现货" to "Hàng sẵn",
        "代发" to "Dropship",
        "一件代发" to "Sỉ lẻ 1 cái",
        "进货单" to "Đơn nhập sỉ"
    )

    private val vndFormatter = DecimalFormat("#,###", DecimalFormatSymbols(Locale.US).apply {
        groupingSeparator = '.'
    })

    /**
     * Định dạng số tiền VNĐ ngắn gọn để hộp chữ dịch luôn nhỏ gọn, không làm chật màn hình Taobao / 1688.
     */
    fun formatVndCompact(vndAmount: Double): String {
        val rounded = vndAmount.roundToLong()
        return when {
            rounded <= 0L -> "0đ"
            rounded < 10_000L -> "${vndFormatter.format(rounded)}đ"
            rounded < 1_000_000L -> {
                val k = rounded / 1000.0
                if (k >= 100 || k % 1.0 == 0.0) {
                    "${k.roundToLong()}k đ"
                } else {
                    String.format(Locale.US, "%.1fk đ", k).replace(".0k", "k")
                }
            }
            else -> {
                val tr = rounded / 1_000_000.0
                String.format(Locale.US, "%.2ftr đ", tr)
                    .replace(".00tr", "tr")
                    .replace(Regex("""(\.\d)0tr"""), "$1tr")
                    .replace('.', ',')
            }
        }
    }

    /**
     * Nhận diện giá tiền ngoại tệ (¥, ￥, 元, RMB, CNY, $, USD, ₩, KRW, 円, JPY, €, £, ฿, NT$)
     * và quy đổi sang VNĐ. Hỗ trợ cả khoảng giá (ví dụ: ¥19.9-39.9 -> ≈ 71k-142k đ), đơn vị 万 (vạn = 10.000),
     * và giá chính trên 1688 khi số nguyên + phần thập phân `.00`/`.50` đứng độc lập.
     */
    fun convertForeignPricesToVnd(originalText: String, translatedText: String): String {
        val source = originalText.trim()
        var result = translatedText.trim().ifBlank { source }

        val isJapaneseContext = source.any { it in '\u3040'..'\u309F' || it in '\u30A0'..'\u30FF' } ||
            source.contains("円") || source.contains("税込") || source.contains("JPY", ignoreCase = true)

        // 1. Kiểm tra khoảng giá trước: Ví dụ "¥ 19.9 - 39.9" hoặc "$10 - $20"
        val rangeRegex = Regex(
            """(NT\$|US\$|RMB|CNY|USD|KRW|JPY|EUR|GBP|THB|[¥￥\$₩€£฿])?\s*(\d{1,7}(?:[.,]\d{1,2})?)\s*[-~～]\s*[¥￥\$₩€£฿]?\s*(\d{1,7}(?:[.,]\d{1,2})?)\s*(元|円|원|块)?""",
            RegexOption.IGNORE_CASE
        )
        val rangeMatch = rangeRegex.find(source)
        if (rangeMatch != null) {
            val prefix = rangeMatch.groupValues[1].uppercase()
            val suffix = rangeMatch.groupValues[4]
            if (prefix.isNotEmpty() || suffix.isNotEmpty()) {
                val v1 = rangeMatch.groupValues[2].replace(",", ".").toDoubleOrNull()
                val v2 = rangeMatch.groupValues[3].replace(",", ".").toDoubleOrNull()
                val rate = resolveCurrencyRate(prefix, suffix, isJapaneseContext)
                if (v1 != null && v2 != null && rate > 0.0 && v1 > 0 && v2 >= v1) {
                    val vndRange = "≈ ${formatVndCompact(v1 * rate)} - ${formatVndCompact(v2 * rate)}"
                    if (!result.contains("đ") && !result.contains("VNĐ", ignoreCase = true)) {
                        return "$result ($vndRange)"
                    }
                }
            }
        }

        // 2. Kiểm tra mức giá đơn: Ví dụ "¥128", "￥39.90", "128元", "券后¥89", "$24.99", "15,000원", "¥1.2万", "¥128/件"
        val singlePriceRegex = Regex(
            """(NT\$|US\$|RMB|CNY|USD|KRW|JPY|EUR|GBP|THB|[¥￥\$₩€£฿])\s*(\d{1,7}(?:[.,]\d{1,2})?)\s*(万)?|(\d{1,7}(?:[.,]\d{1,2})?)\s*(万)?\s*(元|円|원|块|RMB|CNY|USD|KRW|JPY)""",
            RegexOption.IGNORE_CASE
        )

        val matches = singlePriceRegex.findAll(source).toList()
        if (matches.isNotEmpty() && !result.contains("≈") && !result.contains("k đ") && !result.contains("tr đ")) {
            val first = matches.first()
            val prefixSymbol = first.groupValues[1].uppercase()
            val numStr1 = first.groupValues[2]
            val wan1 = first.groupValues[3]
            val numStr2 = first.groupValues[4]
            val wan2 = first.groupValues[5]
            val suffixSymbol = first.groupValues[6].uppercase()

            val rawNumberStr = numStr1.ifEmpty { numStr2 }
            val hasWan = wan1.isNotEmpty() || wan2.isNotEmpty()
            val rate = resolveCurrencyRate(prefixSymbol, suffixSymbol, isJapaneseContext)

            val parsedValue = parsePriceNumber(rawNumberStr, prefixSymbol, suffixSymbol)
            if (parsedValue != null && parsedValue > 0.0 && rate > 0.0) {
                val multiplier = if (hasWan) 10_000.0 else 1.0
                val vndValue = parsedValue * multiplier * rate
                val vndFormatted = formatVndCompact(vndValue)

                if (source.length <= 20) {
                    val cleanOrigPrice = first.value.replace(" ", "")
                    val prefixLabel = when {
                        source.contains("券后") -> "Sau mã: "
                        source.contains("到手") -> "Về tay: "
                        source.contains("折后") -> "Giảm còn: "
                        source.contains("起批") -> "Giá sỉ: "
                        else -> ""
                    }
                    return "$prefixLabel$cleanOrigPrice (≈ $vndFormatted)"
                } else {
                    result = "$result (≈ $vndFormatted)"
                }
            }
        }

        // 3. Đặc trị giá chính trên 1688/Taobao khi ký hiệu ¥ bị vẽ bằng ảnh icon riêng và chỉ còn số thập phân dạng "128.50" hoặc "39.90"
        val standaloneDecimalCnyRegex = Regex("""^(券后|到手价|折后|原价|一口价|批发价)?\s*(\d{1,6}\.\d{1,2})\s*(起|/[件个双套箱包条斤])?$""")
        val standaloneMatch = standaloneDecimalCnyRegex.matchEntire(source)
        if (standaloneMatch != null && !result.contains("≈")) {
            val numVal = standaloneMatch.groupValues[2].toDoubleOrNull()
            if (numVal != null && numVal >= 0.5 && numVal <= 999_999.0) {
                val vndFormatted = formatVndCompact(numVal * RATE_CNY_TO_VND)
                return "¥${standaloneMatch.groupValues[2]} (≈ $vndFormatted)"
            }
        }

        return result
    }

    private fun parsePriceNumber(raw: String, prefix: String, suffix: String): Double? {
        val isKrwOrJpy = prefix == "₩" || prefix == "KRW" || suffix == "원" || suffix == "円" || prefix == "JPY"
        return if (isKrwOrJpy && raw.contains(",")) {
            raw.replace(",", "").toDoubleOrNull()
        } else if (raw.count { it == ',' } == 1 && raw.substringAfter(',').length == 3 && !raw.contains('.')) {
            raw.replace(",", "").toDoubleOrNull()
        } else {
            raw.replace(",", ".").toDoubleOrNull()
        }
    }

    private fun resolveCurrencyRate(prefix: String, suffix: String, isJapaneseContext: Boolean): Double {
        val token = prefix.ifEmpty { suffix }.uppercase()
        return when {
            token == "NT$" -> RATE_TWD_TO_VND
            token == "US$" || token == "$" || token == "USD" -> RATE_USD_TO_VND
            token == "₩" || token == "KRW" || token == "원" -> RATE_KRW_TO_VND
            token == "円" || token == "JPY" -> RATE_JPY_TO_VND
            token == "€" || token == "EUR" -> RATE_EUR_TO_VND
            token == "£" || token == "GBP" -> RATE_GBP_TO_VND
            token == "฿" || token == "THB" -> RATE_THB_TO_VND
            token == "¥" || token == "￥" -> if (isJapaneseContext) RATE_JPY_TO_VND else RATE_CNY_TO_VND
            token == "元" || token == "块" || token == "RMB" || token == "CNY" -> RATE_CNY_TO_VND
            else -> 0.0
        }
    }

    /**
     * Kiểm tra một chuỗi văn bản trên màn hình có cần dịch hoặc quy đổi tiền tệ hay không.
     * Bỏ qua các số thuần túy không có đơn vị tiền tệ và bỏ qua văn bản thuần Tiếng Việt của hệ thống.
     */
    fun shouldTranslateOrConvertNode(text: String): Boolean {
        val trimmed = text.trim()
        if (trimmed.isEmpty() || trimmed.length > 520) return false

        // Nếu có ký hiệu tiền tệ kèm chữ số -> LUÔN DỊCH & QUY ĐỔI TIỀN TỆ!
        val hasCurrency = trimmed.any { it in "¥￥$₩€£฿元円원" } ||
            Regex("""\b(RMB|CNY|USD|KRW|JPY|EUR|NT\$)\b""", RegexOption.IGNORE_CASE).containsMatchIn(trimmed)
        val hasDigit = trimmed.any { it.isDigit() }
        if (hasCurrency && hasDigit) return true

        // Nếu là giá thập phân chuẩn kiểu 1688/Taobao (ví dụ "128.00", "39.90") khi ký hiệu ¥ là icon ảnh
        if (Regex("""^\d{1,6}\.\d{2}$""").matches(trimmed)) return true

        // Nếu có chữ Trung / Nhật / Hàn / Thái / Nga / Ả Rập / Hindi -> LUÔN DỊCH!
        val hasCjkOrForeignScript = trimmed.any { ch ->
            val code = ch.code
            code in 0x4E00..0x9FFF || // CJK Unified Ideographs (Tiếng Trung / Kanji)
                code in 0x3400..0x4DBF || // CJK Extension A
                code in 0x20000..0x2A6DF || // CJK Extension B
                code in 0xF900..0xFAFF || // CJK Compatibility
                code in 0x2E80..0x2EFF || // CJK Radicals
                code in 0x3000..0x303F || // CJK Symbols and Punctuation
                code in 0x3040..0x309F || // Hiragana
                code in 0x30A0..0x30FF || // Katakana
                code in 0x31F0..0x31FF || // Katakana Phonetic Extensions
                code in 0xAC00..0xD7AF || // Hangul Syllables (Tiếng Hàn)
                code in 0x1100..0x11FF || // Hangul Jamo
                code in 0x3130..0x318F || // Hangul Compatibility Jamo
                code in 0x0E00..0x0E7F || // Tiếng Thái
                code in 0x0400..0x04FF || // Cyrillic (Tiếng Nga)
                code in 0x0600..0x06FF || // Arabic
                code in 0x0900..0x097F    // Devanagari (Hindi)
        }
        if (hasCjkOrForeignScript) return true

        // Nếu có chữ cái Latinh nhưng KHÔNG chứa dấu đặc trưng Tiếng Việt -> Dịch sang Tiếng Việt
        val hasLatinLetter = trimmed.any { it in 'a'..'z' || it in 'A'..'Z' }
        if (!hasLatinLetter) return false

        val vietnameseSpecificChars = "ăâđêôơưĂÂĐÊÔƠƯáàảãạấầẩẫậắằẳẵặéèẻẽẹếềểễệíìỉĩịóòỏõọốồổỗộớờởỡợúùủũụứừửữựýỳỷỹỵ"
        val vietCount = trimmed.count { it in vietnameseSpecificChars }
        if (vietCount >= 1) return false

        return trimmed.length >= 2
    }

    private val purePriceFastRegex = Regex(
        """^(券后|到手价|折后|原价|一口价|批发价)?\s*(NT\$|US\$|RMB|CNY|USD|KRW|JPY|[¥￥\$₩€£฿])?\s*\d+([.,]\d+)?(\s*[-~～]\s*[¥￥\$₩€£฿]?\s*\d+([.,]\d+)?)?\s*(万|元|円|원|块|起|/[件个双套箱包条斤])?$""",
        RegexOption.IGNORE_CASE
    )

    /**
     * Dịch một câu đơn lẻ bằng Google Translate (`translate.googleapis.com`) kèm quy đổi tiền tệ VNĐ.
     */
    fun translateSingleTextWithGoogle(rawText: String): String = translateSingleTextWithGoogle(rawText) {}

    private fun translateSingleTextWithGoogle(rawText: String, checkActive: () -> Unit): String {
        checkActive()
        val clean = rawText.trim().replace("\n", " ")
        if (clean.isEmpty()) return ""

        getCachedTranslation(clean)?.let { return it }

        // Nếu chỉ là giá tiền thuần túy (ví dụ: "19.90", "128.50", "¥128.50", "￥39.9", "$19.99") -> Quy đổi tức thì 0ms!
        if (purePriceFastRegex.matches(clean)) {
            val converted = convertForeignPricesToVnd(clean, clean)
            putCachedTranslation(clean, converted)
            return converted
        }

        // Kiểm tra từ điển thuật ngữ Taobao/1688 khớp chính xác 100% -> 0ms!
        ecommerceQuickGlossary.firstOrNull { it.first.equals(clean, ignoreCase = true) }?.let { (_, vn) ->
            putCachedTranslation(clean, vn)
            return vn
        }

        // BƯỚC 5: Tránh spam request nếu chuỗi vừa được gọi trong 4 giây qua
        if (isNetworkCooldownActive(clean)) {
            return clean
        }
        recordNetworkAttempt(clean)

        var conn: HttpURLConnection? = null
        try {
            val encoded = URLEncoder.encode(clean, "UTF-8")
            val url = URL("https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=vi&dt=t&q=$encoded")
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 2_200
                readTimeout = 2_500
                setRequestProperty("User-Agent", "GoogleTranslate/6.28.0.05.421483610 (Linux; U; Android 14)")
                setRequestProperty("Connection", "Keep-Alive")
            }
            if (conn.responseCode in 200..299) {
                val response = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                val rootArray = JSONArray(response)
                val sentences = rootArray.optJSONArray(0)
                val sb = StringBuilder()
                if (sentences != null) {
                    for (i in 0 until sentences.length()) {
                        val seg = sentences.optJSONArray(i)?.optString(0, "").orEmpty()
                        sb.append(seg)
                    }
                }
                val googleTranslated = sb.toString().trim()
                if (googleTranslated.isNotBlank()) {
                    val finalTranslated = if (!googleTranslated.equals(clean, ignoreCase = true)) {
                        convertForeignPricesToVnd(clean, googleTranslated)
                    } else {
                        clean
                    }
                    putCachedTranslation(clean, finalTranslated)
                    return finalTranslated
                }
            }
        } catch (_: Throwable) {
        } finally {
            try { conn?.disconnect() } catch (_: Throwable) {}
        }

        // Dự phòng cấp 2: clients5.google.com (Hạ tầng Google Translate chống nghẽn 429)
        checkActive()
        var conn2: HttpURLConnection? = null
        try {
            val encoded = URLEncoder.encode(clean, "UTF-8")
            val url2 = URL("https://clients5.google.com/translate_a/t?client=dict-chrome-ex&sl=auto&tl=vi&q=$encoded")
            conn2 = (url2.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 3_500
                readTimeout = 3_500
                setRequestProperty("User-Agent", "GoogleTranslate/6.28.0.05.421483610 (Linux; U; Android 14)")
                setRequestProperty("Connection", "Keep-Alive")
            }
            if (conn2.responseCode in 200..299) {
                val response2 = conn2.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                val rootArray2 = JSONArray(response2)
                val firstArr = rootArray2.optJSONArray(0)
                val translated = firstArr?.optString(0, "").orEmpty().trim()
                if (translated.isNotBlank()) {
                    val finalTranslated = if (!translated.equals(clean, ignoreCase = true)) {
                        convertForeignPricesToVnd(clean, translated)
                    } else {
                        clean
                    }
                    putCachedTranslation(clean, finalTranslated)
                    return finalTranslated
                }
            }
        } catch (_: Throwable) {
        } finally {
            try { conn2?.disconnect() } catch (_: Throwable) {}
        }

        // Dự phòng cấp 3: Tra cứu từ điển mua sắm Taobao / 1688 theo cụm từ
        val glossaryMatch = ecommerceQuickGlossary.firstOrNull { clean.contains(it.first, ignoreCase = true) }
        if (glossaryMatch != null) {
            val approx = convertForeignPricesToVnd(clean, glossaryMatch.second)
            putCachedTranslation(clean, approx)
            return approx
        }

        val fallback = convertForeignPricesToVnd(clean, clean)
        putCachedTranslation(clean, fallback)
        return fallback
    }

    /**
     * Dịch tin nhắn trò chuyện thông minh theo đúng nghĩa Tiếng Việt giao tiếp đời thực:
     * - Xử lý trước các từ lóng, viết tắt tiếng Anh & thuật ngữ chat 1688 / Taobao / WeChat / Pinduoduo
     *   để Google Neural Translate không bao giờ dịch cứng nhắc từng chữ (ví dụ: "亲" -> "Bạn ơi", "拍下改价" -> "lên đơn để shop sửa lại giá").
     * - Hậu xử lý câu tiếng Việt cho tự nhiên, mượt mà, dễ hiểu nhất với người Việt.
     */
    fun translateChatMessageNaturally(rawText: String): String {
        val rawTrimmed = rawText.trim()
        if (rawTrimmed.isEmpty()) return ""

        // Tiền xử lý các từ lóng chat & thuật ngữ thương mại điện tử trước khi dịch
        var normalizedInput = rawTrimmed
            // Thuật ngữ chat 1688 / Taobao / WeChat phổ biến hay bị dịch máy sai nghĩa
            .replace(Regex("""^亲[，,、!\s]*"""), "Bạn ơi, ")
            .replace(Regex("""[，,、\s]+亲([！!。.\s]*)$"""), ", bạn nhé$1")
            .replace("在的亲", "Mình đang trực đây bạn ơi")
            .replace("拍下改价", "đặt đơn rồi mình sửa lại giá cho nhé")
            .replace("拍下备注", "đặt đơn rồi ghi chú giúp mình")
            .replace("今天拍下", "hôm nay đặt đơn")
            .replace("现在拍下", "đặt đơn ngay bây giờ")
            .replace("可以拍", "có thể đặt đơn")
            .replace("直接拍", "cứ đặt đơn trực tiếp")
            .replace("有现货", "đang có sẵn hàng")
            .replace("现货秒发", "hàng có sẵn giao ngay")
            .replace("不包邮", "chưa bao gồm phí vận chuyển")
            .replace("包邮", "miễn phí vận chuyển")
            .replace("一件代发", "nhận sỉ lẻ từ 1 chiếc")
            .replace("起批", "lấy sỉ từ")
            // Từ viết tắt tiếng Anh phổ biến trong Messenger / Telegram / WhatsApp / Zalo
            .replace(Regex("""\blmk\b""", RegexOption.IGNORE_CASE), "let me know")
            .replace(Regex("""\btbh\b""", RegexOption.IGNORE_CASE), "to be honest")
            .replace(Regex("""\bngl\b""", RegexOption.IGNORE_CASE), "to be honest")
            .replace(Regex("""\bidk\b""", RegexOption.IGNORE_CASE), "I do not know")
            .replace(Regex("""\bimo\b""", RegexOption.IGNORE_CASE), "in my opinion")
            .replace(Regex("""\bimho\b""", RegexOption.IGNORE_CASE), "in my opinion")
            .replace(Regex("""\basap\b""", RegexOption.IGNORE_CASE), "as soon as possible")
            .replace(Regex("""\bbrb\b""", RegexOption.IGNORE_CASE), "I will be right back")
            .replace(Regex("""\bbtw\b""", RegexOption.IGNORE_CASE), "by the way")
            .replace(Regex("""\bomw\b""", RegexOption.IGNORE_CASE), "I am on my way")
            .replace(Regex("""\btysm\b""", RegexOption.IGNORE_CASE), "thank you so much")
            .replace(Regex("""\bthx\b""", RegexOption.IGNORE_CASE), "thank you")
            .replace(Regex("""\bpls\b|\bplz\b""", RegexOption.IGNORE_CASE), "please")

        val rawTranslated = translateSingleTextWithGoogle(normalizedInput)
        val priceEnriched = convertForeignPricesToVnd(rawTrimmed, rawTranslated)

        return priceEnriched
            .replace(Regex("""(?i)\bcha mẹ\b"""), "bạn ơi")
            .replace(Regex("""(?i)^hôn[,\s]+"""), "Bạn ơi, ")
            .replace(Regex("""(?i)\bchụp ảnh và thay đổi giá\b"""), "lên đơn rồi sửa lại giá")
            .replace(Regex("""\s+"""), " ")
            .trim()
    }

    /**
     * Chuẩn hóa chuỗi bản dịch trước khi đọc bằng giọng nói TTS Tiếng Việt:
     * Biến các ký hiệu tiền tệ / viết tắt như "≈ 454k đ", "1,2tr đ", "¥128" thành lời nói Tiếng Việt tự nhiên.
     */
    fun formatTranslationForNaturalVietnameseSpeech(text: String): String {
        return text
            .replace("**", "")
            .replace("*", "")
            // Tránh đọc cả giá gốc ký hiệu lẫn giá quy đổi gây dài dòng: nếu có "(≈ 454k đ)" thì đọc mượt thành "khoảng 454 nghìn đồng"
            .replace(Regex("""[¥￥]\s*(\d+(?:[.,]\d+)?)\s*\(≈\s*([^)]+)\)"""), "$1 tệ, tức khoảng $2")
            .replace(Regex("""\$\s*(\d+(?:[.,]\d+)?)\s*\(≈\s*([^)]+)\)"""), "$1 đô la, tức khoảng $2")
            .replace(Regex("""\(≈\s*([^)]+)\)"""), ", tức khoảng $1")
            .replace("≈", "khoảng ")
            .replace(Regex("""(\d+(?:[.,]\d+)?)k\s*đ\b""", RegexOption.IGNORE_CASE), "$1 nghìn đồng")
            .replace(Regex("""(\d+(?:[.,]\d+)?)tr\s*đ\b""", RegexOption.IGNORE_CASE), "$1 triệu đồng")
            .replace(Regex("""(\d+(?:\.\d{3})+)đ\b"""), "$1 đồng")
            .replace(Regex("""[¥￥]\s*(\d+(?:[.,]\d+)?)"""), "$1 tệ")
            .replace(Regex("""\s+"""), " ")
            .trim()
    }

    /**
     * Pha 1 (0ms - Tức thì): Trả về ngay lập tức các hộp dịch đã có trong bộ nhớ đệm hoặc là giá tiền ngoại tệ
     * (`¥128`, `$19.99`, `128.50`, từ khóa Taobao/1688) theo tọa độ mới ngay khi người dùng vừa cuộn màn hình!
     * Trả về Pair(Danh sách hộp đã có sẵn, Danh sách các chuỗi mới chưa có trong cache cần dịch ngầm).
     */
    fun buildInstantCachedBoxesForNodes(
        nodes: List<NoAccessibilityScreenEngine.ScreenTextNode>,
        screenWidth: Int,
        screenHeight: Int
    ): Pair<List<CircleToSearchOverlayActivity.TranslatedTextBox>, Boolean> {
        val sw = screenWidth.coerceAtLeast(1).toFloat()
        val sh = screenHeight.coerceAtLeast(1).toFloat()
        val filteredNodes = nodes.filter { shouldTranslateOrConvertNode(it.text) }.take(180)
        if (filteredNodes.isEmpty()) return Pair(emptyList(), false)

        var hasUncached = false
        val rawBoxes = ArrayList<CircleToSearchOverlayActivity.TranslatedTextBox>(filteredNodes.size)

        for (node in filteredNodes) {
            val cleanOrig = node.text.trim().replace("\n", " ")
            var trans = getCachedTranslation(cleanOrig)
            if (trans == null) {
                val glossaryHit = ecommerceQuickGlossary.firstOrNull { it.first.equals(cleanOrig, ignoreCase = true) }
                if (purePriceFastRegex.matches(cleanOrig)) {
                    trans = convertForeignPricesToVnd(cleanOrig, cleanOrig)
                    putCachedTranslation(cleanOrig, trans)
                } else if (glossaryHit != null) {
                    trans = glossaryHit.second
                    putCachedTranslation(cleanOrig, trans)
                } else {
                    val partialHit = ecommerceQuickGlossary.firstOrNull { cleanOrig.contains(it.first, ignoreCase = true) }
                    if (partialHit != null && cleanOrig.length <= 16) {
                        trans = partialHit.second
                        putCachedTranslation(cleanOrig, trans)
                    } else {
                        hasUncached = true
                    }
                }
            }

            if (!trans.isNullOrBlank() && !trans.equals(cleanOrig, ignoreCase = true)) {
                val r = node.boundsInScreen
                val ymin = ((r.top / sh) * 1000f).coerceIn(0f, 985f)
                val xmin = ((r.left / sw) * 1000f).coerceIn(0f, 960f)
                val ymax = ((r.bottom / sh) * 1000f).coerceIn(ymin + 12f, 1000f)
                val xmax = ((r.right / sw) * 1000f).coerceIn(xmin + 35f, 1000f)

                rawBoxes.add(
                    CircleToSearchOverlayActivity.TranslatedTextBox(
                        ymin = ymin,
                        xmin = xmin,
                        ymax = ymax,
                        xmax = xmax,
                        originalText = cleanOrig,
                        translatedText = trans
                    )
                )
            }
        }

        return Pair(resolveBoxCollisions(rawBoxes), hasUncached)
    }

    /**
     * Lấy danh sách văn bản mới chưa có trong bộ nhớ đệm và chưa nằm trong hàng đợi đang dịch
     * để dịch ngầm song song mà KHÔNG BAO GIỜ bị hủy (cancel) khi người dùng tiếp tục cuộn trang!
     */
    private val translationSlots = Semaphore(2)
    private val warmSlot = Semaphore(1)

    fun uncachedStreamingTexts(nodes: List<NoAccessibilityScreenEngine.ScreenTextNode>): List<String> =
        nodes.asSequence()
            .filter { shouldTranslateOrConvertNode(it.text) }
            .map { it.text.trim().replace("\n", " ") }
            .filter { it.isNotEmpty() && !hasCachedTranslation(it) && it !in inFlightTexts && !isNetworkCooldownActive(it) }
            .distinct()
            .take(160)
            .toList()

    private suspend fun translateBatch(chunk: List<String>, constrained: Boolean, streaming: Boolean) {
        val context = currentCoroutineContext()
        suspend fun runBatch() = translationSlots.withPermit {
            context.ensureActive()
            val missing = chunk.filterNot(::hasCachedTranslation)
            // Only claim after obtaining a slot. Cancelling queued work leaves no stale claims.
            val work = if (streaming) missing.filter(inFlightTexts::add) else missing
            try {
                if (work.isNotEmpty()) translateChunkWithGoogle(work) { context.ensureActive() }
            } finally {
                if (streaming) work.forEach(inFlightTexts::remove)
            }
        }
        if (constrained) warmSlot.withPermit { runBatch() } else runBatch()
    }

    suspend fun translateStreamingBatch(chunk: List<String>, constrained: Boolean) {
        translateBatch(chunk, constrained, streaming = true)
    }

    /**
     * Dịch hàng loạt các khối văn bản trên màn hình bằng Google Translate (`translate.googleapis.com`)
     * chỉ trong ~60-110ms (Gộp batch thông minh + xử lý song song + quy đổi tiền tệ VNĐ + chống đè chữ).
     */
    suspend fun translateScreenNodesToBoxes(
        nodes: List<NoAccessibilityScreenEngine.ScreenTextNode>,
        screenWidth: Int,
        screenHeight: Int,
        normRegion: androidx.compose.ui.geometry.Rect? = null,
        constrained: Boolean = false
    ): List<CircleToSearchOverlayActivity.TranslatedTextBox> = withContext(Dispatchers.IO) {
        val sw = screenWidth.coerceAtLeast(1)
        val sh = screenHeight.coerceAtLeast(1)

        val minLeftPx = ((normRegion?.left ?: 0f) * sw).toInt()
        val minTopPx = ((normRegion?.top ?: 0f) * sh).toInt()
        val maxRightPx = ((normRegion?.right ?: 1f) * sw).toInt()
        val maxBottomPx = ((normRegion?.bottom ?: 1f) * sh).toInt()

        val filteredNodes = nodes.filter { node ->
            val r = node.boundsInScreen
            val cx = r.centerX()
            val cy = r.centerY()
            val insideRegion = cx in minLeftPx..maxRightPx && cy in minTopPx..maxBottomPx
            insideRegion && shouldTranslateOrConvertNode(node.text)
        }.take(180)

        if (filteredNodes.isEmpty()) return@withContext emptyList()

        // 1. Tách các chuỗi chưa có trong bộ nhớ đệm để gọi Google Translate
        val uncachedTexts = filteredNodes
            .map { it.text.trim().replace("\n", " ") }
            .distinct()
            .filter { !hasCachedTranslation(it) }

        if (uncachedTexts.isNotEmpty()) {
            // Dịch gộp theo từng lô 6 câu song song qua Google Translate để đạt tốc độ tức thì (~65ms)
            val chunks = uncachedTexts.chunked(6)
            coroutineScope {
                chunks.map { chunk ->
                    async(Dispatchers.IO) {
                        translateBatch(chunk, constrained, streaming = false)
                    }
                }.awaitAll()
            }
        }

        // 2. Tạo danh sách hộp văn bản dịch theo tọa độ chuẩn hóa 0..1000 trong vùng chọn
        val regionW = (maxRightPx - minLeftPx).coerceAtLeast(1).toFloat()
        val regionH = (maxBottomPx - minTopPx).coerceAtLeast(1).toFloat()

        val rawBoxes = mutableListOf<CircleToSearchOverlayActivity.TranslatedTextBox>()
        for (node in filteredNodes) {
            val cleanOrig = node.text.trim().replace("\n", " ")
            var trans = getCachedTranslation(cleanOrig) ?: translateSingleTextWithGoogle(cleanOrig)
            // Nếu bản dịch trống hoặc trùng nguyên gốc mà gốc chứa chữ Trung/ngoại ngữ,
            // thử tra cứu từ điển nhanh hoặc giữ lại bản dịch để không bao giờ bị biến mất hộp dịch
            if (trans.isBlank()) continue
            if (trans.equals(cleanOrig, ignoreCase = true)) {
                val hasForeign = cleanOrig.any { it.code in 0x4E00..0x9FFF || it.code in 0x3040..0x30FF || it.code in 0xAC00..0xD7AF }
                if (hasForeign) {
                    val fallbackTrans = ecommerceQuickGlossary.firstOrNull { cleanOrig.contains(it.first, ignoreCase = true) }?.second
                    if (fallbackTrans != null) {
                        trans = fallbackTrans
                    }
                }
            }

            val r = node.boundsInScreen
            val ymin = (((r.top - minTopPx) / regionH) * 1000f).coerceIn(0f, 985f)
            val xmin = (((r.left - minLeftPx) / regionW) * 1000f).coerceIn(0f, 960f)
            val ymax = (((r.bottom - minTopPx) / regionH) * 1000f).coerceIn(ymin + 12f, 1000f)
            val xmax = (((r.right - minLeftPx) / regionW) * 1000f).coerceIn(xmin + 35f, 1000f)

            rawBoxes.add(
                CircleToSearchOverlayActivity.TranslatedTextBox(
                    ymin = ymin,
                    xmin = xmin,
                    ymax = ymax,
                    xmax = xmax,
                    originalText = cleanOrig,
                    translatedText = trans
                )
            )
        }

        resolveBoxCollisions(rawBoxes)
    }

    /**
     * Gộp nhiều dòng văn bản trong 1 request Google Translate duy nhất để dịch siêu tốc (~65-95ms).
     */
    private fun translateChunkWithGoogle(chunk: List<String>, checkActive: () -> Unit) {
        val stillNeeded = mutableListOf<String>()
        for (item in chunk) {
            val glossaryHit = ecommerceQuickGlossary.firstOrNull { it.first.equals(item, ignoreCase = true) }
            if (purePriceFastRegex.matches(item)) {
                putCachedTranslation(item, convertForeignPricesToVnd(item, item))
            } else if (glossaryHit != null) {
                putCachedTranslation(item, glossaryHit.second)
            } else if (!isNetworkCooldownActive(item)) {
                stillNeeded.add(item)
            }
        }

        if (stillNeeded.isEmpty()) return

        // BƯỚC 5: Ghi nhận thời điểm gọi mạng để giảm tối đa 50% request lặp lại khi cuộn
        stillNeeded.forEach(::recordNetworkAttempt)

        if (stillNeeded.size == 1) {
            translateSingleTextWithGoogle(stillNeeded.first(), checkActive)
            return
        }

        var conn: HttpURLConnection? = null
        try {
            val joined = stillNeeded.joinToString("\n")
            val encoded = URLEncoder.encode(joined, "UTF-8")
            val url = URL("https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=vi&dt=t&q=$encoded")
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 2_200
                readTimeout = 2_500
                setRequestProperty("User-Agent", "GoogleTranslate/6.28.0.05.421483610 (Linux; U; Android 14)")
                setRequestProperty("Connection", "Keep-Alive")
            }

            if (conn.responseCode in 200..299) {
                val response = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                val rootArray = JSONArray(response)
                val sentences = rootArray.optJSONArray(0)
                val sb = StringBuilder()
                if (sentences != null) {
                    for (i in 0 until sentences.length()) {
                        val seg = sentences.optJSONArray(i)?.optString(0, "").orEmpty()
                        sb.append(seg)
                    }
                }
                val lines = sb.toString().split("\n").map { it.trim() }
                if (lines.size == stillNeeded.size) {
                    for (idx in stillNeeded.indices) {
                        val orig = stillNeeded[idx]
                        val trans = lines[idx].ifBlank { orig }
                        val finalTrans = if (trans.isNotBlank() && !trans.equals(orig, ignoreCase = true)) {
                            convertForeignPricesToVnd(orig, trans)
                        } else {
                            orig
                        }
                        putCachedTranslation(orig, finalTrans)
                    }
                    return
                }
            }
        } catch (_: Throwable) {
        } finally {
            try {
                conn?.disconnect()
            } catch (_: Throwable) {}
        }

        // Dự phòng cấp 2: Gộp dịch qua clients5.google.com
        checkActive()
        var conn2: HttpURLConnection? = null
        try {
            val joined = stillNeeded.joinToString("\n")
            val encoded = URLEncoder.encode(joined, "UTF-8")
            val url2 = URL("https://clients5.google.com/translate_a/t?client=dict-chrome-ex&sl=auto&tl=vi&q=$encoded")
            conn2 = (url2.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 3_500
                readTimeout = 3_500
                setRequestProperty("User-Agent", "GoogleTranslate/6.28.0.05.421483610 (Linux; U; Android 14)")
                setRequestProperty("Connection", "Keep-Alive")
            }
            if (conn2.responseCode in 200..299) {
                val response2 = conn2.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                val rootArray2 = JSONArray(response2)
                val firstArr = rootArray2.optJSONArray(0)
                val translatedJoined = firstArr?.optString(0, "").orEmpty()
                val lines2 = translatedJoined.split("\n").map { it.trim() }
                if (lines2.size == stillNeeded.size) {
                    for (idx in stillNeeded.indices) {
                        val orig = stillNeeded[idx]
                        val trans = lines2[idx].ifBlank { orig }
                        val finalTrans = if (trans.isNotBlank() && !trans.equals(orig, ignoreCase = true)) {
                            convertForeignPricesToVnd(orig, trans)
                        } else {
                            orig
                        }
                        putCachedTranslation(orig, finalTrans)
                    }
                    return
                }
            }
        } catch (_: Throwable) {
        } finally {
            try { conn2?.disconnect() } catch (_: Throwable) {}
        }

        // Dự phòng cấp 3 nếu gộp dòng không khớp: dịch từng câu một qua translateSingleTextWithGoogle
        val missing = stillNeeded.filter { !hasCachedTranslation(it) }
        for (item in missing) {
            val res = translateSingleTextWithGoogle(item, checkActive)
            putCachedTranslation(item, res.ifBlank { item })
        }
    }

    /**
     * Thuật toán chống đè chữ 2 chiều (2D Collision Avoidance & Yielding Engine):
     * - Sắp xếp ưu tiên: Thẻ giá tiền ("≈ ... đ") được ưu tiên giữ vị trí nguyên bản.
     * - Các thẻ văn bản / tiêu đề tự động né nhau (Dodge) và nhường đường (Yield):
     *   + Nếu cùng hàng ngang: né sang phải (`xmin = prev.xmax + gapX`).
     *   + Nếu hết chỗ hoặc dạng khối dọc: nhường đường và lùi xuống dưới (`ymin = prev.ymax + gapY`).
     * - Loại bỏ hoàn toàn các hộp trùng lặp (Ghost Duplicate Boxes).
     * - Đảm bảo 100% các hộp dịch không bao giờ che khuất hay đè lên nhau!
     */
    fun resolveBoxCollisions(
        boxes: List<CircleToSearchOverlayActivity.TranslatedTextBox>
    ): List<CircleToSearchOverlayActivity.TranslatedTextBox> {
        if (boxes.size <= 1) return boxes

        // 1. Loại bỏ các hộp hoàn toàn trùng lặp vị trí hoặc nội dung
        val deduplicated = mutableListOf<CircleToSearchOverlayActivity.TranslatedTextBox>()
        for (box in boxes) {
            val isDup = deduplicated.any { prev ->
                abs(prev.xmin - box.xmin) < 12f && abs(prev.ymin - box.ymin) < 12f &&
                    (prev.translatedText.equals(box.translatedText, ignoreCase = true) ||
                        prev.originalText.equals(box.originalText, ignoreCase = true))
            }
            if (!isDup) {
                deduplicated.add(box)
            }
        }

        // 2. Loại bỏ hộp cha (ViewGroup bao trùm) nếu đã chứa các hộp con chi tiết bên trong
        val filtered = deduplicated.filter { parent ->
            val hasChildInside = deduplicated.any { child ->
                child !== parent &&
                    child.xmin >= parent.xmin - 8f && child.xmax <= parent.xmax + 8f &&
                    child.ymin >= parent.ymin - 8f && child.ymax <= parent.ymax + 8f &&
                    (parent.originalText.contains(child.originalText) || parent.translatedText.contains(child.translatedText))
            }
            !hasChildInside
        }

        return filtered
    }

    /**
     * Dự phòng trích xuất tọa độ văn bản bằng `uiautomator dump` khi Shizuku / ADB đang bật
     * mà Accessibility chưa kịp kết nối.
     */
    suspend fun extractNodesViaUiAutomatorFallback(
        context: Context
    ): List<NoAccessibilityScreenEngine.ScreenTextNode> = withContext(Dispatchers.IO) {
        val shell = ShellEngine.getInstance(context.applicationContext)
        if (!shell.state.value.isAdbReady) return@withContext emptyList()

        return@withContext try {
            val res = withTimeoutOrNull(1200L) {
                shell.execute("uiautomator dump /data/local/tmp/cts_nodes.xml >/dev/null 2>&1 && cat /data/local/tmp/cts_nodes.xml; rm -f /data/local/tmp/cts_nodes.xml")
            } ?: return@withContext emptyList()
            val xml = res.output
            if (xml.isBlank() || !xml.contains("<node")) return@withContext emptyList()

            val nodes = mutableListOf<NoAccessibilityScreenEngine.ScreenTextNode>()
            val nodeRegex = Regex("""<node\b[^>]*>""")
            val textRegex = Regex("""\btext="([^"]*)"""")
            val descRegex = Regex("""\bcontent-desc="([^"]*)"""")
            val boundsRegex = Regex("""\bbounds="\[(\d+),(\d+)\]\[(\d+),(\d+)\]"""")

            for (match in nodeRegex.findAll(xml)) {
                val tag = match.value
                val text = textRegex.find(tag)?.groupValues?.get(1)?.trim().orEmpty()
                    .ifEmpty { descRegex.find(tag)?.groupValues?.get(1)?.trim().orEmpty() }
                if (text.isEmpty() || text.length > 240) continue

                val bMatch = boundsRegex.find(tag) ?: continue
                val x1 = bMatch.groupValues[1].toIntOrNull() ?: continue
                val y1 = bMatch.groupValues[2].toIntOrNull() ?: continue
                val x2 = bMatch.groupValues[3].toIntOrNull() ?: continue
                val y2 = bMatch.groupValues[4].toIntOrNull() ?: continue

                if (x2 - x1 >= 12 && y2 - y1 >= 10) {
                    nodes.add(
                        NoAccessibilityScreenEngine.ScreenTextNode(
                            text = decodeXmlEntities(text),
                            boundsInScreen = Rect(x1, y1, x2, y2)
                        )
                    )
                }
            }
            nodes
        } catch (_: Throwable) {
            emptyList()
        }
    }

    private fun decodeXmlEntities(input: String): String {
        return input
            .replace("&amp;", "&")
            .replace("&quot;", "\"")
            .replace("&apos;", "'")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&#10;", " ")
    }
}

/**
 * LỚP PHỦ GOOGLE DỊCH XUYÊN THẤU "CUỘN ĐẾN ĐÂU DỊCH ĐẾN ĐÓ" (GoogleLiveTranslateOverlay):
 * - Đóng hoàn toàn màn hình ảnh chụp tĩnh (`CircleToSearchOverlayActivity`) để gắn trực tiếp lớp phủ xuyên thấu
 *   (`TYPE_APPLICATION_OVERLAY` với `FLAG_NOT_TOUCHABLE | FLAG_NOT_FOCUSABLE`) lên trên ứng dụng đang mở (Taobao, 1688, Pinduoduo, AliExpress...).
 * - Mọi thao tác chạm, vuốt cuộn trang, bấm chọn sản phẩm trên Taobao & 1688 đi xuyên qua lớp dịch 100% theo thời gian thực.
 * - Kiến trúc Zero-Latency Dual-Pipeline:
 *   + Pipeline 1 (Fast Track 0ms): Cập nhật vị trí các hộp đã dịch & quy đổi giá tiền VNĐ tức thì ngay trên mỗi khung hình cuộn mà không có bất kỳ delay nào.
 *   + Pipeline 2 (Non-Cancelling Streaming Worker): Các câu tiếng nước ngoài mới xuất hiện khi cuộn được đưa vào luồng dịch song song chạy ngầm KHÔNG BỊ HỦY khi người dùng tiếp tục vuốt. Dịch xong lô nào hiển thị ngay lô đó!
 */
object GoogleLiveTranslateOverlay {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    @Volatile
    var isRunning: Boolean = false
        private set

    @Volatile
    private var isBoxesTemporarilyHidden: Boolean = false

    fun isPausedForSleep(): Boolean = isBoxesTemporarilyHidden || isScreenPaused

    private var arOverlayView: LiveArBoxesCanvasView? = null
    private var controlBarView: View? = null
    private var statusBadgeTextView: TextView? = null
    private var hideShowBtnView: TextView? = null

    // Nút Loa duy nhất ở góc trên cùng màn hình để đọc toàn bộ truyện/báo
    private var topCornerSpeakerBtn: View? = null
    private var topCornerSpeakerIcon: TextView? = null
    private var topCornerSpeakerLabel: TextView? = null

    // Vùng chạm tương tác trong suốt phủ đúng lên từng hộp bản dịch để người dùng bấm trực tiếp vào chữ
    private val activeTouchTargetViews = mutableListOf<View>()

    // Trạng thái phát âm thanh hiện tại
    @Volatile
    private var currentlyPlayingBox: CircleToSearchOverlayActivity.TranslatedTextBox? = null
    @Volatile
    private var currentlyPlayingText: String? = null

    // Trạng thái đọc toàn bộ màn hình (truyện & báo)
    @Volatile
    private var isFullPageReadingActive: Boolean = false
    private var fullPageReadingQueue = mutableListOf<CircleToSearchOverlayActivity.TranslatedTextBox>()
    private var fullPageReadingIndex: Int = 0

    @Volatile
    private var pausedByBankingSecurity: Boolean = false

    private var fastTrackJob: Job? = null
    private var periodicWatchJob: Job? = null
    private var pendingRefreshJob: Job? = null
    private var ttsJob: Job? = null
    private val streamingTranslateScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val queuedStreamingTexts = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()

    @Volatile
    private var isScreenPaused: Boolean = false
    @Volatile
    private var isRefreshScheduled: Boolean = false
    private var screenStateReceiver: BroadcastReceiver? = null
    private var controlBarGlobalLayoutListener: ViewTreeObserver.OnGlobalLayoutListener? = null

    @Volatile
    private var lastNodesSignature: String = ""
    @Volatile
    private var lastTranslatedNodes: List<NoAccessibilityScreenEngine.ScreenTextNode> = emptyList()
    private var lastFastTrackTimeMs: Long = 0L
    private var pendingTouchTargetRunnable: Runnable? = null
    private var pendingScrollScanRunnable: Runnable? = null

    private fun registerScreenStateReceiver(appCtx: Context) {
        if (screenStateReceiver != null) return
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                when (intent?.action) {
                    Intent.ACTION_SCREEN_OFF -> {
                        // Do not retain overlay windows while locked or automatically wake the
                        // screen-reading pipeline on unlock. Require an explicit user restart.
                        stop(appCtx)
                    }
                }
            }
        }
        try {
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_OFF)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                appCtx.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                appCtx.registerReceiver(receiver, filter)
            }
            screenStateReceiver = receiver
        } catch (_: Throwable) {}
    }

    private fun unregisterScreenStateReceiver(appCtx: Context) {
        val receiver = screenStateReceiver ?: return
        screenStateReceiver = null
        try {
            appCtx.unregisterReceiver(receiver)
        } catch (_: Throwable) {}
    }

    fun start(
        context: Context,
        initialBoxes: List<CircleToSearchOverlayActivity.TranslatedTextBox> = emptyList()
    ): Boolean {
        if (com.example.core.perf.CpuHeatGuard.isHot()) return false
        val appCtx = context.applicationContext
        if (!com.example.core.permission.AppPermissionChecker.isFirstTimeWlanActivated(appCtx)) {
            Toast.makeText(
                appCtx,
                "🔒 Tính năng Dịch Cuộn cần kết nối Gỡ lỗi Wi-Fi 1 lần bằng mã 6 số để kích hoạt trợ năng ngầm vĩnh viễn!",
                Toast.LENGTH_LONG
            ).show()
            try {
                val intent = Intent(appCtx, com.example.MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    putExtra("TARGET_TAB", "SHIZUKU")
                }
                appCtx.startActivity(intent)
            } catch (_: Throwable) {}
            return false
        }

        // MỞ CHO TẤT CẢ NGƯỜI DÙNG (Đồng bộ với CircleToSearchOverlayActivity để nút Dịch Màn Hình luôn hoạt động 100%)
        if (!Settings.canDrawOverlays(appCtx)) {
            NoAccessibilityScreenEngine.isLiveScrollTranslateActive = false
            com.example.core.service.MagicTuneCtsAccessibilityService.clearLiveScrollLease()
            NoAccessibilityScreenEngine.disableServiceIfIdle(appCtx, 60L)
            Toast.makeText(
                appCtx,
                "⚠️ Vui lòng BẬT quyền 'Hiển thị trên ứng dụng khác' cho MagicTune để cuộn & dịch xuyên thấu trên Taobao/1688!",
                Toast.LENGTH_LONG
            ).show()
            try {
                val intent = android.content.Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    android.net.Uri.parse("package:${appCtx.packageName}")
                ).apply {
                    addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                appCtx.startActivity(intent)
            } catch (_: Throwable) {}
            return false
        }

        if (isRunning) return true

        // Đặt cờ đồng bộ ngay lập tức trước khi CircleToSearchOverlayActivity đóng để onDestroy() không tắt AccessibilityService!
        isRunning = true
        queuedStreamingTexts.clear()
        isBoxesTemporarilyHidden = false
        isScreenPaused = false
        isRefreshScheduled = false
        try { com.example.core.adb.AdbNsdScanner.getInstance(appCtx).releaseMulticastLock() } catch (_: Throwable) {}
        ScreenPowerOptimizer.onFeatureStarted(appCtx, "LiveScrollTranslate")
        NoAccessibilityScreenEngine.isLiveScrollTranslateActive = true
        com.example.core.service.MagicTuneCtsAccessibilityService.touchLiveScrollLease(appCtx)
        com.example.core.ocr.ScreenOcrEngine.clearScrollOcrFrameCache()
        lastNodesSignature = ""
        lastTranslatedNodes = emptyList()
        registerScreenStateReceiver(appCtx)

        // Tự động đánh thức ngầm Trợ năng On-Demand trên luồng nền trước khi làm việc
        scope.launch(Dispatchers.Default) {
            NoAccessibilityScreenEngine.autoWakeAccessibilityIfNeeded(appCtx, 1300L)
            com.example.core.service.MagicTuneCtsAccessibilityService.updateEventSubscriptionForLiveScroll(true)
        }

        NoAccessibilityScreenEngine.onBankingAppDetectedCallback = {
            if (isRunning) {
                pausedByBankingSecurity = true
                mainHandler.post {
                    Toast.makeText(appCtx, tr("🛡️ Đã tạm dừng Dịch Cuộn trên ứng dụng bảo mật cao"), Toast.LENGTH_SHORT).show()
                }
                stop(appCtx, keepBankingResumeListener = true)
            }
        }

        NoAccessibilityScreenEngine.onBankingExitedCallback = {
            if (pausedByBankingSecurity) {
                pausedByBankingSecurity = false
                mainHandler.post {
                    Toast.makeText(appCtx, tr("⚡ Đã bật lại Dịch Cuộn ngay khi rời ứng dụng bảo mật"), Toast.LENGTH_SHORT).show()
                    start(appCtx)
                }
            }
        }

        NoAccessibilityScreenEngine.onLiveScrollEventCallback = { _ ->
            mainHandler.post {
                if (!isRunning || isBoxesTemporarilyHidden || isScreenPaused) return@post
                // Giải phóng vùng chạm ngay khi đang cuộn để người dùng vuốt chạm mượt mà 100% không bị cản trở
                clearBoxTouchTargets(appCtx)
                // Chống rung tuyệt đối: Chỉ quét lại sau khi thao tác cuộn dừng/ổn định,
                // tự động nới nhịp khi máy yếu hoặc đang ấm nhiệt độ!
                pendingScrollScanRunnable?.let { mainHandler.removeCallbacks(it) }
                val r = Runnable {
                    if (isRunning && !isBoxesTemporarilyHidden && !isScreenPaused) {
                        lastFastTrackTimeMs = System.currentTimeMillis()
                        triggerZeroLatencyScan(appCtx, forceRescan = false)
                    }
                }
                pendingScrollScanRunnable = r
                val scanDebounceMs = com.example.core.compat.DeviceCompatProfile.recommendedScrollScanDebounceMs(appCtx)
                mainHandler.postDelayed(r, scanDebounceMs)
            }
        }

        val launchUiNow = Runnable {
            if (!isRunning) return@Runnable
            ensureOverlayViewsCreated(appCtx)
            if (initialBoxes.isNotEmpty()) {
                arOverlayView?.setScrollingAlpha(1f)
                arOverlayView?.updateBoxes(initialBoxes)
                statusBadgeTextView?.text = tr("🌐 Dịch Cuộn: ${initialBoxes.size} mục • Đang dịch...")
            } else {
                statusBadgeTextView?.text = tr("🌐 Đang dịch tức thì...")
            }
            // LUÔN chạy triggerZeroLatencyScan ngay lập tức để dịch toàn bộ các câu chưa có trong bộ nhớ đệm trên màn hình!
            triggerZeroLatencyScan(appCtx, forceRescan = true)
        }
        if (Looper.myLooper() == Looper.getMainLooper()) {
            launchUiNow.run()
        } else {
            mainHandler.postAtFrontOfQueue(launchUiNow)
        }
        return true
    }

    fun stop(context: Context, keepBankingResumeListener: Boolean = false) {
        val appCtx = context.applicationContext ?: context
        if (!keepBankingResumeListener) {
            pausedByBankingSecurity = false
        }
        isRunning = false
        ScreenPowerOptimizer.onFeatureStopped(appCtx, "LiveScrollTranslate")
        queuedStreamingTexts.clear()
        isBoxesTemporarilyHidden = false
        isScreenPaused = false
        isRefreshScheduled = false
        unregisterScreenStateReceiver(appCtx)
        NoAccessibilityScreenEngine.isLiveScrollTranslateActive = false
        NoAccessibilityScreenEngine.clearCachedScreenNodes()
        NoAccessibilityScreenEngine.onLiveScrollEventCallback = null
        if (!keepBankingResumeListener) {
            NoAccessibilityScreenEngine.onBankingAppDetectedCallback = null
            NoAccessibilityScreenEngine.onBankingExitedCallback = null
        }

        // 1. Hủy triệt để toàn bộ Job và CoroutineScope
        fastTrackJob?.cancel()
        periodicWatchJob?.cancel()
        pendingRefreshJob?.cancel()
        ttsJob?.cancel()
        try { scope.coroutineContext.cancelChildren() } catch (_: Throwable) {}
        try { streamingTranslateScope.coroutineContext.cancelChildren() } catch (_: Throwable) {}

        // 2. Hủy toàn bộ Runnable & Message trên MainHandler
        mainHandler.removeCallbacksAndMessages(null)
        pendingScrollScanRunnable = null
        pendingTouchTargetRunnable = null
        lastNodesSignature = ""
        lastTranslatedNodes = emptyList()

        // 3. Dừng toàn bộ âm thanh và giải phóng Audio
        stopFullPageReading()
        stopAllAudioPlayback()

        // 4. Dọn dẹp giao diện UI (gỡ WindowManager tức thì)
        val cleanupUi = {
            clearBoxTouchTargets(appCtx)
            arOverlayView?.forceClearBoxes()
            removeOverlayViews(appCtx)
        }
        if (Looper.myLooper() == Looper.getMainLooper()) {
            cleanupUi()
        } else {
            mainHandler.post { cleanupUi() }
        }

        // 5. Giải phóng tài nguyên OCR, MediaProjection, VirtualDisplay, ImageReader
        if (!CircleToSearchOverlayActivity.isOverlayActive && !CircleToSearchWindowOverlay.isShowing) {
            com.example.core.ocr.ScreenOcrEngine.releaseIdleResources()
        } else {
            com.example.core.ocr.ScreenOcrEngine.clearScrollOcrFrameCache()
        }
        com.example.core.projection.MediaProjectionHolder.stopContinuousScrollMode()
        com.example.core.projection.MediaProjectionHolder.cleanup()
        com.example.core.service.MagicTuneMediaProjectionService.stop(appCtx)
        com.example.core.service.MagicTuneCtsAccessibilityService.clearLiveScrollLease()
        com.example.core.service.MagicTuneCtsAccessibilityService.updateEventSubscriptionForLiveScroll(false)
        if (keepBankingResumeListener) {
            com.example.core.service.MagicTuneCtsAccessibilityService.forceDisableServiceNow(appCtx)
        } else {
            NoAccessibilityScreenEngine.disableServiceIfIdle(appCtx, 0L)
        }
        // Closing the last screen-reading surface should release KeepAlive immediately,
        // instead of waiting for its next ticker pass to notice the idle state.
        try {
            com.example.core.service.MagicTuneKeepAliveService.syncServiceNeed(appCtx, "Scroll translation closed")
        } catch (_: Throwable) {}
    }

    fun computeNodesSignature(nodes: List<NoAccessibilityScreenEngine.ScreenTextNode>): String {
        if (nodes.isEmpty()) return ""
        // Lượng tử hóa tọa độ theo lưới 45px để chống rung/nhiễu pixel khi màn hình đứng yên
        return nodes
            .sortedWith(compareBy({ it.boundsInScreen.top / 45 }, { it.boundsInScreen.left / 45 }, { it.text }))
            .take(36)
            .joinToString("|") {
                val quantizedY = it.boundsInScreen.top / 45
                val quantizedX = it.boundsInScreen.left / 45
                "${it.text}@${quantizedY}_${quantizedX}"
            }
    }

    /**
     * Tính hash của văn bản OCR để phát hiện thay đổi nội dung thực tế.
     * Chỉ hash văn bản thuần túy, bỏ qua tọa độ để tránh false positive khi màn hình rung nhẹ.
     */
    private fun computeOcrTextHash(nodes: List<NoAccessibilityScreenEngine.ScreenTextNode>): String {
        if (nodes.isEmpty()) return ""
        return nodes
            .filter { it.text.isNotBlank() }
            .sortedBy { it.text }
            .take(50)
            .joinToString("|") { it.text }
            .let { it.hashCode().toString() }
    }

    /**
     * Kiểm tra xem danh sách node mới và danh sách node đã dịch trước đó có phải cùng một khung nhìn đứng yên hay không.
     * Nếu >= 72% văn bản trùng khớp và độ lệch trục dọc trung bình < 32px -> Màn hình CHƯA CUỘN, giữ nguyên 100% bản dịch!
     */
    private fun isViewportStationary(
        newNodes: List<NoAccessibilityScreenEngine.ScreenTextNode>,
        oldNodes: List<NoAccessibilityScreenEngine.ScreenTextNode>
    ): Boolean {
        if (newNodes.isEmpty() || oldNodes.isEmpty()) return false
        val oldByText = oldNodes.groupBy { it.text }
        var matchedCount = 0
        var totalDeltaY = 0f

        for (node in newNodes) {
            val candidates = oldByText[node.text] ?: continue
            val closest = candidates.minByOrNull { abs(it.boundsInScreen.top - node.boundsInScreen.top) } ?: continue
            val dy = abs(closest.boundsInScreen.top - node.boundsInScreen.top).toFloat()
            val dx = abs(closest.boundsInScreen.left - node.boundsInScreen.left).toFloat()
            if (dy <= 36f && dx <= 36f) {
                matchedCount++
                totalDeltaY += dy
            }
        }

        val minSize = minOf(newNodes.size, oldNodes.size).coerceAtLeast(1)
        val overlapRatio = matchedCount.toFloat() / minSize.toFloat()
        val avgDeltaY = if (matchedCount > 0) totalDeltaY / matchedCount else 999f
        return overlapRatio >= 0.72f && avgDeltaY < 28f
    }

    private fun scheduleCoalescedBoxesRefresh(context: Context, immediate: Boolean = false) {
        if (!isRunning || isBoxesTemporarilyHidden || isScreenPaused) return
        if (immediate) {
            pendingRefreshJob?.cancel()
            isRefreshScheduled = false
            refreshVisibleBoxesFromCache(context)
            return
        }
        if (isRefreshScheduled) return
        isRefreshScheduled = true
        pendingRefreshJob = scope.launch {
            delay(30L)
            isRefreshScheduled = false
            if (isRunning && !isBoxesTemporarilyHidden && !isScreenPaused) {
                refreshVisibleBoxesFromCache(context)
            }
        }
    }

    /**
     * Làm mới tức thì các hộp hiển thị trên màn hình ngay khi mỗi lô câu vừa dịch xong trong bộ nhớ đệm.
     * Sử dụng trực tiếp `lastTranslatedNodes` của khung nhìn hiện tại để bản dịch hiện ra êm ái, không bao giờ nhảy hay mất hộp cũ.
     */
    private fun refreshVisibleBoxesFromCache(context: Context) {
        if (!isRunning || isBoxesTemporarilyHidden || isScreenPaused) return
        scope.launch {
            if (!isRunning || isBoxesTemporarilyHidden || isScreenPaused) return@launch
            val dm = context.resources.displayMetrics
            val sw = dm.widthPixels.coerceAtLeast(1)
            val sh = dm.heightPixels.coerceAtLeast(1)
            val targetNodes = lastTranslatedNodes.ifEmpty {
                withContext(Dispatchers.Default) {
                    NoAccessibilityScreenEngine.extractFastA11yNodesOnly(context, maxWaitMs = 180L)
                }
            }
            if (!isRunning || isBoxesTemporarilyHidden || isScreenPaused || targetNodes.isEmpty()) return@launch
            val (updatedBoxes, stillHasUncached) = withContext(Dispatchers.Default) {
                GoogleScreenTranslator.buildInstantCachedBoxesForNodes(targetNodes, sw, sh)
            }
            if (isRunning && !isBoxesTemporarilyHidden && !isScreenPaused && updatedBoxes.isNotEmpty()) {
                val isWarm = com.example.core.compat.DeviceCompatProfile.isDeviceWarmOrHot(context)
                withContext(Dispatchers.Main.immediate) {
                    arOverlayView?.updateBoxes(updatedBoxes)
                    statusBadgeTextView?.text = when {
                        stillHasUncached -> "🌐 Dịch Cuộn: ${updatedBoxes.size} mục • Đang dịch..."
                        isWarm -> "🌐 Dịch Cuộn: ${updatedBoxes.size} mục (Làm mát)"
                        else -> "🌐 Dịch Cuộn: ${updatedBoxes.size} mục (Đổi VNĐ)"
                    }
                }
            }
        }
    }

    @Volatile
    private var lastOcrExecutionTimeMs: Long = 0L

    @Volatile
    private var lastOcrTextHash: String = ""

    private fun dispatchStreamingChunksForNodes(
        context: Context,
        nodes: List<NoAccessibilityScreenEngine.ScreenTextNode>,
        instantBoxesCount: Int,
        isWarm: Boolean
    ) {
        scope.launch {
            // Giữ các batch đang chạy qua những lần quét cuộn tiếp theo. Hủy giữa chừng làm
            // WebView/Google Translate phải gửi lại cùng văn bản, vừa mất bản dịch vừa tốn pin.
            val candidates = withContext(Dispatchers.Default) {
                GoogleScreenTranslator.uncachedStreamingTexts(nodes)
            }
            if (!isRunning || isBoxesTemporarilyHidden || isScreenPaused) return@launch
            if (candidates.isEmpty()) {
                statusBadgeTextView?.text = if (isWarm) {
                    "🌐 Dịch Cuộn: $instantBoxesCount mục (Làm mát)"
                } else {
                    "🌐 Dịch Cuộn: $instantBoxesCount mục (Đổi VNĐ)"
                }
                return@launch
            }

            statusBadgeTextView?.text = if (instantBoxesCount > 0) {
                "🌐 Dịch Cuộn: $instantBoxesCount mục • Đang dịch..."
            } else {
                "🌐 Google Dịch đang dịch..."
            }

            val netConcurrency = com.example.core.compat.DeviceCompatProfile.recommendedLiveTranslateConcurrency(context)
            // Dịch nhiều mục hơn trên máy mát; giữ batch ngắn trên máy yếu/nóng để cân bằng nhiệt.
            val queueLimit = if (isWarm || netConcurrency <= 1) 36 else 72
            val chunks = candidates.take(queueLimit).chunked(12)
            chunks.forEachIndexed { index, chunk ->
                val queued = chunk.filter { text ->
                    queuedStreamingTexts.size < queueLimit && queuedStreamingTexts.add(text)
                }
                if (queued.isEmpty()) return@forEachIndexed
                val job = streamingTranslateScope.launch batch@{
                    if (!isRunning || isScreenPaused || isBoxesTemporarilyHidden) return@batch
                    GoogleScreenTranslator.translateStreamingBatch(queued, constrained = netConcurrency <= 1)
                    withContext(Dispatchers.Main.immediate) {
                        if (isRunning && !isBoxesTemporarilyHidden && !isScreenPaused) {
                            scheduleCoalescedBoxesRefresh(context, immediate = (index == 0))
                        }
                    }
                }
                job.invokeOnCompletion { queued.forEach(queuedStreamingTexts::remove) }
            }
        }
    }

    /**
     * Quét 0 độ trễ (Zero-Latency) 2 tầng:
     * - Tầng 1 (Tức thì ~5-25ms): Đọc trực tiếp cây giao diện từ Trợ năng ngầm On-Demand (`extractFastA11yNodesOnly`)
     *   mà KHÔNG chụp màn hình hay chạy OCR -> Hiển thị ngay 0ms giá tiền VNĐ + từ điển TMĐT và bắn ngay luồng Google Dịch song song (~90ms)!
     * - Tầng 2 (Bổ sung ngầm chỉ khi cần): Chỉ khi cây Accessibility trống (trang vẽ thuần bằng Canvas/ảnh) hoặc app TMĐT thiếu chữ,
     *   mới chụp màn hình chạy OCR bổ sung ở nền mà không bao giờ làm chậm Tầng 1.
     */
    private fun triggerZeroLatencyScan(context: Context, forceRescan: Boolean = false) {
        if (isScreenPaused) return
        fastTrackJob?.cancel()
        fastTrackJob = scope.launch {
            if (!isRunning || isBoxesTemporarilyHidden || isScreenPaused) return@launch

            val dm = context.resources.displayMetrics
            val sw = dm.widthPixels.coerceAtLeast(1)
            val sh = dm.heightPixels.coerceAtLeast(1)

            com.example.core.service.MagicTuneCtsAccessibilityService.touchLiveScrollLease(context)
            // Mặc định luôn tự đánh thức Trợ năng ngầm trước khi quét dịch
            if (!com.example.core.service.MagicTuneCtsAccessibilityService.isServiceConnected()) {
                NoAccessibilityScreenEngine.autoWakeAccessibilityIfNeeded(context, 1300L)
                com.example.core.service.MagicTuneCtsAccessibilityService.updateEventSubscriptionForLiveScroll(true)
            }
            // TẦNG 1: Đọc nhanh cây giao diện Accessibility On-Demand (~5-25ms, không gọi OCR)
            var nodes = NoAccessibilityScreenEngine.extractFastA11yNodesOnly(context, maxWaitMs = 520L)
            if (nodes.isEmpty() && isRunning && !isBoxesTemporarilyHidden && !isScreenPaused) {
                delay(45L)
                nodes = NoAccessibilityScreenEngine.extractFastA11yNodesOnly(context, maxWaitMs = 380L)
            }

            if (!isRunning || isBoxesTemporarilyHidden || isScreenPaused) return@launch

            val isWarm = com.example.core.compat.DeviceCompatProfile.isDeviceWarmOrHot(context)

            if (nodes.isNotEmpty()) {
                val sig = computeNodesSignature(nodes)
                val shouldSkipA11y = !forceRescan && (
                    (sig == lastNodesSignature && lastNodesSignature.isNotEmpty()) ||
                        (lastTranslatedNodes.isNotEmpty() && isViewportStationary(nodes, lastTranslatedNodes))
                    )
                if (!shouldSkipA11y) {
                    lastNodesSignature = sig
                    lastTranslatedNodes = nodes

                    // Hiển thị TỨC THÌ 0MS toàn bộ giá tiền VNĐ + từ điển + các câu đã có trong Cache
                    val (instantBoxes, hasUncached) = withContext(Dispatchers.Default) {
                        GoogleScreenTranslator.buildInstantCachedBoxesForNodes(nodes, sw, sh)
                    }
                    if (!isRunning || isBoxesTemporarilyHidden || isScreenPaused) return@launch
                    if (instantBoxes.isNotEmpty()) {
                        arOverlayView?.updateBoxes(instantBoxes)
                    }
                    if (hasUncached) {
                        dispatchStreamingChunksForNodes(context, nodes, instantBoxes.size, isWarm)
                    } else {
                        statusBadgeTextView?.text = if (isWarm) {
                            "🌐 Dịch Cuộn: ${instantBoxes.size} mục (Làm mát)"
                        } else {
                            "🌐 Dịch Cuộn: ${instantBoxes.size} mục (Đổi VNĐ)"
                        }
                    }
                }
            }

            // TẦNG 2: Chỉ gọi OCR bổ sung nếu cây Accessibility hoàn toàn rỗng (trang ảnh/Canvas) hoặc app TMĐT có quá ít node (< 6 node)
            val isEcommerceCanvasSparse = nodes.size in 1..5 && NoAccessibilityScreenEngine.getActiveForegroundPackage(context).orEmpty().let { currentFg ->
                currentFg.contains("alibaba") ||
                    currentFg.contains("taobao") ||
                    currentFg.contains("pinduoduo") ||
                    currentFg.contains("tmall") ||
                    currentFg.contains("jd")
            }

            val nowMs = System.currentTimeMillis()
            // OCR tốn CPU hơn đọc Accessibility; quét chậm hơn khi nội dung là canvas/ảnh.
            val minOcrIntervalMs = if (isWarm) 7_000L else 4_000L
            val canRunOcrNow = (nowMs - lastOcrExecutionTimeMs) >= minOcrIntervalMs

            if ((nodes.isEmpty() || isEcommerceCanvasSparse) && canRunOcrNow) {
                lastOcrExecutionTimeMs = nowMs
                if (nodes.isEmpty()) {
                    statusBadgeTextView?.text = tr("🌐 Đang quét chữ trên ảnh (OCR)...")
                }
                val combinedWithOcr = NoAccessibilityScreenEngine.supplementWithOcrNodes(context, nodes)
                if (!isRunning || isBoxesTemporarilyHidden || isScreenPaused) return@launch
                // OCR throttle: chỉ xử lý khi nội dung văn bản thực sự thay đổi
                val ocrTextHash = computeOcrTextHash(combinedWithOcr)
                if (ocrTextHash == lastOcrTextHash && ocrTextHash.isNotEmpty()) {
                    // Nội dung OCR không đổi -> bỏ qua để tiết kiệm CPU/pin
                    if (isWarm) {
                        statusBadgeTextView?.text = tr("🌐 Dịch Cuộn: ${nodes.size} mục (Làm mát)")
                    } else {
                        statusBadgeTextView?.text = tr("🌐 Dịch Cuộn: ${nodes.size} mục (Đổi VNĐ)")
                    }
                } else if (combinedWithOcr.size > nodes.size) {
                    lastOcrTextHash = ocrTextHash
                    nodes = combinedWithOcr
                    lastNodesSignature = computeNodesSignature(nodes)
                    lastTranslatedNodes = nodes

                    val (ocrInstantBoxes, ocrHasUncached) = withContext(Dispatchers.Default) {
                        GoogleScreenTranslator.buildInstantCachedBoxesForNodes(nodes, sw, sh)
                    }
                    if (!isRunning || isBoxesTemporarilyHidden || isScreenPaused) return@launch
                    if (ocrInstantBoxes.isNotEmpty()) {
                        arOverlayView?.updateBoxes(ocrInstantBoxes)
                    }
                    if (ocrHasUncached) {
                        dispatchStreamingChunksForNodes(context, nodes, ocrInstantBoxes.size, isWarm)
                    } else {
                        statusBadgeTextView?.text = tr("🌐 Dịch Cuộn: ${ocrInstantBoxes.size} mục (Đổi VNĐ)")
                    }
                } else if (nodes.isEmpty()) {
                    statusBadgeTextView?.text = tr("🌐 Màn hình chưa có chữ • Kéo nhẹ hoặc bấm 🔄 Dịch lại")
                }
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun ensureOverlayViewsCreated(context: Context) {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        // 1. Lớp phủ AR Boxes XUYÊN THẤU CẢM ỨNG 100% (FLAG_NOT_TOUCHABLE | FLAG_NOT_FOCUSABLE)
        if (arOverlayView == null) {
            val canvasView = LiveArBoxesCanvasView(context)
            val canvasParams = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
                ScreenPowerOptimizer.applyEcoRefreshRateToWindow(this)
            }
            try {
                wm.addView(canvasView, canvasParams)
                arOverlayView = canvasView
            } catch (_: Throwable) {}
        }

        // 2. Thanh điều khiển nổi 2 hàng (Tự động ẩn khi bàn phím ảo xuất hiện)
        if (controlBarView == null) {
            val density = context.resources.displayMetrics.density
            fun dp(v: Int): Int = (v * density).toInt()

            val rootContainer = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(12), dp(8), dp(12), dp(8))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(20).toFloat()
                    setColor(Color.parseColor("#F51E1F22"))
                    setStroke(dp(1), Color.parseColor("#3C4043"))
                }
                elevation = dp(8).toFloat()
            }

            // --- HÀNG 1: Biểu tượng Google Dịch + Trạng thái ngôn ngữ + Nút Đóng (✕) ---
            val row1 = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }

            // 1. Google Translate Icon
            val transIcon = android.widget.ImageView(context).apply {
                setImageResource(com.example.R.drawable.ic_cts_translate)
                setColorFilter(Color.parseColor("#8AB4F8"))
                contentDescription = tr("Google Dịch")
            }
            row1.addView(transIcon, LinearLayout.LayoutParams(dp(20), dp(20)).apply {
                marginStart = dp(2)
                marginEnd = dp(6)
            })

            // 2. Language Status Pill
            val statusTv = TextView(context).apply {
                text = tr("Tự động ▾ → Tiếng Việt ▾")
                setTextColor(Color.parseColor("#E8EAED"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setPadding(dp(10), dp(4), dp(10), dp(4))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(14).toFloat()
                    setColor(Color.parseColor("#2D2F31"))
                }
            }
            statusBadgeTextView = statusTv
            row1.addView(statusTv, LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1f
            ).apply { marginEnd = dp(8) })

            // 3. Nút Đóng (✕)
            val closeTopBtn = TextView(context).apply {
                text = "✕"
                setTextColor(Color.parseColor("#9AA0A6"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setPadding(dp(6), dp(6), dp(6), dp(6))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor("#2D2F31"))
                }
                setOnClickListener {
                    stop(context)
                }
            }
            row1.addView(closeTopBtn, LinearLayout.LayoutParams(dp(28), dp(28)))

            rootContainer.addView(row1, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ))

            // --- HÀNG 2: Hàng các nút hành động (Dịch lại, Ẩn/Hiện, Khoanh tìm) tách riêng không chen chúc ---
            val row2 = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }

            // Nút 1: Dịch lại ngay
            val refreshBtn = createPillButton(
                context = context,
                label = tr("🔄 Dịch lại"),
                bgColorHex = "#2D2F31",
                borderColorHex = "#3C4043",
                isFirst = true
            ) {
                isBoxesTemporarilyHidden = false
                if (arOverlayView == null) {
                    ensureOverlayViewsCreated(context)
                }
                hideShowBtnView?.text = tr("👁 Ẩn")
                NoAccessibilityScreenEngine.clearCachedScreenNodes()
                lastNodesSignature = ""
                lastTranslatedNodes = emptyList()
                statusBadgeTextView?.text = tr("🌐 Đang quét & dịch lại...")
                triggerZeroLatencyScan(context, forceRescan = true)
            }
            row2.addView(refreshBtn)

            // Nút 2: Tạm Ẩn / Hiện bản dịch
            val toggleBtn = createPillButton(
                context = context,
                label = tr("👁 Ẩn"),
                bgColorHex = "#2D2F31",
                borderColorHex = "#3C4043",
                isFirst = false
            ) {
                isBoxesTemporarilyHidden = !isBoxesTemporarilyHidden
                if (isBoxesTemporarilyHidden) {
                    pendingTouchTargetRunnable?.let { mainHandler.removeCallbacks(it) }
                    pendingTouchTargetRunnable = null
                    pendingScrollScanRunnable?.let { mainHandler.removeCallbacks(it) }
                    pendingScrollScanRunnable = null
                    fastTrackJob?.cancel()
                    pendingRefreshJob?.cancel()
                    try { scope.coroutineContext.cancelChildren() } catch (_: Throwable) {}
                    try { streamingTranslateScope.coroutineContext.cancelChildren() } catch (_: Throwable) {}
                    stopFullPageReading()
                    clearBoxTouchTargets(context)

                    // GỠ BỎ HOÀN TOÀN arOverlayView khỏi WindowManager thay vì chỉ set View.GONE
                    val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
                    arOverlayView?.let { overlay ->
                        try {
                            if (overlay.isAttachedToWindow) {
                                wm?.removeViewImmediate(overlay)
                            } else {
                                wm?.removeView(overlay)
                            }
                        } catch (_: Throwable) {}
                    }
                    arOverlayView = null

                    hideShowBtnView?.text = tr("👁 Hiện")
                    statusBadgeTextView?.text = tr("Đã tạm ẩn")
                    NoAccessibilityScreenEngine.isLiveScrollTranslateActive = false
                    com.example.core.service.MagicTuneCtsAccessibilityService.clearLiveScrollLease()
                    com.example.core.service.MagicTuneCtsAccessibilityService.updateEventSubscriptionForLiveScroll(false)
                    NoAccessibilityScreenEngine.disableServiceIfIdle(context, 60L)
                } else {
                    hideShowBtnView?.text = tr("👁 Ẩn")
                    NoAccessibilityScreenEngine.isLiveScrollTranslateActive = true
                    com.example.core.service.MagicTuneCtsAccessibilityService.touchLiveScrollLease(context)
                    ensureOverlayViewsCreated(context)
                    scope.launch(Dispatchers.Default) {
                        NoAccessibilityScreenEngine.autoWakeAccessibilityIfNeeded(context, 1300L)
                        com.example.core.service.MagicTuneCtsAccessibilityService.updateEventSubscriptionForLiveScroll(true)
                    }
                    lastNodesSignature = ""
                    lastTranslatedNodes = emptyList()
                    statusBadgeTextView?.text = tr("Tự động ▾ → Tiếng Việt ▾")
                    triggerZeroLatencyScan(context, forceRescan = true)
                }
            }
            hideShowBtnView = toggleBtn
            row2.addView(toggleBtn)

            // Nút 3: Chuyển sang Khoanh Màn Hình
            val circleBtn = createPillButton(
                context = context,
                label = tr("🔍 Khoanh tìm"),
                bgColorHex = "#2D2F31",
                borderColorHex = "#3C4043",
                isFirst = false
            ) {
                stop(context)
                CircleToSearchOverlayActivity.launch(context)
            }
            row2.addView(circleBtn)

            rootContainer.addView(row2, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(6)
            })

            val barParams = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                y = dp(56)
                ScreenPowerOptimizer.applyEcoRefreshRateToWindow(this)
            }

            // Tự động ẩn thanh điều khiển khi bất kỳ bàn phím ảo nào (bao gồm Laban Key, Gboard, Baidu IME...) xuất hiện
            val decorView = controlBarView?.rootView ?: rootContainer.rootView
            decorView.setOnApplyWindowInsetsListener { _, insets ->
                try {
                    val isImeVisible = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        insets.isVisible(android.view.WindowInsets.Type.ime())
                    } else {
                        val r = android.graphics.Rect()
                        rootContainer.getWindowVisibleDisplayFrame(r)
                        val screenHeight = context.resources.displayMetrics.heightPixels.coerceAtLeast(1)
                        (screenHeight - r.bottom) > screenHeight * 0.12
                    }

                    if (isImeVisible) {
                        if (rootContainer.visibility == View.VISIBLE) {
                            rootContainer.visibility = View.GONE
                        }
                    } else {
                        if (rootContainer.visibility != View.VISIBLE && isRunning) {
                            rootContainer.visibility = View.VISIBLE
                        }
                    }
                } catch (_: Throwable) {}
                insets
            }

            // Fallback kiểm tra qua Global Layout CHỈ trên Android < 11 (Android 11+ đã có WindowInsets IME 0ms, tránh Binder IPC liên tục)
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
                val listener = ViewTreeObserver.OnGlobalLayoutListener {
                    if (!isRunning) return@OnGlobalLayoutListener
                    try {
                        val r = android.graphics.Rect()
                        rootContainer.getWindowVisibleDisplayFrame(r)
                        val screenHeight = context.resources.displayMetrics.heightPixels.coerceAtLeast(1)
                        val keypadHeight = screenHeight - r.bottom
                        if (keypadHeight > screenHeight * 0.10) {
                            if (rootContainer.visibility == View.VISIBLE) {
                                rootContainer.visibility = View.GONE
                            }
                        } else {
                            if (rootContainer.visibility != View.VISIBLE && isRunning) {
                                rootContainer.visibility = View.VISIBLE
                            }
                        }
                    } catch (_: Throwable) {}
                }
                controlBarGlobalLayoutListener = listener
                rootContainer.viewTreeObserver.addOnGlobalLayoutListener(listener)
            }

            // Cho phép người dùng nắm kéo thanh điều khiển tới bất kỳ vị trí nào nếu vướng nút mua hàng
            var initialX = 0
            var initialY = 0
            var initialTouchX = 0f
            var initialTouchY = 0f
            val dragTouchListener = View.OnTouchListener { _, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = barParams.x
                        initialY = barParams.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - initialTouchX).toInt()
                        val dy = (initialTouchY - event.rawY).toInt()
                        barParams.x = initialX + dx
                        barParams.y = (initialY + dy).coerceIn(dp(24), context.resources.displayMetrics.heightPixels - dp(100))
                        try {
                            wm.updateViewLayout(rootContainer, barParams)
                        } catch (_: Throwable) {}
                        true
                    }
                    else -> false
                }
            }
            rootContainer.setOnTouchListener(dragTouchListener)
            statusTv.setOnTouchListener(dragTouchListener)

            try {
                wm.addView(rootContainer, barParams)
                controlBarView = rootContainer
            } catch (_: Throwable) {}
        }

        // 3. Nút Loa duy nhất ở góc trên cùng màn hình (Đọc toàn bộ màn hình: Truyện & Báo)
        if (topCornerSpeakerBtn == null) {
            val density = context.resources.displayMetrics.density
            fun dp(v: Int): Int = (v * density).toInt()

            val speakerContainer = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(6), dp(10), dp(6))
                elevation = dp(8).toFloat()
                isClickable = true
                setOnClickListener {
                    toggleFullPageReading(context)
                }
            }

            val iconTv = TextView(context).apply {
                text = "🔊"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                setPadding(0, 0, dp(4), 0)
            }
            topCornerSpeakerIcon = iconTv
            speakerContainer.addView(iconTv)

            val labelTv = TextView(context).apply {
                text = tr("Đọc màn hình")
                setTextColor(Color.parseColor("#E0F2FE"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
                typeface = Typeface.DEFAULT_BOLD
            }
            topCornerSpeakerLabel = labelTv
            speakerContainer.addView(labelTv)

            topCornerSpeakerBtn = speakerContainer
            updateTopCornerSpeakerUi(isReading = false)

            val speakerParams = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.END
                x = dp(10)
                y = dp(42) // Góc trên bên phải, ngay dưới thanh trạng thái
            }

            try {
                wm.addView(speakerContainer, speakerParams)
            } catch (_: Throwable) {}
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createPillButton(
        context: Context,
        label: String,
        bgColorHex: String,
        borderColorHex: String,
        isFirst: Boolean = false,
        onClick: () -> Unit
    ): TextView {
        val density = context.resources.displayMetrics.density
        fun dp(v: Int): Int = (v * density).toInt()

        return TextView(context).apply {
            text = label
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            minHeight = dp(34)
            minWidth = dp(0)
            setPadding(dp(10), dp(5), dp(10), dp(5))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(17).toFloat()
                setColor(Color.parseColor(bgColorHex))
                setStroke(dp(1), Color.parseColor(borderColorHex))
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                marginStart = if (isFirst) 0 else dp(4)
                marginEnd = dp(4)
            }
            isClickable = true
            setOnTouchListener { v, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        v.alpha = 0.78f
                        v.scaleX = 0.96f
                        v.scaleY = 0.96f
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        v.alpha = 1.0f
                        v.scaleX = 1.0f
                        v.scaleY = 1.0f
                    }
                }
                false
            }
            setOnClickListener {
                try {
                    it.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
                } catch (_: Throwable) {}
                onClick()
            }
        }
    }

    private var ttsMediaPlayer: MediaPlayer? = null
    private var nativeTts: TextToSpeech? = null
    private var isNativeTtsReady: Boolean = false

    // TTS Batching: gom nhiều đoạn text nhỏ thành một câu trước khi phát
    // Giảm số lần gọi TTS API / MediaPlayer init / network request
    private val ttsBatchQueue = mutableListOf<String>()
    private var ttsBatchJob: Job? = null
    private val ttsBatchDelayMs = 300L // delay 300ms để gom đoạn

    fun clearBoxTouchTargets(context: Context) {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
        for (btn in activeTouchTargetViews) {
            try {
                if (btn.isAttachedToWindow) {
                    wm.removeViewImmediate(btn)
                } else {
                    wm.removeView(btn)
                }
            } catch (_: Throwable) {}
        }
        activeTouchTargetViews.clear()
        lastPlacedPairsSignature = ""
    }

    private fun formatTranslationForNaturalVietnameseSpeech(text: String): String {
        return GoogleScreenTranslator.formatTranslationForNaturalVietnameseSpeech(text)
    }

    /**
     * Phát âm thanh bản dịch tiếng Việt:
     * - Tự động ưu tiên Google Neural TTS phát trực tiếp qua URL translate_tts để đạt giọng đọc tự nhiên chuẩn Google.
     * - Tự động fallback sang Android Native TTS nếu không có mạng.
     * - Hỗ trợ callback `onDone` khi phát xong để chuyển câu tiếp theo trong chế độ Đọc toàn màn hình.
     * - TTS Batching: gom nhiều đoạn text nhỏ trong 300ms thành một câu để giảm network/MediaPlayer init.
     */
    fun speakVietnameseTranslation(context: Context, rawText: String, onDone: (() -> Unit)? = null) {
        val appCtx = context.applicationContext ?: context
        val spokenText = formatTranslationForNaturalVietnameseSpeech(rawText)
        if (spokenText.isBlank()) {
            onDone?.invoke()
            return
        }

        // TTS Batching: thêm vào queue, sẽ gom và phát sau ttsBatchDelayMs
        ttsBatchQueue.add(spokenText)
        val currentOnDone = onDone

        ttsBatchJob?.cancel()
        ttsBatchJob = CoroutineScope(Dispatchers.Main).launch {
            delay(ttsBatchDelayMs)
            // Gom tất cả text trong queue thành một câu
            val combinedText = ttsBatchQueue.joinToString(" ") { it }
            ttsBatchQueue.clear()
            // Phát câu đã gom
            speakVietnameseTranslationInternal(appCtx, combinedText, currentOnDone)
        }
    }

    /**
     * Internal function: phát TTS thực tế (không batching)
     * Được gọi bởi speakVietnameseTranslation sau khi đã gom text
     */
    private fun speakVietnameseTranslationInternal(appCtx: Context, spokenText: String, onDone: (() -> Unit)? = null) {
        if (spokenText.isBlank()) {
            onDone?.invoke()
            return
        }

        ttsJob?.cancel()
        ttsJob = CoroutineScope(Dispatchers.IO).launch {
            var conn: HttpURLConnection? = null
            try {
                val encoded = URLEncoder.encode(spokenText, "UTF-8")
                val ttsUrl = "https://translate.googleapis.com/translate_tts?ie=UTF-8&q=$encoded&tl=vi&client=gtx"
                conn = (URL(ttsUrl).openConnection() as HttpURLConnection).apply {
                    setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14)")
                    connectTimeout = 3000
                    readTimeout = 4000
                }
                if (conn.responseCode == 200) {
                    val bytes = conn.inputStream.readBytes()
                    if (bytes.size > 256) {
                        withContext(Dispatchers.Main) {
                            try {
                                ttsMediaPlayer?.stop()
                                ttsMediaPlayer?.release()
                            } catch (_: Throwable) {}
                            val tempFile = File.createTempFile("tts_scroll_", ".mp3", appCtx.cacheDir)
                            tempFile.writeBytes(bytes)
                            ttsMediaPlayer = MediaPlayer().apply {
                                setDataSource(tempFile.absolutePath)
                                setAudioAttributes(
                                    AudioAttributes.Builder()
                                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                                        .build()
                                )
                                prepare()
                                start()
                                setOnCompletionListener {
                                    try {
                                        it.release()
                                        tempFile.delete()
                                    } catch (_: Throwable) {}
                                    ttsMediaPlayer = null
                                    onDone?.invoke()
                                }
                                setOnErrorListener { _, _, _ ->
                                    try {
                                        tempFile.delete()
                                    } catch (_: Throwable) {}
                                    ttsMediaPlayer = null
                                    onDone?.invoke()
                                    true
                                }
                            }
                        }
                        return@launch
                    }
                }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Throwable) {
            } finally {
                try { conn?.disconnect() } catch (_: Throwable) {}
            }

            // Fallback Android Native TTS
            withContext(Dispatchers.Main) {
                if (nativeTts == null) {
                    nativeTts = TextToSpeech(appCtx) { status ->
                        if (status == TextToSpeech.SUCCESS) {
                            nativeTts?.language = Locale.forLanguageTag("vi-VN")
                            isNativeTtsReady = true
                            nativeTts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                                override fun onStart(utteranceId: String?) {}
                                override fun onDone(utteranceId: String?) {
                                    mainHandler.post { onDone?.invoke() }
                                }
                                override fun onError(utteranceId: String?) {
                                    mainHandler.post { onDone?.invoke() }
                                }
                            })
                            nativeTts?.speak(spokenText, TextToSpeech.QUEUE_FLUSH, null, "scroll_tts_${System.currentTimeMillis()}")
                        } else {
                            onDone?.invoke()
                        }
                    }
                } else if (isNativeTtsReady) {
                    nativeTts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {}
                        override fun onDone(utteranceId: String?) {
                            mainHandler.post { onDone?.invoke() }
                        }
                        override fun onError(utteranceId: String?) {
                            mainHandler.post { onDone?.invoke() }
                        }
                    })
                    nativeTts?.speak(spokenText, TextToSpeech.QUEUE_FLUSH, null, "scroll_tts_${System.currentTimeMillis()}")
                } else {
                    onDone?.invoke()
                }
            }
        }
    }

    /**
     * Dừng phát toàn bộ âm thanh (cả MediaPlayer và Android Native TTS)
     */
    fun stopAllAudioPlayback() {
        ttsJob?.cancel()
        ttsJob = null
        ttsBatchJob?.cancel()
        ttsBatchJob = null
        ttsBatchQueue.clear()
        try {
            ttsMediaPlayer?.stop()
            ttsMediaPlayer?.release()
        } catch (_: Throwable) {}
        ttsMediaPlayer = null

        try {
            nativeTts?.stop()
        } catch (_: Throwable) {}

        currentlyPlayingBox = null
        currentlyPlayingText = null
        statusBadgeTextView?.text = tr("Tự động ▾ → Tiếng Việt ▾")
    }

    /**
     * V4.0: Bấm trực tiếp vào văn bản dịch để phát âm thanh:
     * - Ấn 1 lần là phát bản dịch Tiếng Việt tự nhiên.
     * - Ấn lần 2 là dừng.
     * - Viền Google Blue (#8AB4F8) và hiệu ứng sóng âm thanh (Equalizer ılı.) biểu thị hộp đang phát.
     */
    fun toggleBoxAudioPlayback(context: Context, box: CircleToSearchOverlayActivity.TranslatedTextBox) {
        val appCtx = context.applicationContext ?: context
        if (isFullPageReadingActive) {
            stopFullPageReading()
        }

        // Nếu hộp này đang phát -> Ấn lần 2 để DỪNG
        if (currentlyPlayingBox == box || (currentlyPlayingText != null && currentlyPlayingText == box.translatedText)) {
            stopAllAudioPlayback()
            statusBadgeTextView?.text = tr("Tự động ▾ → Tiếng Việt ▾")
            if (isRunning && !isBoxesTemporarilyHidden && !isScreenPaused) {
                arOverlayView?.postInvalidateOnAnimation()
            }
            return
        }

        // Ấn lần 1 -> BẮT ĐẦU PHÁT
        stopAllAudioPlayback()
        currentlyPlayingBox = box
        currentlyPlayingText = box.translatedText
        statusBadgeTextView?.text = "🔊 ${box.translatedText.take(20)}..."
        if (isRunning && !isBoxesTemporarilyHidden && !isScreenPaused) {
            arOverlayView?.postInvalidateOnAnimation()
        }

        speakVietnameseTranslation(appCtx, box.translatedText) {
            mainHandler.post {
                if (currentlyPlayingBox == box || currentlyPlayingText == box.translatedText) {
                    currentlyPlayingBox = null
                    currentlyPlayingText = null
                    statusBadgeTextView?.text = tr("Tự động ▾ → Tiếng Việt ▾")
                    if (isRunning && !isBoxesTemporarilyHidden && !isScreenPaused) {
                        arOverlayView?.postInvalidateOnAnimation()
                    }
                }
            }
        }
    }

    private var lastPlacedPairsSignature: String = ""

    /**
     * Lập lịch cập nhật vùng chạm (Debounced 80ms) sau khi vẽ xong khung hình AR Boxes:
     * Tránh gọi cập nhật WindowManager liên tục khi đang lướt cuộn nhanh.
     */
    fun scheduleTouchTargetUpdate(
        context: Context,
        placedBoxes: List<Pair<CircleToSearchOverlayActivity.TranslatedTextBox, RectF>>
    ) {
        if (!isRunning || isBoxesTemporarilyHidden || isScreenPaused) {
            clearBoxTouchTargets(context)
            return
        }

        val signature = buildString {
            for ((box, r) in placedBoxes) {
                append(box.translatedText.hashCode()).append(':')
                append(r.left.toInt()).append(',').append(r.top.toInt()).append(',')
                append(r.width().toInt()).append(',').append(r.height().toInt()).append(';')
            }
        }
        if (signature == lastPlacedPairsSignature) {
            return
        }

        pendingTouchTargetRunnable?.let { mainHandler.removeCallbacks(it) }
        val r = Runnable {
            if (isRunning && !isBoxesTemporarilyHidden && !isScreenPaused) {
                lastPlacedPairsSignature = signature
                updateBoxTouchTargets(context, placedBoxes)
            }
        }
        pendingTouchTargetRunnable = r
        mainHandler.postDelayed(r, 80L)
    }

    /**
     * Cập nhật vùng chạm tương tác trong suốt (Interactive Touch Targets) phủ đúng lên từng hộp văn bản dịch.
     * Người dùng chạm trực tiếp vào hộp dịch bất kỳ để phát/dừng phát âm,
     * các vùng ngoài hộp dịch để trống 100% cho người dùng vuốt cuộn sách báo, truyện tranh mượt mà!
     */
    fun updateBoxTouchTargets(context: Context, placedBoxes: List<Pair<CircleToSearchOverlayActivity.TranslatedTextBox, RectF>>) {
        if (!isRunning || isBoxesTemporarilyHidden || isScreenPaused) {
            clearBoxTouchTargets(context)
            return
        }
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        while (activeTouchTargetViews.size > placedBoxes.size) {
            val lastIdx = activeTouchTargetViews.size - 1
            val removeView = activeTouchTargetViews.removeAt(lastIdx)
            try {
                if (removeView.isAttachedToWindow) {
                    wm.removeViewImmediate(removeView)
                } else {
                    wm.removeView(removeView)
                }
            } catch (_: Throwable) {}
        }

        val density = context.resources.displayMetrics.density
        val minTouchSize = (36f * density).toInt()

        for (i in placedBoxes.indices) {
            val (box, rect) = placedBoxes[i]
            val touchW = rect.width().toInt().coerceAtLeast(minTouchSize)
            val touchH = rect.height().toInt().coerceAtLeast(minTouchSize)
            val diffX = (touchW - rect.width().toInt()) / 2
            val diffY = (touchH - rect.height().toInt()) / 2
            val touchX = (rect.left.toInt() - diffX).coerceAtLeast(0)
            val touchY = (rect.top.toInt() - diffY).coerceAtLeast(0)

            if (i < activeTouchTargetViews.size) {
                val view = activeTouchTargetViews[i]
                val lp = view.layoutParams as? WindowManager.LayoutParams ?: continue
                if (lp.x != touchX || lp.y != touchY || lp.width != touchW || lp.height != touchH) {
                    lp.x = touchX
                    lp.y = touchY
                    lp.width = touchW
                    lp.height = touchH
                    try {
                        wm.updateViewLayout(view, lp)
                    } catch (_: Throwable) {}
                }
                bindTouchTargetEvents(view, context, box)
            } else {
                val touchView = View(context).apply {
                    setBackgroundColor(Color.TRANSPARENT)
                    isClickable = true
                }
                bindTouchTargetEvents(touchView, context, box)
                val lp = WindowManager.LayoutParams(
                    touchW,
                    touchH,
                    overlayType,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                        WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.TOP or Gravity.START
                    this.x = touchX
                    this.y = touchY
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                    }
                }
                try {
                    wm.addView(touchView, lp)
                    activeTouchTargetViews.add(touchView)
                } catch (_: Throwable) {}
            }
        }
    }

    private fun bindTouchTargetEvents(view: View, context: Context, box: CircleToSearchOverlayActivity.TranslatedTextBox) {
        val slop = ViewConfiguration.get(context).scaledTouchSlop
        view.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0f
            private var startY = 0f
            private var startTime = 0L

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = event.rawX
                        startY = event.rawY
                        startTime = System.currentTimeMillis()
                        v.alpha = 0.75f
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = abs(event.rawX - startX)
                        val dy = abs(event.rawY - startY)
                        if (dx > slop || dy > slop) {
                            v.alpha = 1.0f
                            // Người dùng vuốt màn hình để cuộn trang: giải phóng touch targets
                            clearBoxTouchTargets(context)
                            return false
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        v.alpha = 1.0f
                        val dx = abs(event.rawX - startX)
                        val dy = abs(event.rawY - startY)
                        val duration = System.currentTimeMillis() - startTime
                        if (dx <= slop && dy <= slop && duration < 600) {
                            try {
                                v.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
                            } catch (_: Throwable) {}
                            toggleBoxAudioPlayback(context, box)
                            return true
                        }
                        return false
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        v.alpha = 1.0f
                        return false
                    }
                }
                return false
            }
        })
    }

    /**
     * V4.0: THUẬT TOÁN LỌC NỘI DUNG TRUYỆN & BÁO CHÍ (Story & Article Smart Filter):
     * - Khi mở một trang sách báo hoặc trang truyện tranh/tiểu thuyết:
     *   Chỉ giữ lại câu văn, lời thoại nhân vật, đoạn văn tự sự và bài viết.
     * - Loại bỏ triệt để các thông tin dư thừa: menu, header, footer, số trang, like, share,
     *   bình luận, chap, quảng cáo, giá tiền, thời gian, tên tác giả...
     */
    fun filterStoryAndArticleContent(boxes: List<CircleToSearchOverlayActivity.TranslatedTextBox>): List<CircleToSearchOverlayActivity.TranslatedTextBox> {
        if (boxes.isEmpty()) return emptyList()

        val sorted = boxes.sortedWith(compareBy({ it.ymin }, { it.xmin }))

        val junkKeywords = setOf(
            "trang chủ", "menu", "tìm kiếm", "search", "đăng nhập", "login", "sign in", "đăng ký", "register",
            "thông báo", "cài đặt", "settings", "danh mục", "category", "bình luận", "comment", "chia sẻ", "share",
            "lượt thích", "like", "theo dõi", "follow", "subscribe", "xem thêm", "xem tiếp", "tiếp theo", "next",
            "quay lại", "back", "chương trước", "chương sau", "chap", "chapter", "tập", "trang", "page",
            "quảng cáo", "ad", "ads", "advertisement", "sponsored", "tải về", "download", "cài app", "tải app",
            "mua ngay", "buy now", "giá:", "vnd", "shopee", "lazada", "tiki", "facebook", "google", "youtube",
            "tiktok", "zalo", "instagram", "twitter", "x", "sao chép", "copy", "xóa", "sửa", "edit", "delete",
            "báo cáo", "report", "chính sách", "điều khoản", "bản quyền", "copyright", "all rights reserved"
        )

        val result = mutableListOf<CircleToSearchOverlayActivity.TranslatedTextBox>()

        for (box in sorted) {
            val text = box.translatedText.trim()
            if (text.length < 4) continue // Bỏ chuỗi quá ngắn

            val lower = text.lowercase()

            // Bỏ nếu là giá tiền quy đổi
            if (text.contains("≈") && text.contains("đ")) continue

            // Bỏ nếu ở sát mép đỉnh hoặc đáy màn hình và quá ngắn
            if ((box.ymin < 60 || box.ymin > 940) && text.length < 20) continue

            val words = text.split(Regex("""\s+""")).filter { it.isNotBlank() }
            if (words.isEmpty()) continue
            val numLetters = text.count { it.isLetter() }
            if (numLetters < 3) continue

            // Bỏ nếu là từ khóa rác điều hướng/quảng cáo
            var isJunk = false
            for (kw in junkKeywords) {
                if (lower == kw || lower == "$kw:" || lower == "• $kw" || lower == "- $kw") {
                    isJunk = true
                    break
                }
            }
            if (isJunk) continue

            if (words.size <= 3 && junkKeywords.any { lower.contains(it) }) {
                continue
            }

            // Đặc trưng văn bản truyện hoặc bài báo:
            // Có ít nhất 3 từ HOẶC có dấu câu báo chí/lời thoại ("", «», -, :, ., ,, !, ?)
            val hasSentenceStructure = words.size >= 3 ||
                text.contains(".") || text.contains(",") || text.contains("!") ||
                text.contains("?") || text.contains("“") || text.contains("\"") ||
                text.contains("—") || text.startsWith("-") || text.length >= 12

            if (hasSentenceStructure) {
                result.add(box)
            }
        }

        return result
    }

    /**
     * V4.0: Bấm Nút Loa duy nhất ở góc trên cùng màn hình để đọc toàn bộ truyện/báo trên màn hình:
     * - Ấn 1 lần: Bắt đầu đọc tuần tự toàn bộ nội dung truyện/báo từ trên xuống dưới.
     * - Ấn lần 2: Dừng đọc toàn màn hình ngay lập tức.
     */
    fun toggleFullPageReading(context: Context) {
        val appCtx = context.applicationContext ?: context
        if (isFullPageReadingActive) {
            stopFullPageReading()
            return
        }

        val boxes = arOverlayView?.getDisplayedBoxes() ?: emptyList()
        val storyBoxes = filterStoryAndArticleContent(boxes)

        if (storyBoxes.isEmpty()) {
            Toast.makeText(appCtx, tr("📖 Không phát hiện nội dung truyện hoặc báo trên màn hình"), Toast.LENGTH_SHORT).show()
            return
        }

        stopAllAudioPlayback()
        isFullPageReadingActive = true
        fullPageReadingQueue.clear()
        fullPageReadingQueue.addAll(storyBoxes)
        fullPageReadingIndex = 0

        updateTopCornerSpeakerUi(isReading = true)
        readNextStoryBox(appCtx)
    }

    private fun readNextStoryBox(context: Context) {
        if (!isFullPageReadingActive || fullPageReadingIndex >= fullPageReadingQueue.size) {
            stopFullPageReading()
            return
        }

        val box = fullPageReadingQueue[fullPageReadingIndex]
        currentlyPlayingBox = box
        currentlyPlayingText = box.translatedText
        if (isRunning && !isBoxesTemporarilyHidden && !isScreenPaused) {
            arOverlayView?.postInvalidateOnAnimation()
        }

        speakVietnameseTranslation(context, box.translatedText) {
            mainHandler.post {
                if (isFullPageReadingActive) {
                    fullPageReadingIndex++
                    readNextStoryBox(context)
                }
            }
        }
    }

    fun stopFullPageReading() {
        isFullPageReadingActive = false
        fullPageReadingQueue.clear()
        fullPageReadingIndex = 0
        updateTopCornerSpeakerUi(isReading = false)
        stopAllAudioPlayback()
        if (isRunning && !isBoxesTemporarilyHidden && !isScreenPaused) {
            arOverlayView?.postInvalidateOnAnimation()
        }
    }

    private fun updateTopCornerSpeakerUi(isReading: Boolean) {
        val density = topCornerSpeakerBtn?.resources?.displayMetrics?.density ?: 2f
        fun dp(v: Int): Int = (v * density).toInt()

        topCornerSpeakerBtn?.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(18).toFloat()
            if (isReading) {
                setColor(Color.parseColor("#E61E293B"))
                setStroke(dp(1), Color.parseColor("#8AB4F8")) // Google Blue
            } else {
                setColor(Color.parseColor("#F01E1F22")) // Google Dark Surface
                setStroke(dp(1), Color.parseColor("#3C4043"))
            }
        }
        topCornerSpeakerIcon?.text = if (isReading) "⏹️" else "🔊"
        topCornerSpeakerLabel?.text = if (isReading) tr("Dừng đọc (ılı.)") else tr("Đọc màn hình")
        topCornerSpeakerLabel?.setTextColor(if (isReading) Color.parseColor("#8AB4F8") else Color.parseColor("#E8EAED"))
    }

    private fun removeOverlayViews(context: Context) {
        stopFullPageReading()
        clearBoxTouchTargets(context)

        val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
        topCornerSpeakerBtn?.let { btn ->
            try {
                if (btn.isAttachedToWindow) {
                    wm.removeViewImmediate(btn)
                } else {
                    wm.removeView(btn)
                }
            } catch (_: Throwable) {}
        }
        topCornerSpeakerBtn = null
        topCornerSpeakerIcon = null
        topCornerSpeakerLabel = null

        arOverlayView?.let { overlay ->
            try {
                if (overlay.isAttachedToWindow) {
                    wm.removeViewImmediate(overlay)
                } else {
                    wm.removeView(overlay)
                }
            } catch (_: Throwable) {}
        }
        arOverlayView = null

        controlBarView?.let { bar ->
            controlBarGlobalLayoutListener?.let { listener ->
                try {
                    if (bar.viewTreeObserver.isAlive) {
                        bar.viewTreeObserver.removeOnGlobalLayoutListener(listener)
                    }
                } catch (_: Throwable) {}
            }
            controlBarGlobalLayoutListener = null
            try {
                if (bar.isAttachedToWindow) {
                    wm.removeViewImmediate(bar)
                } else {
                    wm.removeView(bar)
                }
            } catch (_: Throwable) {}
        }
        controlBarView = null
        statusBadgeTextView = null
        hideShowBtnView = null
    }

    /**
     * Custom View vẽ trực tiếp các hộp chữ Google Dịch nhỏ gọn (8.8sp), tự động xuống dòng
     * và né nhau (Collision-Resolved) ngay trên tọa độ văn bản gốc.
     * Tích hợp bộ nhớ đệm `StaticLayout` (Cached Layout Pool) để hàm `onDraw` đạt chuẩn 120FPS không giật lag khi cuộn nhanh.
     */
    private class LiveArBoxesCanvasView(context: Context) : View(context) {
        private var displayedBoxes: List<CircleToSearchOverlayActivity.TranslatedTextBox> = emptyList()
        private var overallAlpha: Float = 1f

        fun updateBoxes(newBoxes: List<CircleToSearchOverlayActivity.TranslatedTextBox>) {
            if (!isRunning || isBoxesTemporarilyHidden || isScreenPaused) {
                return
            }
            if (newBoxes.isEmpty()) {
                return
            }

            // Sắp xếp các hộp theo luồng tự nhiên từ trên xuống dưới (Top-to-Bottom Flow)
            val sorted = newBoxes.sortedWith(compareBy({ it.ymin }, { it.xmin }))

            // Nếu vị trí và nội dung dịch ổn định (chưa xê dịch quá 8.0px), không vẽ lại để chống rung mắt tuyệt đối
            if (sorted.size == displayedBoxes.size &&
                sorted.zip(displayedBoxes).all { (a, b) ->
                    a.originalText == b.originalText &&
                    a.translatedText == b.translatedText &&
                    abs(a.ymin - b.ymin) < 8.0f &&
                    abs(a.xmin - b.xmin) < 8.0f
                }
            ) {
                return
            }

            displayedBoxes = sorted
            postInvalidateOnAnimation()
        }

        fun getDisplayedBoxes(): List<CircleToSearchOverlayActivity.TranslatedTextBox> = displayedBoxes

        override fun onDetachedFromWindow() {
            super.onDetachedFromWindow()
            displayedBoxes = emptyList()
            clearBoxTouchTargets(context)
        }

        fun forceClearBoxes() {
            displayedBoxes = emptyList()
            // Không gọi postInvalidateOnAnimation() khi dọn dẹp để không ép GPU vẽ thêm khung hình rác
            mainHandler.post {
                clearBoxTouchTargets(context)
            }
        }

        private val density = context.resources.displayMetrics.density
        private val scaledDensity = context.resources.configuration.fontScale * context.resources.displayMetrics.density

        private val layoutCacheLock = Any()
        private val layoutCache = object : LinkedHashMap<String, Pair<StaticLayout, Float>>(128, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Pair<StaticLayout, Float>>?): Boolean = size > 300
        }
        private val placedRects = ArrayList<RectF>(24)
        private val rectPool = ArrayList<RectF>(24)
        private val candidateRect = RectF()
        private val waveRect = RectF()

        private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.parseColor("#E6181C20") // Google Lens Dark Surface chip 90%
        }
        private val priceBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.parseColor("#E627272A") // Google Lens Dark Amber chip cho tiền tệ VNĐ
        }
        private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 0.6f * density
            color = Color.parseColor("#26FFFFFF") // Viền mờ 15% tinh tế chuẩn Google Lens
        }
        private val priceBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 0.8f * density
            color = Color.parseColor("#33F59E0B") // Viền hổ phách nhẹ cho giá tiền
        }
        private val playingBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 1.2f * density
            color = Color.parseColor("#8AB4F8") // Viền Google Blue khi đang phát âm thanh
        }
        private val playingWavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.parseColor("#8AB4F8") // Sóng âm thanh Google Blue
        }
        private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 9.0f * scaledDensity
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            setShadowLayer(1.5f * density, 0f, 1f * density, Color.parseColor("#99000000"))
        }

        fun setScrollingAlpha(alpha: Float) {
            if (abs(overallAlpha - alpha) > 0.05f) {
                overallAlpha = alpha
                this.alpha = alpha
            }
        }

        private fun getOrBuildStaticLayout(text: String, textWidthBucket: Int): Pair<StaticLayout, Float> {
            val key = "$text|$textWidthBucket"
            synchronized(layoutCacheLock) {
                layoutCache[key]?.let { return it }
            }

            val staticLayout = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                StaticLayout.Builder.obtain(text, 0, text.length, textPaint, textWidthBucket)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .setLineSpacing(0f, 0.96f)
                    .setIncludePad(false)
                    .setMaxLines(3)
                    .build()
            } else {
                @Suppress("DEPRECATION")
                StaticLayout(text, textPaint, textWidthBucket, Layout.Alignment.ALIGN_NORMAL, 0.96f, 0f, false)
            }

            var maxLineW = 0f
            for (line in 0 until staticLayout.lineCount) {
                maxLineW = max(maxLineW, staticLayout.getLineWidth(line))
            }

            val pair = Pair(staticLayout, maxLineW)
            synchronized(layoutCacheLock) {
                layoutCache[key] = pair
            }
            return pair
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat()
            val h = height.toFloat()
            if (w <= 0f || h <= 0f || displayedBoxes.isEmpty()) return

            val padH = 4.0f * density
            val padV = 2.5f * density
            val cornerRadius = 4.0f * density

            placedRects.clear()
            val placedPairs = ArrayList<Pair<CircleToSearchOverlayActivity.TranslatedTextBox, RectF>>(displayedBoxes.size)
            var poolIdx = 0
            val verticalMargin = 3.0f * density

            for (box in displayedBoxes) {
                val rawLeft = (box.xmin / 1000f) * w
                val rawTop = (box.ymin / 1000f) * h
                val rawRight = (box.xmax / 1000f) * w

                val maxAvailW = (w - rawLeft - 8f * density).coerceIn(60f * density, w - 16f * density)
                val availWidth = max(rawRight - rawLeft + 14f * density, 60f * density).coerceAtMost(maxAvailW).toInt()
                val rawTextWidth = (availWidth - (padH * 2).toInt()).coerceAtLeast((44f * density).toInt())
                val textWidthBucket = ((rawTextWidth + 7) / 8) * 8

                val (staticLayout, maxLineW) = getOrBuildStaticLayout(box.translatedText, textWidthBucket)

                val boxW = maxLineW + padH * 2
                val boxH = staticLayout.height + padV * 2

                val drawLeft = rawLeft.coerceIn(2f * density, (w - boxW - 2f * density).coerceAtLeast(2f * density))
                var drawTop = rawTop.coerceIn(2f * density, (h - boxH - 2f * density).coerceAtLeast(2f * density))
                candidateRect.set(drawLeft, drawTop, drawLeft + boxW, drawTop + boxH)

                // =========================================================================
                // THUẬT TOÁN TỰ ĐỘNG NHƯỜNG VÀ NÉ NHAU (COLLISION DODGE & YIELD ENGINE):
                // 1. Kiểm tra va chạm với toàn bộ các hộp bản dịch đã vẽ trước đó.
                // 2. Nếu trùng lặp chiều ngang và đè lên nhau theo chiều dọc:
                //    Hộp hiện tại TỰ ĐỘNG NHƯỜNG và LÙI XUỐNG DƯỚI mép đáy của hộp bên trên (+ margin 3dp).
                // 3. Tiếp tục lặp đến khi tìm được vị trí hoàn toàn trống trải, tuyệt đối KHÔNG đè chữ!
                // =========================================================================
                var hasCollision = true
                var shiftAttempts = 0
                while (hasCollision && shiftAttempts < 6) {
                    hasCollision = false
                    shiftAttempts++
                    for (placed in placedRects) {
                        val horizontalOverlap = candidateRect.left < placed.right - 2f * density &&
                            candidateRect.right > placed.left + 2f * density
                        val verticalOverlap = candidateRect.top < placed.bottom &&
                            candidateRect.bottom > placed.top
                        if (horizontalOverlap && verticalOverlap) {
                            // CÓ VA CHẠM: Nhường không gian, lùi xuống dưới hộp đã vẽ
                            drawTop = placed.bottom + verticalMargin
                            candidateRect.set(drawLeft, drawTop, drawLeft + boxW, drawTop + boxH)
                            hasCollision = true
                            break
                        }
                    }
                }

                // Nếu lùi quá sâu vượt khỏi đáy màn hình thì bỏ qua
                if (candidateRect.top > h - 4f * density) {
                    continue
                }

                val storedRect = if (poolIdx < rectPool.size) {
                    rectPool[poolIdx].apply { set(candidateRect) }
                } else {
                    RectF(candidateRect).also { rectPool.add(it) }
                }
                poolIdx++
                placedRects.add(storedRect)
                placedPairs.add(Pair(box, RectF(storedRect)))

                val isPriceConverted = box.translatedText.contains("≈") && box.translatedText.contains("đ")
                val isPlayingThis = (currentlyPlayingBox == box || (currentlyPlayingText != null && currentlyPlayingText == box.translatedText))

                canvas.drawRoundRect(
                    candidateRect,
                    cornerRadius,
                    cornerRadius,
                    if (isPriceConverted) priceBgPaint else bgPaint
                )
                canvas.drawRoundRect(
                    candidateRect,
                    cornerRadius,
                    cornerRadius,
                    if (isPlayingThis) playingBorderPaint else if (isPriceConverted) priceBorderPaint else borderPaint
                )

                canvas.save()
                canvas.translate(candidateRect.left + padH, candidateRect.top + padV)
                staticLayout.draw(canvas)
                canvas.restore()

                // V4.0: Hiệu ứng sóng âm thanh nhỏ (Equalizer ılı.) biểu thị đang phát âm thanh ở cuối bản dịch
                if (isPlayingThis) {
                    val waveW = 12f * density
                    val waveH = 8f * density
                    val waveRight = candidateRect.right - 4f * density
                    val waveBottom = candidateRect.bottom - 3f * density
                    val waveLeft = waveRight - waveW
                    // Keep the indicator static: the former 110ms invalidation loop kept
                    // repainting this overlay surface even when the user was idle.
                    for (barIdx in 0..2) {
                        val barRatio = when (barIdx) {
                            0 -> 0.42f
                            1 -> 0.78f
                            else -> 0.56f
                        }
                        val barH = waveH * barRatio
                        val bLeft = waveLeft + barIdx * (4.2f * density)
                        val bTop = waveBottom - barH
                        val bRight = bLeft + 2.4f * density
                        waveRect.set(bLeft, bTop, bRight, waveBottom)
                        canvas.drawRoundRect(
                            waveRect,
                            1.2f * density,
                            1.2f * density,
                            playingWavePaint
                        )
                    }
                }
            }

            if (placedPairs.isNotEmpty() && !isBoxesTemporarilyHidden && !isScreenPaused) {
                // Keep system overlay windows bounded even when many translated boxes are
                // visible. All boxes remain readable; the first 24 retain tap-to-speak.
                scheduleTouchTargetUpdate(context, placedPairs.take(24))
            }
        }
    }
}
