package com.example.core.adb

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.RemoteInput
import com.example.MainActivity
import com.example.core.i18n.AppLanguageManager.tr
import com.example.core.shell.ShellEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Quản lý thông báo ghép nối ADB Không Dây tương tác trực tiếp (Inline RemoteInput) chuẩn Shizuku:
 * - Giúp người dùng nhập 6 số mã PIN ngay trên thanh thông báo trong khi vẫn đang mở màn hình Cài đặt.
 * - Ngăn chặn việc Android tự đóng hộp thoại mã ghép đôi khi chuyển ứng dụng.
 */
object AdbPairingNotificationManager {

    const val CHANNEL_ID = "magictune_adb_pairing_channel"
    const val NOTIFICATION_ID = 20020
    const val KEY_PAIRING_CODE = "key_adb_pairing_pin_code"

    const val ACTION_SUBMIT_PIN = "com.example.core.adb.ACTION_SUBMIT_PAIRING_PIN"
    const val ACTION_STOP_PAIRING = "com.example.core.adb.ACTION_STOP_PAIRING_SEARCH"
    const val EXTRA_PAIRING_PORT = "extra_pairing_port"

    /**
     * Cờ cấu hình bật thông báo ghép nối tương tác.
     */
    const val SHOW_PAIRING_NOTIFICATIONS = true

    @Volatile
    var activeShellEngine: ShellEngine? = null

    @Volatile
    var isNotificationPairingActive: Boolean = false

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var pairingObserverJob: kotlinx.coroutines.Job? = null

    @Volatile
    private var lastStartCallMs: Long = 0L

    @Volatile
    private var lastShownPinPort: Int? = null

    fun ensureChannel(context: Context) {
        if (!SHOW_PAIRING_NOTIFICATIONS) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(NotificationManager::class.java) ?: return
            val channel = NotificationChannel(
                CHANNEL_ID,
                tr(context, "Ghép nối Gỡ lỗi Wi-Fi (Chuẩn Shizuku)", "Wireless Debugging Pairing (Shizuku-style)"),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = tr(context, "Hiển thị ô nhập mã PIN 6 số ngay trên thanh thông báo khi phát hiện dịch vụ _adb-tls-pairing._tcp", "Show 6-digit PIN input directly in notification shade when _adb-tls-pairing._tcp is detected")
                enableVibration(false)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }
            nm.createNotificationChannel(channel)
        }
    }

    /**
     * Khởi chạy tiến trình lắng nghe NSD và ghim thông báo chờ ghép nối giống hệt Shizuku.
     */
    fun startInteractiveNotificationPairing(context: Context, shellEngine: ShellEngine? = null) {
        val engine = shellEngine ?: activeShellEngine ?: ShellEngine.getInstance(context.applicationContext)
        startInteractivePairingNotification(context, engine)
    }

    private const val PREF_PAIRING = "magictune_pairing_prefs"
    private const val KEY_FLOATING_KEYPAD = "floating_keypad_enabled"

    fun isFloatingKeypadEnabled(context: Context): Boolean = false

    fun setFloatingKeypadEnabled(context: Context, enabled: Boolean) {
        try {
            context.applicationContext
                .getSharedPreferences(PREF_PAIRING, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_FLOATING_KEYPAD, false)
                .apply()
        } catch (_: Throwable) {}
    }

    fun startInteractivePairingNotification(context: Context, shellEngine: ShellEngine) {
        val appCtx = context.applicationContext
        activeShellEngine = shellEngine
        if (!SHOW_PAIRING_NOTIFICATIONS) {
            stopInteractivePairingNotification(appCtx)
            return
        }

        val now = System.currentTimeMillis()
        val isDuplicateBurst = isNotificationPairingActive && (now - lastStartCallMs) < 600L
        lastStartCallMs = now

        isNotificationPairingActive = true
        ensureChannel(appCtx)

        val scanner = AdbNsdScanner.getInstance(appCtx)
        scanner.isPairingUiActive = true
        scanner.onPairingPortDiscovered = { port, _ ->
            if (isNotificationPairingActive && port in 1..65535 && lastShownPinPort != port) {
                showPinInputNotification(appCtx, port)
            }
        }
        scanner.onConnectPortDiscovered = { connectPort, _ ->
            // Chỉ tự động kết nối nếu thiết bị ĐÃ TỪNG ghép nối thành công trước đó và người dùng không chủ động ngắt
            scope.launch {
                if (shellEngine.hasPairedBefore() &&
                    !shellEngine.isUserWlanDisconnected() &&
                    !shellEngine.state.value.isWirelessAdbConnected
                ) {
                    val ok = shellEngine.connectWirelessAdb(connectPort)
                    if (ok) {
                        finalizePairingSuccessUi(appCtx, scanner)
                        showPairingResultNotification(
                            appCtx,
                            success = true,
                            title = tr(appCtx, "✅ Đã tự động kết nối WLAN ADB (Cổng $connectPort)", "✅ Auto-connected WLAN ADB (Port $connectPort)"),
                            message = tr(appCtx, "Dịch vụ _adb-tls-connect._tcp đã tự động kết nối thành công với quyền UID 2000!", "Service _adb-tls-connect._tcp connected with UID 2000!")
                        )
                    }
                }
            }
        }

        if (pairingObserverJob?.isActive != true) {
            pairingObserverJob = scope.launch {
                scanner.state.collect { st ->
                    if (!isNotificationPairingActive) return@collect
                    val discoveredPort = st.pairingPort
                    if (discoveredPort != null && discoveredPort in 1..65535 && lastShownPinPort != discoveredPort) {
                        showPinInputNotification(appCtx, discoveredPort)
                    }
                }
            }
        }

        if (!isDuplicateBurst) {
            // Xóa cổng ghép đôi cũ để tránh nhập PIN nhầm vào cổng đã hết hạn từ phiên trước
            scanner.refreshPairingDiscovery(clearPreviousPort = true)
            lastShownPinPort = null
            AdbFloatingPairingOverlay.dismiss()
            showSearchingNotification(appCtx)
        }
    }

    internal fun finalizePairingSuccessUi(appCtx: Context, scanner: AdbNsdScanner = AdbNsdScanner.getInstance(appCtx)) {
        isNotificationPairingActive = false
        lastShownPinPort = null
        pairingObserverJob?.cancel()
        pairingObserverJob = null
        scanner.isPairingUiActive = false
        scanner.onPairingPortDiscovered = null
        scanner.releaseMulticastLock()
        scanner.scheduleAutoStop(5_000L)
        AdbFloatingPairingOverlay.dismiss()
    }

    /**
     * Chạy vòng chờ tìm cổng chính & tự nối ngoài BroadcastReceiver để không bao giờ vượt giới hạn 10s ANR của goAsync().
     */
    internal fun completePostPairConnectAsync(appCtx: Context, pairingPort: Int, engine: ShellEngine) {
        val scanner = AdbNsdScanner.getInstance(appCtx)
        scope.launch {
            var connectPort = scanner.getBestConnectPort()
            var connectedOk = false
            if (connectPort != null && connectPort in 1..65535) {
                connectedOk = engine.connectWirelessAdb(connectPort)
            }
            if (!connectedOk) {
                scanner.refreshConnectDiscovery()
                for (i in 1..20) {
                    delay(450)
                    if (i == 10) {
                        scanner.refreshConnectDiscovery()
                    }
                    connectPort = scanner.getBestConnectPort()
                    if (connectPort != null && connectPort in 1..65535) {
                        connectedOk = engine.connectWirelessAdb(connectPort)
                        if (connectedOk) break
                    }
                }
            }

            if (connectedOk) {
                finalizePairingSuccessUi(appCtx, scanner)
                showPairingResultNotification(
                    context = appCtx,
                    success = true,
                    title = tr(appCtx, "✅ Ghép nối & Kết nối ADB thành công!", "✅ ADB Paired & Connected!"),
                    message = tr(appCtx, "Đã ghép nối cổng $pairingPort và tự động kết nối cổng chính $connectPort (UID 2000). Nhấn để mở MagicTune!", "Paired port $pairingPort and connected main port $connectPort (UID 2000). Tap to open MagicTune!")
                )
            } else {
                scanner.onConnectPortDiscovered = { discoveredPort, _ ->
                    scope.launch {
                        if (!engine.state.value.isWirelessAdbConnected && !engine.isUserWlanDisconnected()) {
                            val ok = engine.connectWirelessAdb(discoveredPort)
                            if (ok) {
                                finalizePairingSuccessUi(appCtx, scanner)
                                showPairingResultNotification(
                                    context = appCtx,
                                    success = true,
                                    title = tr(appCtx, "✅ Đã kết nối Direct ADB (Cổng $discoveredPort)", "✅ Direct ADB Connected (Port $discoveredPort)"),
                                    message = tr(appCtx, "Đã tự động kết nối cổng chính $discoveredPort (UID 2000) thành công!", "Auto-connected main port $discoveredPort (UID 2000)!")
                                )
                            }
                        }
                    }
                }
                showPairingResultNotification(
                    context = appCtx,
                    success = true,
                    title = tr(appCtx, "✅ Ghép nối mã PIN thành công!", "✅ PIN Pairing Succeeded!"),
                    message = tr(appCtx, "Đã ghép nối thành công tại cổng $pairingPort! Hãy quay lại MagicTune để phiên ADB tự động hoàn tất kết nối.", "Paired at port $pairingPort! Return to MagicTune to complete ADB connection.")
                )
            }
        }
    }

    fun stopInteractivePairingNotification(context: Context) {
        val appCtx = context.applicationContext
        isNotificationPairingActive = false
        lastShownPinPort = null
        pairingObserverJob?.cancel()
        pairingObserverJob = null
        val scanner = AdbNsdScanner.getInstance(appCtx)
        scanner.isPairingUiActive = false
        scanner.onPairingPortDiscovered = null
        scanner.onConnectPortDiscovered = null
        AdbFloatingPairingOverlay.dismiss()
        scanner.stopDiscovery()
        val nm = appCtx.getSystemService(NotificationManager::class.java)
        nm?.cancel(NOTIFICATION_ID)
    }

    fun showSearchingNotification(context: Context) {
        if (!SHOW_PAIRING_NOTIFICATIONS) return
        lastShownPinPort = null
        ensureChannel(context)
        val nm = context.getSystemService(NotificationManager::class.java) ?: return

        val remoteInput = RemoteInput.Builder(KEY_PAIRING_CODE)
            .setLabel(tr(context, "Nhập 6 số PIN (hoặc CỔNG 6_SỐ)...", "Enter 6-digit PIN (or PORT 6_DIGITS)..."))
            .setAllowFreeFormInput(true)
            .build()

        val submitIntent = Intent(context, AdbPairingReceiver::class.java).apply {
            action = ACTION_SUBMIT_PIN
            putExtra(EXTRA_PAIRING_PORT, 0)
        }
        val replyFlags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }
        val replyPendingIntent = PendingIntent.getBroadcast(context, 3, submitIntent, replyFlags)
        val quickInputAction = NotificationCompat.Action.Builder(
            com.example.R.drawable.ic_stat_magictune,
            tr(context, "⌨️ NHẬP 6 SỐ / CỔNG", "⌨️ ENTER 6 DIGITS / PORT"),
            replyPendingIntent
        )
            .addRemoteInput(remoteInput)
            .setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_REPLY)
            .setShowsUserInterface(false)
            .setAllowGeneratedReplies(false)
            .build()

        val stopIntent = Intent(context, AdbPairingReceiver::class.java).apply {
            action = ACTION_STOP_PAIRING
        }
        val stopPendingIntent = PendingIntent.getBroadcast(
            context,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val openSettingsIntent = Intent(android.provider.Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        val contentPendingIntent = PendingIntent.getActivity(
            context,
            2,
            openSettingsIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(com.example.R.drawable.ic_stat_magictune)
            .setContentTitle(tr(context, "🔍 Đang lắng nghe dịch vụ ghép nối ADB...", "🔍 Listening for ADB pairing service..."))
            .setContentText(tr(context, "Mở mã PIN 6 số rồi bấm '⌨️ NHẬP 6 SỐ / CỔNG' ngay bên dưới!", "Open 6-digit PIN and tap '⌨️ ENTER 6 DIGITS / PORT' below!"))
            .setStyle(
                NotificationCompat.BigTextStyle().bigText(
                    tr(
                        context,
                        "MagicTune đang quét tự động _adb-tls-pairing._tcp.\n" +
                            "👉 Mở Cài đặt nhà phát triển ➔ Gỡ lỗi qua Wi-Fi ➔ 'Ghép nối bằng mã ghép đôi'.\n" +
                            "Bạn có thể bấm '⌨️ NHẬP 6 SỐ / CỔNG' ngay lập tức (nhập 6 số, hoặc gõ 'CỔNG PIN' VD: 38475 123456).",
                        "MagicTune is scanning _adb-tls-pairing._tcp automatically.\n" +
                            "👉 Open Developer options ➔ Wireless debugging ➔ 'Pair device with pairing code'.\n" +
                            "You can tap '⌨️ ENTER 6 DIGITS / PORT' right away (enter 6 digits, or 'PORT PIN' e.g. 38475 123456)."
                    )
                )
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(contentPendingIntent)
            .addAction(quickInputAction)
            .addAction(
                com.example.R.drawable.ic_stat_magictune,
                tr(context, "Dừng", "Stop"),
                stopPendingIntent
            )
            .build()

        try {
            nm.notify(NOTIFICATION_ID, notification)
        } catch (_: Throwable) {}
    }

    fun showPinInputNotification(context: Context, pairingPort: Int) {
        if (!SHOW_PAIRING_NOTIFICATIONS) return
        lastShownPinPort = pairingPort
        ensureChannel(context)
        val nm = context.getSystemService(NotificationManager::class.java) ?: return

        val remoteInput = RemoteInput.Builder(KEY_PAIRING_CODE)
            .setLabel(tr(context, "Nhập 6 chữ số mã ghép đôi...", "Enter 6-digit pairing code..."))
            .setAllowFreeFormInput(true)
            .build()

        val submitIntent = Intent(context, AdbPairingReceiver::class.java).apply {
            action = ACTION_SUBMIT_PIN
            putExtra(EXTRA_PAIRING_PORT, pairingPort)
        }

        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }

        val replyPendingIntent = PendingIntent.getBroadcast(context, 10, submitIntent, flags)

        val replyAction = NotificationCompat.Action.Builder(
            com.example.R.drawable.ic_stat_magictune,
            tr(context, "🔑 NHẬP 6 SỐ", "🔑 ENTER 6 DIGITS"),
            replyPendingIntent
        )
            .addRemoteInput(remoteInput)
            .setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_REPLY)
            .setShowsUserInterface(false)
            .setAllowGeneratedReplies(false)
            .build()

        val stopIntent = Intent(context, AdbPairingReceiver::class.java).apply {
            action = ACTION_STOP_PAIRING
        }
        val stopPendingIntent = PendingIntent.getBroadcast(
            context,
            11,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(com.example.R.drawable.ic_stat_magictune)
            .setContentTitle(tr(context, "🟢 Đã bắt cổng $pairingPort • Bấm 'NHẬP 6 SỐ'", "🟢 Port $pairingPort detected • Tap 'ENTER 6 DIGITS'"))
            .setContentText(tr(context, "Chạm nút '🔑 NHẬP 6 SỐ' bên dưới rồi gõ 6 số mã ghép đôi!", "Tap '🔑 ENTER 6 DIGITS' below and type the 6-digit pairing code!"))
            .setStyle(
                NotificationCompat.BigTextStyle().bigText(
                    tr(
                        context,
                        "Đã tự động bắt cổng ghép nối: $pairingPort (_adb-tls-pairing._tcp).\n" +
                            "👉 Chạm nút '🔑 NHẬP 6 SỐ' bên dưới và gõ 6 chữ số mã ghép đôi!",
                        "Auto-detected pairing port: $pairingPort (_adb-tls-pairing._tcp).\n" +
                            "👉 Tap '🔑 ENTER 6 DIGITS' below and type the 6-digit pairing code!"
                    )
                )
            )
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setOnlyAlertOnce(false)
            .addAction(replyAction)
            .addAction(com.example.R.drawable.ic_stat_magictune, tr(context, "Hủy", "Cancel"), stopPendingIntent)
            .build()

        try {
            nm.notify(NOTIFICATION_ID, notification)
        } catch (_: Throwable) {}
    }

    fun showProgressNotification(context: Context, message: String) {
        if (!SHOW_PAIRING_NOTIFICATIONS) return
        lastShownPinPort = null
        ensureChannel(context)
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(com.example.R.drawable.ic_stat_magictune)
            .setContentTitle(tr(context, "⏳ Đang xử lý ghép nối ADB...", "⏳ Processing ADB pairing..."))
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setProgress(0, 0, true)
            .setOngoing(true)
            .build()
        try {
            nm.notify(NOTIFICATION_ID, notification)
        } catch (_: Throwable) {}
    }

    @Volatile
    private var lastSuccessNotifTimeMs: Long = 0L

    fun showPairingResultNotification(
        context: Context,
        success: Boolean,
        title: String,
        message: String,
        retryPort: Int? = null
    ) {
        if (!SHOW_PAIRING_NOTIFICATIONS) return
        val now = System.currentTimeMillis()
        if (success) {
            if (now - lastSuccessNotifTimeMs < 15000L) {
                return // Prevent notification spam and repeating beeps ("tút tút mãi")
            }
            lastSuccessNotifTimeMs = now
        }
        lastShownPinPort = null
        ensureChannel(context)
        val nm = context.getSystemService(NotificationManager::class.java) ?: return

        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            context,
            20,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(com.example.R.drawable.ic_stat_magictune)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setOngoing(false)
            .setOnlyAlertOnce(true)
            .setContentIntent(openPendingIntent)

        if (!success && retryPort != null && retryPort > 0) {
            val remoteInput = RemoteInput.Builder(KEY_PAIRING_CODE)
                .setLabel(tr(context, "Nhập lại 6 chữ số mã ghép đôi...", "Re-enter 6-digit pairing code..."))
                .build()
            val submitIntent = Intent(context, AdbPairingReceiver::class.java).apply {
                action = ACTION_SUBMIT_PIN
                putExtra(EXTRA_PAIRING_PORT, retryPort)
            }
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            } else {
                PendingIntent.FLAG_UPDATE_CURRENT
            }
            val replyPendingIntent = PendingIntent.getBroadcast(context, 21, submitIntent, flags)
            val replyAction = NotificationCompat.Action.Builder(
                com.example.R.drawable.ic_stat_magictune,
                tr(context, "🔄 NHẬP LẠI MÃ PIN", "🔄 RE-ENTER PIN"),
                replyPendingIntent
            ).addRemoteInput(remoteInput).build()
            builder.addAction(replyAction)
        }

        try {
            nm.notify(NOTIFICATION_ID, builder.build())
        } catch (_: Throwable) {}
    }
}

/**
 * BroadcastReceiver nhận mã PIN 6 số người dùng gõ từ thanh thông báo (RemoteInput)
 * và thực hiện ghép nối + tự động kết nối vào cổng chính _adb-tls-connect._tcp.
 */
class AdbPairingReceiver : BroadcastReceiver() {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    override fun onReceive(context: Context, intent: Intent) {
        val appCtx = context.applicationContext
        when (intent.action) {
            AdbPairingNotificationManager.ACTION_STOP_PAIRING -> {
                AdbPairingNotificationManager.stopInteractivePairingNotification(appCtx)
            }

            AdbPairingNotificationManager.ACTION_SUBMIT_PIN -> {
                val results = RemoteInput.getResultsFromIntent(intent)
                val rawPin = results?.getCharSequence(AdbPairingNotificationManager.KEY_PAIRING_CODE)?.toString().orEmpty()
                val parsed = AdbPairingInputParser.parse(rawPin)
                val cleanPin = parsed.pin.orEmpty()
                val scanner = AdbNsdScanner.getInstance(appCtx)
                val intentPort = intent.getIntExtra(AdbPairingNotificationManager.EXTRA_PAIRING_PORT, 0)
                val initialPort = parsed.port ?: scanner.getBestPairingPort(intentPort) ?: 0

                if (cleanPin.length < 6) {
                    AdbPairingNotificationManager.showPairingResultNotification(
                        context = appCtx,
                        success = false,
                        title = tr(appCtx, "⚠️ Mã PIN không hợp lệ", "⚠️ Invalid PIN"),
                        message = tr(appCtx, "Vui lòng nhập đủ 6 chữ số mã ghép đôi (hoặc 'CỔNG 6_SỐ').", "Please enter 6-digit pairing code (or 'PORT 6_DIGITS')."),
                        retryPort = if (initialPort > 0) initialPort else null
                    )
                    return
                }

                AdbPairingNotificationManager.showProgressNotification(
                    appCtx,
                    if (initialPort > 0) tr(appCtx, "Đang ghép nối với 127.0.0.1:$initialPort bằng mã PIN $cleanPin...", "Pairing with 127.0.0.1:$initialPort using PIN $cleanPin...")
                    else tr(appCtx, "Đang dò nhanh cổng ghép nối & xác thực PIN $cleanPin...", "Scanning pairing port & verifying PIN $cleanPin...")
                )

                val pendingResult = goAsync()
                scope.launch {
                    var resolvedPort = initialPort
                    try {
                        val result = kotlinx.coroutines.withTimeoutOrNull(15000L) {
                            if (resolvedPort !in 1..65535) {
                                resolvedPort = scanner.discoverPairingPortWithin(1500L) ?: 0
                            }
                            if (resolvedPort !in 1..65535) {
                                AdbPairingNotificationManager.showPairingResultNotification(
                                    context = appCtx,
                                    success = false,
                                    title = tr(appCtx, "⚠️ Chưa bắt được cổng ghép nối", "⚠️ Pairing port not detected"),
                                    message = tr(appCtx, "Hãy đảm bảo bảng 'Ghép nối thiết bị bằng mã ghép đôi' đang mở, hoặc gõ kèm cổng: 'CỔNG PIN' (VD: 38475 $cleanPin).", "Ensure 'Pair device with pairing code' is open, or enter 'PORT PIN' (e.g. 38475 $cleanPin).")
                                )
                                return@withTimeoutOrNull true
                            }

                            val engine = AdbPairingNotificationManager.activeShellEngine ?: ShellEngine.getInstance(appCtx)
                            val pairRes = engine.pairWirelessAdb(resolvedPort, cleanPin)
                            val pairOk = pairRes.isSuccess && pairRes.getOrDefault(false)

                            if (pairOk) {
                                val immediatePort = scanner.getBestConnectPort()
                                val immediateOk = if (immediatePort != null && immediatePort in 1..65535) {
                                    engine.connectWirelessAdb(immediatePort)
                                } else {
                                    false
                                }

                                if (immediateOk) {
                                    AdbPairingNotificationManager.finalizePairingSuccessUi(appCtx, scanner)
                                    AdbPairingNotificationManager.showPairingResultNotification(
                                        context = appCtx,
                                        success = true,
                                        title = tr(appCtx, "✅ Ghép nối & Kết nối ADB thành công!", "✅ ADB Paired & Connected!"),
                                        message = tr(appCtx, "Đã ghép nối cổng $resolvedPort và tự động kết nối cổng chính $immediatePort (UID 2000). Nhấn để mở MagicTune!", "Paired port $resolvedPort and connected main port $immediatePort (UID 2000). Tap to open MagicTune!")
                                    )
                                } else {
                                    AdbPairingNotificationManager.showProgressNotification(
                                        appCtx,
                                        tr(appCtx, "Ghép nối PIN thành công! Đang tự động tìm & kết nối cổng chính...", "PIN paired! Searching & connecting main port...")
                                    )
                                    AdbPairingNotificationManager.completePostPairConnectAsync(appCtx, resolvedPort, engine)
                                }
                            } else {
                                val errMsg = pairRes.exceptionOrNull()?.localizedMessage
                                    ?: tr(appCtx, "Mã PIN không đúng hoặc hộp thoại mã ghép đôi đã đóng.", "Incorrect PIN or pairing dialog closed.")
                                AdbPairingNotificationManager.showPairingResultNotification(
                                    context = appCtx,
                                    success = false,
                                    title = tr(appCtx, "❌ Ghép nối thất bại (Cổng $resolvedPort)", "❌ Pairing failed (Port $resolvedPort)"),
                                    message = tr(appCtx, "$errMsg\nHãy mở lại 'Ghép nối bằng mã ghép đôi' và thử lại.", "$errMsg\nReopen 'Pair with pairing code' and try again."),
                                    retryPort = resolvedPort
                                )
                            }
                            true
                        }
                        if (result == null) {
                            AdbPairingNotificationManager.showPairingResultNotification(
                                context = appCtx,
                                success = false,
                                title = tr(appCtx, "⏱️ Quá thời gian ghép nối", "⏱️ Pairing timed out"),
                                message = tr(appCtx, "Quá trình ghép nối cổng $resolvedPort mất quá nhiều thời gian. Vui lòng thử lại.", "Pairing port $resolvedPort took too long. Please try again."),
                                retryPort = if (resolvedPort > 0) resolvedPort else null
                            )
                        }
                    } catch (t: Throwable) {
                        AdbPairingNotificationManager.showPairingResultNotification(
                            context = appCtx,
                            success = false,
                            title = tr(appCtx, "❌ Lỗi ghép nối", "❌ Pairing error"),
                            message = "${t.localizedMessage ?: t.message}",
                            retryPort = if (resolvedPort > 0) resolvedPort else null
                        )
                    } finally {
                        try { pendingResult.finish() } catch (_: Throwable) {}
                    }
                }
            }
        }
    }
}
