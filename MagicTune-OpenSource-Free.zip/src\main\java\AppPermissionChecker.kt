package com.example.core.permission

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.launch

@androidx.compose.runtime.Immutable
data class AppSelfPermissionStatus(
    val hasNotificationPermission: Boolean,
    val hasOverlayPermission: Boolean,
    val hasUsageStatsPermission: Boolean,
    val hasMediaProjectionPermission: Boolean = false,
    val hasAssistantPermission: Boolean = false,
    val hasWriteSecureSettings: Boolean,
    val isShizukuGranted: Boolean,
    val isFirstTimeWlanActivated: Boolean = false
) {
    val isCorePermissionsGranted: Boolean
        get() = hasNotificationPermission &&
                hasOverlayPermission &&
                hasUsageStatsPermission

    val isFullyGranted: Boolean
        get() = isCorePermissionsGranted

    val missingCount: Int
        get() {
            var count = 0
            if (!hasNotificationPermission) count++
            if (!hasOverlayPermission) count++
            if (!hasUsageStatsPermission) count++
            return count
        }
}

object AppPermissionChecker {

    fun checkSelfPermissions(context: Context, isShizukuReady: Boolean = false): AppSelfPermissionStatus {
        val pkg = context.packageName

        // 1. Quyền Thông Báo (POST_NOTIFICATIONS / NotificationManagerCompat)
        val hasNotif = try {
            val nm = NotificationManagerCompat.from(context)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED && nm.areNotificationsEnabled()
            } else {
                nm.areNotificationsEnabled()
            }
        } catch (_: Exception) { true }

        // 3. Quyền Hiển thị trên ứng dụng khác (SYSTEM_ALERT_WINDOW / Overlay)
        val hasOverlay = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Settings.canDrawOverlays(context)
            } else true
        } catch (_: Exception) { true }

        // 4. Quyền Truy cập lịch sử sử dụng để đọc App gần đây (PACKAGE_USAGE_STATS)
        val hasUsage = try {
            val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                appOps?.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), pkg)
            } else {
                @Suppress("DEPRECATION")
                appOps?.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), pkg)
            }
            if (mode == AppOpsManager.MODE_ALLOWED) {
                true
            } else {
                val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as? android.app.usage.UsageStatsManager
                val now = System.currentTimeMillis()
                val stats = usm?.queryUsageStats(android.app.usage.UsageStatsManager.INTERVAL_DAILY, now - 60_000L, now)
                !stats.isNullOrEmpty()
            }
        } catch (_: Exception) { false }

        // 7. Quyền WRITE_SECURE_SETTINGS (Cấp qua ADB/Shizuku)
        val hasSecure = try {
            context.checkCallingOrSelfPermission(android.Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED
        } catch (_: Exception) { false }

        // 5. Quyền Chiếu Màn Hình & Đọc Màn Hình Ngầm (Hoàn toàn không dùng trợ năng hệ thống)
        val hasMediaProj = hasMediaProjectionPermission(context)

        // 6. Quyền Trợ Lý Kỹ Thuật Số (Digital Assistant Role - Thay thế hoàn toàn YOYO trên Honor MagicOS)
        val hasAssistant = isAssistantPermissionGranted(context)

        // 8. Trạng thái kết nối Gỡ lỗi Wi-Fi (WLAN ADB) thành công lần đầu sau khi tải app
        val isWlanActivated = isFirstTimeWlanActivated(context)

        return AppSelfPermissionStatus(
            hasNotificationPermission = hasNotif,
            hasOverlayPermission = hasOverlay,
            hasUsageStatsPermission = hasUsage,
            hasMediaProjectionPermission = hasMediaProj,
            hasAssistantPermission = hasAssistant,
            hasWriteSecureSettings = hasSecure,
            isShizukuGranted = isShizukuReady,
            isFirstTimeWlanActivated = isWlanActivated
        )
    }

    private const val PREFS_NAME = "wlan_activation_prefs"
    private const val KEY_WLAN_FIRST_ACTIVATED = "wlan_first_activated_v1"
    private const val SETTINGS_SECURE_KEY = "magictune_wlan_activated_forever"
    private const val SETTINGS_GLOBAL_DEVICE_UNLOCKED = "magictune_device_adb_permanently_unlocked"
    private const val MARKER_FILE_NAME = "wlan_first_activated.marker"

    @Volatile
    private var isMemoryCachedActivated: Boolean = false

    fun markWlanActivated(context: Context) {
        val firstActivation = !isFirstTimeWlanActivated(context)
        isMemoryCachedActivated = true
        if (firstActivation) {
            com.example.core.service.MagicTuneKeepAliveService.startOrUpdate(context)
        }
        val appCtx = context.applicationContext ?: context

        // Ghi nền bất đồng bộ để tránh triệt để giật khựng / ANR trên Main Thread
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            // 1. Phân vùng Device-Protected Storage (sẵn sàng ngay trong Direct Boot trước khi nhập mật khẩu máy)
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    val deCtx = appCtx.createDeviceProtectedStorageContext()
                    deCtx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                        .edit().putBoolean(KEY_WLAN_FIRST_ACTIVATED, true).apply()
                    java.io.File(deCtx.filesDir, MARKER_FILE_NAME).createNewFile()
                }
            } catch (_: Throwable) {}

            // 2. Phân vùng Credential-Encrypted Storage (SharedPreferences chuẩn)
            try {
                appCtx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    .edit().putBoolean(KEY_WLAN_FIRST_ACTIVATED, true).apply()
                java.io.File(appCtx.filesDir, MARKER_FILE_NAME).createNewFile()
            } catch (_: Throwable) {}

            // 3. SharedPreferences nội bộ của ShellEngine
            try {
                appCtx.getSharedPreferences("magictune_shell_prefs", Context.MODE_PRIVATE)
                    .edit().putBoolean("persistent_grant_active", true).apply()
                appCtx.getSharedPreferences("magictune_persisted_kv", Context.MODE_PRIVATE)
                    .edit().putBoolean("auto_granted_self_perms_v373", true).apply()
            } catch (_: Throwable) {}

            // 4. Lưu trực tiếp vào Cài đặt Hệ thống Android (Settings.Secure & Settings.Global)
            // Dữ liệu này được lưu vĩnh viễn trên OS, KHÔNG BỊ XÓA khi gỡ app rồi cài lại lần 2, lần 3!
            try {
                val cr = appCtx.contentResolver
                Settings.Secure.putString(cr, SETTINGS_SECURE_KEY, "1")
                Settings.Global.putString(cr, SETTINGS_SECURE_KEY, "1")
                Settings.Secure.putString(cr, SETTINGS_GLOBAL_DEVICE_UNLOCKED, "1")
                Settings.Global.putString(cr, SETTINGS_GLOBAL_DEVICE_UNLOCKED, "1")
            } catch (_: Throwable) {}

            // 5. Cập nhật diện mạo 2 phím điều hướng HUD thành kính lỏng tức thì & đồng bộ hiển thị lên màn hình
            try {
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                    com.example.core.service.SystemFloatingHudOverlay.refreshNavPillColors(appCtx)
                    com.example.core.service.SystemFloatingHudOverlay.syncNavBarBridge(appCtx)
                }
            } catch (_: Throwable) {}
        }
    }

    fun isFirstTimeWlanActivated(context: Context): Boolean {
        if (isMemoryCachedActivated) return true
        val appCtx = context.applicationContext ?: context

        // 1. Kiểm tra Device-Protected Storage (sống sót tuyệt đối qua khởi động lại máy / Direct Boot)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                val deCtx = appCtx.createDeviceProtectedStorageContext()
                val dePrefs = deCtx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                if (dePrefs.getBoolean(KEY_WLAN_FIRST_ACTIVATED, false) ||
                    java.io.File(deCtx.filesDir, MARKER_FILE_NAME).exists()) {
                    isMemoryCachedActivated = true
                    return true
                }
            }
        } catch (_: Throwable) {}

        // 2. Kiểm tra SharedPreferences tiêu chuẩn & File Marker
        try {
            val prefs = appCtx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            if (prefs.getBoolean(KEY_WLAN_FIRST_ACTIVATED, false) ||
                java.io.File(appCtx.filesDir, MARKER_FILE_NAME).exists()) {
            isMemoryCachedActivated = true
            return true
            }
        } catch (_: Throwable) {}

        // 3. BẰNG CHỨNG HỆ THỐNG VĨNH VIỄN (Settings.Secure & Settings.Global)
        // V4.0: Sống sót vĩnh viễn trên thiết bị kể cả khi gỡ app và cài lại nhiều lần!
        try {
            val cr = appCtx.contentResolver
            val secFlag = Settings.Secure.getString(cr, SETTINGS_SECURE_KEY)
            val globFlag = Settings.Global.getString(cr, SETTINGS_SECURE_KEY)
            val secDev = Settings.Secure.getString(cr, SETTINGS_GLOBAL_DEVICE_UNLOCKED)
            val globDev = Settings.Global.getString(cr, SETTINGS_GLOBAL_DEVICE_UNLOCKED)
            if (secFlag == "1" || globFlag == "1" || secDev == "1" || globDev == "1") {
                markWlanActivated(appCtx)
                return true
            }
        } catch (_: Throwable) {}

        // 4. BẰNG CHỨNG LỆNH ADB ĐÃ KHÓA TRỢ NĂNG (Accessibility Service trong Settings.Secure)
        try {
            val cr = appCtx.contentResolver
            val enabledA11y = Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
            if (enabledA11y.contains(appCtx.packageName) ||
                com.example.core.service.MagicTuneCtsAccessibilityService.isServiceConnected() ||
                com.example.core.service.MagicTuneCtsAccessibilityService.isServiceEnabledInSettings(appCtx)) {
                markWlanActivated(appCtx)
                return true
            }
        } catch (_: Throwable) {}

        // 5. BẰNG CHỨNG LỆNH ADB ĐÃ GÁN TRỢ LÝ KỸ THUẬT SỐ (Assistant trong Settings.Secure)
        try {
            val cr = appCtx.contentResolver
            val assist = Settings.Secure.getString(cr, "assistant") ?: ""
            val voice = Settings.Secure.getString(cr, "voice_interaction_service") ?: ""
            if (assist.contains(appCtx.packageName) || voice.contains(appCtx.packageName) || isAssistantPermissionGranted(appCtx)) {
                markWlanActivated(appCtx)
                return true
            }
        } catch (_: Throwable) {}

        // 6. BẰNG CHỨNG CÁC QUYỀN HỆ THỐNG ĐẶC QUYỀN (WRITE_SECURE_SETTINGS / DUMP / READ_LOGS)
        try {
            val hasSecure = appCtx.checkCallingOrSelfPermission(android.Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED
            val hasDump = appCtx.checkCallingOrSelfPermission(android.Manifest.permission.DUMP) == PackageManager.PERMISSION_GRANTED
            val hasReadLogs = appCtx.checkCallingOrSelfPermission(android.Manifest.permission.READ_LOGS) == PackageManager.PERMISSION_GRANTED
            if (hasSecure || hasDump || hasReadLogs) {
                markWlanActivated(appCtx)
                return true
            }
        } catch (_: Throwable) {}

        // 7. BẰNG CHỨNG SHELLENGINE ĐÃ TỪNG KẾT NỐI HOẶC GHÉP ĐÔI (Pairing port hoặc SharedPreferences nội bộ)
        try {
            val shell = com.example.core.shell.ShellEngine.getInstance(appCtx)
            if (shell.hasPairedBefore() || shell.state.value.isAdbReady) {
                markWlanActivated(appCtx)
                return true
            }
            val shellPrefs = appCtx.getSharedPreferences("magictune_shell_prefs", Context.MODE_PRIVATE)
            if (shellPrefs.getBoolean("persistent_grant_active", false) || shellPrefs.getInt("wlan_pair_port", -1) > 0) {
                markWlanActivated(appCtx)
                return true
            }
            val kvPrefs = appCtx.getSharedPreferences("magictune_persisted_kv", Context.MODE_PRIVATE)
            if (kvPrefs.getBoolean("auto_granted_self_perms_v373", false)) {
                markWlanActivated(appCtx)
                return true
            }
        } catch (_: Throwable) {}

        return false
    }

    /**
     * Trạng thái thực tế của ô "Trợ Năng Ngầm & Đọc Màn Hình" trong dialog Kiểm Tra Quyền Hệ Thống.
     * Đây là nguồn chân lý duy nhất để quyết định 2 nút điều hướng HUD có được phép hoạt động hay không.
     * Chỉ trả về true khi: dịch vụ trợ năng đã kết nối / đã bật trong Settings,
     * hoặc đã có WRITE_SECURE_SETTINGS / kết nối WLAN ADB (đủ khả năng tự cấp ngầm).
     */
    fun canUseCircle(context: Context): Boolean =
        isFirstTimeWlanActivated(context) &&
            hasMediaProjectionPermission(context) &&
            (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(context))

    fun isSilentAccessibilityGranted(context: Context? = null): Boolean =
        hasMediaProjectionPermission(context)

    fun hasMediaProjectionPermission(context: Context? = null): Boolean {
        if (com.example.core.projection.MediaProjectionHolder.hasProjectionPermission()) {
            return true
        }
        if (context != null) {
            val appCtx = context.applicationContext ?: context
            val hasSecure = try {
                appCtx.checkCallingOrSelfPermission(android.Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED
            } catch (_: Throwable) { false }
            val isAdb = com.example.core.shell.ShellEngine.getInstance(appCtx).state.value.isAdbReady
            return hasSecure || isAdb
        }
        return false
    }

    fun isAssistantPermissionGranted(context: Context): Boolean {
        if (com.example.core.assistant.MagicTuneVoiceInteractionService.instance != null) {
            return true
        }
        val pkg = context.packageName
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                val roleManager = context.getSystemService(Context.ROLE_SERVICE) as? android.app.role.RoleManager
                if (roleManager?.isRoleAvailable(android.app.role.RoleManager.ROLE_ASSISTANT) == true) {
                    if (roleManager.isRoleHeld(android.app.role.RoleManager.ROLE_ASSISTANT)) {
                        return true
                    }
                }
            } catch (_: Throwable) {}
        }
        return try {
            val cr = context.contentResolver
            val assist = Settings.Secure.getString(cr, "assistant") ?: ""
            val voice = Settings.Secure.getString(cr, "voice_interaction_service") ?: ""
            if (assist.contains(pkg) || voice.contains(pkg)) {
                return true
            }
            val shellPersistedAssist = try {
                com.example.core.shell.ShellEngine.getInstance(context).getPersistedSetting("secure", "assistant") ?: ""
            } catch (_: Throwable) { "" }
            val shellPersistedVoice = try {
                com.example.core.shell.ShellEngine.getInstance(context).getPersistedSetting("secure", "voice_interaction_service") ?: ""
            } catch (_: Throwable) { "" }
            shellPersistedAssist.contains(pkg) || shellPersistedVoice.contains(pkg)
        } catch (_: Throwable) {
            false
        }
    }

    fun requestAssistantPermission(context: Context) {
        val appCtx = context.applicationContext ?: context

        // 1. Nếu đã kết nối WLAN ADB / Shizuku, tự động gán luôn không cần mở Cài đặt
        val shell = com.example.core.shell.ShellEngine.getInstance(appCtx)
        if (shell.state.value.isAdbReady) {
            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                val pkg = appCtx.packageName
                val comp = "$pkg/com.example.core.assistant.MagicTuneVoiceInteractionService"
                val recog = "$pkg/com.example.core.assistant.MagicTuneRecognitionService"
                shell.execute(
                    "pm enable --user 0 $comp >/dev/null 2>&1 || pm enable $comp >/dev/null 2>&1 || true; " +
                    "pm enable --user 0 $recog >/dev/null 2>&1 || pm enable $recog >/dev/null 2>&1 || true; " +
                    "cmd role add-role-holder --user 0 android.app.role.ASSISTANT $pkg >/dev/null 2>&1 || cmd role add-role-holder android.app.role.ASSISTANT $pkg >/dev/null 2>&1 || true; " +
                    "settings put secure assistant '$comp'; " +
                    "settings put secure voice_interaction_service '$comp'; " +
                    "settings put secure voice_recognition_service '$recog'; " +
                    "settings put secure assist_structure_enabled 1; " +
                    "settings put secure assist_screenshot_enabled 1; " +
                    "settings put secure assist_disclosure_enabled 1; " +
                    "settings put secure assist_long_press_home_enabled 1; " +
                    "settings put secure search_press_hold_nav_handle_enabled 1"
                )
                kotlinx.coroutines.delay(250)
                markWlanActivated(appCtx)
                try {
                    com.example.core.service.SystemFloatingHudOverlay.syncNavBarBridge(appCtx)
                } catch (_: Throwable) {}
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                    android.widget.Toast.makeText(appCtx, com.example.core.i18n.AppLanguageManager.tr(appCtx, "✅ Đã tự động kích hoạt Trợ lý kỹ thuật số thành công!", "✅ Digital Assistant automatically enabled!"), android.widget.Toast.LENGTH_SHORT).show()
                }
            }
            return
        }

        // 2. Thử các Intent cài đặt Trợ lý mặc định tối ưu riêng cho MagicOS Honor / Huawei / Android 10-15
        val intentsToTry = listOf(
            Intent(Settings.ACTION_VOICE_INPUT_SETTINGS),
            Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS),
            Intent("android.settings.MANAGE_DEFAULT_APPS_SETTINGS"),
            Intent().setComponent(android.content.ComponentName("com.android.settings", "com.android.settings.Settings\$ManageDefaultAppsActivity")),
            Intent().setComponent(android.content.ComponentName("com.android.settings", "com.android.settings.applications.DefaultAppSettings")),
            Intent().setComponent(android.content.ComponentName("com.android.settings", "com.huawei.settingslib.applications.DefaultAppManagerActivity")),
            Intent().setComponent(android.content.ComponentName("com.android.settings", "com.android.settings.SubSettings")).putExtra(":settings:show_fragment", "com.android.settings.applications.assist.ManageAssist"),
            Intent().setComponent(android.content.ComponentName("com.android.settings", "com.android.settings.Settings\$ManageAssistActivity")),
            Intent("android.settings.VOICE_INPUT_SETTINGS"),
            Intent(Settings.ACTION_APPLICATION_SETTINGS),
            Intent(Settings.ACTION_SETTINGS)
        )

        for (intent in intentsToTry) {
            try {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                showToastSafe(appCtx, com.example.core.i18n.AppLanguageManager.tr(appCtx, "👉 Chọn 'Ứng dụng hỗ trợ' ➔ Chọn 'MagicTune' (và bật 'Sử dụng văn bản & ảnh chụp màn hình')", "👉 Select 'Assist app' ➔ Choose 'MagicTune' (and enable 'Use text & screenshots')"), android.widget.Toast.LENGTH_LONG)
                return
            } catch (_: Throwable) {}
        }

        // 3. Dự phòng qua RoleManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                val roleManager = appCtx.getSystemService(Context.ROLE_SERVICE) as? android.app.role.RoleManager
                if (roleManager?.isRoleAvailable(android.app.role.RoleManager.ROLE_ASSISTANT) == true) {
                    val intent = roleManager.createRequestRoleIntent(android.app.role.RoleManager.ROLE_ASSISTANT).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                    return
                }
            } catch (_: Throwable) {}
        }

        // 4. Mở trang thông tin ứng dụng
        openAppDetailsSettings(context)
    }

    fun openAccessibilitySettings(context: Context) {
        val appCtx = context.applicationContext ?: context
        try {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            appCtx.startActivity(intent)
        } catch (_: Throwable) {
            try {
                val intent = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                appCtx.startActivity(intent)
            } catch (_: Throwable) {
                openAppDetailsSettings(appCtx)
            }
        }
    }

    fun requestMediaProjectionPermission(context: Context, onResult: ((Boolean) -> Unit)? = null) {
        val appCtx = context.applicationContext ?: context
        // 1. Tự động cấp quyền ngầm nếu đã có WRITE_SECURE_SETTINGS / WLAN ADB
        com.example.core.service.MagicTuneCtsAccessibilityService.autoGrantAndEnableSilently(appCtx)
        if (hasMediaProjectionPermission(appCtx)) {
            showToastSafe(appCtx, com.example.core.i18n.AppLanguageManager.tr(appCtx, "✅ Đã kích hoạt Trợ Năng & Đọc Màn Hình!", "✅ Accessibility & Screen Reading enabled!"), android.widget.Toast.LENGTH_SHORT)
            onResult?.invoke(true)
            return
        }

        // 2. Dự phòng qua MediaProjection khi chưa có quyền đặc quyền ADB / WRITE_SECURE_SETTINGS
        com.example.core.projection.MediaProjectionPermissionActivity.requestPermission(context, onResult)
    }

    // Các hàm mở trang cấp quyền tương ứng cho từng mục:
    fun requestNotificationPermission(context: Context) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                    putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            } else {
                openAppDetailsSettings(context)
            }
        } catch (_: Exception) {
            openAppDetailsSettings(context)
        }
    }

    fun requestOverlayPermission(context: Context) {
        val appCtx = context.applicationContext ?: context
        val pkg = appCtx.packageName
        try {
            val shell = com.example.core.shell.ShellEngine.getInstance(appCtx)
            if (shell.state.value.isAdbReady) {
                kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                    try {
                        shell.execute(
                            "cmd appops set $pkg ACCESS_RESTRICTED_SETTINGS allow >/dev/null 2>&1 || cmd appops set --user 0 $pkg ACCESS_RESTRICTED_SETTINGS allow >/dev/null 2>&1 || true; " +
                            "pm grant --user 0 $pkg android.permission.SYSTEM_ALERT_WINDOW >/dev/null 2>&1 || pm grant $pkg android.permission.SYSTEM_ALERT_WINDOW >/dev/null 2>&1 || true; " +
                            "cmd appops set $pkg SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1 || cmd appops set --user 0 $pkg SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1 || appops set $pkg SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1 || true; " +
                            "cmd appops set $pkg 24 allow >/dev/null 2>&1 || cmd appops set --user 0 $pkg 24 allow >/dev/null 2>&1 || true"
                        )
                        com.example.core.service.SystemFloatingHudOverlay.syncNavBarBridge(appCtx)
                    } catch (_: Throwable) {}
                }
                showToastSafe(
                    appCtx,
                    com.example.core.i18n.AppLanguageManager.tr(appCtx, "✅ Đã tự động mở khóa quyền Hiển thị trên ứng dụng khác cho Honor MagicOS!", "✅ Display over other apps unlocked for Honor MagicOS!"),
                    android.widget.Toast.LENGTH_SHORT
                )
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(appCtx)) {
                    return
                }
            }
        } catch (_: Throwable) {}

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$pkg")
                ).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return
            }
        } catch (_: Exception) {}

        val honorOverlayIntents = listOf(
            Intent().setClassName("com.hihonor.systemmanager", "com.huawei.systemmanager.addviewmonitor.AddViewMonitorActivity"),
            Intent().setClassName("com.hihonor.systemmanager", "com.hihonor.systemmanager.addviewmonitor.AddViewMonitorActivity"),
            Intent().setClassName("com.huawei.systemmanager", "com.huawei.systemmanager.addviewmonitor.AddViewMonitorActivity"),
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
        )
        for (fallback in honorOverlayIntents) {
            try {
                fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(fallback)
                return
            } catch (_: Exception) {}
        }
        openAppDetailsSettings(context)
    }

    fun requestUsageStatsPermission(context: Context) {
        val appCtx = context.applicationContext ?: context
        val pkg = appCtx.packageName

        // 1. Tự động cấp ngay lập tức qua WLAN ADB / Shizuku nếu đang kết nối
        val shell = com.example.core.shell.ShellEngine.getInstance(appCtx)
        if (shell.state.value.isAdbReady) {
            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                try {
                    shell.execute(
                        "cmd appops set $pkg GET_USAGE_STATS allow >/dev/null 2>&1 || cmd appops set --user 0 $pkg GET_USAGE_STATS allow >/dev/null 2>&1 || appops set $pkg GET_USAGE_STATS allow >/dev/null 2>&1 || true; " +
                        "pm grant --user 0 $pkg android.permission.PACKAGE_USAGE_STATS >/dev/null 2>&1 || pm grant -u 0 $pkg android.permission.PACKAGE_USAGE_STATS >/dev/null 2>&1 || pm grant $pkg android.permission.PACKAGE_USAGE_STATS >/dev/null 2>&1 || true"
                    )
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                        android.widget.Toast.makeText(appCtx, com.example.core.i18n.AppLanguageManager.tr(appCtx, "✅ Đã tự động cấp Quyền Truy Cập Dữ Liệu Sử Dụng qua ADB!", "✅ Usage Access granted automatically via ADB!"), android.widget.Toast.LENGTH_SHORT).show()
                    }
                } catch (_: Throwable) {}
            }
            return
        }

        // 2. Mở trực tiếp trang cài đặt của MagicTune
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val directIntent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
                    data = Uri.parse("package:$pkg")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(directIntent)
                return
            }
        } catch (_: Exception) {}

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            }
        } catch (_: Exception) {
            openAppDetailsSettings(context)
        }
    }

    fun openAppDetailsSettings(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:${context.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {}
    }

    /**
     * Mở trực tiếp trang 'Quản lý khởi chạy ứng dụng' (App Launch / Auto-start) trên MagicOS Honor.
     * Cho phép người dùng chuyển từ Tự động quản lý sang Quản lý thủ công (Bật Tự khởi chạy, Khởi chạy thứ cấp, Chạy ngầm).
     */
    fun openHonorAppLaunchSettings(context: Context) {
        val intents = listOf(
            Intent().setClassName("com.hihonor.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
            Intent().setClassName("com.hihonor.systemmanager", "com.hihonor.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
            Intent().setClassName("com.hihonor.systemmanager", "com.hihonor.systemmanager.optimize.bootstart.BootStartActivity"),
            Intent().setClassName("com.hihonor.systemmanager", "com.huawei.systemmanager.appcontrol.activity.StartupAppControlActivity"),
            Intent().setClassName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
            Intent().setClassName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.bootstart.BootStartActivity")
        )

        for (intent in intents) {
            try {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                return
            } catch (_: Exception) {}
        }

        openAppDetailsSettings(context)
    }

    /**
     * Cố gắng mở trang gỡ bỏ 'Cài đặt bị hạn chế' (Restricted Settings) cho MagicTune trên Android 13+.
     * Trên MagicOS, nếu mục bị ẩn, người dùng cần vào Cài đặt ứng dụng -> Dấu 3 chấm -> Cho phép cài đặt bị hạn chế.
     */
    fun openRestrictedSettingsGuide(context: Context) {
        // Không có Intent trực tiếp để gỡ hạn chế, nhưng mở trang Chi tiết ứng dụng là bước đầu tiên
        openAppDetailsSettings(context)
    }

    /**
     * Mở trang 'Quyền đặc biệt' (Special App Access) nơi chứa Usage Stats và Write Settings.
     */
    fun openSpecialAppAccess(context: Context) {
        try {
            val intent = Intent("android.settings.SPECIAL_APP_ACCESS").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            openAppDetailsSettings(context)
        }
    }

    private fun showToastSafe(context: Context, message: String, duration: Int) {
        val appCtx = context.applicationContext ?: context
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
            try { android.widget.Toast.makeText(appCtx, message, duration).show() } catch (_: Throwable) {}
        } else {
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                try { android.widget.Toast.makeText(appCtx, message, duration).show() } catch (_: Throwable) {}
            }
        }
    }
}
