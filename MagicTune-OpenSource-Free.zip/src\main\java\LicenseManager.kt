package com.example.core.license

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.compose.runtime.Immutable
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap

/**
 * LicenseManager phiên bản Mã Nguồn Mở & Miễn Phí 100% (Không Firebase, Không Đăng Nhập, Không Pro/Thu Phí).
 * Chỉ giữ lại:
 * - Tùy chỉnh giao diện Header (Tên app, phiên bản, cỡ chữ, tỉ lệ UI 80-100%, link & nút MXH, link cập nhật APK).
 * - Quản lý Kho API Key AI cá nhân (Gemini / Groq) và giới hạn nhịp gọi an toàn trong Free-Tier.
 * - Mã định danh thiết bị cục bộ và các cờ thiết lập nội bộ.
 */
object LicenseManager {

    const val PREF_NAME = "magictune_pro_prefs"
    const val ACTION_PRO_ACTIVATED = "com.example.ACTION_PRO_ACTIVATED"
    const val ACTION_CONFIG_UPDATED = "com.example.ACTION_CONFIG_UPDATED"

    private const val KEY_CUSTOM_APP_NAME = "custom_app_name"
    private const val KEY_CUSTOM_APP_VERSION = "custom_app_version"
    private const val KEY_CUSTOM_APP_FONT_SIZE = "custom_app_font_size_sp"
    private const val KEY_SHOW_FB_HEADER_ICON = "show_fb_header_icon"
    private const val KEY_SHOW_YT_HEADER_ICON = "show_yt_header_icon"
    const val KEY_APP_UI_SCALE = "app_ui_scale_ratio"
    const val KEY_APP_UI_SCALE_UPDATED_AT = "app_ui_scale_updated_at"

    private const val KEY_GROQ_API_KEY_POOL = "groq_api_key_pool"
    private const val KEY_GEMINI_API_KEY_POOL = "magic_live_api_key_pool"
    private const val KEY_INVALID_DEAD_AI_KEYS = "invalid_dead_ai_keys_v1"
    private const val KEY_USER_CUSTOM_GEMINI_KEY = "user_custom_magic_live_key"
    private const val KEY_USER_CUSTOM_GEMINI_ONLY = "user_custom_gemini_only_key"
    private const val KEY_USER_CUSTOM_GROQ_ONLY = "user_custom_groq_only_key"
    private const val KEY_DISMISSED_BROADCAST_ID = "dismissed_broadcast_id"
    private const val KEY_DISMISSED_RELEASE_ID = "dismissed_apk_release_id"

    private const val DEFAULT_GITHUB_REPO = "https://github.com/Vuong05062000/MagicTune-OpenSource"
    private const val DEFAULT_FB_LINK = "https://www.facebook.com"
    private const val DEFAULT_YT_LINK = "https://www.youtube.com"

    @Immutable
    data class LatestApkRelease(
        val versionCode: Long = 0L,
        val versionName: String = "",
        val downloadUrl: String = "",
        val sizeBytes: Long = 0L,
        val releaseNotes: String = "",
        val hostLabel: String = "",
        val uploadedAtMs: Long = 0L,
        val autoUpdateEnabled: Boolean = true
    ) {
        val releaseId: String
            get() = "${versionCode}_${uploadedAtMs}"
    }

    @Immutable
    data class GlobalBroadcastMessage(
        val id: String = "",
        val title: String = "",
        val message: String = "",
        val type: String = "UPDATE",
        val isActive: Boolean = false,
        val actionUrl: String = "",
        val sentAtMs: Long = 0L
    )

    data class LiveKeyValidationReport(
        val validGeminiKeys: List<String>,
        val validGroqKeys: List<String>,
        val invalidReasons: List<String>,
        val savedAnyValidKey: Boolean
    )

    data class AiKeyPoolStatusSummary(
        val totalGroqKeys: Int,
        val activeGroqKeys: Int,
        val cooldownGroqKeys: Int,
        val totalGeminiKeys: Int,
        val activeGeminiKeys: Int,
        val cooldownGeminiKeys: Int,
        val hasPersonalGemini: Boolean,
        val hasPersonalGroq: Boolean,
        val totalCallsTodayInFreeTier: Int
    )

    private val _isProFlow = MutableStateFlow(true)
    val isProFlow: StateFlow<Boolean> = _isProFlow

    private val _latestApkReleaseFlow = MutableStateFlow<LatestApkRelease?>(null)
    val latestApkReleaseFlow: StateFlow<LatestApkRelease?> = _latestApkReleaseFlow

    private val _globalBroadcastFlow = MutableStateFlow<GlobalBroadcastMessage?>(null)
    val globalBroadcastFlow: StateFlow<GlobalBroadcastMessage?> = _globalBroadcastFlow

    private val _proStateVersionFlow = MutableStateFlow(0L)
    val proStateVersionFlow: StateFlow<Long> = _proStateVersionFlow

    private val _appUiScaleFlow = MutableStateFlow(0.85f)
    val appUiScaleFlow: StateFlow<Float> = _appUiScaleFlow

    @Volatile
    private var lastNotifyBroadcastMs: Long = 0L

    fun initProFlowFromCache(context: Context) {
        _isProFlow.value = true
        getAppUiScale(context)
    }

    fun isProActivated(context: Context): Boolean = true

    fun isAccountProActivated(context: Context): Boolean = true

    fun isAppFreeMode(context: Context): Boolean = true

    fun isAdminSimulateFreeMode(context: Context): Boolean = false

    fun isCurrentUserAdmin(context: Context?): Boolean = false

    fun canUseProFeatures(context: Context): Boolean = true

    fun canAccessMagicLive(context: Context): Boolean = true

    fun checkAndConsumeProOrTrial(context: Context, actionName: String): Pair<Boolean, String> =
        true to "Miễn phí 100%: $actionName"

    fun checkDeviceRecognizedProInCloud(context: Context, forceRefresh: Boolean = false): Boolean = true

    fun checkOnlinePaymentStatusRemote(context: Context): Boolean = true

    fun showRecognizedProToastOnce(context: Context, label: String = "") {}

    fun grantAppReloadBonusTrial(context: Context) {}

    fun persistHardwareProSignatureIfNeeded(context: Context) {}

    fun listenToGlobalConfigChanges(context: Context) {}

    fun detachRealtimeListenersOnBackground(context: Context) {}

    fun fetchGlobalConfigNow(
        context: Context,
        onLoaded: (() -> Unit)? = null,
        onResult: ((Boolean) -> Unit)? = null
    ) {
        onLoaded?.invoke()
        onResult?.invoke(true)
    }

    fun isConnectionRelatedAdbError(
        command: String,
        errorOutput: String,
        featureSource: String = ""
    ): Boolean = true

    fun saveAdminAdbErrorLog(
        context: Context,
        command: String,
        exitCode: Int = 0,
        errorOutput: String,
        connectionMode: String = "",
        featureSource: String = ""
    ) {
        // Không gửi log lỗi ADB lên cloud trong bản hoàn toàn ngoại tuyến / miễn phí.
    }

    fun notifyProAndConfigStateChanged(context: Context) {
        val now = System.currentTimeMillis()
        _isProFlow.value = true
        if (now - lastNotifyBroadcastMs < 60L) return
        lastNotifyBroadcastMs = now
        _proStateVersionFlow.value = now
        try {
            val pkg = context.packageName
            context.sendBroadcast(Intent(ACTION_PRO_ACTIVATED).setPackage(pkg))
            context.sendBroadcast(Intent(ACTION_CONFIG_UPDATED).setPackage(pkg))
        } catch (_: Exception) {}
    }

    fun getDeviceId(context: Context): String {
        return try {
            val id = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
                ?.trim()?.uppercase().orEmpty()
            if (id.isNotBlank()) id else "MT-${Build.MODEL.uppercase().replace(" ", "_")}"
        } catch (_: Throwable) {
            "MT-LOCAL"
        }
    }

    // =========================================================================
    // TÙY CHỈNH GIAO DIỆN HEADER & TỈ LỆ HIỂN THỊ (CHO TẤT CẢ NGƯỜI DÙNG)
    // =========================================================================

    private fun getApkBrandingScopeSuffix(): String {
        val vc = try { com.example.BuildConfig.VERSION_CODE } catch (_: Throwable) { 1 }
        val vn = try { com.example.BuildConfig.VERSION_NAME } catch (_: Throwable) { com.example.data.APP_VERSION_NAME }
            .replace(Regex("[^a-zA-Z0-9]"), "_")
        return "v${vc}_${vn}"
    }

    private fun scopedAppNameKey(): String = "${KEY_CUSTOM_APP_NAME}_${getApkBrandingScopeSuffix()}"
    private fun scopedAppVersionKey(): String = "${KEY_CUSTOM_APP_VERSION}_${getApkBrandingScopeSuffix()}"
    private fun scopedAppFontSizeKey(): String = "${KEY_CUSTOM_APP_FONT_SIZE}_${getApkBrandingScopeSuffix()}"

    fun getAppName(context: Context): String {
        val prefs = context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val local = prefs.getString(scopedAppNameKey(), null)
        return if (!local.isNullOrBlank()) local else "MagicTune Tool"
    }

    fun setAppName(context: Context, name: String) {
        val clean = name.trim().ifBlank { "MagicTune Tool" }
        context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit().putString(scopedAppNameKey(), clean).apply()
        notifyProAndConfigStateChanged(context)
    }

    fun getAppVersionLabel(context: Context): String {
        val prefs = context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val local = prefs.getString(scopedAppVersionKey(), null)
        return local ?: com.example.data.APP_VERSION_NAME.lowercase()
    }

    fun setAppVersionLabel(context: Context, versionLabel: String) {
        context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit().putString(scopedAppVersionKey(), versionLabel.trim()).apply()
        notifyProAndConfigStateChanged(context)
    }

    fun getAppNameFontSizeSp(context: Context): Float {
        val prefs = context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val local = prefs.getFloat(scopedAppFontSizeKey(), -1f)
        return if (local in 7f..26f) local else 11.5f
    }

    fun setAppNameFontSizeSp(context: Context, sizeSp: Float) {
        val cleanSize = sizeSp.coerceIn(7.5f, 24f)
        context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit().putFloat(scopedAppFontSizeKey(), cleanSize).apply()
        notifyProAndConfigStateChanged(context)
    }

    fun setHeaderBrandingConfig(
        context: Context,
        appName: String,
        versionLabel: String,
        fontSizeSp: Float
    ) {
        val cleanName = appName.trim().ifBlank { "MagicTune Tool" }
        val cleanVer = versionLabel.trim()
        val cleanSize = fontSizeSp.coerceIn(7.5f, 24f)
        context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(scopedAppNameKey(), cleanName)
            .putString(scopedAppVersionKey(), cleanVer)
            .putFloat(scopedAppFontSizeKey(), cleanSize)
            .apply()
        notifyProAndConfigStateChanged(context)
    }

    fun getAppUiScale(context: Context): Float {
        val prefs = context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val local = prefs.getFloat(KEY_APP_UI_SCALE, -1f)
        val result = if (local in 0.80f..1.00f) {
            (kotlin.math.round(local * 100f) / 100f).coerceIn(0.80f, 1.00f)
        } else {
            0.85f
        }
        _appUiScaleFlow.value = result
        return result
    }

    fun setAppUiScale(context: Context, scale: Float, syncCloud: Boolean = false) {
        val cleanScale = (kotlin.math.round(scale * 100f) / 100f).coerceIn(0.80f, 1.00f)
        context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit()
            .putFloat(KEY_APP_UI_SCALE, cleanScale)
            .putLong(KEY_APP_UI_SCALE_UPDATED_AT, System.currentTimeMillis())
            .apply()
        _appUiScaleFlow.value = cleanScale
        notifyProAndConfigStateChanged(context)
    }

    fun isFacebookHeaderIconVisible(context: Context?): Boolean {
        if (context == null) return true
        return context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_SHOW_FB_HEADER_ICON, true)
    }

    fun setFacebookHeaderIconVisible(context: Context, visible: Boolean) {
        context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_SHOW_FB_HEADER_ICON, visible).apply()
        notifyProAndConfigStateChanged(context)
    }

    fun isYouTubeHeaderIconVisible(context: Context?): Boolean {
        if (context == null) return true
        return context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_SHOW_YT_HEADER_ICON, true)
    }

    fun setYouTubeHeaderIconVisible(context: Context, visible: Boolean) {
        context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_SHOW_YT_HEADER_ICON, visible).apply()
        notifyProAndConfigStateChanged(context)
    }

    fun getFacebookLink(context: Context): String {
        val saved = context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getString("custom_fb_link", null)?.trim()
        return if (!saved.isNullOrBlank()) saved else DEFAULT_FB_LINK
    }

    fun setFacebookLink(context: Context, link: String) {
        val clean = link.trim().ifBlank { DEFAULT_FB_LINK }
        context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit().putString("custom_fb_link", clean).apply()
        notifyProAndConfigStateChanged(context)
    }

    fun getCustomYouTubeUrl(context: Context): String {
        val saved = context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getString("custom_youtube_url", null)?.trim()
        return if (!saved.isNullOrBlank()) saved else DEFAULT_YT_LINK
    }

    fun setCustomYouTubeUrl(context: Context, url: String) {
        val clean = url.trim().ifBlank { DEFAULT_YT_LINK }
        context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit().putString("custom_youtube_url", clean).apply()
        notifyProAndConfigStateChanged(context)
    }

    fun isShizukuConnectionDisabled(context: Context): Boolean {
        return try {
            context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .getBoolean("disable_shizuku_connection", false)
        } catch (_: Exception) {
            false
        }
    }

    fun setShizukuConnectionDisabled(
        context: Context,
        disabled: Boolean,
        onComplete: ((Boolean, String) -> Unit)? = null
    ) {
        try {
            context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .edit().putBoolean("disable_shizuku_connection", disabled).apply()
            notifyProAndConfigStateChanged(context)
            onComplete?.invoke(true, if (disabled) "Đã tắt kết nối Shizuku" else "Đã bật kết nối Shizuku")
        } catch (e: Exception) {
            onComplete?.invoke(false, "Lỗi lưu cài đặt Shizuku: ${e.message}")
        }
    }

    // =========================================================================
    // CẬP NHẬT APK & BROADCAST CỤC BỘ
    // =========================================================================

    fun isSupportedApkUpdateLink(url: String): Boolean {
        val clean = url.trim().lowercase()
        return clean.startsWith("https://") || clean.startsWith("http://")
    }

    fun getUpdateLink(context: Context): String {
        val saved = context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getString("custom_update_link", null)?.trim()
        return if (!saved.isNullOrBlank() && isSupportedApkUpdateLink(saved)) saved else DEFAULT_GITHUB_REPO
    }

    fun getGoogleDriveUpdateLink(context: Context): String = getUpdateLink(context)

    fun resolveGoogleDriveApkLink(context: Context, candidate: String): String =
        candidate.trim().takeIf { isSupportedApkUpdateLink(it) } ?: getGoogleDriveUpdateLink(context)

    fun setUpdateLink(context: Context, link: String) {
        val clean = link.trim().takeIf { isSupportedApkUpdateLink(it) } ?: DEFAULT_GITHUB_REPO
        context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit().putString("custom_update_link", clean).apply()
        notifyProAndConfigStateChanged(context)
    }

    fun getCurrentInstalledVersionCode(context: Context): Long {
        return try {
            val pm = context.packageManager
            val pkgInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageInfo(context.packageName, PackageManager.PackageInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(context.packageName, 0)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                pkgInfo.longVersionCode
            } else {
                @Suppress("DEPRECATION")
                pkgInfo.versionCode.toLong()
            }
        } catch (_: Throwable) {
            runCatching { com.example.BuildConfig.VERSION_CODE.toLong() }.getOrDefault(0L)
        }
    }

    fun isUpdateAvailableForThisDevice(context: Context, release: LatestApkRelease?): Boolean {
        if (release == null) return false
        return release.versionCode > getCurrentInstalledVersionCode(context) &&
            release.downloadUrl.isNotBlank()
    }

    fun isBroadcastDismissed(context: Context, broadcastId: String): Boolean {
        if (broadcastId.isBlank()) return false
        return context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getString(KEY_DISMISSED_BROADCAST_ID, "") == broadcastId
    }

    fun markBroadcastDismissed(context: Context, broadcastId: String) {
        if (broadcastId.isBlank()) return
        context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_DISMISSED_BROADCAST_ID, broadcastId).apply()
    }

    fun isReleaseAutoPromptDismissed(context: Context, releaseId: String): Boolean {
        if (releaseId.isBlank()) return false
        return context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getString(KEY_DISMISSED_RELEASE_ID, "") == releaseId
    }

    fun markReleaseAutoPromptDismissed(context: Context, releaseId: String) {
        if (releaseId.isBlank()) return
        context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_DISMISSED_RELEASE_ID, releaseId).apply()
    }

    // =========================================================================
    // QUẢN LÝ KEY AI CÁ NHÂN (GEMINI & GROQ — XOAY VÒNG & GIỚI HẠN MIỄN PHÍ)
    // =========================================================================

    private const val MAX_FREE_GEMINI_RPM = 12
    private const val MAX_FREE_GEMINI_RPD = 1400
    private const val MAX_FREE_GROQ_RPM = 25
    private const val MAX_FREE_GROQ_RPD = 1400

    private val verifiedValidAiKeysRam = ConcurrentHashMap.newKeySet<String>()
    private val invalidDeadAiKeysRam = ConcurrentHashMap.newKeySet<String>()
    @Volatile
    private var invalidDeadKeysLoaded = false

    private val keyMinuteTimestampsMap = ConcurrentHashMap<String, MutableList<Long>>()
    private val keyDailyCountMap = ConcurrentHashMap<String, Int>()
    private val keyCooldownMap = ConcurrentHashMap<String, Long>()
    private val magic_liveKeyCooldownMap = ConcurrentHashMap<String, Long>()

    @Volatile
    private var activeQuotaDayKey: String = ""
    private var currentApiKeyIndex = 0
    private var currentMagicLiveKeyIndex = 0

    private fun ensureInvalidDeadKeysLoaded(context: Context?) {
        if (invalidDeadKeysLoaded || context == null) return
        synchronized(invalidDeadAiKeysRam) {
            if (invalidDeadKeysLoaded) return
            try {
                val prefs = context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                prefs.getStringSet(KEY_INVALID_DEAD_AI_KEYS, emptySet())?.forEach { k ->
                    if (k.isNotBlank()) invalidDeadAiKeysRam.add(k.trim())
                }
                invalidDeadKeysLoaded = true
            } catch (_: Throwable) {}
        }
    }

    fun isAiKeyInvalidOrDead(context: Context?, key: String): Boolean {
        val clean = key.trim()
        if (clean.isBlank()) return true
        ensureInvalidDeadKeysLoaded(context)
        return invalidDeadAiKeysRam.contains(clean)
    }

    fun isPlausibleGeminiKeyFormat(key: String): Boolean {
        val clean = key.trim()
        if (!clean.matches(Regex("^AIza[0-9A-Za-z_\\-]{31,48}$"))) return false
        val body = clean.removePrefix("AIza")
        if (body.toSet().size < 8) return false
        if (body.contains("12345678") || body.contains("abcdefgh", ignoreCase = true)) return false
        return !invalidDeadAiKeysRam.contains(clean)
    }

    fun isPlausibleGroqKeyFormat(key: String): Boolean {
        val clean = key.trim()
        if (!clean.matches(Regex("^gsk_[0-9A-Za-z_\\-]{36,72}$"))) return false
        val body = clean.removePrefix("gsk_")
        if (body.toSet().size < 10) return false
        if (body.contains("12345678") || body.contains("abcdefgh", ignoreCase = true)) return false
        return !invalidDeadAiKeysRam.contains(clean)
    }

    fun verifySingleGeminiKeyLive(context: Context?, apiKey: String): Pair<Boolean, String> {
        val clean = apiKey.trim()
        ensureInvalidDeadKeysLoaded(context)
        if (!isPlausibleGeminiKeyFormat(clean)) {
            return false to "Key Gemini (${clean.take(10)}...) sai định dạng chuẩn (cần 39 ký tự bắt đầu bằng AIza...)"
        }
        if (verifiedValidAiKeysRam.contains(clean)) {
            return true to "Key Gemini hợp lệ"
        }
        var conn: HttpURLConnection? = null
        return try {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models?key=$clean&pageSize=3")
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 6000
                readTimeout = 6000
                setRequestProperty("Accept", "application/json")
            }
            val code = conn.responseCode
            when {
                code in 200..299 -> {
                    val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText().take(600) }
                    if (body.contains("\"models\"")) {
                        verifiedValidAiKeysRam.add(clean)
                        invalidDeadAiKeysRam.remove(clean)
                        true to "Key Gemini hợp lệ & hoạt động tốt"
                    } else {
                        false to "Key Gemini (${clean.take(10)}...) phản hồi không hợp lệ từ Google"
                    }
                }
                code == 429 -> {
                    verifiedValidAiKeysRam.add(clean)
                    invalidDeadAiKeysRam.remove(clean)
                    true to "Key Gemini hợp lệ (đang chạm giới hạn phút tạm thời)"
                }
                code == 400 || code == 401 || code == 403 ->
                    false to "Key Gemini (${clean.take(10)}...) không hợp lệ hoặc đã bị thu hồi trên Google AI Studio."
                else ->
                    false to "Máy chủ Google trả mã HTTP $code khi kiểm tra Key (${clean.take(10)}...)"
            }
        } catch (_: Throwable) {
            false to "Không thể kết nối Internet để kiểm tra Key Gemini (${clean.take(10)}...)."
        } finally {
            try { conn?.disconnect() } catch (_: Throwable) {}
        }
    }

    fun verifySingleGroqKeyLive(context: Context?, apiKey: String): Pair<Boolean, String> {
        val clean = apiKey.trim()
        ensureInvalidDeadKeysLoaded(context)
        if (!isPlausibleGroqKeyFormat(clean)) {
            return false to "Key Groq (${clean.take(10)}...) sai định dạng chuẩn (cần ~56 ký tự bắt đầu bằng gsk_...)"
        }
        if (verifiedValidAiKeysRam.contains(clean)) {
            return true to "Key Groq hợp lệ"
        }
        var conn: HttpURLConnection? = null
        return try {
            val url = URL("https://api.groq.com/openai/v1/models")
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 6000
                readTimeout = 6000
                setRequestProperty("Authorization", "Bearer $clean")
                setRequestProperty("Accept", "application/json")
            }
            val code = conn.responseCode
            when {
                code in 200..299 -> {
                    val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText().take(600) }
                    if (body.contains("\"data\"")) {
                        verifiedValidAiKeysRam.add(clean)
                        invalidDeadAiKeysRam.remove(clean)
                        true to "Key Groq hợp lệ & hoạt động tốt"
                    } else {
                        false to "Key Groq (${clean.take(10)}...) phản hồi không hợp lệ từ Groq"
                    }
                }
                code == 429 -> {
                    verifiedValidAiKeysRam.add(clean)
                    invalidDeadAiKeysRam.remove(clean)
                    true to "Key Groq hợp lệ (đang chạm giới hạn phút tạm thời)"
                }
                code == 400 || code == 401 || code == 403 ->
                    false to "Key Groq (${clean.take(10)}...) không hợp lệ hoặc đã bị thu hồi trên Groq Console."
                else ->
                    false to "Máy chủ Groq trả mã HTTP $code khi kiểm tra Key (${clean.take(10)}...)"
            }
        } catch (_: Throwable) {
            false to "Không thể kết nối Internet để kiểm tra Key Groq (${clean.take(10)}...)."
        } finally {
            try { conn?.disconnect() } catch (_: Throwable) {}
        }
    }

    fun markAiKeyInvalidOrDead(context: Context?, badKey: String, isGemini: Boolean) {
        val clean = badKey.trim()
        if (clean.isBlank()) return
        ensureInvalidDeadKeysLoaded(context)
        invalidDeadAiKeysRam.add(clean)
        verifiedValidAiKeysRam.remove(clean)
        if (isGemini) {
            magic_liveKeyCooldownMap[clean] = System.currentTimeMillis() + 365L * 24 * 3600_000L
            currentMagicLiveKeyIndex = (currentMagicLiveKeyIndex + 1).coerceAtLeast(0)
        } else {
            keyCooldownMap[clean] = System.currentTimeMillis() + 365L * 24 * 3600_000L
            currentApiKeyIndex = (currentApiKeyIndex + 1).coerceAtLeast(0)
        }
        if (context != null) {
            val appCtx = context.applicationContext
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    val savedDead = LinkedHashSet<String>(prefs.getStringSet(KEY_INVALID_DEAD_AI_KEYS, emptySet()) ?: emptySet())
                    savedDead.add(clean)
                    val editor = prefs.edit().putStringSet(KEY_INVALID_DEAD_AI_KEYS, savedDead)
                    val currCustom = getUserCustomMagicLiveKey(appCtx)
                    if (currCustom.contains(clean)) {
                        val filtered = currCustom.split(Regex("[\\s,;]+"))
                            .map { it.trim() }.filter { it.isNotBlank() && it != clean }.joinToString(" ")
                        editor.putString(KEY_USER_CUSTOM_GEMINI_KEY, filtered)
                    }
                    editor.apply()
                } catch (_: Throwable) {}
            }
        }
    }

    fun getUserCustomMagicLiveKey(context: Context): String {
        ensureInvalidDeadKeysLoaded(context)
        return context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getString(KEY_USER_CUSTOM_GEMINI_KEY, "")?.trim().orEmpty()
    }

    fun getUserPersonalGeminiKey(context: Context): String {
        val raw = getUserCustomMagicLiveKey(context)
        val extra = context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getString(KEY_USER_CUSTOM_GEMINI_ONLY, "")?.trim().orEmpty()
        return "$raw $extra".split(Regex("[\\s,;]+"))
            .map { it.trim() }.filter { isPlausibleGeminiKeyFormat(it) }.distinct().joinToString(" ")
    }

    fun getUserPersonalGroqKey(context: Context): String {
        val raw = getUserCustomMagicLiveKey(context)
        val extra = context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getString(KEY_USER_CUSTOM_GROQ_ONLY, "")?.trim().orEmpty()
        return "$raw $extra".split(Regex("[\\s,;]+"))
            .map { it.trim() }.filter { isPlausibleGroqKeyFormat(it) }.distinct().joinToString(" ")
    }

    fun hasUserPersonalGeminiKey(context: Context): Boolean = getUserPersonalGeminiKey(context).isNotBlank()

    fun hasUserPersonalGroqKey(context: Context): Boolean = getUserPersonalGroqKey(context).isNotBlank()

    fun setUserCustomMagicLiveKey(context: Context, key: String, syncToCloud: Boolean = false) {
        ensureInvalidDeadKeysLoaded(context)
        val tokens = key.split(Regex("[\\s,;]+")).map { it.trim() }
            .filter { it.isNotBlank() && it != "null" }.distinct()
        val geminiTokens = tokens.filter { isPlausibleGeminiKeyFormat(it) }
        val groqTokens = tokens.filter { isPlausibleGroqKeyFormat(it) }
        val cleanCombined = (geminiTokens + groqTokens).distinct().joinToString(" ")
        for (tk in geminiTokens) magic_liveKeyCooldownMap.remove(tk)
        for (tk in groqTokens) keyCooldownMap.remove(tk)
        context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_USER_CUSTOM_GEMINI_KEY, cleanCombined)
            .putString(KEY_USER_CUSTOM_GEMINI_ONLY, geminiTokens.joinToString(" "))
            .putString(KEY_USER_CUSTOM_GROQ_ONLY, groqTokens.joinToString(" "))
            .putLong("user_custom_ai_key_updated_ms", System.currentTimeMillis())
            .apply()
        notifyProAndConfigStateChanged(context)
    }

    fun validateAndSaveUserAiKeysLive(context: Context, rawText: String): LiveKeyValidationReport {
        val appCtx = context.applicationContext ?: context
        ensureInvalidDeadKeysLoaded(appCtx)
        val candidateGemini = Regex("AIza[0-9A-Za-z_\\-]{10,}").findAll(rawText).map { it.value.trim() }.distinct().toList()
        val candidateGroq = Regex("gsk_[0-9A-Za-z_\\-]{10,}").findAll(rawText).map { it.value.trim() }.distinct().toList()

        val validGemini = mutableListOf<String>()
        val validGroq = mutableListOf<String>()
        val invalidReasons = mutableListOf<String>()

        for (gKey in candidateGemini) {
            val (ok, msg) = verifySingleGeminiKeyLive(appCtx, gKey)
            if (ok) validGemini.add(gKey) else invalidReasons.add(msg)
        }
        for (kKey in candidateGroq) {
            val (ok, msg) = verifySingleGroqKeyLive(appCtx, kKey)
            if (ok) validGroq.add(kKey) else invalidReasons.add(msg)
        }

        val savedAny = validGemini.isNotEmpty() || validGroq.isNotEmpty()
        if (savedAny) {
            val prevGemini = getUserPersonalGeminiKey(appCtx).split(Regex("[\\s,;]+")).map { it.trim() }.filter { isPlausibleGeminiKeyFormat(it) }
            val prevGroq = getUserPersonalGroqKey(appCtx).split(Regex("[\\s,;]+")).map { it.trim() }.filter { isPlausibleGroqKeyFormat(it) }
            val combinedValid = ((validGemini + prevGemini).distinct() + (validGroq + prevGroq).distinct()).joinToString(" ")
            setUserCustomMagicLiveKey(appCtx, combinedValid)
        }

        return LiveKeyValidationReport(
            validGeminiKeys = validGemini,
            validGroqKeys = validGroq,
            invalidReasons = invalidReasons,
            savedAnyValidKey = savedAny
        )
    }

    fun checkMagicLiveAiKeyRequirement(context: Context): Pair<Boolean, String> {
        if (com.example.core.ai.PersonalAi.Use.entries.any {
            com.example.core.ai.PersonalAi.choice(context, it) != null
        }) return true to ""

        val hasGem = getAllGeminiKeysRaw(context).isNotEmpty()
        val hasGroq = getAllGroqKeysRaw(context).isNotEmpty()
        if (hasGem || hasGroq) {
            return true to "🔑 Đang sử dụng API Key cá nhân trên thiết bị"
        }
        return false to "🔑 Vui lòng thêm API Key Gemini (AIza...) hoặc Groq (gsk_...) miễn phí cá nhân tại tab '12. API Cá Nhân' hoặc bấm '🔑 Thêm Key' trên bảng MagicLive."
    }

    private fun getAllGeminiKeysRaw(context: Context): List<String> {
        ensureInvalidDeadKeysLoaded(context)
        val combined = mutableListOf<String>()
        val prefs = context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val sources = listOf(
            getUserPersonalGeminiKey(context),
            prefs.getString(KEY_GEMINI_API_KEY_POOL, "").orEmpty(),
            prefs.getString(KEY_GROQ_API_KEY_POOL, "").orEmpty()
        )
        for (src in sources) {
            src.split(Regex("[\\s,;]+")).map { it.trim() }
                .filter { isPlausibleGeminiKeyFormat(it) && !isAiKeyInvalidOrDead(context, it) }
                .forEach { if (!combined.contains(it)) combined.add(it) }
        }
        return combined
    }

    private fun getAllGroqKeysRaw(context: Context): List<String> {
        ensureInvalidDeadKeysLoaded(context)
        val combined = mutableListOf<String>()
        val prefs = context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val sources = listOf(
            getUserPersonalGroqKey(context),
            prefs.getString(KEY_GROQ_API_KEY_POOL, "").orEmpty(),
            prefs.getString(KEY_GEMINI_API_KEY_POOL, "").orEmpty()
        )
        for (src in sources) {
            src.split(Regex("[\\s,;]+")).map { it.trim() }
                .filter { isPlausibleGroqKeyFormat(it) && !isAiKeyInvalidOrDead(context, it) }
                .forEach { if (!combined.contains(it)) combined.add(it) }
        }
        val buildKey = try { com.example.BuildConfig.GROQ_API_KEY.trim() } catch (_: Throwable) { "" }
        if (isPlausibleGroqKeyFormat(buildKey) && !isAiKeyInvalidOrDead(context, buildKey) && !combined.contains(buildKey)) {
            combined.add(buildKey)
        }
        return combined
    }

    fun getAllMagicLiveApiKeys(context: Context, forMagicLiveFeature: Boolean = false): List<String> {
        ensureQuotaDayFresh(context)
        val all = getAllGeminiKeysRaw(context)
        if (all.isEmpty()) return emptyList()
        val start = if (all.size > 1) (currentMagicLiveKeyIndex.coerceAtLeast(0)) % all.size else 0
        val rotated = all.drop(start) + all.take(start)
        return rotated.filter { isAiKeyWithinFreeTierLimit(context, it, isGemini = true) }.ifEmpty { rotated }
    }

    fun getAllGroqApiKeys(context: Context, forMagicLiveFeature: Boolean = false): List<String> {
        ensureQuotaDayFresh(context)
        val all = getAllGroqKeysRaw(context)
        if (all.isEmpty()) return emptyList()
        val start = if (all.size > 1) (currentApiKeyIndex.coerceAtLeast(0)) % all.size else 0
        val rotated = all.drop(start) + all.take(start)
        return rotated.filter { isAiKeyWithinFreeTierLimit(context, it, isGemini = false) }.ifEmpty { rotated }
    }

    fun getLoadBalancedGroqApiKey(context: Context): String {
        val keys = getAllGroqApiKeys(context)
        val first = keys.firstOrNull() ?: return ""
        currentApiKeyIndex = (currentApiKeyIndex + 1).coerceAtLeast(0)
        return first
    }

    fun markMagicLiveApiKeyCooldown(key: String, cooldownMs: Long = 75_000L) {
        val clean = key.trim()
        if (clean.isNotBlank()) {
            magic_liveKeyCooldownMap[clean] = System.currentTimeMillis() + cooldownMs
            currentMagicLiveKeyIndex = (currentMagicLiveKeyIndex + 1).coerceAtLeast(0)
        }
    }

    fun markGroqApiKeyCooldown(key: String, cooldownMs: Long = 65_000L) {
        val clean = key.trim()
        if (clean.isNotBlank()) {
            keyCooldownMap[clean] = System.currentTimeMillis() + cooldownMs
            currentApiKeyIndex = (currentApiKeyIndex + 1).coerceAtLeast(0)
        }
    }

    private fun currentQuotaDayString(): String =
        java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())

    private fun ensureQuotaDayFresh(context: Context?) {
        val today = currentQuotaDayString()
        if (activeQuotaDayKey != today) {
            synchronized(keyDailyCountMap) {
                if (activeQuotaDayKey != today) {
                    activeQuotaDayKey = today
                    keyDailyCountMap.clear()
                    if (context != null) {
                        try {
                            val prefs = context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                            if (prefs.getString("ai_quota_day_str", "") != today) {
                                prefs.edit().putString("ai_quota_day_str", today).putString("ai_quota_counts_json", "{}").apply()
                            } else {
                                val obj = JSONObject(prefs.getString("ai_quota_counts_json", "{}") ?: "{}")
                                val keys = obj.keys()
                                while (keys.hasNext()) {
                                    val k = keys.next()
                                    keyDailyCountMap[k] = obj.optInt(k, 0)
                                }
                            }
                        } catch (_: Throwable) {}
                    }
                }
            }
        }
    }

    fun isAiKeyWithinFreeTierLimit(context: Context?, apiKey: String, isGemini: Boolean): Boolean {
        val clean = apiKey.trim()
        if (clean.isBlank()) return false
        ensureQuotaDayFresh(context)
        val now = System.currentTimeMillis()
        val cooldownUntil = if (isGemini) (magic_liveKeyCooldownMap[clean] ?: 0L) else (keyCooldownMap[clean] ?: 0L)
        if (cooldownUntil > now) return false
        val maxRpm = if (isGemini) MAX_FREE_GEMINI_RPM else MAX_FREE_GROQ_RPM
        val maxRpd = if (isGemini) MAX_FREE_GEMINI_RPD else MAX_FREE_GROQ_RPD
        if ((keyDailyCountMap[clean] ?: 0) >= maxRpd) return false
        val list = keyMinuteTimestampsMap.getOrPut(clean) { Collections.synchronizedList(mutableListOf()) }
        synchronized(list) {
            list.removeAll { now - it > 60_000L }
            if (list.size >= maxRpm) return false
        }
        return true
    }

    fun tryConsumeAiKeyFreeTierQuota(context: Context?, apiKey: String, isGemini: Boolean): Boolean {
        val clean = apiKey.trim()
        if (!isAiKeyWithinFreeTierLimit(context, clean, isGemini)) return false
        val list = keyMinuteTimestampsMap.getOrPut(clean) { Collections.synchronizedList(mutableListOf()) }
        synchronized(list) { list.add(System.currentTimeMillis()) }
        val newDaily = (keyDailyCountMap[clean] ?: 0) + 1
        keyDailyCountMap[clean] = newDaily
        if (isGemini) currentMagicLiveKeyIndex++ else currentApiKeyIndex++
        if (context != null && (newDaily % 5 == 1)) {
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val obj = JSONObject()
                    for ((k, v) in keyDailyCountMap) obj.put(k, v)
                    context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                        .edit()
                        .putString("ai_quota_day_str", currentQuotaDayString())
                        .putString("ai_quota_counts_json", obj.toString())
                        .apply()
                } catch (_: Throwable) {}
            }
        }
        return true
    }

    fun getAiKeyPoolStatusSummary(context: Context): AiKeyPoolStatusSummary {
        ensureQuotaDayFresh(context)
        val allGroq = getAllGroqKeysRaw(context)
        val allGemini = getAllGeminiKeysRaw(context)
        val activeGroq = allGroq.count { isAiKeyWithinFreeTierLimit(context, it, isGemini = false) }
        val activeGemini = allGemini.count { isAiKeyWithinFreeTierLimit(context, it, isGemini = true) }
        return AiKeyPoolStatusSummary(
            totalGroqKeys = allGroq.size,
            activeGroqKeys = activeGroq,
            cooldownGroqKeys = (allGroq.size - activeGroq).coerceAtLeast(0),
            totalGeminiKeys = allGemini.size,
            activeGeminiKeys = activeGemini,
            cooldownGeminiKeys = (allGemini.size - activeGemini).coerceAtLeast(0),
            hasPersonalGemini = hasUserPersonalGeminiKey(context),
            hasPersonalGroq = hasUserPersonalGroqKey(context),
            totalCallsTodayInFreeTier = keyDailyCountMap.values.sum()
        )
    }
}
