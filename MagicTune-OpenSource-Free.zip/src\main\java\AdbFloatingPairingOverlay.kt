package com.example.core.adb

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.example.core.i18n.AppLanguageManager.tr
import com.example.core.shell.ShellEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Cửa sổ nổi siêu gọn (FLAG_NOT_FOCUSABLE) hiển thị ngay phía trên màn hình Cài Đặt khi ghép nối Gỡ lỗi Wi-Fi.
 * - Tuyệt đối không chiếm quyền Focus của cửa sổ Cài đặt và không bật bàn phím che khuất mã 6 số.
 * - Người dùng vừa nhìn 6 số trong Cài đặt vừa bấm trực tiếp 6 số trên thanh nổi -> Ghép nối thành công 100%!
 */
object AdbFloatingPairingOverlay {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    @Volatile
    private var rootView: View? = null
    private var windowManager: WindowManager? = null
    private var layoutParams: WindowManager.LayoutParams? = null
    private var scannerWatchJob: Job? = null

    private var statusTextView: TextView? = null
    private var pinDisplayView: TextView? = null
    private var currentPin: String = ""
    private var isPairingBusy: Boolean = false
    @Volatile
    private var lastAppContext: Context? = null

    fun showIfPermitted(context: Context) {
        val appCtx = context.applicationContext ?: context
        lastAppContext = appCtx
        if (!Settings.canDrawOverlays(appCtx)) {
            dismiss()
            return
        }
        mainHandler.post {
            try {
                val existing = rootView
                val wm = windowManager
                if (existing != null && wm != null) {
                    try { wm.removeViewImmediate(existing) } catch (_: Throwable) {}
                }
                rootView = null
                createAndAttachOverlay(appCtx)
            } catch (_: Throwable) {
                rootView = null
            }
        }
    }

    fun dismiss() {
        scannerWatchJob?.cancel()
        scannerWatchJob = null
        lastAppContext?.let { ctx ->
            try {
                val scanner = AdbNsdScanner.getInstance(ctx)
                scanner.isPairingUiActive = false
                scanner.releaseMulticastLock()
                if (!AdbPairingNotificationManager.isNotificationPairingActive) {
                    scanner.stopDiscovery(updateStatusText = false)
                }
            } catch (_: Throwable) {}
        }
        mainHandler.post {
            try {
                val view = rootView
                val wm = windowManager
                if (view != null && wm != null) {
                    wm.removeViewImmediate(view)
                }
            } catch (_: Throwable) {}
            rootView = null
            statusTextView = null
            pinDisplayView = null
            currentPin = ""
            isPairingBusy = false
        }
    }

    private fun dp(context: Context, value: Float): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            context.resources.displayMetrics
        ).toInt()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createAndAttachOverlay(context: Context) {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
        windowManager = wm
        currentPin = ""
        isPairingBusy = false

        val overlayType = com.example.core.compat.DeviceCompatProfile.overlayWindowType()

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(context, 38f)
        }
        layoutParams = params

        val outerWrapper = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            val hPad = dp(context, 10f)
            setPadding(hPad, dp(context, 4f), hPad, dp(context, 4f))
        }

        val cardBg = GradientDrawable().apply {
            setColor(Color.parseColor("#F2090D16"))
            cornerRadius = dp(context, 16f).toFloat()
            setStroke(dp(context, 1.5f), Color.parseColor("#00E5FF"))
        }

        val card = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            background = cardBg
            val pad = dp(context, 10f)
            setPadding(pad, dp(context, 8f), pad, dp(context, 8f))
        }

        // Hàng 1: Tiêu đề + Trạng thái Cổng + Nút đóng X
        val headerRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val statusTv = TextView(context).apply {
            text = tr(context, "⏳ Mở 'Ghép nối bằng mã ghép đôi' để bắt cổng...", "⏳ Open 'Pair device with pairing code' to detect port...")
            setTextColor(Color.parseColor("#67E8F9"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        statusTextView = statusTv

        val closeBtn = TextView(context).apply {
            text = "✕"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            val bg = GradientDrawable().apply {
                setColor(Color.parseColor("#334155"))
                cornerRadius = dp(context, 8f).toFloat()
            }
            background = bg
            val s = dp(context, 26f)
            layoutParams = LinearLayout.LayoutParams(s, s).apply {
                marginStart = dp(context, 6f)
            }
            setOnClickListener { dismiss() }
        }

        headerRow.addView(statusTv)
        headerRow.addView(closeBtn)

        // Cho phép kéo thanh nổi lên/xuống bằng cách vuốt thanh tiêu đề
        var initialY = 0
        var touchY = 0f
        headerRow.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    initialY = params.y
                    touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.y = (initialY + (event.rawY - touchY).toInt()).coerceAtLeast(0)
                    try { wm.updateViewLayout(outerWrapper, params) } catch (_: Throwable) {}
                    true
                }
                else -> false
            }
        }

        // Hàng 2: Hiển thị 6 số PIN đang bấm + Nút Xóa
        val pinRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(context, 6f)
                bottomMargin = dp(context, 6f)
            }
        }

        val pinTv = TextView(context).apply {
            text = tr(context, "Bấm 6 số mã ghép đôi bên dưới: _ _ _ _ _ _", "Enter 6-digit pairing code below: _ _ _ _ _ _")
            setTextColor(Color.parseColor("#10B981"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            val pinBg = GradientDrawable().apply {
                setColor(Color.parseColor("#020617"))
                cornerRadius = dp(context, 10f).toFloat()
                setStroke(dp(context, 1f), Color.parseColor("#1E293B"))
            }
            background = pinBg
            setPadding(dp(context, 8f), dp(context, 6f), dp(context, 8f), dp(context, 6f))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        pinDisplayView = pinTv

        val backspaceBtn = TextView(context).apply {
            text = tr(context, "⌫ Xóa", "⌫ Del")
            setTextColor(Color.parseColor("#FCA5A5"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            val bg = GradientDrawable().apply {
                setColor(Color.parseColor("#450A0A"))
                cornerRadius = dp(context, 10f).toFloat()
                setStroke(dp(context, 1f), Color.parseColor("#EF4444"))
            }
            background = bg
            setPadding(dp(context, 10f), dp(context, 6f), dp(context, 10f), dp(context, 6f))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                marginStart = dp(context, 6f)
            }
            setOnClickListener {
                if (!isPairingBusy && currentPin.isNotEmpty()) {
                    currentPin = currentPin.dropLast(1)
                    updatePinDisplay(context)
                }
            }
        }

        pinRow.addView(pinTv)
        pinRow.addView(backspaceBtn)

        // Hàng 3: Dãy phím số 0..9 trên 1 hàng ngang siêu gọn (không cần mở bàn phím hệ thống)
        val digitsRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        for (digit in listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")) {
            val btn = TextView(context).apply {
                text = digit
                setTextColor(Color.parseColor("#020617"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                val btnBg = GradientDrawable().apply {
                    setColor(Color.parseColor("#00E5FF"))
                    cornerRadius = dp(context, 8f).toFloat()
                }
                background = btnBg
                setPadding(0, dp(context, 8f), 0, dp(context, 8f))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    val m = dp(context, 1.5f)
                    setMargins(m, 0, m, 0)
                }
                setOnClickListener {
                    onDigitPressed(context, digit)
                }
            }
            digitsRow.addView(btn)
        }

        card.addView(headerRow)
        card.addView(pinRow)
        card.addView(digitsRow)
        outerWrapper.addView(card)

        wm.addView(outerWrapper, params)
        rootView = outerWrapper

        startWatchingScanner(context)
    }

    private fun startWatchingScanner(context: Context) {
        scannerWatchJob?.cancel()
        val scanner = AdbNsdScanner.getInstance(context)
        scanner.isPairingUiActive = true
        scanner.startDiscovery()
        scannerWatchJob = scope.launch {
            scanner.state.collect {
                mainHandler.post {
                    updateUiState(context)
                }
            }
        }
    }

    private fun renderPinTextOnly() {
        val tv = pinDisplayView ?: return
        if (currentPin.isEmpty()) {
            tv.text = tr("Bấm 6 số mã ghép đôi: _ _ _ _ _ _", "Enter 6-digit code: _ _ _ _ _ _")
            tv.setTextColor(Color.parseColor("#94A3B8"))
        } else {
            val padded = currentPin.padEnd(6, '_').toCharArray().joinToString(" ")
            tv.text = tr("Mã PIN: $padded", "PIN: $padded")
            tv.setTextColor(Color.parseColor("#10B981"))
        }
    }

    private fun updatePinDisplay(context: Context) {
        renderPinTextOnly()
        updateUiState(context)
    }

    private fun updateUiState(context: Context) {
        if (isPairingBusy) return
        val tv = statusTextView ?: return
        val scanner = AdbNsdScanner.getInstance(context)
        val port = scanner.getBestPairingPort()
        if (port != null && port in 1..65535) {
            tv.text = tr(context, "🟢 Đã bắt cổng $port! Hãy bấm 6 số mã ghép đôi bên dưới:", "🟢 Port $port detected! Enter 6-digit code below:")
            tv.setTextColor(Color.parseColor("#10B981"))
        } else {
            tv.text = tr(context, "⏳ Vào Gỡ lỗi Wi-Fi ➔ Bấm 'Ghép nối bằng mã ghép đôi' (Kéo để di chuyển)", "⏳ Go to Wireless debugging ➔ Tap 'Pair with pairing code' (Drag to move)")
            tv.setTextColor(Color.parseColor("#67E8F9"))
        }
    }

    private fun onDigitPressed(context: Context, digit: String) {
        if (isPairingBusy) return
        if (currentPin.length >= 6) return
        currentPin += digit
        updatePinDisplay(context)

        if (currentPin.length == 6) {
            val scanner = AdbNsdScanner.getInstance(context)
            val port = scanner.getBestPairingPort() ?: 0
            if (port !in 1..65535) {
                currentPin = ""
                renderPinTextOnly()
                statusTextView?.text = tr(context, "⚠️ Chưa bắt được cổng! Hãy mở bảng 'Ghép nối bằng mã ghép đôi' rồi bấm lại 6 số.", "⚠️ Port not detected! Open 'Pair with pairing code' and re-enter 6 digits.")
                statusTextView?.setTextColor(Color.parseColor("#F59E0B"))
                return
            }
            submitPinFromOverlay(context, port, currentPin)
        }
    }

    private fun submitPinFromOverlay(context: Context, pairingPort: Int, pin: String) {
        isPairingBusy = true
        statusTextView?.text = tr(context, "⏳ Đang ghép nối mã $pin với cổng $pairingPort...", "⏳ Pairing code $pin on port $pairingPort...")
        statusTextView?.setTextColor(Color.parseColor("#38BDF8"))

        scope.launch {
            val appCtx = context.applicationContext
            val engine = AdbPairingNotificationManager.activeShellEngine ?: ShellEngine.getInstance(appCtx)
            val scanner = AdbNsdScanner.getInstance(appCtx)
            val pairRes = engine.pairWirelessAdb(pairingPort, pin)
            val pairOk = pairRes.isSuccess && pairRes.getOrDefault(false)

            if (pairOk) {
                mainHandler.post {
                    statusTextView?.text = tr(appCtx, "✅ Ghép nối thành công! Đang tự động kết nối cổng chính...", "✅ Paired! Auto-connecting main port...")
                    statusTextView?.setTextColor(Color.parseColor("#10B981"))
                }
                var connectPort = scanner.getBestConnectPort()
                var connectedOk = false
                if (connectPort != null && connectPort in 1..65535) {
                    connectedOk = engine.connectWirelessAdb(connectPort)
                }
                if (!connectedOk) {
                    scanner.refreshConnectDiscovery()
                    for (i in 1..16) {
                        delay(400)
                        connectPort = scanner.getBestConnectPort()
                        if (connectPort != null && connectPort in 1..65535) {
                            connectedOk = engine.connectWirelessAdb(connectPort)
                            if (connectedOk) break
                        }
                    }
                }
                if (connectedOk) {
                    AdbPairingNotificationManager.finalizePairingSuccessUi(appCtx, scanner)
                    try {
                        val nm = appCtx.getSystemService(android.app.NotificationManager::class.java)
                        nm?.cancel(AdbPairingNotificationManager.NOTIFICATION_ID)
                    } catch (_: Throwable) {}
                    mainHandler.post {
                        statusTextView?.text = tr(appCtx, "🎉 ĐÃ KẾT NỐI DIRECT WLAN ADB THÀNH CÔNG!", "🎉 DIRECT WLAN ADB CONNECTED!")
                        statusTextView?.setTextColor(Color.parseColor("#10B981"))
                    }
                    delay(1000)
                    dismiss()
                } else {
                    mainHandler.post {
                        isPairingBusy = false
                        currentPin = ""
                        renderPinTextOnly()
                        statusTextView?.text = tr(appCtx, "✅ Đã ghép nối PIN! Chưa thấy cổng chính — hãy tắt/bật lại Gỡ lỗi Wi-Fi hoặc bấm Nối Nhanh trong app.", "✅ PIN paired! Main port not found — toggle Wireless debugging or tap Quick Connect.")
                        statusTextView?.setTextColor(Color.parseColor("#F59E0B"))
                    }
                }
            } else {
                val err = pairRes.exceptionOrNull()?.localizedMessage ?: tr(appCtx, "Sai mã PIN hoặc cổng đã đóng", "Wrong PIN or port closed")
                mainHandler.post {
                    isPairingBusy = false
                    currentPin = ""
                    renderPinTextOnly()
                    statusTextView?.text = "❌ $err"
                    statusTextView?.setTextColor(Color.parseColor("#F87171"))
                }
            }
        }
    }
}
