package com.example.ui.components
import com.example.core.i18n.AppLanguageManager.tr
import com.example.ui.theme.TextPrimary

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.installer.InAppApkUpdater
import com.example.core.installer.WlanFastApkInstaller
import com.example.core.license.LicenseManager
import com.example.core.shell.ShellEngine
import com.example.data.APP_VERSION_NAME
import com.example.ui.theme.MagicAmber
import com.example.ui.theme.MagicAmberLight
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicCyanLight
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicEmeraldLight
import com.example.ui.theme.MagicRose
import com.example.ui.theme.MagicRoseLight
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.MagicSurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

@Composable
fun InAppUpdateDialog(
    initialUpdateUrl: String,
    broadcastTitle: String = "",
    broadcastMessage: String = "",
    autoStartDownload: Boolean = false,
    autoInstallOnDownloaded: Boolean = false,
    latestRelease: LicenseManager.LatestApkRelease? = null,
    cloudReleaseOnly: Boolean = false,
    isCheckingCloudRelease: Boolean = false,
    cloudCheckSucceeded: Boolean = true,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var urlInput by remember(initialUpdateUrl) {
        mutableStateOf(
            LicenseManager.resolveGoogleDriveApkLink(
                context,
                initialUpdateUrl.ifBlank { latestRelease?.downloadUrl.orEmpty() }
            )
        )
    }
    var showCustomUrlBox by remember { mutableStateOf(false) }
    var isDownloading by remember { mutableStateOf(false) }
    var isInstalling by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf<InAppApkUpdater.DownloadProgress?>(null) }
    var downloadedApk by remember { mutableStateOf<InAppApkUpdater.DownloadedApkInfo?>(null) }
    var statusText by remember { mutableStateOf<String?>(null) }
    var errorText by remember { mutableStateOf<String?>(null) }
    var needsInstallPermission by remember { mutableStateOf(false) }
    var downloadJob by remember { mutableStateOf<Job?>(null) }
    val installedVersionCode = remember(context) { LicenseManager.getCurrentInstalledVersionCode(context) }
    val cloudUpdateAvailable = latestRelease != null && latestRelease.versionCode > installedVersionCode &&
        latestRelease.downloadUrl.isNotBlank()

    val isAdbReady = remember {
        try { ShellEngine.getInstance(context).state.value.isAdbReady } catch (_: Throwable) { false }
    }
    val isFolderLink = remember(urlInput) {
        InAppApkUpdater.isDriveFolderLink(urlInput) || InAppApkUpdater.isGitHubReleasesPageLink(urlInput)
    }

    // Bộ chọn tệp APK đã tải sẵn trong máy để cài ngay (hỗ trợ cài siêu tốc qua ADB bỏ chặn Honor!)
    val localApkPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                isInstalling = true
                errorText = null
                statusText = "⏳ Đang xử lý tệp APK vừa chọn..."
                val res = WlanFastApkInstaller.installApkFromUri(context, uri) { msg ->
                    statusText = msg
                }
                isInstalling = false
                when (res) {
                    is WlanFastApkInstaller.InstallResult.Success -> {
                        statusText = "✅ Đã cài đặt thành công ${res.appLabel}!"
                        Toast.makeText(context, tr("✅ Cập nhật thành công!"), Toast.LENGTH_LONG).show()
                    }
                    is WlanFastApkInstaller.InstallResult.FallbackStandardInstall -> {
                        statusText = res.message
                    }
                    is WlanFastApkInstaller.InstallResult.Error -> {
                        errorText = res.error
                    }
                }
            }
        }
    }

    fun triggerInstall(info: InAppApkUpdater.DownloadedApkInfo, preferAdb: Boolean) {
        if (cloudReleaseOnly && (isCheckingCloudRelease || !cloudUpdateAvailable ||
                info.versionCode != latestRelease?.versionCode ||
                info.packageName != context.packageName)) {
            errorText = "Tệp APK không khớp bản cập nhật Admin đã phát hành. Hãy tải lại."
            return
        }
        scope.launch {
            isInstalling = true
            errorText = null
            needsInstallPermission = false
            statusText = if (preferAdb && isAdbReady) {
                tr("⚡ Đang cài đặt cập nhật siêu tốc qua WLAN ADB (vượt chặn Honor)...")
            } else {
                tr("📲 Đang mở trình cài đặt hệ thống...")
            }
            val res = try {
                InAppApkUpdater.installDownloadedApk(
                    context = context,
                    apkFile = info.file,
                    preferAdbIfReady = preferAdb
                )
            } catch (e: CancellationException) {
                isInstalling = false
                throw e
            } catch (e: Throwable) {
                InAppApkUpdater.InstallActionResult.Error(tr("Lỗi khi cài đặt: ${e.message ?: "Không xác định"}"))
            }
            isInstalling = false
            when (res) {
                is InAppApkUpdater.InstallActionResult.InstalledViaAdb -> {
                    statusText = res.message
                    Toast.makeText(context, res.message, Toast.LENGTH_LONG).show()
                }
                is InAppApkUpdater.InstallActionResult.OpenedSystemInstaller -> {
                    statusText = res.message
                }
                is InAppApkUpdater.InstallActionResult.NeedsUnknownSourcesPermission -> {
                    needsInstallPermission = true
                    statusText = null
                    errorText = res.message
                }
                is InAppApkUpdater.InstallActionResult.Error -> {
                    statusText = null
                    errorText = res.message
                }
            }
        }
    }

    fun startDownloadNow() {
        if (cloudReleaseOnly && !cloudUpdateAvailable) return
        val target = if (cloudReleaseOnly) {
            LicenseManager.resolveGoogleDriveApkLink(context, latestRelease?.downloadUrl.orEmpty())
        } else {
            urlInput.trim()
        }
        if (target.isBlank()) {
            errorText = "Chưa có link tải bản cập nhật."
            return
        }
        downloadJob?.cancel()
        errorText = null
        needsInstallPermission = false
        statusText = "⬇️ Đang kết nối máy chủ tải bản cập nhật..."
        isDownloading = true
        progress = null

        downloadJob = scope.launch {
            val result = try {
                InAppApkUpdater.downloadApk(
                    context = context,
                    rawUrl = target,
                    onProgress = { p -> progress = p }
                )
            } catch (e: CancellationException) {
                isDownloading = false
                throw e
            } catch (e: Throwable) {
                InAppApkUpdater.DownloadResult.Error(tr("Lỗi tải bản cập nhật: ${e.message ?: "Không xác định"}"))
            }
            isDownloading = false
            when (result) {
                is InAppApkUpdater.DownloadResult.Success -> {
                    if (cloudReleaseOnly && (result.info.versionCode != latestRelease?.versionCode ||
                            result.info.versionCode <= installedVersionCode ||
                            result.info.packageName != context.packageName)) {
                        InAppApkUpdater.clearDownloadedApk(context)
                        downloadedApk = null
                        statusText = null
                        errorText = "APK tải về không khớp bản Admin đã phát hành hoặc không mới hơn bản đang cài."
                        return@launch
                    }
                    downloadedApk = result.info
                    val sizeMb = String.format(Locale.US, "%.1f MB", result.info.sizeBytes / (1024.0 * 1024.0))
                    statusText = "✅ Đã tải xong v${result.info.versionName} ($sizeMb). Đang tiến hành cài đặt..."
                    if (autoInstallOnDownloaded) {
                        triggerInstall(result.info, preferAdb = true)
                    }
                }
                is InAppApkUpdater.DownloadResult.FolderLinkOnly -> {
                    statusText = null
                    errorText = result.message
                }
                is InAppApkUpdater.DownloadResult.Error -> {
                    statusText = null
                    errorText = result.message
                }
            }
        }
    }

    // Kiểm tra xem có tệp APK khớp URL đã tải sẵn trong cache không + tự động tải & cài thẳng nếu được yêu cầu
    LaunchedEffect(if (cloudReleaseOnly) latestRelease?.releaseId else "manual") {
        if (cloudReleaseOnly && !cloudUpdateAvailable) {
            downloadedApk = null
            return@LaunchedEffect
        }
        val existing = withContext(Dispatchers.IO) {
            InAppApkUpdater.getExistingDownloadedApk(
                context,
                if (cloudReleaseOnly) latestRelease?.downloadUrl.orEmpty() else urlInput
            )
        }
        val usableExisting = existing?.takeIf {
            !cloudReleaseOnly || (it.versionCode == latestRelease?.versionCode &&
                it.versionCode > installedVersionCode && it.packageName == context.packageName)
        }
        downloadedApk = usableExisting
        if (autoStartDownload && InAppApkUpdater.isDirectDownloadableUrl(urlInput)) {
            if (usableExisting != null && autoInstallOnDownloaded) {
                triggerInstall(usableExisting, preferAdb = true)
            } else {
                startDownloadNow()
            }
        }
    }

    AlertDialog(
        onDismissRequest = {
            if (!isDownloading && !isInstalling) onDismiss()
        },
        containerColor = MagicSurfaceCard,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.SystemUpdate,
                        contentDescription = null,
                        tint = MagicCyanLight,
                        modifier = Modifier.size(22.dp)
                    )
                    Column {
                        Text(
                            text = if (cloudReleaseOnly) tr("Kiểm Tra Bản Cập Nhật") else tr("Cập Nhật Trong Ứng Dụng"),
                            color = TextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = tr("Bản đang cài: $APP_VERSION_NAME (build $installedVersionCode)") +
                                if (isAdbReady) " • ⚡ ADB Sẵn sàng" else "",
                            color = MagicEmeraldLight,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MagicSurfaceDark)
                        .border(1.dp, MagicBorder, RoundedCornerShape(8.dp))
                        .clickable {
                            downloadJob?.cancel()
                            onDismiss()
                        }
                        .testTag("close_in_app_update_dialog"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = tr("Đóng cập nhật"),
                        tint = TextPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        },
        text = {
            ScrollableDialogColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (cloudReleaseOnly) {
                    Text(
                        text = when {
                            isCheckingCloudRelease -> tr("Đang kiểm tra bản APK mới nhất từ Admin...")
                            !cloudCheckSucceeded -> tr("Chưa xác nhận được bản mới nhất qua mạng. Thông tin bên dưới là dữ liệu đã lưu trên máy.")
                            latestRelease == null -> tr("Admin chưa phát hành bản APK cập nhật.")
                            cloudUpdateAvailable -> tr("Có bản cập nhật mới trên Google Drive. Nhấn tải xuống, rồi xác nhận cài đặt khi APK đã tải xong.")
                            else -> tr("Bản của bạn đã mới nhất.")
                        },
                        color = if (cloudUpdateAvailable && !isCheckingCloudRelease) MagicEmeraldLight else TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        lineHeight = 18.sp
                    )
                    if (isCheckingCloudRelease) {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = MagicCyan)
                    }
                } else if (!autoStartDownload && !autoInstallOnDownloaded) {
                    Text(
                        text = tr("Bản hiện tại vẫn dùng bình thường. Chọn Tải Trong App nếu muốn cập nhật, hoặc Giữ bản hiện tại để tiếp tục dùng APK này."),
                        color = TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                }
                if (latestRelease != null && latestRelease.downloadUrl.isNotBlank()) {
                    val relSizeMb = if (latestRelease.sizeBytes > 0L) {
                        String.format(Locale.US, "%.1f MB", latestRelease.sizeBytes / (1024.0 * 1024.0))
                    } else ""
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(MagicEmerald.copy(alpha = 0.12f))
                            .border(1.dp, MagicEmerald.copy(alpha = 0.55f), RoundedCornerShape(10.dp))
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = tr("☁️ Bản APK Mới Nhất Từ Admin: v${latestRelease.versionName.ifBlank { "Mới" }} (build ${latestRelease.versionCode})"),
                            color = MagicEmeraldLight,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Black
                        )
                        val metaLine = listOfNotNull(
                            relSizeMb.takeIf { it.isNotBlank() }?.let { "📦 $it" },
                            latestRelease.hostLabel.takeIf { it.isNotBlank() }?.let { "⚡ $it" }
                        ).joinToString(" • ")
                        if (metaLine.isNotBlank()) {
                            Text(
                                text = metaLine,
                                color = MagicCyanLight,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        if (latestRelease.releaseNotes.isNotBlank()) {
                            Text(
                                text = latestRelease.releaseNotes,
                                color = TextPrimary,
                                fontSize = 11.sp,
                                lineHeight = 16.sp
                            )
                        }
                    }
                } else if (broadcastTitle.isNotBlank() || broadcastMessage.isNotBlank()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(MagicAmber.copy(alpha = 0.12f))
                            .border(1.dp, MagicAmber.copy(alpha = 0.55f), RoundedCornerShape(10.dp))
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        if (broadcastTitle.isNotBlank()) {
                            Text(
                                text = "🚀 $broadcastTitle",
                                color = MagicAmberLight,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        if (broadcastMessage.isNotBlank()) {
                            Text(
                                text = broadcastMessage,
                                color = TextPrimary,
                                fontSize = 11.sp,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }

                // Màn cập nhật thủ công hỗ trợ tệp Google Drive công khai hoặc link .apk từ GitHub.
                if (!cloudReleaseOnly) Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MagicSurfaceDark)
                        .border(1.dp, MagicBorder, RoundedCornerShape(10.dp))
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = when {
                                InAppApkUpdater.isGitHubReleasesPageLink(urlInput) -> tr("🐙 Nguồn: Trang GitHub Releases")
                                isFolderLink -> tr("📁 Nguồn: Thư mục Google Drive")
                                InAppApkUpdater.isGitHubApkFileLink(urlInput) -> tr("🐙 Nguồn: Tệp APK GitHub")
                                InAppApkUpdater.isGoogleDriveFileLink(urlInput) -> tr("☁️ Nguồn: Tệp Google Drive")
                                else -> tr("⚠️ Chỉ hỗ trợ link APK từ GitHub hoặc Google Drive")
                            },
                            color = when {
                                isFolderLink -> MagicAmberLight
                                InAppApkUpdater.isSupportedApkFileLink(urlInput) -> MagicCyanLight
                                else -> MagicRoseLight
                            },
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    OutlinedButton(
                        onClick = { showCustomUrlBox = !showCustomUrlBox },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 38.dp)
                            .testTag("in_app_update_custom_url_toggle"),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.7f))
                    ) {
                        Text(
                            text = if (showCustomUrlBox) tr("Ẩn phần nhập link APK") else tr("Dán link APK"),
                            color = MagicCyanLight,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Text(
                        text = urlInput.ifBlank { tr("Chưa có đường dẫn cập nhật") },
                        color = TextMuted,
                        fontSize = 9.8.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (showCustomUrlBox) {
                        OutlinedTextField(
                            value = urlInput,
                            onValueChange = { urlInput = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("in_app_update_url_input"),
                            label = { Text(tr("Link tệp APK (GitHub hoặc Google Drive)"), fontSize = 10.sp) },
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MagicCyan,
                                unfocusedBorderColor = MagicBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            )
                        )
                    }
                }

                // Thanh tiến trình tải trực tiếp trong app
                if (isDownloading) {
                    val p = progress
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(MagicCyan.copy(alpha = 0.1f))
                            .border(1.dp, MagicCyan.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val mbDone = (p?.downloadedBytes ?: 0L) / (1024.0 * 1024.0)
                        val mbTotal = (p?.totalBytes ?: -1L) / (1024.0 * 1024.0)
                        val pctLabel = if (p != null && p.percent >= 0) "${p.percent}%" else tr("Đang tải...")
                        val sizeLabel = if (p != null && p.totalBytes > 0L) {
                            String.format(Locale.US, "%.1f / %.1f MB", mbDone, mbTotal)
                        } else {
                            String.format(Locale.US, "%.1f MB", mbDone)
                        }
                        val speedLabel = if (p != null && p.speedKbps > 0) " • ${p.speedKbps} KB/s" else ""

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("⬇️ $pctLabel", color = MagicCyanLight, fontSize = 11.5.sp, fontWeight = FontWeight.Black)
                            Text("$sizeLabel$speedLabel", color = TextSecondary, fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold)
                        }
                        if (p != null && p.percent >= 0) {
                            LinearProgressIndicator(
                                progress = { (p.percent / 100f).coerceIn(0f, 1f) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(7.dp)
                                    .clip(RoundedCornerShape(4.dp)),
                                color = MagicEmerald,
                                trackColor = MagicSurfaceCard
                            )
                        } else {
                            LinearProgressIndicator(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(7.dp)
                                    .clip(RoundedCornerShape(4.dp)),
                                color = MagicCyan,
                                trackColor = MagicSurfaceCard
                            )
                        }
                    }
                }

                // Tệp APK đã tải xong sẵn sàng cài
                val readyApk = downloadedApk?.takeIf {
                    !cloudReleaseOnly || (cloudUpdateAvailable && !isCheckingCloudRelease)
                }
                if (readyApk != null && !isDownloading) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(MagicEmerald.copy(alpha = 0.13f))
                            .border(1.dp, MagicEmerald.copy(alpha = 0.55f), RoundedCornerShape(10.dp))
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MagicEmeraldLight, modifier = Modifier.size(16.dp))
                            Text(
                                text = tr("APK sẵn sàng: v${readyApk.versionName} (${String.format(Locale.US, "%.1f MB", readyApk.sizeBytes / (1024.0 * 1024.0))})"),
                                color = MagicEmeraldLight,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(IntrinsicSize.Min),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Button(
                                onClick = { triggerInstall(readyApk, preferAdb = true) },
                                enabled = !isInstalling,
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                                    .heightIn(min = 40.dp, max = 44.dp)
                                    .testTag("in_app_update_install_now_btn"),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MagicEmerald,
                                    contentColor = Color(0xFF020617)
                                )
                            ) {
                                Icon(
                                    imageVector = if (isAdbReady) Icons.Default.Bolt else Icons.Default.SystemUpdate,
                                    contentDescription = null,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isAdbReady) tr("Cài Siêu Tốc (ADB)") else tr("Cài Bản Mới Ngay"),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    maxLines = 1
                                )
                            }
                            OutlinedButton(
                                onClick = {
                                    InAppApkUpdater.clearDownloadedApk(context)
                                    downloadedApk = null
                                    statusText = "Đã xóa bản tải tạm."
                                },
                                enabled = !isInstalling,
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .heightIn(min = 40.dp, max = 44.dp),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                border = BorderStroke(1.dp, MagicBorder)
                            ) {
                                Text(tr("Xóa"), color = TextSecondary, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                if (!statusText.isNullOrBlank()) {
                    Text(
                        text = statusText.orEmpty(),
                        color = MagicCyanLight,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (!errorText.isNullOrBlank()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MagicRose.copy(alpha = 0.14f))
                            .border(1.dp, MagicRose.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "⚠️ ${errorText.orEmpty()}",
                            color = MagicRoseLight,
                            fontSize = 10.8.sp,
                            fontWeight = FontWeight.SemiBold,
                            lineHeight = 15.sp
                        )
                        if (needsInstallPermission) {
                            Button(
                                onClick = { InAppApkUpdater.openUnknownAppSourcesSettings(context) },
                                colors = ButtonDefaults.buttonColors(containerColor = MagicAmber, contentColor = Color(0xFF020617)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth().heightIn(min = 38.dp)
                            ) {
                                Text(tr("Mở Quyền Cài Đặt APK Cho MagicTune"), fontSize = 11.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }

                // Các tùy chọn bổ trợ: Chọn file APK đã tải sẵn / Mở link bằng trình duyệt
                if (!cloudReleaseOnly) Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(IntrinsicSize.Min),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            try {
                                localApkPickerLauncher.launch(arrayOf("application/vnd.android.package-archive", "*/*"))
                            } catch (_: Throwable) {
                                Toast.makeText(context, tr("Không thể mở bộ chọn tệp."), Toast.LENGTH_SHORT).show()
                            }
                        },
                        enabled = !isDownloading && !isInstalling,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .heightIn(min = 40.dp, max = 44.dp)
                            .testTag("in_app_update_pick_local_apk_btn"),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
                        border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.55f))
                    ) {
                        Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = MagicCyanLight, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(tr("Chọn APK Có Sẵn"), color = MagicCyanLight, fontSize = 10.2.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    }

                    OutlinedButton(
                        onClick = {
                            try {
                                val target = LicenseManager.resolveGoogleDriveApkLink(
                                    context,
                                    urlInput.trim().ifBlank { LicenseManager.getGoogleDriveUpdateLink(context) }
                                )
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(target)).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                context.startActivity(intent)
                            } catch (_: Throwable) {}
                        },
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .heightIn(min = 40.dp, max = 44.dp)
                            .testTag("in_app_update_open_browser_btn"),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
                        border = BorderStroke(1.dp, MagicBorder)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(tr("Mở Trình Duyệt"), color = TextSecondary, fontSize = 10.2.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    }
                }
            }
        },
        confirmButton = {
            if (isDownloading) {
                Button(
                    onClick = {
                        downloadJob?.cancel()
                        isDownloading = false
                        statusText = "Đã hủy tải xuống."
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MagicRose),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(tr("Hủy Tải"), color = Color.White, fontWeight = FontWeight.Black, fontSize = 12.sp)
                }
            } else if (cloudReleaseOnly && (isCheckingCloudRelease || !cloudUpdateAvailable)) {
                // Không có APK mới được xác nhận để cài đặt.
            } else if (!isFolderLink) {
                Button(
                    onClick = {
                        val ready = downloadedApk
                        if (cloudReleaseOnly && ready != null) triggerInstall(ready, preferAdb = true)
                        else startDownloadNow()
                    },
                    enabled = !isInstalling,
                    modifier = Modifier.testTag("in_app_update_download_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = MagicCyan, contentColor = Color(0xFF020617)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = when {
                            cloudReleaseOnly && downloadedApk != null -> tr("Cài đặt ngay")
                            cloudReleaseOnly -> tr("Cài đặt bản cập nhật")
                            downloadedApk != null -> tr("Tải Lại Bản Mới")
                            else -> tr("Tải Trong App")
                        },
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp
                    )
                }
            } else {
                Button(
                    onClick = {
                        try {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(urlInput.trim())).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                        } catch (_: Throwable) {}
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald, contentColor = Color(0xFF020617)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(tr("Mở Thư Mục Tải"), fontWeight = FontWeight.Black, fontSize = 12.sp)
                }
            }
        },
        dismissButton = {
            TextButton(
                onClick = {
                    downloadJob?.cancel()
                    onDismiss()
                }
            ) {
                Text(
                    if (cloudReleaseOnly && !cloudUpdateAvailable) "Đóng" else "Giữ bản hiện tại",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    )
}
