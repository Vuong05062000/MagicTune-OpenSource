package com.example.core.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.Log
import com.example.core.license.LicenseManager
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import org.json.JSONArray
import org.json.JSONObject

/**
 * HybridGeminiVisionEngine:
 * Tận dụng các mô hình Gemini miễn phí hỗ trợ đa phương thức (xem ảnh + văn bản) trong phạm vi 100% Free Tier:
 * 1. Xoay vòng tự động qua Kho Key Gemini Miễn Phí (`AIza...` của cá nhân người dùng hoặc Kho Key Admin)
 *    với giới hạn nghiêm ngặt trong phạm vi miễn phí (<= 12 RPM, <= 1,400 RPD mỗi key) qua `gemini-2.5-flash`, `gemini-2.5-flash-lite`, `gemini-2.0-flash`.
 * 2. Kết hợp với Firebase AI Logic miễn phí (`gemini-3.8-flash`, `gemini-3.5-flash-lite` - Billing not required) cho tài khoản Pro/Admin.
 */
object HybridGeminiVisionEngine {

    private const val TAG = "HybridGeminiVision"

    data class GeminiStreamResult(
        val text: String,
        val modelUsed: String = "",
        val errorDiagnostic: String? = null
    )

    private fun decodeSafeBitmapFromBase64(base64Jpeg: String, maxDim: Int = 1024): Bitmap? {
        if (base64Jpeg.isBlank()) return null
        return try {
            val cleanB64 = base64Jpeg
                .substringAfter("base64,", base64Jpeg)
                .trim()
            val bytes = Base64.decode(cleanB64, Base64.DEFAULT)
            if (bytes.isEmpty()) return null

            val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, boundsOpts)
            val srcW = boundsOpts.outWidth
            val srcH = boundsOpts.outHeight
            if (srcW <= 0 || srcH <= 0) return null

            var sampleSize = 1
            while ((srcW / sampleSize) > maxDim * 2 || (srcH / sampleSize) > maxDim * 2) {
                sampleSize *= 2
            }

            val decodeOpts = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, decodeOpts) ?: return null
            val maxSide = maxOf(decoded.width, decoded.height)
            if (maxSide > maxDim) {
                val ratio = maxDim.toFloat() / maxSide.toFloat()
                val targetW = (decoded.width * ratio).toInt().coerceAtLeast(1)
                val targetH = (decoded.height * ratio).toInt().coerceAtLeast(1)
                val scaled = Bitmap.createScaledBitmap(decoded, targetW, targetH, true)
                if (scaled != decoded) {
                    decoded.recycle()
                }
                scaled
            } else {
                decoded
            }
        } catch (e: Throwable) {
            Log.w(TAG, "decodeSafeBitmapFromBase64 failed: ${e.message}")
            null
        }
    }

    private fun cleanOutputText(raw: String): String {
        return raw
            .replace(Regex("<think>[\\s\\S]*?</think>"), "")
            .replace("**", "")
            .trim()
    }

    /**
     * Gọi Gemini trực tiếp qua Kho API Key `AIza...` (Cá nhân hoặc Admin Pool) với chế độ SSE Streaming:
     * - Kiểm tra hạn mức miễn phí (<= 12 RPM, <= 1,400 RPD) trước khi gọi.
     * - Tự động đổi sang Key `AIza...` tiếp theo ngay lập tức nếu Key hiện tại hết hạn mức miễn phí (429 / Quota).
     */
    private fun streamViaGeminiApiKeyPool(
        context: Context,
        apiKeys: List<String>,
        systemInstruction: String,
        userPrompt: String,
        imageBase64: String?,
        temperature: Float,
        maxOutputTokens: Int,
        conversationHistory: List<Pair<String, String>>,
        sanitizePreview: (String) -> String,
        shouldAbort: (() -> Boolean)?,
        onPartialText: ((String) -> Unit)?
    ): GeminiStreamResult {
        val restModels = listOf(
            "gemini-2.5-flash",
            "gemini-2.5-flash-lite",
            "gemini-2.0-flash"
        )
        val cleanB64 = imageBase64?.substringAfter("base64,", imageBase64)?.trim().orEmpty()
        val historyPrefix = if (conversationHistory.isNotEmpty()) {
            buildString {
                append("Ngữ cảnh hội thoại gần đây:\n")
                for ((r, msg) in conversationHistory.takeLast(6)) {
                    val who = if (r == "assistant" || r == "model") "MagicLive" else "Người dùng"
                    append("- ").append(who).append(": ").append(msg.take(260)).append("\n")
                }
                append("\n")
            }
        } else ""

        var lastDiagnostic: String? = null

        for (apiKey in apiKeys) {
            if (shouldAbort?.invoke() == true) {
                return GeminiStreamResult(text = "", errorDiagnostic = "aborted")
            }
            // Chỉ tiêu dùng trong phạm vi miễn phí của Key này; nếu chạm trần miễn phí thì tự động nhảy sang Key kế tiếp
            if (!LicenseManager.tryConsumeAiKeyFreeTierQuota(context, apiKey, isGemini = true)) {
                lastDiagnostic = "Key ${apiKey.take(8)}... reached free-tier cap, rotating"
                continue
            }

            var rotateToNextKey = false
            for (modelName in restModels) {
                if (shouldAbort?.invoke() == true || rotateToNextKey) break
                var conn: HttpURLConnection? = null
                try {
                    val streamUrl = URL("https://generativelanguage.googleapis.com/v1beta/models/$modelName:streamGenerateContent?alt=sse&key=$apiKey")
                    conn = (streamUrl.openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        doOutput = true
                        doInput = true
                        connectTimeout = 7000
                        readTimeout = 22000
                        setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                        setRequestProperty("Accept", "text/event-stream")
                    }

                    val parts = JSONArray()
                    val combinedPrompt = buildString {
                        if (systemInstruction.isNotBlank()) {
                            append(systemInstruction.trim()).append("\n\n")
                        }
                        if (historyPrefix.isNotBlank()) {
                            append(historyPrefix)
                        }
                        append(userPrompt.trim().ifEmpty { "Quan sát bức ảnh này và giải thích tự nhiên bằng Tiếng Việt." })
                    }
                    parts.put(JSONObject().put("text", combinedPrompt))
                    if (cleanB64.isNotEmpty()) {
                        parts.put(
                            JSONObject().put(
                                "inlineData",
                                JSONObject()
                                    .put("mimeType", "image/jpeg")
                                    .put("data", cleanB64)
                            )
                        )
                    }

                    val payload = JSONObject().apply {
                        put("contents", JSONArray().put(JSONObject().put("parts", parts)))
                        put(
                            "generationConfig",
                            JSONObject()
                                .put("temperature", temperature.toDouble())
                                .put("maxOutputTokens", maxOutputTokens.coerceIn(64, 4096))
                        )
                    }

                    conn.outputStream.use { os ->
                        os.write(payload.toString().toByteArray(Charsets.UTF_8))
                    }

                    val code = conn.responseCode
                    if (code !in 200..299) {
                        val errBody = try {
                            conn.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText().take(220) }.orEmpty()
                        } catch (_: Throwable) { "" }
                        lastDiagnostic = "HTTP $code ($modelName): ${errBody.take(120)}"
                        if (code == 401 ||
                            errBody.contains("API_KEY_INVALID", ignoreCase = true) ||
                            errBody.contains("API key not valid", ignoreCase = true)
                        ) {
                            LicenseManager.markAiKeyInvalidOrDead(context, apiKey, isGemini = true)
                            rotateToNextKey = true
                        } else if (code == 429 || code == 403 ||
                            errBody.contains("RESOURCE_EXHAUSTED", ignoreCase = true) ||
                            errBody.contains("quota", ignoreCase = true)
                        ) {
                            val isDaily = errBody.contains("per_day", ignoreCase = true) ||
                                errBody.contains("Daily", ignoreCase = true)
                            LicenseManager.markMagicLiveApiKeyCooldown(
                                apiKey,
                                cooldownMs = if (isDaily) 6 * 3600_000L else 75_000L
                            )
                            rotateToNextKey = true
                        }
                        continue
                    }

                    val accumulated = StringBuilder()
                    var lastEmitMs = 0L
                    BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8), 2048).use { reader ->
                        while (shouldAbort?.invoke() != true) {
                            val line = reader.readLine() ?: break
                            val trimmed = line.trim()
                            if (!trimmed.startsWith("data:")) continue
                            val jsonStr = trimmed.removePrefix("data:").trim()
                            if (jsonStr.isEmpty() || jsonStr == "[DONE]") continue
                            try {
                                val chunkObj = JSONObject(jsonStr)
                                val textParts = chunkObj.optJSONArray("candidates")
                                    ?.optJSONObject(0)
                                    ?.optJSONObject("content")
                                    ?.optJSONArray("parts")
                                if (textParts != null) {
                                    for (i in 0 until textParts.length()) {
                                        val delta = textParts.optJSONObject(i)?.optString("text", "").orEmpty()
                                        if (delta.isNotEmpty()) {
                                            accumulated.append(delta)
                                        }
                                    }
                                    if (onPartialText != null && accumulated.isNotEmpty()) {
                                        val now = System.currentTimeMillis()
                                        if (lastEmitMs == 0L || (now - lastEmitMs) >= 120L) {
                                            val preview = sanitizePreview(accumulated.toString())
                                            if (preview.isNotEmpty()) {
                                                lastEmitMs = now
                                                onPartialText(preview)
                                            }
                                        }
                                    }
                                }
                            } catch (_: Throwable) {}
                        }
                    }

                    val finalClean = cleanOutputText(accumulated.toString())
                    if (finalClean.isNotBlank()) {
                        if (onPartialText != null) {
                            val finalPreview = sanitizePreview(finalClean)
                            if (finalPreview.isNotEmpty()) {
                                onPartialText(finalPreview)
                            }
                        }
                        return GeminiStreamResult(text = finalClean, modelUsed = modelName)
                    }
                } catch (e: Throwable) {
                    lastDiagnostic = "${e.javaClass.simpleName}: ${e.message?.take(90)}"
                } finally {
                    try { conn?.disconnect() } catch (_: Throwable) {}
                }
            }
        }

        return GeminiStreamResult(text = "", errorDiagnostic = lastDiagnostic)
    }

    /**
     * Gọi Gemini Streaming đa phương thức (hỗ trợ cả Hình ảnh + Văn bản hoặc Thuần văn bản):
     * 1. Tự động ưu tiên xoay vòng qua danh sách Key Gemini miễn phí (`AIza...`) trong phạm vi Free Tier.
     * 2. Nếu là tài khoản PRO hoặc ADMIN, hỗ trợ thêm kênh Firebase AI Logic miễn phí (`gemini-3.8-flash` -> `gemini-3.5-flash-lite`).
     */
    suspend fun streamGeminiResponse(
        context: Context,
        systemInstruction: String,
        userPrompt: String,
        imageBase64: String? = null,
        temperature: Float = 0.25f,
        maxOutputTokens: Int = 1800,
        conversationHistory: List<Pair<String, String>> = emptyList(),
        modelCandidates: List<String> = listOf("gemini-3.8-flash", "gemini-3.5-flash-lite"),
        sanitizePreview: (String) -> String = { cleanOutputText(it) },
        shouldAbort: (() -> Boolean)? = null,
        onPartialText: ((String) -> Unit)? = null
    ): GeminiStreamResult {
        if (com.example.core.perf.CpuHeatGuard.isHot()) return GeminiStreamResult("", errorDiagnostic = "thermal_pause")
        if (shouldAbort?.invoke() == true) {
            return GeminiStreamResult(text = "", errorDiagnostic = "aborted")
        }

        PersonalAi.reply(context, systemInstruction, userPrompt, imageBase64, conversationHistory, maxOutputTokens)?.let {
            onPartialText?.invoke(it)
            return GeminiStreamResult(text = it, modelUsed = "personal")
        }

        // 1. ƯU TIÊN XOAY VÒNG KHO KEY GEMINI MIỄN PHÍ (`AIza...`) CỦA CÁ NHÂN HOẶC KHO ADMIN
        val availableGeminiKeys = LicenseManager.getAllMagicLiveApiKeys(context, forMagicLiveFeature = true)
            .filter { it.startsWith("AIza") && it.length >= 16 }

        var poolError: String? = null
        if (availableGeminiKeys.isNotEmpty()) {
            val poolResult = streamViaGeminiApiKeyPool(
                context = context,
                apiKeys = availableGeminiKeys,
                systemInstruction = systemInstruction,
                userPrompt = userPrompt,
                imageBase64 = imageBase64,
                temperature = temperature,
                maxOutputTokens = maxOutputTokens,
                conversationHistory = conversationHistory,
                sanitizePreview = sanitizePreview,
                shouldAbort = shouldAbort,
                onPartialText = onPartialText
            )
            if (poolResult.text.isNotBlank()) {
                return poolResult
            }
            poolError = poolResult.errorDiagnostic
        }

        return GeminiStreamResult(
            text = "",
            errorDiagnostic = poolError ?: "Vui lòng thêm API Key Gemini (AIza...) cá nhân tại tab '12. API Cá Nhân'"
        )
    }
}
