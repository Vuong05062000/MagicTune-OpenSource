package com.example.ui.theme

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

object ThemePreferences {
    private const val PREFS_NAME = "magictune_theme_prefs"
    private const val KEY_IVORY_THEME = "ivory_theme_enabled"

    var isIvoryTheme by mutableStateOf(false)
        private set

    fun init(context: Context) {
        try {
            val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            isIvoryTheme = prefs.getBoolean(KEY_IVORY_THEME, false)
        } catch (_: Throwable) {}
    }

    fun toggle(context: Context) {
        val next = !isIvoryTheme
        isIvoryTheme = next
        try {
            context.applicationContext
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_IVORY_THEME, next)
                .apply()
        } catch (_: Throwable) {}
    }
}

val MagicDarkBackground: Color
    get() = if (ThemePreferences.isIvoryTheme) Color(0xFFF4EFE6) else Color(0xFF000000)

val MagicSurfaceDark: Color
    get() = if (ThemePreferences.isIvoryTheme) Color(0xFFEBE4D7) else Color(0xCC0B1120)

val MagicSurfaceCard: Color
    get() = if (ThemePreferences.isIvoryTheme) Color(0xFFFCF9F2) else Color(0x991E293B)

val MagicBorder: Color
    get() = if (ThemePreferences.isIvoryTheme) Color(0xFFD5CCB9) else Color(0x38FFFFFF)

val MagicBlue = Color(0xFF2563EB)
val MagicBlueLight: Color
    get() = if (ThemePreferences.isIvoryTheme) Color(0xFF1D4ED8) else Color(0xFF60A5FA)

val MagicCyan = Color(0xFF06B6D4)
val MagicCyanLight: Color
    get() = if (ThemePreferences.isIvoryTheme) Color(0xFF0369A1) else Color(0xFF67E8F9)

val MagicEmerald = Color(0xFF10B981)
val MagicEmeraldLight: Color
    get() = if (ThemePreferences.isIvoryTheme) Color(0xFF047857) else Color(0xFF34D399)

val MagicAmber = Color(0xFFF59E0B)
val MagicAmberLight: Color
    get() = if (ThemePreferences.isIvoryTheme) Color(0xFFB45309) else Color(0xFFFCD34D)

val MagicRose = Color(0xFFF43F5E)
val MagicRoseLight: Color
    get() = if (ThemePreferences.isIvoryTheme) Color(0xFFBE123C) else Color(0xFFFDA4AF)

val MagicPurple = Color(0xFF8B5CF6)
val MagicPurpleLight: Color
    get() = if (ThemePreferences.isIvoryTheme) Color(0xFF6D28D9) else Color(0xFFA78BFA)

val TextPrimary: Color
    get() = if (ThemePreferences.isIvoryTheme) Color(0xFF000000) else Color(0xFFFFFFFF)

val TextSecondary: Color
    get() = if (ThemePreferences.isIvoryTheme) Color(0xFF111827) else Color(0xFFE2E8F0)

val TextMuted: Color
    get() = if (ThemePreferences.isIvoryTheme) Color(0xFF334155) else Color(0xFF94A3B8)
