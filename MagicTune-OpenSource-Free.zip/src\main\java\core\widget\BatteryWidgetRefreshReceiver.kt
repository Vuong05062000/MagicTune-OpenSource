package com.example.core.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import com.example.core.widget.MagicTuneBatteryWidgetProvider.Companion.ACTION_WIDGET_FORCE_REFRESH

/**
 * Receiver nhận AlarmManager định kỳ và làm mới cả 2 widget pin (3×2 & 2×2).
 * Chỉ kích hoạt khi cắm sạc để tiết kiệm pin: AlarmManager sẽ được bật/tắt
 * dựa trên trạng thái POWER_CONNECTED / POWER_DISCONNECTED trong MainActivity.
 */
class BatteryWidgetRefreshReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        refreshAllBatteryWidgets(context)
    }

    companion object {
        const val ACTION_START_REFRESH_ALARM = "com.example.core.widget.ACTION_START_REFRESH_ALARM"
        const val ACTION_STOP_REFRESH_ALARM = "com.example.core.widget.ACTION_STOP_REFRESH_ALARM"
        const val REFRESH_INTERVAL_MS = 15_000L

        fun refreshAllBatteryWidgets(context: Context) {
            val appCtx = context.applicationContext ?: context
            try {
                appCtx.sendBroadcast(
                    Intent(ACTION_WIDGET_FORCE_REFRESH).setPackage(appCtx.packageName)
                )
            } catch (_: Throwable) {}
            try {
                appCtx.sendBroadcast(
                    Intent("com.example.core.widget.ACTION_SIMPLE_BATTERY_REFRESH")
                        .setPackage(appCtx.packageName)
                )
            } catch (_: Throwable) {}
        }

        fun startRefreshAlarm(context: Context) {
            val appCtx = context.applicationContext ?: context
            val am = appCtx.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
            val pi = PendingIntent.getBroadcast(
                appCtx, 0xBA7701,
                Intent(ACTION_START_REFRESH_ALARM).setPackage(appCtx.packageName),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            am.setInexactRepeating(
                AlarmManager.ELAPSED_REALTIME_WAKEUP,
                SystemClock.elapsedRealtime() + REFRESH_INTERVAL_MS,
                REFRESH_INTERVAL_MS,
                pi
            )
        }

        fun stopRefreshAlarm(context: Context) {
            val appCtx = context.applicationContext ?: context
            val am = appCtx.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
            val pi = PendingIntent.getBroadcast(
                appCtx, 0xBA7701,
                Intent(ACTION_START_REFRESH_ALARM).setPackage(appCtx.packageName),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            am.cancel(pi)
        }
    }
}
