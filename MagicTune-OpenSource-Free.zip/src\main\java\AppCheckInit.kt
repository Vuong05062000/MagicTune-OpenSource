package com.example.core.ai

import android.content.Context
import android.content.Intent

/**
 * Phiên bản mã nguồn mở miễn phí 100% — đã gỡ bỏ Firebase App Check.
 */
fun configureAppCheck(context: Context, intent: Intent?) {
    // No-op: Không sử dụng Firebase App Check trong bản hoàn toàn miễn phí.
}

fun ensureAppCheckReadyForOverlay(context: Context) {
    // No-op
}
