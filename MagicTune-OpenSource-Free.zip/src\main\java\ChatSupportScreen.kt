package com.example.ui.components
import com.example.core.i18n.AppLanguageManager.tr
import com.example.ui.theme.TextPrimary

import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.ai.HybridGeminiVisionEngine
import com.example.core.ai.PersonalAi
import com.example.core.license.LicenseManager
import com.example.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: String, // "user" | "support"
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Composable
fun ChatSupportScreen(
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    BackHandler { onNavigateBack() }

    var inputMessage by remember { mutableStateOf("") }
    var isAiGenerating by remember { mutableStateOf(false) }

    val messagesList = remember {
        mutableStateListOf(
            ChatMessage(
                sender = "support",
                text = tr("Xin chào! Tôi là Trợ lý hướng dẫn sử dụng **MagicTune ${com.example.data.APP_VERSION_NAME}** (Bản miễn phí 100%, không cần đăng nhập).\n\n") +
                    tr("• Bạn có thể hỏi về cách kết nối WLAN ADB 6 số, sửa trễ thông báo Zalo/Facebook/Gmail, mở khóa pin 97%, dịch cuộn Taobao/1688, MagicLive AI, máy in nhiệt K80 hoặc cách gắn API Key cá nhân miễn phí tại tab **12. API Cá Nhân**.")
            )
        )
    }

    LaunchedEffect(messagesList.size) {
        if (messagesList.isNotEmpty()) {
            listState.animateScrollToItem(messagesList.lastIndex)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MagicDarkBackground)
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            color = MagicSurfaceCard,
            border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.35f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(onClick = onNavigateBack, modifier = Modifier.size(34.dp)) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = tr("Quay lại"),
                        tint = TextPrimary
                    )
                }
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(MagicCyan.copy(alpha = 0.16f))
                        .border(1.dp, MagicCyan.copy(alpha = 0.45f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.SupportAgent,
                        contentDescription = null,
                        tint = MagicCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = tr("Trợ Lý Hướng Dẫn MagicTune AI"),
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Text(
                        text = tr("Miễn phí 100% • Trực tiếp qua Key AI cá nhân"),
                        color = MagicEmeraldLight,
                        fontSize = 10.sp
                    )
                }
            }
        }

        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messagesList, key = { it.id }) { msg ->
                val isUser = msg.sender == "user"
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                ) {
                    Surface(
                        modifier = Modifier.widthIn(max = 320.dp),
                        shape = RoundedCornerShape(14.dp),
                        color = if (isUser) MagicCyan.copy(alpha = 0.18f) else MagicSurfaceDark,
                        border = BorderStroke(
                            1.dp,
                            if (isUser) MagicCyan.copy(alpha = 0.4f) else TextPrimary.copy(alpha = 0.1f)
                        )
                    ) {
                        Text(
                            text = msg.text.replace("**", ""),
                            color = TextPrimary,
                            fontSize = 12.sp,
                            lineHeight = 17.sp,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            }
        }

        if (isAiGenerating) {
            LinearProgressIndicator(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp),
                color = MagicCyan
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = inputMessage,
                onValueChange = { inputMessage = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text(tr("Hỏi cách dùng tính năng MagicTune..."), fontSize = 12.sp) },
                singleLine = false,
                maxLines = 3,
                shape = RoundedCornerShape(14.dp)
            )
            IconButton(
                enabled = !isAiGenerating && inputMessage.isNotBlank(),
                onClick = {
                    val q = inputMessage.trim()
                    if (q.isBlank()) return@IconButton
                    inputMessage = ""
                    messagesList.add(ChatMessage(sender = "user", text = q))
                    isAiGenerating = true
                    coroutineScope.launch {
                        val reply = generateFreeSupportReply(context, q)
                        messagesList.add(ChatMessage(sender = "support", text = reply))
                        isAiGenerating = false
                    }
                },
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(MagicCyan)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = tr("Gửi"),
                    tint = Color(0xFF020617)
                )
            }
        }
    }
}

private suspend fun generateFreeSupportReply(context: Context, userQuery: String): String =
    withContext(Dispatchers.IO) {
        val sysPrompt = """
            Bạn là Trợ lý AI hướng dẫn sử dụng MagicTune Tool (Phiên bản Mã Nguồn Mở Miễn Phí 100%, không cần đăng nhập).
            Trả lời ngắn gọn, thân thiện bằng Tiếng Việt dựa trên các tab thực tế của ứng dụng:
            - Tab 1 Thiết Lập: Kiểm tra quyền và AI Pin.
            - Tab 2 Thời Tiết / Tab 3 Thông Báo: Sửa trễ thông báo Zalo, Facebook, Gmail trên Honor MagicOS.
            - Tab 4 Tối Ưu & AI: Bàn phím Telex, MagicLive, Khoanh tròn hỏi AI, Dịch cuộn, Mở khóa pin.
            - Tab 5 Kết Nối: Kết nối WLAN ADB 6 số & Shizuku.
            - Tab 6 Dọn App & Tab 7 Pin Ngầm: Đóng băng app xả pin nền.
            - Tab 12 API Cá Nhân: Dán khóa Gemini (AIza...) hoặc Groq (gsk_...) miễn phí để dùng mọi tính năng AI.
            - Tab 13 Cài Đặt: Đổi tên app, phiên bản, cỡ chữ Header, tỉ lệ giao diện 80-100%, link nút MXH & link cập nhật APK.
        """.trimIndent()

        try {
            PersonalAi.reply(
                context = context,
                system = sysPrompt,
                prompt = userQuery,
                image = null,
                history = emptyList(),
                maxTokens = 700
            )?.takeIf { it.isNotBlank() }?.let { return@withContext it }

            val groqKey = LicenseManager.getLoadBalancedGroqApiKey(context)
            if (groqKey.isNotBlank()) {
                var conn: HttpURLConnection? = null
                try {
                    conn = (URL("https://api.groq.com/openai/v1/chat/completions").openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        doOutput = true
                        connectTimeout = 5000
                        readTimeout = 8000
                        setRequestProperty("Authorization", "Bearer $groqKey")
                        setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                    }
                    val body = org.json.JSONObject().apply {
                        put("model", "llama-3.3-70b-versatile")
                        put(
                            "messages",
                            org.json.JSONArray()
                                .put(org.json.JSONObject().put("role", "system").put("content", sysPrompt))
                                .put(org.json.JSONObject().put("role", "user").put("content", userQuery))
                        )
                        put("temperature", 0.35)
                        put("max_tokens", 700)
                    }
                    conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                    if (conn.responseCode in 200..299) {
                        val txt = conn.inputStream.bufferedReader().use { it.readText() }
                        val parsed = org.json.JSONObject(txt)
                            .optJSONArray("choices")?.optJSONObject(0)
                            ?.optJSONObject("message")?.optString("content", "").orEmpty().trim()
                        if (parsed.isNotBlank()) return@withContext parsed
                    }
                } catch (_: Throwable) {
                } finally {
                    try { conn?.disconnect() } catch (_: Throwable) {}
                }
            }

            val gemRes = HybridGeminiVisionEngine.streamGeminiResponse(
                context = context,
                systemInstruction = sysPrompt,
                userPrompt = userQuery,
                maxOutputTokens = 700
            )
            if (gemRes.text.isNotBlank()) return@withContext gemRes.text
        } catch (_: Throwable) {}

        val q = userQuery.lowercase()
        when {
            q.contains("thông báo") || q.contains("zalo") || q.contains("facebook") ->
                tr("Để sửa trễ thông báo trên Honor MagicOS, bạn hãy mở tab 3. Thông Báo và bấm nút tối ưu thông báo toàn diện, hoặc kết nối WLAN ADB tại tab 5. Kết Nối để ứng dụng cấp đầy đủ AppOps và tắt hạn chế nền PowerGenius.")
            q.contains("shizuku") || q.contains("adb") || q.contains("wlan") || q.contains("6 số") ->
                tr("Bạn mở tab 5. Kết Nối để ghép đôi Direct WLAN ADB bằng mã 6 số ngay trong thông báo mà không cần máy tính hay cáp USB.")
            q.contains("api") || q.contains("key") || q.contains("ai") || q.contains("gemini") || q.contains("groq") ->
                tr("Mở tab 12. API Cá Nhân để dán Gemini API Key (AIza...) hoặc Groq API Key (gsk_...) miễn phí của bạn, chọn model ưa thích và sử dụng không giới hạn.")
            else ->
                tr("Phiên bản này hoàn toàn miễn phí 100% mọi tính năng và không cần đăng nhập. Để AI trả lời chi tiết hơn mọi câu hỏi kỹ thuật, bạn có thể thêm 1 Gemini/Groq API Key miễn phí trong tab 12. API Cá Nhân.")
        }
    }
