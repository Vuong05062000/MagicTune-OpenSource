package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.VerifiedUser
import com.example.core.installer.InAppApkUpdater
import com.example.core.license.LicenseManager
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import com.example.R
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.shell.ShellEngineState
import com.example.core.shell.ShellMode
import com.example.data.APP_VERSION_NAME
import com.example.data.DeviceInfo
import com.example.ui.MainTab
import com.example.ui.theme.MagicAmber
import com.example.ui.theme.MagicBlue
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicCyanLight
import com.example.ui.theme.MagicDarkBackground
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicRose
import com.example.ui.theme.MagicRoseLight
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.MagicSurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

import com.example.core.auth.FirebaseAuthManager

import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.TextButton
import androidx.compose.material3.IconButton
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LightMode
import com.example.ui.theme.ThemePreferences
import kotlin.math.roundToInt

@Composable
fun HeaderSection(
    deviceInfo: DeviceInfo = DeviceInfo(),
    shellState: ShellEngineState,
    currentTab: MainTab,
    onTabSelected: (MainTab) -> Unit,
    onOpenRevertModal: () -> Unit,
    onOpenWlanDialog: () -> Unit,
    onDisconnectWlan: () -> Unit = {},
    onRequestShizukuPermission: () -> Unit,
    onOpenShizukuTab: () -> Unit = {},
    onOpenYouTube: () -> Unit = {},
    onOpenPermissionDialog: () -> Unit = {},
    isPermissionFullyGranted: Boolean = true,
    globalSearchQuery: String = "",
    onGlobalSearchChange: (String) -> Unit = {},
    onOpenTerminal: () -> Unit = {},
    globalSearchFocusTick: Int = 0,
    onOpenChatSupport: () -> Unit = {}
) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val scrollState = rememberScrollState()
    val searchFocusRequester = remember { FocusRequester() }

    androidx.compose.runtime.LaunchedEffect(globalSearchFocusTick) {
        if (globalSearchFocusTick > 0) {
            kotlinx.coroutines.delay(120)
            try {
                searchFocusRequester.requestFocus()
                keyboardController?.show()
            } catch (_: Throwable) {}
        }
    }

    val proStateVersion by LicenseManager.proStateVersionFlow.collectAsStateWithLifecycle()
    val isProFlowState by LicenseManager.isProFlow.collectAsStateWithLifecycle()
    val authSession by FirebaseAuthManager.authSessionFlow.collectAsStateWithLifecycle()
    var liveFirebaseLoggedIn by remember(authSession) {
        mutableStateOf(authSession.isLoggedIn)
    }
    val isLoggedInSession = authSession.isLoggedIn || liveFirebaseLoggedIn
    var isRealAdmin by remember(authSession) {
        mutableStateOf(authSession.isAdmin)
    }
    var isSimulateFree by remember { mutableStateOf(false) }
    val isAdmin = !isSimulateFree && isRealAdmin
    var isPro by remember(isProFlowState) { mutableStateOf(isProFlowState) }
    var isAccountPro by remember { mutableStateOf(false) }
    var headerAppName by remember { mutableStateOf("Magictune_Tool") }
    var headerAppVer by remember { mutableStateOf(APP_VERSION_NAME) }
    var headerAppFontSize by remember { mutableStateOf(14f) }
    var isShizukuDisabled by remember { mutableStateOf(false) }
    var showFbHeaderIcon by remember { mutableStateOf(true) }
    var showYtHeaderIcon by remember { mutableStateOf(true) }
    val globalBroadcast by LicenseManager.globalBroadcastFlow.collectAsStateWithLifecycle()
    val latestApkRelease by LicenseManager.latestApkReleaseFlow.collectAsStateWithLifecycle()

    val coroutineScope = androidx.compose.runtime.rememberCoroutineScope()
    var isExportingApk by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    var showInAppUpdateDialog by remember { mutableStateOf(false) }
    var showCloudUpdateDialog by remember { mutableStateOf(false) }
    var isCheckingCloudUpdate by remember { mutableStateOf(false) }
    var showDownloadConfirmDialog by remember { mutableStateOf(false) }
    var cloudCheckSucceeded by remember { mutableStateOf(false) }
    var cloudUpdateRequestId by remember { mutableStateOf(0) }
    var inAppUpdateUrl by remember { mutableStateOf("") }
    var inAppUpdateAutoStart by remember { mutableStateOf(false) }
    var inAppUpdateAutoInstall by remember { mutableStateOf(true) }
    var showSafetyPrivacyDialog by remember { mutableStateOf(false) }

    androidx.compose.runtime.LaunchedEffect(proStateVersion, isProFlowState, authSession) {
        val loaded = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            val syncedAuth = FirebaseAuthManager.refreshAuthSessionNow(context)
            val hasUser = syncedAuth.isLoggedIn || FirebaseAuthManager.getCurrentUser() != null
            val simFree = LicenseManager.isAdminSimulateFreeMode(context)
            val realAdm = syncedAuth.isAdmin || FirebaseAuthManager.isCurrentAdmin(context, null) || LicenseManager.isCurrentUserAdmin(context)
            val pro = !simFree && LicenseManager.isProActivated(context)
            val accPro = !simFree && LicenseManager.isAccountProActivated(context)
            val appName = LicenseManager.getAppName(context)
            val appVer = LicenseManager.getAppVersionLabel(context)
            val appFontSize = LicenseManager.getAppNameFontSizeSp(context)
            val shizukuOff = LicenseManager.isShizukuConnectionDisabled(context)
            val showFb = LicenseManager.isFacebookHeaderIconVisible(context)
            val showYt = LicenseManager.isYouTubeHeaderIconVisible(context)
            arrayOf<Any?>(simFree, realAdm, pro, accPro, appName, appVer, appFontSize, shizukuOff, showFb, showYt, hasUser)
        }
        isSimulateFree = loaded[0] as Boolean
        isRealAdmin = loaded[1] as Boolean
        isPro = loaded[2] as Boolean
        isAccountPro = loaded[3] as Boolean
        headerAppName = loaded[4] as String
        headerAppVer = loaded[5] as String
        headerAppFontSize = loaded[6] as Float
        isShizukuDisabled = loaded[7] as Boolean
        showFbHeaderIcon = loaded[8] as Boolean
        showYtHeaderIcon = loaded[9] as Boolean
        liveFirebaseLoggedIn = loaded[10] as Boolean
    }

    androidx.compose.runtime.DisposableEffect(Unit) {
        val receiver = object : android.content.BroadcastReceiver() {
            override fun onReceive(ctx: android.content.Context?, intent: Intent?) {
                val c = ctx ?: return
                coroutineScope.launch {
                    val loaded = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                        val syncedAuth = FirebaseAuthManager.refreshAuthSessionNow(c)
                        val hasUser = syncedAuth.isLoggedIn || FirebaseAuthManager.getCurrentUser() != null
                        val simFree = LicenseManager.isAdminSimulateFreeMode(c)
                        val realAdm = syncedAuth.isAdmin || FirebaseAuthManager.isCurrentAdmin(c, null) || LicenseManager.isCurrentUserAdmin(c)
                        val pro = !simFree && LicenseManager.isProActivated(c)
                        val accPro = !simFree && LicenseManager.isAccountProActivated(c)
                        val appName = LicenseManager.getAppName(c)
                        val appVer = LicenseManager.getAppVersionLabel(c)
                        val appFontSize = LicenseManager.getAppNameFontSizeSp(c)
                        val shizukuOff = LicenseManager.isShizukuConnectionDisabled(c)
                        val showFb = LicenseManager.isFacebookHeaderIconVisible(c)
                        val showYt = LicenseManager.isYouTubeHeaderIconVisible(c)
                        arrayOf<Any?>(simFree, realAdm, pro, accPro, appName, appVer, appFontSize, shizukuOff, showFb, showYt, hasUser)
                    }
                    isSimulateFree = loaded[0] as Boolean
                    isRealAdmin = loaded[1] as Boolean
                    isPro = loaded[2] as Boolean
                    isAccountPro = loaded[3] as Boolean
                    headerAppName = loaded[4] as String
                    headerAppVer = loaded[5] as String
                    headerAppFontSize = loaded[6] as Float
                    isShizukuDisabled = loaded[7] as Boolean
                    showFbHeaderIcon = loaded[8] as Boolean
                    showYtHeaderIcon = loaded[9] as Boolean
                    liveFirebaseLoggedIn = loaded[10] as Boolean
                }
            }
        }
        val filter = android.content.IntentFilter().apply {
            addAction(LicenseManager.ACTION_PRO_ACTIVATED)
            addAction(LicenseManager.ACTION_CONFIG_UPDATED)
        }
        androidx.core.content.ContextCompat.registerReceiver(
            context,
            receiver,
            filter,
            androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED
        )
        onDispose {
            try { context.unregisterReceiver(receiver) } catch (_: Exception) {}
        }
    }

    var isBannerDismissed by remember(globalBroadcast?.id) { mutableStateOf(false) }
    var dismissedBroadcastId by remember(globalBroadcast?.id) { mutableStateOf("") }
    androidx.compose.runtime.LaunchedEffect(globalBroadcast?.id) {
        val bid = globalBroadcast?.id ?: return@LaunchedEffect
        val dismissed = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            LicenseManager.isBroadcastDismissed(context, bid)
        }
        isBannerDismissed = dismissed
        dismissedBroadcastId = if (dismissed) bid else ""
    }
    var forceShowBroadcastModal by remember { mutableStateOf(false) }

    val hasNewerCloudApk = remember(latestApkRelease) {
        LicenseManager.isUpdateAvailableForThisDevice(context, latestApkRelease)
    }

    // Mời người dùng cập nhật khi có release mới; người dùng có thể bỏ qua và tiếp tục dùng APK hiện tại.
    androidx.compose.runtime.LaunchedEffect(latestApkRelease?.releaseId, latestApkRelease?.autoUpdateEnabled) {
        val rel = latestApkRelease ?: return@LaunchedEffect
        if (!rel.autoUpdateEnabled) return@LaunchedEffect
        if (!InAppApkUpdater.isDirectDownloadableUrl(rel.downloadUrl)) return@LaunchedEffect
        val shouldAutoUpdate = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            LicenseManager.isUpdateAvailableForThisDevice(context, rel) &&
                !LicenseManager.isReleaseAutoPromptDismissed(context, rel.releaseId)
        }
        if (shouldAutoUpdate && !showInAppUpdateDialog && !showCloudUpdateDialog) {
            inAppUpdateUrl = rel.downloadUrl
            inAppUpdateAutoStart = false
            inAppUpdateAutoInstall = false
            showInAppUpdateDialog = true
        }
    }

    val activeBroadcast = globalBroadcast?.takeIf { it.isActive && (it.title.isNotBlank() || it.message.isNotBlank()) }
    val hasUpdateBroadcast = activeBroadcast?.type == "UPDATE"
    val hasUpdateAlert = hasUpdateBroadcast || hasNewerCloudApk
    val shouldShowBroadcastModal = !showInAppUpdateDialog && !showCloudUpdateDialog &&
        (forceShowBroadcastModal || (activeBroadcast != null && dismissedBroadcastId != activeBroadcast.id))

    if (showCloudUpdateDialog) {
        InAppUpdateDialog(
            initialUpdateUrl = latestApkRelease?.downloadUrl.orEmpty(),
            latestRelease = latestApkRelease,
            cloudReleaseOnly = true,
            isCheckingCloudRelease = isCheckingCloudUpdate,
            cloudCheckSucceeded = cloudCheckSucceeded,
            onDismiss = {
                showCloudUpdateDialog = false
                cloudUpdateRequestId++
            }
        )
    }

    if (showSafetyPrivacyDialog) {
        SafetyPrivacyCertificationDialog(
            onDismiss = { showSafetyPrivacyDialog = false }
        )
    }



    if (showInAppUpdateDialog) {
        InAppUpdateDialog(
            initialUpdateUrl = inAppUpdateUrl,
            broadcastTitle = activeBroadcast?.takeIf { it.type == "UPDATE" }?.title.orEmpty(),
            broadcastMessage = activeBroadcast?.takeIf { it.type == "UPDATE" }?.message.orEmpty(),
            autoStartDownload = inAppUpdateAutoStart,
            autoInstallOnDownloaded = inAppUpdateAutoInstall,
            latestRelease = latestApkRelease,
            onDismiss = {
                showInAppUpdateDialog = false
                val rel = latestApkRelease
                if (rel != null && hasNewerCloudApk) {
                    LicenseManager.markReleaseAutoPromptDismissed(context, rel.releaseId)
                }
            }
        )
    }

    if (showDownloadConfirmDialog) {
        val downloadUrl = LicenseManager.resolveGoogleDriveApkLink(context, latestApkRelease?.downloadUrl.orEmpty())
        AlertDialog(
            onDismissRequest = { showDownloadConfirmDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Download, contentDescription = null, tint = MagicCyan, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Xác Nhận Tải APK", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    val ver = latestApkRelease?.versionName ?: headerAppVer
                    Text("Phiên bản: v$ver", color = MagicEmerald, fontWeight = FontWeight.Bold, fontSize = 13.5.sp)
                    Text(
                        "Bạn có chắc chắn muốn mở Google Drive để tải bản cài đặt APK mới nhất không?",
                        color = TextPrimary.copy(alpha = 0.9f),
                        fontSize = 12.5.sp
                    )
                    if (downloadUrl.isNotBlank()) {
                        Text(
                            "Link: $downloadUrl",
                            color = Color.Gray,
                            fontSize = 10.5.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(
                        onClick = {
                            try {
                                val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Liên kết tải APK", downloadUrl))
                                android.widget.Toast.makeText(context, "Đã sao chép liên kết tải APK.", android.widget.Toast.LENGTH_SHORT).show()
                            } catch (_: Exception) {}
                        }
                    ) {
                        Text("Sao chép link", color = MagicCyanLight, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = {
                            showDownloadConfirmDialog = false
                            try {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(downloadUrl)).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                context.startActivity(intent)
                            } catch (_: Exception) {}
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MagicCyan, contentColor = Color(0xFF020617)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Tải ngay", fontWeight = FontWeight.Bold)
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showDownloadConfirmDialog = false }) {
                    Text("Hủy", color = Color.Gray)
                }
            },
            containerColor = MagicSurfaceDark,
            shape = RoundedCornerShape(14.dp)
        )
    }



    if (shouldShowBroadcastModal && activeBroadcast != null) {
        AlertDialog(
            onDismissRequest = {
                LicenseManager.markBroadcastDismissed(context, activeBroadcast.id)
                dismissedBroadcastId = activeBroadcast.id
                isBannerDismissed = true
                forceShowBroadcastModal = false
            },
            containerColor = MagicSurfaceCard,
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (activeBroadcast.type == "UPDATE") MagicAmber.copy(alpha = 0.2f) else MagicCyan.copy(alpha = 0.2f))
                                .border(1.dp, if (activeBroadcast.type == "UPDATE") MagicAmber else MagicCyan, RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = if (activeBroadcast.type == "UPDATE") "🚀 THÔNG BÁO CẬP NHẬT TOÀN CẦU" else "📢 THÔNG BÁO TOÀN CẦU TỪ ADMIN",
                                color = if (activeBroadcast.type == "UPDATE") MagicAmber else MagicCyanLight,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Text(
                            text = activeBroadcast.title.ifBlank { "Thông báo từ Quản trị viên" },
                            color = TextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(MagicSurfaceCard)
                            .border(1.dp, MagicBorder, RoundedCornerShape(8.dp))
                            .clickable {
                                LicenseManager.markBroadcastDismissed(context, activeBroadcast.id)
                                dismissedBroadcastId = activeBroadcast.id
                                isBannerDismissed = true
                                forceShowBroadcastModal = false
                            }
                            .testTag("close_broadcast_dialog_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Đóng thông báo",
                            tint = TextPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            },
            text = {
                ScrollableDialogColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = activeBroadcast.message,
                        color = TextPrimary,
                        fontSize = 13.sp,
                        lineHeight = 19.sp
                    )
                    if (activeBroadcast.type == "UPDATE") {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(MagicEmerald.copy(alpha = 0.14f))
                                .border(1.dp, MagicEmerald.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                .padding(10.dp)
                        ) {
                            Text(
                                text = "💡 Mẹo: Bạn có thể bấm nút tải ngay bên dưới hoặc ấn vào nút 'Bản cập nhật' ở góc trái trên cùng màn hình (Header) bất cứ lúc nào!",
                                color = MagicEmerald,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            },
            confirmButton = {
                if (activeBroadcast.type == "UPDATE") {
                    Button(
                        onClick = {
                            LicenseManager.markBroadcastDismissed(context, activeBroadcast.id)
                            dismissedBroadcastId = activeBroadcast.id
                            isBannerDismissed = true
                            forceShowBroadcastModal = false
                            val targetUrl = LicenseManager.resolveGoogleDriveApkLink(
                                context,
                                latestApkRelease?.downloadUrl.orEmpty().ifBlank { activeBroadcast.actionUrl }
                            )
                            inAppUpdateUrl = targetUrl
                            // Opening the update dialog must not start network traffic or install by itself.
                            inAppUpdateAutoStart = false
                            inAppUpdateAutoInstall = false
                            showInAppUpdateDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.SystemUpdate, contentDescription = null, tint = Color(0xFF020617), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Tải Bản Cập Nhật Mới", color = Color(0xFF020617), fontWeight = FontWeight.Black, fontSize = 12.sp)
                    }
                } else {
                    Button(
                        onClick = {
                            LicenseManager.markBroadcastDismissed(context, activeBroadcast.id)
                            dismissedBroadcastId = activeBroadcast.id
                            isBannerDismissed = true
                            forceShowBroadcastModal = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MagicCyan),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Đã Hiểu", color = Color(0xFF020617), fontWeight = FontWeight.Black, fontSize = 12.sp)
                    }
                }
            },
            dismissButton = {
                if (activeBroadcast.type == "UPDATE") {
                    TextButton(
                        onClick = {
                            LicenseManager.markBroadcastDismissed(context, activeBroadcast.id)
                            dismissedBroadcastId = activeBroadcast.id
                            isBannerDismissed = true
                            forceShowBroadcastModal = false
                        }
                    ) {
                        Text("Để sau", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        )
    }



    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MagicDarkBackground)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // Banner Thông Báo Toàn Cầu (Hiển thị nổi bật ngay trên Header khi Admin phát thông báo, có nút X để người dùng đóng lại cho gọn)
        if (activeBroadcast != null && !isBannerDismissed) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        if (hasUpdateBroadcast) MagicAmber.copy(alpha = 0.16f)
                        else MagicCyan.copy(alpha = 0.14f)
                    )
                    .border(
                        1.dp,
                        if (hasUpdateBroadcast) MagicAmber else MagicCyan,
                        RoundedCornerShape(8.dp)
                    )
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = if (hasUpdateBroadcast) Icons.Default.SystemUpdate else Icons.Default.Campaign,
                    contentDescription = "Thông báo toàn cầu",
                    tint = if (hasUpdateBroadcast) MagicAmber else MagicCyanLight,
                    modifier = Modifier.size(18.dp)
                )
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { forceShowBroadcastModal = true }
                ) {
                    Text(
                        text = activeBroadcast.title.ifBlank { "📢 Thông báo từ Quản trị viên" },
                        color = if (hasUpdateBroadcast) MagicAmber else MagicCyanLight,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Black,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (activeBroadcast.message.isNotBlank()) {
                        Text(
                            text = activeBroadcast.message,
                            color = TextPrimary,
                            fontSize = 10.5.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                if (hasUpdateBroadcast) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MagicEmerald)
                            .clickable {
                                val targetUrl = LicenseManager.resolveGoogleDriveApkLink(
                                    context,
                                    latestApkRelease?.downloadUrl.orEmpty().ifBlank { activeBroadcast.actionUrl }
                                )
                                inAppUpdateUrl = targetUrl
                                inAppUpdateAutoStart = false
                                inAppUpdateAutoInstall = false
                                showInAppUpdateDialog = true
                            }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "📥 Tải Ngay",
                            color = Color(0xFF020617),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
                // Nút X để người dùng ẩn thông báo cho gọn
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(TextPrimary.copy(alpha = 0.15f))
                        .clickable {
                            LicenseManager.markBroadcastDismissed(context, activeBroadcast.id)
                            isBannerDismissed = true
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Ẩn thông báo",
                        tint = TextPrimary,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }

        // Hàng 1: Tên ứng dụng, tải link APK, kiểm tra cập nhật và xuất APK.
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.app_avatar_logo),
                        contentDescription = "Magictune Tool Avatar",
                        modifier = Modifier
                            .size(26.dp)
                            .clip(RoundedCornerShape(7.dp))
                    )
                    Text(
                        text = "Magictune Tool Miễn Phí Cho Android",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                val isIvory = ThemePreferences.isIvoryTheme
                Row(
                    modifier = Modifier
                        .testTag("header_theme_toggle_button")
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isIvory) MagicSurfaceCard.copy(alpha = 0.08f) else Color(0xFFF4EFE6).copy(alpha = 0.14f))
                        .border(
                            1.dp,
                            if (isIvory) Color(0xFFE0D8CA) else Color(0xFFF4EFE6).copy(alpha = 0.45f),
                            RoundedCornerShape(8.dp)
                        )
                        .clickable { ThemePreferences.toggle(context) }
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = if (isIvory) Icons.Default.DarkMode else Icons.Default.LightMode,
                        contentDescription = "Chuyển nền tối / trắng ngà",
                        tint = if (isIvory) MagicSurfaceCard else Color(0xFFF4EFE6),
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = if (isIvory) "Nền tối" else "Trắng ngà",
                        color = if (isIvory) MagicSurfaceCard else Color(0xFFF4EFE6),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }

        }

        val isShizukuLive = !isShizukuDisabled && shellState.isShizukuRunning && shellState.isShizukuPermissionGranted
        val isDirectWlanLive = shellState.isWirelessAdbConnected
        val isRootLive = shellState.mode == ShellMode.ROOT && shellState.isRootAvailable
        val isConnected = isDirectWlanLive || isRootLive || isShizukuLive

        // Hàng 2: Sáu nút cùng chiều rộng: Kết nối | Hoàn tác | An toàn | Xuất APK | Hỗ trợ | Đủ quyền
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            HeaderActionCell(
                modifier = Modifier.weight(1f).testTag("header_connect_button"),
                label = if (isConnected) "Đã nối" else "Kết nối",
                icon = Icons.Default.SystemUpdate,
                accent = if (isConnected) MagicEmerald else MagicAmber,
                onClick = onOpenWlanDialog
            )
            HeaderActionCell(
                modifier = Modifier.weight(1f).testTag("header_revert_button"),
                label = "Hoàn tác",
                icon = Icons.Default.Refresh,
                accent = MagicRose,
                onClick = onOpenRevertModal
            )
            HeaderActionCell(
                modifier = Modifier.weight(1f).testTag("header_safety_privacy_button"),
                label = "An toàn",
                icon = Icons.Default.VerifiedUser,
                accent = MagicEmerald,
                onClick = { showSafetyPrivacyDialog = true }
            )
            HeaderActionCell(
                modifier = Modifier.weight(1f).testTag("header_export_apk_button"),
                label = "Xuất APK",
                icon = Icons.Default.Download,
                accent = MagicCyanLight,
                onClick = {
                    if (!isExportingApk) {
                        coroutineScope.launch {
                            isExportingApk = true
                            try {
                                exportAndShareInstalledApk(context)
                            } finally {
                                isExportingApk = false
                            }
                        }
                    }
                }
            )
            HeaderActionCell(
                modifier = Modifier.weight(1f).testTag("header_support_button"),
                label = "Hỗ trợ",
                icon = Icons.AutoMirrored.Filled.Chat,
                accent = MagicCyan,
                onClick = onOpenChatSupport
            )
            HeaderActionCell(
                modifier = Modifier.weight(1f).testTag("header_permission_button"),
                label = if (isPermissionFullyGranted) "Đủ quyền" else "Cấp quyền",
                icon = Icons.Default.Shield,
                accent = if (isPermissionFullyGranted) MagicEmerald else MagicAmber,
                onClick = onOpenPermissionDialog
            )
        }
        // Hàng 2: Tìm kiếm toàn cục cùng nút Terminal ADB trong header, không nổi ở mép màn hình.
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
        Box(
            modifier = Modifier
                .weight(1f)
                .heightIn(min = 42.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(MagicSurfaceDark)
                .border(
                    1.dp,
                    if (globalSearchQuery.isNotBlank()) MagicCyan else MagicBorder,
                    RoundedCornerShape(10.dp)
                )
                .padding(horizontal = 10.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Tìm kiếm",
                    tint = if (globalSearchQuery.isNotBlank()) MagicCyan else TextSecondary,
                    modifier = Modifier.size(18.dp)
                )
                Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                    if (globalSearchQuery.isEmpty()) {
                        Text(
                            text = "Tìm tên hoặc số ô (#00–#64, Pin 2x2...)",
                            color = TextSecondary,
                            fontSize = 11.8.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    BasicTextField(
                        value = globalSearchQuery,
                        onValueChange = onGlobalSearchChange,
                        singleLine = true,
                        cursorBrush = SolidColor(MagicCyan),
                        textStyle = TextStyle(color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium),
                        modifier = Modifier
                            .fillMaxWidth()
                            .focusRequester(searchFocusRequester)
                    )
                }
                if (globalSearchQuery.isNotBlank()) {
                    Icon(
                        imageVector = Icons.Default.Clear,
                        contentDescription = "Xóa",
                        tint = TextPrimary,
                        modifier = Modifier.size(16.dp).clickable { onGlobalSearchChange("") }
                    )
                }
            }
        }
        Row(
            modifier = Modifier
                .height(42.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(MagicCyan.copy(alpha = 0.12f))
                .border(1.dp, MagicCyan.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                .clickable(onClick = onOpenTerminal)
                .padding(horizontal = 8.dp)
                .testTag("header_global_search_adb_button"),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(Icons.Default.Terminal, contentDescription = null, tint = MagicCyanLight, modifier = Modifier.size(16.dp))
            Text("ADB", color = MagicCyanLight, fontSize = 10.sp, fontWeight = FontWeight.Black)
        }
        }
    }
}

@Composable
private fun HeaderActionCell(
    modifier: Modifier,
    label: String,
    icon: ImageVector,
    accent: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .height(46.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(accent.copy(alpha = 0.13f))
            .border(1.dp, accent.copy(alpha = 0.48f), RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 2.dp, vertical = 3.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(1.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = accent,
                modifier = Modifier.size(14.dp)
            )
            Text(
                text = label,
                color = TextPrimary,
                fontSize = 8.5.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                softWrap = false,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )
        }
    }
}

private val SelectedTabBrush = Brush.horizontalGradient(listOf(MagicBlue, MagicCyan))

@Composable
private fun CompactTabButton(
    title: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val bgModifier = if (isSelected) {
        Modifier.background(SelectedTabBrush)
    } else {
        Modifier.background(MagicSurfaceCard)
    }

    Box(
        modifier = Modifier
            .defaultMinSize(minHeight = 28.dp)
            .clip(RoundedCornerShape(7.dp))
            .then(bgModifier)
            .border(
                width = 1.dp,
                color = if (isSelected) MagicCyanLight else MagicBorder,
                shape = RoundedCornerShape(7.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 9.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = title,
            color = if (isSelected) TextPrimary else TextPrimary,
            fontSize = 11.5.sp,
            fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
            maxLines = 1
        )
    }
}

private suspend fun exportAndShareInstalledApk(context: android.content.Context) {
    try {
        val fileName = "MagicTune_Tool_${APP_VERSION_NAME.lowercase()}.apk"
        val shareUri = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            val sourceApk = java.io.File(context.applicationInfo.sourceDir)

            // 1. Lưu bản sao vào thư mục Download của máy (MediaStore.Downloads - Không cần quyền bộ nhớ trên Android 10 - 17)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                try {
                    val resolver = context.contentResolver
                    val contentValues = android.content.ContentValues().apply {
                        put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                        put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "application/vnd.android.package-archive")
                        put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS)
                    }
                    val downloadUri = resolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                    if (downloadUri != null) {
                        resolver.openOutputStream(downloadUri)?.use { outStream ->
                            sourceApk.inputStream().use { inStream ->
                                inStream.copyTo(outStream)
                            }
                        }
                    }
                } catch (_: Exception) {}
            }

            // 2. Tạo file chuẩn trong cacheDir và lấy Uri chia sẻ (Zalo, Drive, Telegram, Quick Share...)
            val cacheApk = java.io.File(context.cacheDir, fileName)
            sourceApk.copyTo(cacheApk, overwrite = true)
            androidx.core.content.FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                cacheApk
            )
        }

        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
            android.widget.Toast.makeText(
                context,
                "✅ Đã lưu $fileName vào thư mục Download & mở bảng chia sẻ!",
                android.widget.Toast.LENGTH_LONG
            ).show()

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/vnd.android.package-archive"
                putExtra(Intent.EXTRA_STREAM, shareUri)
                putExtra(Intent.EXTRA_SUBJECT, fileName)
                putExtra(Intent.EXTRA_TEXT, "Bộ cài đặt chuẩn $fileName (Đã ký xác thực đầy đủ v1 + v2 + v3, tương thích Honor Max MagicOS 11 & Android 17)")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(shareIntent, "Chia sẻ $fileName").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        }
    } catch (e: Exception) {
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
            android.widget.Toast.makeText(
                context,
                "Không thể xuất APK: ${e.message}",
                android.widget.Toast.LENGTH_SHORT
            ).show()
        }
    }
}

