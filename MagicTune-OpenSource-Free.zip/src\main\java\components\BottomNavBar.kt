package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Settings
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainTab
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.MagicSurfaceDark
import com.example.ui.theme.TextSecondary

internal data class BottomNavItem(
    val tab: MainTab,
    val label: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)

@Composable
fun BottomNavBar(
    currentTab: MainTab,
    onTabSelected: (MainTab) -> Unit,
    onAddClicked: () -> Unit
) {
    val mainTabs = listOf(
        BottomNavItem(MainTab.SETUP, "Thiết Lập", Icons.Default.Settings),
        BottomNavItem(MainTab.TUNE, "Tối Ưu", Icons.Default.RocketLaunch),
        BottomNavItem(MainTab.NOTIFICATIONS, "Thông Báo", Icons.Default.Notifications),
        BottomNavItem(MainTab.BG_DRAIN_MONITOR, "Pin", Icons.Default.BatteryFull)
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(74.dp)
            .background(MagicSurfaceDark)
            .padding(start = 8.dp, end = 8.dp, top = 4.dp, bottom = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        mainTabs.forEach { item ->
            val isSelected = currentTab == item.tab
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(64.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isSelected) MagicCyan.copy(alpha = 0.2f) else MagicSurfaceCard)
                    .border(1.dp, if (isSelected) MagicCyan else MagicBorder, RoundedCornerShape(12.dp))
                    .clickable { onTabSelected(item.tab) },
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(2.dp)
                ) {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.label,
                        tint = if (isSelected) MagicCyan else TextSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                    Text(
                        text = item.label,
                        color = if (isSelected) MagicCyan else TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                }
            }
        }

        // Nút Thêm — nút cuối cùng
        Box(
            modifier = Modifier
                .weight(1f)
                .height(64.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(MagicEmerald.copy(alpha = 0.2f))
                .border(1.dp, MagicEmerald, RoundedCornerShape(12.dp))
                .clickable { onAddClicked() },
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(2.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Thêm",
                    tint = MagicEmerald,
                    modifier = Modifier.size(22.dp)
                )
                Text(
                    text = "Thêm",
                    color = MagicEmerald,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
            }
        }
    }
}
