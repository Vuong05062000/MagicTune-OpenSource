package com.example.core.auth

import android.content.Context
import androidx.compose.runtime.Immutable
import com.example.data.HonorAppItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * Phiên bản hoàn toàn miễn phí & không đăng nhập / không Firebase.
 * Giữ lại Kho App cục bộ trên thiết bị để người dùng thêm/quản lý danh sách ứng dụng cá nhân.
 */
object FirebaseAuthManager {

    private const val PREF_NAME = "magictune_pro_prefs"
    private const val KEY_LOCAL_HONOR_APPS = "local_honor_apps_json_v1"

    data class LocalUserProfile(
        val uid: String = "",
        val email: String? = null,
        val displayName: String? = null
    )

    @Immutable
    data class AuthSessionSnapshot(
        val isLoggedIn: Boolean = false,
        val uid: String = "",
        val email: String = "",
        val displayName: String = "",
        val role: String = "user",
        val isAdmin: Boolean = false,
        val isInitialized: Boolean = true
    )

    private val _authSessionFlow = MutableStateFlow(AuthSessionSnapshot())
    val authSessionFlow: StateFlow<AuthSessionSnapshot> = _authSessionFlow.asStateFlow()

    private val localHonorAppsFlow = MutableStateFlow<List<HonorAppItem>>(emptyList())
    @Volatile
    private var localAppsLoaded = false

    fun getCurrentUser(): LocalUserProfile? = null

    fun initAuthSessionFromCache(context: Context) {
        ensureLocalAppsLoaded(context)
    }

    fun refreshAuthSessionNow(context: Context): AuthSessionSnapshot = _authSessionFlow.value

    fun ensureCentralAuthStateObserver(context: Context) {
        ensureLocalAppsLoaded(context)
    }

    fun startSingleDeviceSessionGuard(context: Context) {}

    fun detachSingleDeviceListenerOnBackground() {}

    fun updateUserHeartbeat(context: Context, force: Boolean = true) {}

    fun refreshFirebaseTokenSilentlyIfNeeded(context: Context) {}

    fun isCurrentAdmin(context: Context?, user: Any? = null): Boolean = false

    fun observeHonorApps(context: Context? = null): Flow<List<HonorAppItem>> {
        if (context != null) ensureLocalAppsLoaded(context)
        return localHonorAppsFlow.asStateFlow()
    }

    suspend fun saveHonorApp(app: HonorAppItem, context: Context? = null) = withContext(Dispatchers.IO) {
        val item = app.copy(
            id = app.id.ifBlank { "local_${System.currentTimeMillis()}" },
            status = "APPROVED"
        )
        val updated = (localHonorAppsFlow.value.filter { it.id != item.id } + item)
            .sortedByDescending { it.createdAt }
        localHonorAppsFlow.value = updated
        persistLocalApps(context, updated)
    }

    suspend fun contributeHonorApp(app: HonorAppItem, context: Context? = null) {
        saveHonorApp(app.copy(status = "APPROVED"), context)
    }

    suspend fun deleteHonorApp(appId: String, context: Context? = null) = withContext(Dispatchers.IO) {
        val updated = localHonorAppsFlow.value.filterNot { it.id == appId }
        localHonorAppsFlow.value = updated
        persistLocalApps(context, updated)
    }

    suspend fun updateHonorAppStatus(appId: String, status: String, context: Context? = null) =
        withContext(Dispatchers.IO) {
            val updated = localHonorAppsFlow.value.map {
                if (it.id == appId) it.copy(status = status) else it
            }
            localHonorAppsFlow.value = updated
            persistLocalApps(context, updated)
        }

    private fun ensureLocalAppsLoaded(context: Context) {
        if (localAppsLoaded) return
        synchronized(this) {
            if (localAppsLoaded) return
            localAppsLoaded = true
            try {
                val prefs = context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                val raw = prefs.getString(KEY_LOCAL_HONOR_APPS, "").orEmpty()
                if (raw.isNotBlank()) {
                    val arr = JSONArray(raw)
                    val list = buildList {
                        for (i in 0 until arr.length()) {
                            val o = arr.optJSONObject(i) ?: continue
                            add(
                                HonorAppItem(
                                    id = o.optString("id"),
                                    name = o.optString("name"),
                                    description = o.optString("description"),
                                    downloadUrl = o.optString("downloadUrl"),
                                    category = o.optString("category", "Tiện Ích"),
                                    version = o.optString("version", "1.0"),
                                    author = o.optString("author", "Cộng đồng Honor"),
                                    isProOnly = false,
                                    iconName = o.optString("iconName", "apps"),
                                    status = o.optString("status", "APPROVED"),
                                    contributorEmail = o.optString("contributorEmail"),
                                    createdAt = o.optLong("createdAt", System.currentTimeMillis())
                                )
                            )
                        }
                    }
                    localHonorAppsFlow.value = list
                }
            } catch (_: Throwable) {}
        }
    }

    private fun persistLocalApps(context: Context?, list: List<HonorAppItem>) {
        if (context == null) return
        try {
            val arr = JSONArray()
            list.forEach { item ->
                arr.put(
                    JSONObject().apply {
                        put("id", item.id)
                        put("name", item.name)
                        put("description", item.description)
                        put("downloadUrl", item.downloadUrl)
                        put("category", item.category)
                        put("version", item.version)
                        put("author", item.author)
                        put("isProOnly", false)
                        put("iconName", item.iconName)
                        put("status", item.status)
                        put("contributorEmail", item.contributorEmail)
                        put("createdAt", item.createdAt)
                    }
                )
            }
            context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_LOCAL_HONOR_APPS, arr.toString())
                .apply()
        } catch (_: Throwable) {}
    }
}
