package com.example.ui.components
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.MagicSurfaceDark
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.MagicDarkBackground

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Assistant
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import kotlin.math.roundToInt
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.core.installer.WlanFastApkInstaller
import com.example.data.DeviceInfo
import com.example.data.TuneStatus
import com.example.ui.theme.*
import kotlinx.coroutines.launch

private val TuneRoseGradBrush = Brush.horizontalGradient(listOf(MagicRose, Color(0xFFDC2626)))
private val TuneCyanEmeraldGradBrush = Brush.horizontalGradient(listOf(MagicCyan, MagicEmerald))
private val TuneCyanPurpleGradBrush = Brush.horizontalGradient(listOf(MagicCyan, MagicPurple))
private val TuneCyanEmeraldLinearBrush = Brush.linearGradient(listOf(MagicCyan, MagicEmerald))
private val TunePurpleCyanLinearBrush = Brush.linearGradient(listOf(MagicPurple, MagicCyan))
private val TuneAmberCyanLinearBrush = Brush.linearGradient(listOf(MagicAmber, MagicCyan))

@Composable
fun TuneScreen(
    deviceInfo: DeviceInfo,
    tuneStatus: TuneStatus = TuneStatus(),
    isAdbReady: Boolean = false,
    isBusy: Boolean,
    onApplyMaxSettings: () -> Unit,
    onApplySmartBatterySaver: () -> Unit = {},
    onEnhanceGestureSensitivity: () -> Unit = {},
    onBoostTouchAndFingerprint: () -> Unit = {},
    onOpenFingerprintEnrollSetting: () -> Unit = {},
    onBoostWifiSpeed: () -> Unit = {},
    onBoostDualWifi: () -> Unit = {},
    onApplyAlwaysOnNetworkBatterySaver: () -> Unit = {},
    onRestoreDefaultNetworkAndBattery: () -> Unit = {},
    onApplyVaporChamberCooling: () -> Unit = {},
    onApplyIosFluidSmoothness: () -> Unit = {},
    onRestoreDefaultSmoothnessAndThermal: () -> Unit = {},
    onApplyIosBatteryEngine: () -> Unit = {},
    onRestoreDefaultBatteryEngine: () -> Unit = {},
    onSetRefreshRate: (Int) -> Unit,
    onSetAnimationScale: (Float) -> Unit,
    onDisableYoyoWake: () -> Unit = {},
    onRemapNavBarToGoogleAssistant: () -> Unit = {},
    onModCircleToSearch: () -> Unit = {},
    onModMagicLive: () -> Unit = {},
    onSetDefaultAssistant: () -> Unit = {},
    onTestTriggerNavAssistant: () -> Unit = {},
    onTestCircleToSearch: () -> Unit = {},
    onRestoreYoyoOriginal: () -> Unit = {},
    onToggleNavPillsCentered: (Boolean) -> Unit = {},
    onToggleNavigationBarPill: (Boolean) -> Unit = {},
    onHideNavigationBar: () -> Unit,
    onReplaceHonorSearch: (Boolean) -> Unit = {},
    onBlockAppMarketUpdates: () -> Unit = {},
    onUnblockAppMarketUpdates: () -> Unit = {},
    onApplyThermalCooling: () -> Unit = {},
    onFixAudio: () -> Unit,
    onFixAndroidAuto: () -> Unit = {},
    onFixGps: () -> Unit = {},
    onRefreshSatellites: () -> Unit = {},
    onSetFontLarge: (Boolean) -> Unit,
    onSetDarkModeOled: (Boolean) -> Unit,
    onEnableAdBlocker: () -> Unit,
    onDisableAdBlocker: () -> Unit,
    onEnableStealthDevMode: () -> Unit = {},
    onRestoreDevModeVisibility: () -> Unit = {},
    onFixMagicOSSystemUpdate: () -> Unit = {},
    onUnlockRestrictedStorage: () -> Unit = {},
    onExtractAndSyncRestrictedData: () -> Unit = {},
    onCleanRestrictedCaches: () -> Unit = {},
    onToggleDeepPrivacySensor: (String, Boolean) -> Unit = { _, _ -> },
    onRunAutomationMacro: (String) -> Unit = {},
    onOpenAppsManagerTab: () -> Unit = {},
    onOpenPlayStore: (String) -> Unit = {},
    onRequestOverlaySettingIntent: () -> Unit = {},
    onRefreshDeviceInfo: () -> Unit = {},
    onToggleDeviceFeature: (String, Boolean) -> Unit = { _, _ -> },
    onNavigateToUniversalFix: () -> Unit = {},
    onOpenDirectWlanTab: () -> Unit = {},
    onOpenGestureSettings: () -> Unit = {},
    onSetPermanentRefreshRateLock: (Int, Boolean) -> Unit = { _, _ -> },
    onSetPermanentResolutionLock: (String, Boolean) -> Unit = { _, _ -> },
    onDisableSafeConflictingOemFeatures: () -> Unit = {},
    onRestoreSafeConflictingOemFeatures: () -> Unit = {},
    onOpenBackgroundDrainScreen: () -> Unit = {}
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var isWlanFirstActivated by remember {
        mutableStateOf(com.example.core.permission.AppPermissionChecker.isFirstTimeWlanActivated(context))
    }
    var showWlanRequiredDialog by remember { mutableStateOf(false) }
    var isInstallingApk by remember { mutableStateOf(false) }
    var installStatusText by remember { mutableStateOf("") }

    val apkPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                isInstallingApk = true
                installStatusText = "⏳ Đang chuẩn bị tệp APK..."
                val result = WlanFastApkInstaller.installApkFromUri(context, uri) { progress ->
                    installStatusText = progress
                }
                isInstallingApk = false
                when (result) {
                    is WlanFastApkInstaller.InstallResult.Success -> {
                        Toast.makeText(
                            context,
                            "🎉 Cài đặt siêu tốc thành công: ${result.appLabel}!\nỨng dụng đã sẵn sàng trên màn hình chính.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                    is WlanFastApkInstaller.InstallResult.FallbackStandardInstall -> {
                        Toast.makeText(context, "Đã mở trình cài đặt APK chuẩn của hệ thống.", Toast.LENGTH_SHORT).show()
                    }
                    is WlanFastApkInstaller.InstallResult.Error -> {
                        Toast.makeText(context, "❌ Lỗi: ${result.error}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }
    var hasOverlay by remember { mutableStateOf(true) }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                coroutineScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                    val overlayOk = try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            Settings.canDrawOverlays(context)
                        } else true
                    } catch (_: Throwable) { true }
                    val wlanOk = com.example.core.permission.AppPermissionChecker.isFirstTimeWlanActivated(context)
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                        hasOverlay = overlayOk
                        isWlanFirstActivated = wlanOk
                    }
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .blockInputWhileBusy(isBusy)
            .testTag("tune_screen_root_column"),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // Banner nhắc kết nối nhanh nếu chưa bật Gỡ lỗi không dây / Shizuku
        if (!isAdbReady) {
            item(key = "tune_banner_no_adb") {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                border = BorderStroke(1.dp, MagicAmber.copy(alpha = 0.65f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(
                        modifier = Modifier.fillMaxHeight().weight(1f),
                        verticalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Text(
                            text = "⚡ Chưa kết nối Gỡ lỗi Không dây (WLAN ADB)",
                            color = MagicAmber,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "Hãy kết nối Mã 6 Số (Ô #36) 1 lần để các lệnh tối ưu sâu từ Ô #20 đến Ô #35 thực thi tự động 100%.",
                            color = TextSecondary,
                            fontSize = 10.5.sp,
                            lineHeight = 14.5.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = onOpenDirectWlanTab,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MagicCyan,
                            contentColor = Color(0xFF020617)
                        )
                    ) {
                        Text(text = "Kết Nối Ngay", fontSize = 11.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
            }
        }

        item(key = "tune_card_16") {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Mở tính năng từ thông báo ghim", fontWeight = FontWeight.Bold)
                    Text("Vuốt mở thanh thông báo để tìm ứng dụng, mở Magiclive hoặc Vẽ mở app. Khoanh tròn xuất hiện sau lần kết nối ADB đầu tiên.")
                    if (!isWlanFirstActivated) {
                        Button(onClick = onOpenDirectWlanTab) { Text("Kết nối ADB lần đầu") }
                    }
                }
            }
        }

        item(key = "tune_card_17") {
        Card(
            modifier = Modifier.fillMaxWidth().testTag("wlan_fast_apk_installer_card"),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = BorderStroke(1.dp, MagicEmerald.copy(alpha = 0.45f))
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TuneBadgeTag(text = "Ô #21", color = MagicEmerald)
                    Icon(Icons.Default.Download, contentDescription = null, tint = MagicEmerald, modifier = Modifier.size(18.dp))
                }
                Text(
                    text = "Cài Đặt Siêu Tốc Tệp APK (Bỏ Qua Chặn Honor)",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "Chọn bất kỳ tệp .APK nào trong máy để cài đè nâng cấp trực tiếp và tự động mở khóa quyền Cài đặt bị hạn chế trên Honor MagicOS.",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 15.5.sp
                )
                if (installStatusText.isNotBlank()) {
                    Text(
                        text = installStatusText,
                        color = MagicCyanLight,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Button(
                    onClick = {
                        try {
                            apkPickerLauncher.launch("application/vnd.android.package-archive")
                        } catch (_: Exception) {
                            Toast.makeText(context, "⚠️ Không tìm thấy trình chọn tệp (Files) trên máy để chọn APK.", Toast.LENGTH_LONG).show()
                        }
                    },
                    enabled = !isInstallingApk,
                    modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 36.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald, contentColor = Color(0xFF020617))
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(17.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isInstallingApk) "⏳ ĐANG CÀI ĐẶT APK..." else "📦 CHỌN TỆP APK ĐỂ CÀI ĐẶT NGAY",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }
        }

        // Ô #22: BẢNG CHỈNH NHANH DỄ DÙNG (1 CHẠM) & CẢM ỨNG ĐÁY / VÂN TAY CƯỜNG LỰC
        item(key = "tune_card_18") {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = BorderStroke(1.5.dp, TuneCyanEmeraldLinearBrush)
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    TuneBadgeTag(text = "Ô #22", color = MagicCyan)
                }
                Text(
                    text = "✨ BẢNG CHỈNH NHANH 1-CHẠM & CẢM ỨNG CƯỜNG LỰC",
                    color = MagicCyanLight,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.fillMaxWidth()
                )

                // Hàng riêng cho nhãn MÁC AN TOÀN 100% không bị bóp hẹp
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MagicEmerald.copy(alpha = 0.18f))
                        .border(1.dp, MagicEmerald.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Default.Shield, contentDescription = null, tint = MagicEmerald, modifier = Modifier.size(16.dp))
                    Text(
                        text = "MÁC AN TOÀN 100% • Tùy chỉnh hệ thống không mất dữ liệu",
                        color = MagicEmeraldLight,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
                    Button(
                        onClick = { onSetFontLarge(!tuneStatus.isFontBoldLarge) },
                        modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (tuneStatus.isFontBoldLarge) MagicEmerald else MagicAmber,
                            contentColor = Color(0xFF020617)
                        )
                    ) {
                        Text(
                            text = if (tuneStatus.isFontBoldLarge) "✓ Chữ Đang To Rõ" else "🔤 Bật Chữ To Rõ",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = onApplyMaxSettings,
                        modifier = Modifier.fillMaxHeight().weight(1f).defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MagicCyan, contentColor = Color(0xFF020617))
                    ) {
                        Text(text = "🚀 Làm Máy Siêu Mượt", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = onEnableStealthDevMode,
                        modifier = Modifier.fillMaxHeight().weight(1f).defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MagicSurfaceCard, contentColor = Color.White),
                        border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.6f))
                    ) {
                        Text(text = "🏦 Vào Bank & App", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                    }
                }

                // Hàng 3: Tối ưu cảm ứng & vân tay cường lực dày (>0.45mm)
                Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = onBoostTouchAndFingerprint,
                        modifier = Modifier.fillMaxHeight().weight(1f).defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (tuneStatus.isFingerprintBoosted) MagicEmerald else MagicPurple,
                            contentColor = Color.White
                        ),
                        border = BorderStroke(1.dp, (if (tuneStatus.isFingerprintBoosted) MagicEmeraldLight else MagicPurpleLight).copy(alpha = 0.6f))
                    ) {
                        Text(
                            text = if (tuneStatus.isFingerprintBoosted) "✓ Đã Bù Nhạy" else "⚡ Nhạy Cảm Ứng",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                    }
                    Button(
                        onClick = onOpenFingerprintEnrollSetting,
                        modifier = Modifier.fillMaxHeight().weight(1f).defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MagicSurfaceCard, contentColor = MagicAmber),
                        border = BorderStroke(1.dp, MagicAmber.copy(alpha = 0.6f))
                    ) {
                        Text(
                            text = "🎯 Quét Lại Vân Tay",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                // Hàng 4: Siêu Tiết Kiệm Pin Thông Minh (Zero Delay) & Mở Cập Nhật Hệ Thống MagicOS
                Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = onApplySmartBatterySaver,
                        modifier = Modifier.fillMaxHeight().weight(1f).defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MagicEmerald,
                            contentColor = Color(0xFF020617)
                        )
                    ) {
                        Text(
                            text = "🔋 Siêu Tiết Kiệm Pin",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                    }
                    Button(
                        onClick = onFixMagicOSSystemUpdate,
                        modifier = Modifier.fillMaxHeight().weight(1f).defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MagicSurfaceCard,
                            contentColor = MagicCyanLight
                        ),
                        border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.6f))
                    ) {
                        Text(
                            text = "🔄 Mở Cập Nhật OTA",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                // Hàng 5: Lối tắt sang Dọn Ứng Dụng & Vẽ Chữ Mở App A-Z
                Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = onOpenAppsManagerTab,
                        modifier = Modifier.fillMaxHeight().weight(1f).defaultMinSize(minHeight = 34.dp),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = "🗑️ Quản Lý & Đóng Băng App",
                            color = MagicCyanLight,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                    }
                    OutlinedButton(
                        onClick = onOpenGestureSettings,
                        modifier = Modifier.fillMaxHeight().weight(1f).defaultMinSize(minHeight = 34.dp),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, MagicPurple.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = "✍️ Cài Đặt Vẽ Chữ A–Z",
                            color = MagicPurpleLight,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                // Hợp nhất từ Ô #30 cũ: Bù nhạy vuốt đáy & cạnh kính cường lực dày
                Button(
                    onClick = onEnhanceGestureSensitivity,
                    modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 36.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MagicSurfaceCard, contentColor = MagicCyanLight),
                    border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.5f))
                ) {
                    Icon(Icons.Default.FlashOn, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (tuneStatus.isGestureSensitivityEnhanced || tuneStatus.isFingerprintBoosted) "✓ Đã Bù Nhạy Vuốt Đáy & Cảm Ứng Cường Lực" else "⚡ Tăng Nhạy Vuốt Đáy & Cạnh (Bù Kính Cường Lực)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
        }

        // Ô #23: HỢP NHẤT MAX SETTING TOÀN DIỆN, TẦN SỐ QUÉT 120HZ/144HZ & TỐC ĐỘ CHUYỂN CẢNH
        item(key = "tune_card_19") {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = BorderStroke(1.2.dp, TunePurpleCyanLinearBrush)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TuneBadgeTag(text = "Ô #23", color = MagicCyan)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MagicPurple.copy(alpha = 0.2f))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "GIỮ NGUYÊN CẢ KHI TẮT GỠ LỖI WLAN",
                            color = MagicPurpleLight,
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
                Text(
                    text = "Kích Hoạt Max Setting, Tần Số Quét (${deviceInfo.refreshRate}) & Chuyển Cảnh (${tuneStatus.currentAnimationScale}x)",
                    color = TextPrimary,
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "Hợp nhất toàn diện: Tùy chọn tần số quét linh hoạt (60Hz Tiết Kiệm Pin / 90Hz Cân Bằng / 120-144Hz Cực Mượt), tùy chỉnh tốc độ chuyển cảnh animation 0.5x/0x, giảm độ trễ cảm ứng và giữ nguyên ngay cả khi ngắt kết nối ADB.",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 15.5.sp
                )
                Button(
                    onClick = onApplyMaxSettings,
                    modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 36.dp).testTag("apply_max_settings_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MagicPurple, contentColor = Color.White)
                ) {
                    Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "⚡ BẬT MAX SETTING TOÀN DIỆN",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.5.sp
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        144 to "Ép 120/144Hz\n(Cực Mượt)",
                        90 to "90Hz\n(Mượt & Nhẹ)",
                        60 to "60Hz\n(Tiết Kiệm Pin)"
                    ).forEach { (rate, title) ->
                        val isSelected = when (rate) {
                            144 -> tuneStatus.currentRefreshRate >= 120
                            90 -> tuneStatus.currentRefreshRate in 80..119
                            60 -> tuneStatus.currentRefreshRate <= 65
                            else -> tuneStatus.currentRefreshRate == rate
                        }
                        Box(
                            modifier = Modifier
                                .fillMaxHeight().weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) MagicCyan.copy(alpha = 0.22f) else MagicSurfaceCard)
                                .border(1.dp, if (isSelected) MagicCyan else MagicBorder, RoundedCornerShape(10.dp))
                                .clickable { onSetRefreshRate(rate) }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = title,
                                color = if (isSelected) MagicCyanLight else TextPrimary,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0.5f to "0.5x (Siêu tốc)", 1.0f to "1.0x (Chuẩn)", 0.0f to "Tắt hẳn (0x)").forEach { (scale, title) ->
                        val isSelected = tuneStatus.currentAnimationScale == scale
                        Box(
                            modifier = Modifier
                                .fillMaxHeight().weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) MagicEmerald.copy(alpha = 0.22f) else MagicSurfaceCard)
                                .border(1.dp, if (isSelected) MagicEmerald else MagicBorder, RoundedCornerShape(10.dp))
                                .clickable { onSetAnimationScale(scale) }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = title,
                                color = if (isSelected) MagicEmeraldLight else TextPrimary,
                                fontSize = 10.8.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight().weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (tuneStatus.isFontBoldLarge) MagicAmber.copy(alpha = 0.15f) else MagicSurfaceCard)
                            .border(1.dp, if (tuneStatus.isFontBoldLarge) MagicAmber else MagicBorder, RoundedCornerShape(10.dp))
                            .clickable { onSetFontLarge(!tuneStatus.isFontBoldLarge) }
                            .padding(horizontal = 8.dp, vertical = 8.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = if (tuneStatus.isFontBoldLarge) "Bật 115%" else "Mặc định",
                                    color = if (tuneStatus.isFontBoldLarge) MagicEmeraldLight else TextMuted,
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Switch(
                                    checked = tuneStatus.isFontBoldLarge,
                                    onCheckedChange = { onSetFontLarge(it) },
                                    modifier = Modifier.scale(0.7f)
                                )
                            }
                            Text(
                                text = "👓 Chữ To",
                                color = MagicAmber,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                    Box(
                        modifier = Modifier
                            .fillMaxHeight().weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (tuneStatus.isDarkModeOled) MagicPurple.copy(alpha = 0.15f) else MagicSurfaceCard)
                            .border(1.dp, if (tuneStatus.isDarkModeOled) MagicPurple else MagicBorder, RoundedCornerShape(10.dp))
                            .clickable { onSetDarkModeOled(!tuneStatus.isDarkModeOled) }
                            .padding(horizontal = 8.dp, vertical = 8.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = if (tuneStatus.isDarkModeOled) "Đang Bật" else "Đang Tắt",
                                    color = if (tuneStatus.isDarkModeOled) MagicEmeraldLight else TextMuted,
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Switch(
                                    checked = tuneStatus.isDarkModeOled,
                                    onCheckedChange = { onSetDarkModeOled(it) },
                                    modifier = Modifier.scale(0.7f)
                                )
                            }
                            Text(
                                text = "🌙 Dark OLED",
                                color = MagicPurpleLight,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        }
        }

        // Ô #24: KHÓA CỨNG VĨNH VIỄN TẦN SỐ QUÉT & ĐỘ PHÂN GIẢI MÀN HÌNH (BẤT CHẤP TIẾT KIỆM PIN)
        item(key = "tune_card_20") {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = BorderStroke(1.2.dp, TuneAmberCyanLinearBrush)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TuneBadgeTag(text = "Ô #24", color = MagicAmber)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MagicAmber.copy(alpha = 0.2f))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "BẤT CHẤP CHẾ ĐỘ TIẾT KIỆM PIN",
                            color = MagicAmber,
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
                Text(
                    text = "Tối Ưu Độ Phân Giải Gốc & Chế Độ Eco Tự Động",
                    color = TextPrimary,
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "Ưu tiên giữ độ phân giải mặc định phần cứng máy (wm size reset & density reset) giúp GPU nhẹ tải nhất, tấm nền OLED sắc nét tuyệt đối và không hao pin do nội suy. Khi sử dụng các tính năng nổi, hệ thống sẽ tự động hạ tần số quét xuống 60Hz để tiết kiệm tối đa điện năng.",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 15.5.sp
                )

                // Cảnh báo tuổi thọ pin & màn hình khi dùng max liên tục
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MagicSurfaceDark)
                        .border(1.dp, Color(0xFFFF6B6B).copy(alpha = 0.7f), RoundedCornerShape(10.dp))
                        .padding(10.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = "⚠️ CẢNH BÁO LƯU Ý VỀ PIN & MÀN HÌNH:",
                            color = Color(0xFFFF6B6B),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "Việc khóa cứng vĩnh viễn tần số quét tối đa (120Hz/144Hz) và độ phân giải cao nhất liên tục sẽ làm tăng tiêu thụ điện năng, nóng máy và có thể làm giảm tuổi thọ tấm nền màn hình OLED / pin nếu sử dụng ở cường độ cao trong thời gian dài.",
                            color = Color(0xFFFF8A8A),
                            fontSize = 10.2.sp,
                            lineHeight = 14.sp
                        )
                    }
                }

                Text(text = "1. Tần số quét thích ứng:", color = MagicCyanLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(
                    text = "MagicTune không khóa màn hình ở 90/120/144Hz và không đặt mức tối thiểu. Android/HONOR tự hạ tần số khi nội dung đứng yên để giảm điện và nhiệt.",
                    color = TextSecondary,
                    fontSize = 10.5.sp,
                    lineHeight = 14.sp
                )
                if (tuneStatus.isRefreshRateLocked) {
                    Button(
                        onClick = { onSetPermanentRefreshRateLock(120, false) },
                        modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MagicSurfaceCard, contentColor = MagicAmber)
                    ) {
                        Text("🔓 Đang khóa ${tuneStatus.lockedRefreshRate}Hz • Bấm để Mở khóa", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // 2. Độ phân giải màn hình: Ưu tiên chuẩn gốc mặc định của phần cứng máy
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "2. Độ Phân Giải Gốc Phần Cứng Mặc Định:",
                        color = MagicCyanLight,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Chuẩn phần cứng gốc • Nét & Mát",
                        color = MagicEmeraldLight,
                        fontSize = 9.8.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                // Thẻ Độ phân giải phần cứng gốc mặc định
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MagicSurfaceCard)
                        .border(1.dp, MagicEmerald.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "🎯 ĐỘ PHÂN GIẢI GỐC: ${deviceInfo.screen}",
                                color = MagicEmeraldLight,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MagicEmerald.copy(alpha = 0.2f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "Mặc định tối ưu",
                                    color = MagicEmeraldLight,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Text(
                            text = "Ưu tiên độ phân giải vật lý gốc của tấm nền máy để tránh nội suy điểm ảnh, giữ chất lượng hình ảnh trung thực tuyệt đối, GPU hoạt động nhẹ tải nhất và hạn chế nóng máy, hao pin.",
                            color = TextSecondary,
                            fontSize = 10.5.sp,
                            lineHeight = 14.sp
                        )
                        Button(
                            onClick = { onSetPermanentResolutionLock("MAX_NATIVE", true) },
                            modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 36.dp),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald, contentColor = Color.Black)
                        ) {
                            Text("🎯 Khôi Phục / Khóa Chuẩn Gốc Phần Cứng", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                if (tuneStatus.isResolutionLocked) {
                    Button(
                        onClick = { onSetPermanentResolutionLock("MAX_NATIVE", false) },
                        modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MagicSurfaceCard, contentColor = MagicAmber)
                    ) {
                        Text("🔓 Đang khóa: ${tuneStatus.lockedResolutionMode} • Bấm để Mở khóa gốc", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                // Thẻ Eco Display 60Hz: Tự động hạ tần số quét / độ phân giải khi dùng 2 nút điều hướng
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MagicSurfaceDark)
                        .border(1.dp, MagicCyan.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text("⚡", fontSize = 13.sp)
                            Text(
                                text = "Eco Display 60Hz cho tính năng nổi",
                                color = MagicCyanLight,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = "Khi kích hoạt bất kỳ tính năng nào từ thông báo ghim (Khoanh Tròn Hỏi AI, Dịch Cuộn Màn Hình, Chat Magiclive, Bảng Vẽ Cử Chỉ), hệ thống sẽ TỰ ĐỘNG hạ tần số quét màn hình xuống 60Hz để giảm tải hiển thị. Khi đóng tính năng, màn hình tự động trở lại tần số quét bạn đã cài đặt.",
                            color = TextSecondary,
                            fontSize = 10.3.sp,
                            lineHeight = 14.sp
                        )
                    }
                }

                // Thẻ Trợ Lực Công Nghệ Màn Hình Honor (LTPO OLED, 8T LTPO, Tandem OLED, 4320Hz PWM, Smart Resolution)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MagicSurfaceDark)
                        .border(1.dp, MagicEmerald.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text("🛡️", fontSize = 13.sp)
                            Text(
                                text = "Trợ Lực Công Nghệ Màn Hình Honor MagicOS",
                                color = MagicEmeraldLight,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = "Kích hoạt trợ lực phần cứng toàn diện: 8T LTPO / LTPO OLED tự hạ 1Hz-10Hz khi khung hình tĩnh, Dynamic Dimming 4320Hz PWM dịu mắt, Smart Resolution tự động, CABC & Tandem OLED giảm APL. Giúp màn hình chỉ ăn điện 0.1% - 1%/giờ!",
                            color = TextSecondary,
                            fontSize = 10.2.sp,
                            lineHeight = 14.sp
                        )
                        Button(
                            onClick = {
                                com.example.core.perf.ScreenPowerOptimizer.applyFullHonorDisplayOptimization(context)
                                android.widget.Toast.makeText(
                                    context,
                                    "✨ Đã kích hoạt Trợ lực Màn hình Honor (8T LTPO, Dynamic Dimming, Smart Resolution, Tandem OLED)!",
                                    android.widget.Toast.LENGTH_LONG
                                ).show()
                            },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 38.dp, max = 42.dp),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MagicEmerald,
                                contentColor = Color(0xFF020617)
                            )
                        ) {
                            Text("⚡ Kích Hoạt Trợ Lực Màn Hình Honor", fontSize = 11.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Mục 3: Vô hiệu hóa an toàn các tính năng xung đột của hãng gây nóng máy & hao pin
                Text(
                    text = "3. Giải Quyết Xung Đột Hãng An Toàn (Hạ Nhiệt & Chống Hao Pin):",
                    color = MagicCyanLight,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MagicSurfaceDark)
                        .border(1.dp, MagicEmerald.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                        .padding(10.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.Shield, contentDescription = null, tint = MagicEmerald, modifier = Modifier.size(16.dp))
                            Text(
                                text = "⚡ KHÓA VĨNH VIỄN 7 TẦNG • BẤT CHẤP TẮT GỠ LỖI WLAN",
                                color = MagicEmeraldLight,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Text(
                            text = "Khóa cứng 7 tầng vĩnh viễn (AppOps Ignore + Standby Restricted + Hibernation + Hủy JobScheduler + Suspend + Disable/Uninstall User 0 + Khiên WRITE_SECURE_SETTINGS) đối với các trình ngầm gây giằng co CPU, nóng máy & hao pin (PowerGenius, PowerGenie, iAware, HiBoard, HiAI, Magazine, AMap/Baidu...). Dù bạn tắt hoàn toàn Gỡ lỗi WLAN hay khởi động lại máy, các tiến trình xung đột vẫn bị vô hiệu hóa vĩnh viễn 100%, giúp máy luôn mát mẻ tuyệt đối!",
                            color = TextSecondary,
                            fontSize = 10.2.sp,
                            lineHeight = 14.sp
                        )
                        Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = onDisableSafeConflictingOemFeatures,
                                modifier = Modifier.fillMaxHeight().weight(1f).defaultMinSize(minHeight = 36.dp),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald, contentColor = Color(0xFF020617))
                            ) {
                                Text("🛡️ VÔ HIỆU XUNG ĐỘT VĨNH VIỄN", fontSize = 10.8.sp, fontWeight = FontWeight.Black)
                            }
                            OutlinedButton(
                                onClick = onRestoreSafeConflictingOemFeatures,
                                modifier = Modifier.fillMaxHeight().weight(0.7f).defaultMinSize(minHeight = 36.dp),
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, MagicBorder),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = MagicCyanLight)
                            ) {
                                Text("🔄 Khôi Phục", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
        }

        // Ô #25: CHẶN QUẢNG CÁO TOÀN DIỆN (ADBLOCKER PRO)
        item(key = "tune_card_20_adblock") {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = BorderStroke(1.dp, if (tuneStatus.isAdBlockerEnabled) MagicEmerald else MagicEmerald.copy(alpha = 0.35f))
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TuneBadgeTag(text = "Ô #25", color = MagicEmerald)
                        Icon(Icons.Default.Shield, null, tint = MagicEmerald, modifier = Modifier.size(18.dp))
                    }
                    TuneStatusPill(
                        text = if (tuneStatus.isAdBlockerEnabled) "ĐANG BẬT" else "ĐANG TẮT",
                        isPositive = tuneStatus.isAdBlockerEnabled
                    )
                }
                Text(
                    text = "Chặn Quảng Cáo Toàn Diện (AdBlocker Pro)",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "Kích hoạt Private DNS AdGuard chặn sạch banner, video pop-up trong ứng dụng và trình duyệt.",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
                Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = onEnableAdBlocker,
                        modifier = Modifier.fillMaxHeight().weight(1f).defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald, contentColor = Color(0xFF020617))
                    ) {
                        Icon(Icons.Default.Check, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (tuneStatus.isAdBlockerEnabled) "Đã Bật Chặn QC" else "Bật Chặn Quảng Cáo", fontSize = 11.sp, fontWeight = FontWeight.Black)
                    }
                    OutlinedButton(
                        onClick = onDisableAdBlocker,
                        modifier = Modifier.defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, MagicBorder)
                    ) {
                        Text("Tắt DNS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                    }
                }
            }
        }
        }

        // Ô #26: TẮT / BẬT VUỐT XUỐNG TÌM KIẾM HONOR (HISEARCH)
        item(key = "tune_card_21_hisearch") {
        Card(
            modifier = Modifier.fillMaxWidth().testTag("honor_swipe_search_card_31"),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = BorderStroke(1.dp, if (tuneStatus.isHonorSearchDisabled) MagicEmerald else MagicPurple.copy(alpha = 0.55f))
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        TuneBadgeTag(text = "Ô #26", color = MagicPurple)
                        Icon(Icons.Default.Block, contentDescription = null, tint = MagicPurpleLight, modifier = Modifier.size(18.dp))
                    }
                    TuneStatusPill(
                        text = if (tuneStatus.isHonorSearchDisabled) "ĐÃ CHẶN" else "ĐANG MỞ",
                        isPositive = tuneStatus.isHonorSearchDisabled
                    )
                }
                Text(
                    text = "Tắt Vuốt Xuống Tìm Kiếm Honor (HiSearch)",
                    color = TextPrimary,
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "Khắc phục triệt để phiền toái trên điện thoại Honor: khi vuốt xuống ở màn hình chính để kéo thanh thông báo nhưng lại bị nhảy vào bảng Tìm kiếm toàn cục (HiSearch) kèm quảng cáo tiếng Trung.",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 15.5.sp
                )
                Row(
                    modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { onReplaceHonorSearch(true) },
                        modifier = Modifier.fillMaxHeight().weight(1f).defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MagicPurple, contentColor = Color.White)
                    ) {
                        Text(
                            text = "🚫 Tắt Tìm Kiếm\nVuốt Xuống",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center,
                            lineHeight = 15.sp
                        )
                    }
                    OutlinedButton(
                        onClick = { onReplaceHonorSearch(false) },
                        modifier = Modifier.fillMaxHeight().weight(1f).defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp),
                        border = BorderStroke(1.dp, MagicBorder)
                    ) {
                        Text(
                            text = "Mở Lại\nHiSearch Gốc",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        }
        }

        // Ô #27: Giảm tải an toàn qua chế độ Tiết kiệm pin Android bằng ADB
        item(key = "tune_card_22") {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = BorderStroke(1.2.dp, if (tuneStatus.isVcCoolingActive) MagicCyan else MagicBorder)
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TuneBadgeTag(text = "Ô #27", color = MagicCyan)
                }
                Text(
                    text = "⚡ Giảm tải an toàn bằng ADB",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = if (tuneStatus.isVcCoolingActive) "Đang bật Tiết kiệm pin Android do MagicTune quản lý" else "Chưa bật chế độ giảm tải qua ADB",
                    color = if (tuneStatus.isVcCoolingActive) MagicCyanLight else TextMuted,
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "Nút này dùng lệnh Android chuẩn `cmd power set-mode 1` để giảm tải nguồn. Bấm lần nữa sẽ khôi phục trạng thái Tiết kiệm pin trước đó. Android/HONOR vẫn tự quản lý giới hạn nhiệt; ADB không điều khiển quạt hay buồng hơi vật lý. Tự làm mát nền đã tắt để app không tự tạo thêm tải.",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 15.5.sp
                )
                Button(
                    onClick = onApplyVaporChamberCooling,
                    modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 36.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (tuneStatus.isVcCoolingActive) MagicEmerald else MagicCyan,
                        contentColor = Color(0xFF020617)
                    )
                ) {
                    Icon(imageVector = Icons.Default.FlashOn, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = if (tuneStatus.isVcCoolingActive) "KHÔI PHỤC CHẾ ĐỘ PIN TRƯỚC ĐÓ" else "BẬT TIẾT KIỆM PIN ANDROID QUA ADB", fontSize = 11.sp, fontWeight = FontWeight.Black)
                }
                OutlinedButton(
                    onClick = onOpenBackgroundDrainScreen,
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 36.dp)
                        .testTag("tune_open_background_drain_button"),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, MagicAmber.copy(alpha = 0.65f))
                ) {
                    Text(
                        text = "🔍 Xem App Đang Chạy Ngầm Gây Nóng & Hao Pin",
                        color = MagicAmberLight,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
        }

        // Ô #28: SỬA RÈ ÂM THANH BLUETOOTH (HI-FI 48KHZ)
        item(key = "tune_card_23") {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = BorderStroke(1.dp, if (tuneStatus.isAudio48kFixed) MagicEmerald else MagicBorder)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TuneBadgeTag(text = "Ô #28", color = MagicCyan)
                    TuneStatusPill(
                        text = if (tuneStatus.isAudio48kFixed) "ĐÃ BẬT 48KHZ" else "TIÊU CHUẨN",
                        isPositive = tuneStatus.isAudio48kFixed
                    )
                }
                Text(
                    text = "Âm Thanh Bluetooth Hi-Fi 48kHz",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "Ép Audio Server chuẩn 48kHz Hi-Fi, chống rè loa & tai nghe Bluetooth.",
                    color = TextSecondary,
                    fontSize = 10.8.sp
                )
                Button(
                    onClick = onFixAudio,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 38.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald, contentColor = Color(0xFF020617))
                ) {
                    Icon(Icons.Default.GraphicEq, null, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(
                        if (tuneStatus.isAudio48kFixed) "✓ Đã Bật Âm Thanh 48kHz Hi-Fi" else "🎵 Bật Âm Thanh 48kHz Hi-Fi",
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }
        }

        // Ô #29: ĐẶC TRỊ ANDROID AUTO (MÀN HÌNH XE HƠI)
        item(key = "tune_card_24") {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = BorderStroke(1.dp, if (tuneStatus.isAndroidAutoFixed) MagicEmerald else MagicBorder)
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TuneBadgeTag(text = "Ô #29", color = MagicCyan)
                        Icon(Icons.Default.Navigation, null, tint = MagicCyan, modifier = Modifier.size(18.dp))
                    }
                    TuneStatusPill(
                        text = if (tuneStatus.isAndroidAutoFixed) "ĐÃ TỐI ƯU" else "CHƯA FIX",
                        isPositive = tuneStatus.isAndroidAutoFixed
                    )
                }
                Text(
                    text = "Đặc Trị Android Auto (Màn Xe Hơi)",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "Khắc phục triệt để lỗi không nhận Android Auto, văng kết nối cáp/không dây trên xe hơi.",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
                Button(
                    onClick = onFixAndroidAuto,
                    modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 36.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MagicCyan, contentColor = Color(0xFF020617))
                ) {
                    Text(
                        if (tuneStatus.isAndroidAutoFixed) "✓ ĐÃ TỐI ƯU ANDROID AUTO" else "🚗 FIX LỖI ANDROID AUTO XE HƠI NGAY",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }
        }

        // Ô #30: ẨN CHẾ ĐỘ NHÀ PHÁT TRIỂN MỞ FULL CÁC ỨNG DỤNG YÊU CẦU BẢO MẬT CAO
        item(key = "tune_card_25") {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = BorderStroke(1.2.dp, if (tuneStatus.isDevModeStealthActive) MagicEmerald else MagicAmber.copy(alpha = 0.7f))
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TuneBadgeTag(text = "Ô #30", color = MagicEmerald)
                        Icon(Icons.Default.Shield, null, tint = MagicEmerald, modifier = Modifier.size(18.dp))
                    }
                    TuneStatusPill(
                        text = if (tuneStatus.isDevModeStealthActive) "ĐÃ TỰ ĐỘNG ẨN" else "TỰ ĐỘNG KHI WLAN",
                        isPositive = tuneStatus.isDevModeStealthActive
                    )
                }
                Text(
                    text = "Ẩn Trạng Thái Nhà Phát Triển & Tắt Sạch ADB",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "Khi WLAN kết nối, hệ thống tự ẩn ngầm cờ Nhà phát triển & USB để mở phần lớn ứng dụng tài chính, thanh toán và trò chơi mà không ngắt kết nối. Nếu gặp ứng dụng kiểm tra nghiêm ngặt vẫn báo lỗi gỡ lỗi/ADB (như SEC-10 hoặc Mã 10), hãy bấm nút bên dưới để tắt sạch luôn Gỡ lỗi Wi-Fi (adbd) & đưa USB về MTP (nếu trước đó đã tắt WLAN mà vẫn bị lưu cache trên máy, hãy vào Cài đặt -> Hệ thống -> Tùy chọn đặt lại -> Đặt lại tùy chọn nhà phát triển).",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
                Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = onEnableStealthDevMode,
                        modifier = Modifier.fillMaxHeight().weight(1.2f).defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald, contentColor = Color(0xFF020617))
                    ) {
                        Text(
                            text = "🛡️ TẮT SẠCH ADB\n& ẨN DEV MODE",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center,
                            lineHeight = 15.sp
                        )
                    }
                    OutlinedButton(
                        onClick = onRestoreDevModeVisibility,
                        modifier = Modifier.fillMaxHeight().weight(0.8f).defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp),
                        border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.6f))
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(Icons.Default.Visibility, null, tint = MagicCyanLight, modifier = Modifier.size(15.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(
                                text = "Hiện Lại\nDev",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MagicCyanLight,
                                textAlign = TextAlign.Center,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            }
        }
        }

        // Ô #31: MỞ KHÓA & GIẢI NÉN ANDROID/DATA & ANDROID/OBB
        item(key = "tune_card_26") {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.4f))
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TuneBadgeTag(text = "Ô #31", color = MagicCyan)
                        Icon(Icons.Default.Layers, null, tint = MagicCyan, modifier = Modifier.size(18.dp))
                    }
                    if (tuneStatus.isRestrictedStorageUnlocked) {
                        TuneStatusPill(text = "ĐÃ MỞ KHÓA", isPositive = true)
                    }
                }
                Text(
                    text = "Truy Cập & Giải Nén Android/data & obb",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "Kiểm tra, dọn bộ nhớ đệm qua ADB Shell, giải nén .zip sang MagicTune_Workspace/Extract_Out (tự đồng bộ thư mục obb/data nếu có) và cấp quyền AppOps quản lý tệp.",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
                if (tuneStatus.restrictedStorageSummary.isNotBlank()) {
                    Text(
                        text = tuneStatus.restrictedStorageSummary,
                        color = MagicCyanLight,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = onUnlockRestrictedStorage,
                        modifier = Modifier.fillMaxHeight().weight(1f).defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MagicCyan, contentColor = Color(0xFF020617))
                    ) {
                        Text("📂 MỞ KHÓA DATA/OBB", fontSize = 10.2.sp, fontWeight = FontWeight.Black)
                    }
                    Button(
                        onClick = onExtractAndSyncRestrictedData,
                        modifier = Modifier.fillMaxHeight().weight(1f).defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MagicSurfaceCard, contentColor = MagicEmeraldLight),
                        border = BorderStroke(1.dp, MagicEmerald.copy(alpha = 0.5f))
                    ) {
                        Text("📦 GIẢI NÉN & ĐỒNG BỘ", fontSize = 10.2.sp, fontWeight = FontWeight.Black)
                    }
                }
                Button(
                    onClick = onCleanRestrictedCaches,
                    modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 36.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MagicSurfaceCard, contentColor = MagicAmber),
                    border = BorderStroke(1.dp, MagicAmber.copy(alpha = 0.5f))
                ) {
                    Text("🧹 DỌN RÁC BỘ NHỚ ĐỆM ẨN (CACHE DATA/OBB)", fontSize = 10.5.sp, fontWeight = FontWeight.Black)
                }
            }
        }
        }

        // Ô #32: KIỂM SOÁT QUYỀN RIÊNG TƯ CẢM BIẾN CẤP ĐỘ SÂU
        item(key = "tune_card_27") {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = BorderStroke(1.2.dp, MagicRose.copy(alpha = 0.6f))
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TuneBadgeTag(text = "Ô #32", color = MagicRose)
                    Icon(Icons.Default.VisibilityOff, null, tint = MagicRoseLight, modifier = Modifier.size(18.dp))
                }
                Text(
                    text = "Kiểm Soát Quyền Riêng Tư Cảm Biến Sâu",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "Khóa cứng Camera, Microphone, Vị trí GPS và Bộ nhớ tạm (Clipboard) chống nghe lén & theo dõi ngầm.",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
                Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { onToggleDeepPrivacySensor("CAMERA", !tuneStatus.isCameraPrivacyBlocked) },
                        modifier = Modifier.fillMaxHeight().weight(1f).defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (tuneStatus.isCameraPrivacyBlocked) MagicRose else MagicSurfaceCard,
                            contentColor = Color.White
                        ),
                        border = BorderStroke(1.dp, MagicRose.copy(alpha = 0.5f))
                    ) {
                        Text(if (tuneStatus.isCameraPrivacyBlocked) "🔓 Mở Camera" else "📷 Khóa Camera", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = { onToggleDeepPrivacySensor("MICROPHONE", !tuneStatus.isMicPrivacyBlocked) },
                        modifier = Modifier.fillMaxHeight().weight(1f).defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (tuneStatus.isMicPrivacyBlocked) MagicRose else MagicSurfaceCard,
                            contentColor = Color.White
                        ),
                        border = BorderStroke(1.dp, MagicRose.copy(alpha = 0.5f))
                    ) {
                        Text(if (tuneStatus.isMicPrivacyBlocked) "🔓 Mở Micro" else "🎙️ Khóa Micro", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { onToggleDeepPrivacySensor("LOCATION", !tuneStatus.isLocationPrivacyBlocked) },
                        modifier = Modifier.fillMaxHeight().weight(1f).defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (tuneStatus.isLocationPrivacyBlocked) MagicRose else MagicSurfaceCard,
                            contentColor = Color.White
                        ),
                        border = BorderStroke(1.dp, MagicRose.copy(alpha = 0.5f))
                    ) {
                        Text(if (tuneStatus.isLocationPrivacyBlocked) "🔓 Mở Vị Trí" else "📍 Khóa Vị Trí", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = { onToggleDeepPrivacySensor("CLIPBOARD", !tuneStatus.isClipboardPrivacyBlocked) },
                        modifier = Modifier.fillMaxHeight().weight(1f).defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (tuneStatus.isClipboardPrivacyBlocked) MagicRose else MagicSurfaceCard,
                            contentColor = Color.White
                        ),
                        border = BorderStroke(1.dp, MagicRose.copy(alpha = 0.5f))
                    ) {
                        Text(if (tuneStatus.isClipboardPrivacyBlocked) "🔓 Mở Bộ Nhớ" else "📋 Chặn Đọc Copy", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        }

        // Ô #33: TỰ ĐỘNG HÓA & KỊCH BẢN HỆ THỐNG (MACRO GAME & DỌN ĐA NHIỆM)
        item(key = "tune_card_28") {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = BorderStroke(1.2.dp, MagicAmber.copy(alpha = 0.6f))
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TuneBadgeTag(text = "Ô #33", color = MagicAmber)
                    if (tuneStatus.activeAutomationMacro.isNotBlank()) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicAmber.copy(alpha = 0.18f))
                                .padding(horizontal = 7.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = tuneStatus.activeAutomationMacro,
                                color = MagicAmber,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
                Text(
                    text = "Tự Động Hóa & Kịch Bản Hệ Thống",
                    color = TextPrimary,
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "Kịch bản hóa các tác vụ hệ thống, giải phóng RAM sâu, khóa xung nhịp Game Turbo & mô phỏng thao tác.",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
                Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { onRunAutomationMacro("RAM_PURGE_BOOST") },
                        modifier = Modifier.fillMaxHeight().weight(1f).defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MagicSurfaceCard, contentColor = MagicCyanLight),
                        border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.5f))
                    ) {
                        Text("🧹 Giải Phóng RAM", fontSize = 10.8.sp, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = { onRunAutomationMacro("AUTO_SWIPE_CLEAN_RECENTS") },
                        modifier = Modifier.fillMaxHeight().weight(1f).defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MagicSurfaceCard, contentColor = MagicPurpleLight),
                        border = BorderStroke(1.dp, MagicPurple.copy(alpha = 0.5f))
                    ) {
                        Text("🔄 Dọn Đa Nhiệm", fontSize = 10.8.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { onRunAutomationMacro("GAME_TURBO_MACRO") },
                        modifier = Modifier.fillMaxHeight().weight(1f).defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MagicSurfaceCard, contentColor = MagicEmeraldLight),
                        border = BorderStroke(1.dp, MagicEmerald.copy(alpha = 0.5f))
                    ) {
                        Text("🎮 Khóa Xung Game", fontSize = 10.8.sp, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = { onRunAutomationMacro("SCREENSHOT_QUICK_KEY") },
                        modifier = Modifier.fillMaxHeight().weight(1f).defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MagicSurfaceCard, contentColor = MagicAmber),
                        border = BorderStroke(1.dp, MagicAmber.copy(alpha = 0.5f))
                    ) {
                        Text("📸 Chụp Màn Hình", fontSize = 10.8.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        }

        // Ô #34: TỐI ƯU MẠNG & KẾT NỐI (TĂNG TỐC WI-FI, WI-FI KÉP, SIÊU TIẾT KIỆM PIN LIÊN TỤC)
        item(key = "tune_card_29") {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = BorderStroke(1.2.dp, MagicCyan.copy(alpha = 0.6f))
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TuneBadgeTag(text = "Ô #34", color = MagicCyan)
                }
                Text(
                    text = "Tối Ưu Mạng & Siêu Tiết Kiệm Pin Kết Nối",
                    color = TextPrimary,
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "Tăng tốc độ Wi-Fi, ổn định Wi-Fi kép (2.4GHz + 5GHz), kích hoạt Link Turbo và siêu tiết kiệm pin modem dù Wi-Fi, 4G/5G, Bluetooth bật liên tục 24/7.",
                    color = TextSecondary,
                    fontSize = 11.sp
                )

                // Tính năng 1: Tăng tốc Wi-Fi & Giảm trễ
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
                    border = BorderStroke(1.dp, if (tuneStatus.isWifiSpeedBoosted) MagicEmerald.copy(alpha = 0.6f) else MagicBorder)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column(modifier = Modifier.fillMaxHeight().weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            if (tuneStatus.isWifiSpeedBoosted) {
                                Text(text = "✓ Đang Bật", color = MagicEmerald, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                            Text(text = "🚀 Tăng Tốc Độ Wi-Fi & Giảm Ping", color = MagicCyanLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(
                                text = "Tắt quét Wi-Fi nền định vị rác, bật Wi-Fi Low Latency Mode, giữ Wi-Fi luôn thức & tắt log chip Wi-Fi thừa.",
                                color = TextSecondary,
                                fontSize = 10.sp
                            )
                        }
                        Button(
                            onClick = onBoostWifiSpeed,
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (tuneStatus.isWifiSpeedBoosted) MagicEmerald else MagicCyan,
                                contentColor = Color(0xFF020617)
                            )
                        ) {
                            Text(text = if (tuneStatus.isWifiSpeedBoosted) "Tối Ưu Lại" else "Kích Hoạt", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Tính năng 2: Wi-Fi kép & Link Turbo
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
                    border = BorderStroke(1.dp, if (tuneStatus.isDualWifiBoosted) MagicEmerald.copy(alpha = 0.6f) else MagicBorder)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column(modifier = Modifier.fillMaxHeight().weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            if (tuneStatus.isDualWifiBoosted) {
                                Text(text = "✓ Đang Bật", color = MagicEmerald, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                            Text(text = "📶 Ổn Định Wi-Fi Kép & Link Turbo", color = MagicCyanLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(
                                text = "Kích hoạt 2 băng tần 2.4G+5G cùng lúc (Honor/Android), tăng tốc mạng song song Wi-Fi + Di động mượt mà.",
                                color = TextSecondary,
                                fontSize = 10.sp
                            )
                        }
                        Button(
                            onClick = onBoostDualWifi,
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (tuneStatus.isDualWifiBoosted) MagicEmerald else MagicCyan,
                                contentColor = Color(0xFF020617)
                            )
                        ) {
                            Text(text = if (tuneStatus.isDualWifiBoosted) "Tối Ưu Lại" else "Kích Hoạt", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Tính năng 3: Siêu tiết kiệm pin kết nối 24/7
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
                    border = BorderStroke(1.dp, if (tuneStatus.isAlwaysOnNetworkBatterySaved) MagicEmerald.copy(alpha = 0.6f) else MagicBorder)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min).padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column(modifier = Modifier.fillMaxHeight().weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            if (tuneStatus.isAlwaysOnNetworkBatterySaved) {
                                Text(text = "✓ Đang Bật", color = MagicEmerald, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                            Text(text = "🔋 Siêu Tiết Kiệm Pin Mạng 24/7", color = MagicEmeraldLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(
                                text = "Tắt 4G chờ ngầm khi có Wi-Fi (-25% pin), tắt quét Bluetooth ngầm (tai nghe/smartwatch vẫn kết nối), Smart 5G mát máy.",
                                color = TextSecondary,
                                fontSize = 10.sp
                            )
                        }
                        Button(
                            onClick = onApplyAlwaysOnNetworkBatterySaver,
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (tuneStatus.isAlwaysOnNetworkBatterySaved) MagicEmerald else MagicEmeraldLight,
                                contentColor = Color(0xFF020617)
                            )
                        ) {
                            Text(text = if (tuneStatus.isAlwaysOnNetworkBatterySaved) "Tối Ưu Lại" else "Kích Hoạt", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Nút Khôi Phục Cài Đặt Mạng Mặc Định
                Button(
                    onClick = onRestoreDefaultNetworkAndBattery,
                    modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 36.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MagicSurfaceCard, contentColor = MagicAmber),
                    border = BorderStroke(1.dp, MagicAmber.copy(alpha = 0.45f))
                ) {
                    Text(text = "🔄 Khôi Phục Cài Đặt Mạng & Pin Mặc Định", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        }

        // Ô #35: TRẢI NGHIỆM MƯỢT MÀ CHUẨN IOS APPLE (IOS PROMOTION & FLUID TOUCH)
        item(key = "tune_card_30") {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = BorderStroke(1.2.dp, MagicPurple.copy(alpha = 0.6f))
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TuneBadgeTag(text = "Ô #35", color = MagicPurple)
                    if (tuneStatus.isIosFluidSmoothnessActive) {
                        TuneQuickStatusChip(label = "✓ Mượt Chuẩn MagicOS", color = MagicEmerald)
                    }
                }
                Text(
                    text = "Trải Nghiệm Mượt Đỉnh Cao MagicOS",
                    color = TextPrimary,
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "Đưa độ mượt mà, phản hồi cử chỉ vuốt chạm và chuyển cảnh của điện thoại đạt độ dính tay tuyệt đối, phản hồi 0ms và không khựng khung hình (Zero Frame Drop) y hệt và vượt trội MagicOS độc quyền Honor.",
                    color = TextSecondary,
                    fontSize = 11.sp
                )

                Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = onApplyIosFluidSmoothness,
                        modifier = Modifier.fillMaxHeight().weight(1f).defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (tuneStatus.isIosFluidSmoothnessActive) MagicEmerald else MagicPurple,
                            contentColor = Color.White
                        ),
                        border = BorderStroke(1.dp, (if (tuneStatus.isIosFluidSmoothnessActive) MagicEmeraldLight else MagicPurpleLight).copy(alpha = 0.6f))
                    ) {
                        Text(
                            text = if (tuneStatus.isIosFluidSmoothnessActive) "✓ Đã Bật Mượt MagicOS" else "⚡ Kích Hoạt Mượt Chuẩn MagicOS",
                            fontSize = 11.2.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Button(
                        onClick = onRestoreDefaultSmoothnessAndThermal,
                        modifier = Modifier.fillMaxHeight().weight(1f).defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MagicSurfaceCard, contentColor = MagicAmber),
                        border = BorderStroke(1.dp, MagicAmber.copy(alpha = 0.5f))
                    ) {
                        Text(text = "🔄 Khôi Phục Độ Mượt", fontSize = 11.2.sp, fontWeight = FontWeight.Bold)
                    }
                }

                // Hàng 2: Engine Quản Lý Pin Chuẩn MagicOS Độc Lập (App Nap & Deep Standby)
                Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = onApplyIosBatteryEngine,
                        modifier = Modifier.fillMaxHeight().weight(1f).defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (tuneStatus.isIosBatteryEngineActive) MagicEmerald else MagicCyan,
                            contentColor = Color(0xFF020617)
                        )
                    ) {
                        Text(
                            text = if (tuneStatus.isIosBatteryEngineActive) "✓ Engine Pin MagicOS Đang Bật" else "🔋 Bật Engine Pin Chuẩn MagicOS",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    OutlinedButton(
                        onClick = onRestoreDefaultBatteryEngine,
                        modifier = Modifier.fillMaxHeight().weight(1f).defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, MagicBorder)
                    ) {
                        Text(
                            text = "Khôi Phục Pin Gốc",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Hàng 3: Mở Khóa Dung Lượng Pin Thực Honor (Phá khóa 80% ảo của Smart Battery Capacity)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MagicDarkBackground)
                        .border(
                            1.dp,
                            if (tuneStatus.isSmartBatteryCapacityUnlocked) MagicEmerald.copy(alpha = 0.55f) else MagicCyan.copy(alpha = 0.45f),
                            RoundedCornerShape(10.dp)
                        )
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    if (tuneStatus.isSmartBatteryCapacityUnlocked) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Start,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TuneQuickStatusChip(
                                label = "✓ Sạc Thực ${tuneStatus.honorBatteryChargeLimitPercent}%",
                                color = MagicEmerald
                            )
                        }
                    }
                    Text(
                        text = "🔋 Mở Khóa Dung Lượng Pin Thực (Phá khóa 80% ảo Honor)",
                        color = if (tuneStatus.isSmartBatteryCapacityUnlocked) MagicEmeraldLight else MagicCyanLight,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        text = "Khắc phục triệt để tình trạng Honor bật 'Dung lượng pin thông minh' khóa mất 15–20% dung lượng thật (báo 100% nhưng thực tế chỉ nạp ~80%). Bạn có thể chọn chỉ giữ 3% đệm bảo vệ (nạp thực 97%) hoặc mở 100% dung lượng vật lý:",
                        color = TextSecondary,
                        fontSize = 10.5.sp,
                        lineHeight = 14.5.sp
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Button(
                            onClick = { onToggleDeviceFeature("unlock_battery_97", false) },
                            modifier = Modifier.fillMaxHeight().weight(1f).defaultMinSize(minHeight = 36.dp),
                            shape = RoundedCornerShape(9.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (tuneStatus.isSmartBatteryCapacityUnlocked && tuneStatus.honorBatteryChargeLimitPercent < 100) MagicEmerald else MagicCyan,
                                contentColor = Color(0xFF020617)
                            )
                        ) {
                            Text(
                                text = "⚡ Sạc Thực 97% (Khóa 3%)",
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Button(
                            onClick = { onToggleDeviceFeature("unlock_battery_100", false) },
                            modifier = Modifier.fillMaxHeight().weight(1f).defaultMinSize(minHeight = 36.dp),
                            shape = RoundedCornerShape(9.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (tuneStatus.isSmartBatteryCapacityUnlocked && tuneStatus.honorBatteryChargeLimitPercent >= 100) MagicEmerald else MagicPurple,
                                contentColor = Color.White
                            )
                        ) {
                            Text(
                                text = "🔓 Mở 100% Dung Lượng",
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OutlinedButton(
                            onClick = { com.example.data.MagicTuneRepository.openHonorBatterySettings(context) },
                            modifier = Modifier.fillMaxHeight().weight(1f).defaultMinSize(minHeight = 36.dp),
                            shape = RoundedCornerShape(9.dp),
                            border = BorderStroke(1.dp, MagicAmber.copy(alpha = 0.6f))
                        ) {
                            Text(
                                text = "⚙️ Cài Đặt Pin Honor",
                                color = MagicAmber,
                                fontSize = 10.2.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        OutlinedButton(
                            onClick = { onToggleDeviceFeature("restore_battery_cap", true) },
                            modifier = Modifier.fillMaxHeight().weight(1f).defaultMinSize(minHeight = 36.dp),
                            shape = RoundedCornerShape(9.dp),
                            border = BorderStroke(1.dp, MagicBorder)
                        ) {
                            Text(
                                text = "🔄 Về Mặc Định Honor",
                                color = TextSecondary,
                                fontSize = 10.2.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Chi tiết các công nghệ MagicOS tích hợp
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MagicSurfaceCard.copy(alpha = 0.7f))
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(text = "• Phản hồi cảm ứng 0ms: Ưu tiên luồng UI, chạm là phản hồi tức thì.", fontSize = 10.sp, color = MagicCyanLight)
                    Text(text = "• VSYNC SurfaceFlinger Render Sớm 0.5ms: Loại bỏ triệt để micro-stutter.", fontSize = 10.sp, color = MagicCyanLight)
                    Text(text = "• ProMotion Khóa Tần Số Quét Cao: Không tụt khung hình khi cuộn lướt app.", fontSize = 10.sp, color = MagicCyanLight)
                    Text(text = "• Hoạt ảnh vật lý đàn hồi 0.5x: Chuyển cảnh mượt mà, tốc độ tự nhiên.", fontSize = 10.sp, color = MagicCyanLight)
                }
            }
        }
        }

        // Footer dẫn sang trang Tối ưu Đa Hãng
        item(key = "tune_footer") {
            HonorOptimizationDisclaimerFooter(onNavigateToUniversalFix = onNavigateToUniversalFix)
        }
    }

    // DIALOG CẢNH BÁO KHÓA ĐỎ TÍNH NĂNG TRỢ NĂNG NGẦM (CẦN KẾT NỐI WI-FI LẦN ĐẦU)
    if (showWlanRequiredDialog) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showWlanRequiredDialog = false },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = MagicRose)
                    Text(
                        text = "🔒 CẦN KẾT NỐI GỠ LỖI WI-FI LẦN ĐẦU",
                        color = MagicRose,
                        fontSize = 14.5.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            },
            text = {
                ScrollableDialogColumn(
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    thumbColor = MagicRose
                ) {
                    Text(
                        text = "Tính năng này cần Trợ Năng & Duy trì chạy nền vĩnh viễn để hoạt động ổn định 100% không bao giờ bị MagicOS thu hồi quyền.",
                        color = TextPrimary.copy(alpha = 0.95f),
                        fontSize = 12.sp,
                        lineHeight = 16.5.sp
                    )
                    Text(
                        text = "Vui lòng kết nối Gỡ lỗi Wi-Fi 1 lần (Mã 6 số). Ứng dụng sẽ tự động chạy lệnh ADB khóa quyền vĩnh viễn và mở khóa toàn bộ tính năng ngay lập tức!",
                        color = Color(0xFFFEF08A),
                        fontSize = 11.5.sp,
                        lineHeight = 16.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showWlanRequiredDialog = false
                        onOpenDirectWlanTab()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MagicRose, contentColor = Color.White),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("⚡ BẤM KẾT NỐI (MÃ 6 SỐ) NGAY", fontWeight = FontWeight.Black, fontSize = 11.5.sp)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showWlanRequiredDialog = false },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Để sau", color = TextPrimary.copy(alpha = 0.7f), fontSize = 11.5.sp)
                }
            },
            containerColor = MagicSurfaceDark,
            shape = RoundedCornerShape(16.dp)
        )
    }
}

@Composable
private fun TuneQuickStatusChip(
    label: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.14f))
            .border(1.dp, color.copy(alpha = 0.45f), RoundedCornerShape(8.dp))
            .padding(horizontal = 6.dp, vertical = 5.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = TextPrimary,
            fontSize = 9.8.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun TuneBadgeTag(
    text: String,
    color: Color
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(color.copy(alpha = 0.22f))
            .border(1.dp, color.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
            .padding(horizontal = 7.dp, vertical = 2.dp)
    ) {
        Text(
            text = text,
            color = TextPrimary,
            fontSize = 10.sp,
            fontWeight = FontWeight.Black
        )
    }
}

@Composable
private fun TuneStatusPill(
    text: String,
    isPositive: Boolean
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (isPositive) MagicEmerald.copy(alpha = 0.2f) else MagicAmber.copy(alpha = 0.18f))
            .padding(horizontal = 7.dp, vertical = 3.dp)
    ) {
        Text(
            text = text,
            color = if (isPositive) MagicEmeraldLight else MagicAmber,
            fontSize = 9.5.sp,
            fontWeight = FontWeight.Black
        )
    }
}
