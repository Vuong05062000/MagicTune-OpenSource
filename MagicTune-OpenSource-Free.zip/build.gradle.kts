import java.io.File
import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.google.devtools.ksp)
}

// Private values are intentionally not bundled with the portable source project.
val privateProperties = Properties().apply {
    rootProject.file("private.properties").takeIf { it.isFile }?.inputStream()?.use { load(it) }
}
fun privateString(name: String): String {
    val value = System.getenv("MAGICTUNE_" + name) ?: privateProperties.getProperty(name, "")
    return "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"")
        .replace("\r", "\\r").replace("\n", "\\n") + "\""
}
val signingPropertiesFile = System.getenv("MAGICTUNE_SIGNING_PROPERTIES")?.let { file(it) }
    ?: rootProject.file("keystore.properties")
val signingProperties = Properties().apply {
    if (signingPropertiesFile.isFile) signingPropertiesFile.inputStream().use { load(it) }
}

android {
    namespace = "com.example"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.magictune.tool"
        minSdk = 24
        targetSdk = 36
        versionCode = 198
        versionName = "8.2.1"
        ndk { abiFilters += listOf("armeabi-v7a", "arm64-v8a") }
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        for (name in listOf("ADMIN_EMAIL", "ADMIN_PHONE", "PRO_SECRET_SALT", "PRO_ACCOUNT_SALT", "GROQ_API_KEY")) {
            buildConfigField("String", name, privateString(name))
        }
    }
    packaging { jniLibs { useLegacyPackaging = true } }
    signingConfigs {
        if (signingPropertiesFile.isFile) {
            create("release") {
                fun required(name: String) = requireNotNull(signingProperties.getProperty(name)) {
                    "Missing signing property: " + name
                }
                storeFile = File(signingPropertiesFile.absoluteFile.parentFile, required("storeFile"))
                storeType = signingProperties.getProperty("storeType", "PKCS12")
                storePassword = required("storePassword")
                keyAlias = required("keyAlias")
                keyPassword = required("keyPassword")
                enableV1Signing = true
                enableV2Signing = true
                enableV3Signing = true
                enableV4Signing = false
            }
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // No debug-key fallback: without a private key, release output stays unsigned.
            if (signingPropertiesFile.isFile) signingConfig = signingConfigs.getByName("release")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    sourceSets {
        getByName("main") {
            manifest.srcFile("AndroidManifest.xml")
            java.srcDirs("src/main/java")
            res.srcDirs("res")
        }
        getByName("test") { java.srcDirs("src/test/java") }
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.profileinstaller)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.activity.compose)

    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.core)
    implementation("androidx.compose.material:material-icons-extended")
    implementation(libs.androidx.navigation.compose)

    implementation(libs.shizuku.api)
    implementation(libs.shizuku.provider)

    implementation(libs.coil.compose)
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.kotlinx.coroutines.core)
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.10.2")
    implementation(libs.play.services.location)

    // ADB Direct WLAN & TLS
    implementation(libs.libadb.android)
    // implementation(libs.sun.security.android) // Đã thay bằng chuẩn ASN.1 DER X.509v3 thuần túy để tránh lỗi X500Name trên ART
    implementation(libs.conscrypt.android)

    // ML Kit
    implementation(libs.mlkit.text.recognition)
    implementation(libs.mlkit.text.recognition.chinese)

    // Tests
    testImplementation(libs.junit)
    testImplementation(libs.robolectric)
    testImplementation(libs.androidx.junit)
    testImplementation(libs.androidx.core)
    testImplementation(libs.kotlinx.coroutines.test)
}

configurations.matching { it.name.contains("UnitTest") }.configureEach {
    exclude(group = "org.conscrypt", module = "conscrypt-android")
}

