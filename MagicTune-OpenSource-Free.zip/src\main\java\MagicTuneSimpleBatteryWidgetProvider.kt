package com.example.core.widget
import com.example.core.i18n.AppLanguageManager.tr

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Build
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.core.ai.AiPowerAutopilotManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Widget Pin Cơ Bản 2×2 — Tối giản, gọn mắt, đủ màu sắc dành cho người dùng thích sự đơn giản.
 * - Khi sạc: chỉ hiển thị DUY NHẤT 1 icon phích điện (🔌) gọn gàng.
 * - Hiển thị pin thiết bị Bluetooth đang kết nối dưới dạng các vòng tròn nhỏ ngay dưới thanh pin chính.
 */
class MagicTuneSimpleBatteryWidgetProvider : AppWidgetProvider() {

    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: android.os.Bundle?
    ) {
        super.onAppWidgetOptionsChanged(context, appWidgetManager, appWidgetId, newOptions)
        updateWidget(context.applicationContext ?: context, appWidgetManager, appWidgetId)
    }

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        val appCtx = context.applicationContext ?: context
        val idsCopy = appWidgetIds.copyOf()
        val pendingResult = goAsync()
        val finishedFlag = AtomicBoolean(false)
        fun finishSafely() {
            if (finishedFlag.compareAndSet(false, true)) {
                try { pendingResult.finish() } catch (_: Throwable) {}
            }
        }
        CoroutineScope(Dispatchers.IO).launch {
            try {
                for (appWidgetId in idsCopy) {
                    updateWidget(appCtx, appWidgetManager, appWidgetId)
                }
            } catch (_: Throwable) {
            } finally {
                finishSafely()
            }
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (WidgetCycleDisplay.toggle(context, intent, MagicTuneSimpleBatteryWidgetProvider::class.java)) return
        super.onReceive(context, intent)
        val appCtx = context.applicationContext ?: context
        when (intent.action) {
            ACTION_BT_BATTERY_LEVEL_CHANGED,
            BluetoothDevice.ACTION_ACL_CONNECTED,
            BluetoothDevice.ACTION_ACL_DISCONNECTED -> {
                recordBluetoothBroadcast(appCtx, intent)
                val pendingResult = goAsync()
                val finishedFlag = AtomicBoolean(false)
                fun finishSafely() {
                    if (finishedFlag.compareAndSet(false, true)) {
                        try { pendingResult.finish() } catch (_: Throwable) {}
                    }
                }
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        notifyAllWidgets(appCtx)
                    } finally {
                        finishSafely()
                    }
                }
            }
            ACTION_SIMPLE_BATTERY_REFRESH,
            Intent.ACTION_POWER_CONNECTED,
            Intent.ACTION_POWER_DISCONNECTED,
            Intent.ACTION_BATTERY_LOW,
            Intent.ACTION_BATTERY_OKAY -> {
                val pendingResult = goAsync()
                val finishedFlag = AtomicBoolean(false)
                fun finishSafely() {
                    if (finishedFlag.compareAndSet(false, true)) {
                        try { pendingResult.finish() } catch (_: Throwable) {}
                    }
                }
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        notifyAllWidgets(appCtx)
                    } finally {
                        finishSafely()
                    }
                }
            }
        }
    }

    companion object {
        const val ACTION_SIMPLE_BATTERY_REFRESH = "com.example.core.widget.ACTION_SIMPLE_BATTERY_REFRESH"
        const val ACTION_BT_BATTERY_LEVEL_CHANGED = "android.bluetooth.device.action.BATTERY_LEVEL_CHANGED"
        private const val EXTRA_BT_BATTERY_LEVEL = "android.bluetooth.device.extra.BATTERY_LEVEL"

        private data class BtDeviceBattery(
            val address: String,
            val shortName: String,
            val iconGlyph: String,
            val batteryPct: Int // 0..100
        )

        // Bộ nhớ đệm % pin nhận được từ broadcast BATTERY_LEVEL_CHANGED (mac -> batteryPct)
        private val cachedBtBatteryByAddress = ConcurrentHashMap<String, Int>()
        private val connectedBtAddresses = ConcurrentHashMap.newKeySet<String>()

        @Suppress("DEPRECATION")
        fun recordBluetoothBroadcast(context: Context, intent: Intent?) {
            if (intent == null) return
            try {
                val device: BluetoothDevice? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                } else {
                    intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                }
                val address = device?.address ?: return
                when (intent.action) {
                    ACTION_BT_BATTERY_LEVEL_CHANGED -> {
                        val level = intent.getIntExtra(EXTRA_BT_BATTERY_LEVEL, -1)
                        if (level in 0..100) {
                            cachedBtBatteryByAddress[address] = level
                            connectedBtAddresses.add(address)
                        }
                    }
                    BluetoothDevice.ACTION_ACL_CONNECTED -> {
                        connectedBtAddresses.add(address)
                    }
                    BluetoothDevice.ACTION_ACL_DISCONNECTED -> {
                        connectedBtAddresses.remove(address)
                        cachedBtBatteryByAddress.remove(address)
                    }
                }
            } catch (_: Throwable) {}
        }

        fun notifyAllWidgets(context: Context, customStatusLine1Override: String? = null) {
            try {
                val appCtx = context.applicationContext
                val pm = appCtx.getSystemService(Context.POWER_SERVICE) as? android.os.PowerManager
                if (pm != null && !pm.isInteractive) return
                val awm = AppWidgetManager.getInstance(appCtx)
                val ids = awm.getAppWidgetIds(
                    ComponentName(appCtx, MagicTuneSimpleBatteryWidgetProvider::class.java)
                )
                for (id in ids) {
                    updateWidget(appCtx, awm, id, customStatusLine1Override)
                }
            } catch (_: Throwable) {}
        }

        fun updateWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int,
            customStatusLine1Override: String? = null
        ) {
            try {
                val batteryIntent: Intent? = try {
                    context.applicationContext.registerReceiver(
                        null,
                        IntentFilter(Intent.ACTION_BATTERY_CHANGED)
                    )
                } catch (_: Throwable) {
                    null
                }
                val data = BatteryInfoReader.read(context, batteryIntent, lightweight = true)
                val isCharging = data.isCharging
                val views = RemoteViews(context.packageName, R.layout.widget_battery_simple_2x2)
                WidgetBackgroundOpacityHelper.applyBackground(context, views, R.id.widget_simple_bat_container, WidgetBackgroundOpacityHelper.BgStyle.DEFAULT)
                WidgetCycleDisplay.bind(context, views, appWidgetId, batteryIntent, MagicTuneSimpleBatteryWidgetProvider::class.java)
                val widgetHeightDp = appWidgetManager.getAppWidgetOptions(appWidgetId)
                    ?.getInt(if (context.resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE) AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT else AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 110) ?: 110
                val fontScale = context.resources.configuration.fontScale.coerceAtLeast(1f)
                val compactLayout = widgetHeightDp / fontScale < 240f
                if (compactLayout) {
                    val density = context.resources.displayMetrics.density
                    val horizontalPadding = (10f * density).toInt()
                    val verticalPadding = (3f * density).toInt()
                    views.setViewPadding(R.id.widget_simple_bat_container, horizontalPadding, verticalPadding, horizontalPadding, verticalPadding)
                    views.setTextViewTextSize(R.id.widget_phone_name, TypedValue.COMPLEX_UNIT_SP, 11.5f / fontScale)
                    views.setTextViewTextSize(R.id.widget_simple_bat_status, TypedValue.COMPLEX_UNIT_SP, 11f / fontScale)
                    views.setTextViewTextSize(R.id.widget_simple_bat_temp, TypedValue.COMPLEX_UNIT_SP, 10.5f / fontScale)
                    views.setTextViewTextSize(R.id.widget_simple_bat_pct, TypedValue.COMPLEX_UNIT_SP, 26f / fontScale)
                    views.setTextViewTextSize(R.id.widget_simple_bat_line1, TypedValue.COMPLEX_UNIT_SP, 11f / fontScale)
                    views.setTextViewTextSize(R.id.widget_simple_bat_line2, TypedValue.COMPLEX_UNIT_SP, 11f / fontScale)
                    views.setTextViewTextSize(R.id.widget_cycle_text, TypedValue.COMPLEX_UNIT_SP, 11f / fontScale)
                    views.setTextViewTextSize(R.id.widget_cycle_toggle, TypedValue.COMPLEX_UNIT_SP, 11f / fontScale)
                    views.setViewPadding(R.id.widget_cycle_toggle, (3f * density).toInt(), verticalPadding, (3f * density).toInt(), verticalPadding)
                }

                // 1. Trạng thái gọn (góc trên trái) — Khi sạc CHỈ dùng duy nhất 1 icon phích điện (🔌)
                val statusText = if (isCharging) {
                    when {
                        data.batteryPct >= 100 && !data.isFullySaturated -> tr("⚡ NGÂM 100%")
                        data.batteryPct >= 100 -> "🔌 NO 100%"
                        data.currentWatts >= 35.0 -> tr("🔌 SIÊU NHANH")
                        data.currentWatts >= 18.0 -> tr("🔌 SẠC NHANH")
                        else -> tr("🔌 ĐANG SẠC")
                    }
                } else {
                    if (data.batteryPct <= 20) "⚠️ PIN YẾU" else "🔋 ĐANG DÙNG"
                }
                val statusColor = when {
                    isCharging && data.batteryPct >= 100 && data.isFullySaturated -> Color.parseColor("#34D399")
                    isCharging && data.batteryPct >= 100 && !data.isFullySaturated -> Color.parseColor("#38BDF8")
                    isCharging -> Color.parseColor("#FBBF24")
                    data.batteryPct <= 20 -> Color.parseColor("#FB7185")
                    data.batteryPct <= 40 -> Color.parseColor("#FBBF24")
                    else -> Color.parseColor("#34D399")
                }
                views.setTextViewText(R.id.widget_simple_bat_status, statusText)
                views.setTextColor(R.id.widget_simple_bat_status, statusColor)

                // 2. Nhiệt độ pin (góc trên phải)
                val tempColor = when {
                    !data.isBatteryTemperatureAvailable -> Color.parseColor("#94A3B8")
                    data.tempCelsius >= 41.0 -> Color.parseColor("#F87171")
                    data.tempCelsius >= 37.5 -> Color.parseColor("#FBBF24")
                    else -> Color.parseColor("#7DD3FC")
                }
                views.setTextViewText(
                    R.id.widget_simple_bat_temp,
                    if (data.isBatteryTemperatureAvailable) {
                        String.format(Locale.US, "🌡️ %.1f°C", data.tempCelsius)
                    } else {
                        "🌡️ --°C"
                    }
                )
                views.setTextColor(R.id.widget_simple_bat_temp, tempColor)

                // 3. Đọc pin thiết bị Bluetooth đang kết nối (tối đa 4 vòng tròn nhỏ dưới thanh pin chính)
                val btDevices = readConnectedBluetoothBatteries(context)
                val hasBtDevices = btDevices.isNotEmpty()

                // 4. Phần trăm pin lớn + Thanh tiến trình (tự thu nhẹ cỡ chữ khi có vòng tròn Bluetooth cho thoáng)
                // Khi sạc: hiển thị phần trăm có số thập phân tăng dần (VD: 86.35%) thay vì integer nhảy lẹ.
                val displayPct = if (isCharging) BatteryInfoReader.getSmoothBatteryPct(context, data) else data.batteryPct.toDouble()
                val pctColor = when {
                    isCharging -> Color.parseColor("#34D399")
                    data.batteryPct <= 20 -> Color.parseColor("#FB7185")
                    data.batteryPct <= 35 -> Color.parseColor("#FBBF24")
                    data.batteryPct <= 60 -> Color.parseColor("#38BDF8")
                    else -> Color.parseColor("#34D399")
                }
                views.setTextViewText(R.id.widget_simple_bat_pct, if (isCharging) String.format(Locale.US, "%.2f%%", displayPct) else "${data.batteryPct}%")
                views.setTextColor(R.id.widget_simple_bat_pct, pctColor)
                views.setTextViewTextSize(
                    R.id.widget_simple_bat_pct,
                    TypedValue.COMPLEX_UNIT_SP,
                    (if (compactLayout) {
                        if (widgetHeightDp < 155) 26f else 32f
                    } else if (hasBtDevices) 34f else 42f) / fontScale
                )
                views.setProgressBar(R.id.widget_simple_bat_progress, 100, displayPct.coerceIn(0.0, 100.0).toInt(), false)
                if (isCharging && !com.example.core.service.MagicTuneKeepAliveService.isServiceRunning) {
                    try {
                        com.example.core.service.MagicTuneKeepAliveService.syncServiceNeed(
                            context.applicationContext ?: context,
                            tr("Đang cập nhật % pin thời gian thực")
                        )
                    } catch (_: Throwable) {}
                } else if (!isCharging) {
                    try {
                        BatteryWidgetRefreshReceiver.stopRefreshAlarm(context.applicationContext ?: context)
                    } catch (_: Throwable) {}
                }

                // 5. Render hàng vòng tròn nhỏ Bluetooth ngay dưới thanh pin chính
                val slotIds = intArrayOf(
                    R.id.widget_simple_bt_slot_1,
                    R.id.widget_simple_bt_slot_2,
                    R.id.widget_simple_bt_slot_3,
                    R.id.widget_simple_bt_slot_4
                )
                val ringIds = intArrayOf(
                    R.id.widget_simple_bt_ring_1,
                    R.id.widget_simple_bt_ring_2,
                    R.id.widget_simple_bt_ring_3,
                    R.id.widget_simple_bt_ring_4
                )
                val nameIds = intArrayOf(
                    R.id.widget_simple_bt_name_1,
                    R.id.widget_simple_bt_name_2,
                    R.id.widget_simple_bt_name_3,
                    R.id.widget_simple_bt_name_4
                )

                if (hasBtDevices) {
                    views.setViewVisibility(R.id.widget_simple_bat_bt_row, View.VISIBLE)
                    for (i in 0 until 4) {
                        val bt = btDevices.getOrNull(i)
                        if (bt != null) {
                            views.setViewVisibility(slotIds[i], View.VISIBLE)
                            val ringBmp = createBluetoothRingBitmap(bt.batteryPct)
                            views.setImageViewBitmap(ringIds[i], ringBmp)
                            views.setTextViewText(nameIds[i], "${bt.iconGlyph}${bt.shortName}")
                        } else {
                            views.setViewVisibility(slotIds[i], View.GONE)
                        }
                    }
                } else {
                    views.setViewVisibility(R.id.widget_simple_bat_bt_row, View.GONE)
                }

                // 6. Hai dòng thông tin cơ bản ở đáy — Khi sạc KHÔNG lặp thêm icon sạc/phích điện thứ 2
                if (isCharging) {
                    if (data.batteryPct >= 100) {
                        if (!data.isFullySaturated) {
                            val remText = if (data.saturationRemainingMinutes > 0) {
                                String.format(Locale.US, "Nạp bù ion ~%dp", data.saturationRemainingMinutes)
                            } else {
                                tr("Nạp bù ion")
                            }
                            views.setTextViewText(R.id.widget_simple_bat_line1, remText)
                            views.setTextColor(R.id.widget_simple_bat_line1, Color.parseColor("#38BDF8"))
                            views.setTextViewText(R.id.widget_simple_bat_line2, tr("Đang nạp tiếp đến khi dòng về ≤ 1W"))
                            views.setTextColor(R.id.widget_simple_bat_line2, Color.parseColor("#BAE6FD"))
                        } else {
                            views.setTextViewText(
                                R.id.widget_simple_bat_line1,
                                tr("Đã ngắt dòng an toàn")
                            )
                            views.setTextColor(R.id.widget_simple_bat_line1, Color.parseColor("#34D399"))
                            views.setTextViewText(R.id.widget_simple_bat_line2, tr("Đã no 100% thực tế • Hãy rút sạc"))
                            views.setTextColor(R.id.widget_simple_bat_line2, Color.parseColor("#A7F3D0"))
                        }
                    } else {
                        fun formatEta(mins: Int): String = if (mins >= 60) "${mins / 60}h ${mins % 60}p" else "${mins}p"
                        val cleanSpeedLabel = when {
                            data.currentWatts >= 35.0 -> tr("Siêu nhanh")
                            data.currentWatts >= 18.0 -> tr("Sạc nhanh")
                            else -> tr("Sạc thường")
                        }
                        val etaOnlyLine = if (data.minutesTo100 > 0) {
                            tr("Đầy 100% ~${formatEta(data.minutesTo100)} • No pin ~${formatEta(data.minutesToFull)}")
                        } else {
                            tr("Đang tính thời gian đầy...")
                        }
                        views.setTextViewText(
                            R.id.widget_simple_bat_line1,
                            etaOnlyLine
                        )
                        views.setTextColor(R.id.widget_simple_bat_line1, Color.parseColor("#FBBF24"))
                        views.setTextViewText(
                            R.id.widget_simple_bat_line2,
                            String.format(Locale.US, "%s • %.2fV", cleanSpeedLabel, data.voltageV)
                        )
                        views.setTextColor(R.id.widget_simple_bat_line2, Color.parseColor("#A7F3D0"))
                    }
                } else {
                    val drain = try {
                        AiPowerAutopilotManager.getDrainRateAnalytics(
                            context = context,
                            lightweightRead = true,
                            preloadedBattery = data
                        )
                    } catch (_: Throwable) {
                        null
                    }
                    val onRate = drain?.screenOnDrainPctPerHour
                    val offRate = drain?.screenOffDrainPctPerHour
                    val onPrefix = if (drain?.screenOnSource == "Ước tính") "~" else ""
                    val offPrefix = if (drain?.screenOffSource == "Ước tính nền") "~" else ""
                    val onStr = onRate?.let {
                        String.format(Locale.US, "%s%.1f%%/h", onPrefix, it)
                    } ?: "--%/h"
                    val offStr = offRate?.let {
                        String.format(Locale.US, "%s%.1f%%/h", offPrefix, it)
                    } ?: "--%/h"

                    var estOnH = data.estimatedScreenOnHours
                    var estOnM = data.estimatedScreenOnMins
                    var estStandbyH = data.estimatedStandbyHours
                    if (data.batteryPct > 0) {
                        val totalMins = AiPowerAutopilotManager.estimateScreenOnMinutes(
                            batteryPct = data.batteryPct,
                            screenOnDrainPctPerHour = onRate,
                            designCapacityMah = data.designCapacityMah
                        )
                        estOnH = totalMins / 60
                        estOnM = totalMins % 60
                    }
                    if (offRate != null && offRate > 0.1 && data.batteryPct > 0) {
                        estStandbyH = (data.batteryPct.toDouble() / maxOf(offRate, 1.1)).toInt().coerceIn(2, 96)
                    }

                    views.setTextViewText(R.id.widget_simple_bat_line1, "☀️ $onStr • 🌙 $offStr")
                    views.setTextColor(R.id.widget_simple_bat_line1, Color.parseColor("#38BDF8"))
                    views.setTextViewText(
                        R.id.widget_simple_bat_line2,
                        tr("⏱️ ~${estOnH}h ${estOnM}p • Chờ ~${estStandbyH}h")
                    )
                    views.setTextColor(R.id.widget_simple_bat_line2, Color.parseColor("#CBD5E1"))
                }

                if (!customStatusLine1Override.isNullOrBlank()) {
                    views.setTextViewText(R.id.widget_simple_bat_line1, customStatusLine1Override)
                    views.setTextColor(R.id.widget_simple_bat_line1, Color.parseColor("#38BDF8"))
                }

                // 7. Chạm vào phần giữa/đáy để làm mới số liệu & pin Bluetooth ngay lập tức
                val refreshIntent = Intent(context, MagicTuneSimpleBatteryWidgetProvider::class.java).apply {
                    action = ACTION_SIMPLE_BATTERY_REFRESH
                }
                val refreshPi = PendingIntent.getBroadcast(
                    context,
                    appWidgetId + 8700,
                    refreshIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_simple_bat_container, refreshPi)
                views.setOnClickPendingIntent(R.id.widget_simple_bat_body, refreshPi)

                // 8. Chạm vào thanh trạng thái trên cùng để mở thẳng Tab 7 (Pin & Soi Ngầm)
                val openBatteryTabIntent = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    putExtra("TARGET_TAB", "BG_DRAIN_MONITOR")
                }
                val openPi = PendingIntent.getActivity(
                    context,
                    appWidgetId + 8800,
                    openBatteryTabIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_simple_bat_header, openPi)

                appWidgetManager.updateAppWidget(appWidgetId, views)
            } catch (_: Throwable) {}
        }

        @SuppressLint("MissingPermission")
        private fun readConnectedBluetoothBatteries(context: Context): List<BtDeviceBattery> {
            return try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val granted = ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.BLUETOOTH_CONNECT
                    ) == PackageManager.PERMISSION_GRANTED
                    if (!granted) return emptyList()
                }
                val bm = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager ?: return emptyList()
                val adapter = bm.adapter ?: return emptyList()
                if (!adapter.isEnabled) return emptyList()

                val bonded = adapter.bondedDevices.orEmpty()
                if (bonded.isEmpty()) return emptyList()

                val isConnectedMethod = try {
                    BluetoothDevice::class.java.getMethod("isConnected")
                } catch (_: Throwable) {
                    null
                }
                val getBatteryLevelMethod = try {
                    BluetoothDevice::class.java.getMethod("getBatteryLevel")
                } catch (_: Throwable) {
                    null
                }

                val list = ArrayList<BtDeviceBattery>(4)
                for (device in bonded) {
                    val addr = device.address ?: continue
                    val connected = try {
                        (isConnectedMethod?.invoke(device) as? Boolean) == true
                    } catch (_: Throwable) {
                        addr in connectedBtAddresses
                    }
                    if (!connected) {
                        connectedBtAddresses.remove(addr)
                        continue
                    }

                    val livePct = try {
                        (getBatteryLevelMethod?.invoke(device) as? Int) ?: -1
                    } catch (_: Throwable) {
                        -1
                    }
                    val pct = when {
                        livePct in 0..100 -> {
                            cachedBtBatteryByAddress[addr] = livePct
                            livePct
                        }
                        else -> cachedBtBatteryByAddress[addr] ?: -1
                    }
                    if (pct !in 0..100) continue

                    val rawName = try {
                        device.name.orEmpty().trim()
                    } catch (_: Throwable) {
                        ""
                    }.ifBlank { "BT" }

                    val glyph = resolveBluetoothGlyph(device, rawName)
                    val shortName = formatShortBtName(rawName)
                    list.add(
                        BtDeviceBattery(
                            address = addr,
                            shortName = shortName,
                            iconGlyph = glyph,
                            batteryPct = pct
                        )
                    )
                }
                list.sortedBy { it.batteryPct }.take(4)
            } catch (_: Throwable) {
                emptyList()
            }
        }

        @SuppressLint("MissingPermission")
        private fun resolveBluetoothGlyph(device: BluetoothDevice, name: String): String {
            val lower = name.lowercase(Locale.US)
            if (lower.contains("watch") || lower.contains("band") || lower.contains("gt") || lower.contains("fit")) {
                return "⌚"
            }
            if (lower.contains("bud") || lower.contains("pod") || lower.contains("ear") ||
                lower.contains("head") || lower.contains("choice") || lower.contains("freebuds") || lower.contains("tws")
            ) {
                return "🎧"
            }
            if (lower.contains("speak") || lower.contains("jbl") || lower.contains("marshal") ||
                lower.contains("bose") || lower.contains("sony srs") || lower.contains("sound")
            ) {
                return "🔊"
            }
            if (lower.contains("pen") || lower.contains("pencil") || lower.contains("stylus")) {
                return "✏️"
            }
            if (lower.contains("mouse") || lower.contains("chuot")) return "🖱️"
            if (lower.contains("key") || lower.contains("kbd")) return "⌨️"

            return try {
                val major = device.bluetoothClass?.majorDeviceClass
                val devClass = device.bluetoothClass?.deviceClass
                when {
                    major == BluetoothClass.Device.Major.WEARABLE -> "⌚"
                    devClass == BluetoothClass.Device.AUDIO_VIDEO_LOUDSPEAKER ||
                        devClass == BluetoothClass.Device.AUDIO_VIDEO_PORTABLE_AUDIO -> "🔊"
                    major == BluetoothClass.Device.Major.AUDIO_VIDEO -> "🎧"
                    major == BluetoothClass.Device.Major.PERIPHERAL -> "⌨️"
                    else -> "🎧"
                }
            } catch (_: Throwable) {
                "🎧"
            }
        }

        private fun formatShortBtName(rawName: String): String {
            val cleaned = rawName
                .replace(Regex("(?i)\\b(honor|huawei|apple|samsung|xiaomi|redmi|sony|jbl)\\b"), "")
                .trim()
                .ifBlank { rawName }
            return if (cleaned.length <= 6) cleaned else cleaned.take(5) + "…"
        }

        private fun createBluetoothRingBitmap(batteryPct: Int): Bitmap {
            val sizePx = 88
            val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            val pct = batteryPct.coerceIn(0, 100)

            val strokeW = 9.5f
            val pad = strokeW / 2f + 3f
            val oval = RectF(pad, pad, sizePx - pad, sizePx - pad)

            // Nền tròn tối gọn mắt
            val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.FILL
                color = Color.parseColor("#CC0F172A")
            }
            canvas.drawCircle(sizePx / 2f, sizePx / 2f, (sizePx / 2f) - 2f, bgPaint)

            // Vòng nền (track)
            val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = strokeW
                color = Color.parseColor("#25354D")
            }
            canvas.drawArc(oval, 0f, 360f, false, trackPaint)

            // Vòng tiến trình % pin đổi màu theo mức pin
            val arcColor = when {
                pct <= 20 -> Color.parseColor("#FB7185")
                pct <= 45 -> Color.parseColor("#FBBF24")
                pct <= 70 -> Color.parseColor("#38BDF8")
                else -> Color.parseColor("#34D399")
            }
            val progressPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = strokeW
                strokeCap = Paint.Cap.ROUND
                color = arcColor
            }
            val sweep = (pct / 100f) * 360f
            if (sweep > 0f) {
                canvas.drawArc(oval, -90f, sweep, false, progressPaint)
            }

            // Con số % rõ nét ở tâm vòng tròn
            val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textAlign = Paint.Align.CENTER
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textSize = if (pct >= 100) 24f else 28f
            }
            val fm = textPaint.fontMetrics
            val baseline = (sizePx / 2f) - (fm.ascent + fm.descent) / 2f
            canvas.drawText(pct.toString(), sizePx / 2f, baseline, textPaint)

            return bmp
        }
    }
}
