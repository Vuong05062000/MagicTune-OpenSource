package com.example.core.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews
import com.example.R
import com.example.core.i18n.AppLanguageManager.tr

object WidgetCycleDisplay {
    const val ACTION_TOGGLE = "com.magictune.tool.widget.TOGGLE_CYCLES"
    private var cachedCount: Int? = null
    private var readAt = 0L

    @Synchronized
    private fun readCount(intent: Intent?): Int? {
        val fromBattery = intent?.getIntExtra("android.os.extra.CYCLE_COUNT", -1) ?: -1
        if (fromBattery >= 0) return fromBattery
        val now = SystemClock.elapsedRealtime()
        if (readAt > 0 && now - readAt < 1_800_000L) return cachedCount
        readAt = now
        cachedCount = listOf("/sys/class/power_supply/battery/cycle_count",
            "/sys/class/hw_power/charger/charge_data/cycle_count").firstNotNullOfOrNull { path ->
            try { java.io.File(path).readText().trim().toIntOrNull()?.takeIf { it >= 0 } }
            catch (_: Exception) { null }
        }
        return cachedCount
    }

    fun toggle(context: Context, intent: Intent, provider: Class<*>): Boolean {
        if (intent.action != ACTION_TOGGLE) return false
        val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        if (id == AppWidgetManager.INVALID_APPWIDGET_ID) return true
        val prefs = context.getSharedPreferences("widget_cycles", Context.MODE_PRIVATE)
        val key = "show_$id"
        prefs.edit().putBoolean(key, !prefs.getBoolean(key, true)).apply()
        context.sendBroadcast(Intent(context, provider).apply {
            action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, intArrayOf(id))
        })
        return true
    }

    private var cachedCpu: Double? = null
    private var cpuReadAt = -15_000L
    private var phoneName: String? = null

    @Synchronized
    internal fun cpuTemperature(): Double? {
        val now = SystemClock.elapsedRealtime()
        if (now - cpuReadAt < 15_000L) return cachedCpu
        cpuReadAt = now
        cachedCpu = try {
            java.io.File("/sys/class/thermal").listFiles()?.filter {
                it.isDirectory && it.name.startsWith("thermal_zone")
            }?.mapNotNull { zone ->
                try {
                    val type = java.io.File(zone, "type").readText().trim().lowercase(java.util.Locale.ROOT)
                    if (!type.contains("cpu") && !type.contains("soc")) return@mapNotNull null
                    val raw = java.io.File(zone, "temp").readText().trim().toDouble()
                    val celsius = if (raw > 1000) raw / 1000 else if (raw > 150) raw / 10 else raw
                    celsius.takeIf { it in 0.1..150.0 }
                } catch (_: Exception) { null }
            }?.maxOrNull()
        } catch (_: Exception) { null }
        return cachedCpu
    }

    fun bind(context: Context, views: RemoteViews, id: Int, battery: Intent?, provider: Class<*>) {
        if (phoneName == null) phoneName = try {
            MagicLiveActionExecutor.getCommercialDeviceName(context)
        } catch (_: Exception) { "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}" }
        views.setTextViewText(R.id.widget_phone_name, phoneName)
        views.setViewVisibility(R.id.widget_cpu_temperature, View.GONE)
        val show = context.getSharedPreferences("widget_cycles", Context.MODE_PRIVATE).getBoolean("show_$id", true)
        views.setViewVisibility(R.id.widget_cycle_text, if (show) View.VISIBLE else View.GONE)
        if (show) views.setTextViewText(R.id.widget_cycle_text, readCount(battery)?.let { tr(context, "Chu kỳ: $it") } ?: tr(context, "Chu kỳ: --"))
        views.setTextViewText(R.id.widget_cycle_toggle, if (show) tr(context, "Ẩn chu kỳ") else tr(context, "Hiện chu kỳ"))
        val click = Intent(context, provider).apply {
            action = ACTION_TOGGLE
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
        }
        views.setOnClickPendingIntent(R.id.widget_cycle_toggle, PendingIntent.getBroadcast(
            context, id, click, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
    }
}
