package com.example.core.auth

import android.content.Context

/**
 * Phiên bản hoàn toàn miễn phí không dùng Firebase — bỏ đồng bộ cloud quản trị.
 */
object AdminSessionCache {
    fun loadAdminConfigSnapshot(context: Context) {
        // No-op: Cấu hình giao diện & liên kết được lưu cục bộ trong SharedPreferences.
    }

    fun ensureOfflineHydrated(context: Context) {
        // No-op
    }

    fun attachRealtimeListeners(context: Context) {
        // No-op
    }

    fun detachRealtimeListeners(force: Boolean = false) {
        // No-op
    }
}
