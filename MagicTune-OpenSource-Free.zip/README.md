﻿# MagicTune Tool (Open Source â€” 100% Free & Offline)

MagicTune Tool is an open-source Android utility built with Jetpack Compose, Wireless ADB (`libadb-android`), Shizuku, Material 3, and ML Kit, designed for Honor MagicOS and modern Android devices.

- **Repository:** https://github.com/Vuong05062000/MagicTune-OpenSource
- **100% Free & Local:** Completely free with all features unlocked out of the box. **No Firebase, no login, no telemetry, and no cloud maintenance cost.**

> **Open Source License:** Released under the [MIT License](LICENSE). Anyone worldwide is free to fork, modify, learn from, and distribute this project.

---

## Features / TĂ­nh nÄƒng chĂ­nh

- **Wireless ADB & Shizuku Bridge**: On-device NSD WLAN ADB pairing & shell execution without a PC.
- **Home Screen Widgets**:
  - 3Ă—2 & 2Ă—2 Live Battery Widgets (real-time fractional `%` while charging, accurate CC/CV charging ETA, mAh fuel-gauge drain analytics, Bluetooth device battery rings)
  - App Search & Gesture Draw Widget (recent apps + handwriting app launcher)
  - RAM & ROM Optimizer Widget
  - Clock, Weather & 24h/7d Forecast Widget (63 provinces/cities + islands & online geocoding) + Perpetual Lunar Calendar Widget
  - Global widget background transparency slider (0%â€“100%)
- **Notification & OEM Tuning**: Background keep-alive tuning for Android / Honor / Xiaomi / OPPO / Vivo / Samsung.
- **AI & Screen Utilities**: On-device ML Kit OCR screen translator, Circle-to-Search overlay, gesture letter app launcher, personal Gemini/Groq API key support, and thermal ESC/POS printer support (K80 / K57 via LAN/Wi-Fi/Bluetooth).

---

## Tech Stack

- **Language:** Kotlin, Jetpack Compose (Material 3)
- **Min / Target / Compile SDK:** `24` / `36` / `36`
- **Build System:** Gradle `9.3.1`, Android Gradle Plugin `9.1.1`, Java `17+`
- **Core Libraries:** `libadb-android`, `conscrypt-android`, Shizuku API, ML Kit Text Recognition (Latin & Chinese)

---

## Getting Started / HÆ°á»›ng dáº«n build

### 1. Prerequisites
- **JDK 17** or **JDK 21**
- **Android SDK** with **Platform 36** and **Build-Tools 36.0.0**
- Create `local.properties` in the project root:
  ```properties
  sdk.dir=/path/to/Android/Sdk
  ```
  *(On Windows: `sdk.dir=C\:\\Users\\<You>\\AppData\\Local\\Android\\Sdk`)*

### 2. Optional Configuration Files
1. **Private config (`private.properties`, optional)** â€” copy `private.properties.example` to `private.properties` if you want to bundle default build config values. *(If omitted, safe open-source defaults are used so builds work immediately.)*
2. **Release Signing (`keystore.properties`, optional)** â€” copy `keystore.properties.example` to `keystore.properties` and point `storeFile` to your `.p12` / `.jks` keystore.

### 3. Build Commands

**Debug APK:**
```bash
# macOS / Linux
chmod +x gradlew
./gradlew assembleDebug

# Windows (PowerShell / CMD)
gradlew.bat assembleDebug
```
Output: `build/outputs/apk/debug/`

**Release APK:**
```bash
./gradlew assembleRelease
# or on Windows:
gradlew.bat assembleRelease
```
Output: `build/outputs/apk/release/`

### 4. Static Layout Tests
Requires Node.js:
```bash
node tests/widget-layouts.test.cjs
```

---

## Project Structure

```text
.
â”œâ”€â”€ AndroidManifest.xml       # App manifest (components, receivers, widget metadata)
â”œâ”€â”€ build.gradle.kts          # Gradle configuration & dependencies
â”œâ”€â”€ gradle/                   # Gradle wrapper & libs.versions.toml catalog
â”œâ”€â”€ res/                      # Android XML layouts, drawables, widget metadata
â”œâ”€â”€ src/main/java/            # Kotlin source files (UI, widgets, ADB/shell, AI)
â”œâ”€â”€ tests/                    # Static XML layout validation checks
â”œâ”€â”€ LICENSE                   # MIT License
â””â”€â”€ README.md
```

---

## Security Notice for Contributors
Never commit `private.properties`, `keystore.properties`, `google-services.json`, `.p12`/`.jks` keystores, or personal credentials. All of these are ignored in `.gitignore`.


