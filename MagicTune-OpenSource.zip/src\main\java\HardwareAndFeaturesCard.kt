package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DeviceInfo
import com.example.data.PhoneFeatureItem
import com.example.ui.theme.MagicAmber
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicCyanLight
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicEmeraldLight
import com.example.ui.theme.MagicPurple
import com.example.ui.theme.MagicPurpleLight
import com.example.ui.theme.MagicRose
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.MagicSurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun HardwareAndFeaturesCard(
    deviceInfo: DeviceInfo,
    onRefresh: () -> Unit,
    onToggleFeature: (String, Boolean) -> Unit,
    cardNumberBadge: String = "Ô #01"
) {
    val context = LocalContext.current
    // Mặc định thu gọn bảng thông số sâu & danh sách công tắc phần cứng để Ô #01 đo/vẽ < 4ms (0 khựng 120Hz khi cuộn Tab 1),
    // người dùng vẫn mở xem đầy đủ chỉ với 1 chạm ngay bên dưới.
    var showDeepSpecs by remember { mutableStateOf(false) }
    var showHardwareSwitches by remember { mutableStateOf(false) }

    val enabledFeatureCount = remember(deviceInfo.features) {
        deviceInfo.features.count { it.isEnabled }
    }
    val totalFeatureCount = remember(deviceInfo.features) {
        deviceInfo.features.size
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
        border = BorderStroke(1.2.dp, remember { Brush.horizontalGradient(listOf(MagicCyan, MagicEmerald)) })
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header Bar với Badge & Tiêu đề tách hàng riêng biệt
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicCyan)
                                .padding(horizontal = 7.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = cardNumberBadge,
                                color = Color(0xFF020617),
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicEmerald.copy(alpha = 0.18f))
                                .border(1.dp, MagicEmerald.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 7.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "✓ Bật $enabledFeatureCount/$totalFeatureCount mục",
                                color = MagicEmeraldLight,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }

                    Button(
                        onClick = onRefresh,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.heightIn(min = 34.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MagicSurfaceCard,
                            contentColor = MagicCyanLight
                        ),
                        border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.5f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Làm mới thông số phần cứng",
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Làm mới", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Text(
                    text = "📱 GIÁM SÁT PHẦN CỨNG & TRẠNG THÁI BẬT/TẮT",
                    color = MagicCyanLight,
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "Đọc trực tiếp CPU, GPU, RAM, ROM, Chu kỳ Pin, Cảm biến & $totalFeatureCount trạng thái phần cứng",
                    color = TextSecondary,
                    fontSize = 10.5.sp,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Hàng 1: Thiết bị & Hệ điều hành + Vi xử lý CPU & GPU
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                HardwareSpecBox(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Default.PhoneAndroid,
                    label = "Thiết Bị & Hệ Điều Hành",
                    value = "${deviceInfo.brand.uppercase()} ${deviceInfo.model}".trim(),
                    subValue = "${deviceInfo.version} • ${deviceInfo.magicOS}",
                    extraValue = "Mã: ${deviceInfo.deviceCodename} (${deviceInfo.board})",
                    accentColor = MagicCyan
                )
                HardwareSpecBox(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Default.Memory,
                    label = "Chipset CPU & Đồ Họa GPU",
                    value = deviceInfo.soc,
                    subValue = "${deviceInfo.cpuCores} ${deviceInfo.cpuFreq}".trim(),
                    extraValue = "GPU: ${deviceInfo.gpu}",
                    accentColor = MagicEmerald
                )
            }

            // Hàng 2: Thanh tiến trình RAM & Bộ nhớ trong ROM
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                HardwareProgressBox(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Default.Build,
                    label = "Bộ Nhớ RAM Thời Gian Thực",
                    detail = deviceInfo.ram,
                    percent = deviceInfo.ramUsedPercent,
                    accentColor = MagicPurple
                )
                HardwareProgressBox(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Default.Memory,
                    label = "Bộ Nhớ Trong (ROM)",
                    detail = deviceInfo.storage,
                    percent = deviceInfo.storageUsedPercent,
                    accentColor = MagicAmber
                )
            }

            // Hàng 3: Thông số Pin chuyên sâu (Dung lượng, Nhiệt độ, Điện áp, Sức khỏe, Chu kỳ sạc)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0F172A))
                    .border(1.dp, MagicBorder, RoundedCornerShape(12.dp))
                    .padding(10.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MagicEmerald.copy(alpha = 0.16f))
                                    .border(0.8.dp, MagicEmerald.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 7.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "🔋 Pin & Nhiệt Độ",
                                    color = MagicEmeraldLight,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MagicAmber.copy(alpha = 0.16f))
                                    .border(0.8.dp, MagicAmber.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 7.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "🌡️ ${deviceInfo.temp} • ${deviceInfo.refreshRate}",
                                    color = MagicAmber,
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.BatteryChargingFull,
                                contentDescription = null,
                                tint = MagicEmerald,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "${deviceInfo.model} • ${deviceInfo.batteryLevel}% (${deviceInfo.batteryStatus})",
                                color = Color.White,
                                fontSize = 12.2.sp,
                                fontWeight = FontWeight.Black,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MiniMetricChip(label = "Sức khỏe", value = deviceInfo.batteryHealth, color = MagicEmeraldLight)
                        MiniMetricChip(label = "Thời gian đầy", value = deviceInfo.batteryTimeToFullMinutes, color = MagicAmber)
                        MiniMetricChip(label = "Chu kỳ sạc", value = deviceInfo.batteryCycleCount, color = MagicPurpleLight)
                    }

                    // Khung Mở Khóa Dung Lượng Pin Thực Honor (Phá khóa 80% ảo của Dung lượng pin thông minh)
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF090F1D))
                            .border(
                                1.dp,
                                if (deviceInfo.isSmartBatteryCapacityUnlocked) MagicEmerald.copy(alpha = 0.55f) else MagicCyan.copy(alpha = 0.45f),
                                RoundedCornerShape(10.dp)
                            )
                            .padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(
                                        if (deviceInfo.isSmartBatteryCapacityUnlocked) MagicEmerald.copy(alpha = 0.18f)
                                        else MagicCyan.copy(alpha = 0.18f)
                                    )
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (deviceInfo.isSmartBatteryCapacityUnlocked) "✓ Đã mở khóa sạc thực" else "⚡ Chế độ mở khóa pin",
                                    color = if (deviceInfo.isSmartBatteryCapacityUnlocked) MagicEmeraldLight else MagicCyanLight,
                                    fontSize = 9.8.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                            Text(
                                text = "⚙️ Cài đặt Pin",
                                color = MagicAmber,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MagicAmber.copy(alpha = 0.14f))
                                    .clickable {
                                        com.example.data.MagicTuneRepository.openHonorBatterySettings(context)
                                    }
                                    .padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                        Text(
                            text = "🔋 Dung lượng thực: ${deviceInfo.batteryCapacityStatus}",
                            color = if (deviceInfo.isSmartBatteryCapacityUnlocked) MagicEmeraldLight else MagicCyanLight,
                            fontSize = 11.2.sp,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(
                            text = "Honor mặc định hạ áp ngắt sạc sớm. Khi sạc đạt 100%, MagicTune tự động duy trì sạc ngâm bù ion (Trickle Charge) và chỉ kích hoạt ngắt dòng an toàn khi công suất sạc đo được giảm về mức ≤ 1W (mức tiêu thụ nền ở chế độ ngủ, chống tình trạng sạc vô tận nếu chờ 0W), đảm bảo pin thực sự no điện 100% mà không bị chai phồng:",
                            color = TextSecondary,
                            fontSize = 9.8.sp,
                            lineHeight = 13.5.sp
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Button(
                                onClick = { onToggleFeature("unlock_battery_97", false) },
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 38.dp),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 5.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MagicEmerald.copy(alpha = 0.2f),
                                    contentColor = MagicEmeraldLight
                                ),
                                border = BorderStroke(1.dp, MagicEmerald)
                            ) {
                                Text(
                                    text = "⚡ Sạc Thực 97% (Đệm 3%)",
                                    color = MagicEmeraldLight,
                                    fontSize = 10.2.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                            Button(
                                onClick = { onToggleFeature("unlock_battery_100", false) },
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 38.dp),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 5.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MagicCyan.copy(alpha = 0.2f),
                                    contentColor = MagicCyanLight
                                ),
                                border = BorderStroke(1.dp, MagicCyan)
                            ) {
                                Text(
                                    text = "🔓 Mở 100% Dung Lượng",
                                    color = MagicCyanLight,
                                    fontSize = 10.2.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }
                }
            }

            // Hàng 4: Nút Mở rộng / Thu gọn Thông số phần cứng chuyên sâu (Màn hình, Cảm biến, Kernel, Bản vá, Uptime)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(MagicSurfaceCard)
                    .border(1.dp, MagicBorder, RoundedCornerShape(10.dp))
                    .clickable { showDeepSpecs = !showDeepSpecs }
                    .padding(horizontal = 10.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "🔍 Thông Số Phần Cứng Chuyên Sâu (Màn Hình, Cảm Biến, Kernel, Bản Vá)",
                        color = MagicCyanLight,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    Icon(
                        imageVector = if (showDeepSpecs) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                        contentDescription = null,
                        tint = MagicCyanLight,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            AnimatedVisibility(visible = showDeepSpecs) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF090F1D))
                        .border(1.dp, MagicCyan.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    DeepHardwareRow("Độ phân giải & Mật độ điểm ảnh", deviceInfo.screen)
                    DeepHardwareRow("Tần số quét màn hình", deviceInfo.refreshRate)
                    DeepHardwareRow("Kiến trúc CPU & Tập lệnh (ABI)", deviceInfo.abi)
                    DeepHardwareRow("Tổng số cảm biến phần cứng", "${deviceInfo.sensorCount} cảm biến đang hoạt động")
                    DeepHardwareRow("Bản vá bảo mật Android", deviceInfo.securityPatch)
                    DeepHardwareRow("Nhân hệ thống (Linux Kernel)", deviceInfo.kernel)
                    DeepHardwareRow("Thời gian máy chạy (Uptime)", deviceInfo.uptime)
                    DeepHardwareRow("Kênh giao tiếp hệ thống", deviceInfo.serial)
                }
            }

            // Hàng 5: Bảng Trạng Thái Bật / Tắt Phần Cứng (Chỉ Xem - Bấm ⚙️ Mở Cài Đặt)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(
                        remember {
                            Brush.horizontalGradient(
                                listOf(MagicCyan.copy(alpha = 0.16f), MagicEmerald.copy(alpha = 0.16f))
                            )
                        }
                    )
                    .border(1.dp, MagicCyan.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                    .clickable { showHardwareSwitches = !showHardwareSwitches }
                    .padding(horizontal = 10.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = MagicEmerald,
                            modifier = Modifier.size(16.dp)
                        )
                        Column {
                            Text(
                                text = "🔍 TRẠNG THÁI BẬT / TẮT PHẦN CỨNG",
                                color = Color.White,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "Đang bật $enabledFeatureCount / $totalFeatureCount mục • Chỉ hiển thị trạng thái, bấm ⚙️ mở Cài đặt bật/tắt thủ công",
                                color = MagicEmeraldLight,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Icon(
                        imageVector = if (showHardwareSwitches) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            AnimatedVisibility(visible = showHardwareSwitches) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    deviceInfo.features.forEach { feature ->
                        androidx.compose.runtime.key(feature.id) {
                            HardwareFeatureStatusRow(
                                feature = feature,
                                onOpenSystemSetting = {
                                    openHardwareSettingFallback(context, feature.id)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HardwareSpecBox(
    modifier: Modifier = Modifier,
    icon: ImageVector,
    label: String,
    value: String,
    subValue: String,
    extraValue: String,
    accentColor: Color
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(MagicSurfaceCard)
            .border(1.dp, accentColor.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
            .padding(10.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(14.dp)
                )
                Text(
                    text = label,
                    color = TextSecondary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Text(
                text = value,
                color = Color.White,
                fontSize = 11.8.sp,
                fontWeight = FontWeight.Black
            )
            Text(
                text = subValue,
                color = accentColor,
                fontSize = 10.2.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = extraValue,
                color = TextMuted,
                fontSize = 9.5.sp
            )
        }
    }
}

@Composable
private fun HardwareProgressBox(
    modifier: Modifier = Modifier,
    icon: ImageVector,
    label: String,
    detail: String,
    percent: Float,
    accentColor: Color
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(MagicSurfaceCard)
            .border(1.dp, accentColor.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
            .padding(10.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(15.dp)
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(5.dp))
                        .background(accentColor.copy(alpha = 0.16f))
                        .padding(horizontal = 6.dp, vertical = 1.5.dp)
                ) {
                    Text(
                        text = "${percent.toInt()}%",
                        color = accentColor,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            Text(
                text = label,
                color = TextSecondary,
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth()
            )

            LinearProgressIndicator(
                progress = { (percent / 100f).coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = accentColor,
                trackColor = Color(0xFF0F172A)
            )

            Text(
                text = detail,
                color = Color.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                lineHeight = 13.5.sp
            )
        }
    }
}

@Composable
private fun MiniMetricChip(
    label: String,
    value: String,
    color: Color
) {
    Column(horizontalAlignment = Alignment.Start) {
        Text(
            text = label,
            color = TextMuted,
            fontSize = 9.2.sp,
            fontWeight = FontWeight.Medium
        )
        Text(
            text = value,
            color = color,
            fontSize = 10.5.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun DeepHardwareRow(
    label: String,
    value: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = label,
            color = TextSecondary,
            fontSize = 10.5.sp,
            modifier = Modifier.weight(0.42f)
        )
        Text(
            text = value,
            color = TextPrimary,
            fontSize = 10.5.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(0.58f)
        )
    }
}

@Composable
private fun HardwareFeatureStatusRow(
    feature: PhoneFeatureItem,
    onOpenSystemSetting: () -> Unit
) {
    val statusBg = if (feature.isEnabled) MagicEmerald.copy(alpha = 0.16f) else Color(0xFF334155).copy(alpha = 0.45f)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF0F172A))
            .border(
                width = 1.dp,
                color = if (feature.isEnabled) MagicEmerald.copy(alpha = 0.4f) else MagicBorder,
                shape = RoundedCornerShape(10.dp)
            )
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Hàng 1: Chấm trạng thái + Mác ĐANG BẬT/ĐANG TẮT (chỉ hiển thị) | Nút bánh răng ⚙️ mở Cài đặt thủ công
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (feature.isEnabled) MagicEmerald else Color.Gray)
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(5.dp))
                            .background(statusBg)
                            .border(
                                width = 0.8.dp,
                                color = if (feature.isEnabled) MagicEmerald.copy(alpha = 0.45f) else Color.White.copy(alpha = 0.12f),
                                shape = RoundedCornerShape(5.dp)
                            )
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = feature.statusText,
                            color = if (feature.isEnabled) MagicEmeraldLight else TextSecondary,
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }

                // Nút bánh răng ⚙️ mở nhanh trang Cài đặt hệ thống để người dùng tự bật/tắt thủ công
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .testTag("hardware_setting_${feature.id}")
                        .clickable { onOpenSystemSetting() },
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(MagicSurfaceCard)
                            .border(1.dp, MagicBorder, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Mở Cài đặt ${feature.name}",
                            tint = MagicCyanLight,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // Hàng 2: Tên chức năng nằm trọn vẹn trên hàng riêng toàn chiều ngang
            Text(
                text = feature.name,
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth()
            )

            // Hàng 3: Mô tả chi tiết hiển thị trọn vẹn không bị cắt dấu "..."
            Text(
                text = feature.detail,
                color = if (feature.isEnabled) MagicCyanLight else TextMuted,
                fontSize = 10.2.sp,
                lineHeight = 14.sp,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

fun openHardwareSettingFallback(context: Context, featureId: String) {
    val intents = when (featureId) {
        "wifi" -> listOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) Intent(Settings.Panel.ACTION_WIFI) else Intent(Settings.ACTION_WIFI_SETTINGS),
            Intent(Settings.ACTION_WIFI_SETTINGS)
        )
        "bluetooth" -> listOf(
            Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
        )
        "mobile_data" -> listOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY) else Intent(Settings.ACTION_DATA_ROAMING_SETTINGS),
            Intent(Settings.ACTION_DATA_ROAMING_SETTINGS),
            Intent(Settings.ACTION_WIRELESS_SETTINGS)
        )
        "gps", "gps_high_accuracy" -> listOf(
            Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
        )
        "nfc" -> listOf(
            Intent(Settings.ACTION_NFC_SETTINGS),
            Intent(Settings.ACTION_WIRELESS_SETTINGS)
        )
        "auto_rotate", "dark_mode" -> listOf(
            Intent(Settings.ACTION_DISPLAY_SETTINGS)
        )
        "adblocker_dns" -> listOf(
            Intent(Settings.ACTION_WIRELESS_SETTINGS),
            Intent(Settings.ACTION_WIFI_SETTINGS)
        )
        "yoyo_nav_wake" -> {
            com.example.core.service.SystemFloatingHudOverlay.openSystemNavigationSettings(context)
            return
        }
        "block_update" -> listOf(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = android.net.Uri.parse("package:com.hihonor.appmarket")
            },
            Intent(Settings.ACTION_APPLICATION_SETTINGS)
        )
        "auto_sync" -> listOf(
            Intent(Settings.ACTION_SYNC_SETTINGS),
            Intent(Settings.ACTION_ADD_ACCOUNT)
        )
        "adb_debug" -> listOf(
            Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS),
            Intent(Settings.ACTION_DEVICE_INFO_SETTINGS)
        )
        "unlock_battery_97", "unlock_battery_100", "restore_battery_cap" -> {
            com.example.data.MagicTuneRepository.openHonorBatterySettings(context)
            return
        }
        else -> listOf(Intent(Settings.ACTION_SETTINGS))
    }

    for (intent in intents) {
        try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            return
        } catch (_: Exception) {}
    }
}
