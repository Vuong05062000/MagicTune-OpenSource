package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.core.restore.RevertActionCatalog
import com.example.core.widget.GestureLauncherOverlay
import com.example.ui.theme.MagicAmber
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicCyanLight
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicEmeraldLight
import com.example.ui.theme.MagicPurple
import com.example.ui.theme.MagicPurpleLight
import com.example.ui.theme.MagicRose
import com.example.ui.theme.MagicRoseLight
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.MagicSurfaceDark
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

private data class RevertCategoryItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val section: String,
    val accentColor: Color
)

@Composable
fun RevertModal(
    onDismiss: () -> Unit,
    onConfirmRevert: () -> Unit,
    onRevertSingleCategory: (String) -> Unit = {},
    onRevertSelectedCategories: (List<String>) -> Unit = {}
) {
    val context = LocalContext.current
    val config = LocalConfiguration.current
    var refreshTick by remember { mutableIntStateOf(0) }
    var searchText by remember { mutableStateOf("") }

    val customTemplatesCount = remember(refreshTick) { GestureLauncherOverlay.getAllCustomTemplateChars(context).size }
    val isDirectLaunch = remember(refreshTick) { GestureLauncherOverlay.isDirectLaunchAfterDraw(context) }

    val categories = remember(customTemplatesCount, isDirectLaunch) {
        val presets = listOf(
            RevertCategoryItem(
                "NAV_YOYO", "Thanh điều hướng & YOYO",
                "Trả thanh điều hướng về mặc định; hiện lại thanh gợi ý và YOYO.",
                "Nhóm tổng quát", MagicCyan
            ),
            RevertCategoryItem(
                "DISPLAY_ANIM", "Màn hình & hoạt ảnh",
                "Tự động điều chỉnh tần số quét và đặt hoạt ảnh về 1×.",
                "Nhóm tổng quát", MagicEmerald
            ),
            RevertCategoryItem(
                "DNS_ADBLOCK", "DNS, mạng & pin kết nối",
                "Tắt DNS chặn quảng cáo và khôi phục cấu hình kết nối.",
                "Nhóm tổng quát", MagicAmber
            ),
            RevertCategoryItem(
                "TOUCH_THERMAL", "Cảm ứng, pin & tản nhiệt",
                "Khôi phục độ nhạy cảm ứng, cấu hình pin và làm mát.",
                "Nhóm tổng quát", MagicPurple
            ),
            RevertCategoryItem(
                "DEV_STEALTH", "Menu nhà phát triển",
                "Hiện lại trang Tùy chọn nhà phát triển trong Cài đặt.",
                "Nhóm tổng quát", MagicCyanLight
            ),
            RevertCategoryItem(
                "HISEARCH_HIBOARD", "HiSearch, HiBoard & App Market",
                "Bật lại tìm kiếm Honor, bảng tin và cập nhật App Market.",
                "Nhóm tổng quát", MagicEmeraldLight
            ),
            RevertCategoryItem(
                "AUDIO_FONT", "Âm thanh, cỡ chữ & thông báo",
                "Trả cỡ chữ, Bluetooth và thông báo về cài đặt mặc định.",
                "Nhóm tổng quát", MagicPurpleLight
            ),
            RevertCategoryItem(
                "GESTURE_DRAW", "Bảng vẽ mở ứng dụng",
                "Đặt lại chữ A–Z, xóa ${customTemplatesCount} nét vẽ mẫu; chế độ ${if (isDirectLaunch) "mở thẳng" else "hiện kết quả"}.",
                "Nhóm tổng quát", MagicRoseLight
            )
        )
        presets + RevertActionCatalog.actions.map { action ->
            val accent = when (action.section) {
                "Màn hình" -> MagicEmerald
                "Điều hướng & cảm ứng" -> MagicCyan
                "Mạng & Wi-Fi" -> MagicAmber
                "Pin & nhiệt" -> MagicPurple
                "Âm thanh & thông báo" -> MagicRoseLight
                "Riêng tư & vị trí" -> MagicCyanLight
                "Dịch vụ Honor" -> MagicEmeraldLight
                else -> MagicRose
            }
            RevertCategoryItem(
                id = action.id,
                title = action.title,
                subtitle = action.description,
                section = action.section,
                accentColor = accent
            )
        }
    }

    // Keep the familiar broad presets selected initially; atomic actions are opt-in.
    val selectedIds = remember {
        mutableStateListOf(
            "NAV_YOYO", "DISPLAY_ANIM", "DNS_ADBLOCK", "TOUCH_THERMAL",
            "DEV_STEALTH", "HISEARCH_HIBOARD", "AUDIO_FONT"
        )
    }
    val filteredCategories = remember(categories, searchText) {
        if (searchText.isBlank()) categories
        else categories.filter {
            it.title.contains(searchText.trim(), ignoreCase = true) ||
                it.subtitle.contains(searchText.trim(), ignoreCase = true) ||
                it.section.contains(searchText.trim(), ignoreCase = true)
        }
    }
    val maxDialogHeight = (config.screenHeightDp * 0.9f).dp

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = true
        )
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .heightIn(max = maxDialogHeight)
                .padding(4.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = BorderStroke(1.3.dp, Brush.linearGradient(listOf(MagicRose, MagicAmber, MagicCyan)))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = maxDialogHeight)
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MagicRose.copy(alpha = 0.18f))
                            .border(1.dp, MagicRose.copy(alpha = 0.7f), RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, tint = MagicRoseLight, modifier = Modifier.size(19.dp))
                    }
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                        Text(
                            "TRUNG TÂM HOÀN TÁC",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            "80 mục khôi phục · chọn nhóm hoặc từng cài đặt",
                            color = MagicEmeraldLight,
                            fontSize = 10.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(9.dp))
                            .background(MagicSurfaceCard)
                            .border(1.dp, MagicBorder, RoundedCornerShape(9.dp))
                            .clickable { onDismiss() }
                            .testTag("close_revert_dialog_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Đóng", tint = Color.White, modifier = Modifier.size(17.dp))
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(9.dp))
                        .background(MagicSurfaceCard)
                        .padding(horizontal = 9.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Đã chọn ${selectedIds.size}/${categories.size}", color = MagicCyanLight, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("Đang hiển thị ${filteredCategories.size} mục", color = TextSecondary, fontSize = 10.sp)
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(36.dp)
                        .clip(RoundedCornerShape(9.dp))
                        .background(MagicSurfaceCard)
                        .border(1.dp, MagicBorder, RoundedCornerShape(9.dp))
                        .padding(horizontal = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    Icon(Icons.Default.Search, contentDescription = null, tint = MagicCyanLight, modifier = Modifier.size(17.dp))
                    Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                        if (searchText.isBlank()) Text("Tìm nhóm hoặc cài đặt...", color = TextSecondary, fontSize = 11.sp)
                        BasicTextField(
                            value = searchText,
                            onValueChange = { searchText = it },
                            singleLine = true,
                            textStyle = TextStyle(color = TextPrimary, fontSize = 11.sp),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    if (searchText.isNotBlank()) {
                        Icon(
                            Icons.Default.Close,
                            contentDescription = "Xóa tìm kiếm",
                            tint = TextSecondary,
                            modifier = Modifier.size(18.dp).clickable { searchText = "" }
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    OutlinedButton(
                        onClick = { selectedIds.clear(); selectedIds.addAll(categories.map { it.id }) },
                        modifier = Modifier.weight(1f).height(34.dp),
                        contentPadding = PaddingValues(horizontal = 7.dp, vertical = 0.dp),
                        shape = RoundedCornerShape(9.dp),
                        border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.6f)),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MagicCyanLight)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Chọn tất cả (${categories.size})", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    }
                    OutlinedButton(
                        onClick = { selectedIds.clear() },
                        modifier = Modifier.weight(1f).height(34.dp),
                        contentPadding = PaddingValues(horizontal = 7.dp, vertical = 0.dp),
                        shape = RoundedCornerShape(9.dp),
                        border = BorderStroke(1.dp, MagicBorder),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Bỏ chọn", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }

                LazyColumn(
                    modifier = Modifier
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    items(filteredCategories, key = { it.id }) { item ->
                        val isChecked = item.id in selectedIds
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isChecked) Color(0xFF111C30) else MagicSurfaceCard.copy(alpha = 0.72f))
                                .border(
                                    1.dp,
                                    if (isChecked) item.accentColor.copy(alpha = 0.55f) else MagicBorder,
                                    RoundedCornerShape(10.dp)
                                )
                                .clickable {
                                    if (isChecked) selectedIds.remove(item.id) else selectedIds.add(item.id)
                                }
                                .padding(horizontal = 6.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Checkbox(
                                checked = isChecked,
                                onCheckedChange = { checked ->
                                    if (checked && item.id !in selectedIds) selectedIds.add(item.id)
                                    else if (!checked) selectedIds.remove(item.id)
                                },
                                colors = CheckboxDefaults.colors(
                                    checkedColor = item.accentColor,
                                    uncheckedColor = TextSecondary,
                                    checkmarkColor = Color(0xFF020617)
                                ),
                                modifier = Modifier.size(30.dp)
                            )
                            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                                Text(
                                    item.title,
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    "${item.section} · ${item.subtitle}",
                                    color = TextSecondary,
                                    fontSize = 9.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .width(58.dp)
                                    .height(30.dp)
                                    .clip(RoundedCornerShape(7.dp))
                                    .background(MagicRose.copy(alpha = 0.16f))
                                    .border(1.dp, MagicRose.copy(alpha = 0.55f), RoundedCornerShape(7.dp))
                                    .clickable {
                                        onRevertSingleCategory(item.id)
                                        refreshTick++
                                        Toast.makeText(context, "Đang khôi phục: ${item.title}", Toast.LENGTH_SHORT).show()
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Text("Hoàn tác", color = MagicRoseLight, fontSize = 9.sp, fontWeight = FontWeight.Black, maxLines = 1)
                            }
                        }
                    }
                }

                Button(
                    onClick = {
                        if (selectedIds.isEmpty()) {
                            Toast.makeText(context, "Chọn ít nhất một mục để hoàn tác.", Toast.LENGTH_SHORT).show()
                        } else {
                            onRevertSelectedCategories(selectedIds.toList())
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(40.dp).defaultMinSize(minHeight = 0.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MagicAmber, contentColor = Color(0xFF020617))
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("Hoàn tác ${selectedIds.size} mục đã chọn", fontSize = 11.sp, fontWeight = FontWeight.Black, maxLines = 1)
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(0.8f).height(36.dp),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                        shape = RoundedCornerShape(9.dp),
                        border = BorderStroke(1.dp, MagicBorder),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary)
                    ) {
                        Text("Đóng", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = onConfirmRevert,
                        modifier = Modifier.weight(1.5f).height(36.dp).defaultMinSize(minHeight = 0.dp),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                        shape = RoundedCornerShape(9.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MagicRose, contentColor = Color.White)
                    ) {
                        Text("Khôi phục mặc định toàn bộ", fontSize = 10.sp, fontWeight = FontWeight.Black, maxLines = 1)
                    }
                }
            }
        }
    }
}
