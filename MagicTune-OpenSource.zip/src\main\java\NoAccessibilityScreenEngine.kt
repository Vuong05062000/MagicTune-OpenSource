package com.example.core.service

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Rect
import android.os.Build
import android.os.Looper
import android.util.Log
import com.example.core.assistant.MagicTuneVoiceInteractionService
import com.example.core.ocr.ScreenOcrEngine
import com.example.core.projection.MediaProjectionHolder
import com.example.core.shell.ShellEngine
import java.io.File
import java.text.Normalizer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Động Cơ Đọc Màn Hình & Trợ Lý Ảo KHÔNG DÙNG TRỢ NĂNG (NO-ACCESSIBILITY ARCHITECTURE).
 *
 * MỤC TIÊU CỐT LÕI & TUÂN THỦ 100%:
 * 1. Tuyệt đối KHÔNG kế thừa `AccessibilityService`, KHÔNG import bất kỳ lớp `android.accessibilityservice.*`
 *    hay `android.view.accessibility.*` nào.
 * 2. Vượt qua 100% rào cản bảo mật của ứng dụng Ngân Hàng & Chính Phủ (MB Bank, Vietcombank, Techcombank, VNeID...):
 *    - Không bao giờ bị cảnh báo "Phát hiện dịch vụ trợ năng độc hại", không bị ép tắt app hay chặn giao dịch.
 *    - Tôn trọng cờ FLAG_SECURE của hệ thống và chủ động bỏ qua, không đọc hay chụp màn hình ứng dụng nhạy cảm.
 * 3. Vận hành bằng các API Android công khai hợp lệ:
 *    - Động cơ 1: MediaProjection + ImageReader (Chụp nhanh màn hình 10-25ms & xử lý cuộn liên tục).
 *    - Động cơ 2: Google ML Kit Text Recognition (OCR On-Device trích xuất tọa độ văn bản, dịch thuật).
 *    - Động cơ 3: Digital Assistant Framework (`MagicTuneVoiceInteractionService` + `AssistStructure`).
 *    - Động cơ 4: Điều khiển thao tác tự động chuẩn xác qua `ShellEngine` (input tap/swipe/keyevent).
 */
object NoAccessibilityScreenEngine {

    private const val TAG = "NoAccessibilityEngine"

    const val GLOBAL_ACTION_BACK = 1
    const val GLOBAL_ACTION_HOME = 2
    const val GLOBAL_ACTION_RECENTS = 3
    const val GLOBAL_ACTION_NOTIFICATIONS = 4
    const val GLOBAL_ACTION_QUICK_SETTINGS = 5
    const val GLOBAL_ACTION_LOCK_SCREEN = 8
    const val GLOBAL_ACTION_TAKE_SCREENSHOT = 9

    val instance: NoAccessibilityScreenEngine get() = this

    private val helperScope = CoroutineScope(
        SupervisorJob() + Dispatchers.IO + com.example.MagicTuneApplication.globalCoroutineExceptionHandler
    )
    private val mainHandler = android.os.Handler(Looper.getMainLooper())

    @Volatile
    var isLiveScrollTranslateActive: Boolean = false

    var isAccessibilityAutoHidden: Boolean
        get() = MagicTuneCtsAccessibilityService.isAccessibilityAutoHidden
        set(value) {
            MagicTuneCtsAccessibilityService.isAccessibilityAutoHidden = value
        }

    @Volatile
    var onLiveScrollEventCallback: ((isScrolling: Boolean) -> Unit)? = null

    @Volatile
    var onBankingAppDetectedCallback: (() -> Unit)? = null

    @Volatile
    var onBankingExitedCallback: (() -> Unit)? = null

    @Volatile
    private var wasLastForegroundBanking: Boolean = false

    fun notifyBankingTransition(context: Context, enteredBanking: Boolean) {
        val appCtx = context.applicationContext ?: context
        if (enteredBanking) {
            if (!wasLastForegroundBanking) {
                wasLastForegroundBanking = true
                MagicTuneCtsAccessibilityService.isBankingBlocked = true
                MagicTuneCtsAccessibilityService.isAccessibilityAutoHidden = true
                clearCachedScreenNodes()
                try {
                    com.example.core.widget.MagicLiveFloatingOverlay.dismiss(appCtx)
                } catch (_: Throwable) {}
                mainHandler.post {
                    try {
                        onBankingAppDetectedCallback?.invoke()
                    } catch (_: Throwable) {}
                }
            }
        } else {
            if (wasLastForegroundBanking || MagicTuneCtsAccessibilityService.isBankingBlocked) {
                wasLastForegroundBanking = false
                MagicTuneCtsAccessibilityService.isBankingBlocked = false
                MagicTuneCtsAccessibilityService.isAccessibilityAutoHidden = false
                mainHandler.post {
                    try {
                        onBankingExitedCallback?.invoke()
                    } catch (_: Throwable) {}
                }
            }
        }
    }

    @Volatile
    var lastCapturedScreenNodes: List<ScreenTextNode> = emptyList()
        private set

    @Volatile
    private var cachedFullUiNodes: List<UiNodeRecord> = emptyList()

    @Volatile
    private var cachedUiNodesTimestampMs: Long = 0L

    @Volatile
    private var cachedForegroundPackage: String = ""

    @Volatile
    private var cachedForegroundPackageTimestampMs: Long = 0L

    @Volatile
    private var lastAppContextRef: Context? = null

    data class ScreenTextNode(
        val text: String,
        val boundsInScreen: Rect
    )

    data class UiNodeRecord(
        val text: String,
        val contentDesc: String,
        val hint: String = "",
        val className: String = "",
        val resourceId: String = "",
        val packageName: String = "",
        val isClickable: Boolean = false,
        val isCheckable: Boolean = false,
        val isChecked: Boolean = false,
        val bounds: Rect
    )

    private val bankingPackages = setOf(
        "com.mbmobile",
        "com.VCB",
        "com.vietcombank.mobile",
        "vn.com.techcombank.bb.app",
        "com.techcombank.bb.app",
        "com.techcombank.mobile",
        "com.vnpay.bidv",
        "com.bidv.smartbanking",
        "com.vietinbank.ipay",
        "com.icb.igrp.mb",
        "com.agribank.agribankplus",
        "com.vpbank.vpbankonline",
        "mobile.acb.com.vn",
        "com.acb.mobile",
        "com.tpb.mb.gprsandroid",
        "vn.tpb.mb.gprsandroid",
        "vn.shb.mbanking",
        "com.sacombank.ewallet",
        "com.hdbank.mobilebanking",
        "com.ocb.omniextra",
        "vn.com.MSB.smartbanking",
        "vn.com.msb.smartbanking",
        "com.msb.mteller",
        "vn.com.seabank.mb1",
        "com.vnpay.Eximbank",
        "com.lpbank.lienviet24h",
        "com.scb.mobile",
        "com.scb.vn",
        "com.vnpay.vnpay",
        "vn.com.mbbank.digital",
        "com.mbbank.biz",
        "com.vib.myvib2",
        "com.vib.myvib",
        "com.pvcombank.mobile",
        "com.shinhan.global.vn.bank",
        "com.wooribank.smart.vn",
        "com.uob.mightyvn",
        "com.hsbc.mobilebanking",
        "com.timo.vn",
        "vn.timo.app",
        "vn.cake.digitalbank",
        "vn.tnex.consumer",
        "com.lio.bank",
        "vn.vss.app",
        "com.bhxh.vssid",
        "gov.vneid",
        "com.vnpt.vneid",
        "vn.gov.vneid",
        "com.dancuquocgia.vneid",
        "vn.gov.canhan.etaxmobile",
        "vn.gov.gdt.etaxmobile",
        "vn.gov.etax",
        "vn.gov.dichvucong",
        "com.vnpt.dvc",
        "com.vnpt.ihanoi",
        "com.hanoi.ihanoi",
        "com.vnpay.agribank",
        "vn.com.acb.acblap",
        "com.vnpay.vietinbank",
        "vn.com.sacombank.mbanking",
        "com.shb.mobile",
        "com.ocb.omni",
        "com.vnpay.vpbank",
        "com.namabank.ebanking",
        "com.namabank.openbanking",
        "com.vnpay.namabank",
        "vn.com.namabank.ebanking",
        "vn.tpay",
        "com.mservice.momopay",
        "com.mservice.momotransfer",
        "vn.com.vng.zalopay",
        "vn.zalopay.sdk",
        "vn.viettel.viettelpay",
        "com.bplus.vtpay",
        "com.shopee.pay.vn",
        "com.airpay.android",
        "com.vnpay.wallet"
    )

    fun isSensitiveBankingPackage(pkg: String): Boolean {
        if (pkg.isBlank()) return false
        val lower = pkg.lowercase()
        // Loại trừ tuyệt đối các ứng dụng mua sắm (Primary use-case for Dịch Cuộn)
        if (lower.contains("taobao") || lower.contains("alibaba") || lower.contains("shopee") && !lower.contains("pay") ||
            lower.contains("lazada") || lower.contains("tmall") || lower.contains("pinduoduo") ||
            lower.contains("amazon") || lower.contains("aliexpress") || lower.contains("jd.")) return false
        return bankingPackages.any { it.trim().equals(lower, ignoreCase = true) } ||
            lower.contains("mbmobile") ||
            lower.contains("mbbank") ||
            lower.contains("techcombank") ||
            lower.contains("namabank") ||
            lower.contains("vietcombank") ||
            lower.contains("vietinbank") ||
            lower.contains("agribank") ||
            lower.contains("bidv") ||
            lower.contains("vpbank") ||
            lower.contains("tpbank") ||
            lower.contains("sacombank") ||
            lower.contains("hdbank") ||
            lower.contains("eximbank") ||
            lower.contains("seabank") ||
            lower.contains("lienviet") ||
            lower.contains("lpbank") ||
            lower.contains("myvib") ||
            lower.contains("shinhan") ||
            lower.contains("cake.digitalbank") ||
            lower.contains("vneid") ||
            lower.contains("vssid") ||
            lower.contains("etax") ||
            lower.contains("ihanoi") ||
            lower.contains("baohiemxahoi") ||
            lower.contains(".gov.") ||
            lower.endsWith(".gov") ||
            lower.startsWith("gov.") ||
            lower.contains(".gov.vn") ||
            lower.contains("dichvucong") ||
            lower.contains("banking") ||
            lower.contains("smartbanking") ||
            lower.contains("mobilebanking") ||
            lower.contains("ebanking") ||
            lower.contains("digibank") ||
            lower.contains("digi_bank") ||
            lower.contains("smartotp") ||
            lower.contains("softotp") ||
            lower.contains("vnpay") ||
            lower.contains("zalopay") ||
            lower.contains("momopay") ||
            lower.contains("momotransfer") ||
            lower.contains("viettelpay") ||
            lower.contains("viettelmoney")
    }

    private val browserKeywords = listOf(
        "chrome",
        "browser",
        "webview",
        "firefox",
        "mozilla",
        "emmx",
        "coccoc",
        "opera",
        "brave",
        "sbrowser",
        "ucmobile",
        "quark",
        "duckduckgo",
        "vivaldi",
        "kiwi"
    )

    fun isBrowserOrWebViewPackage(pkg: String): Boolean {
        if (pkg.isBlank()) return false
        val lower = pkg.lowercase()
        return browserKeywords.any { lower.contains(it) }
    }

    fun isServiceConnected(): Boolean = MagicTuneCtsAccessibilityService.isServiceConnected() || MagicTuneVoiceInteractionService.instance != null

    fun ensureServiceEnabledViaSecureSettings(context: Context): Boolean {
        val appCtx = context.applicationContext ?: context
        lastAppContextRef = appCtx
        // Bật ngầm dịch vụ trợ năng theo nhu cầu (đã có cơ chế tự tắt 100% ngay khi phát hiện app ngân hàng)
        return MagicTuneCtsAccessibilityService.ensureServiceEnabledViaSecureSettings(appCtx)
    }

    fun disableServiceViaSecureSettings(context: Context, forceDisableSelf: Boolean = false) {
        clearCachedScreenNodes()
        MagicTuneCtsAccessibilityService.disableServiceViaSecureSettings(context, forceDisableSelf)
    }

    fun forceDisableServiceNow(context: Context) {
        clearCachedScreenNodes()
        MagicTuneCtsAccessibilityService.forceDisableServiceNow(context)
    }

    fun enterDeepSleepNow(context: Context, forceImmediate: Boolean = true) {
        clearCachedScreenNodes()
        MagicTuneCtsAccessibilityService.enterDeepSleepNow(context, forceImmediate)
    }

    fun disableServiceIfIdle(context: Context, idleDelayMs: Long = 250L) {
        if (idleDelayMs <= 60L) {
            enterDeepSleepNow(context, forceImmediate = false)
        } else {
            MagicTuneCtsAccessibilityService.disableServiceIfIdle(context, idleDelayMs)
        }
    }

    @Volatile
    private var lastAutoWakeFailureMs: Long = 0L

    /**
     * Mặc định tự đánh thức Trợ năng ngầm trước khi MagicLive / Dịch Cuộn / Khoanh màn hình làm việc.
     * Trả về true ngay 0ms nếu đang kết nối, giữ an toàn tuyệt đối khi ở Banking/VNeID hoặc Cài đặt.
     */
    suspend fun autoWakeAccessibilityIfNeeded(context: Context, maxWaitMs: Long = 1350L): Boolean {
        val appCtx = context.applicationContext ?: context
        lastAppContextRef = appCtx
        if (MagicTuneCtsAccessibilityService.isServiceConnected()) {
            lastAutoWakeFailureMs = 0L
            return true
        }
        val now = System.currentTimeMillis()
        if (now - lastAutoWakeFailureMs < 1_500L) {
            return MagicTuneCtsAccessibilityService.isServiceConnected()
        }
        val res = MagicTuneCtsAccessibilityService.wakeUpAccessibilityService(appCtx, maxWaitMs = maxWaitMs)
        val ok = res.connected || MagicTuneCtsAccessibilityService.isServiceConnected()
        lastAutoWakeFailureMs = if (ok) 0L else System.currentTimeMillis()
        return ok
    }

    suspend fun wakeUpBackgroundAccessibility(context: Context): MagicTuneCtsAccessibilityService.WakeUpResult {
        val appCtx = context.applicationContext ?: context
        lastAppContextRef = appCtx
        clearForegroundPackageCache()
        clearCachedScreenNodes()
        lastAutoWakeFailureMs = 0L
        return MagicTuneCtsAccessibilityService.wakeUpAccessibilityService(appCtx)
    }

    fun awaitServiceInstance(context: Context, maxWaitMs: Long = 750L): NoAccessibilityScreenEngine {
        val appCtx = context.applicationContext ?: context
        lastAppContextRef = appCtx
        MagicTuneCtsAccessibilityService.awaitServiceInstance(appCtx, maxWaitMs)
        return this
    }

    fun extractFullUiRecordsNow(context: Context): List<UiNodeRecord> {
        val appCtx = context.applicationContext ?: context
        if (MagicTuneCtsAccessibilityService.isServiceConnected()) {
            val records = MagicTuneCtsAccessibilityService.extractNodesFromActiveWindow(appCtx)
            if (records.isNotEmpty()) {
                cachedFullUiNodes = records
                cachedUiNodesTimestampMs = System.currentTimeMillis()
                return records
            }
        }
        if (cachedFullUiNodes.isNotEmpty()) {
            return cachedFullUiNodes
        }
        return emptyList()
    }

    fun clearCachedScreenNodes() {
        lastCapturedScreenNodes = emptyList()
        cachedFullUiNodes = emptyList()
        cachedUiNodesTimestampMs = 0L
    }

    fun updateAssistStructureCache(
        context: Context,
        records: List<UiNodeRecord>,
        foregroundPkg: String
    ) {
        cachedFullUiNodes = records
        cachedUiNodesTimestampMs = System.currentTimeMillis()
        if (foregroundPkg.isNotBlank()) {
            cachedForegroundPackage = foregroundPkg
        }
        val dm = context.resources.displayMetrics
        val screenW = dm.widthPixels.coerceAtLeast(1)
        val screenH = dm.heightPixels.coerceAtLeast(1)
        val textNodes = convertUiRecordsToScreenTextNodes(records, screenW, screenH)
        if (textNodes.isNotEmpty()) {
            lastCapturedScreenNodes = mergeAdjacentCurrencyAndPriceNodes(textNodes)
        }
    }

    fun notifyForegroundPackageChanged(pkg: String) {
        if (pkg.isNotBlank() && pkg != "com.android.systemui") {
            cachedForegroundPackage = pkg
            cachedForegroundPackageTimestampMs = System.currentTimeMillis()
        }
    }

    fun invalidateForegroundPackageCache() {
        // Chỉ đặt lại mốc thời gian để ép đọc UsageEvents mới, giữ nguyên gói tiền cảnh gần nhất nếu người dùng vẫn đang ở trong cùng 1 app
        cachedForegroundPackageTimestampMs = 0L
    }

    fun clearForegroundPackageCache() {
        cachedForegroundPackage = ""
        cachedForegroundPackageTimestampMs = 0L
    }

    fun getActiveForegroundPackage(context: Context? = null, forceFresh: Boolean = false): String? {
        val now = System.currentTimeMillis()
        // Giữ bộ nhớ đệm 1800ms để nhận diện nhanh app Ngân hàng / VNeID mà không spam IPC UsageStatsManager
        val cacheValidityLimit = 1_800L
        if (!forceFresh && cachedForegroundPackage.isNotBlank() && (now - cachedForegroundPackageTimestampMs < cacheValidityLimit)) {
            return cachedForegroundPackage
        }

        if (context != null) {
            val appCtx = context.applicationContext ?: context
            try {
                val usm = appCtx.getSystemService(Context.USAGE_STATS_SERVICE) as? android.app.usage.UsageStatsManager
                if (usm != null) {
                    val end = System.currentTimeMillis()
                    // Quét cửa sổ ngắn (120 giây lần đầu/forceFresh, 10 giây các lần thường) để UsageStats IPC phản hồi < 2ms
                    val lookbackMs = if (forceFresh || cachedForegroundPackage.isBlank()) 120_000L else 10_000L
                    val begin = end - lookbackMs
                    val events = usm.queryEvents(begin, end)
                    val event = android.app.usage.UsageEvents.Event()
                    var lastResumedPkg: String? = null
                    var lastResumedTs = -1L
                    var lastPausedOrStoppedPkg: String? = null
                    var lastPausedOrStoppedTs = -1L
                    while (events.hasNextEvent()) {
                        events.getNextEvent(event)
                        val ep = event.packageName
                        if (!ep.isNullOrBlank() && ep != "com.android.systemui") {
                            when (event.eventType) {
                                android.app.usage.UsageEvents.Event.ACTIVITY_RESUMED -> {
                                    lastResumedPkg = ep
                                    lastResumedTs = event.timeStamp
                                }
                                android.app.usage.UsageEvents.Event.ACTIVITY_PAUSED,
                                android.app.usage.UsageEvents.Event.ACTIVITY_STOPPED -> {
                                    lastPausedOrStoppedPkg = ep
                                    lastPausedOrStoppedTs = event.timeStamp
                                }
                            }
                        }
                    }

                    // Nếu app Ngân hàng / VNeID vừa PAUSED/STOPPED mà chưa có ACTIVITY_RESUMED mới hơn -> Giải phóng ngay 0ms!
                    if (!lastPausedOrStoppedPkg.isNullOrBlank() &&
                        isSensitiveBankingPackage(lastPausedOrStoppedPkg) &&
                        lastPausedOrStoppedTs >= lastResumedTs
                    ) {
                        cachedForegroundPackage = ""
                        cachedForegroundPackageTimestampMs = now
                        notifyBankingTransition(appCtx, enteredBanking = false)
                        return null
                    }

                    if (!lastResumedPkg.isNullOrBlank()) {
                        cachedForegroundPackage = lastResumedPkg
                        cachedForegroundPackageTimestampMs = now
                        notifyBankingTransition(appCtx, enteredBanking = isSensitiveBankingPackage(lastResumedPkg))
                        return lastResumedPkg
                    }

                    // Nếu người dùng vẫn đang ở yên trong cùng 1 ứng dụng quá 10 giây (không phát sinh sự kiện chuyển Activity mới),
                    // giữ nguyên gói tiền cảnh đã biết và không gọi dumpsys window gây tốn CPU!
                    if (cachedForegroundPackage.isNotBlank()) {
                        cachedForegroundPackageTimestampMs = now
                        return cachedForegroundPackage
                    }
                }
            } catch (_: Throwable) {}
        }

        return cachedForegroundPackage.ifBlank { null }
    }

    fun getActiveForegroundAppLabel(context: Context): String {
        val pkg = getActiveForegroundPackage(context)?.trim().orEmpty()
        if (pkg.isBlank() || pkg == context.packageName || pkg == "com.android.systemui") return ""

        val knownAppMap = mapOf(
            "com.zing.zalo" to "Zalo",
            "com.facebook.orca" to "Messenger",
            "com.facebook.mlite" to "Messenger Lite",
            "org.telegram.messenger" to "Telegram",
            "org.telegram.messenger.web" to "Telegram",
            "org.thunderdog.challegram" to "Telegram X",
            "com.tencent.mm" to "WeChat (微信)",
            "com.tencent.mobileqq" to "QQ",
            "com.alibaba.wireless" to "1688 (阿里巴巴)",
            "com.taobao.taobao" to "Taobao (淘宝)",
            "com.xunmeng.pinduoduo" to "Pinduoduo (拼多多)",
            "com.tmall.wireless" to "Tmall (天猫)",
            "com.whatsapp" to "WhatsApp",
            "com.whatsapp.w4b" to "WhatsApp Business",
            "jp.naver.line.android" to "LINE",
            "com.kakao.talk" to "KakaoTalk",
            "com.viber.voip" to "Viber",
            "com.instagram.android" to "Instagram",
            "com.ss.android.ugc.trill" to "TikTok",
            "com.zhiliaoapp.musically" to "TikTok",
            "com.ss.android.ugc.aweme" to "Douyin (抖音)",
            "com.shopee.vn" to "Shopee",
            "com.lazada.android" to "Lazada",
            "com.alibaba.intl.android.apps.poseidon" to "Alibaba.com",
            "com.alibaba.android.rimet" to "DingTalk (钉钉)",
            "com.xingin.xhs" to "Xiaohongshu (小红书)"
        )
        knownAppMap[pkg]?.let { return it }

        return try {
            val pm = context.packageManager
            val appInfo = pm.getApplicationInfo(pkg, 0)
            val label = pm.getApplicationLabel(appInfo).toString().trim()
            if (label.isNotBlank()) label else pkg
        } catch (_: Throwable) {
            pkg
        }
    }

    private fun convertUiRecordsToScreenTextNodes(
        records: List<UiNodeRecord>,
        screenW: Int,
        screenH: Int
    ): List<ScreenTextNode> {
        val rawNodes = mutableListOf<ScreenTextNode>()
        val visitedRects = HashSet<String>()
        val maxAllowedHeight = (screenH * 0.65f).toInt()

        for (rec in records) {
            val r = rec.bounds
            val intersectsScreen = r.right > 2 &&
                r.left < screenW - 2 &&
                r.bottom > 34 &&
                r.top < screenH - 22
            if (!intersectsScreen || r.width() < 6 || r.height() < 8 || r.height() >= maxAllowedHeight) continue

            val chosen = when {
                rec.text.isNotEmpty() -> rec.text
                rec.contentDesc.isNotEmpty() -> {
                    val descLower = rec.contentDesc.lowercase()
                    // LỌC BỎ 100% nhãn mô tả hình ảnh, ảnh đại diện, avatar và icon nút bấm (Tránh đọc nhầm "hình đại diện")
                    if (descLower.contains("hình đại diện") ||
                        descLower.contains("ảnh đại diện") ||
                        descLower.contains("avatar") ||
                        descLower.contains("profile picture") ||
                        descLower.contains("user avatar") ||
                        descLower.contains("profile photo") ||
                        descLower.contains("头像") ||
                        descLower == "quay lại" || descLower == "back" ||
                        descLower == "gửi" || descLower == "send" ||
                        descLower == "micro" || descLower == "chụp ảnh" ||
                        descLower == "nhãn dán" || descLower == "sticker" ||
                        descLower == "tin nhắn thoại" || descLower == "thêm"
                    ) {
                        ""
                    } else {
                        rec.contentDesc
                    }
                }
                rec.hint.isNotEmpty() -> rec.hint
                else -> ""
            }
            if (chosen.isNotEmpty() && chosen.length <= 520) {
                val clipped = Rect(
                    r.left.coerceIn(0, screenW),
                    r.top.coerceIn(0, screenH),
                    r.right.coerceIn(0, screenW),
                    r.bottom.coerceIn(0, screenH)
                )
                if (clipped.width() >= 6 && clipped.height() >= 8) {
                    val key = "${chosen}_${clipped.left / 6}_${clipped.top / 6}"
                    if (visitedRects.add(key)) {
                        rawNodes.add(ScreenTextNode(chosen, clipped))
                    }
                }
            }
        }
        return rawNodes
    }

    /**
     * Chụp màn hình Offline hoàn toàn KHÔNG CẦN QUYỀN TRỢ NĂNG:
     * - Bảo vệ quyền riêng tư & bảo mật: nếu đang mở ứng dụng ngân hàng, lập tức trả về null.
     * - Tầng 1: MediaProjection + ImageReader công khai của Android (~15ms).
     * - Tầng 2: Digital Assistant Framework (`MagicTuneVoiceInteractionService.requestSilentCaptureViaAssist`).
     * - Tầng 3: ShellEngine `screencap -p` khi có kết nối Shizuku / ADB.
     * - Tầng 4: Bộ nhớ đệm Assist gần nhất (<3.5s).
     */
    suspend fun captureScreenOffline(
        context: Context,
        skipFullScreenDownscale: Boolean = false
    ): Bitmap? = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext ?: context
        lastAppContextRef = appCtx

        // 1. Kiểm tra an ninh ứng dụng Ngân hàng (tận dụng bộ nhớ đệm 600ms & cập nhật 0ms từ A11y để tránh spam UsageStats IPC)
        val currentFg = getActiveForegroundPackage(appCtx)
        if (currentFg != null && isSensitiveBankingPackage(currentFg)) {
            Log.w(TAG, "Sensitive banking app detected ($currentFg). Screen capture blocked.")
            withContext(Dispatchers.Main) {
                onBankingAppDetectedCallback?.invoke()
            }
            return@withContext null
        }

        // Tầng 0A: Sử dụng ngay ảnh chụp vừa nhận được từ phiên Trợ lý Kỹ thuật số (< 5 giây) khi chụp tĩnh
        if (!isLiveScrollTranslateActive) {
            val recentBmp = MagicTuneVoiceInteractionService.lastCapturedAssistBitmap
            val recentAge = System.currentTimeMillis() - MagicTuneVoiceInteractionService.lastCapturedAssistTimeMs
            if (isBitmapValidAndNotBlack(recentBmp) && recentAge < 5000L) {
                Log.d(TAG, "Using fresh assist screenshot from VoiceInteraction (age: ${recentAge}ms)")
                return@withContext recentBmp
            }
        }

        // Tầng 1 (ƯU TIÊN SỐ 1 ANDROID 11+): AccessibilityService.takeScreenshot() (không giữ VirtualDisplay nền)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            if (!MediaProjectionHolder.isProjectionActive && MagicTuneCtsAccessibilityService.instance == null) {
                autoWakeAccessibilityIfNeeded(appCtx, maxWaitMs = 1200L)
            }
            val existingSvc = MagicTuneCtsAccessibilityService.instance
            val a11ySvc = existingSvc ?: if (!MediaProjectionHolder.isProjectionActive) {
                MagicTuneCtsAccessibilityService.awaitServiceInstance(appCtx, 600L)
            } else null
            if (a11ySvc != null) {
                try {
                    var a11yBmp = MagicTuneCtsAccessibilityService.captureScreenViaAccessibility(appCtx)
                    if (!isBitmapValidAndNotBlack(a11yBmp) && MagicTuneCtsAccessibilityService.isServiceConnected()) {
                        kotlinx.coroutines.delay(90L)
                        a11yBmp = MagicTuneCtsAccessibilityService.captureScreenViaAccessibility(appCtx)
                    }
                    if (a11yBmp != null && isBitmapValidAndNotBlack(a11yBmp)) {
                        if (skipFullScreenDownscale) {
                            return@withContext a11yBmp
                        }
                        val maxAllowed = com.example.core.compat.DeviceCompatProfile.recommendedOcrMaxSidePx(appCtx)
                        val maxSide = max(a11yBmp.width, a11yBmp.height)
                        val res = if (maxSide > maxAllowed) {
                            val scale = maxAllowed.toFloat() / maxSide.toFloat()
                            val sw = (a11yBmp.width * scale).toInt().coerceAtLeast(1)
                            val sh = (a11yBmp.height * scale).toInt().coerceAtLeast(1)
                            val scaled = Bitmap.createScaledBitmap(a11yBmp, sw, sh, true)
                            if (scaled !== a11yBmp) a11yBmp.recycle()
                            scaled
                        } else {
                            a11yBmp
                        }
                        return@withContext res
                    }
                } catch (_: Throwable) {}
            }
        }

        // Tầng 2A: Digital Assistant Framework (Chụp trực tiếp qua VoiceInteractionSession khi đã cấp Trợ lý mặc định)
        if (MagicTuneVoiceInteractionService.isDefaultAssistant(appCtx)) {
            val assistBmp = MagicTuneVoiceInteractionService.requestSilentCaptureViaAssist(
                context = appCtx,
                needScreenshot = true,
                timeoutMs = 550L
            )
            if (isBitmapValidAndNotBlack(assistBmp)) {
                return@withContext assistBmp
            }
        }

        // Tầng 2B: Dự phòng MediaProjection (nếu takeScreenshot() không khả dụng hoặc Android < 11)
        if (MediaProjectionHolder.isProjectionActive) {
            try {
                val projBmp = MediaProjectionHolder.captureCurrentScreen(appCtx)
                if (projBmp != null && isBitmapValidAndNotBlack(projBmp)) {
                    if (skipFullScreenDownscale) {
                        return@withContext projBmp
                    }
                    val maxAllowed = com.example.core.compat.DeviceCompatProfile.recommendedOcrMaxSidePx(appCtx)
                    val maxSide = max(projBmp.width, projBmp.height)
                    return@withContext if (maxSide > maxAllowed) {
                        val scale = maxAllowed.toFloat() / maxSide.toFloat()
                        val sw = (projBmp.width * scale).toInt().coerceAtLeast(1)
                        val sh = (projBmp.height * scale).toInt().coerceAtLeast(1)
                        val scaled = Bitmap.createScaledBitmap(projBmp, sw, sh, true)
                        if (scaled !== projBmp) projBmp.recycle()
                        scaled
                    } else {
                        projBmp
                    }
                }
            } catch (e: Throwable) {
                Log.d(TAG, "Fast MediaProjection capture attempt: ${e.message}")
            }
        }

        // Tầng 3: ShellEngine (screencap -p) qua Shizuku / WLAN ADB vào externalCacheDir để không bị SELinux chặn đọc file
        val shell = ShellEngine.getInstance(appCtx)
        if (shell.state.value.isAdbReady) {
            val rawBmp = withTimeoutOrNull(2400L) {
                val outDir = appCtx.externalCacheDir ?: appCtx.cacheDir
                outDir?.mkdirs()
                val tmpFile = File(outDir, "magictune_cts.png")
                if (tmpFile.exists()) tmpFile.delete()
                val absPath = tmpFile.absolutePath
                val sdcardFallback = "${android.os.Environment.getExternalStorageDirectory().path}/Android/data/${appCtx.packageName}/cache/magictune_cts.png"
                shell.execute(
                    "screencap -p '$absPath' 2>/dev/null || screencap -p '$sdcardFallback' 2>/dev/null; " +
                        "chmod 666 '$absPath' '$sdcardFallback' 2>/dev/null || true"
                )
                val targetFile = if (tmpFile.exists() && tmpFile.length() > 1024L) {
                    tmpFile
                } else {
                    File(sdcardFallback)
                }
                if (targetFile.exists() && targetFile.length() > 1024L) {
                    BitmapFactory.decodeFile(targetFile.absolutePath)
                } else null
            }
            if (rawBmp != null && isBitmapValidAndNotBlack(rawBmp)) {
                if (skipFullScreenDownscale) {
                    return@withContext rawBmp
                }
                val maxAllowed = com.example.core.compat.DeviceCompatProfile.recommendedOcrMaxSidePx(appCtx)
                val maxSide = max(rawBmp.width, rawBmp.height)
                return@withContext if (maxSide > maxAllowed) {
                    val scale = maxAllowed.toFloat() / maxSide.toFloat()
                    val sw = (rawBmp.width * scale).toInt().coerceAtLeast(1)
                    val sh = (rawBmp.height * scale).toInt().coerceAtLeast(1)
                    val scaled = Bitmap.createScaledBitmap(rawBmp, sw, sh, true)
                    if (scaled !== rawBmp) rawBmp.recycle()
                    scaled
                } else {
                    rawBmp
                }
            }
        }

        // Tầng 4: Dự phòng ảnh chụp trợ lý nếu chưa được giải phóng
        val fallbackBmp = MagicTuneVoiceInteractionService.lastCapturedAssistBitmap
        val fallbackAge = System.currentTimeMillis() - MagicTuneVoiceInteractionService.lastCapturedAssistTimeMs
        if (isBitmapValidAndNotBlack(fallbackBmp) && fallbackAge < 5000L) {
            return@withContext fallbackBmp
        }

        return@withContext null
    }

    /**
     * Kiểm tra Bitmap có hợp lệ và KHÔNG phải là khung hình đen xì (all-black transition buffer / FLAG_SECURE) hay không.
     */
    fun isBitmapValidAndNotBlack(bmp: Bitmap?): Boolean {
        if (bmp == null || bmp.isRecycled || bmp.width < 16 || bmp.height < 16) return false
        // Tránh copy 14MB GPU HARDWARE bitmap chỉ để kiểm tra vài điểm ảnh
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && bmp.config == Bitmap.Config.HARDWARE) {
            return true
        }
        return try {
            val w = bmp.width
            val h = bmp.height
            var nonBlackPixels = 0
            val grid = 4
            for (gx in 1..grid) {
                for (gy in 1..grid) {
                    val x = (w * gx) / (grid + 1)
                    val y = (h * gy) / (grid + 1)
                    val px = bmp.getPixel(x.coerceIn(0, w - 1), y.coerceIn(0, h - 1))
                    val a = (px ushr 24) and 0xFF
                    val r = (px ushr 16) and 0xFF
                    val g = (px ushr 8) and 0xFF
                    val b = px and 0xFF
                    if (a > 20 && (r > 8 || g > 8 || b > 8)) {
                        nonBlackPixels++
                        if (nonBlackPixels >= 2) {
                            return true
                        }
                    }
                }
            }
            false
        } catch (_: Throwable) {
            true
        }
    }

    /**
     * Luồng đọc siêu tốc 0 độ trễ (~2-25ms) CHỈ DÙNG TRỢ NĂNG NGẦM ON-DEMAND (không chụp ảnh, không gọi ML Kit OCR):
     * Dùng cho Pha 1 của Dịch Cuộn Tức Thì để hiển thị ngay bản dịch & quy đổi VNĐ trong tích tắc ngay khi bấm nút.
     */
    suspend fun extractFastA11yNodesOnly(
        context: Context,
        maxWaitMs: Long = 420L
    ): List<ScreenTextNode> = withContext(Dispatchers.Default) {
        val appCtx = context.applicationContext ?: context
        lastAppContextRef = appCtx

        val currentFg = getActiveForegroundPackage(appCtx)
        if (currentFg != null && (isSensitiveBankingPackage(currentFg) || MagicTuneCtsAccessibilityService.isSystemSettingsPackage(currentFg))) {
            return@withContext emptyList()
        }

        MagicTuneCtsAccessibilityService.beginTemporaryBurst(1600L)
        try {
            if (MagicTuneCtsAccessibilityService.instance == null) {
                autoWakeAccessibilityIfNeeded(appCtx, maxWaitMs = maxWaitMs.coerceAtLeast(1100L))
            }
            val a11ySvc = MagicTuneCtsAccessibilityService.instance
                ?: MagicTuneCtsAccessibilityService.awaitServiceInstance(appCtx, maxWaitMs)
            if (a11ySvc != null) {
                val a11yRecords = MagicTuneCtsAccessibilityService.extractNodesFromActiveWindow(appCtx)
                if (a11yRecords.isNotEmpty()) {
                    val dm = appCtx.resources.displayMetrics
                    val screenW = dm.widthPixels.coerceAtLeast(1)
                    val screenH = dm.heightPixels.coerceAtLeast(1)
                    val rawNodes = convertUiRecordsToScreenTextNodes(a11yRecords, screenW, screenH)
                    if (rawNodes.isNotEmpty()) {
                        val merged = mergeAdjacentCurrencyAndPriceNodes(rawNodes)
                        lastCapturedScreenNodes = merged
                        return@withContext merged
                    }
                }
            }
            return@withContext emptyList()
        } finally {
            MagicTuneCtsAccessibilityService.endTemporaryBurstAndIdle(appCtx, 80L)
        }
    }

    /**
     * Bổ sung các node văn bản vẽ bằng Canvas / Hình ảnh qua ML Kit OCR (chỉ gọi khi cây Accessibility rỗng hoặc thiếu node trên app TMĐT).
     */
    suspend fun supplementWithOcrNodes(
        context: Context,
        existingA11yNodes: List<ScreenTextNode>
    ): List<ScreenTextNode> = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext ?: context
        val bitmap = captureScreenOffline(appCtx) ?: return@withContext existingA11yNodes
        val shouldRecycle = bitmap !== MagicTuneVoiceInteractionService.lastCapturedAssistBitmap &&
            bitmap !== MediaProjectionHolder.lastCapturedBitmap
        try {
            val ocrNodes = if (isLiveScrollTranslateActive) {
                ScreenOcrEngine.recognizeScrollRegionTextNodes(bitmap)
            } else {
                ScreenOcrEngine.recognizeScreenTextNodes(bitmap)
            }
            if (ocrNodes.isNotEmpty()) {
                val mergedOcr = mergeAdjacentCurrencyAndPriceNodes(ocrNodes)
                val combined = combineA11yAndOcrNodes(existingA11yNodes, mergedOcr)
                lastCapturedScreenNodes = combined
                return@withContext combined
            }
        } catch (_: Throwable) {
        } finally {
            if (shouldRecycle && !bitmap.isRecycled) {
                try { bitmap.recycle() } catch (_: Throwable) {}
            }
        }
        existingA11yNodes
    }

    /**
     * Trích xuất toàn bộ văn bản và tọa độ Bounding Box Pixel trên màn hình bằng Google ML Kit OCR
     * mà HOÀN TOÀN KHÔNG CẦN QUYỀN TRỢ NĂNG.
     */
    suspend fun extractVisibleScreenNodesNow(context: Context): List<ScreenTextNode> = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext ?: context
        lastAppContextRef = appCtx

        // Kiểm tra an ninh ứng dụng Ngân hàng
        val currentFg = getActiveForegroundPackage(appCtx)
        if (currentFg != null && isSensitiveBankingPackage(currentFg)) {
            Log.w(TAG, "Banking app detected ($currentFg). Returning empty OCR nodes.")
            return@withContext emptyList()
        }

        // Giữ burst xuyên suốt cả 2 tầng (Accessibility Node -> Capture/OCR) để không bị tắt giữa chừng
        MagicTuneCtsAccessibilityService.beginTemporaryBurst(2800L)
        try {
        // Tầng 0: Trích xuất trực tiếp từ Cây Giao Diện Trợ Năng Ngầm (0ms On-Demand burst, 100% chuẩn xác)
        var a11yNodes = extractFastA11yNodesOnly(appCtx, maxWaitMs = 520L)

        // Tầng 0A: Nếu Trợ Năng chưa bật, sử dụng ngay cây chữ từ AssistStructure vừa trích xuất qua phiên Trợ lý
        // (CHỈ DÙNG KHI CHỤP TĨNH 1 LẦN, TUYỆT ĐỐI KHÔNG DÙNG KHI ĐANG DỊCH CUỘN TRỰC TIẾP ĐỂ TRÁNH DÙNG LẠI NỘI DUNG CỦA TRANG CŨ)
        if (!isLiveScrollTranslateActive) {
            if (a11yNodes.isEmpty() && lastCapturedScreenNodes.isNotEmpty()) {
                a11yNodes = lastCapturedScreenNodes
            } else if (a11yNodes.isEmpty() && cachedFullUiNodes.isNotEmpty()) {
                val dm = appCtx.resources.displayMetrics
                val screenW = dm.widthPixels.coerceAtLeast(1)
                val screenH = dm.heightPixels.coerceAtLeast(1)
                val assistTextNodes = convertUiRecordsToScreenTextNodes(cachedFullUiNodes, screenW, screenH)
                if (assistTextNodes.isNotEmpty()) {
                    a11yNodes = mergeAdjacentCurrencyAndPriceNodes(assistTextNodes)
                    lastCapturedScreenNodes = a11yNodes
                }
            }
        }

        // Kiểm tra xem a11yNodes đã đủ để hiển thị trọn vẹn chưa:
        // Các app TMĐT như 1688, Taobao vẽ tiêu đề sản phẩm, banner, phân loại bằng Canvas/Weex không có accessibility node,
        // hoặc khi a11yNodes có ít hơn 14 node hoặc không chứa chữ Trung trong app Trung Quốc:
        val isEcommerceApp = currentFg != null && (
            currentFg.contains("alibaba") ||
            currentFg.contains("taobao") ||
            currentFg.contains("pinduoduo") ||
            currentFg.contains("tmall") ||
            currentFg.contains("jd") ||
            currentFg.contains("aliexpress")
        )
        val hasCjkInA11y = a11yNodes.any { node ->
            node.text.any { it.code in 0x4E00..0x9FFF || it.code in 0x3040..0x30FF || it.code in 0xAC00..0xD7AF }
        }
        val isA11ySufficient = when {
            isEcommerceApp -> (a11yNodes.size >= 8 && hasCjkInA11y) || a11yNodes.size >= 14
            else -> a11yNodes.isNotEmpty()
        }

        if (isA11ySufficient) {
            lastCapturedScreenNodes = a11yNodes
            return@withContext a11yNodes
        }

        // Tầng 1: Chụp ảnh màn hình & Nhận diện OCR Google ML Kit Chinese + Latin (Cắt vùng cuộn & kiểm tra khung hình trùng khi Dịch Cuộn)
        val bitmap = captureScreenOffline(appCtx)
        if (bitmap != null) {
            val shouldRecycle = bitmap !== MagicTuneVoiceInteractionService.lastCapturedAssistBitmap &&
                bitmap !== MediaProjectionHolder.lastCapturedBitmap
            try {
                val ocrNodes = if (isLiveScrollTranslateActive) {
                    ScreenOcrEngine.recognizeScrollRegionTextNodes(bitmap)
                } else {
                    ScreenOcrEngine.recognizeScreenTextNodes(bitmap)
                }
                if (ocrNodes.isNotEmpty()) {
                    val mergedOcr = mergeAdjacentCurrencyAndPriceNodes(ocrNodes)
                    val combined = combineA11yAndOcrNodes(a11yNodes, mergedOcr)
                    lastCapturedScreenNodes = combined
                    return@withContext combined
                }
            } catch (e: Throwable) {
                Log.e(TAG, "ML Kit OCR processing error: ${e.message}")
            } finally {
                if (shouldRecycle) {
                    try { bitmap.recycle() } catch (_: Throwable) {}
                }
            }
        }

        if (a11yNodes.isNotEmpty()) {
            lastCapturedScreenNodes = a11yNodes
            return@withContext a11yNodes
        }

        // 2. Dự phòng qua cấu trúc AssistStructure của VoiceSession
        if (cachedFullUiNodes.isNotEmpty()) {
            val dm = appCtx.resources.displayMetrics
            val screenW = dm.widthPixels.coerceAtLeast(1)
            val screenH = dm.heightPixels.coerceAtLeast(1)
            val rawNodes = convertUiRecordsToScreenTextNodes(cachedFullUiNodes, screenW, screenH)
            if (rawNodes.isNotEmpty()) {
                val merged = mergeAdjacentCurrencyAndPriceNodes(rawNodes)
                lastCapturedScreenNodes = merged
                return@withContext merged
            }
        }

        return@withContext lastCapturedScreenNodes
        } finally {
            if (!isLiveScrollTranslateActive) {
                MagicTuneCtsAccessibilityService.enterDeepSleepNow(appCtx, forceImmediate = false)
            } else {
                MagicTuneCtsAccessibilityService.endTemporaryBurstAndIdle(appCtx, 40L)
            }
        }
    }

    private fun combineA11yAndOcrNodes(
        a11yNodes: List<ScreenTextNode>,
        ocrNodes: List<ScreenTextNode>
    ): List<ScreenTextNode> {
        if (a11yNodes.isEmpty()) return ocrNodes
        if (ocrNodes.isEmpty()) return a11yNodes

        val result = a11yNodes.toMutableList()
        for (ocr in ocrNodes) {
            val ocx = ocr.boundsInScreen.centerX()
            val ocy = ocr.boundsInScreen.centerY()
            val overlaps = a11yNodes.any { a ->
                val acx = a.boundsInScreen.centerX()
                val acy = a.boundsInScreen.centerY()
                kotlin.math.abs(acx - ocx) < 45 && kotlin.math.abs(acy - ocy) < 32
            }
            if (!overlaps) {
                result.add(ocr)
            }
        }
        return result
    }

    private fun mergeAdjacentCurrencyAndPriceNodes(nodes: List<ScreenTextNode>): List<ScreenTextNode> {
        if (nodes.size <= 1) return nodes

        val sortedByCenterY = nodes.sortedWith(
            compareBy<ScreenTextNode> { it.boundsInScreen.centerY() }.thenBy { it.boundsInScreen.left }
        )
        val rowGroups = mutableListOf<MutableList<ScreenTextNode>>()

        for (node in sortedByCenterY) {
            val r = node.boundsInScreen
            val matchingRow = rowGroups.lastOrNull { group ->
                val ref = group.first().boundsInScreen
                val maxH = max(ref.height(), r.height())
                val verticalOverlap = min(ref.bottom, r.bottom) - max(ref.top, r.top)
                val sameBaseline = abs(ref.bottom - r.bottom) <= 26
                val closeCenterY = abs(ref.centerY() - r.centerY()) <= maxH * 0.85f
                verticalOverlap >= 4 || sameBaseline || closeCenterY
            }
            if (matchingRow != null) {
                matchingRow.add(node)
            } else {
                rowGroups.add(mutableListOf(node))
            }
        }

        val currencyPrefixRegex = Regex(
            """^(¥|￥|\$|US\$|₩|€|£|฿|NT\$|RMB|CNY|USD|KRW|JPY|券后|券后价|到手|到手价|折后|折后价|活动价|批发价|起批|原价|一口价|单价|[¥￥\$]\s*\d+([.,]\d+)?)$""",
            RegexOption.IGNORE_CASE
        )
        val numberOrPricePartRegex = Regex(
            """^(\d+([.,]\d+)?(\s*[-~～]\s*[¥￥\$]?\s*\d+([.,]\d+)?)?|\.\d+|,\d+|元|円|원|块|起|起批|/件|/个|/双|/套|/箱|/包|/斤|万|万\+|件起批|[¥￥]\s*\d+.*)$"""
        )

        val merged = mutableListOf<ScreenTextNode>()
        for (row in rowGroups) {
            row.sortBy { it.boundsInScreen.left }
            var i = 0
            while (i < row.size) {
                var current = row[i]
                var j = i + 1
                while (j < row.size) {
                    val next = row[j]
                    val gapX = next.boundsInScreen.left - current.boundsInScreen.right
                    val closeHorizontally = gapX in -24..68

                    val curTrim = current.text.trim()
                    val nextTrim = next.text.trim()

                    val curHasCurrency = curTrim.any { it in "¥￥$₩€£฿元" } || currencyPrefixRegex.matches(curTrim)
                    val curIsNumber = curTrim.matches(Regex("""^[¥￥\$]?\s*\d+([.,]\d+)?$"""))
                    val nextIsPricePart = numberOrPricePartRegex.matches(nextTrim)

                    val shouldMerge = closeHorizontally && (
                        (curHasCurrency && nextIsPricePart) ||
                            (currencyPrefixRegex.matches(curTrim) && (nextIsPricePart || nextTrim.any { it in "¥￥$₩€£฿" })) ||
                            (curIsNumber && (nextTrim.startsWith(".") || nextTrim.matches(Regex("""^(元|円|원|块|起|起批|/件|/个|/双|/套|万)$"""))))
                        )

                    if (shouldMerge) {
                        val noSpace = nextTrim.startsWith(".") ||
                            curTrim.endsWith("¥") ||
                            curTrim.endsWith("￥") ||
                            curTrim.endsWith("$")
                        val joiner = if (noSpace) "" else " "
                        val combinedText = (curTrim + joiner + nextTrim)
                            .replace(Regex("""([¥￥\$₩€£฿])\s+(\d)"""), "$1$2")
                            .replace(Regex("""(\d)\s+\.(\d)"""), "$1.$2")
                        val combinedRect = Rect(
                            min(current.boundsInScreen.left, next.boundsInScreen.left),
                            min(current.boundsInScreen.top, next.boundsInScreen.top),
                            max(current.boundsInScreen.right, next.boundsInScreen.right),
                            max(current.boundsInScreen.bottom, next.boundsInScreen.bottom)
                        )
                        current = ScreenTextNode(combinedText, combinedRect)
                        j++
                    } else {
                        break
                    }
                }
                merged.add(current)
                i = j
            }
        }
        return merged
    }

    /**
     * Thao tác chạm xuyên màn hình (Passthrough Tap) qua ShellEngine hoặc Intent
     */
    fun performPassthroughTapAt(
        context: Context,
        rawX: Float,
        rawY: Float,
        onComplete: (() -> Unit)? = null
    ) {
        val appCtx = context.applicationContext ?: context
        helperScope.launch {
            try {
                val shell = ShellEngine.getInstance(appCtx)
                if (shell.state.value.isAdbReady) {
                    shell.execute("input tap ${rawX.toInt()} ${rawY.toInt()}")
                }
            } catch (_: Throwable) {} finally {
                withContext(Dispatchers.Main) {
                    onComplete?.invoke()
                }
            }
        }
    }

    suspend fun dispatchGestureStrokeAndWait(
        context: Context,
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        durationMs: Long
    ): Boolean = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext ?: context
        try {
            if (!MagicTuneCtsAccessibilityService.isServiceConnected()) {
                autoWakeAccessibilityIfNeeded(appCtx, maxWaitMs = 950L)
            }
            if (MagicTuneCtsAccessibilityService.isServiceConnected()) {
                return@withContext MagicTuneCtsAccessibilityService.dispatchGestureStrokeAndWait(
                    context, startX, startY, endX, endY, durationMs
                )
            }
            val shell = ShellEngine.getInstance(appCtx)
            if (shell.state.value.isAdbReady) {
                shell.execute("input swipe ${startX.toInt()} ${startY.toInt()} ${endX.toInt()} ${endY.toInt()} $durationMs")
                return@withContext true
            }
            return@withContext false
        } finally {
            // Ngay sau khi vuốt/chạm xong, đưa Trợ năng ngầm vào ngủ sâu tức thì (0% CPU)
            MagicTuneCtsAccessibilityService.enterDeepSleepNow(appCtx)
        }
    }

    suspend fun performVoiceGlobalAction(context: Context, globalAction: Int): Boolean = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext ?: context
        try {
            if (!MagicTuneCtsAccessibilityService.isServiceConnected()) {
                autoWakeAccessibilityIfNeeded(appCtx, maxWaitMs = 950L)
            }
            if (MagicTuneCtsAccessibilityService.isServiceConnected()) {
                if (MagicTuneCtsAccessibilityService.performGlobalAction(globalAction)) {
                    return@withContext true
                }
            }
            val shell = ShellEngine.getInstance(appCtx)
            if (shell.state.value.isAdbReady) {
                when (globalAction) {
                    GLOBAL_ACTION_BACK -> shell.execute("input keyevent 4")
                    GLOBAL_ACTION_HOME -> shell.execute("input keyevent 3")
                    GLOBAL_ACTION_RECENTS -> shell.execute("input keyevent 187")
                    GLOBAL_ACTION_NOTIFICATIONS -> shell.execute("cmd statusbar expand-notifications")
                    GLOBAL_ACTION_QUICK_SETTINGS -> shell.execute("cmd statusbar expand-settings")
                    GLOBAL_ACTION_LOCK_SCREEN -> shell.execute("input keyevent 26")
                    GLOBAL_ACTION_TAKE_SCREENSHOT -> shell.execute("input keyevent 120")
                }
                return@withContext true
            }

            // Thực hiện qua Intent chuẩn Android nếu không có ADB
            when (globalAction) {
                GLOBAL_ACTION_HOME -> {
                    val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                        addCategory(Intent.CATEGORY_HOME)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    appCtx.startActivity(homeIntent)
                    return@withContext true
                }
            }
            return@withContext false
        } finally {
            // Ngay sau khi bấm phím xong, đưa Trợ năng ngầm vào ngủ sâu tức thì (0% CPU)
            MagicTuneCtsAccessibilityService.enterDeepSleepNow(appCtx)
        }
    }

    suspend fun performVoiceScrollOrSwipe(context: Context, direction: String): Boolean = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext ?: context
        val dm = appCtx.resources.displayMetrics
        val sw = dm.widthPixels
        val sh = dm.heightPixels

        val shell = ShellEngine.getInstance(appCtx)
        if (!shell.state.value.isAdbReady) return@withContext false

        val midX = sw / 2
        when (direction.uppercase()) {
            "DOWN", "SCROLL_DOWN", "CUỘN_XUỐNG", "VUỐT_LÊN" -> {
                val startY = (sh * 0.75f).toInt()
                val endY = (sh * 0.25f).toInt()
                shell.execute("input swipe $midX $startY $midX $endY 300")
                return@withContext true
            }
            "UP", "SCROLL_UP", "CUỘN_LÊN", "VUỐT_XUỐNG" -> {
                val startY = (sh * 0.25f).toInt()
                val endY = (sh * 0.75f).toInt()
                shell.execute("input swipe $midX $startY $midX $endY 300")
                return@withContext true
            }
            "LEFT", "VUỐT_TRÁI" -> {
                val startX = (sw * 0.85f).toInt()
                val endX = (sw * 0.15f).toInt()
                val midY = sh / 2
                shell.execute("input swipe $startX $midY $endX $midY 300")
                return@withContext true
            }
            "RIGHT", "VUỐT_PHẢI" -> {
                val startX = (sw * 0.15f).toInt()
                val endX = (sw * 0.85f).toInt()
                val midY = sh / 2
                shell.execute("input swipe $startX $midY $endX $midY 300")
                return@withContext true
            }
        }
        return@withContext false
    }

    suspend fun clickScreenElementByVoiceText(context: Context, targetQuery: String): Boolean = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext ?: context
        val nodes = extractVisibleScreenNodesNow(appCtx)
        val queryNorm = normalizeVi(targetQuery)

        val match = nodes.firstOrNull { normalizeVi(it.text).contains(queryNorm) } ?: return@withContext false
        val cx = match.boundsInScreen.centerX()
        val cy = match.boundsInScreen.centerY()

        val shell = ShellEngine.getInstance(appCtx)
        if (shell.state.value.isAdbReady) {
            shell.execute("input tap $cx $cy")
            return@withContext true
        }
        return@withContext false
    }

    suspend fun toggleSettingSwitchByTitle(context: Context, title: String, enable: Boolean): Boolean = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext ?: context
        val shell = ShellEngine.getInstance(appCtx)
        if (shell.state.value.isAdbReady) {
            val lower = title.lowercase()
            if (lower.contains("bluetooth")) {
                shell.execute("cmd bluetooth_manager " + (if (enable) "enable" else "disable"))
                return@withContext true
            } else if (lower.contains("wifi") || lower.contains("wi-fi")) {
                shell.execute("svc wifi " + (if (enable) "enable" else "disable"))
                return@withContext true
            }
        }
        return@withContext false
    }

    suspend fun clickFirstVideoOrContentCard(context: Context): Boolean = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext ?: context
        val dm = appCtx.resources.displayMetrics
        val cx = dm.widthPixels / 2
        val cy = (dm.heightPixels * 0.45f).toInt()

        val shell = ShellEngine.getInstance(appCtx)
        if (shell.state.value.isAdbReady) {
            shell.execute("input tap $cx $cy")
            return@withContext true
        }
        return@withContext false
    }

    suspend fun inputVoiceTextIntoScreenField(
        context: Context,
        textToInput: String,
        autoClickSend: Boolean = false
    ): Boolean = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext ?: context
        val shell = ShellEngine.getInstance(appCtx)
        if (shell.state.value.isAdbReady) {
            val safe = textToInput.replace("'", "").replace('"', ' ')
            shell.execute("input text '$safe'")
            if (autoClickSend) {
                shell.execute("input keyevent 66")
            }
            return@withContext true
        }
        return@withContext false
    }
    fun isInputMethodWindowShowing(): Boolean? {
        try {
            MagicTuneCtsAccessibilityService.isInputMethodWindowShowingNow()?.let { return it }
            val ctx = lastAppContextRef ?: return null
            val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager ?: return null
            val method = imm.javaClass.getMethod("getInputMethodWindowVisibleHeight")
            val height = (method.invoke(imm) as? Int) ?: 0
            return height > 0
        } catch (_: Throwable) {
            return null
        }
    }

    private fun normalizeVi(input: String): String {
        return Normalizer.normalize(input.lowercase(), Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .replace('đ', 'd')
            .trim()
    }
}
