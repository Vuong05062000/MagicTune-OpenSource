package com.example.ui.components

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.installer.AdminApkReleaseInspector
import com.example.core.installer.InAppApkUpdater
import com.example.core.license.LicenseManager
import com.example.data.APP_VERSION_NAME
import com.example.ui.theme.MagicAmber
import com.example.ui.theme.MagicAmberLight
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicCyanLight
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicEmeraldLight
import com.example.ui.theme.MagicRose
import com.example.ui.theme.MagicRoseLight
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.MagicSurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AdminApkReleaseCard(
    onPublishedUrl: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val currentRelease by LicenseManager.latestApkReleaseFlow.collectAsStateWithLifecycle()
    val installedVersionCode = remember { com.example.BuildConfig.VERSION_CODE.toLong() }

    var releaseNotes by remember {
        mutableStateOf("Cập nhật bản mới tối ưu hiệu năng, sửa lỗi và nâng cấp trải nghiệm mượt mà.")
    }
    var driveDownloadUrl by remember(currentRelease?.downloadUrl) {
        mutableStateOf(currentRelease?.downloadUrl?.takeIf { InAppApkUpdater.isSupportedApkFileLink(it) }.orEmpty())
    }
    var autoUpdateOldDevices by remember(currentRelease?.autoUpdateEnabled) {
        mutableStateOf(currentRelease?.autoUpdateEnabled ?: true)
    }
    var alsoBroadcastUpdate by remember { mutableStateOf(true) }

    var isPublishing by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var publishJob by remember { mutableStateOf<Job?>(null) }

    fun launchPublishTask(prepare: suspend () -> Result<AdminApkReleaseInspector.InspectedLocalApk>) {
        publishJob?.cancel()
        errorMessage = null
        val checkedApkUrl = driveDownloadUrl.trim()
        if (!InAppApkUpdater.isSupportedApkFileLink(checkedApkUrl)) {
            errorMessage = "Hãy dán link tệp .apk trên GitHub (Releases/Raw) hoặc link tệp Google Drive công khai ('Bất kỳ ai có đường liên kết')."
            return
        }
        val sourceLabel = InAppApkUpdater.detectApkSourceLabel(checkedApkUrl)
        statusMessage = "🔍 Đang kiểm tra tệp APK..."
        isPublishing = true

        publishJob = scope.launch {
            try {
                val preparedResult = prepare()
                val apkInfo = preparedResult.getOrElse { err ->
                    isPublishing = false
                    statusMessage = null
                    errorMessage = err.message ?: "Không thể đọc tệp APK."
                    return@launch
                }

                val sizeMb = String.format(Locale.US, "%.1f MB", apkInfo.sizeBytes / (1024.0 * 1024.0))
                statusMessage = "🔗 Đang phát hành link $sourceLabel cho v${apkInfo.versionName} ($sizeMb)..."
                LicenseManager.publishLatestApkRelease(
                    context = context,
                    downloadUrl = checkedApkUrl,
                    versionCode = apkInfo.versionCode,
                    versionName = apkInfo.versionName,
                    sizeBytes = apkInfo.sizeBytes,
                    releaseNotes = releaseNotes,
                    autoUpdateEnabled = autoUpdateOldDevices,
                    alsoSendUpdateBroadcast = alsoBroadcastUpdate
                )
                onPublishedUrl(checkedApkUrl)
                isPublishing = false
                statusMessage = "✅ Đã phát hành v${apkInfo.versionName} (build ${apkInfo.versionCode}) qua $sourceLabel."
                if (apkInfo.isTempStagingFile) runCatching { apkInfo.file.delete() }
                Toast.makeText(context, "✅ Đã phát hành link $sourceLabel v${apkInfo.versionName}!", Toast.LENGTH_LONG).show()
            } catch (e: CancellationException) {
                isPublishing = false
                statusMessage = "Đã hủy kiểm tra APK."
                throw e
            } catch (e: Throwable) {
                isPublishing = false
                statusMessage = null
                errorMessage = "Lỗi phát hành APK: ${e.message ?: "Không xác định"}"
            }
        }
    }

    // Bộ chọn tệp .APK qua Android SAF (0 quyền bộ nhớ)
    val apkPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            launchPublishTask {
                AdminApkReleaseInspector.prepareApkFromUri(context, uri)
            }
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
        border = BorderStroke(
            1.2.dp,
            if (currentRelease != null) MagicEmerald else MagicAmber
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.SystemUpdate,
                        contentDescription = null,
                        tint = MagicEmeraldLight,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "[Ô 1.0] 🚀 PHÁT HÀNH APK (GITHUB / GOOGLE DRIVE)",
                        color = MagicEmeraldLight,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Black
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(
                            if (currentRelease != null) MagicEmerald.copy(alpha = 0.2f)
                            else MagicAmber.copy(alpha = 0.2f)
                        )
                        .border(
                            1.dp,
                            if (currentRelease != null) MagicEmerald else MagicAmber,
                            RoundedCornerShape(6.dp)
                        )
                        .padding(horizontal = 7.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = if (currentRelease != null) "🟢 v${currentRelease?.versionName}" else "⚪ CHƯA ÚP",
                        color = if (currentRelease != null) MagicEmeraldLight else MagicAmberLight,
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            Text(
                text = "Tải APK lên GitHub Releases (khuyên dùng) hoặc Google Drive công khai ('Bất kỳ ai có đường liên kết'). Dán link ở đây rồi chọn tệp APK bên dưới để đọc phiên bản phát hành.",
                color = TextSecondary,
                fontSize = 10.5.sp,
                lineHeight = 15.sp
            )

            OutlinedTextField(
                value = driveDownloadUrl,
                onValueChange = { driveDownloadUrl = it },
                modifier = Modifier.fillMaxWidth().testTag("admin_apk_google_drive_url_input"),
                label = { Text("Link tệp APK (GitHub hoặc Google Drive)", fontSize = 10.5.sp) },
                placeholder = { Text("https://github.com/.../releases/download/.../app.apk hoặc drive.google.com/file/d/...", fontSize = 10.sp) },
                singleLine = true,
                enabled = !isPublishing,
                shape = RoundedCornerShape(8.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MagicEmerald,
                    unfocusedBorderColor = MagicBorder,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )

            // Trạng thái bản APK đang phát hành trên Cloud
            val published = currentRelease
            if (published != null && published.downloadUrl.isNotBlank()) {
                val sizeMb = if (published.sizeBytes > 0L) {
                    String.format(Locale.US, "%.1f MB", published.sizeBytes / (1024.0 * 1024.0))
                } else "—"
                val formattedTime = remember(published.uploadedAtMs) {
                    if (published.uploadedAtMs > 0L) {
                        SimpleDateFormat("HH:mm dd/MM/yyyy", Locale.getDefault()).format(Date(published.uploadedAtMs))
                    } else "Vừa phát hành"
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MagicEmerald.copy(alpha = 0.1f))
                        .border(1.dp, MagicEmerald.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = MagicEmeraldLight,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "Đang phát hành: v${published.versionName} (build ${published.versionCode})",
                                color = MagicEmeraldLight,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedButton(
                                onClick = {
                                    LicenseManager.clearLatestApkRelease(context)
                                    statusMessage = "🗑️ Đã gỡ liên kết cập nhật khỏi app. Tệp trên GitHub/Drive không bị xóa."
                                    errorMessage = null
                                },
                                enabled = !isPublishing,
                                modifier = Modifier
                                    .defaultMinSize(minHeight = 36.dp)
                                    .testTag("admin_clear_cloud_apk_btn"),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                border = BorderStroke(1.dp, MagicRose.copy(alpha = 0.6f))
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Gỡ bản Cloud",
                                    tint = MagicRoseLight,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text("Gỡ bản", color = MagicRoseLight, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    val sourceTag = if (InAppApkUpdater.isGitHubApkLink(published.downloadUrl)) "🐙 GitHub" else "☁️ Google Drive"
                    Text(
                        text = "📦 $sizeMb • $sourceTag • 🕒 $formattedTime",
                        color = MagicCyanLight,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = published.downloadUrl,
                        color = TextMuted,
                        fontSize = 9.5.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Nội dung ghi chú bản cập nhật
            OutlinedTextField(
                value = releaseNotes,
                onValueChange = { releaseNotes = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_apk_release_notes_input"),
                label = { Text("Ghi chú bản cập nhật gửi tới người dùng", fontSize = 10.5.sp) },
                minLines = 2,
                maxLines = 3,
                enabled = !isPublishing,
                shape = RoundedCornerShape(8.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MagicEmerald,
                    unfocusedBorderColor = MagicBorder,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedContainerColor = MagicSurfaceCard,
                    unfocusedContainerColor = MagicSurfaceCard
                )
            )

            // Tùy chọn tự hiện lời nhắc; tải và cài vẫn cần người dùng chủ động xác nhận.
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(MagicSurfaceCard)
                    .border(1.dp, MagicBorder, RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "⚡ Tự hiện lời nhắc cập nhật cho máy cũ",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Chỉ hiện hộp thoại; APK chỉ tải khi người dùng bấm nút tải",
                        color = TextMuted,
                        fontSize = 9.8.sp
                    )
                }
                Switch(
                    checked = autoUpdateOldDevices,
                    onCheckedChange = { enabled ->
                        autoUpdateOldDevices = enabled
                        if (currentRelease != null) {
                            LicenseManager.setLatestApkAutoUpdateEnabled(context, enabled)
                        }
                    },
                    modifier = Modifier.testTag("admin_apk_auto_update_switch"),
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color(0xFF020617),
                        checkedTrackColor = MagicEmerald
                    )
                )
            }

            // Tùy chọn gửi kèm thông báo Broadcast UPDATE
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(MagicSurfaceCard)
                    .border(1.dp, MagicBorder, RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "📢 Gửi thông báo toàn cầu khi phát hành",
                    color = TextSecondary,
                    fontSize = 10.8.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                Switch(
                    checked = alsoBroadcastUpdate,
                    onCheckedChange = { alsoBroadcastUpdate = it },
                    enabled = !isPublishing,
                    modifier = Modifier.testTag("admin_apk_broadcast_switch"),
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color(0xFF020617),
                        checkedTrackColor = MagicCyan
                    )
                )
            }

            // Chỉ kiểm tra APK cục bộ và phát hành link; không tải APK lên máy chủ.
            if (isPublishing) {
                Text("🔍 Đang kiểm tra APK trên thiết bị…", color = MagicCyanLight, fontSize = 10.8.sp, fontWeight = FontWeight.Bold)
            }

            if (!statusMessage.isNullOrBlank()) {
                Text(
                    text = statusMessage.orEmpty(),
                    color = MagicEmeraldLight,
                    fontSize = 10.8.sp,
                    fontWeight = FontWeight.Bold,
                    lineHeight = 15.sp
                )
            }

            if (!errorMessage.isNullOrBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MagicRose.copy(alpha = 0.14f))
                        .border(1.dp, MagicRose.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        .padding(8.dp)
                ) {
                    Text(
                        text = "⚠️ ${errorMessage.orEmpty()}",
                        color = MagicRoseLight,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        lineHeight = 15.sp
                    )
                }
            }

            // Chọn APK đã đưa lên Drive hoặc phát hành thông tin phiên bản đang cài.
            Row(
                modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        try {
                            apkPickerLauncher.launch(arrayOf("application/vnd.android.package-archive", "*/*"))
                        } catch (_: Throwable) {
                            Toast.makeText(context, "Không thể mở trình chọn tệp APK.", Toast.LENGTH_SHORT).show()
                        }
                    },
                    enabled = !isPublishing,
                    modifier = Modifier
                        .fillMaxHeight()
                        .weight(1f)
                        .defaultMinSize(minHeight = 36.dp)
                        .testTag("admin_pick_drive_release_apk_btn"),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MagicEmerald,
                        contentColor = Color(0xFF020617)
                    )
                ) {
                    Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = "Chọn APK Đọc Phiên Bản",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                OutlinedButton(
                    onClick = {
                        launchPublishTask {
                            AdminApkReleaseInspector.prepareCurrentInstalledApk(context)
                        }
                    },
                    enabled = !isPublishing,
                    modifier = Modifier
                        .fillMaxHeight()
                        .weight(1f)
                        .defaultMinSize(minHeight = 36.dp)
                        .testTag("admin_publish_installed_apk_btn"),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                    border = BorderStroke(1.dp, MagicCyan)
                ) {
                    Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = MagicCyanLight, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = "Phát Hành Bản Đang Cài ($APP_VERSION_NAME • b$installedVersionCode)",
                        color = MagicCyanLight,
                        fontSize = 10.2.sp,
                        fontWeight = FontWeight.Black,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}
