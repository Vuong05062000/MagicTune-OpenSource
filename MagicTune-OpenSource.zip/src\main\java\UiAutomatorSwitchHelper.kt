package com.example.core.shell

import android.util.Xml
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader

data class DumpsysNotifPkgStatus(
    val packageName: String,
    val foundInDumpsys: Boolean,
    val hasLowOrGentleChannel: Boolean,
    val hasDefaultNoBannerChannel: Boolean,
    val hasHighBannerChannel: Boolean
) {
    val needsGentleOrBannerFix: Boolean
        get() = hasLowOrGentleChannel || hasDefaultNoBannerChannel || !hasHighBannerChannel
}

data class UiNode(
    val text: String,
    val contentDesc: String,
    val resourceId: String,
    val className: String,
    val checkable: Boolean,
    val checked: Boolean,
    val clickable: Boolean,
    val enabled: Boolean,
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int
) {
    val centerX: Int get() = (left + right) / 2
    val centerY: Int get() = (top + bottom) / 2
    val width: Int get() = right - left
    val height: Int get() = bottom - top
    val isSwitchLike: Boolean
        get() = checkable || className.contains("Switch", ignoreCase = true) ||
            className.contains("CheckBox", ignoreCase = true)
}

data class UiSwitchMatch(
    val labelNode: UiNode,
    val switchNode: UiNode,
    val isChecked: Boolean,
    val tapX: Int,
    val tapY: Int
)

data class VisualToggleReport(
    val packageName: String,
    val appName: String,
    val openedSettingsOk: Boolean,
    val masterNotifTurnedOn: Boolean,
    val gentleTurnedOff: Boolean,
    val bannerTurnedOn: Boolean,
    val lockScreenTurnedOn: Boolean,
    val soundTurnedOn: Boolean,
    val vibrateTurnedOn: Boolean,
    val badgeTurnedOn: Boolean,
    val detailMessage: String
)

object UiAutomatorSwitchHelper {

    private val boundsRegex = Regex("""\[(\d+),(\d+)]\[(\d+),(\d+)]""")
    private val pkgHeaderRegex = Regex("""AppSettings:\s*([a-zA-Z0-9._]+)""")
    private val pkgAltRegex = Regex("""Package(?:\s+record)?[:\s]+([a-zA-Z0-9._]+)""")
    private val importanceRegex = Regex("""(?:mImportance|importance)\s*=\s*(-?\d+)""", RegexOption.IGNORE_CASE)

    fun parseDumpsysNotificationChannels(
        dumpsysOutput: String,
        targetPackages: Set<String>
    ): Map<String, DumpsysNotifPkgStatus> {
        if (dumpsysOutput.isBlank() || targetPackages.isEmpty()) return emptyMap()
        val result = mutableMapOf<String, DumpsysNotifPkgStatus>()
        val lines = dumpsysOutput.lines()
        var currentPkg: String? = null
        val pkgSections = mutableMapOf<String, StringBuilder>()

        for (line in lines) {
            val match = pkgHeaderRegex.find(line) ?: pkgAltRegex.find(line)
            if (match != null) {
                val detected = match.groupValues[1]
                if (detected in targetPackages) {
                    currentPkg = detected
                    pkgSections.getOrPut(detected) { StringBuilder() }.append(line).append('\n')
                    continue
                } else if (line.trimStart().startsWith("AppSettings:")) {
                    currentPkg = null
                }
            }
            val activePkg = currentPkg
            if (activePkg != null) {
                pkgSections.getOrPut(activePkg) { StringBuilder() }.append(line).append('\n')
            }
        }

        for (pkg in targetPackages) {
            val section = pkgSections[pkg]?.toString() ?: run {
                val idx = dumpsysOutput.indexOf(pkg)
                if (idx >= 0) dumpsysOutput.substring(idx, (idx + 2500).coerceAtMost(dumpsysOutput.length)) else ""
            }
            if (section.isBlank()) continue

            val importances = importanceRegex.findAll(section)
                .mapNotNull { it.groupValues[1].toIntOrNull() }
                .filter { it >= 0 }
                .toList()

            val hasLowOrGentle = importances.any { it in 0..2 }
            val hasDefault = importances.any { it == 3 }
            val hasHigh = if (importances.isEmpty()) false else importances.any { it >= 4 }

            result[pkg] = DumpsysNotifPkgStatus(
                packageName = pkg,
                foundInDumpsys = true,
                hasLowOrGentleChannel = hasLowOrGentle,
                hasDefaultNoBannerChannel = hasDefault,
                hasHighBannerChannel = hasHigh
            )
        }
        return result
    }

    fun parseUiNodes(xml: String): List<UiNode> {
        if (xml.isBlank()) return emptyList()
        val nodes = ArrayList<UiNode>(64)
        try {
            val parser = Xml.newPullParser()
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
            parser.setInput(StringReader(xml))
            var eventType = parser.eventType
            while (eventType != XmlPullParser.END_DOCUMENT) {
                if (eventType == XmlPullParser.START_TAG && parser.name == "node") {
                    val boundsStr = parser.getAttributeValue(null, "bounds").orEmpty()
                    val m = boundsRegex.find(boundsStr)
                    val l = m?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 0
                    val t = m?.groupValues?.getOrNull(2)?.toIntOrNull() ?: 0
                    val r = m?.groupValues?.getOrNull(3)?.toIntOrNull() ?: 0
                    val b = m?.groupValues?.getOrNull(4)?.toIntOrNull() ?: 0
                    nodes.add(
                        UiNode(
                            text = parser.getAttributeValue(null, "text").orEmpty(),
                            contentDesc = parser.getAttributeValue(null, "content-desc").orEmpty(),
                            resourceId = parser.getAttributeValue(null, "resource-id").orEmpty(),
                            className = parser.getAttributeValue(null, "class").orEmpty(),
                            checkable = parser.getAttributeValue(null, "checkable") == "true",
                            checked = parser.getAttributeValue(null, "checked") == "true",
                            clickable = parser.getAttributeValue(null, "clickable") == "true",
                            enabled = parser.getAttributeValue(null, "enabled") != "false",
                            left = l,
                            top = t,
                            right = r,
                            bottom = b
                        )
                    )
                }
                eventType = parser.next()
            }
        } catch (_: Throwable) {
            return parseUiNodesRegexFallback(xml)
        }
        return nodes
    }

    private fun parseUiNodesRegexFallback(xml: String): List<UiNode> {
        val nodes = ArrayList<UiNode>(32)
        val nodeTagRegex = Regex("""<node\s+([^>]+)/?>""")
        fun attr(attrs: String, name: String): String {
            return Regex("""\b${Regex.escape(name)}="([^"]*)"""").find(attrs)?.groupValues?.get(1).orEmpty()
        }
        for (match in nodeTagRegex.findAll(xml)) {
            val attrs = match.groupValues[1]
            val m = boundsRegex.find(attr(attrs, "bounds"))
            nodes.add(
                UiNode(
                    text = attr(attrs, "text"),
                    contentDesc = attr(attrs, "content-desc"),
                    resourceId = attr(attrs, "resource-id"),
                    className = attr(attrs, "class"),
                    checkable = attr(attrs, "checkable") == "true",
                    checked = attr(attrs, "checked") == "true",
                    clickable = attr(attrs, "clickable") == "true",
                    enabled = attr(attrs, "enabled") != "false",
                    left = m?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 0,
                    top = m?.groupValues?.getOrNull(2)?.toIntOrNull() ?: 0,
                    right = m?.groupValues?.getOrNull(3)?.toIntOrNull() ?: 0,
                    bottom = m?.groupValues?.getOrNull(4)?.toIntOrNull() ?: 0
                )
            )
        }
        return nodes
    }

    fun findClickableChannelRows(nodes: List<UiNode>): List<UiNode> {
        if (nodes.isEmpty()) return emptyList()
        val ignoredKeywords = listOf(
            "nhẹ nhàng", "gentle", "biểu ngữ", "banner", "màn hình khóa",
            "lock screen", "rung", "vibrate", "âm thanh", "sound", "huy hiệu", "badge",
            "cho phép thông báo", "allow notifications"
        )
        return nodes.filter { node ->
            if (!node.enabled || node.width <= 0 || node.height <= 0 || node.isSwitchLike) return@filter false
            val combinedLabel = "${node.text} ${node.contentDesc}".trim()
            if (combinedLabel.isBlank()) return@filter false
            val lower = combinedLabel.lowercase()
            if (ignoredKeywords.any { lower.contains(it) }) return@filter false
            node.clickable || nodes.any { parent ->
                parent !== node &&
                    parent.clickable &&
                    !parent.isSwitchLike &&
                    parent.left <= node.left &&
                    parent.top <= node.top &&
                    parent.right >= node.right &&
                    parent.bottom >= node.bottom &&
                    parent.height in 40..420
            }
        }
    }

    fun findSwitchForLabel(
        nodes: List<UiNode>,
        positiveKeywords: List<String>,
        excludeKeywords: List<String> = emptyList()
    ): UiSwitchMatch? {
        if (nodes.isEmpty() || positiveKeywords.isEmpty()) return null
        val switchNodes = nodes.filter { it.isSwitchLike && it.enabled && it.width > 0 && it.height > 0 }
        if (switchNodes.isEmpty()) return null

        val labelCandidates = nodes.filter { node ->
            val label = "${node.text} ${node.contentDesc}".trim()
            if (label.isBlank()) return@filter false
            val lower = label.lowercase()
            positiveKeywords.any { lower.contains(it.lowercase()) } &&
                excludeKeywords.none { lower.contains(it.lowercase()) }
        }

        for (label in labelCandidates) {
            val alignedSwitch = switchNodes
                .filter { sw ->
                    val yDiff = kotlin.math.abs(sw.centerY - label.centerY)
                    val insideSameVerticalBand = (sw.top <= label.bottom + 90 && sw.bottom >= label.top - 90)
                    yDiff <= 140 && insideSameVerticalBand
                }
                .minByOrNull { kotlin.math.abs(it.centerY - label.centerY) }

            if (alignedSwitch != null) {
                return UiSwitchMatch(
                    labelNode = label,
                    switchNode = alignedSwitch,
                    isChecked = alignedSwitch.checked,
                    tapX = alignedSwitch.centerX,
                    tapY = alignedSwitch.centerY
                )
            }
        }
        return null
    }

    suspend fun autoToggleAppNotificationScreen(
        shellEngine: ShellEngine,
        pkg: String,
        appName: String,
        pressBackWhenDone: Boolean = false,
        onProgressUpdate: (String) -> Unit = {},
        onLog: (String) -> Unit = {}
    ): VisualToggleReport = withContext(Dispatchers.IO) {
        onProgressUpdate("⚡ Đang mở khóa kênh thông báo & biểu ngữ cho $appName...")
        val cmd = buildString {
            append("cmd appops set $pkg POST_NOTIFICATION allow >/dev/null 2>&1; ")
            append("cmd appops set --user 0 $pkg POST_NOTIFICATION allow >/dev/null 2>&1; ")
            append("cmd notification set_bubbles $pkg 1 >/dev/null 2>&1; ")
            append("am set-standby-bucket --user 0 $pkg active >/dev/null 2>&1")
        }
        val res = shellEngine.execute(cmd)
        val cmdOk = res.isSuccess
        var uiSynced = false

        if (cmdOk) {
            try {
                onProgressUpdate("👁️ Đang mở trang Cài đặt Thông báo của $appName...")
                shellEngine.execute(
                    "am start --activity-no-animation -a android.settings.APP_NOTIFICATION_SETTINGS " +
                        "--es android.provider.extra.APP_PACKAGE $pkg >/dev/null 2>&1 || " +
                        "am start --activity-no-animation -a android.settings.APPLICATION_DETAILS_SETTINGS " +
                        "-d package:$pkg >/dev/null 2>&1"
                )
                delay(550L)

                val dumpRes = shellEngine.execute(
                    "uiautomator dump /data/local/tmp/mt_ui.xml >/dev/null 2>&1 && cat /data/local/tmp/mt_ui.xml 2>/dev/null; rm -f /data/local/tmp/mt_ui.xml >/dev/null 2>&1"
                )
                val nodes = parseUiNodes(dumpRes.output)
                val isSettingsForeground = nodes.isNotEmpty() &&
                    nodes.none { it.text.contains("MagicTune", ignoreCase = true) } &&
                    (dumpRes.output.contains("package=\"com.android.settings\"", ignoreCase = true) ||
                        dumpRes.output.contains("package=\"com.hihonor.", ignoreCase = true) ||
                        dumpRes.output.contains("systemmanager", ignoreCase = true) ||
                        nodes.any { it.resourceId.contains("settings", ignoreCase = true) } ||
                        findSwitchForLabel(nodes, listOf("cho phép thông báo", "allow notifications", "thông báo nhẹ nhàng", "gentle", "biểu ngữ", "banners", "floating")) != null)

                if (isSettingsForeground) {
                    val masterSwitch = findSwitchForLabel(nodes, listOf("cho phép thông báo", "allow notifications"))
                    if (masterSwitch != null && !masterSwitch.isChecked && masterSwitch.tapX > 0) {
                        shellEngine.execute("input tap ${masterSwitch.tapX} ${masterSwitch.tapY}")
                        delay(180L)
                    }
                    val gentleSwitch = findSwitchForLabel(nodes, listOf("thông báo nhẹ nhàng", "gentle"))
                    if (gentleSwitch != null && gentleSwitch.isChecked && gentleSwitch.tapX > 0) {
                        shellEngine.execute("input tap ${gentleSwitch.tapX} ${gentleSwitch.tapY}")
                        delay(180L)
                    }
                    val bannerSwitch = findSwitchForLabel(nodes, listOf("biểu ngữ", "banners", "floating"))
                    if (bannerSwitch != null && !bannerSwitch.isChecked && bannerSwitch.tapX > 0) {
                        shellEngine.execute("input tap ${bannerSwitch.tapX} ${bannerSwitch.tapY}")
                    }
                    uiSynced = masterSwitch != null || gentleSwitch != null || bannerSwitch != null
                }
                if (pressBackWhenDone) {
                    shellEngine.execute("input keyevent 4 >/dev/null 2>&1")
                }
            } catch (_: Throwable) {}
        }

        delay(80L)
        if (cmdOk) {
            onLog(
                if (uiSynced) "✅ Đã tự động gạt công tắc Thông báo & Biểu ngữ trực tiếp cho $appName ($pkg)"
                else "✅ Đã kích hoạt quyền & kênh thông báo ưu tiên cho $appName ($pkg)"
            )
        } else {
            onLog("⚠️ Chưa có quyền Shell/ADB để sửa tự động kênh thông báo cho $appName ($pkg)")
        }

        VisualToggleReport(
            packageName = pkg,
            appName = appName,
            openedSettingsOk = cmdOk,
            masterNotifTurnedOn = cmdOk,
            gentleTurnedOff = cmdOk && uiSynced,
            bannerTurnedOn = cmdOk,
            lockScreenTurnedOn = cmdOk,
            soundTurnedOn = cmdOk,
            vibrateTurnedOn = cmdOk,
            badgeTurnedOn = cmdOk,
            detailMessage = if (cmdOk) {
                "Đã kích hoạt thông báo ưu tiên cho $appName"
            } else {
                res.error.ifBlank { "Cần kết nối Gỡ lỗi WLAN/Shizuku để cấu hình tự động cho $appName" }
            }
        )
    }
}
