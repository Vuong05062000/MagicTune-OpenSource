## Run / preview
- `npm run dev` (Next.js turbopack) **bị lỗi** trong môi trường này: watcher báo `Permission denied (os error 13)` khi đọc `src/components/auth`, `src/components/modals`, `src/components/modules` (giới hạn inotify của proot/Alpine), không phải lỗi code.
- Để preview: `npm run build` (static export ra `/workspace/out`), rồi `python3 -m http.server 36657 --bind 127.0.0.1 --directory /workspace/out`.
- Preview đang chạy tại `http://127.0.0.1:36657/` — trang chủ HTTP 200, không lỗi JS.

## Fix lỗi trùng lặp menu (trailingSlash)
- Nguyên nhân: `next.config.ts` có `trailingSlash: true` kết hợp `output: "export"` tạo ra file trùng lặp (`about.html` ≈ `about/index.html`), khiến mọi route dẫn về cùng nội dung — nút menu chính mở ra giống nhau.
- Fix: Comment dòng `trailingSlash: true` trong `next.config.ts`, rồi `npm run build` lại. Next.js sẽ tạo file HTML đơn lẻ cho mỗi route (`about.html`, `privacy.html`,...), URL `/about` và `/about/` đều hoạt động đúng với nội dung riêng lẻ.

## Notes
- Firebase warnings trên localhost (permission-denied config, OAuth domain) là bình thường, chỉ ảnh hưởng auth popup trên production domain.