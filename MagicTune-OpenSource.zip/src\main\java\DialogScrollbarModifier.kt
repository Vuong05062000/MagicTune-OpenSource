package com.example.ui.components

import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.MagicCyan

/**
 * Modifier gắn cuộn dọc (verticalScroll) kèm vẽ Thanh Cuộn (Scrollbar) trực quan bên phải
 * cho tất cả các Dialog / Modal trong toàn bộ ứng dụng, đảm bảo 100% mọi hộp thoại đều cuộn mượt mà.
 */
fun Modifier.verticalScrollWithScrollbar(
    scrollState: ScrollState,
    thumbColor: Color = MagicCyan,
    trackColor: Color = Color(0xFF1E293B),
    scrollbarWidth: Dp = 4.5.dp,
    endPadding: Dp = 2.dp
): Modifier = this
    .verticalScroll(scrollState)
    .drawWithContent {
        drawContent()

        val viewportHeight = this.size.height
        if (viewportHeight <= 0f) return@drawWithContent

        val maxScroll = scrollState.maxValue.toFloat()
        val totalContentHeight = viewportHeight + maxScroll
        val barWidthPx = scrollbarWidth.toPx()
        val padPx = endPadding.toPx()
        val xOffset = (this.size.width - barWidthPx - padPx).coerceAtLeast(0f)
        val cornerRadius = CornerRadius(barWidthPx / 2f, barWidthPx / 2f)

        // Vẽ rãnh thanh cuộn (Track)
        drawRoundRect(
            color = trackColor.copy(alpha = if (maxScroll > 0f) 0.55f else 0.25f),
            topLeft = Offset(xOffset, 4f),
            size = Size(barWidthPx, (viewportHeight - 8f).coerceAtLeast(8f)),
            cornerRadius = cornerRadius
        )

        // Vẽ con trượt thanh cuộn (Thumb)
        val usableTrackHeight = (viewportHeight - 8f).coerceAtLeast(16f)
        val thumbHeight = if (maxScroll > 0f && totalContentHeight > 0f) {
            (viewportHeight / totalContentHeight * usableTrackHeight)
                .coerceIn(28.dp.toPx().coerceAtMost(usableTrackHeight), usableTrackHeight)
        } else {
            usableTrackHeight
        }

        val scrollFraction = if (maxScroll > 0f) {
            (scrollState.value.toFloat() / maxScroll).coerceIn(0f, 1f)
        } else {
            0f
        }
        val thumbY = 4f + scrollFraction * (usableTrackHeight - thumbHeight).coerceAtLeast(0f)

        drawRoundRect(
            color = thumbColor.copy(alpha = if (maxScroll > 0f) 0.9f else 0.45f),
            topLeft = Offset(xOffset, thumbY),
            size = Size(barWidthPx, thumbHeight),
            cornerRadius = cornerRadius
        )
    }

@Composable
fun ScrollableDialogColumn(
    modifier: Modifier = Modifier,
    verticalArrangement: Arrangement.Vertical = Arrangement.spacedBy(10.dp),
    horizontalAlignment: Alignment.Horizontal = Alignment.Start,
    thumbColor: Color = MagicCyan,
    content: @Composable ColumnScope.() -> Unit
) {
    val scrollState = rememberScrollState()
    Column(
        modifier = modifier
            .fillMaxWidth()
            .verticalScrollWithScrollbar(scrollState = scrollState, thumbColor = thumbColor)
            .padding(end = 8.dp),
        verticalArrangement = verticalArrangement,
        horizontalAlignment = horizontalAlignment,
        content = content
    )
}
