import type { NextConfig } from "next";

const nextConfig: NextConfig = {
output: "export",
  // trailingSlash: true,  // Bỏ cờ này để Next.js tạo file *.html đơn lẻ cho mỗi route, tránh file index.html trùng lặp
  images: {
    unoptimized: true
  }
};

export default nextConfig;
