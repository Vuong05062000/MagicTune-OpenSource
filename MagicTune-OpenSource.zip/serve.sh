#!/bin/sh
exec python3 -m http.server 36657 --bind 127.0.0.1 --directory /workspace/out
