package com.example.core.adb

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import android.util.Log
import com.example.core.shell.ShellMode
import com.example.core.shell.ShellResult
import io.github.muntashirakon.adb.AbsAdbConnectionManager
import io.github.muntashirakon.adb.AdbStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.cert.Certificate
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

enum class DiagnosticSeverity {
    PASS, WARN, FAIL
}

@androidx.compose.runtime.Immutable
data class AdbDiagnosticStep(
    val id: String,
    val title: String,
    val detail: String,
    val severity: DiagnosticSeverity,
    val latencyMs: Long? = null
)

@androidx.compose.runtime.Immutable
data class AdbDiagnosticReport(
    val generatedAtMs: Long = System.currentTimeMillis(),
    val overallReady: Boolean = false,
    val steps: List<AdbDiagnosticStep> = emptyList(),
    val recommendedAction: String = ""
)

@androidx.compose.runtime.Immutable
data class AdbTelemetrySnapshot(
    val isConnected: Boolean = false,
    val activeHost: String = "127.0.0.1",
    val activePort: Int = 0,
    val lanIp: String? = null,
    val protocolLabel: String = "TLS 1.3 + SPAKE2 + RSA-2048",
    val certFingerprintSha256: String = "",
    val uidIdentity: String = "Chưa xác thực",
    val lastLatencyMs: Long? = null,
    val avgLatencyMs: Long? = null,
    val totalCommandsExecuted: Int = 0,
    val failedCommandsCount: Int = 0,
    val reconnectCount: Int = 0,
    val lastConnectedAtMs: Long = 0L,
    val lastErrorSummary: String? = null
)

/**
 * DirectAdbManager: Quản lý kết nối Direct WLAN ADB (UID 2000) độc lập.
 * Tách biệt hoàn toàn việc nạp thư viện gốc (Conscrypt / SPAKE2 / AbsAdbConnectionManager)
 * vào lớp nội bộ khởi tạo lười (Lazy Isolation), giúp ứng dụng mở tức thì và tương thích 100%
 * trên mọi thiết bị từ Android 8 đến Android 17 (API 37+) cũng như máy ảo Preview.
 */
class DirectAdbManager(private val context: Context) {

    companion object {
        private const val TAG = "DirectAdbManager"
        private const val KEY_DIR = "adb_keys"
        private const val PRIVATE_KEY_FILE = "magictune_adb.priv"
        private const val CERTIFICATE_FILE = "magictune_adb.cert"

        @Volatile
        private var instance: DirectAdbManager? = null

        fun getInstance(context: Context): DirectAdbManager {
            return instance ?: synchronized(this) {
                instance ?: DirectAdbManager(context.applicationContext).also { instance = it }
            }
        }

        /**
         * Kiểm tra trạng thái kết nối Direct ADB hoàn toàn không khóa (Lock-Free, 0ms),
         * không nạp lớp native Conscrypt khi khởi động app.
         */
        fun isInstanceConnectedFast(): Boolean {
            val inst = instance ?: return false
            return inst.isConnectedFast()
        }
    }

    private class InternalAdbEngine(private val owner: DirectAdbManager) : AbsAdbConnectionManager() {
        init {
            try {
                setHostAddress("127.0.0.1")
                // Tương thích hoàn hảo cho cả Android 16 (API 36), Android 17 (API 37+) và MagicOS 10/11:
                // Giới hạn cờ API nội bộ của libadb-android ở ngưỡng 35 để giao thức TLS 1.3 / SPAKE2 không bị lỗi phiên bản mới
                val safeAdbApi = Build.VERSION.SDK_INT.coerceIn(29, 35)
                setApi(safeAdbApi)
                setTimeout(3, TimeUnit.SECONDS)
            } catch (t: Throwable) {
                Log.w(TAG, "InternalAdbEngine init fallback: ${t.message}")
            }
        }

        override fun getPrivateKey(): PrivateKey = owner.obtainPrivateKey()

        override fun getCertificate(): Certificate = owner.obtainCertificate()

        override fun getDeviceName(): String = "magictune@honor"
    }

    @Volatile
    private var internalEngine: InternalAdbEngine? = null

    private fun getOrCreateEngine(): InternalAdbEngine? {
        internalEngine?.let { return it }
        return synchronized(this) {
            internalEngine ?: try {
                InternalAdbEngine(this).also { internalEngine = it }
            } catch (t: Throwable) {
                Log.e(TAG, "Không thể khởi tạo engine ADB TLS trên thiết bị này: ${t.message}", t)
                null
            }
        }
    }

    private var cachedPrivateKey: PrivateKey? = null
    private var cachedCertificate: Certificate? = null

    @Volatile
    private var fastConnectedFlag: Boolean = false
    @Volatile
    private var lastAutoReconnectFailMs: Long = 0L
    @Volatile
    private var isManualDisconnected: Boolean = false
    private val managerScope = kotlinx.coroutines.CoroutineScope(Dispatchers.IO + kotlinx.coroutines.SupervisorJob())
    private var wifiCallback: ConnectivityManager.NetworkCallback? = null

    private val connectMutex = kotlinx.coroutines.sync.Mutex()
    private val _telemetry = MutableStateFlow(AdbTelemetrySnapshot())
    val telemetry: StateFlow<AdbTelemetrySnapshot> = _telemetry.asStateFlow()

    private val totalCommandsCounter = AtomicInteger(0)
    private val failedCommandsCounter = AtomicInteger(0)
    private val reconnectCounter = AtomicInteger(0)
    private val shellCommandSeq = AtomicInteger(0)
    @Volatile
    private var cachedCertFingerprint: String = ""

    init {
        registerWifiNetworkCallback()
        // Làm nóng (Pre-warm) cặp khóa RSA 2048-bit và chứng chỉ X.509v3 trên luồng nền
        // để khi người dùng nhập 6 số PIN ghép nối sẽ phản hồi tức thì trong 0ms.
        managerScope.launch {
            try {
                obtainPrivateKey()
                val cert = obtainCertificate()
                cachedCertFingerprint = computeShortFingerprint(cert)
                _telemetry.update {
                    it.copy(
                        certFingerprintSha256 = cachedCertFingerprint,
                        lanIp = getPrimaryWifiIpv4()
                    )
                }
            } catch (t: Throwable) {
                Log.w(TAG, "Pre-warm ADB keys error: ${t.message}")
            }
        }
    }

    private fun registerWifiNetworkCallback() {
        try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    managerScope.launch {
                        _telemetry.update { it.copy(lanIp = getPrimaryWifiIpv4()) }
                    }
                }

                override fun onLost(network: Network) {
                    managerScope.launch {
                        val hasOtherWifi = try {
                            val active = cm.activeNetwork
                            val caps = active?.let { cm.getNetworkCapabilities(it) }
                            caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
                        } catch (_: Throwable) { false }
                        if (!hasOtherWifi && fastConnectedFlag) {
                            fastConnectedFlag = false
                            closePersistentShellAsync()
                            _telemetry.update { it.copy(isConnected = false, lanIp = null) }
                        }
                    }
                }
            }
            wifiCallback = cb
            val req = NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .build()
            cm.registerNetworkCallback(req, cb)
        } catch (_: Throwable) {}
    }

    val isConnected: Boolean
        get() = isConnectedFast()

    /**
     * Kiểm tra kết nối không khóa (0ms), an toàn tuyệt đối trên Main Thread (Compose recomposition).
     * Không gọi trực tiếp vào socket/native layer trên UI Thread.
     */
    fun isConnectedFast(): Boolean {
        return fastConnectedFlag && internalEngine != null
    }

    /**
     * Xác minh trạng thái socket thực tế trên luồng IO (chỉ gọi từ Dispatchers.IO).
     */
    fun verifyConnectedIo(): Boolean {
        if (!fastConnectedFlag) return false
        val eng = internalEngine ?: return false
        if (connectMutex.isLocked) return fastConnectedFlag
        return try {
            val real = eng.isConnected
            fastConnectedFlag = real
            real
        } catch (_: Throwable) {
            fastConnectedFlag = false
            false
        }
    }

    internal fun obtainPrivateKey(): PrivateKey {
        return cachedPrivateKey ?: synchronized(this) {
            cachedPrivateKey ?: loadOrGenerateKeys().first.also { cachedPrivateKey = it }
        }
    }

    internal fun obtainCertificate(): Certificate {
        return cachedCertificate ?: synchronized(this) {
            cachedCertificate ?: loadOrGenerateKeys().second.also { cachedCertificate = it }
        }
    }

    private fun loadOrGenerateKeys(): Pair<PrivateKey, Certificate> {
        val keysDir = File(context.filesDir, KEY_DIR)
        if (!keysDir.exists()) {
            keysDir.mkdirs()
        }
        val privFile = File(keysDir, PRIVATE_KEY_FILE)
        val certFile = File(keysDir, CERTIFICATE_FILE)

        if (privFile.exists() && certFile.exists() && privFile.length() > 64L && certFile.length() > 64L) {
            try {
                val privBytes = privFile.readBytes()
                val kf = KeyFactory.getInstance("RSA")
                val privKey = kf.generatePrivate(PKCS8EncodedKeySpec(privBytes))

                val cf = CertificateFactory.getInstance("X.509")
                FileInputStream(certFile).use { fis ->
                    val cert = cf.generateCertificate(fis) as X509Certificate
                    cert.verify(cert.publicKey)
                    cachedPrivateKey = privKey
                    cachedCertificate = cert
                    return Pair(privKey, cert)
                }
            } catch (e: Throwable) {
                Log.w(TAG, "Failed to load cached ADB keys, regenerating...", e)
                try { privFile.delete() } catch (_: Throwable) {}
                try { certFile.delete() } catch (_: Throwable) {}
            }
        }

        val kpg = KeyPairGenerator.getInstance("RSA")
        kpg.initialize(2048, SecureRandom())
        val keyPair = kpg.generateKeyPair()

        val cert = generateSelfSignedCertificate(keyPair)

        try {
            FileOutputStream(privFile).use { it.write(keyPair.private.encoded) }
            FileOutputStream(certFile).use { it.write(cert.encoded) }
        } catch (e: Throwable) {
            Log.e(TAG, "Failed to save generated ADB keys to disk", e)
        }

        cachedPrivateKey = keyPair.private
        cachedCertificate = cert
        return Pair(keyPair.private, cert)
    }

    /**
     * Tự phục hồi: Xóa toàn bộ cặp khóa RSA ADB cũ, ngắt kết nối TLS đang tồn đọng
     * và tạo mới cặp khóa RSA 2048-bit cùng chứng chỉ X.509 mới để khắc phục triệt để lỗi Unauthorized / Connection refused.
     */
    fun resetAdbKeys(): Boolean {
        return try {
            disconnectDirect()
            cachedPrivateKey = null
            cachedCertificate = null
            val keysDir = File(context.filesDir, KEY_DIR)
            if (keysDir.exists()) {
                for (f in keysDir.listFiles() ?: emptyArray()) {
                    try { f.delete() } catch (_: Throwable) {}
                }
            }
            val pair = loadOrGenerateKeys()
            cachedCertFingerprint = computeShortFingerprint(pair.second)
            _telemetry.update {
                it.copy(
                    certFingerprintSha256 = cachedCertFingerprint,
                    isConnected = false,
                    lastErrorSummary = null
                )
            }
            pair.first != null && pair.second != null
        } catch (t: Throwable) {
            Log.e(TAG, "Reset ADB keys error", t)
            false
        }
    }

    private fun computeShortFingerprint(cert: Certificate): String {
        return try {
            val digest = MessageDigest.getInstance("SHA-256").digest(cert.encoded)
            digest.take(8).joinToString(":") { b -> "%02X".format(b.toInt() and 0xFF) }
        } catch (_: Throwable) {
            ""
        }
    }

    fun getCertificateFingerprintShort(): String {
        if (cachedCertFingerprint.isNotBlank()) return cachedCertFingerprint
        return try {
            computeShortFingerprint(obtainCertificate()).also { cachedCertFingerprint = it }
        } catch (_: Throwable) {
            ""
        }
    }

    fun getPrimaryWifiIpv4(): String? {
        return try {
            val interfaces = java.net.NetworkInterface.getNetworkInterfaces() ?: return null
            val all = interfaces.toList()
            val preferred = all.firstOrNull { intf ->
                intf.isUp && !intf.isLoopback &&
                    (intf.name.lowercase().startsWith("wlan") || intf.name.lowercase().startsWith("eth"))
            }
            val ordered = if (preferred != null) listOf(preferred) + all else all
            for (intf in ordered) {
                if (!intf.isUp || intf.isLoopback) continue
                val name = intf.name.lowercase()
                if (name.startsWith("wlan") || name.startsWith("eth") || name.startsWith("ap")) {
                    for (addr in intf.inetAddresses) {
                        if (addr is java.net.Inet4Address && !addr.isLoopbackAddress) {
                            val ip = addr.hostAddress
                            if (!ip.isNullOrBlank() && ip != "0.0.0.0" && !ip.startsWith("169.254")) {
                                return ip
                            }
                        }
                    }
                }
            }
            null
        } catch (_: Throwable) {
            null
        }
    }

    private fun derLength(length: Int): ByteArray {
        if (length < 128) {
            return byteArrayOf(length.toByte())
        }
        val bytes = mutableListOf<Byte>()
        var temp = length
        while (temp > 0) {
            bytes.add(0, (temp and 0xFF).toByte())
            temp = temp ushr 8
        }
        val result = ByteArray(1 + bytes.size)
        result[0] = (0x80 or bytes.size).toByte()
        for (i in bytes.indices) {
            result[i + 1] = bytes[i]
        }
        return result
    }

    private fun derTag(tag: Int, content: ByteArray): ByteArray {
        val lenBytes = derLength(content.size)
        val out = ByteArray(1 + lenBytes.size + content.size)
        out[0] = tag.toByte()
        System.arraycopy(lenBytes, 0, out, 1, lenBytes.size)
        System.arraycopy(content, 0, out, 1 + lenBytes.size, content.size)
        return out
    }

    private fun derSequence(vararg elements: ByteArray): ByteArray {
        val totalSize = elements.sumOf { it.size }
        val combined = ByteArray(totalSize)
        var offset = 0
        for (el in elements) {
            System.arraycopy(el, 0, combined, offset, el.size)
            offset += el.size
        }
        return derTag(0x30, combined)
    }

    /**
     * Tạo chứng chỉ X.509v3 tự ký bằng cấu trúc ASN.1 DER chuẩn RFC 5280 kết hợp
     * `java.security.Signature` và `java.security.cert.CertificateFactory` gốc của Android SDK.
     * Tuyệt đối KHÔNG sử dụng `android.sun.security.x509.X500Name` để triệt tiêu 100% lỗi
     * `ExceptionInInitializerError` / `NoClassDefFoundError: android.sun.security.x509.X500Name` trên Android Runtime (ART).
     */
    internal fun generateSelfSignedCertificate(keyPair: java.security.KeyPair): X509Certificate {
        // 1. Version: [0] EXPLICIT INTEGER 2 (v3)
        val versionDer = byteArrayOf(0xA0.toByte(), 0x03, 0x02, 0x01, 0x02)

        // 2. SerialNumber: INTEGER dương 64-bit
        val serialBigInt = BigInteger(64, SecureRandom()).abs().max(BigInteger.ONE)
        val serialDer = derTag(0x02, serialBigInt.toByteArray())

        // 3. Signature AlgorithmIdentifier: sha256WithRSAEncryption (OID 1.2.840.113549.1.1.11 + NULL)
        val sha256WithRsaAlgId = byteArrayOf(
            0x30, 0x0D,
            0x06, 0x09, 0x2A, 0x86.toByte(), 0x48, 0x86.toByte(), 0xF7.toByte(), 0x0D, 0x01, 0x01, 0x0B,
            0x05, 0x00
        )

        // 4. Issuer & Subject Name: CN=MagicTune Direct ADB (OID 2.5.4.3)
        val cnOid = byteArrayOf(0x06, 0x03, 0x55, 0x04, 0x03)
        val cnVal = derTag(0x0C, "MagicTune Direct ADB".toByteArray(Charsets.UTF_8))
        val attrTypeAndValue = derSequence(cnOid, cnVal)
        val rdnSet = derTag(0x31, attrTypeAndValue)
        val x500NameDer = derSequence(rdnSet)

        // 5. Validity: UTCTime (notBefore = 24h trước, notAfter = 2049-12-31 23:59:59Z chuẩn RFC 5280)
        val utcFormat = java.text.SimpleDateFormat("yyMMddHHmmss'Z'", java.util.Locale.US).apply {
            timeZone = java.util.TimeZone.getTimeZone("UTC")
        }
        val notBeforeDate = Date(System.currentTimeMillis() - 1000L * 60 * 60 * 24)
        val notBeforeDer = derTag(0x17, utcFormat.format(notBeforeDate).toByteArray(Charsets.US_ASCII))
        val notAfterDer = derTag(0x17, "491231235959Z".toByteArray(Charsets.US_ASCII))
        val validityDer = derSequence(notBeforeDer, notAfterDer)

        // 6. SubjectPublicKeyInfo: keyPair.public.encoded đã ở sẵn định dạng chuẩn X.509 DER
        val subjectPublicKeyInfoDer = keyPair.public.encoded

        // 7. Đóng gói TBSCertificate và ký số bằng SHA256withRSA
        val tbsCertificate = derSequence(
            versionDer,
            serialDer,
            sha256WithRsaAlgId,
            x500NameDer,
            validityDer,
            x500NameDer,
            subjectPublicKeyInfoDer
        )

        val signer = java.security.Signature.getInstance("SHA256withRSA")
        signer.initSign(keyPair.private)
        signer.update(tbsCertificate)
        val signatureBytes = signer.sign()

        // 8. BIT STRING chữ ký (byte đầu = 0x00 số bit dư)
        val bitStringBody = ByteArray(1 + signatureBytes.size)
        bitStringBody[0] = 0x00
        System.arraycopy(signatureBytes, 0, bitStringBody, 1, signatureBytes.size)
        val signatureBitString = derTag(0x03, bitStringBody)

        // 9. Ghép hoàn chỉnh X.509v3 Certificate DER và chuyển sang đối tượng X509Certificate chuẩn
        val certDer = derSequence(tbsCertificate, sha256WithRsaAlgId, signatureBitString)
        val cf = CertificateFactory.getInstance("X.509")
        val cert = cf.generateCertificate(java.io.ByteArrayInputStream(certDer)) as X509Certificate
        cert.verify(keyPair.public)
        return cert
    }

    @Volatile
    var activeHost: String = "127.0.0.1"
        private set

    @Volatile
    var activePort: Int = 5555
        private set

    private fun isTcpEndpointReachable(host: String, port: Int, timeoutMs: Int = 650): Boolean {
        return try {
            java.net.Socket().use { socket ->
                socket.soTimeout = timeoutMs
                socket.connect(java.net.InetSocketAddress(host, port), timeoutMs)
                true
            }
        } catch (_: Throwable) {
            false
        }
    }

    /**
     * Collects all valid local IPv4 addresses where Android's Wireless Debugging (`adbd`) may bind.
     * Always places 127.0.0.1 (loopback) and NSD-discovered host first.
     */
    fun getCandidateHosts(preferredHost: String? = null): List<String> {
        val hosts = LinkedHashSet<String>()
        hosts.add("127.0.0.1")
        if (!preferredHost.isNullOrBlank() &&
            preferredHost != "0.0.0.0" &&
            !preferredHost.startsWith("169.254") &&
            !preferredHost.contains(":")
        ) {
            hosts.add(preferredHost.trim())
        }
        try {
            val scanner = AdbNsdScanner.getInstance(context)
            val scannerState = scanner.state.value
            scannerState.pairingHost?.takeIf { it.isNotBlank() && it != "0.0.0.0" && !it.contains(":") }?.let { hosts.add(it) }
            scanner.getBestPairingHost()?.takeIf { it.isNotBlank() && it != "0.0.0.0" && !it.contains(":") }?.let { hosts.add(it) }
            scannerState.connectHost?.takeIf { it.isNotBlank() && it != "0.0.0.0" && !it.contains(":") }?.let { hosts.add(it) }
        } catch (_: Throwable) {}

        try {
            val interfaces = java.net.NetworkInterface.getNetworkInterfaces()
            if (interfaces != null) {
                for (intf in interfaces) {
                    if (!intf.isUp || intf.isLoopback) continue
                    val name = intf.name.lowercase()
                    if (name.startsWith("wlan") || name.startsWith("ap") || name.startsWith("eth")) {
                        for (addr in intf.inetAddresses) {
                            if (addr is java.net.Inet4Address && !addr.isLoopbackAddress) {
                                val ip = addr.hostAddress
                                if (!ip.isNullOrBlank() && ip != "0.0.0.0") {
                                    hosts.add(ip)
                                }
                            }
                        }
                    }
                }
            }
        } catch (_: Throwable) {}

        return hosts.toList()
    }

    /**
     * Pair directly with Android Wireless Debugging using 6-digit PIN and Pairing Port.
     * QUAN TRỌNG: Tuyệt đối KHÔNG gọi isTcpEndpointReachable() trước eng.pair()!
     * Vì PairingServer của Android (adbd) là single-shot TLS listener: nếu mở một raw TCP socket
     * rồi đóng ngay mà không bắt tay TLS 1.3, adbd sẽ báo lỗi SSL_accept EOF và tự đóng luôn cổng ghép đôi!
     */
    suspend fun pairDirect(port: Int, pairingCode: String, preferredHost: String? = null): Result<Boolean> = withContext(Dispatchers.IO) {
        connectMutex.lock()
        try {
            val eng = getOrCreateEngine()
                ?: return@withContext Result.failure(Exception("Thiết bị không hỗ trợ thư viện mã hóa ADB TLS"))
            val cleanCode = pairingCode.filter { it.isDigit() }.take(6)
            if (cleanCode.length != 6 || port !in 1..65535) {
                return@withContext Result.failure(Exception("Mã PIN 6 số hoặc cổng ghép nối ($port) không hợp lệ."))
            }

            val scanner = try { AdbNsdScanner.getInstance(context) } catch (_: Throwable) { null }
            // Hỗ trợ cả 127.0.0.1 (loopback) VÀ địa chỉ IPv4 Wi-Fi / NSD do adbd quảng bá:
            // Nếu 127.0.0.1 trả về ECONNREFUSED (<5ms), tự động chuyển ngay sang IP Wi-Fi nội bộ của thiết bị!
            val orderedForPairing = getCandidateHosts(preferredHost)

            // Danh sách cổng thử nghiệm: ưu tiên cổng NSD mới nhất và cổng truyền vào
            val candidatePorts = LinkedHashSet<Int>()
            val latestNsdPort = scanner?.getBestPairingPort(port)
            if (latestNsdPort != null && latestNsdPort in 1..65535) {
                candidatePorts.add(latestNsdPort)
            }
            if (port in 1..65535) {
                candidatePorts.add(port)
            }

            var lastError: Throwable? = null
            var effectivePortTried = port

            portLoop@ for (targetPort in candidatePorts) {
                effectivePortTried = targetPort
                for (host in orderedForPairing) {
                    try {
                        Log.d(TAG, "Pairing with $host:$targetPort using code: $cleanCode")
                        try { eng.setHostAddress(host) } catch (_: Throwable) {}
                        // Đặt socket timeout ngắn hơn coroutine timeout để socket tự giải phóng trước khi coroutine hết giờ
                        try { eng.setTimeout(4, TimeUnit.SECONDS) } catch (_: Throwable) {}

                        var attemptError: Throwable? = null
                        val ok = kotlinx.coroutines.withTimeoutOrNull(5200L) {
                            try {
                                eng.pair(host, targetPort, cleanCode)
                            } catch (t: Throwable) {
                                attemptError = t
                                Log.w(TAG, "Inner pair exception on $host:$targetPort: ${t.message}", t)
                                false
                            }
                        } ?: false

                        Log.d(TAG, "Direct pairing result on $host:$targetPort -> $ok")
                        if (ok) {
                            activeHost = host
                            try {
                            val scanner = AdbNsdScanner.getInstance(context)
                            scanner.stopDiscovery(updateStatusText = false)
                            scanner.releaseMulticastLock()
                        } catch (_: Throwable) {}
                        return@withContext Result.success(true)
                        }

                        if (attemptError != null) {
                            lastError = attemptError
                            val rootCause = attemptError?.cause ?: attemptError
                            val errMsg = "${attemptError?.message.orEmpty()} ${rootCause?.message.orEmpty()}"
                            val isTcpRefused = rootCause is java.net.ConnectException ||
                                rootCause is java.net.NoRouteToHostException ||
                                rootCause is java.net.SocketTimeoutException ||
                                errMsg.contains("ECONNREFUSED", ignoreCase = true) ||
                                errMsg.contains("Connection refused", ignoreCase = true) ||
                                errMsg.contains("ENETUNREACH", ignoreCase = true) ||
                                errMsg.contains("EHOSTUNREACH", ignoreCase = true)
                            // Nếu TCP đã kết nối vào adbd nhưng bắt tay SPAKE2 thất bại (do sai mã PIN),
                            // dừng ngay không thử lại trên IP khác vì PairingServer chỉ nhận 1 phiên duy nhất.
                            if (!isTcpRefused) {
                                break@portLoop
                            }
                        }
                    } catch (e: Throwable) {
                        lastError = e
                        Log.w(TAG, "Direct pairing attempt failed on $host:$targetPort: ${e.message}")
                    }
                }
            }

            val errDetail = lastError?.localizedMessage.orEmpty()
            val friendlyMessage = when {
                errDetail.contains("ECONNREFUSED", ignoreCase = true) ||
                    errDetail.contains("Connection refused", ignoreCase = true) ->
                    "Cổng ghép nối $effectivePortTried đã bị đóng! Lưu ý: Khi mở hộp thoại Mã ghép đôi 6 số trong Cài đặt, bạn KHÔNG ĐƯỢC thoát Cài đặt (hãy nhập 6 số ngay trên Thanh thông báo hoặc Cửa sổ nổi)."
                errDetail.contains("Exchanging message", ignoreCase = true) ||
                    errDetail.contains("peer info", ignoreCase = true) ->
                    "Mã ghép đôi 6 số không khớp hoặc đã hết hạn trên cổng $effectivePortTried. Hãy bấm lại 'Ghép nối thiết bị bằng mã ghép đôi' và nhập mã mới."
                else ->
                    "Ghép nối thất bại tại cổng $effectivePortTried (${errDetail.ifBlank { "Cửa sổ mã ghép đôi đã đóng hoặc sai mã 6 số" }}). Hãy nhập 6 số ngay trên Thanh thông báo khi đang mở màn hình Cài đặt!"
            }
            Result.failure(Exception(friendlyMessage, lastError))
        } finally {
            connectMutex.unlock()
        }
    }

    /**
     * Connect directly to ADB daemon over <127.0.0.1 or Wi-Fi IP>:<mainPort> using TLS 1.3 / Conscrypt.
     */
    suspend fun connectDirect(port: Int, preferredHost: String? = null): Result<Boolean> = withContext(Dispatchers.IO) {
        if (fastConnectedFlag && activePort == port && isConnectedFast()) {
            return@withContext Result.success(true)
        }
        connectMutex.lock()
        try {
            val eng = getOrCreateEngine()
                ?: return@withContext Result.failure(Exception("Thiết bị không hỗ trợ thư viện mã hóa ADB TLS"))
            if (fastConnectedFlag && activePort == port) {
                try {
                    if (eng.isConnected) return@withContext Result.success(true)
                } catch (_: Throwable) {}
            }
            if (fastConnectedFlag) {
                fastConnectedFlag = false
            }
            try { eng.disconnect() } catch (_: Throwable) {}

            val candidates = getCandidateHosts(preferredHost)
            val candidatePorts = LinkedHashSet<Int>()
            if (port in 1..65535) candidatePorts.add(port)
            try {
                val scanner = AdbNsdScanner.getInstance(context)
                scanner.getBestConnectPort()?.takeIf { it in 1..65535 }?.let { candidatePorts.add(it) }
                scanner.state.value.connectPort?.takeIf { it in 1..65535 }?.let { candidatePorts.add(it) }
            } catch (_: Throwable) {}
            if (activePort in 1..65535) candidatePorts.add(activePort)

            var lastError: Throwable? = null

            // 10x Speedup: Kiểm tra song song đồng thời (Parallel Async) toàn bộ endpoint CANDIDATE trong ~180ms
            val deferredChecks = mutableListOf<Pair<Pair<String, Int>, kotlinx.coroutines.Deferred<Boolean>>>()
            for (targetPort in candidatePorts) {
                for (host in candidates) {
                    val def = async(Dispatchers.IO) {
                        isTcpEndpointReachable(host, targetPort, timeoutMs = 180)
                    }
                    deferredChecks.add((host to targetPort) to def)
                }
            }

            val reachableEndpoints = mutableListOf<Pair<String, Int>>()
            val fallbackEndpoints = mutableListOf<Pair<String, Int>>()
            for ((endpoint, def) in deferredChecks) {
                if (def.await()) {
                    reachableEndpoints.add(endpoint)
                } else {
                    fallbackEndpoints.add(endpoint)
                }
            }
            val orderedEndpoints = if (reachableEndpoints.isNotEmpty()) {
                reachableEndpoints
            } else {
                fallbackEndpoints
            }
            val connectAttemptTimeoutMs = if (reachableEndpoints.isNotEmpty()) 2800L else 1000L

            for ((host, targetPort) in orderedEndpoints) {
                try {
                    Log.d(TAG, "Connecting Direct ADB to $host:$targetPort")
                    try { eng.disconnect() } catch (_: Throwable) {}
                    try { eng.setHostAddress(host) } catch (_: Throwable) {}
                    // Đồng bộ socket timeout < coroutine timeout để không bỏ sót socket treo giữ mutex
                    try { eng.setTimeout(if (reachableEndpoints.isNotEmpty()) 3 else 1, TimeUnit.SECONDS) } catch (_: Throwable) {}
                    val ok = kotlinx.coroutines.withTimeoutOrNull(connectAttemptTimeoutMs) {
                        try {
                            eng.connect(host, targetPort)
                        } catch (t: Throwable) {
                            lastError = t
                            false
                        }
                    } ?: false
                    val connectedNow = ok && try { eng.isConnected } catch (_: Throwable) { false }
                    Log.d(TAG, "Direct connect result on $host:$targetPort -> ok=$ok, isConnected=$connectedNow")
                    if (connectedNow) {
                        val wasReconnect = reconnectCounter.get() > 0 || lastConnectedAtWasSet()
                        val reconnects = if (wasReconnect) reconnectCounter.incrementAndGet() else reconnectCounter.get()
                        activeHost = host
                        activePort = targetPort
                        fastConnectedFlag = true
                        lastAutoReconnectFailMs = 0L
                        isManualDisconnected = false
                        val fp = getCertificateFingerprintShort()
                        val lan = getPrimaryWifiIpv4()
                        _telemetry.update { cur ->
                            cur.copy(
                                isConnected = true,
                                activeHost = host,
                                activePort = targetPort,
                                lanIp = lan,
                                certFingerprintSha256 = fp,
                                uidIdentity = if (cur.uidIdentity == "Chưa xác thực") "uid=2000(shell)" else cur.uidIdentity,
                                reconnectCount = reconnects,
                                lastConnectedAtMs = System.currentTimeMillis(),
                                lastErrorSummary = null
                            )
                        }
                        try {
                            val scanner = AdbNsdScanner.getInstance(context)
                            scanner.stopDiscovery(updateStatusText = false)
                            scanner.releaseMulticastLock()
                        } catch (_: Throwable) {}
                        return@withContext Result.success(true)
                    }
                } catch (e: Throwable) {
                    lastError = e
                    Log.w(TAG, "Direct connect attempt failed on $host:$targetPort: ${e.message}")
                }
            }
            fastConnectedFlag = false
            lastAutoReconnectFailMs = System.currentTimeMillis()
            val errMsg = lastError?.localizedMessage ?: "Cổng $port chưa mở hoặc chưa ghép nối"
            _telemetry.update { cur ->
                cur.copy(
                    isConnected = false,
                    lanIp = getPrimaryWifiIpv4(),
                    lastErrorSummary = errMsg
                )
            }
            Result.failure(Exception(errMsg, lastError))
        } finally {
            connectMutex.unlock()
        }
    }

    private fun lastConnectedAtWasSet(): Boolean = _telemetry.value.lastConnectedAtMs > 0L

    /**
     * Dò cổng đa tầng thông minh (SystemProperties -> NSD -> Parallel TCP Probe) và tự động kết nối ngay
     * không cần người dùng nhập tay bất kỳ số cổng nào.
     */
    suspend fun probeAndAutoConnect(
        preferredPort: Int? = null,
        preferredHost: String? = null
    ): Result<Int> = withContext(Dispatchers.IO) {
        val scanner = try { AdbNsdScanner.getInstance(context) } catch (_: Throwable) { null }
        val activePairingPort = scanner?.state?.value?.pairingPort

        val candidatePorts = LinkedHashSet<Int>()
        preferredPort?.takeIf { it in 1024..65535 }?.let { candidatePorts.add(it) }
        scanner?.readSystemAdbTlsPort()?.takeIf { it in 1024..65535 && it != activePairingPort }?.let { candidatePorts.add(it) }
        scanner?.state?.value?.connectPort?.takeIf { it in 1024..65535 && it != activePairingPort }?.let { candidatePorts.add(it) }
        scanner?.lastKnownConnectPort?.takeIf { it in 1024..65535 && it != activePairingPort }?.let { candidatePorts.add(it) }
        scanner?.getBestConnectPort()?.takeIf { it in 1024..65535 && it != activePairingPort }?.let { candidatePorts.add(it) }
        scanner?.getRecentConnectPorts()?.forEach { p ->
            if (p != activePairingPort) candidatePorts.add(p)
        }
        if (activePort in 1024..65535 && activePort != activePairingPort) {
            candidatePorts.add(activePort)
        }
        candidatePorts.add(5555)

        val hosts = getCandidateHosts(preferredHost ?: scanner?.getBestConnectHost())
        val probeJobs = mutableListOf<Pair<Pair<String, Int>, kotlinx.coroutines.Deferred<Boolean>>>()
        for (port in candidatePorts) {
            for (host in hosts) {
                val job = async(Dispatchers.IO) {
                    isTcpEndpointReachable(host, port, timeoutMs = 180)
                }
                probeJobs.add((host to port) to job)
            }
        }

        val reachable = mutableListOf<Pair<String, Int>>()
        for ((ep, job) in probeJobs) {
            if (job.await()) {
                reachable.add(ep)
            }
        }

        val targetEndpoint = reachable.firstOrNull { it.first == "127.0.0.1" }
            ?: reachable.firstOrNull()
            ?: (hosts.first() to (candidatePorts.firstOrNull() ?: 5555))

        val res = connectDirect(targetEndpoint.second, targetEndpoint.first)
        if (res.isSuccess && res.getOrDefault(false)) {
            Result.success(activePort)
        } else {
            Result.failure(res.exceptionOrNull() ?: Exception("Không tìm thấy cổng ADB đang mở"))
        }
    }

    /**
     * Đo độ trễ phản hồi (RTT ms) thực tế qua kênh TLS Shell + xác nhận danh tính UID 2000.
     */
    suspend fun pingLatencyMs(): Long? = withContext(Dispatchers.IO) {
        if (!verifyConnectedIo()) return@withContext null
        val startMs = SystemClock.elapsedRealtime()
        val res = executeCommand("id -u", timeoutSec = 5L)
        val rtt = (SystemClock.elapsedRealtime() - startMs).coerceAtLeast(1L)
        if (res.exitCode == 0) {
            val uidRaw = res.output.trim()
            val uidText = when {
                uidRaw.contains("2000") -> "uid=2000(shell) ✓"
                uidRaw.contains("0") -> "uid=0(root) ✓"
                uidRaw.isNotBlank() -> "uid=$uidRaw"
                else -> "uid=2000(shell)"
            }
            _telemetry.update { cur ->
                val newAvg = cur.avgLatencyMs?.let { ((it * 3) + rtt) / 4 } ?: rtt
                cur.copy(
                    lastLatencyMs = rtt,
                    avgLatencyMs = newAvg,
                    uidIdentity = uidText,
                    lanIp = getPrimaryWifiIpv4(),
                    lastErrorSummary = null
                )
            }
            rtt
        } else {
            null
        }
    }

    /**
     * Chẩn đoán chuyên sâu 6 điểm cho Gỡ lỗi Không Dây (WLAN ADB).
     */
    suspend fun runDiagnostics(hasPairedBefore: Boolean): AdbDiagnosticReport = withContext(Dispatchers.IO) {
        val steps = mutableListOf<AdbDiagnosticStep>()

        // 1. Tùy chọn nhà phát triển
        val devEnabled = try {
            Settings.Global.getInt(context.contentResolver, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1
        } catch (_: Throwable) { false }
        steps.add(
            AdbDiagnosticStep(
                id = "dev_opts",
                title = "1. Tùy chọn nhà phát triển",
                detail = if (devEnabled) "Đang bật sẵn (development_settings_enabled = 1)" else "Đang tắt — cần bật Tùy chọn nhà phát triển trong Cài đặt.",
                severity = if (devEnabled) DiagnosticSeverity.PASS else DiagnosticSeverity.FAIL
            )
        )

        // 2. Công tắc Gỡ lỗi Wi-Fi
        val rawAdbWifi = try {
            Settings.Global.getInt(context.contentResolver, "adb_wifi_enabled", -1)
        } catch (_: Throwable) { -1 }
        val connectedAlready = verifyConnectedIo()
        val adbWifiOn = rawAdbWifi == 1 || (rawAdbWifi == -1 && connectedAlready)
        steps.add(
            AdbDiagnosticStep(
                id = "adb_wifi",
                title = "2. Công tắc Gỡ lỗi qua Wi-Fi",
                detail = when {
                    adbWifiOn -> "Đang bật (adb_wifi_enabled = 1)"
                    rawAdbWifi == 0 -> "Đang tắt! Hãy bật lại công tắc 'Gỡ lỗi qua Wi-Fi' trong Cài đặt."
                    else -> "Không đọc được trực tiếp (OEM ẩn), kiểm tra qua cổng mDNS."
                },
                severity = when {
                    adbWifiOn -> DiagnosticSeverity.PASS
                    rawAdbWifi == 0 -> DiagnosticSeverity.FAIL
                    else -> DiagnosticSeverity.WARN
                }
            )
        )

        // 3. Kết nối mạng Wi-Fi & IPv4 LAN
        val lanIp = getPrimaryWifiIpv4()
        steps.add(
            AdbDiagnosticStep(
                id = "wifi_net",
                title = "3. Mạng Wi-Fi & Địa chỉ LAN",
                detail = if (lanIp != null) "IP nội bộ: $lanIp (Sẵn sàng loopback 127.0.0.1 & WLAN)" else "Chưa có IPv4 Wi-Fi! Gỡ lỗi không dây cần kết nối một mạng Wi-Fi.",
                severity = if (lanIp != null) DiagnosticSeverity.PASS else DiagnosticSeverity.WARN
            )
        )

        // 4. Radar mDNS & Cổng Hệ Thống (service.adb.tls.port)
        val scanner = try { AdbNsdScanner.getInstance(context) } catch (_: Throwable) { null }
        val sysPort = scanner?.readSystemAdbTlsPort()
        val nsdConnectPort = scanner?.state?.value?.connectPort ?: scanner?.lastKnownConnectPort
        val bestPort = sysPort ?: nsdConnectPort ?: if (connectedAlready) activePort else null
        steps.add(
            AdbDiagnosticStep(
                id = "port_radar",
                title = "4. Radar mDNS & Cổng TLS",
                detail = when {
                    sysPort != null -> "Bắt trực tiếp từ kernel prop: cổng $sysPort"
                    nsdConnectPort != null -> "Phát hiện qua _adb-tls-connect._tcp: cổng $nsdConnectPort"
                    connectedAlready -> "Đang giữ kết nối tại $activeHost:$activePort"
                    else -> "Chưa thấy cổng mở — hãy thử bật/tắt lại Gỡ lỗi Wi-Fi hoặc bấm Quét Cổng."
                },
                severity = if (bestPort != null) DiagnosticSeverity.PASS else DiagnosticSeverity.WARN
            )
        )

        // 5. Khóa RSA-2048 & Chứng chỉ X.509v3
        val fp = getCertificateFingerprintShort()
        val certOk = fp.isNotBlank()
        steps.add(
            AdbDiagnosticStep(
                id = "rsa_cert",
                title = "5. Khóa RSA-2048 & Chứng chỉ TLS",
                detail = when {
                    certOk && hasPairedBefore -> "Chứng chỉ hợp lệ (SHA-256: $fp) • Đã từng ghép đôi"
                    certOk -> "Chứng chỉ hợp lệ (SHA-256: $fp) • Chưa ghép đôi mã 6 số lần đầu"
                    else -> "Khóa RSA chưa sẵn sàng — nên bấm Reset Khóa RSA."
                },
                severity = if (certOk && hasPairedBefore) DiagnosticSeverity.PASS else if (certOk) DiagnosticSeverity.WARN else DiagnosticSeverity.FAIL
            )
        )

        // 6. Kiểm tra Handshake & Ping RTT UID 2000
        val pingMs = if (connectedAlready) pingLatencyMs() else null
        steps.add(
            AdbDiagnosticStep(
                id = "shell_ping",
                title = "6. Bắt tay TLS & Ping UID 2000",
                detail = when {
                    pingMs != null -> "Kênh shell phản hồi mượt: ${pingMs}ms (${_telemetry.value.uidIdentity})"
                    connectedAlready -> "Socket đang mở tại $activeHost:$activePort nhưng stream shell chưa phản hồi."
                    bestPort != null -> "Tìm thấy cổng $bestPort nhưng chưa kết nối — bấm 'Tự Dò & Nối Ngay'."
                    else -> "Chưa có phiên TLS hoạt động."
                },
                severity = if (pingMs != null) DiagnosticSeverity.PASS else if (connectedAlready || bestPort != null) DiagnosticSeverity.WARN else DiagnosticSeverity.FAIL,
                latencyMs = pingMs
            )
        )

        val recommended = when {
            pingMs != null -> "Hệ thống Direct WLAN ADB hoạt động hoàn hảo (${pingMs}ms • UID 2000)."
            !devEnabled -> "Hãy bật 'Tùy chọn nhà phát triển' trước."
            rawAdbWifi == 0 -> "Hãy bật công tắc 'Gỡ lỗi qua Wi-Fi' trong Cài đặt nhà phát triển."
            !hasPairedBefore -> "Cần ghép nối mã PIN 6 số 1 lần đầu ở Tab '1. Mã 6 Số'."
            bestPort != null -> "Đã thấy cổng $bestPort! Bấm nút '⚡ Tự Dò Cổng & Kết Nối Ngay'."
            lanIp == null -> "Hãy kết nối Wi-Fi để Android kích hoạt daemon Gỡ lỗi không dây."
            else -> "Tắt rồi bật lại Gỡ lỗi Wi-Fi hoặc bấm Reset Khóa RSA rồi ghép đôi lại."
        }

        _telemetry.update { it.copy(lanIp = lanIp, certFingerprintSha256 = fp) }
        AdbDiagnosticReport(
            generatedAtMs = System.currentTimeMillis(),
            overallReady = pingMs != null,
            steps = steps,
            recommendedAction = recommended
        )
    }

    /**
     * Disconnect ADB connection gracefully.
     */
    fun disconnectDirect() {
        closePersistentShellAsync()
        fastConnectedFlag = false
        isManualDisconnected = true
        _telemetry.update { it.copy(isConnected = false) }
        val eng = internalEngine ?: return
        try {
            if (eng.isConnected) {
                eng.disconnect()
            }
        } catch (e: Throwable) {
            Log.w(TAG, "DisconnectDirect error", e)
        }
    }

    private val execMutex = kotlinx.coroutines.sync.Mutex()

    @Volatile
    private var activeCommandStream: AdbStream? = null

    @Volatile
    private var persistentShellStream: AdbStream? = null
    private var persistentShellOs: java.io.OutputStream? = null
    private var persistentShellIs: java.io.InputStream? = null

    private fun closePersistentShellLocked() {
        try { persistentShellOs?.close() } catch (_: Throwable) {}
        try { persistentShellIs?.close() } catch (_: Throwable) {}
        try { persistentShellStream?.close() } catch (_: Throwable) {}
        persistentShellOs = null
        persistentShellIs = null
        persistentShellStream = null
        activeCommandStream = null
    }

    private fun closePersistentShellAsync() {
        val stream = persistentShellStream
        persistentShellOs = null
        persistentShellIs = null
        persistentShellStream = null
        activeCommandStream = null
        try { stream?.close() } catch (_: Throwable) {}
    }

    /**
     * Đóng ngay lập tức persistent shell stream khi màn hình tắt để tiết kiệm pin tối đa (0% socket polling).
     */
    fun closePersistentShellOnScreenOff() {
        closePersistentShellAsync()
    }

    /**
     * Ngắt ngay lập tức lệnh Direct ADB đang chạy (nếu có) để ưu tiên lệnh mới nhất.
     */
    fun abortCurrentCommand(): Boolean {
        val s = activeCommandStream ?: persistentShellStream ?: return false
        return try {
            s.close()
            persistentShellOs = null
            persistentShellIs = null
            persistentShellStream = null
            activeCommandStream = null
            true
        } catch (_: Throwable) {
            false
        }
    }

    /**
     * Execute shell command directly over TLS socket with UID 2000 (Native ADB Shell).
     * Reuses a single persistent `sh` stream across sequential commands to eliminate repeated adbd shell forks.
     * Includes newline/CR sanitization and up to 3 transport retries (450ms backoff) on transient wireless ADB drops.
     */
    suspend fun executeCommand(command: String, timeoutSec: Long = 300): ShellResult = withContext(Dispatchers.IO) {
        val sanitizedInput = command
            .replace("\r\n", "\n")
            .replace("\r", "")
            .trim()
        if (sanitizedInput.isEmpty()) {
            return@withContext ShellResult("", 0, "", "", ShellMode.WIRELESS_ADB)
        }

        val devOn = try {
            Settings.Global.getInt(context.contentResolver, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1
        } catch (_: Exception) { false }
        val adbWifiOn = try {
            Settings.Global.getInt(context.contentResolver, "adb_wifi_enabled", 0) == 1
        } catch (_: Exception) { false }
        if (!devOn || !adbWifiOn) {
            disconnectDirect()
            return@withContext ShellResult(
                command = sanitizedInput,
                exitCode = 1,
                output = "",
                error = "Chế độ nhà phát triển hoặc Gỡ lỗi qua Wi-Fi đang tắt trong Cài đặt hệ thống. Lệnh bị ngắt để chống dòng rò và tiết kiệm pin.",
                modeUsed = ShellMode.WIRELESS_ADB
            )
        }

        val maxAttempts = 3
        var lastTransportError = "Direct ADB chưa được kết nối (WLAN đang tắt hoặc chưa ghép nối)."

        for (attempt in 1..maxAttempts) {
            var eng = internalEngine
            if (eng == null || !verifyConnectedIo()) {
                val nowMs = System.currentTimeMillis()
                val canTryReconnect = !isManualDisconnected &&
                    activePort in 1..65535 &&
                    (attempt > 1 || (nowMs - lastAutoReconnectFailMs) >= 8_000L)
                if (canTryReconnect) {
                    try {
                        val reconnected = kotlinx.coroutines.withTimeoutOrNull(2200L) {
                            connectDirect(activePort, activeHost).getOrDefault(false)
                        } ?: false
                        if (reconnected) {
                            eng = internalEngine
                        } else {
                            lastAutoReconnectFailMs = System.currentTimeMillis()
                        }
                    } catch (_: Throwable) {
                        lastAutoReconnectFailMs = System.currentTimeMillis()
                    }
                }
                if (eng == null || !verifyConnectedIo()) {
                    if (attempt < maxAttempts && !isManualDisconnected && activePort in 1..65535) {
                        kotlinx.coroutines.delay(450L)
                        continue
                    }
                    return@withContext ShellResult(
                        command = sanitizedInput,
                        exitCode = 1,
                        output = "",
                        error = lastTransportError,
                        modeUsed = ShellMode.WIRELESS_ADB
                    )
                }
            }

            execMutex.lock()
            val cmdStartMs = SystemClock.elapsedRealtime()
            var shouldRetryTransport = false
            try {
                val currentEng = eng ?: getOrCreateEngine()
                    ?: throw IllegalStateException("Không có engine ADB TLS khả dụng")

                var stream = persistentShellStream?.takeIf { !it.isClosed }
                var os = persistentShellOs
                var `is` = persistentShellIs
                var isFreshStream = false

                if (stream == null || os == null || `is` == null) {
                    closePersistentShellLocked()
                    stream = try {
                        currentEng.openStream("shell:")
                    } catch (openErr: Throwable) {
                        val isRejected = openErr.message?.contains("rejected", ignoreCase = true) == true ||
                            openErr.message?.contains("closed", ignoreCase = true) == true ||
                            openErr.message?.contains("reset", ignoreCase = true) == true ||
                            openErr.message?.contains("pipe", ignoreCase = true) == true
                        if (isRejected && activePort in 1..65535) {
                            Log.w(TAG, "Stream open bị từ chối (lần $attempt), đang thử kết nối lại và mở lại stream...")
                            kotlinx.coroutines.delay(450L)
                            fastConnectedFlag = false
                            try { currentEng.disconnect() } catch (_: Throwable) {}
                            val reconnected = connectDirect(activePort, activeHost).getOrDefault(false)
                            if (!reconnected) throw openErr
                            val retryEng = internalEngine ?: throw openErr
                            retryEng.openStream("shell:")
                        } else {
                            throw openErr
                        }
                    }
                    os = stream.openOutputStream()
                    `is` = stream.openInputStream()
                    persistentShellStream = stream
                    persistentShellOs = os
                    persistentShellIs = `is`
                    isFreshStream = true
                }

                val activeStream = stream
                activeCommandStream = activeStream

                val cmdId = shellCommandSeq.incrementAndGet()
                val startPart1 = "---MT_START_${cmdId}"
                val startPart2 = "---"
                val fullStartMarker = startPart1 + startPart2
                val markerPart1 = "---MT_EXIT_${cmdId}:"
                val markerPart2 = "---"
                val exitRegex = Regex("${Regex.escape(markerPart1)}(-?\\d+)${Regex.escape(markerPart2)}")

                val execScript = buildString {
                    if (isFreshStream) {
                        append("export PATH=/sbin:/system/sbin:/system/bin:/system/xbin:/odm/bin:/vendor/bin:/vendor/xbin:\$PATH\n")
                    }
                    append("echo \"$startPart1\"\"$startPart2\"\n")
                    append(sanitizedInput).append("\n")
                    append("__mt_ec=\$?\n")
                    append("echo \"$markerPart1\$__mt_ec\"\"$markerPart2\"\n")
                }

                try {
                    os.write(execScript.toByteArray(Charsets.UTF_8))
                    os.flush()
                } catch (writeErr: Throwable) {
                    closePersistentShellLocked()
                    throw writeErr
                }

                val outputBuilder = StringBuilder()
                var foundMarker = false

                val readDeferred = async(Dispatchers.IO) {
                    val buffer = ByteArray(4096)
                    try {
                        while (!activeStream.isClosed) {
                            val read = `is`.read(buffer)
                            if (read == -1) break
                            if (read > 0) {
                                val chunk = String(buffer, 0, read, Charsets.UTF_8)
                                synchronized(outputBuilder) {
                                    outputBuilder.append(chunk)
                                    val bLen = outputBuilder.length
                                    if (bLen >= markerPart1.length + markerPart2.length + 1) {
                                        val tailLen = (markerPart1.length + 80).coerceAtMost(bLen)
                                        val tailStr = outputBuilder.substring(bLen - tailLen)
                                        if (exitRegex.containsMatchIn(tailStr)) {
                                            foundMarker = true
                                            return@async true
                                        }
                                    }
                                }
                            }
                        }
                    } catch (_: Throwable) {
                    }
                    foundMarker
                }

                val completedInTime = withTimeoutOrNull(timeoutSec * 1000L) {
                    readDeferred.await()
                }

                if (completedInTime == null) {
                    closePersistentShellLocked()
                    readDeferred.cancel()
                    val partialOut = synchronized(outputBuilder) { outputBuilder.toString().trim() }
                    totalCommandsCounter.incrementAndGet()
                    failedCommandsCounter.incrementAndGet()
                    _telemetry.update {
                        it.copy(
                            totalCommandsExecuted = totalCommandsCounter.get(),
                            failedCommandsCount = failedCommandsCounter.get(),
                            lastErrorSummary = "Timeout > ${timeoutSec}s"
                        )
                    }
                    return@withContext ShellResult(
                        command = sanitizedInput,
                        exitCode = 124,
                        output = partialOut,
                        error = "Quá thời gian thực thi lệnh qua Direct ADB (Timeout > ${timeoutSec}s)",
                        modeUsed = ShellMode.WIRELESS_ADB
                    )
                }

                if (!foundMarker || activeStream.isClosed) {
                    closePersistentShellLocked()
                }

                // Nếu stream rớt giữa chừng trước khi nhận được start/exit marker (mất gói wireless ADB), thử lại tối đa 3 lần
                val rawSnapshot = synchronized(outputBuilder) { outputBuilder.toString() }
                val hasMarkerInSnapshot = exitRegex.containsMatchIn(rawSnapshot)
                if (!hasMarkerInSnapshot && !isManualDisconnected && attempt < maxAttempts) {
                    closePersistentShellLocked()
                    lastTransportError = "Kênh Wireless ADB tạm ngắt trước khi lệnh hoàn tất (lần $attempt/$maxAttempts)"
                    shouldRetryTransport = true
                    fastConnectedFlag = false
                } else {
                    var exitCode = 0
                    var fullText = rawSnapshot.replace("\r\n", "\n")

                    val match = exitRegex.findAll(fullText).lastOrNull()
                    if (match != null) {
                        exitCode = match.groupValues[1].toIntOrNull() ?: 0
                        fullText = fullText.substring(0, match.range.first)
                    }

                    val startIdx = fullText.indexOf(fullStartMarker)
                    if (startIdx >= 0) {
                        fullText = fullText.substring(startIdx + fullStartMarker.length)
                    }

                    val sanitizedText = fullText
                        .replace(Regex("\\u001B\\[[0-9;?]*[ -/]*[@-~]"), "")
                        .replace(Regex("[\\u0000-\\u0008\\u000B\\u000C\\u000E-\\u001F\\u007F]"), "")

                    val cleanLines = sanitizedText.lines().filterNot { line ->
                        val l = line.trim()
                        l == sanitizedInput ||
                            l.startsWith("export PATH=") ||
                            l.contains("__mt_ec=") ||
                            l.contains("\"$markerPart1") ||
                            l.contains("\"$startPart1\"\"$startPart2")
                    }
                    val cleanOutput = cleanLines.joinToString("\n").trim()

                    val elapsed = (SystemClock.elapsedRealtime() - cmdStartMs).coerceAtLeast(1L)
                    val totalNow = totalCommandsCounter.incrementAndGet()
                    val failNow = if (exitCode != 0) failedCommandsCounter.incrementAndGet() else failedCommandsCounter.get()
                    _telemetry.update { cur ->
                        val newAvg = cur.avgLatencyMs?.let { ((it * 4) + elapsed) / 5 } ?: elapsed
                        cur.copy(
                            lastLatencyMs = elapsed,
                            avgLatencyMs = newAvg,
                            totalCommandsExecuted = totalNow,
                            failedCommandsCount = failNow,
                            lastErrorSummary = if (exitCode != 0) cleanOutput.take(120) else null
                        )
                    }

                    return@withContext ShellResult(
                        command = sanitizedInput,
                        exitCode = exitCode,
                        output = cleanOutput,
                        error = if (exitCode != 0) cleanOutput else "",
                        modeUsed = ShellMode.WIRELESS_ADB
                    )
                }
            } catch (e: Throwable) {
                closePersistentShellLocked()
                val errMsg = e.localizedMessage ?: "Direct ADB execution error"
                lastTransportError = errMsg
                val isTransientTransportErr = e is java.io.IOException ||
                    e is java.net.SocketException ||
                    errMsg.contains("closed", true) ||
                    errMsg.contains("reset", true) ||
                    errMsg.contains("pipe", true) ||
                    errMsg.contains("eof", true) ||
                    errMsg.contains("rejected", true)
                if (isTransientTransportErr && !isManualDisconnected && attempt < maxAttempts) {
                    Log.w(TAG, "Wireless ADB transport error (attempt $attempt/$maxAttempts): $errMsg")
                    fastConnectedFlag = false
                    shouldRetryTransport = true
                } else {
                    Log.e(TAG, "Execute command direct error: $sanitizedInput", e)
                    val totalNow = totalCommandsCounter.incrementAndGet()
                    val failNow = failedCommandsCounter.incrementAndGet()
                    _telemetry.update {
                        it.copy(
                            totalCommandsExecuted = totalNow,
                            failedCommandsCount = failNow,
                            lastErrorSummary = errMsg
                        )
                    }
                    return@withContext ShellResult(
                        command = sanitizedInput,
                        exitCode = 1,
                        output = "",
                        error = errMsg,
                        modeUsed = ShellMode.WIRELESS_ADB
                    )
                }
            } finally {
                activeCommandStream = null
                execMutex.unlock()
            }

            if (shouldRetryTransport) {
                kotlinx.coroutines.delay(450L)
            }
        }

        val totalNow = totalCommandsCounter.incrementAndGet()
        val failNow = failedCommandsCounter.incrementAndGet()
        _telemetry.update {
            it.copy(
                totalCommandsExecuted = totalNow,
                failedCommandsCount = failNow,
                lastErrorSummary = lastTransportError
            )
        }
        ShellResult(
            command = sanitizedInput,
            exitCode = 1,
            output = "",
            error = lastTransportError,
            modeUsed = ShellMode.WIRELESS_ADB
        )
    }
}
