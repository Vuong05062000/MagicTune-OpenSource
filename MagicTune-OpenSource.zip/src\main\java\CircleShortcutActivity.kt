package com.example.core.widget

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/** Each launcher entry has its own task so an existing MainActivity is not reused. */
open class FeatureShortcutActivity : Activity() {
    protected open val feature = "circle"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        launchFeature()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        launchFeature()
    }

    private fun launchFeature() {
        startActivity(Intent(this, MagicLiveLockscreenActivity::class.java).apply {
            putExtra("pinned_overlay_action", feature)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        })
        finish()
    }
}

class CircleShortcutActivity : FeatureShortcutActivity()
class DrawShortcutActivity : FeatureShortcutActivity() {
    override val feature = "draw"
}
class LiveShortcutActivity : FeatureShortcutActivity() {
    override val feature = "live"
}
class TranslateShortcutActivity : FeatureShortcutActivity() {
    override val feature = "translate"
}

class GoogleCircleShortcutActivity : FeatureShortcutActivity() {
    override val feature = "google_circle"
}

class DoublePowerFolderShortcutActivity : FeatureShortcutActivity() {
    override val feature = "double_power_folder"
}
