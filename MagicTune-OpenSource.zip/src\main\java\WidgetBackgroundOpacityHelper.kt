package com.example.core.widget

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.example.R

object WidgetBackgroundOpacityHelper {

    private const val PREFS_NAME = "magictune_widget_prefs"
    private const val KEY_BG_OPACITY_PCT = "widget_bg_opacity_pct"
    const val DEFAULT_OPACITY_PCT = 35

    enum class BgStyle(val prefix: String, val fallbackRes: Int) {
        DEFAULT("widget_bg", R.drawable.widget_bg),
        GLASS("widget_glass_bg", R.drawable.widget_glass_bg),
        PERPETUAL("widget_perpetual_calendar_bg", R.drawable.widget_perpetual_calendar_bg),
        SEARCH("bg_widget_search_card", R.drawable.bg_widget_search_card)
    }

    fun getOpacityPercent(context: Context): Int {
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getInt(KEY_BG_OPACITY_PCT, DEFAULT_OPACITY_PCT).coerceIn(0, 100)
    }

    fun setOpacityPercent(context: Context, percent: Int, refreshWidgets: Boolean = true) {
        val appCtx = context.applicationContext
        val clamped = percent.coerceIn(0, 100)
        appCtx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_BG_OPACITY_PCT, clamped)
            .apply()
        if (refreshWidgets) {
            notifyAllWidgets(appCtx)
        }
    }

    fun resolveDrawable(context: Context, style: BgStyle): Int {
        val pct = getOpacityPercent(context)
        val step = (((pct + 2) / 5) * 5).coerceIn(0, 100)
        val resId = context.resources.getIdentifier("${style.prefix}_p$step", "drawable", context.packageName)
        return if (resId != 0) resId else style.fallbackRes
    }

    fun applyBackground(context: Context, views: RemoteViews, viewId: Int, style: BgStyle) {
        views.setInt(viewId, "setBackgroundResource", resolveDrawable(context, style))
    }

    fun notifyAllWidgets(context: Context) {
        val appCtx = context.applicationContext
        val awm = try { AppWidgetManager.getInstance(appCtx) } catch (_: Throwable) { return }
        for (descriptor in HomeWidgetPinHelper.allWidgets) {
            try {
                val cn = ComponentName(appCtx, descriptor.providerClass)
                val ids = awm.getAppWidgetIds(cn)
                if (ids.isNotEmpty()) {
                    val intent = Intent(appCtx, descriptor.providerClass).apply {
                        action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                        putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                    }
                    appCtx.sendBroadcast(intent)
                }
            } catch (_: Throwable) {}
        }
    }
}
