package com.example.core.widget

import android.app.ActivityManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Environment
import android.os.StatFs
import android.widget.RemoteViews
import com.example.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.roundToInt

class MagicTuneMemoryWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        val appCtx = context.applicationContext ?: context
        val idsCopy = appWidgetIds.copyOf()
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                for (id in idsCopy) {
                    updateWidget(appCtx, appWidgetManager, id)
                }
            } catch (_: Throwable) {
            } finally {
                try { pendingResult.finish() } catch (_: Throwable) {}
            }
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_BOOST_RAM) {
            val appCtx = context.applicationContext ?: context
            val pendingResult = goAsync()
            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                try {
                    val am = appCtx.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
                    val pm = appCtx.packageManager
                    val myPkg = appCtx.packageName
                    val installed = try {
                        pm.getInstalledApplications(0)
                    } catch (_: Throwable) {
                        emptyList()
                    }
                    var killedCount = 0
                    for (appInfo in installed) {
                        val pkg = appInfo.packageName ?: continue
                        if (pkg == myPkg || pkg.startsWith("com.android.systemui")) continue
                        if ((appInfo.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) == 0) {
                            try {
                                am?.killBackgroundProcesses(pkg)
                                killedCount++
                            } catch (_: Throwable) {}
                        }
                    }
                    val awm = AppWidgetManager.getInstance(appCtx)
                    val ids = awm.getAppWidgetIds(ComponentName(appCtx, MagicTuneMemoryWidgetProvider::class.java))
                    val status = "✅ Đã giải phóng"
                    for (id in ids) {
                        updateWidget(appCtx, awm, id, status)
                    }
                } catch (_: Throwable) {
                } finally {
                    try { pendingResult.finish() } catch (_: Throwable) {}
                }
            }
        }
    }

    companion object {
        const val ACTION_BOOST_RAM = "com.example.core.widget.ACTION_BOOST_RAM"

        fun updateWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int,
            statusOverride: String? = null
        ) {
            try {
                val views = RemoteViews(context.packageName, R.layout.widget_ram_rom_live)
                val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
                val memInfo = ActivityManager.MemoryInfo()
                am?.getMemoryInfo(memInfo)
                val totalRamGb = (memInfo.totalMem.toDouble() / (1024.0 * 1024.0 * 1024.0)).coerceAtLeast(0.1)
                val availRamGb = (memInfo.availMem.toDouble() / (1024.0 * 1024.0 * 1024.0)).coerceIn(0.0, totalRamGb)
                val usedRamPct = (((totalRamGb - availRamGb) / totalRamGb) * 100.0).roundToInt().coerceIn(0, 100)

                val stat = StatFs(Environment.getDataDirectory().path)
                val totalRomGb = ((stat.blockSizeLong * stat.blockCountLong).toDouble() / (1024.0 * 1024.0 * 1024.0)).coerceAtLeast(0.1)
                val availRomGb = ((stat.blockSizeLong * stat.availableBlocksLong).toDouble() / (1024.0 * 1024.0 * 1024.0)).coerceIn(0.0, totalRomGb)
                val usedRomPct = (((totalRomGb - availRomGb) / totalRomGb) * 100.0).roundToInt().coerceIn(0, 100)

                WidgetBackgroundOpacityHelper.applyBackground(context, views, R.id.widget_ram_rom_container, WidgetBackgroundOpacityHelper.BgStyle.DEFAULT)
                views.setTextViewText(R.id.widget_memory_title, "Bộ nhớ")
                views.setTextViewText(R.id.widget_ram_label, "RAM khả dụng")
                views.setTextViewText(
                    R.id.widget_ram_text,
                    String.format(Locale.US, "%.1f / %.0f GB (%d%% đã dùng)", availRamGb, totalRamGb, usedRamPct)
                )
                views.setProgressBar(R.id.widget_ram_progress, 100, usedRamPct, false)
                views.setViewVisibility(R.id.widget_ram_progress, android.view.View.VISIBLE)

                views.setTextViewText(R.id.widget_rom_label, "ROM khả dụng (/data)")
                views.setTextViewText(
                    R.id.widget_rom_text,
                    String.format(Locale.US, "%.1f / %.0f GB (%d%% đã dùng)", availRomGb, totalRomGb, usedRomPct)
                )
                views.setProgressBar(R.id.widget_rom_progress, 100, usedRomPct, false)
                views.setViewVisibility(R.id.widget_rom_progress, android.view.View.VISIBLE)
                views.setTextViewText(R.id.widget_memory_status, statusOverride ?: "")
                views.setTextViewText(
                    R.id.widget_memory_info,
                    "Thanh màu biểu thị phần đã dùng"
                )

                val boostIntent = Intent(context, MagicTuneMemoryWidgetProvider::class.java).apply {
                    action = ACTION_BOOST_RAM
                }
                val boostPi = PendingIntent.getBroadcast(
                    context,
                    appWidgetId + 5100,
                    boostIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_ram_rom_container, boostPi)
                appWidgetManager.updateAppWidget(appWidgetId, views)
            } catch (_: Throwable) {}
        }
    }
}
