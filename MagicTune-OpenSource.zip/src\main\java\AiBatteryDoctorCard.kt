package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.ai.AiAutopilotConfig
import com.example.core.ai.AiUltraPowerProfile
import com.example.core.ai.DrainRateAnalytics
import com.example.core.ai.PowerExecutionResult
import com.example.ui.theme.MagicAmberLight
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicCyanLight
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicEmeraldLight
import com.example.ui.theme.MagicPurple
import com.example.ui.theme.MagicPurpleLight
import com.example.ui.theme.MagicRose
import com.example.ui.theme.MagicRoseLight
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.MagicSurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun AiBatteryDoctorCard(
    activeProfile: AiUltraPowerProfile,
    autopilotConfig: AiAutopilotConfig,
    drainAnalytics: DrainRateAnalytics?,
    isExecutingPowerPlan: Boolean,
    executingLabel: String?,
    lastExecutionResult: PowerExecutionResult?,
    onActivateProfile: (AiUltraPowerProfile) -> Unit,
    onUpdateAutopilotRule: (String, Boolean) -> Unit,
    onToggleAllAutopilot: (Boolean) -> Unit
) {
    var showAutopilotPanel by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("ai_battery_doctor_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0A1326)),
        border = BorderStroke(
            width = 1.2.dp,
            brush = Brush.horizontalGradient(
                listOf(
                    MagicEmerald.copy(alpha = 0.85f),
                    MagicCyan.copy(alpha = 0.78f),
                    MagicPurple.copy(alpha = 0.72f)
                )
            )
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // 1. HEADER Ô #42 — GỌN GÀNG, RÕ SỐ THỨ TỰ
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(MagicEmerald.copy(alpha = 0.3f), MagicCyan.copy(alpha = 0.3f))
                                )
                            )
                            .border(1.dp, MagicEmerald.copy(alpha = 0.7f), RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "Siêu tiết kiệm pin",
                            tint = MagicEmeraldLight,
                            modifier = Modifier.size(19.dp)
                        )
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(5.dp))
                                    .background(MagicEmerald.copy(alpha = 0.22f))
                                    .border(0.8.dp, MagicEmerald.copy(alpha = 0.6f), RoundedCornerShape(5.dp))
                                    .padding(horizontal = 6.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = "Ô #42",
                                    color = MagicEmeraldLight,
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                            Text(
                                text = "Siêu Tiết Kiệm Pin & Autopilot 24/7",
                                color = Color.White,
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Black,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = "Bảo vệ trợ năng ngầm",
                                tint = MagicEmeraldLight,
                                modifier = Modifier.size(12.dp)
                            )
                            Text(
                                text = "Bảo vệ 100% Trợ năng ngầm • Không ảnh hưởng thông báo",
                                color = MagicEmeraldLight,
                                fontSize = 9.8.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }

            // 2. TỐC ĐỘ XẢ PIN THỰC TẾ (SÁNG MÀN / TẮT MÀN / ĐÃ CỨU)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val onRate = drainAnalytics?.screenOnDrainPctPerHour?.takeIf { it.isFinite() && it > 0.0 }
                val offRate = drainAnalytics?.screenOffDrainPctPerHour?.takeIf { it.isFinite() && it >= 0.0 }
                val onSrc = drainAnalytics?.screenOnSource.orEmpty()
                val offSrc = drainAnalytics?.screenOffSource.orEmpty()
                val savedMah = drainAnalytics?.estimatedSavedMah ?: 0
                val savesCount = drainAnalytics?.autopilotSavesCount ?: 0
                val onPrefix = if (onSrc == "Ước tính") "~" else ""
                val offPrefix = if (offSrc == "Ước tính nền") "~" else ""

                DrainMetricChip(
                    modifier = Modifier.weight(1f),
                    label = if (onSrc.isNotBlank()) "Sáng màn • $onSrc" else "Sáng màn",
                    value = onRate?.let { String.format(Locale.US, "%s%.1f%%/h", onPrefix, it) } ?: "Đang nạp...",
                    color = if (onRate != null && onRate > 12.0) MagicRoseLight else MagicCyanLight
                )
                DrainMetricChip(
                    modifier = Modifier.weight(1f),
                    label = if (offSrc.isNotBlank()) "Tắt màn • $offSrc" else "Tắt màn chờ",
                    value = offRate?.let { String.format(Locale.US, "%s%.1f%%/h", offPrefix, it) } ?: "Đang nạp...",
                    color = if (offRate != null && offRate > 2.5) MagicAmberLight else MagicEmeraldLight
                )
                DrainMetricChip(
                    modifier = Modifier.weight(1f),
                    label = "Đã cứu pin",
                    value = if (savedMah > 0) "~${savedMah}mAh ($savesCount)" else "Sẵn sàng",
                    color = MagicPurpleLight
                )
            }

            // 3. BỘ 3 CẤP ĐỘ SIÊU TIẾT KIỆM PIN (1 CHẠM MƯỢT KHÔNG ĐƠ)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0E1B33))
                    .border(1.dp, MagicBorder.copy(alpha = 0.72f), RoundedCornerShape(12.dp))
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "1. Chọn Cấp Độ Tiết Kiệm (1 Chạm)",
                        color = MagicEmeraldLight,
                        fontSize = 11.2.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    if (activeProfile != AiUltraPowerProfile.NONE) {
                        Text(
                            text = "↺ Mặc định",
                            color = MagicCyanLight,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .clickable(enabled = !isExecutingPowerPlan) {
                                    onActivateProfile(AiUltraPowerProfile.NONE)
                                }
                                .padding(horizontal = 6.dp, vertical = 4.dp)
                                .testTag("ai_ultra_power_restore_btn")
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    UltraPowerPresetTile(
                        modifier = Modifier
                            .weight(1f)
                            .testTag("ai_ultra_power_balanced_btn"),
                        title = "AI 24/7",
                        badge = "-25~35%",
                        subtitle = "Mượt LTPO • Đủ TB",
                        isActive = activeProfile == AiUltraPowerProfile.BALANCED_24_7,
                        accentColor = MagicEmerald,
                        enabled = !isExecutingPowerPlan,
                        onClick = { onActivateProfile(AiUltraPowerProfile.BALANCED_24_7) }
                    )
                    UltraPowerPresetTile(
                        modifier = Modifier
                            .weight(1f)
                            .testTag("ai_ultra_power_extreme_btn"),
                        title = "Cực Đại",
                        badge = "-40~55%",
                        subtitle = "60Hz + Doze sâu",
                        isActive = activeProfile == AiUltraPowerProfile.EXTREME_ULTRA,
                        accentColor = MagicCyan,
                        enabled = !isExecutingPowerPlan,
                        onClick = { onActivateProfile(AiUltraPowerProfile.EXTREME_ULTRA) }
                    )
                    UltraPowerPresetTile(
                        modifier = Modifier
                            .weight(1f)
                            .testTag("ai_ultra_power_survival_btn"),
                        title = "Sinh Tồn",
                        badge = "-55~70%",
                        subtitle = "Tối đa thời lượng",
                        isActive = activeProfile == AiUltraPowerProfile.SURVIVAL_MAX,
                        accentColor = MagicPurple,
                        enabled = !isExecutingPowerPlan,
                        onClick = { onActivateProfile(AiUltraPowerProfile.SURVIVAL_MAX) }
                    )
                }

                if (activeProfile != AiUltraPowerProfile.NONE) {
                    Text(
                        text = "✓ Đang bật: ${activeProfile.label}",
                        color = MagicEmeraldLight,
                        fontSize = 10.2.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (isExecutingPowerPlan && !executingLabel.isNullOrBlank()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CircularProgressIndicator(
                            color = MagicEmeraldLight,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(15.dp)
                        )
                        Text(
                            text = executingLabel,
                            color = MagicEmeraldLight,
                            fontSize = 10.8.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                if (lastExecutionResult != null) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(9.dp))
                            .background(MagicEmerald.copy(alpha = 0.13f))
                            .border(0.8.dp, MagicEmerald.copy(alpha = 0.45f), RoundedCornerShape(9.dp))
                            .padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Text(
                            text = lastExecutionResult.summary,
                            color = MagicEmeraldLight,
                            fontSize = 10.6.sp,
                            fontWeight = FontWeight.Bold
                        )
                        val safeBeforeT = if (lastExecutionResult.beforeTempC.isFinite()) lastExecutionResult.beforeTempC else 0.0
                        val safeAfterT = if (lastExecutionResult.afterTempC.isFinite()) lastExecutionResult.afterTempC else 0.0
                        Text(
                            text = String.format(
                                Locale.US,
                                "Pin %.1f°C → %.1f°C • RAM trống %dMB → %dMB",
                                safeBeforeT,
                                safeAfterT,
                                lastExecutionResult.beforeRamMb,
                                lastExecutionResult.afterRamMb
                            ),
                            color = TextSecondary,
                            fontSize = 9.5.sp
                        )
                    }
                }
            }

            // 4. BẢNG TỰ ĐỘNG 24/7 (4 LÁ CHẮN — THU GỌN MẶC ĐỊNH CHO ĐỠ RỐI)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0D172B))
                    .border(
                        1.dp,
                        if (autopilotConfig.isAnyEnabled) MagicCyan.copy(alpha = 0.55f) else MagicBorder.copy(alpha = 0.6f),
                        RoundedCornerShape(12.dp)
                    )
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showAutopilotPanel = !showAutopilotPanel },
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "2. Tự Động Tiết Kiệm 24/7 (${autopilotConfig.activeRuleCount}/3)",
                            color = if (autopilotConfig.isAnyEnabled) MagicCyanLight else Color.White,
                            fontSize = 11.4.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "Tự kích hoạt theo sự kiện tắt màn / đêm / pin yếu (0% chạy thừa)",
                            color = TextSecondary,
                            fontSize = 9.5.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(7.dp))
                                .background(
                                    if (autopilotConfig.activeRuleCount == 3) MagicRose.copy(alpha = 0.22f)
                                    else MagicEmerald.copy(alpha = 0.22f)
                                )
                                .clickable {
                                    onToggleAllAutopilot(autopilotConfig.activeRuleCount < 3)
                                }
                                .padding(horizontal = 8.dp, vertical = 5.dp)
                                .testTag("ai_autopilot_toggle_all_btn")
                        ) {
                            Text(
                                text = if (autopilotConfig.activeRuleCount == 3) "Tắt hết" else "Bật 3/3",
                                color = if (autopilotConfig.activeRuleCount == 3) MagicRoseLight else MagicEmeraldLight,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Icon(
                            imageVector = if (showAutopilotPanel) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = if (showAutopilotPanel) "Thu gọn Tự động 24/7" else "Mở Tự động 24/7",
                            tint = MagicCyanLight,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                if (showAutopilotPanel) {
                    AutopilotRuleSwitchRow(
                        title = "1) Ngủ Đông Sau 45s Tắt Màn",
                        subtitle = "Đóng băng app nền khi tắt màn, mở sáng màn tự nhả tức thì",
                        checked = autopilotConfig.screenOffDeepDozeEnabled,
                        testTagName = "ap_switch_screen_off_doze",
                        onCheckedChange = { onUpdateAutopilotRule("screen_off_doze", it) }
                    )
                    AutopilotRuleSwitchRow(
                        title = "2) Chống Tụt Pin Đêm (23:00–06:30)",
                        subtitle = "Ép Deep Doze sâu qua đêm, chỉ tụt ~1–3%",
                        checked = autopilotConfig.nightUltraStandbyEnabled,
                        testTagName = "ap_switch_night_standby",
                        onCheckedChange = { onUpdateAutopilotRule("night_standby", it) }
                    )
                    AutopilotRuleSwitchRow(
                        title = "3) Tự Bật Sinh Tồn Khi Pin ≤ 20%",
                        subtitle = "Kéo dài giờ sử dụng khi pin yếu, sạc ≥30% tự khôi phục",
                        checked = autopilotConfig.lowBatterySurvivalEnabled,
                        testTagName = "ap_switch_low_batt_survival",
                        onCheckedChange = { onUpdateAutopilotRule("low_batt_survival", it) }
                    )
                    Text(
                        text = "4) Hạ nhiệt tự động nền đã tắt. Dùng nút ADB theo yêu cầu để bật Tiết kiệm pin Android.",
                        color = TextMuted,
                        fontSize = 10.sp,
                        lineHeight = 14.sp
                    )

                    val logs = drainAnalytics?.recentLogs.orEmpty()
                    if (logs.isNotEmpty()) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF081020))
                                .padding(8.dp),
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Text(
                                text = "Nhật ký cứu pin gần đây:",
                                color = MagicCyanLight,
                                fontSize = 9.6.sp,
                                fontWeight = FontWeight.Bold
                            )
                            logs.take(3).forEach { logLine ->
                                Text(
                                    text = logLine,
                                    color = TextSecondary,
                                    fontSize = 9.4.sp,
                                    lineHeight = 13.sp,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DrainMetricChip(
    modifier: Modifier,
    label: String,
    value: String,
    color: Color
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF081020))
            .border(0.7.dp, color.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
            .padding(horizontal = 7.dp, vertical = 5.dp),
        verticalArrangement = Arrangement.spacedBy(1.dp)
    ) {
        Text(
            text = label,
            color = TextMuted,
            fontSize = 8.6.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = value,
            color = color,
            fontSize = 10.5.sp,
            fontWeight = FontWeight.Black,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun AutopilotRuleSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    testTagName: String,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(9.dp))
            .background(if (checked) MagicCyan.copy(alpha = 0.1f) else Color(0xFF0A1222))
            .border(
                0.7.dp,
                if (checked) MagicCyan.copy(alpha = 0.45f) else MagicBorder.copy(alpha = 0.5f),
                RoundedCornerShape(9.dp)
            )
            .clickable { onCheckedChange(!checked) }
            .padding(horizontal = 9.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(1.dp)
        ) {
            Text(
                text = title,
                color = if (checked) Color.White else Color.White.copy(alpha = 0.88f),
                fontSize = 10.8.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = subtitle,
                color = TextSecondary,
                fontSize = 9.4.sp,
                lineHeight = 12.5.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(testTagName),
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = MagicEmerald,
                uncheckedThumbColor = TextSecondary,
                uncheckedTrackColor = MagicSurfaceCard
            )
        )
    }
}

@Composable
private fun UltraPowerPresetTile(
    modifier: Modifier,
    title: String,
    badge: String,
    subtitle: String,
    isActive: Boolean,
    accentColor: Color,
    enabled: Boolean,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier
            .heightIn(min = 68.dp)
            .clip(RoundedCornerShape(11.dp))
            .background(if (isActive) accentColor.copy(alpha = 0.24f) else MagicSurfaceDark)
            .border(
                width = if (isActive) 1.5.dp else 0.9.dp,
                color = if (isActive) accentColor else MagicBorder.copy(alpha = 0.7f),
                shape = RoundedCornerShape(11.dp)
            )
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 7.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                color = Color.White,
                fontSize = 10.8.sp,
                fontWeight = FontWeight.Black,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            if (isActive) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Đang bật",
                    tint = accentColor,
                    modifier = Modifier.size(13.dp)
                )
            }
        }
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(5.dp))
                .background(accentColor.copy(alpha = 0.2f))
                .padding(horizontal = 5.dp, vertical = 1.dp)
        ) {
            Text(
                text = badge,
                color = if (isActive) Color.White else accentColor,
                fontSize = 9.sp,
                fontWeight = FontWeight.Black
            )
        }
        Text(
            text = subtitle,
            color = if (isActive) Color.White.copy(alpha = 0.88f) else TextSecondary,
            fontSize = 9.sp,
            lineHeight = 12.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
