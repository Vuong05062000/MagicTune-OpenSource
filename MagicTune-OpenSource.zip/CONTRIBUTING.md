# Contributing to MagicTune Tool

Thank you for helping improve MagicTune Tool!

## Guidelines

1. **Fork & Branch**: Create a descriptive branch from `main` (e.g. `fix/widget-height` or `feat/new-oem-preset`).
2. **No Secrets**: Never commit API keys, `google-services.json`, `private.properties`, `keystore.properties`, or signing certificates (`.p12` / `.jks`).
3. **Verify Before PR**:
   - Run static layout checks: `node tests/widget-layouts.test.cjs`
   - Run a debug build: `./gradlew assembleDebug` (or `gradlew.bat assembleDebug` on Windows)
4. **Keep Changes Focused**: Match existing Kotlin / Jetpack Compose conventions and keep UI text clear.
