package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.core.ai.PersonalAi
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun PersonalApiScreen() {
    val context = LocalContext.current.applicationContext
    val scope = rememberCoroutineScope()
    var accounts by remember { mutableStateOf(emptyList<PersonalAi.Account>()) }
    var provider by remember { mutableStateOf(PersonalAi.Provider.GEMINI) }
    var name by remember { mutableStateOf("") }
    var secret by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<String?>(null) }
    var expanded by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<String?>(null) }
    var models by remember { mutableStateOf(emptyList<PersonalAi.Model>()) }
    var query by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var revision by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        try { accounts = withContext(Dispatchers.IO) { PersonalAi.accounts(context) } }
        catch (_: Exception) { message = "Không mở được kho khóa mã hóa trên thiết bị." }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("API cá nhân", style = MaterialTheme.typography.headlineSmall)
            Text("Lưu khóa trên máy bằng Android Keystore. Chọn model riêng cho chat, đọc ảnh và tạo ảnh. Khi khóa cá nhân thất bại, app dùng luồng khóa chung hiện có. Lời gọi API có thể dùng hạn mức hoặc tính phí tài khoản của bạn.")
        }
        item {
            Card {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box {
                        OutlinedButton(onClick = { expanded = true }, enabled = !busy && editing == null) { Text(provider.title) }
                        DropdownMenu(expanded, onDismissRequest = { expanded = false }) {
                            PersonalAi.Provider.entries.forEach { source ->
                                DropdownMenuItem(text = { Text(source.title) }, onClick = {
                                    provider = source
                                    expanded = false
                                })
                            }
                        }
                    }
                    OutlinedTextField(name, { name = it }, label = { Text("Tên dễ nhớ") },
                        singleLine = true, modifier = Modifier.fillMaxWidth(), enabled = !busy)
                    OutlinedTextField(secret, { secret = it }, label = { Text("API key") },
                        visualTransformation = PasswordVisualTransformation(), singleLine = true,
                        modifier = Modifier.fillMaxWidth(), enabled = !busy)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(enabled = !busy && secret.isNotBlank(), onClick = {
                            busy = true
                            scope.launch {
                                try {
                                    val id = withContext(Dispatchers.IO) { PersonalAi.save(context, provider, name, secret, editing) }
                                    secret = ""
                                    name = ""
                                    editing = null
                                    accounts = withContext(Dispatchers.IO) { PersonalAi.accounts(context) }
                                    selected = id
                                    models = emptyList()
                                    models = PersonalAi.refresh(context, id)
                                    message = PersonalAi.status(context, id)
                                } catch (e: CancellationException) { throw e }
                                catch (e: Exception) { message = e.message ?: "Không lưu hoặc tải được danh sách model." }
                                finally { busy = false }
                            }
                        }) { Text(if (editing == null) "Lưu và tải model" else "Cập nhật khóa") }
                        if (editing != null) TextButton(enabled = !busy, onClick = { editing = null; secret = ""; name = "" }) { Text("Hủy sửa") }
                    }
                    TextButton(enabled = !busy, onClick = {
                        busy = true
                        scope.launch {
                            try {
                                withContext(Dispatchers.IO) {
                                    val raw = com.example.core.license.LicenseManager.getUserCustomMagicLiveKey(context)
                                    val existing = PersonalAi.accounts(context)
                                    raw.split(Regex("""[\s,;]+""")).distinct().forEach { key ->
                                        val source = when {
                                            key.startsWith("AIza") -> PersonalAi.Provider.GEMINI
                                            key.startsWith("gsk_") -> PersonalAi.Provider.GROQ
                                            else -> null
                                        }
                                        if (source != null && existing.none { it.key == key }) {
                                            PersonalAi.save(context, source, source.title + " đã lưu", key)
                                        }
                                    }
                                }
                                accounts = withContext(Dispatchers.IO) { PersonalAi.accounts(context) }
                                message = "Đã nhập khóa Gemini/Groq từ thiết lập cũ. Chọn tài khoản để tải model."
                            } catch (_: Exception) { message = "Không nhập được khóa cũ." }
                            finally { busy = false }
                        }
                    }) { Text("Nhập khóa cá nhân từ thiết lập cũ") }
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                PersonalAi.Use.entries.forEach { use ->
                    val choice = remember(revision, accounts) { PersonalAi.choice(context, use) }
                    Text("${use.title} • " + (choice?.let { c ->
                        accounts.firstOrNull { it.id == c.account }?.let { "${it.name} / ${c.model}" }
                    } ?: "Tự động dùng hệ thống"))
                    if (choice != null) TextButton(onClick = {
                        PersonalAi.clearChoice(context, use)
                        revision++
                    }) { Text("Dùng hệ thống cho ${use.title.lowercase()}") }
                }
            }
        }
        if (message.isNotBlank()) item { Text(message) }
        if (busy) item { LinearProgressIndicator(modifier = Modifier.fillMaxWidth()) }
        items(accounts, key = { it.id }) { account ->
            Card {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Text("${account.name} • ${account.provider.title}")
                    Text("••••${account.key.takeLast(4)}")
                    Text(PersonalAi.status(context, account.id))
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(enabled = !busy, onClick = {
                            selected = account.id
                            models = PersonalAi.cachedModels(context, account.id)
                            query = ""
                            busy = true
                            scope.launch {
                                try {
                                    models = PersonalAi.refresh(context, account.id)
                                    message = PersonalAi.status(context, account.id)
                                } catch (e: CancellationException) { throw e }
                                catch (e: Exception) { message = e.message ?: "Lỗi tải model" }
                                finally { busy = false }
                            }
                        }) { Text("Model / Kiểm tra") }
                        TextButton(enabled = !busy, onClick = {
                            editing = account.id
                            provider = account.provider
                            name = account.name
                            secret = ""
                            message = "Nhập khóa thay thế trong biểu mẫu phía trên."
                        }) { Text("Đổi khóa") }
                        TextButton(enabled = !busy, onClick = {
                            busy = true
                            scope.launch {
                                try {
                                    withContext(Dispatchers.IO) { PersonalAi.delete(context, account.id) }
                                    accounts = withContext(Dispatchers.IO) { PersonalAi.accounts(context) }
                                    if (selected == account.id) { selected = null; models = emptyList() }
                                    if (editing == account.id) { editing = null; secret = ""; name = "" }
                                    revision++
                                } catch (e: CancellationException) { throw e }
                                catch (_: Exception) { message = "Không xóa được tài khoản." }
                                finally { busy = false }
                            }
                        }) { Text("Xóa") }
                    }
                }
            }
        }
        if (selected != null) item {
            Text("Model • ${accounts.firstOrNull { it.id == selected }?.name.orEmpty()}")
            Text("Sắp theo ngày do API cung cấp, mới trước. Model thiếu ngày nằm sau và được sắp theo phiên bản/tên; thứ tự này không xác nhận ngày phát hành.")
            Text("Chọn đúng chức năng model hỗ trợ. Nếu model từ chối ảnh hoặc không có quyền gọi, app tự dùng khóa chung. Pollinations ở đây dùng cho tạo ảnh.")
            OutlinedTextField(query, { query = it }, label = { Text("Tìm model") }, modifier = Modifier.fillMaxWidth())
        }
        items(models.filter { it.id.contains(query, true) || it.title.contains(query, true) }, key = { it.id }) { model ->
            val account = accounts.firstOrNull { it.id == selected }
            if (account != null) Card {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Text(model.title.ifBlank { model.id })
                    Text(model.id)
                    if (model.date > 0) Text(java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date(model.date)))
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        val uses = if (account.provider == PersonalAi.Provider.POLLINATIONS) listOf(PersonalAi.Use.IMAGE)
                            else if (account.provider == PersonalAi.Provider.GROQ)
                                listOf(PersonalAi.Use.CHAT, PersonalAi.Use.VISION)
                            else PersonalAi.Use.entries
                        uses.forEach { use ->
                            TextButton(enabled = !busy, onClick = {
                                PersonalAi.choose(context, use, account.id, model.id)
                                revision++
                                message = "Đã chọn ${model.id} cho ${use.title.lowercase()}."
                            }) { Text(use.title) }
                        }
                    }
                }
            }
        }
    }
}
