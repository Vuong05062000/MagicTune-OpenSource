package com.example.core.adb

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import java.io.ByteArrayOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.MulticastSocket
import java.net.NetworkInterface
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executor
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

data class AdbNsdState(
    val isScanning: Boolean = false,
    val pairingPort: Int? = null,
    val pairingHost: String? = null,
    val pairingServiceName: String? = null,
    val connectPort: Int? = null,
    val connectHost: String? = null,
    val connectServiceName: String? = null,
    val statusText: String = "Chưa quét dịch vụ mDNS"
)

/**
 * Module NsdManager + Raw mDNS Hybrid Radar (hỗ trợ chuẩn Android 11 -> 17 & Honor MagicOS 9/10/11):
 * 1. `_adb-tls-pairing._tcp` -> Tự động phát hiện và điền cổng ghép nối (Pairing Port) 5 số khi mở hộp thoại mã 6 số.
 * 2. `_adb-tls-connect._tcp` -> Tự động phát hiện cổng kết nối chính (Connect Port) 5 số khi bật Gỡ lỗi qua Wi-Fi.
 *
 * Cơ chế 3 lớp song song giúp bắt cổng tức thì (< 200ms) ngay cả khi MagicOS/Android 15-17 bóp NsdManager nền:
 * - Lớp 1: NsdManager.discoverServices + NsdManager.registerServiceInfoCallback (API 34+) / resolveService (API < 34) với mutex tách biệt giữa pairing & connect.
 * - Lớp 2: Raw UDP Multicast mDNS listener (224.0.0.251:5353, SO_REUSEADDR) đọc trực tiếp gói SRV từ mdnsd.
 * - Lớp 3: Active mDNS PTR QU query (unicast-response) gửi định kỳ trong phiên ghép nối để mdnsd trả thẳng cổng 5 số về socket cục bộ.
 */
class AdbNsdScanner(private val context: Context) {

    companion object {
        private const val TAG = "AdbNsdScanner"
        const val SERVICE_TYPE_PAIRING = "_adb-tls-pairing._tcp"
        const val SERVICE_TYPE_CONNECT = "_adb-tls-connect._tcp"
        private const val MDNS_MULTICAST_ADDR = "224.0.0.251"
        private const val MDNS_PORT = 5353

        @Volatile
        private var instance: AdbNsdScanner? = null

        fun getInstance(context: Context): AdbNsdScanner {
            return instance ?: synchronized(this) {
                instance ?: AdbNsdScanner(context.applicationContext).also { instance = it }
            }
        }
    }

    private val nsdManager: NsdManager? by lazy {
        context.getSystemService(Context.NSD_SERVICE) as? NsdManager
    }

    private val wifiManager: WifiManager? by lazy {
        context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
    }

    private var multicastLock: WifiManager.MulticastLock? = null

    @Volatile
    private var isMulticastLockHeld: Boolean = false

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    // Chỉ dùng cho 1 lần registerServiceInfoCallback: single-thread executor (daemon) là đủ,
    // tránh cached thread pool để lại nhiều thread rảnh và chặn tiến trình thoát.
    private val nsdExecutor: Executor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "magictune-nsd-callback").apply { isDaemon = true }
    }

    private val _state = MutableStateFlow(AdbNsdState())
    val state: StateFlow<AdbNsdState> = _state.asStateFlow()

    private val isPairingDiscoveryActive = AtomicBoolean(false)
    private val isConnectDiscoveryActive = AtomicBoolean(false)

    private var pairingDiscoveryListener: NsdManager.DiscoveryListener? = null
    private var connectDiscoveryListener: NsdManager.DiscoveryListener? = null

    private val pairingResolveMutex = Mutex()
    private val connectResolveMutex = Mutex()

    // Lưu ServiceInfoCallback trên Android 14+ (API 34+) để hủy đăng ký sạch sẽ khi mất dịch vụ hoặc dừng quét
    private val activePairingCallbacks = ConcurrentHashMap<String, Any>()
    private val activeConnectCallbacks = ConcurrentHashMap<String, Any>()

    private var rawMdnsMulticastJob: Job? = null
    private var rawMdnsQuerierJob: Job? = null
    private var autoStopJob: Job? = null

    @Volatile
    private var lastPairingDiscoveredAtMs: Long = 0L

    var onPairingPortDiscovered: ((port: Int, host: String) -> Unit)? = null
    var onConnectPortDiscovered: ((port: Int, host: String) -> Unit)? = null

    @Volatile
    var lastKnownConnectPort: Int? = null
        private set

    @Volatile
    var lastKnownPairingPort: Int? = null
        private set

    @Volatile
    var lastKnownPairingHost: String? = null
        private set

    @Volatile
    var isPairingUiActive: Boolean = false

    @Volatile
    private var lastConnectDiscoveredAtMs: Long = 0L

    private val nsdPrefs by lazy {
        context.applicationContext.getSharedPreferences("magictune_nsd_cache", Context.MODE_PRIVATE)
    }

    fun getBestPairingPort(fallbackPort: Int = 0): Int? {
        val devOn = try {
            android.provider.Settings.Global.getInt(context.contentResolver, android.provider.Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1
        } catch (_: Exception) { false }
        if (!devOn) {
            lastKnownPairingPort = null
            _state.value = _state.value.copy(pairingPort = null)
            return null
        }
        _state.value.pairingPort?.takeIf { it in 1..65535 }?.let { return it }
        if (fallbackPort in 1..65535) return fallbackPort
        val pairingRecent = (System.currentTimeMillis() - lastPairingDiscoveredAtMs) < 60_000L
        if (pairingRecent) {
            lastKnownPairingPort?.takeIf { it in 1..65535 }?.let { return it }
        }
        val savedPort = nsdPrefs.getInt("last_pairing_port", 0)
        val savedTime = nsdPrefs.getLong("last_pairing_time", 0L)
        if (savedPort in 1..65535 && (System.currentTimeMillis() - savedTime) < 60_000L) {
            return savedPort
        }
        return null
    }

    fun getBestPairingHost(): String? {
        _state.value.pairingHost?.takeIf { it.isNotBlank() && it != "0.0.0.0" }?.let { return it }
        lastKnownPairingHost?.takeIf { it.isNotBlank() && it != "0.0.0.0" }?.let { return it }
        val savedHost = nsdPrefs.getString("last_pairing_host", null)
        if (!savedHost.isNullOrBlank() && savedHost != "0.0.0.0") return savedHost
        return null
    }

    fun getBestConnectHost(): String? {
        _state.value.connectHost?.takeIf { it.isNotBlank() && it != "0.0.0.0" && !it.contains(":") }?.let { return it }
        val savedHost = nsdPrefs.getString("last_connect_host", null)
        if (!savedHost.isNullOrBlank() && savedHost != "0.0.0.0" && !savedHost.contains(":")) return savedHost
        return null
    }

    fun getRecentConnectPorts(): List<Int> {
        val raw = nsdPrefs.getString("recent_connect_ports", "").orEmpty()
        val pairingNow = _state.value.pairingPort
        val out = LinkedHashSet<Int>()
        _state.value.connectPort?.takeIf { it in 1024..65535 && it != pairingNow }?.let { out.add(it) }
        readSystemAdbTlsPort()?.takeIf { it in 1024..65535 && it != pairingNow }?.let { out.add(it) }
        raw.split(',')
            .mapNotNull { it.trim().toIntOrNull() }
            .filter { it in 1024..65535 && it != pairingNow }
            .forEach { out.add(it) }
        return out.toList().take(4)
    }

    private fun recordRecentConnectPort(port: Int, hostAddress: String) {
        if (port !in 1024..65535) return
        try {
            val currentList = nsdPrefs.getString("recent_connect_ports", "").orEmpty()
                .split(',')
                .mapNotNull { it.trim().toIntOrNull() }
                .filter { it in 1024..65535 && it != port }
            val updated = (listOf(port) + currentList).take(4).joinToString(",")
            nsdPrefs.edit()
                .putInt("last_connect_port", port)
                .putString("last_connect_host", hostAddress)
                .putLong("last_connect_time", System.currentTimeMillis())
                .putString("recent_connect_ports", updated)
                .apply()
        } catch (_: Throwable) {}
    }

    private val systemPropertiesGetMethod by lazy {
        runCatching {
            val spClass = Class.forName("android.os.SystemProperties")
            spClass.getMethod("get", String::class.java, String::class.java)
        }.getOrNull()
    }

    fun readSystemAdbTlsPort(): Int? {
        try {
            val method = systemPropertiesGetMethod ?: return null
            val raw = (method.invoke(null, "service.adb.tls.port", "") as? String)?.trim().orEmpty()
            val port = raw.toIntOrNull()
            if (port != null && port in 1024..65535) return port
        } catch (_: Throwable) {}
        return null
    }

    fun getBestConnectPort(): Int? {
        val devOn = try {
            android.provider.Settings.Global.getInt(context.contentResolver, android.provider.Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1
        } catch (_: Exception) { false }
        if (!devOn) {
            lastKnownConnectPort = null
            _state.value = _state.value.copy(connectPort = null)
            return null
        }
        val adbWifiOn = try {
            android.provider.Settings.Global.getInt(context.contentResolver, "adb_wifi_enabled", 0) == 1
        } catch (_: Exception) { false }
        if (!adbWifiOn) {
            lastKnownConnectPort = null
            _state.value = _state.value.copy(connectPort = null)
            return null
        }
        val currentPairing = _state.value.pairingPort
        readSystemAdbTlsPort()?.let { sysPort ->
            if (sysPort != currentPairing) {
                lastKnownConnectPort = sysPort
                lastConnectDiscoveredAtMs = System.currentTimeMillis()
                if (_state.value.connectPort != sysPort) {
                    _state.value = _state.value.copy(connectPort = sysPort)
                }
                return sysPort
            }
        }
        _state.value.connectPort?.takeIf { it in 1..65535 && it != currentPairing }?.let { return it }
        lastKnownConnectPort?.takeIf { it in 1..65535 && it != currentPairing }?.let { return it }
        val savedConnectPort = nsdPrefs.getInt("last_connect_port", 0)
        val savedConnectTime = nsdPrefs.getLong("last_connect_time", 0L)
        if (savedConnectPort in 1..65535 &&
            savedConnectPort != currentPairing &&
            (System.currentTimeMillis() - savedConnectTime) < 15 * 60_000L
        ) {
            return savedConnectPort
        }
        return null
    }

    suspend fun discoverConnectPortWithin(timeoutMs: Long = 3500L): Int? {
        getBestConnectPort()?.takeIf { it in 1024..65535 }?.let { return it }
        refreshConnectDiscovery()
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            delay(120L)
            getBestConnectPort()?.takeIf { it in 1024..65535 }?.let { return it }
        }
        return null
    }

    suspend fun discoverPairingPortWithin(timeoutMs: Long = 2000L): Int? {
        getBestPairingPort()?.takeIf { it in 1024..65535 }?.let { return it }
        refreshPairingDiscovery(clearPreviousPort = false)
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            delay(100L)
            getBestPairingPort()?.takeIf { it in 1024..65535 }?.let { return it }
        }
        return null
    }

    /**
     * Bắt đầu lắng nghe đồng thời cả _adb-tls-pairing._tcp và _adb-tls-connect._tcp.
     */
    fun startDiscovery() {
        val devOn = try {
            android.provider.Settings.Global.getInt(context.contentResolver, android.provider.Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1
        } catch (_: Exception) { false }
        val adbWifiOn = try {
            android.provider.Settings.Global.getInt(context.contentResolver, "adb_wifi_enabled", 0) == 1
        } catch (_: Exception) { false }
        if (!devOn || !adbWifiOn) {
            stopDiscovery(updateStatusText = false)
            return
        }

        readSystemAdbTlsPort()?.let { sysPort ->
            lastKnownConnectPort = sysPort
            if (_state.value.connectPort == null) {
                _state.value = _state.value.copy(connectPort = sysPort)
            }
        }

        val manager = nsdManager
        val isPairingActive = AdbPairingNotificationManager.isNotificationPairingActive || isPairingUiActive
        if (isPairingActive) {
            acquireMulticastLock(forceForPairing = true)
        }

        _state.value = _state.value.copy(
            isScanning = true,
            statusText = if (manager != null) {
                "Đang lắng nghe _adb-tls-pairing._tcp & _adb-tls-connect._tcp..."
            } else {
                "Đang quét mDNS trực tiếp _adb-tls-pairing._tcp..."
            }
        )

        if (manager != null) {
            if (isPairingActive) {
                startPairingDiscovery(manager)
            }
            startConnectDiscovery(manager)
        }
        if (isPairingActive) {
            startRawMdnsRadar()
        }
        scheduleAutoStop(6_000L)
    }

    /**
     * Bắt đầu quét riêng kênh connect (_adb-tls-connect._tcp) trên luồng nền cho Tab Kết Nối.
     * TUYỆT ĐỐI không chiếm MulticastLock và không khởi chạy raw UDP radar để bảo toàn 100% pin và không đơ UI.
     */
    fun startConnectDiscoveryOnly() {
        val devOn = try {
            android.provider.Settings.Global.getInt(context.contentResolver, android.provider.Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1
        } catch (_: Exception) { false }
        val adbWifiOn = try {
            android.provider.Settings.Global.getInt(context.contentResolver, "adb_wifi_enabled", 0) == 1
        } catch (_: Exception) { false }
        if (!devOn || !adbWifiOn) {
            stopDiscovery(updateStatusText = false)
            return
        }

        val manager = nsdManager ?: return
        if (isConnectDiscoveryActive.get()) return
        scope.launch {
            readSystemAdbTlsPort()?.let { sysPort ->
                lastKnownConnectPort = sysPort
                if (_state.value.connectPort == null) {
                    _state.value = _state.value.copy(connectPort = sysPort)
                }
            }
            startConnectDiscovery(manager)
            scheduleAutoStop(5_000L)
        }
    }

    /**
     * Làm mới riêng kênh bắt cổng mã 6 số (_adb-tls-pairing._tcp) khi người dùng bấm mở Cài đặt Gỡ lỗi WLAN.
     * Hủy listener cũ nếu đã chạy lâu và mở lại ngay phiên NSD + Raw mDNS mới để bắt tức thì trên MagicOS 9/10/11.
     */
    fun refreshPairingDiscovery(clearPreviousPort: Boolean = false) {
        val devOn = try {
            android.provider.Settings.Global.getInt(context.contentResolver, android.provider.Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1
        } catch (_: Exception) { false }
        if (!devOn) {
            stopDiscovery(updateStatusText = false)
            return
        }

        if (clearPreviousPort) {
            lastKnownPairingPort = null
            lastPairingDiscoveredAtMs = 0L
            _state.value = _state.value.copy(
                pairingPort = null,
                pairingServiceName = null
            )
        }

        val manager = nsdManager
        if (manager != null) {
            if (isPairingDiscoveryActive.compareAndSet(true, false)) {
                try {
                    pairingDiscoveryListener?.let { manager.stopServiceDiscovery(it) }
                } catch (_: Throwable) {}
            }
            pairingDiscoveryListener = null
            unregisterServiceCallbacks(manager, activePairingCallbacks)
        }

        val isPairingActive = AdbPairingNotificationManager.isNotificationPairingActive || isPairingUiActive
        if (isPairingActive) {
            acquireMulticastLock(forceForPairing = true)
        }
        _state.value = _state.value.copy(
            isScanning = true,
            statusText = "Đang lắng nghe _adb-tls-pairing._tcp..."
        )
        if (manager != null) {
            scope.launch {
                // Đợi nhẹ 120ms để NsdManager nhả socket listener cũ hoàn toàn trên Android 15-17
                delay(120L)
                startPairingDiscovery(manager)
            }
        }
        if (isPairingActive) {
            restartRawMdnsRadar()
        }
        scheduleAutoStop(15_000L)
    }

    fun refreshConnectDiscovery() {
        val devOn = try {
            android.provider.Settings.Global.getInt(context.contentResolver, android.provider.Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1
        } catch (_: Exception) { false }
        val adbWifiOn = try {
            android.provider.Settings.Global.getInt(context.contentResolver, "adb_wifi_enabled", 0) == 1
        } catch (_: Exception) { false }
        if (!devOn || !adbWifiOn) {
            stopDiscovery(updateStatusText = false)
            return
        }

        readSystemAdbTlsPort()?.let { sysPort ->
            lastKnownConnectPort = sysPort
            _state.value = _state.value.copy(connectPort = sysPort)
            onConnectPortDiscovered?.invoke(sysPort, getBestConnectHost() ?: "127.0.0.1")
        }
        val manager = nsdManager
        // TUYỆT ĐỐI không xin MulticastLock và không bật raw UDP radar khi kết nối connectPort thông thường
        // để chip Wi-Fi phần cứng giữ nguyên chế độ ngủ tiết kiệm điện DTIM Power Save (tránh nóng máy).
        _state.value = _state.value.copy(isScanning = true)
        if (manager != null) {
            if (isConnectDiscoveryActive.compareAndSet(true, false)) {
                try {
                    connectDiscoveryListener?.let { manager.stopServiceDiscovery(it) }
                } catch (_: Throwable) {}
                connectDiscoveryListener = null
                unregisterServiceCallbacks(manager, activeConnectCallbacks)
                scope.launch {
                    delay(100L)
                    startConnectDiscovery(manager)
                }
            } else {
                startConnectDiscovery(manager)
            }
        }
        scheduleAutoStop(20_000L)
    }

    fun scheduleAutoStop(timeoutMs: Long = 30_000L) {
        val safeTimeout = timeoutMs.coerceIn(5_000L, 45_000L)
        autoStopJob?.cancel()
        autoStopJob = scope.launch {
            delay(safeTimeout)
            val pairingStillOpen = isPairingUiActive || AdbPairingNotificationManager.isNotificationPairingActive
            if (!pairingStillOpen) {
                stopDiscovery()
            } else {
                scheduleAutoStop(10_000L)
            }
        }
    }

    fun refreshDiscovery() {
        stopDiscovery()
        scope.launch {
            delay(150L)
            startDiscovery()
        }
    }

    private fun stopPairingDiscoveryOnly(updateStatusText: Boolean = false) {
        val manager = nsdManager
        if (manager != null) {
            if (isPairingDiscoveryActive.compareAndSet(true, false)) {
                try {
                    pairingDiscoveryListener?.let { manager.stopServiceDiscovery(it) }
                } catch (_: Throwable) {}
            }
            unregisterServiceCallbacks(manager, activePairingCallbacks)
        }
        pairingDiscoveryListener = null
        stopRawMdnsRadar()
        releaseMulticastLock()
        finalizeIdleDiscoveryResourcesIfAllStopped(updateStatusText)
    }

    private fun stopConnectDiscoveryOnly(updateStatusText: Boolean = false) {
        val manager = nsdManager
        if (manager != null) {
            if (isConnectDiscoveryActive.compareAndSet(true, false)) {
                try {
                    connectDiscoveryListener?.let { manager.stopServiceDiscovery(it) }
                } catch (_: Throwable) {}
            }
            unregisterServiceCallbacks(manager, activeConnectCallbacks)
        }
        connectDiscoveryListener = null
        val pairingStillNeeded = isPairingUiActive || AdbPairingNotificationManager.isNotificationPairingActive
        if (!isPairingDiscoveryActive.get() || !pairingStillNeeded) {
            stopDiscovery(updateStatusText = updateStatusText)
        }
    }

    private fun finalizeIdleDiscoveryResourcesIfAllStopped(updateStatusText: Boolean) {
        if (!isPairingDiscoveryActive.get() && !isConnectDiscoveryActive.get()) {
            autoStopJob?.cancel()
            autoStopJob = null
            stopRawMdnsRadar()
            releaseMulticastLock()
            _state.value = _state.value.copy(
                isScanning = false,
                statusText = if (updateStatusText) "Đã dừng quét dịch vụ mDNS" else _state.value.statusText
            )
        }
    }

    fun clearDiscoveredPorts() {
        lastKnownConnectPort = null
        lastKnownPairingPort = null
        lastKnownPairingHost = null
        lastPairingDiscoveredAtMs = 0L
        lastConnectDiscoveredAtMs = 0L
        _state.value = _state.value.copy(
            pairingPort = null,
            pairingHost = null,
            pairingServiceName = null,
            connectPort = null,
            connectHost = null,
            connectServiceName = null,
            statusText = "Đã dừng quét và ngắt kết nối"
        )
    }

    fun stopDiscovery(updateStatusText: Boolean = true) {
        autoStopJob?.cancel()
        autoStopJob = null
        val manager = nsdManager
        if (manager != null) {
            if (isPairingDiscoveryActive.compareAndSet(true, false)) {
                try {
                    pairingDiscoveryListener?.let { manager.stopServiceDiscovery(it) }
                } catch (e: Exception) {
                    Log.w(TAG, "Stop pairing discovery error", e)
                }
            }
            if (isConnectDiscoveryActive.compareAndSet(true, false)) {
                try {
                    connectDiscoveryListener?.let { manager.stopServiceDiscovery(it) }
                } catch (e: Exception) {
                    Log.w(TAG, "Stop connect discovery error", e)
                }
            }
            unregisterServiceCallbacks(manager, activePairingCallbacks)
            unregisterServiceCallbacks(manager, activeConnectCallbacks)
        }
        pairingDiscoveryListener = null
        connectDiscoveryListener = null
        stopRawMdnsRadar()
        releaseMulticastLock()

        _state.value = _state.value.copy(
            isScanning = false,
            statusText = if (updateStatusText) "Đã dừng quét dịch vụ mDNS" else _state.value.statusText
        )
    }

    @Volatile
    private var multicastAutoReleaseJob: kotlinx.coroutines.Job? = null

    fun acquireMulticastLock(forceForPairing: Boolean = false) {
        // NGUYÊN TẮC BẢO VỆ NHIỆT ĐỘ & PIN TUYỆT ĐỐI (ICE-COOL RUNTIME):
        val devOn = try {
            android.provider.Settings.Global.getInt(context.contentResolver, android.provider.Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1
        } catch (_: Exception) { false }
        if (!devOn) {
            releaseMulticastLock()
            return
        }

        // 1. Tuyệt đối KHÔNG BAO GIỜ cấp MulticastLock nếu người dùng đang Dịch màn hình, đang mở Gemini Live, hoặc Khoanh tròn tìm kiếm
        if (com.example.core.widget.GoogleLiveTranslateOverlay.isRunning ||
            com.example.core.widget.MagicLiveFloatingOverlay.isShowing ||
            com.example.core.widget.CircleToSearchWindowOverlay.isShowing ||
            com.example.core.widget.CircleToSearchOverlayActivity.isOverlayActive
        ) {
            releaseMulticastLock()
            return
        }

        val isPairingActive = forceForPairing ||
            AdbPairingNotificationManager.isNotificationPairingActive ||
            isPairingUiActive
        if (!isPairingActive) {
            // Không cấp MulticastLock cho tác vụ kết nối thông thường để chip Wi-Fi giữ nguyên DTIM sleep
            return
        }
        try {
            if (multicastLock == null) {
                multicastLock = wifiManager?.createMulticastLock("magictune_adb_nsd_lock")?.apply {
                    setReferenceCounted(false)
                }
            }
            if (multicastLock?.isHeld == false) {
                multicastLock?.acquire()
                isMulticastLockHeld = true
                Log.d(TAG, "MulticastLock acquired for pairing (ice-cool mode)")
            }
            // Hạn chế tối đa thời gian chiếm giữ MulticastLock: Tự động nhả sau tối đa 2 giây (đủ 100% để bắt mDNS pairing)
            multicastAutoReleaseJob?.cancel()
            multicastAutoReleaseJob = scope.launch {
                delay(2_000L)
                releaseMulticastLock()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not acquire MulticastLock", e)
        }
    }

    fun releaseMulticastLock() {
        multicastAutoReleaseJob?.cancel()
        multicastAutoReleaseJob = null
        isMulticastLockHeld = false
        try {
            if (multicastLock?.isHeld == true) {
                multicastLock?.release()
                Log.d(TAG, "MulticastLock released successfully")
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not release MulticastLock", e)
        }
    }

    private fun startPairingDiscovery(manager: NsdManager) {
        if (isPairingDiscoveryActive.get()) return

        val listener = object : NsdManager.DiscoveryListener {
            override fun onStartDiscoveryFailed(serviceType: String?, errorCode: Int) {
                Log.w(TAG, "Pairing discovery start failed: $errorCode")
                isPairingDiscoveryActive.set(false)
            }

            override fun onStopDiscoveryFailed(serviceType: String?, errorCode: Int) {
                isPairingDiscoveryActive.set(false)
            }

            override fun onDiscoveryStarted(serviceType: String?) {
                Log.d(TAG, "Started NSD discovery for $serviceType")
                isPairingDiscoveryActive.set(true)
            }

            override fun onDiscoveryStopped(serviceType: String?) {
                Log.d(TAG, "Stopped NSD discovery for $serviceType")
                isPairingDiscoveryActive.set(false)
            }

            override fun onServiceFound(serviceInfo: NsdServiceInfo?) {
                if (serviceInfo == null) return
                Log.d(TAG, "Found pairing service: ${serviceInfo.serviceName}")
                resolveDiscoveredService(manager, serviceInfo, isPairing = true)
            }

            override fun onServiceLost(serviceInfo: NsdServiceInfo?) {
                if (serviceInfo == null) return
                Log.d(TAG, "Lost pairing service: ${serviceInfo.serviceName}")
                // Nếu thông báo ghép nối vẫn đang mở hoặc cổng mới tìm thấy chưa quá 8 giây trên Honor MagicOS,
                // không xóa ngay để tránh làm thông báo nhập mã 6 số biến mất khi kéo thanh thông báo xuống.
                val recentlyFound = (System.currentTimeMillis() - lastPairingDiscoveredAtMs) < 8_000L
                if (!AdbPairingNotificationManager.isNotificationPairingActive &&
                    !recentlyFound &&
                    _state.value.pairingServiceName == serviceInfo.serviceName
                ) {
                    _state.value = _state.value.copy(
                        pairingPort = null,
                        pairingServiceName = null,
                        statusText = "Cửa sổ mã ghép đôi đã đóng • Đang kết nối cổng chính..."
                    )
                }
            }
        }

        pairingDiscoveryListener = listener
        try {
            manager.discoverServices(SERVICE_TYPE_PAIRING, NsdManager.PROTOCOL_DNS_SD, listener)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start pairing discovery", e)
            isPairingDiscoveryActive.set(false)
        }
    }

    private fun startConnectDiscovery(manager: NsdManager) {
        if (isConnectDiscoveryActive.get()) return

        val listener = object : NsdManager.DiscoveryListener {
            override fun onStartDiscoveryFailed(serviceType: String?, errorCode: Int) {
                Log.w(TAG, "Connect discovery start failed: $errorCode")
                isConnectDiscoveryActive.set(false)
            }

            override fun onStopDiscoveryFailed(serviceType: String?, errorCode: Int) {
                isConnectDiscoveryActive.set(false)
            }

            override fun onDiscoveryStarted(serviceType: String?) {
                Log.d(TAG, "Started NSD discovery for $serviceType")
                isConnectDiscoveryActive.set(true)
            }

            override fun onDiscoveryStopped(serviceType: String?) {
                Log.d(TAG, "Stopped NSD discovery for $serviceType")
                isConnectDiscoveryActive.set(false)
            }

            override fun onServiceFound(serviceInfo: NsdServiceInfo?) {
                if (serviceInfo == null) return
                Log.d(TAG, "Found connect service: ${serviceInfo.serviceName}")
                resolveDiscoveredService(manager, serviceInfo, isPairing = false)
            }

            override fun onServiceLost(serviceInfo: NsdServiceInfo?) {
                if (serviceInfo == null) return
                val devStillOn = try {
                    android.provider.Settings.Global.getInt(context.contentResolver, android.provider.Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1
                } catch (_: Exception) { false }
                val adbWifiStillOn = devStillOn && try {
                    android.provider.Settings.Global.getInt(context.contentResolver, "adb_wifi_enabled", 0) == 1
                } catch (_: Exception) { false }
                if (!adbWifiStillOn && _state.value.connectServiceName == serviceInfo.serviceName) {
                    lastKnownConnectPort = null
                    _state.value = _state.value.copy(
                        connectPort = null,
                        connectServiceName = null
                    )
                }
            }
        }

        connectDiscoveryListener = listener
        try {
            manager.discoverServices(SERVICE_TYPE_CONNECT, NsdManager.PROTOCOL_DNS_SD, listener)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start connect discovery", e)
            isConnectDiscoveryActive.set(false)
        }
    }

    private fun resolveDiscoveredService(
        manager: NsdManager,
        serviceInfo: NsdServiceInfo,
        isPairing: Boolean
    ) {
        // Android 14+ (API 34+): ưu tiên API hiện đại registerServiceInfoCallback (không bị nghẽn resolveService cũ)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            registerServiceInfoCallbackApi34(manager, serviceInfo, isPairing)
            return
        }

        val mutex = if (isPairing) pairingResolveMutex else connectResolveMutex
        scope.launch {
            mutex.withLock {
                try {
                    var attempts = 0
                    var resolved: NsdServiceInfo? = null
                    while (attempts < 3 && resolved == null) {
                        attempts++
                        resolved = resolveSingleServiceSuspended(manager, serviceInfo)
                        if (resolved == null && attempts < 3) {
                            delay(200L * attempts)
                        }
                    }
                    if (resolved != null) {
                        handleResolvedServiceInfo(resolved, isPairing)
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Queued resolveService exception", e)
                }
            }
        }
    }

    private fun registerServiceInfoCallbackApi34(
        manager: NsdManager,
        serviceInfo: NsdServiceInfo,
        isPairing: Boolean
    ) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.UPSIDE_DOWN_CAKE) return
        val key = serviceInfo.serviceName ?: return
        val map = if (isPairing) activePairingCallbacks else activeConnectCallbacks

        val old = map.remove(key)
        if (old != null) {
            try {
                (old as? NsdManager.ServiceInfoCallback)?.let { manager.unregisterServiceInfoCallback(it) }
            } catch (_: Throwable) {}
        }

        val callback = object : NsdManager.ServiceInfoCallback {
            override fun onServiceInfoCallbackRegistrationFailed(errorCode: Int) {
                Log.w(TAG, "registerServiceInfoCallback failed ($errorCode) for $key, fallback resolveService")
                map.remove(key, this)
                scope.launch {
                    val mutex = if (isPairing) pairingResolveMutex else connectResolveMutex
                    mutex.withLock {
                        resolveSingleServiceSuspended(manager, serviceInfo)?.let {
                            handleResolvedServiceInfo(it, isPairing)
                        }
                    }
                }
            }

            override fun onServiceUpdated(updatedInfo: NsdServiceInfo) {
                handleResolvedServiceInfo(updatedInfo, isPairing)
                if (updatedInfo.port in 1..65535) {
                    map.remove(key, this)
                    try {
                        manager.unregisterServiceInfoCallback(this)
                    } catch (_: Throwable) {}
                }
            }

            override fun onServiceLost() {
                map.remove(key, this)
                try {
                    manager.unregisterServiceInfoCallback(this)
                } catch (_: Throwable) {}
            }

            override fun onServiceInfoCallbackUnregistered() {
                map.remove(key, this)
            }
        }

        map[key] = callback
        try {
            manager.registerServiceInfoCallback(serviceInfo, nsdExecutor, callback)
        } catch (e: Throwable) {
            map.remove(key, callback)
            Log.w(TAG, "registerServiceInfoCallback exception, fallback resolveService", e)
            scope.launch {
                val mutex = if (isPairing) pairingResolveMutex else connectResolveMutex
                mutex.withLock {
                    resolveSingleServiceSuspended(manager, serviceInfo)?.let {
                        handleResolvedServiceInfo(it, isPairing)
                    }
                }
            }
        }
    }

    private fun unregisterServiceCallbacks(manager: NsdManager, map: ConcurrentHashMap<String, Any>) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            map.clear()
            return
        }
        val entries = map.values.toList()
        map.clear()
        for (cb in entries) {
            try {
                (cb as? NsdManager.ServiceInfoCallback)?.let { manager.unregisterServiceInfoCallback(it) }
            } catch (_: Throwable) {}
        }
    }

    private suspend fun resolveSingleServiceSuspended(
        manager: NsdManager,
        serviceInfo: NsdServiceInfo
    ): NsdServiceInfo? = withTimeoutOrNull(2200L) {
        suspendCancellableCoroutine { cont ->
            val hasResumed = AtomicBoolean(false)
            fun safeResume(result: NsdServiceInfo?) {
                if (hasResumed.compareAndSet(false, true)) {
                    try {
                        if (cont.isActive) {
                            cont.resumeWith(Result.success(result))
                        }
                    } catch (_: Throwable) {}
                }
            }
            try {
                @Suppress("DEPRECATION")
                manager.resolveService(serviceInfo, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(info: NsdServiceInfo?, errorCode: Int) {
                        Log.w(TAG, "Resolve failed ($errorCode) for ${info?.serviceName}")
                        safeResume(null)
                    }

                    override fun onServiceResolved(resolvedInfo: NsdServiceInfo?) {
                        safeResume(resolvedInfo)
                    }
                })
            } catch (e: Throwable) {
                safeResume(null)
            }
        }
    }

    private fun handleResolvedServiceInfo(resolvedInfo: NsdServiceInfo, isPairing: Boolean) {
        val port = resolvedInfo.port
        if (port !in 1..65535) return

        @Suppress("DEPRECATION")
        val hostAddress = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val ipv4 = resolvedInfo.hostAddresses.firstOrNull {
                it is Inet4Address && !it.isLoopbackAddress
            }?.hostAddress
            ipv4 ?: "127.0.0.1"
        } else {
            val raw = resolvedInfo.host?.hostAddress
            if (raw != null && !raw.contains(":")) raw else "127.0.0.1"
        }

        emitDiscoveredService(
            port = port,
            hostAddress = hostAddress,
            serviceName = resolvedInfo.serviceName ?: if (isPairing) "adb-pairing" else "adb-connect",
            isPairing = isPairing
        )
    }

    private fun emitDiscoveredService(
        port: Int,
        hostAddress: String,
        serviceName: String,
        isPairing: Boolean
    ) {
        if (port !in 1..65535) return
        if (isPairing) {
            val changed = _state.value.pairingPort != port || _state.value.pairingServiceName != serviceName
            lastPairingDiscoveredAtMs = System.currentTimeMillis()
            lastKnownPairingPort = port
            lastKnownPairingHost = hostAddress
            try {
                nsdPrefs.edit()
                    .putInt("last_pairing_port", port)
                    .putString("last_pairing_host", hostAddress)
                    .putLong("last_pairing_time", System.currentTimeMillis())
                    .apply()
            } catch (_: Throwable) {}
            _state.value = _state.value.copy(
                pairingPort = port,
                pairingHost = hostAddress,
                pairingServiceName = serviceName,
                statusText = "🟢 Đã tự động bắt được cổng ghép nối: $port! Chỉ cần nhập mã PIN 6 số."
            )
            if (changed) {
                Log.i(TAG, "✅ Discovered _adb-tls-pairing._tcp -> $hostAddress:$port ($serviceName)")
            }
            onPairingPortDiscovered?.invoke(port, hostAddress)
            // Dừng ngay discovery kênh pairing và giải phóng MulticastLock tức thì
            releaseMulticastLock()
            stopPairingDiscoveryOnly(updateStatusText = false)
        } else {
            val changed = _state.value.connectPort != port || _state.value.connectServiceName != serviceName
            lastKnownConnectPort = port
            lastConnectDiscoveredAtMs = System.currentTimeMillis()
            recordRecentConnectPort(port, hostAddress)
            _state.value = _state.value.copy(
                connectPort = port,
                connectHost = hostAddress,
                connectServiceName = serviceName,
                statusText = if (_state.value.pairingPort != null) {
                    _state.value.statusText
                } else {
                    "🟢 Đã phát hiện cổng kết nối ADB: $port ($hostAddress)"
                }
            )
            if (changed) {
                Log.i(TAG, "✅ Discovered _adb-tls-connect._tcp -> $hostAddress:$port ($serviceName)")
            }
            onConnectPortDiscovered?.invoke(port, hostAddress)
            // Dừng ngay NsdManager.stopServiceDiscovery() sau khi tìm thấy cổng ADB connect
            stopConnectDiscoveryOnly(updateStatusText = false)
        }
    }

    // ==================== RAW mDNS UDP RADAR (LỚP DỰ PHÒNG CHỐNG BÓP NSD TRÊN MAGICOS 9/10/11) ====================

    private fun restartRawMdnsRadar() {
        stopRawMdnsRadar()
        startRawMdnsRadar()
    }

    private fun startRawMdnsRadar() {
        // Passive multicast listener chỉ có ích khi MulticastLock đang được giữ (không có lock thì không nhận được
        // gói multicast nào). Nếu lock không được cấp (vd: đang có overlay/dịch màn hình), chỉ chạy active unicast querier.
        if (isMulticastLockHeld && rawMdnsMulticastJob?.isActive != true) {
            rawMdnsMulticastJob = scope.launch {
                runPassiveMdnsMulticastListener()
            }
        }
        if (rawMdnsQuerierJob?.isActive != true) {
            rawMdnsQuerierJob = scope.launch {
                runActiveMdnsPtrQuerier()
            }
        }
    }

    private fun stopRawMdnsRadar() {
        rawMdnsMulticastJob?.cancel()
        rawMdnsMulticastJob = null
        rawMdnsQuerierJob?.cancel()
        rawMdnsQuerierJob = null
    }

    private suspend fun runPassiveMdnsMulticastListener() {
        var socket: MulticastSocket? = null
        try {
            val group = InetAddress.getByName(MDNS_MULTICAST_ADDR)
            socket = MulticastSocket(null).apply {
                reuseAddress = true
                soTimeout = 1500
                bind(InetSocketAddress(MDNS_PORT))
            }
            // Tham gia nhóm 224.0.0.251 trên mọi interface IPv4 đang bật (Wi-Fi + loopback)
            try {
                val interfaces = NetworkInterface.getNetworkInterfaces()
                var joinedAny = false
                if (interfaces != null) {
                    for (nif in interfaces) {
                        if (nif.isUp && nif.supportsMulticast() && !nif.isPointToPoint) {
                            try {
                                socket.joinGroup(InetSocketAddress(group, MDNS_PORT), nif)
                                joinedAny = true
                            } catch (_: Throwable) {}
                        }
                    }
                }
                if (!joinedAny) {
                    @Suppress("DEPRECATION")
                    socket.joinGroup(group)
                }
            } catch (_: Throwable) {
                try {
                    @Suppress("DEPRECATION")
                    socket.joinGroup(group)
                } catch (_: Throwable) {}
            }

            val buf = ByteArray(4096)
            val packet = DatagramPacket(buf, buf.size)
            val passiveStartTime = System.currentTimeMillis()
            while (scope.isActive && _state.value.isScanning && isMulticastLockHeld) {
                val pairingExpected = AdbPairingNotificationManager.isNotificationPairingActive || isPairingUiActive
                if (!pairingExpected) {
                    // Đã rời màn hình ghép đôi -> dừng socket multicast ngay để CPU và chip Wi-Fi nghỉ ngơi mát máy
                    break
                }
                // Giới hạn an toàn tuyệt đối 90s để chống kẹt MulticastLock làm cạn pin radio Wi-Fi
                if (System.currentTimeMillis() - passiveStartTime > 90_000L) {
                    Log.d(TAG, "Passive mDNS multicast safety timeout (90s) -> releasing socket and lock")
                    break
                }
                try {
                    packet.setData(buf, 0, buf.size)
                    socket.receive(packet)
                    parseMdnsPacketAndEmit(packet.data, packet.length)
                } catch (_: java.net.SocketTimeoutException) {
                    // Timeout định kỳ để kiểm tra vòng lặp
                } catch (_: Throwable) {
                    delay(300L)
                }
            }
        } catch (e: Throwable) {
            Log.d(TAG, "Passive mDNS bind skipped (${e.message}), active QU querier remains active")
        } finally {
            try { socket?.close() } catch (_: Throwable) {}
            releaseMulticastLock()
        }
    }

    private suspend fun runActiveMdnsPtrQuerier() {
        var socket: DatagramSocket? = null
        try {
            socket = DatagramSocket().apply {
                soTimeout = 450
            }
            val group = InetAddress.getByName(MDNS_MULTICAST_ADDR)
            val pairingQuery = buildMdnsPtrQuery("_adb-tls-pairing._tcp.local")
            val connectQuery = buildMdnsPtrQuery("_adb-tls-connect._tcp.local")
            val rxBuf = ByteArray(4096)
            val resp = DatagramPacket(rxBuf, rxBuf.size)

            // Thời điểm bắt đầu vòng đời của querier này (được reset mỗi lần khởi động lại radar)
            val loopStartTime = System.currentTimeMillis()

            while (scope.isActive && _state.value.isScanning) {
                val pairingExpected = AdbPairingNotificationManager.isNotificationPairingActive || isPairingUiActive
                if (!pairingExpected) {
                    // Đã xong hoặc rời ghép đôi -> dừng ngay querier mDNS để tiết kiệm pin
                    break
                }
                try {
                    socket.send(DatagramPacket(pairingQuery, pairingQuery.size, group, MDNS_PORT))

                    // Chỉ gửi thêm query kênh connect khi chưa biết cổng connect (giảm số gói đánh thức radio Wi-Fi)
                    if (_state.value.connectPort == null) {
                        socket.send(DatagramPacket(connectQuery, connectQuery.size, group, MDNS_PORT))
                    }

                    // Đọc toàn bộ các gói phản hồi unicast trả về trong cửa sổ 350ms
                    val deadline = System.currentTimeMillis() + 350L
                    while (System.currentTimeMillis() < deadline && _state.value.isScanning) {
                        try {
                            resp.setData(rxBuf, 0, rxBuf.size)
                            socket.receive(resp)
                            parseMdnsPacketAndEmit(resp.data, resp.length)
                        } catch (_: java.net.SocketTimeoutException) {
                            break
                        }
                    }
                } catch (_: Throwable) {}

                // Nhịp quét thích ứng để tiết kiệm pin:
                // - Màn hình ghép đôi đang mở (người dùng đang nhìn): quét nhanh để bắt cổng tức thì.
                // - Chỉ còn thông báo (app ở nền): giãn nhịp để chip Wi-Fi ngủ lâu hơn.
                val interval = when {
                    isPairingUiActive -> if (_state.value.pairingPort == null) 1_200L else 2_500L
                    else -> 4_000L
                }
                delay(interval)

                // Giới hạn thời gian chống quét vô hạn: tối đa 90s khi màn hình mở, 45s khi app ở nền
                // để bảo đảm chip Wi-Fi luôn được nghỉ ngơi sâu (PS-Poll mode), không bị drain pin.
                val maxQuerierDuration = if (isPairingUiActive) 90_000L else 45_000L
                if (System.currentTimeMillis() - loopStartTime > maxQuerierDuration) {
                    Log.d(TAG, "Active QU querier safety timeout reached (${maxQuerierDuration / 1000}s) -> stopping radar to save battery")
                    break
                }
            }
        } catch (e: Throwable) {
            Log.w(TAG, "Active mDNS QU querier stopped", e)
        } finally {
            try { socket?.close() } catch (_: Throwable) {}
            releaseMulticastLock()
        }
    }

    private fun buildMdnsPtrQuery(fqdn: String): ByteArray {
        val out = ByteArrayOutputStream()
        // DNS Header: ID=0, Flags=0, QDCOUNT=1, AN=0, NS=0, AR=0
        out.write(0x00); out.write(0x00)
        out.write(0x00); out.write(0x00)
        out.write(0x00); out.write(0x01)
        out.write(0x00); out.write(0x00)
        out.write(0x00); out.write(0x00)
        out.write(0x00); out.write(0x00)

        fqdn.trimEnd('.').split('.').forEach { label ->
            val bytes = label.toByteArray(Charsets.UTF_8)
            out.write(bytes.size and 0xFF)
            out.write(bytes)
        }
        out.write(0x00)
        // QTYPE = PTR (12)
        out.write(0x00); out.write(0x0C)
        // QCLASS = IN (1) + QU unicast-response bit (0x8001) để mdnsd trả thẳng về socket cục bộ
        out.write(0x80); out.write(0x01)
        return out.toByteArray()
    }

    private fun parseMdnsPacketAndEmit(data: ByteArray, length: Int) {
        if (length < 12) return
        val qdCount = ((data[4].toInt() and 0xFF) shl 8) or (data[5].toInt() and 0xFF)
        val anCount = ((data[6].toInt() and 0xFF) shl 8) or (data[7].toInt() and 0xFF)
        val nsCount = ((data[8].toInt() and 0xFF) shl 8) or (data[9].toInt() and 0xFF)
        val arCount = ((data[10].toInt() and 0xFF) shl 8) or (data[11].toInt() and 0xFF)
        val totalRRs = anCount + nsCount + arCount
        if (totalRRs <= 0 || totalRRs > 64) return

        var offset = 12
        for (i in 0 until qdCount) {
            val next = skipDnsName(data, length, offset) ?: return
            offset = next + 4
            if (offset > length) return
        }

        val discoveredSrv = mutableListOf<Triple<String, Int, String>>() // fullName, port, targetHost
        val hostIps = mutableMapOf<String, String>()

        for (i in 0 until totalRRs) {
            if (offset >= length) break
            val namePair = readDnsName(data, length, offset) ?: break
            val rrName = namePair.first
            offset = namePair.second
            if (offset + 10 > length) break

            val rrType = ((data[offset].toInt() and 0xFF) shl 8) or (data[offset + 1].toInt() and 0xFF)
            // TTL = 4 bytes, RDLENGTH = 2 bytes
            val rdLength = ((data[offset + 8].toInt() and 0xFF) shl 8) or (data[offset + 9].toInt() and 0xFF)
            val rdataOffset = offset + 10
            val nextOffset = rdataOffset + rdLength
            if (nextOffset > length) break

            when (rrType) {
                33 -> { // SRV record: priority(2) weight(2) port(2) target(...)
                    if (rdLength >= 7) {
                        val port = ((data[rdataOffset + 4].toInt() and 0xFF) shl 8) or
                            (data[rdataOffset + 5].toInt() and 0xFF)
                        val targetName = readDnsName(data, length, rdataOffset + 6)?.first.orEmpty()
                        if (port in 1..65535) {
                            discoveredSrv.add(Triple(rrName, port, targetName))
                        }
                    }
                }
                1 -> { // A record (IPv4)
                    if (rdLength == 4) {
                        val ip = "${data[rdataOffset].toInt() and 0xFF}." +
                            "${data[rdataOffset + 1].toInt() and 0xFF}." +
                            "${data[rdataOffset + 2].toInt() and 0xFF}." +
                            "${data[rdataOffset + 3].toInt() and 0xFF}"
                        if (ip != "0.0.0.0" && !ip.startsWith("127.")) {
                            hostIps[rrName.lowercase()] = ip
                        }
                    }
                }
            }
            offset = nextOffset
        }

        for ((fullName, port, targetHost) in discoveredSrv) {
            val lower = fullName.lowercase()
            val resolvedIp = hostIps[targetHost.lowercase()] ?: "127.0.0.1"
            val shortName = fullName.substringBefore("._adb-tls-").ifBlank { fullName }
            when {
                lower.contains("_adb-tls-pairing._tcp") -> {
                    emitDiscoveredService(
                        port = port,
                        hostAddress = resolvedIp,
                        serviceName = shortName,
                        isPairing = true
                    )
                }
                lower.contains("_adb-tls-connect._tcp") -> {
                    emitDiscoveredService(
                        port = port,
                        hostAddress = resolvedIp,
                        serviceName = shortName,
                        isPairing = false
                    )
                }
            }
        }
    }

    private fun skipDnsName(data: ByteArray, length: Int, start: Int): Int? {
        var idx = start
        var steps = 0
        while (idx < length && steps++ < 128) {
            val b = data[idx].toInt() and 0xFF
            if (b == 0) return idx + 1
            if ((b and 0xC0) == 0xC0) {
                return if (idx + 2 <= length) idx + 2 else null
            }
            idx += 1 + b
        }
        return null
    }

    private fun readDnsName(data: ByteArray, length: Int, start: Int): Pair<String, Int>? {
        val sb = StringBuilder()
        var idx = start
        var nextOffsetAfterName = -1
        var jumps = 0
        while (idx < length && jumps++ < 32) {
            val len = data[idx].toInt() and 0xFF
            if (len == 0) {
                if (nextOffsetAfterName < 0) nextOffsetAfterName = idx + 1
                break
            }
            if ((len and 0xC0) == 0xC0) {
                if (idx + 1 >= length) return null
                if (nextOffsetAfterName < 0) nextOffsetAfterName = idx + 2
                val ptr = ((len and 0x3F) shl 8) or (data[idx + 1].toInt() and 0xFF)
                if (ptr >= length) return null
                idx = ptr
            } else {
                idx++
                if (idx + len > length) return null
                if (sb.isNotEmpty()) sb.append('.')
                sb.append(String(data, idx, len, Charsets.UTF_8))
                idx += len
            }
        }
        if (nextOffsetAfterName < 0) return null
        return Pair(sb.toString(), nextOffsetAfterName)
    }
}
