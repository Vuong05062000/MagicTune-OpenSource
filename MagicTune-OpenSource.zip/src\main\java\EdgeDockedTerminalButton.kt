package com.example.ui.components

import android.content.Context
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicCyanLight
import com.example.ui.theme.MagicRose
import com.example.ui.theme.MagicRoseLight

private const val PREFS_EDGE_BUTTON = "magictune_edge_terminal_prefs"
private const val KEY_DOCKED_LEFT = "is_docked_left"
private const val KEY_Y_RATIO = "y_offset_ratio"

/**
 * Nút mở ADB Log & Terminal ở cạnh màn hình:
 * - Thiết kế Kính Lỏng Trong Suốt (Liquid Glass) xuyên thấu sang trọng với viền phản quang đa sắc.
 * - Hỗ trợ kéo lên / kéo xuống mượt mà dọc theo cạnh màn hình.
 * - Hỗ trợ kéo nhảy từ cạnh màn hình Phải sang cạnh màn hình Trái (và ngược lại) với hiệu ứng đàn hồi tự hít vào mép.
 * - Tự động lưu vị trí cạnh Trái/Phải và độ cao Y để giữ nguyên theo ý người dùng.
 */
@Composable
fun EdgeDockedTerminalButton(
    isScrolling: Boolean,
    errorCount: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val density = LocalDensity.current

    var isDockedLeft by remember { mutableStateOf(false) }
    var yRatio by remember { mutableFloatStateOf(0.78f) }
    androidx.compose.runtime.LaunchedEffect(Unit) {
        val loaded = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            val prefs = context.getSharedPreferences(PREFS_EDGE_BUTTON, Context.MODE_PRIVATE)
            prefs.getBoolean(KEY_DOCKED_LEFT, false) to prefs.getFloat(KEY_Y_RATIO, 0.78f).coerceIn(0.12f, 0.88f)
        }
        isDockedLeft = loaded.first
        yRatio = loaded.second
    }
    var isDragging by remember { mutableStateOf(false) }
    var dragRawX by remember { mutableFloatStateOf(0f) }
    var dragRawY by remember { mutableFloatStateOf(0f) }

    BoxWithConstraints(
        modifier = Modifier.fillMaxSize()
    ) {
        val containerWidthPx = constraints.maxWidth.toFloat().coerceAtLeast(1f)
        val containerHeightPx = constraints.maxHeight.toFloat().coerceAtLeast(1f)

        val btnWidthDp = if (errorCount > 0) 64.dp else 56.dp
        val btnHeightDp = 42.dp
        val btnWidthPx = with(density) { btnWidthDp.toPx() }
        val btnHeightPx = with(density) { btnHeightDp.toPx() }

        val minY = with(density) { 76.dp.toPx() }
        val maxY = (containerHeightPx - btnHeightPx - with(density) { 36.dp.toPx() }).coerceAtLeast(minY)

        val targetDockedX = if (isDockedLeft) 0f else (containerWidthPx - btnWidthPx).coerceAtLeast(0f)
        val targetDockedY = (yRatio * containerHeightPx).coerceIn(minY, maxY)

        val animatedX by animateFloatAsState(
            targetValue = if (isDragging) dragRawX else targetDockedX,
            animationSpec = if (isDragging) {
                spring(stiffness = Spring.StiffnessHigh)
            } else {
                spring(
                    dampingRatio = Spring.DampingRatioLowBouncy,
                    stiffness = Spring.StiffnessMediumLow
                )
            },
            label = "edge_btn_x"
        )

        val animatedY by animateFloatAsState(
            targetValue = if (isDragging) dragRawY else targetDockedY,
            animationSpec = if (isDragging) {
                spring(stiffness = Spring.StiffnessHigh)
            } else {
                spring(
                    dampingRatio = Spring.DampingRatioNoBouncy,
                    stiffness = Spring.StiffnessMedium
                )
            },
            label = "edge_btn_y"
        )

        val shape = remember(isDragging, isDockedLeft) {
            when {
                isDragging -> RoundedCornerShape(20.dp)
                isDockedLeft -> RoundedCornerShape(
                    topStart = 3.dp,
                    bottomStart = 3.dp,
                    topEnd = 18.dp,
                    bottomEnd = 18.dp
                )
                else -> RoundedCornerShape(
                    topStart = 18.dp,
                    bottomStart = 18.dp,
                    topEnd = 3.dp,
                    bottomEnd = 3.dp
                )
            }
        }

        // Hiệu ứng Kính Lỏng Trong Suốt (Liquid Glass) - cache Brush để không cấp phát lại mỗi frame kéo
        val hasErrors = errorCount > 0
        val glassFillBrush = remember(hasErrors, isDragging) {
            if (hasErrors) {
                Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = if (isDragging) 0.28f else 0.18f),
                        MagicRose.copy(alpha = if (isDragging) 0.34f else 0.22f),
                        Color(0xFF1E1B4B).copy(alpha = if (isDragging) 0.38f else 0.24f)
                    )
                )
            } else {
                Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = if (isDragging) 0.28f else 0.16f),
                        MagicCyan.copy(alpha = if (isDragging) 0.26f else 0.14f),
                        Color(0xFF0F172A).copy(alpha = if (isDragging) 0.34f else 0.20f)
                    )
                )
            }
        }

        val glassBorderBrush = remember(hasErrors) {
            if (hasErrors) {
                Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.85f),
                        MagicRoseLight.copy(alpha = 0.65f),
                        Color.White.copy(alpha = 0.25f)
                    )
                )
            } else {
                Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.85f),
                        MagicCyanLight.copy(alpha = 0.55f),
                        Color.White.copy(alpha = 0.22f)
                    )
                )
            }
        }

        val contentAlpha = if (isScrolling && !isDragging) 0.68f else 0.96f

        Box(
            modifier = Modifier
                .graphicsLayer {
                    translationX = animatedX
                    translationY = animatedY
                }
                .size(width = btnWidthDp, height = btnHeightDp)
                .then(
                    if (isDragging) {
                        Modifier.border(
                            width = 1.6.dp,
                            color = if (hasErrors) MagicRose else MagicCyan,
                            shape = shape
                        )
                    } else {
                        Modifier
                    }
                )
                .clip(shape)
                .background(glassFillBrush)
                .border(width = 1.1.dp, brush = glassBorderBrush, shape = shape)
                .pointerInput(containerWidthPx, containerHeightPx) {
                    detectDragGestures(
                        onDragStart = {
                            dragRawX = if (isDockedLeft) 0f else (containerWidthPx - btnWidthPx).coerceAtLeast(0f)
                            dragRawY = (yRatio * containerHeightPx).coerceIn(minY, maxY)
                            isDragging = true
                        },
                        onDragEnd = {
                            val centerX = dragRawX + btnWidthPx / 2f
                            val newDockedLeft = centerX < (containerWidthPx / 2f)
                            val clampedY = dragRawY.coerceIn(minY, maxY)
                            val newRatio = (clampedY / containerHeightPx).coerceIn(0.10f, 0.90f)
                            isDockedLeft = newDockedLeft
                            yRatio = newRatio
                            isDragging = false
                            context.getSharedPreferences(PREFS_EDGE_BUTTON, Context.MODE_PRIVATE).edit()
                                .putBoolean(KEY_DOCKED_LEFT, newDockedLeft)
                                .putFloat(KEY_Y_RATIO, newRatio)
                                .apply()
                        },
                        onDragCancel = {
                            val centerX = dragRawX + btnWidthPx / 2f
                            val newDockedLeft = centerX < (containerWidthPx / 2f)
                            val clampedY = dragRawY.coerceIn(minY, maxY)
                            val newRatio = (clampedY / containerHeightPx).coerceIn(0.10f, 0.90f)
                            isDockedLeft = newDockedLeft
                            yRatio = newRatio
                            isDragging = false
                            context.getSharedPreferences(PREFS_EDGE_BUTTON, Context.MODE_PRIVATE).edit()
                                .putBoolean(KEY_DOCKED_LEFT, newDockedLeft)
                                .putFloat(KEY_Y_RATIO, newRatio)
                                .apply()
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            dragRawX = (dragRawX + dragAmount.x).coerceIn(0f, (containerWidthPx - btnWidthPx).coerceAtLeast(0f))
                            dragRawY = (dragRawY + dragAmount.y).coerceIn(minY, maxY)
                        }
                    )
                }
                .clickable { onClick() }
                .testTag("edge_docked_terminal_button"),
            contentAlignment = Alignment.Center
        ) {
            // Vệt phản quang kính lỏng (Specular Liquid Highlight) phía trên
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
                    .height(1.5.dp)
                    .width(btnWidthDp - 14.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.55f))
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.padding(horizontal = 6.dp)
            ) {
                if (!isDockedLeft) {
                    // Thanh gờ nắm kéo mảnh bên trái khi neo ở cạnh phải
                    Box(
                        modifier = Modifier
                            .width(2.5.dp)
                            .height(16.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.45f))
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Terminal,
                            contentDescription = "Mở hộp lệnh ADB & Log",
                            tint = Color.White.copy(alpha = contentAlpha),
                            modifier = Modifier.size(13.dp)
                        )
                        if (errorCount > 0) {
                            Text(
                                text = "$errorCount",
                                color = MagicRoseLight,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                    Text(
                        text = "ADB",
                        color = if (errorCount > 0) MagicRoseLight else MagicCyanLight.copy(alpha = contentAlpha),
                        fontSize = 8.5.sp,
                        fontWeight = FontWeight.Black,
                        lineHeight = 9.sp
                    )
                }

                if (isDockedLeft) {
                    Spacer(modifier = Modifier.width(4.dp))
                    // Thanh gờ nắm kéo mảnh bên phải khi neo ở cạnh trái
                    Box(
                        modifier = Modifier
                            .width(2.5.dp)
                            .height(16.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.45f))
                    )
                }
            }
        }
    }
}
