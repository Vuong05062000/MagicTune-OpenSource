package com.example.core.auth

import android.content.Context
import androidx.compose.runtime.Immutable
import com.example.core.license.LicenseManager
import com.example.data.HonorAppItem
import com.google.firebase.Timestamp
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.launch
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

@Immutable
data class AdminDerivedUiState(
    val mergedDevices: List<DeviceRecord> = emptyList(),
    val mergedUsers: List<UserProfile> = emptyList(),
    val aiBillLogByNormDevId: Map<String, LicenseManager.AiProChatLogRecord> = emptyMap(),
    val aiBillLogByEmail: Map<String, LicenseManager.AiProChatLogRecord> = emptyMap(),
    val userByUid: Map<String, UserProfile> = emptyMap(),
    val userByNormDevId: Map<String, UserProfile> = emptyMap(),
    val userByEmail: Map<String, UserProfile> = emptyMap(),
    val deviceByOwnerUid: Map<String, DeviceRecord> = emptyMap(),
    val deviceByNormDevId: Map<String, DeviceRecord> = emptyMap(),
    val totalAccountProCount: Int = 0,
    val totalDeviceProCount: Int = 0,
    val deduplicatedPaymentIntents: List<PaymentIntentRecord> = emptyList(),
    val blockedFraudOrUnpaidCount: Int = 0,
    val aiBlockedAlertByNormDevId: Map<String, LicenseManager.AiProChatLogRecord> = emptyMap(),
    val aiBlockedAlertByEmail: Map<String, LicenseManager.AiProChatLogRecord> = emptyMap(),
    val linkedDevicesByUserKey: Map<String, List<DeviceRecord>> = emptyMap(),
    val online24hDevicesCount: Int = 0,
    val online24hUsersCount: Int = 0,
    val guestDevicesCount: Int = 0,
    val boundDevicesCount: Int = 0
)

@Immutable
data class AdminConfigSnapshot(
    val proPrice: String = "50.000đ",
    val proPriceOriginal: String = "80.000đ",
    val accountProPrice: String = "99.000đ",
    val accountProPriceOriginal: String = "160.000đ",
    val upgradeAccountProPrice: String = "50.000đ",
    val isProSaleActive: Boolean = true,
    val autoFreeDays: String = "30",
    val bankName: String = "",
    val bankCode: String = "",
    val accountNumber: String = "",
    val accountHolder: String = "",
    val supportLink: String = "",
    val youtubeLink: String = "",
    val globalUpdateLink: String = "",
    val showFbHeaderIcon: Boolean = true,
    val showYtHeaderIcon: Boolean = true,
    val isAppFreeMode: Boolean = false,
    val freeTrialLimit: String = "3",
    val groqApiKeyPool: String = "",
    val autoApproveProEnabled: Boolean = false,
    val deviceId: String = "",
    val isNotifListenerGranted: Boolean = false,
    val isShizukuLockedRemotely: Boolean = false,
    val simulateFreeMode: Boolean = false,
    val isLoaded: Boolean = false,
    val updatedAtMs: Long = 0L
)

@Immutable
data class AdminDashboardSnapshot(
    val users: List<UserProfile> = emptyList(),
    val devices: List<DeviceRecord> = emptyList(),
    val paymentIntents: List<PaymentIntentRecord> = emptyList(),
    val approvedIntents: List<PaymentIntentRecord> = emptyList(),
    val proRecoveries: List<LicenseManager.ProRecoveryRecord> = emptyList(),
    val aiLogs: List<LicenseManager.AiProChatLogRecord> = emptyList(),
    val storeApps: List<HonorAppItem> = emptyList(),
    val lastSyncTimestampMs: Long = 0L,
    val lastSyncLabel: String = "",
    val isFromOfflineCacheOnly: Boolean = false,
    val isOfflineHydrated: Boolean = false,
    val isSyncing: Boolean = false
)

internal fun deduplicateRealDevices(devsSnap: List<DeviceRecord>): List<DeviceRecord> {
    return devsSnap
        .filter { d ->
            val rawId = d.deviceId.trim()
            if (rawId.contains("@")) return@filter false
            val normId = LicenseManager.normalizeDeviceIdForMatch(rawId)
            val isPlaceholderId = normId.isBlank() || normId == "UNKNOWN" || normId == "NULL" || normId == "DEFAULT"
            val isEffectivePro = d.isPro && !d.revokedByAdmin
            (!isPlaceholderId && normId.length >= 4) || isEffectivePro
        }
        .groupBy { d ->
            val normId = LicenseManager.normalizeDeviceIdForMatch(d.deviceId)
            if (normId.isNotBlank()) normId else "RAW_${d.deviceId.trim().uppercase().ifBlank { d.ownerUid }}"
        }
        .mapNotNull { (_, group) ->
            val primary = group.maxWithOrNull(
                compareBy<DeviceRecord> { it.isPro && !it.revokedByAdmin }
                    .thenBy { it.isAccountPro || it.proTier == "ACCOUNT_PRO" }
                    .thenBy { it.deviceId.trim().startsWith("MT-", ignoreCase = true) }
                    .thenBy { it.proActivatedAt?.toDate()?.time ?: 0L }
                    .thenBy { it.lastActive?.toDate()?.time ?: 0L }
                    .thenBy { it.createdAt?.toDate()?.time ?: 0L }
            ) ?: return@mapNotNull null

            fun isRealEmail(e: String): Boolean {
                val t = e.trim()
                return t.isNotBlank() &&
                    t.contains("@") &&
                    !t.contains("Khách vãng lai", ignoreCase = true) &&
                    !t.contains("Chưa đăng nhập", ignoreCase = true) &&
                    !t.contains("Ẩn danh", ignoreCase = true)
            }

            val bestDeviceId = group.firstOrNull { it.deviceId.trim().startsWith("MT-", ignoreCase = true) }?.deviceId
                ?: primary.deviceId
            val bestHwId = group.firstOrNull { it.hardwareId.isNotBlank() }?.hardwareId ?: primary.hardwareId
            val bestModel = group.firstOrNull {
                it.model.isNotBlank() && !it.model.equals("Thiết bị Android", ignoreCase = true)
            }?.model ?: primary.model
            val bestOwnerEmail = group.firstOrNull { isRealEmail(it.ownerEmail) }?.ownerEmail ?: primary.ownerEmail
            val bestOwnerUid = group.firstOrNull { it.ownerUid.isNotBlank() }?.ownerUid ?: primary.ownerUid
            val bestOwnerName = group.firstOrNull {
                it.ownerName.isNotBlank() &&
                    !it.ownerName.equals("Khách vãng lai", ignoreCase = true) &&
                    !it.ownerName.equals("Thiết bị không tài khoản", ignoreCase = true)
            }?.ownerName ?: primary.ownerName
            val bestLicenseKey = group.firstOrNull { it.licenseKey.isNotBlank() }?.licenseKey ?: primary.licenseKey
            val bestReason = group.firstOrNull { it.approvedByAiReason.isNotBlank() }?.approvedByAiReason ?: primary.approvedByAiReason
            val bestTransCode = group.firstOrNull { it.bankTransCode.isNotBlank() }?.bankTransCode ?: primary.bankTransCode
            val bestLastActive = group.mapNotNull { it.lastActive }.maxByOrNull { it.toDate().time } ?: primary.lastActive
            val bestCreatedAt = group.mapNotNull { it.createdAt }.minByOrNull { it.toDate().time } ?: primary.createdAt
            val bestProAt = group.mapNotNull { it.proActivatedAt }.maxByOrNull { it.toDate().time } ?: primary.proActivatedAt
            val maxTrial = group.maxOfOrNull { it.freeTrialUsed } ?: primary.freeTrialUsed

            val anyNonRevokedPro = group.any {
                !it.revokedByAdmin && (it.isPro || it.isAccountPro || it.upgradedToAccountPro || it.licenseKey.length >= 12)
            }
            val effRevoked = group.all { it.revokedByAdmin } || (!anyNonRevokedPro && group.any { it.revokedByAdmin })
            val effAccPro = !effRevoked && group.any { !it.revokedByAdmin && (it.isAccountPro || it.proTier == "ACCOUNT_PRO") }
            val effUpgraded = !effRevoked && group.any { !it.revokedByAdmin && it.upgradedToAccountPro }
            val effPro = !effRevoked && anyNonRevokedPro
            val effTier = when {
                effRevoked -> "FREE"
                effAccPro -> "ACCOUNT_PRO"
                effPro -> "DEVICE_PRO"
                else -> "FREE"
            }

            primary.copy(
                deviceId = bestDeviceId,
                hardwareId = bestHwId,
                model = bestModel,
                isPro = effPro,
                isAccountPro = effAccPro,
                upgradedToAccountPro = effUpgraded,
                proTier = effTier,
                revokedByAdmin = effRevoked,
                ownerUid = bestOwnerUid,
                ownerEmail = bestOwnerEmail,
                ownerName = bestOwnerName,
                freeTrialUsed = maxTrial,
                licenseKey = bestLicenseKey,
                approvedByAiReason = bestReason,
                bankTransCode = bestTransCode,
                lastActive = bestLastActive,
                createdAt = bestCreatedAt,
                proActivatedAt = bestProAt
            )
        }
}

internal fun deduplicateRealUsers(usersSnap: List<UserProfile>): List<UserProfile> {
    val uidToEmail = usersSnap
        .asSequence()
        .filter { it.userId.isNotBlank() && it.email.trim().contains("@") }
        .associate { it.userId.trim() to it.email.trim().lowercase() }

    return usersSnap
        .filter { u ->
            val resolvedEmail = u.email.trim().lowercase().ifBlank { uidToEmail[u.userId.trim()].orEmpty() }
            val hasIdentity = resolvedEmail.isNotBlank() || u.phoneNumber.isNotBlank() ||
                (u.displayName.isNotBlank() && !u.displayName.equals("Chưa đặt tên", ignoreCase = true)) ||
                u.isPro || u.role == "admin"
            hasIdentity && (resolvedEmail.isNotBlank() || u.userId.isNotBlank())
        }
        .groupBy { u ->
            val resolvedEmail = u.email.trim().lowercase().ifBlank { uidToEmail[u.userId.trim()].orEmpty() }
            resolvedEmail.ifBlank { "UID_${u.userId.trim()}" }
        }
        .mapNotNull { (_, group) ->
            val primary = group.maxWithOrNull(
                compareBy<UserProfile> { it.role == "admin" }
                    .thenBy { it.isPro && !it.revokedByAdmin }
                    .thenBy { it.isAccountPro || it.proTier == "ACCOUNT_PRO" }
                    .thenBy { it.email.trim().contains("@") }
                    .thenBy { it.displayName.isNotBlank() && !it.displayName.equals("Chưa đặt tên", ignoreCase = true) }
                    .thenBy { it.lastActive?.toDate()?.time ?: 0L }
                    .thenBy { it.createdAt?.toDate()?.time ?: 0L }
            ) ?: return@mapNotNull null

            val bestUid = group.firstOrNull {
                val id = it.userId.trim()
                id.isNotBlank() &&
                    !id.startsWith("email_", ignoreCase = true) &&
                    !id.startsWith("manual_", ignoreCase = true)
            }?.userId ?: primary.userId
            val resolvedEmail = group.firstOrNull { it.email.trim().contains("@") }?.email?.trim()
                ?: uidToEmail[primary.userId.trim()].orEmpty()
            val bestName = group.firstOrNull {
                it.displayName.isNotBlank() && !it.displayName.equals("Chưa đặt tên", ignoreCase = true)
            }?.displayName ?: primary.displayName
            val bestPhone = group.firstOrNull { it.phoneNumber.isNotBlank() }?.phoneNumber ?: primary.phoneNumber
            val bestDevId = group.firstOrNull { it.deviceId.isNotBlank() }?.deviceId ?: primary.deviceId
            val bestHwId = group.firstOrNull { it.hardwareId.isNotBlank() }?.hardwareId ?: primary.hardwareId
            val bestActiveDevId = group.firstOrNull { it.activeDeviceId.isNotBlank() }?.activeDeviceId ?: primary.activeDeviceId
            val bestActiveModel = group.firstOrNull { it.activeDeviceModel.isNotBlank() }?.activeDeviceModel ?: primary.activeDeviceModel
            val bestKey = group.firstOrNull { it.licenseKey.isNotBlank() }?.licenseKey ?: primary.licenseKey
            val bestSrc = group.firstOrNull { it.proActivatedSource.isNotBlank() }?.proActivatedSource ?: primary.proActivatedSource
            val bestTrans = group.firstOrNull { it.bankTransCode.isNotBlank() }?.bankTransCode ?: primary.bankTransCode
            val bestLastActive = group.mapNotNull { it.lastActive }.maxByOrNull { it.toDate().time } ?: primary.lastActive
            val bestCreatedAt = group.mapNotNull { it.createdAt }.minByOrNull { it.toDate().time } ?: primary.createdAt
            val bestProAt = group.mapNotNull { it.proActivatedAt }.maxByOrNull { it.toDate().time } ?: primary.proActivatedAt

            val effRole = if (group.any { it.role == "admin" }) "admin" else primary.role
            val anyNonRevokedPro = group.any { !it.revokedByAdmin && (it.isPro || it.isAccountPro || it.proTier == "ACCOUNT_PRO") }
            val effRevoked = group.all { it.revokedByAdmin } || (!anyNonRevokedPro && group.any { it.revokedByAdmin })
            val effAccPro = !effRevoked && (effRole == "admin" || group.any { !it.revokedByAdmin && (it.isAccountPro || it.proTier == "ACCOUNT_PRO") })
            val effPro = !effRevoked && (anyNonRevokedPro || effAccPro)
            val effTier = when {
                effRevoked -> "FREE"
                effAccPro -> "ACCOUNT_PRO"
                effPro -> "DEVICE_PRO"
                else -> "FREE"
            }

            primary.copy(
                userId = bestUid,
                email = resolvedEmail.ifBlank { primary.email },
                displayName = bestName,
                phoneNumber = bestPhone,
                role = effRole,
                isPro = effPro,
                isAccountPro = effAccPro,
                proTier = effTier,
                revokedByAdmin = effRevoked,
                deviceId = bestDevId,
                hardwareId = bestHwId,
                activeDeviceId = bestActiveDevId,
                activeDeviceModel = bestActiveModel,
                licenseKey = bestKey,
                proActivatedSource = bestSrc,
                bankTransCode = bestTrans,
                lastActive = bestLastActive,
                createdAt = bestCreatedAt,
                proActivatedAt = bestProAt
            )
        }
}

/**
 * Trung tâm bộ nhớ đệm Quản trị viên Offline + Realtime:
 * - Giữ nguyên toàn bộ dữ liệu trong RAM khi chuyển tab (0ms mở lại trang Quản Trị, không bao giờ về 0).
 * - Lưu bền vững xuống tệp JSON gọn nhẹ riêng trong `filesDir/admin_offline_cache/admin_snapshot_v2.json`
 *   thay vì ghi XML khổng lồ vào SharedPreferences (loại bỏ hoàn toàn đơ QueuedWork / ANR / OOM văng app).
 * - Gộp (coalesce) các luồng REST + Firestore Listener để giao diện chỉ cập nhật gọn gàng, mượt 120fps.
 */
object AdminSessionCache {

    private const val CACHE_DIR = "admin_offline_cache"
    private const val SNAPSHOT_FILE = "admin_snapshot_v2.json"

    private val appScope = CoroutineScope(
        SupervisorJob() + Dispatchers.IO + com.example.MagicTuneApplication.globalCoroutineExceptionHandler
    )
    private val snapshotMutex = Mutex()
    private val diskWriteLock = Any()
    private val isRefreshInFlight = AtomicBoolean(false)
    private val isPrewarmStarted = AtomicBoolean(false)
    private val activeListenerHolders = AtomicInteger(0)

    private val _snapshotFlow = MutableStateFlow(AdminDashboardSnapshot())
    val snapshotFlow: StateFlow<AdminDashboardSnapshot> = _snapshotFlow.asStateFlow()

    private val _derivedStateFlow = MutableStateFlow(AdminDerivedUiState())
    val derivedStateFlow: StateFlow<AdminDerivedUiState> = _derivedStateFlow.asStateFlow()

    private val _adminConfigFlow = MutableStateFlow(AdminConfigSnapshot())
    val adminConfigFlow: StateFlow<AdminConfigSnapshot> = _adminConfigFlow.asStateFlow()

    @Volatile
    private var lastManualRefreshMs: Long = 0L

    @Volatile
    private var hasEverSyncedOnline: Boolean = false

    private var diskSaveJob: Job? = null
    private var realtimeRootJob: Job? = null
    private var coalesceFlushJob: Job? = null
    private var recoveryReg: ListenerRegistration? = null
    private var chatLogsReg: ListenerRegistration? = null

    @Volatile
    private var pendingUsers: List<UserProfile>? = null
    @Volatile
    private var pendingDevices: List<DeviceRecord>? = null
    @Volatile
    private var pendingIntents: List<PaymentIntentRecord>? = null
    @Volatile
    private var pendingRecoveries: List<LicenseManager.ProRecoveryRecord>? = null
    @Volatile
    private var pendingLogs: List<LicenseManager.AiProChatLogRecord>? = null
    @Volatile
    private var pendingApps: List<HonorAppItem>? = null

    private fun mergeAdminUsers(existing: List<UserProfile>, incoming: List<UserProfile>): List<UserProfile> {
        val byId = LinkedHashMap<String, UserProfile>(existing.size + incoming.size)
        (existing + incoming).forEach { user ->
            val key = user.userId.trim().ifBlank { user.email.trim().lowercase(Locale.ROOT) }
                .ifBlank { "${user.displayName}:${user.phoneNumber}" }
            if (key.isNotBlank()) byId[key] = user
        }
        return byId.values.sortedWith(
            compareByDescending<UserProfile> { it.isPro }
                .thenByDescending { it.proActivatedAt?.toDate()?.time ?: it.lastActive?.toDate()?.time ?: it.createdAt?.toDate()?.time ?: 0L }
        )
    }

    private fun mergeAdminDevices(existing: List<DeviceRecord>, incoming: List<DeviceRecord>): List<DeviceRecord> {
        val byId = LinkedHashMap<String, DeviceRecord>(existing.size + incoming.size)
        (existing + incoming).forEach { device ->
            val normalizedId = LicenseManager.normalizeDeviceIdForMatch(device.deviceId)
            val key = normalizedId.ifBlank {
                "${device.deviceId.trim().uppercase(Locale.ROOT)}:${device.ownerUid}:${device.ownerEmail.trim().lowercase(Locale.ROOT)}"
            }
            if (key.isNotBlank()) byId[key] = device
        }
        return byId.values.sortedWith(
            compareByDescending<DeviceRecord> { it.isPro }
                .thenByDescending { it.proActivatedAt?.toDate()?.time ?: it.lastActive?.toDate()?.time ?: it.createdAt?.toDate()?.time ?: 0L }
        )
    }

    suspend fun appendUsersPage(users: List<UserProfile>) = withContext(Dispatchers.IO) {
        if (users.isEmpty()) return@withContext
        val next = snapshotMutex.withLock {
            val current = _snapshotFlow.value
            current.copy(users = mergeAdminUsers(current.users, users))
        }
        applySnapshotWithDerived(next, saveToDisk = false)
    }

    suspend fun appendDevicesPage(devices: List<DeviceRecord>) = withContext(Dispatchers.IO) {
        if (devices.isEmpty()) return@withContext
        val next = snapshotMutex.withLock {
            val current = _snapshotFlow.value
            current.copy(devices = mergeAdminDevices(current.devices, devices))
        }
        applySnapshotWithDerived(next, saveToDisk = false)
    }

    private val tlTimeOnly = ThreadLocal.withInitial {
        SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    }
    private val tlDateTimeShort = ThreadLocal.withInitial {
        SimpleDateFormat("HH:mm dd/MM", Locale.getDefault())
    }

    private fun formatTimeOnly(ms: Long): String = try {
        (tlTimeOnly.get() ?: SimpleDateFormat("HH:mm:ss", Locale.getDefault())).format(Date(ms))
    } catch (_: Throwable) { "" }

    private fun formatOfflineLabel(ms: Long): String {
        if (ms <= 0L) return "📦 Dữ liệu Offline đã lưu trên máy"
        val formatted = try {
            (tlDateTimeShort.get() ?: SimpleDateFormat("HH:mm dd/MM", Locale.getDefault())).format(Date(ms))
        } catch (_: Throwable) { "" }
        return if (formatted.isNotBlank()) "📦 Offline (lưu lúc $formatted)" else "📦 Dữ liệu Offline đã lưu"
    }

    private fun formatSyncedLabel(ms: Long): String {
        val t = formatTimeOnly(if (ms > 0L) ms else System.currentTimeMillis())
        return "✅ Đồng bộ Kép (REST + Realtime): $t"
    }

    /**
     * Đọc toàn bộ 20+ cấu hình Quản trị viên (EncryptedSharedPreferences / Keystore / Settings.Secure)
     * trong MỘT lượt duy nhất trên Dispatchers.IO rồi lưu nóng vào RAM (`adminConfigFlow`).
     * Giúp màn hình Quản Trị mở lên 0ms không bao giờ chạm đĩa hay Binder IPC trên Main Thread.
     */
    suspend fun loadAdminConfigSnapshot(context: Context): AdminConfigSnapshot = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext
        val snap = AdminConfigSnapshot(
            proPrice = runCatching { LicenseManager.getProPrice(appCtx) }.getOrDefault("50.000đ"),
            proPriceOriginal = runCatching { LicenseManager.getProOriginalPrice(appCtx) }.getOrDefault("80.000đ"),
            accountProPrice = runCatching { LicenseManager.getAccountProPrice(appCtx) }.getOrDefault("99.000đ"),
            accountProPriceOriginal = runCatching { LicenseManager.getAccountProOriginalPrice(appCtx) }.getOrDefault("160.000đ"),
            upgradeAccountProPrice = runCatching { LicenseManager.getUpgradeToAccountProPrice(appCtx) }.getOrDefault("50.000đ"),
            isProSaleActive = runCatching { LicenseManager.isProSaleActive(appCtx) }.getOrDefault(true),
            autoFreeDays = runCatching { LicenseManager.getAutoFreeInactivityDays(appCtx).toString() }.getOrDefault("30"),
            bankName = runCatching { LicenseManager.getPaymentBankName(appCtx) }.getOrDefault(""),
            bankCode = runCatching { LicenseManager.getPaymentBankCode(appCtx) }.getOrDefault(""),
            accountNumber = runCatching { LicenseManager.getPaymentAccountNumber(appCtx) }.getOrDefault(""),
            accountHolder = runCatching { LicenseManager.getPaymentAccountHolder(appCtx) }.getOrDefault(""),
            supportLink = runCatching { LicenseManager.getFacebookLink(appCtx) }.getOrDefault(""),
            youtubeLink = runCatching { LicenseManager.getCustomYouTubeUrl(appCtx) }.getOrDefault(""),
            globalUpdateLink = runCatching { LicenseManager.getGoogleDriveUpdateLink(appCtx) }.getOrDefault(""),
            showFbHeaderIcon = runCatching { LicenseManager.isFacebookHeaderIconVisible(appCtx) }.getOrDefault(true),
            showYtHeaderIcon = runCatching { LicenseManager.isYouTubeHeaderIconVisible(appCtx) }.getOrDefault(true),
            isAppFreeMode = runCatching { LicenseManager.isAppFreeMode(appCtx) }.getOrDefault(false),
            freeTrialLimit = runCatching { LicenseManager.getFreeTrialLimit(appCtx).toString() }.getOrDefault("3"),
            groqApiKeyPool = runCatching { LicenseManager.getCombinedAiApiKeyPool(appCtx) }.getOrDefault(""),
            autoApproveProEnabled = runCatching { LicenseManager.isAutoApproveNotificationPaymentEnabled(appCtx) }.getOrDefault(false),
            deviceId = runCatching { LicenseManager.getDeviceId(appCtx) }.getOrDefault(""),
            isNotifListenerGranted = runCatching { LicenseManager.isNotificationListenerGranted(appCtx) }.getOrDefault(false),
            isShizukuLockedRemotely = runCatching { LicenseManager.isShizukuConnectionDisabled(appCtx) }.getOrDefault(false),
            simulateFreeMode = runCatching { LicenseManager.isAdminSimulateFreeMode(appCtx) }.getOrDefault(false),
            isLoaded = true,
            updatedAtMs = System.currentTimeMillis()
        )
        _adminConfigFlow.value = snap
        snap
    }

    /**
     * Nạp sẵn toàn bộ dữ liệu Quản trị viên (Cấu hình + Snapshot Offline + Đồng bộ ngầm Cloud)
     * ngay lúc khởi động ứng dụng để khi bấm vào trang Quản Trị lần đầu tiên là hiện tức thì 0ms, không đơ lag.
     */
    fun prewarmAllAdminDataAsync(context: Context) {
        val appCtx = context.applicationContext
        if (!isPrewarmStarted.compareAndSet(false, true)) return
        appScope.launch {
            supervisorScope {
                launch {
                    runCatching { loadAdminConfigSnapshot(appCtx) }
                }
                launch {
                    runCatching { ensureOfflineHydrated(appCtx) }
                }
            }
            // Đồng bộ cấu hình toàn cầu & số liệu đám mây âm thầm dưới nền
            runCatching {
                LicenseManager.fetchGlobalConfigNow(appCtx) {
                    appScope.launch {
                        runCatching { loadAdminConfigSnapshot(appCtx) }
                    }
                }
            }
            // Chỉ tải sẵn offline disk cache cực nhẹ, không tự động kéo REST toàn bộ khi mở app
            // Giữ RAM luôn mát mẻ dưới 120MB; dữ liệu Cloud chỉ nạp khi Admin chủ động mở trang Quản Trị
        }
    }

    fun hydrateFromOfflineDiskAsync(context: Context) {
        val appCtx = context.applicationContext
        appScope.launch {
            ensureOfflineHydrated(appCtx)
        }
    }

    suspend fun ensureOfflineHydrated(context: Context) = withContext(Dispatchers.IO) {
        if (_snapshotFlow.value.isOfflineHydrated && _snapshotFlow.value.hasAnyData()) {
            return@withContext
        }
        val appCtx = context.applicationContext
        val loaded = readOfflineSnapshotFromDisk(appCtx)
        if (loaded != null) {
            applySnapshotWithDerived(loaded, saveToDisk = false)
        } else {
            // Đánh dấu đã kiểm tra disk để tránh lặp lại khi máy mới hoàn toàn
            snapshotMutex.withLock {
                if (!_snapshotFlow.value.isOfflineHydrated) {
                    _snapshotFlow.value = _snapshotFlow.value.copy(isOfflineHydrated = true)
                }
            }
        }
    }

    private fun AdminDashboardSnapshot.hasAnyData(): Boolean {
        return users.isNotEmpty() ||
            devices.isNotEmpty() ||
            paymentIntents.isNotEmpty() ||
            approvedIntents.isNotEmpty() ||
            proRecoveries.isNotEmpty() ||
            aiLogs.isNotEmpty() ||
            storeApps.isNotEmpty()
    }

    fun refreshFromCloud(
        context: Context,
        force: Boolean = false,
        onFinished: ((syncedOnline: Boolean, uniqueDevices: Int, uniqueUsers: Int, message: String) -> Unit)? = null
    ) {
        val appCtx = context.applicationContext
        val now = System.currentTimeMillis()
        if (force && isRefreshInFlight.get() && (now - lastManualRefreshMs) < 2_500L) {
            onFinished?.invoke(true, _derivedStateFlow.value.mergedDevices.size, _derivedStateFlow.value.mergedUsers.size, "⚡ Đang cập nhật dữ liệu mới nhất...")
            return
        }
        if (!isRefreshInFlight.compareAndSet(false, true)) {
            if (force) {
                onFinished?.invoke(true, _derivedStateFlow.value.mergedDevices.size, _derivedStateFlow.value.mergedUsers.size, "⚡ Đang đồng bộ dữ liệu dưới nền...")
            }
            return
        }
        if (force) lastManualRefreshMs = now

        appScope.launch {
            var syncedOnline = false
            var resultMsg = ""
            try {
                // Bảo đảm dữ liệu offline đã lên RAM trước khi chờ mạng
                ensureOfflineHydrated(appCtx)
                snapshotMutex.withLock {
                    _snapshotFlow.value = _snapshotFlow.value.copy(isSyncing = true)
                }

                // Nạp song song và đẩy từng phần dữ liệu lên RAM ngay khi có phản hồi (không chờ luồng chậm nhất)
                val fetched = withTimeoutOrNull(14_000L) {
                    supervisorScope {
                        val usersDef = async {
                            runCatching { FirebaseAuthManager.fetchAllUsersViaRest(appCtx, forceRefresh = force) }
                                .getOrNull()
                                ?.also { list ->
                                    if (list.isNotEmpty()) {
                                        pendingUsers = list
                                        scheduleCoalescedFlush(appCtx, delayMs = 120L)
                                    }
                                }
                        }
                        val devsDef = async {
                            runCatching { FirebaseAuthManager.fetchAllDevicesViaRest(appCtx, forceRefresh = force) }
                                .getOrNull()
                                ?.also { list ->
                                    if (list.isNotEmpty()) {
                                        pendingDevices = list
                                        scheduleCoalescedFlush(appCtx, delayMs = 120L)
                                    }
                                }
                        }
                        val intentsDef = async {
                            runCatching { FirebaseAuthManager.fetchPaymentIntentsViaRest(appCtx, forceRefresh = force) }
                                .getOrNull()
                                ?.also { list ->
                                    if (list.isNotEmpty()) {
                                        pendingIntents = list
                                        scheduleCoalescedFlush(appCtx, delayMs = 120L)
                                    }
                                }
                        }
                        val recsDef = async {
                            runCatching { LicenseManager.fetchProRecoveryRequestsViaRest(appCtx, forceRefresh = force) }
                                .getOrNull()
                                ?.also { list ->
                                    if (list.isNotEmpty()) {
                                        pendingRecoveries = list
                                        scheduleCoalescedFlush(appCtx, delayMs = 120L)
                                    }
                                }
                        }
                        val logsDef = async {
                            runCatching { LicenseManager.fetchAiProChatLogsViaRest(appCtx, forceRefresh = force) }
                                .getOrNull()
                                ?.also { list ->
                                    if (list.isNotEmpty()) {
                                        pendingLogs = list
                                        scheduleCoalescedFlush(appCtx, delayMs = 120L)
                                    }
                                }
                        }
                        val appsDef = async {
                            runCatching { FirebaseAuthManager.fetchHonorAppsViaRest(appCtx, forceRefresh = force) }
                                .getOrNull()
                                ?.also { list ->
                                    if (list.isNotEmpty()) {
                                        pendingApps = list
                                        scheduleCoalescedFlush(appCtx, delayMs = 120L)
                                    }
                                }
                        }
                        listOf(
                            usersDef.await(),
                            devsDef.await(),
                            intentsDef.await(),
                            recsDef.await(),
                            logsDef.await(),
                            appsDef.await()
                        )
                    }
                }

                if (fetched == null) {
                    val cur = _snapshotFlow.value
                    val fallbackLabel = if (cur.hasAnyData()) formatOfflineLabel(cur.lastSyncTimestampMs) else cur.lastSyncLabel
                    snapshotMutex.withLock {
                        _snapshotFlow.value = _snapshotFlow.value.copy(
                            isSyncing = false,
                            isFromOfflineCacheOnly = !hasEverSyncedOnline && cur.hasAnyData(),
                            lastSyncLabel = fallbackLabel
                        )
                    }
                    resultMsg = if (cur.hasAnyData()) {
                        "📦 Mạng yếu/Offline — Đang hiển thị dữ liệu đã lưu trên máy!"
                    } else {
                        "⏱️ Hết thời gian chờ mạng (14s). Vui lòng thử lại!"
                    }
                } else {
                    @Suppress("UNCHECKED_CAST")
                    val uList = fetched[0] as? List<UserProfile>
                    @Suppress("UNCHECKED_CAST")
                    val dList = fetched[1] as? List<DeviceRecord>
                    @Suppress("UNCHECKED_CAST")
                    val iList = fetched[2] as? List<PaymentIntentRecord>
                    @Suppress("UNCHECKED_CAST")
                    val rList = fetched[3] as? List<LicenseManager.ProRecoveryRecord>
                    @Suppress("UNCHECKED_CAST")
                    val lList = fetched[4] as? List<LicenseManager.AiProChatLogRecord>
                    @Suppress("UNCHECKED_CAST")
                    val aList = fetched[5] as? List<HonorAppItem>

                    val cur = _snapshotFlow.value
                    val gotAnyFreshList = (uList != null && uList.isNotEmpty()) ||
                        (dList != null && dList.isNotEmpty()) ||
                        (iList != null && iList.isNotEmpty()) ||
                        (rList != null && rList.isNotEmpty()) ||
                        (lList != null && lList.isNotEmpty()) ||
                        (aList != null && aList.isNotEmpty())

                    val syncTs = if (gotAnyFreshList) System.currentTimeMillis() else cur.lastSyncTimestampMs
                    if (gotAnyFreshList) {
                        hasEverSyncedOnline = true
                        LicenseManager.saveAdminLastGlobalSyncMs(appCtx, syncTs)
                    }

                    val nextSnapshot = cur.copy(
                        users = if (uList != null && uList.isNotEmpty()) mergeAdminUsers(cur.users, uList) else cur.users,
                        devices = if (dList != null && dList.isNotEmpty()) mergeAdminDevices(cur.devices, dList) else cur.devices,
                        paymentIntents = if (iList != null && (iList.isNotEmpty() || cur.paymentIntents.isEmpty() || gotAnyFreshList)) iList else cur.paymentIntents,
                        proRecoveries = if (rList != null && (rList.isNotEmpty() || cur.proRecoveries.isEmpty() || gotAnyFreshList)) rList else cur.proRecoveries,
                        aiLogs = if (lList != null && (lList.isNotEmpty() || cur.aiLogs.isEmpty() || gotAnyFreshList)) lList else cur.aiLogs,
                        storeApps = if (aList != null && (aList.isNotEmpty() || cur.storeApps.isEmpty())) aList else cur.storeApps,
                        lastSyncTimestampMs = syncTs,
                        lastSyncLabel = if (gotAnyFreshList) formatSyncedLabel(syncTs) else formatOfflineLabel(syncTs),
                        isFromOfflineCacheOnly = !gotAnyFreshList && !hasEverSyncedOnline && cur.hasAnyData(),
                        isOfflineHydrated = true,
                        isSyncing = false
                    )
                    applySnapshotWithDerived(nextSnapshot, saveToDisk = gotAnyFreshList)
                    syncedOnline = gotAnyFreshList
                    val devCount = _derivedStateFlow.value.mergedDevices.size
                    val usrCount = _derivedStateFlow.value.mergedUsers.size
                    resultMsg = if (gotAnyFreshList) {
                        "✅ Đã làm mới số liệu ($devCount thiết bị, $usrCount tài khoản thực tế)"
                    } else {
                        "📦 Chưa có mạng — Đang giữ dữ liệu Offline đã lưu ($devCount thiết bị, $usrCount tài khoản)"
                    }
                }
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                snapshotMutex.withLock {
                    _snapshotFlow.value = _snapshotFlow.value.copy(isSyncing = false)
                }
                resultMsg = "⚠️ Lỗi làm mới dữ liệu: ${t.localizedMessage ?: t.message}"
            } finally {
                isRefreshInFlight.set(false)
                snapshotMutex.withLock {
                    if (_snapshotFlow.value.isSyncing) {
                        _snapshotFlow.value = _snapshotFlow.value.copy(isSyncing = false)
                    }
                }
                if (onFinished != null) {
                    val devCount = _derivedStateFlow.value.mergedDevices.size
                    val usrCount = _derivedStateFlow.value.mergedUsers.size
                    withContext(Dispatchers.Main) {
                        onFinished(syncedOnline, devCount, usrCount, resultMsg)
                    }
                }
            }
        }
    }

    fun attachRealtimeListeners(context: Context) {
        val appCtx = context.applicationContext
        val holders = activeListenerHolders.incrementAndGet()
        if (holders > 1 && realtimeRootJob?.isActive == true) return

        realtimeRootJob?.cancel()
        try { recoveryReg?.remove() } catch (_: Throwable) {}
        try { chatLogsReg?.remove() } catch (_: Throwable) {}
        recoveryReg = null
        chatLogsReg = null

        realtimeRootJob = appScope.launch {
            // Giãn nhịp gắn 6 listener để khung hình đầu tiên của trang Quản Trị luôn đạt 120fps
            delay(if (_snapshotFlow.value.isOfflineHydrated) 350L else 600L)

            try {
                recoveryReg = LicenseManager.observeProRecoveryRequests(appCtx) { list ->
                    if (list.isNotEmpty() || _snapshotFlow.value.proRecoveries.isEmpty()) {
                        pendingRecoveries = list
                        scheduleCoalescedFlush(appCtx)
                    }
                }
            } catch (_: Throwable) {}

            delay(60L)
            try {
                chatLogsReg = LicenseManager.observeAiProChatLogs(appCtx) { list ->
                    if (list.isNotEmpty() || _snapshotFlow.value.aiLogs.isEmpty()) {
                        pendingLogs = list
                        scheduleCoalescedFlush(appCtx)
                    }
                }
            } catch (_: Throwable) {}

            delay(60L)
            launch {
                try {
                    FirebaseAuthManager.observeAllUsers(appCtx).conflate().collect { list ->
                        if (list.isNotEmpty() || _snapshotFlow.value.users.isEmpty()) {
                            pendingUsers = list
                            scheduleCoalescedFlush(appCtx)
                        }
                    }
                } catch (_: Throwable) {}
            }
            delay(60L)
            launch {
                try {
                    FirebaseAuthManager.observeAllDevices(appCtx).conflate().collect { list ->
                        if (list.isNotEmpty() || _snapshotFlow.value.devices.isEmpty()) {
                            pendingDevices = list
                            scheduleCoalescedFlush(appCtx)
                        }
                    }
                } catch (_: Throwable) {}
            }
            delay(60L)
            launch {
                try {
                    FirebaseAuthManager.observePaymentIntents(appCtx).conflate().collect { list ->
                        if (list.isNotEmpty() || _snapshotFlow.value.paymentIntents.isEmpty()) {
                            pendingIntents = list
                            scheduleCoalescedFlush(appCtx)
                        }
                    }
                } catch (_: Throwable) {}
            }
            delay(60L)
            launch {
                try {
                    FirebaseAuthManager.observeHonorApps(appCtx).conflate().collect { list ->
                        if (list.isNotEmpty() || _snapshotFlow.value.storeApps.isEmpty()) {
                            pendingApps = list
                            scheduleCoalescedFlush(appCtx)
                        }
                    }
                } catch (_: Throwable) {}
            }
        }
    }

    fun detachRealtimeListeners(force: Boolean = false) {
        if (!force) {
            val remaining = activeListenerHolders.decrementAndGet().coerceAtLeast(0)
            if (remaining > 0) return
        }
        activeListenerHolders.set(0)
        coalesceFlushJob?.cancel()
        coalesceFlushJob = null
        realtimeRootJob?.cancel()
        realtimeRootJob = null
        try { recoveryReg?.remove() } catch (_: Throwable) {}
        try { chatLogsReg?.remove() } catch (_: Throwable) {}
        recoveryReg = null
        chatLogsReg = null
    }

    private fun scheduleCoalescedFlush(context: Context, delayMs: Long = 300L) {
        coalesceFlushJob?.cancel()
        coalesceFlushJob = appScope.launch(Dispatchers.Default) {
            delay(delayMs)
            val u = pendingUsers.also { pendingUsers = null }
            val d = pendingDevices.also { pendingDevices = null }
            val i = pendingIntents.also { pendingIntents = null }
            val r = pendingRecoveries.also { pendingRecoveries = null }
            val l = pendingLogs.also { pendingLogs = null }
            val a = pendingApps.also { pendingApps = null }
            if (u == null && d == null && i == null && r == null && l == null && a == null) return@launch

            val cur = _snapshotFlow.value
            val nextUsers = if (u != null) mergeAdminUsers(cur.users, u) else cur.users
            val nextDevices = if (d != null) mergeAdminDevices(cur.devices, d) else cur.devices
            val nextIntents = i ?: cur.paymentIntents
            val nextRecoveries = r ?: cur.proRecoveries
            val nextLogs = l ?: cur.aiLogs
            val nextApps = a ?: cur.storeApps

            val changed = nextUsers != cur.users ||
                nextDevices != cur.devices ||
                nextIntents != cur.paymentIntents ||
                nextRecoveries != cur.proRecoveries ||
                nextLogs != cur.aiLogs ||
                nextApps != cur.storeApps
            if (!changed) return@launch

            val now = System.currentTimeMillis()
            hasEverSyncedOnline = true
            val next = cur.copy(
                users = nextUsers,
                devices = nextDevices,
                paymentIntents = nextIntents,
                proRecoveries = nextRecoveries,
                aiLogs = nextLogs,
                storeApps = nextApps,
                lastSyncTimestampMs = now,
                lastSyncLabel = formatSyncedLabel(now),
                isFromOfflineCacheOnly = false,
                isOfflineHydrated = true
            )
            applySnapshotWithDerived(next, saveToDisk = false)
            scheduleDebouncedDiskSave(context, next)
        }
    }

    fun updateSnapshot(context: Context, persistImmediately: Boolean = true, transform: (AdminDashboardSnapshot) -> AdminDashboardSnapshot) {
        val appCtx = context.applicationContext
        appScope.launch(Dispatchers.Default) {
            val next = snapshotMutex.withLock {
                val updated = transform(_snapshotFlow.value)
                updated
            }
            applySnapshotWithDerived(next, saveToDisk = persistImmediately)
        }
    }

    fun addApprovedIntent(context: Context, intent: PaymentIntentRecord) {
        updateSnapshot(context, persistImmediately = true) { cur ->
            val updated = listOf(intent) + cur.approvedIntents.filter {
                it.deviceId != intent.deviceId && it.intentId != intent.intentId
            }
            cur.copy(approvedIntents = updated.take(50))
        }
    }

    private suspend fun applySnapshotWithDerived(snapshot: AdminDashboardSnapshot, saveToDisk: Boolean) {
        val computed = withContext(Dispatchers.Default) {
            computeDerivedState(snapshot)
        }
        snapshotMutex.withLock {
            _derivedStateFlow.value = computed
            _snapshotFlow.value = snapshot
        }
        if (saveToDisk) {
            val ctx = appContextRef ?: return
            LicenseManager.saveAdminLastGlobalSyncMs(ctx, snapshot.lastSyncTimestampMs)
            appScope.launch(Dispatchers.IO) {
                writeOfflineSnapshotToDisk(ctx, snapshot)
            }
        }
    }

    private fun scheduleDebouncedDiskSave(context: Context, snapshot: AdminDashboardSnapshot) {
        appContextRef = context.applicationContext
        diskSaveJob?.cancel()
        diskSaveJob = appScope.launch(Dispatchers.IO) {
            delay(2_500L)
            val latest = _snapshotFlow.value
            if (latest.hasAnyData()) {
                LicenseManager.saveAdminLastGlobalSyncMs(context.applicationContext, latest.lastSyncTimestampMs)
                writeOfflineSnapshotToDisk(context.applicationContext, latest)
            } else {
                writeOfflineSnapshotToDisk(context.applicationContext, snapshot)
            }
        }
    }

    @Volatile
    private var appContextRef: Context? = null

    private fun computeDerivedState(snapshot: AdminDashboardSnapshot): AdminDerivedUiState {
        val rawMergedDevices = deduplicateRealDevices(snapshot.devices)
        val rawMergedUsers = deduplicateRealUsers(snapshot.users)
        val logsSnap = snapshot.aiLogs
        val intentsSnap = snapshot.paymentIntents

        val rawUserByUid = rawMergedUsers.asSequence().filter { it.userId.isNotBlank() }.associateBy { it.userId }
        val rawUserByEmail = buildMap<String, UserProfile> {
            rawMergedUsers.forEach { u ->
                val em = u.email.trim().lowercase()
                if (em.contains("@")) {
                    val existing = get(em)
                    val isBetter = existing == null ||
                        (!existing.isAccountPro && u.isAccountPro) ||
                        (!existing.isPro && u.isPro)
                    if (isBetter) put(em, u)
                }
            }
        }
        val rawUserByNormDevId = buildMap<String, UserProfile> {
            for (u in rawMergedUsers) {
                val d1 = LicenseManager.normalizeDeviceIdForMatch(u.deviceId)
                if (d1.isNotBlank()) putIfAbsent(d1, u)
                val d2 = LicenseManager.normalizeDeviceIdForMatch(u.activeDeviceId)
                if (d2.isNotBlank()) putIfAbsent(d2, u)
            }
        }

        // Cross-enrich DeviceRecord với thông tin chủ sở hữu thực tế từ UserProfile (tránh hiện sai "Khách vãng lai")
        val mergedDevices = rawMergedDevices.map { d ->
            val normId = LicenseManager.normalizeDeviceIdForMatch(d.deviceId)
            val cleanDevEmail = d.ownerEmail.trim().lowercase().takeIf {
                it.contains("@") && !it.contains("Khách vãng lai", true) && !it.contains("Chưa đăng nhập", true)
            }
            val matchedUser = (if (d.ownerUid.isNotBlank()) rawUserByUid[d.ownerUid] else null)
                ?: (if (!cleanDevEmail.isNullOrBlank()) rawUserByEmail[cleanDevEmail] else null)
                ?: (if (normId.isNotBlank()) rawUserByNormDevId[normId] else null)
            if (matchedUser != null) {
                val isGuestOrBlankEmail = !d.ownerEmail.contains("@") ||
                    d.ownerEmail.contains("Khách vãng lai", true) ||
                    d.ownerEmail.contains("Chưa đăng nhập", true)
                val isGuestName = d.ownerName.isBlank() ||
                    d.ownerName.equals("Khách vãng lai", true) ||
                    d.ownerName.equals("Thiết bị không tài khoản", true)
                d.copy(
                    ownerUid = d.ownerUid.ifBlank { matchedUser.userId },
                    ownerEmail = if (isGuestOrBlankEmail && matchedUser.email.contains("@")) matchedUser.email else d.ownerEmail,
                    ownerName = if (isGuestName && matchedUser.displayName.isNotBlank() && !matchedUser.displayName.equals("Chưa đặt tên", true)) matchedUser.displayName else d.ownerName
                )
            } else {
                d
            }
        }

        val devByOwnerUid = HashMap<String, MutableList<DeviceRecord>>(mergedDevices.size)
        val devByOwnerEmail = HashMap<String, MutableList<DeviceRecord>>(mergedDevices.size)
        val devByNormId = HashMap<String, DeviceRecord>(mergedDevices.size)

        for (d in mergedDevices) {
            if (d.ownerUid.isNotBlank()) {
                devByOwnerUid.getOrPut(d.ownerUid) { ArrayList(2) }.add(d)
            }
            val em = d.ownerEmail.trim().lowercase()
            if (em.contains("@")) {
                devByOwnerEmail.getOrPut(em) { ArrayList(2) }.add(d)
            }
            val n = LicenseManager.normalizeDeviceIdForMatch(d.deviceId)
            if (n.isNotBlank()) {
                devByNormId[n] = d
            }
        }

        val linkedDevicesByUserKey = HashMap<String, List<DeviceRecord>>(rawMergedUsers.size * 2)
        val mergedUsers = ArrayList<UserProfile>(rawMergedUsers.size)

        for (u in rawMergedUsers) {
            val em = u.email.trim().lowercase()
            val aNorm = LicenseManager.normalizeDeviceIdForMatch(u.activeDeviceId)
            val dNorm = LicenseManager.normalizeDeviceIdForMatch(u.deviceId)

            val seenIds = HashSet<String>(4)
            val candidateDevs = ArrayList<DeviceRecord>(4)

            fun addCandidate(d: DeviceRecord?) {
                if (d != null) {
                    val norm = LicenseManager.normalizeDeviceIdForMatch(d.deviceId).ifBlank { d.deviceId }
                    if (seenIds.add(norm)) candidateDevs.add(d)
                }
            }

            if (u.userId.isNotBlank()) devByOwnerUid[u.userId]?.let { list -> for (d in list) addCandidate(d) }
            if (em.contains("@")) devByOwnerEmail[em]?.let { list -> for (d in list) addCandidate(d) }
            if (aNorm.isNotBlank()) addCandidate(devByNormId[aNorm])
            if (dNorm.isNotBlank()) addCandidate(devByNormId[dNorm])

            if (candidateDevs.size > 1) {
                candidateDevs.sortWith(
                    compareByDescending { it.lastActive?.toDate()?.time ?: it.proActivatedAt?.toDate()?.time ?: 0L }
                )
            }

            val bestLinked = candidateDevs.firstOrNull()
            val enriched = if (bestLinked != null) {
                u.copy(
                    deviceId = u.deviceId.ifBlank { bestLinked.deviceId },
                    activeDeviceId = u.activeDeviceId.ifBlank { bestLinked.deviceId },
                    activeDeviceModel = u.activeDeviceModel.ifBlank { bestLinked.model },
                    hardwareId = u.hardwareId.ifBlank { bestLinked.hardwareId }
                )
            } else {
                u
            }
            mergedUsers.add(enriched)

            if (candidateDevs.isNotEmpty()) {
                if (u.userId.isNotBlank()) linkedDevicesByUserKey[u.userId] = candidateDevs
                if (em.contains("@")) linkedDevicesByUserKey[em] = candidateDevs
            }
        }

        val aiBillLogByNormDevId = logsSnap
            .asSequence()
            .filter { it.proGranted }
            .mapNotNull { log ->
                val norm = LicenseManager.normalizeDeviceIdForMatch(log.deviceId)
                if (norm.isNotBlank()) norm to log else null
            }
            .distinctBy { it.first }
            .toMap()

        val aiBillLogByEmail = logsSnap
            .asSequence()
            .filter { it.proGranted && it.ownerEmail.isNotBlank() }
            .map { it.ownerEmail.trim().lowercase() to it }
            .distinctBy { it.first }
            .toMap()

        val blockedEvents = setOf(
            "FAKE_BILL_DETECTED",
            "REUSED_BILL_BLOCKED",
            "BILL_REJECTED",
            "UNPAID_PRO_REQUEST_BLOCKED"
        )
        val aiBlockedAlertByNormDevId = logsSnap
            .asSequence()
            .filter { !it.proGranted && blockedEvents.contains(it.eventType) }
            .mapNotNull { log ->
                val norm = LicenseManager.normalizeDeviceIdForMatch(log.deviceId)
                if (norm.isNotBlank()) norm to log else null
            }
            .distinctBy { it.first }
            .toMap()

        val aiBlockedAlertByEmail = logsSnap
            .asSequence()
            .filter { !it.proGranted && blockedEvents.contains(it.eventType) && it.ownerEmail.contains("@") }
            .map { it.ownerEmail.trim().lowercase() to it }
            .distinctBy { it.first }
            .toMap()

        val userByUid = mergedUsers
            .asSequence()
            .filter { it.userId.isNotBlank() }
            .associateBy { it.userId }

        val userByNormDevId = buildMap<String, UserProfile> {
            for (u in mergedUsers) {
                val d1 = LicenseManager.normalizeDeviceIdForMatch(u.deviceId)
                if (d1.isNotBlank()) putIfAbsent(d1, u)
                val d2 = LicenseManager.normalizeDeviceIdForMatch(u.activeDeviceId)
                if (d2.isNotBlank()) putIfAbsent(d2, u)
            }
        }

        val userByEmail = buildMap<String, UserProfile> {
            mergedUsers.forEach { u ->
                val em = u.email.trim().lowercase()
                if (em.contains("@")) {
                    val existing = get(em)
                    val isBetter = existing == null ||
                        (!existing.isAccountPro && u.isAccountPro) ||
                        (!existing.isPro && u.isPro)
                    if (isBetter) put(em, u)
                }
            }
        }

        val deviceByOwnerUid = mergedDevices
            .asSequence()
            .filter { it.ownerUid.isNotBlank() }
            .associateBy { it.ownerUid }

        val deviceByNormDevId = mergedDevices
            .asSequence()
            .mapNotNull { d ->
                val norm = LicenseManager.normalizeDeviceIdForMatch(d.deviceId)
                if (norm.isNotBlank()) norm to d else null
            }
            .distinctBy { it.first }
            .toMap()

        val accProTotal = mergedUsers.count {
            it.isPro && !it.revokedByAdmin && (it.isAccountPro || it.proTier == "ACCOUNT_PRO")
        }
        val devProTotal = mergedDevices.count {
            it.isPro && !it.revokedByAdmin && it.deviceId.trim().length >= 4 &&
                !it.isAccountPro && it.proTier != "ACCOUNT_PRO"
        }

        val dayAgoMs = System.currentTimeMillis() - 86_400_000L
        val online24hDevicesCount = mergedDevices.count { (it.lastActive?.toDate()?.time ?: 0L) >= dayAgoMs }
        val online24hUsersCount = mergedUsers.count { (it.lastActive?.toDate()?.time ?: 0L) >= dayAgoMs }
        val guestDevicesCount = mergedDevices.count { d ->
            !d.ownerEmail.contains("@") ||
                d.ownerEmail.contains("Khách vãng lai", true) ||
                d.ownerEmail.contains("Chưa đăng nhập", true)
        }
        val boundDevicesCount = mergedDevices.size - guestDevicesCount

        val deduplicatedIntents = intentsSnap
            .filter { intent ->
                if (intent.isPro) return@filter false
                val combinedText = "${intent.actionType} ${intent.details} ${intent.note}"
                val isUpgradeOrder = combinedText.contains("NANG_CAP", ignoreCase = true) ||
                    combinedText.contains("Nâng Cấp", ignoreCase = true) ||
                    combinedText.contains("Nang Cap", ignoreCase = true) ||
                    combinedText.contains("Package=2", ignoreCase = true) ||
                    combinedText.contains("UPPRO", ignoreCase = true) ||
                    combinedText.contains("PRO_TO_ACCOUNT", ignoreCase = true)
                val isManualReviewBill = intent.actionType.contains("BILL", ignoreCase = true) ||
                    intent.actionType == "CLICKED_I_PAID" ||
                    isUpgradeOrder
                val isAccountPackage = isUpgradeOrder ||
                    combinedText.contains("ACCOUNT", ignoreCase = true) ||
                    combinedText.contains("Tài Khoản", ignoreCase = true)
                val normId = LicenseManager.normalizeDeviceIdForMatch(intent.deviceId)
                val matchedDev = if (normId.isNotBlank()) deviceByNormDevId[normId] else null
                val cleanEmail = intent.ownerEmail.trim().lowercase().substringBefore(" (").trim()
                val matchedUsr = (if (normId.isNotBlank()) userByNormDevId[normId] else null)
                    ?: (if (cleanEmail.contains("@")) userByEmail[cleanEmail] else null)

                val devHasDevicePro = matchedDev != null && matchedDev.isPro && !matchedDev.revokedByAdmin &&
                    !matchedDev.isAccountPro && matchedDev.proTier != "ACCOUNT_PRO"
                val usrHasDevicePro = matchedUsr != null && matchedUsr.isPro && !matchedUsr.revokedByAdmin &&
                    !matchedUsr.isAccountPro && matchedUsr.proTier != "ACCOUNT_PRO"
                val isAlreadyDeviceProOnly = devHasDevicePro || usrHasDevicePro

                val alreadyProInDevices = matchedDev != null && matchedDev.isPro && !matchedDev.revokedByAdmin &&
                    ((!isAccountPackage && !isAlreadyDeviceProOnly) || matchedDev.isAccountPro || matchedDev.proTier == "ACCOUNT_PRO")
                val alreadyProInUsers = matchedUsr != null && matchedUsr.isPro && !matchedUsr.revokedByAdmin &&
                    ((!isAccountPackage && !isAlreadyDeviceProOnly) || matchedUsr.isAccountPro || matchedUsr.proTier == "ACCOUNT_PRO")
                val alreadyFullAccountPro = (matchedDev != null && matchedDev.isPro && !matchedDev.revokedByAdmin && (matchedDev.isAccountPro || matchedDev.proTier == "ACCOUNT_PRO")) ||
                    (matchedUsr != null && matchedUsr.isPro && !matchedUsr.revokedByAdmin && (matchedUsr.isAccountPro || matchedUsr.proTier == "ACCOUNT_PRO"))

                (!alreadyProInDevices && !alreadyProInUsers) || (isManualReviewBill && !intent.isPro && !alreadyFullAccountPro)
            }
            .groupBy { intent ->
                LicenseManager.normalizeDeviceIdForMatch(intent.deviceId).ifBlank {
                    "${intent.ownerEmail.trim().lowercase()}_${intent.model.trim().lowercase()}"
                }
            }
            .mapNotNull { (_, intents) ->
                intents.sortedWith(
                    compareByDescending<PaymentIntentRecord> {
                        it.actionType == "BILL_NEEDS_MANUAL_REVIEW" ||
                            it.actionType == "BILL_SUBMITTED_FOR_REVIEW" ||
                            it.actionType == "CLICKED_I_PAID"
                    }.thenByDescending { it.timestamp?.toDate()?.time ?: 0L }
                ).firstOrNull()
            }
            .sortedByDescending { it.timestamp?.toDate()?.time ?: 0L }

        val blockedCount = logsSnap.count {
            !it.proGranted && (
                it.eventType == "FAKE_BILL_DETECTED" ||
                    it.eventType == "REUSED_BILL_BLOCKED" ||
                    it.eventType == "BILL_REJECTED" ||
                    it.eventType == "UNPAID_PRO_REQUEST_BLOCKED"
                )
        }

        return AdminDerivedUiState(
            mergedDevices = mergedDevices,
            mergedUsers = mergedUsers,
            aiBillLogByNormDevId = aiBillLogByNormDevId,
            aiBillLogByEmail = aiBillLogByEmail,
            userByUid = userByUid,
            userByNormDevId = userByNormDevId,
            userByEmail = userByEmail,
            deviceByOwnerUid = deviceByOwnerUid,
            deviceByNormDevId = deviceByNormDevId,
            totalAccountProCount = accProTotal,
            totalDeviceProCount = devProTotal,
            deduplicatedPaymentIntents = deduplicatedIntents,
            blockedFraudOrUnpaidCount = blockedCount,
            aiBlockedAlertByNormDevId = aiBlockedAlertByNormDevId,
            aiBlockedAlertByEmail = aiBlockedAlertByEmail,
            linkedDevicesByUserKey = linkedDevicesByUserKey,
            online24hDevicesCount = online24hDevicesCount,
            online24hUsersCount = online24hUsersCount,
            guestDevicesCount = guestDevicesCount,
            boundDevicesCount = boundDevicesCount
        )
    }

    private fun getSnapshotFile(context: Context): File {
        val dir = File(context.applicationContext.filesDir, CACHE_DIR)
        if (!dir.exists()) {
            try { dir.mkdirs() } catch (_: Throwable) {}
        }
        return File(dir, SNAPSHOT_FILE)
    }

    private fun tsToMs(ts: Timestamp?): Long = ts?.toDate()?.time ?: 0L

    private fun msToTs(ms: Long): Timestamp? = if (ms > 0L) Timestamp(Date(ms)) else null

    private fun writeOfflineSnapshotToDisk(context: Context, snapshot: AdminDashboardSnapshot) {
        synchronized(diskWriteLock) {
            try {
                val root = JSONObject()
                root.put("lastSyncTimestampMs", snapshot.lastSyncTimestampMs)

                root.put("users", JSONArray().apply {
                    snapshot.users.take(150).forEach { u ->
                        put(JSONObject().apply {
                            put("userId", u.userId)
                            put("email", u.email)
                            put("phoneNumber", u.phoneNumber)
                            put("displayName", u.displayName)
                            put("role", u.role)
                            put("isPro", u.isPro)
                            put("isAccountPro", u.isAccountPro)
                            put("proTier", u.proTier)
                            put("deviceId", u.deviceId)
                            put("hardwareId", u.hardwareId)
                            put("activeDeviceId", u.activeDeviceId)
                            put("activeDeviceModel", u.activeDeviceModel)
                            put("licenseKey", u.licenseKey)
                            put("proActivatedSource", u.proActivatedSource)
                            put("bankTransCode", u.bankTransCode)
                            put("revokedByAdmin", u.revokedByAdmin)
                            put("proActivatedMs", tsToMs(u.proActivatedAt))
                            put("lastActiveMs", tsToMs(u.lastActive))
                            put("createdMs", tsToMs(u.createdAt))
                            put("customGeminiKey", u.customGeminiKey)
                            put("customGroqKey", u.customGroqKey)
                            put("customAiKeyRaw", u.customAiKeyRaw)
                            put("customAiKeyUpdatedMs", tsToMs(u.customAiKeyUpdatedAt))
                        })
                    }
                })

                root.put("devices", JSONArray().apply {
                    snapshot.devices.take(150).forEach { d ->
                        put(JSONObject().apply {
                            put("deviceId", d.deviceId)
                            put("hardwareId", d.hardwareId)
                            put("model", d.model)
                            put("isPro", d.isPro)
                            put("isAccountPro", d.isAccountPro)
                            put("upgradedToAccountPro", d.upgradedToAccountPro)
                            put("proTier", d.proTier)
                            put("revokedByAdmin", d.revokedByAdmin)
                            put("ownerUid", d.ownerUid)
                            put("ownerEmail", d.ownerEmail)
                            put("ownerName", d.ownerName)
                            put("freeTrialUsed", d.freeTrialUsed)
                            put("licenseKey", d.licenseKey)
                            put("approvedByAiReason", d.approvedByAiReason)
                            put("bankTransCode", d.bankTransCode)
                            put("proActivatedMs", tsToMs(d.proActivatedAt))
                            put("lastActiveMs", tsToMs(d.lastActive))
                            put("createdMs", tsToMs(d.createdAt))
                            put("customGeminiKey", d.customGeminiKey)
                            put("customGroqKey", d.customGroqKey)
                            put("customAiKeyRaw", d.customAiKeyRaw)
                            put("customAiKeyUpdatedMs", tsToMs(d.customAiKeyUpdatedAt))
                        })
                    }
                })

                fun serializeIntent(it: PaymentIntentRecord) = JSONObject().apply {
                    put("intentId", it.intentId)
                    put("deviceId", it.deviceId)
                    put("model", it.model)
                    put("ownerEmail", it.ownerEmail)
                    put("ownerName", it.ownerName)
                    put("actionType", it.actionType)
                    put("details", it.details.take(800))
                    put("note", it.note.take(500))
                    put("isPro", it.isPro)
                    put("timestampMs", tsToMs(it.timestamp))
                }

                root.put("paymentIntents", JSONArray().apply {
                    snapshot.paymentIntents.take(40).forEach { put(serializeIntent(it)) }
                })
                root.put("approvedIntents", JSONArray().apply {
                    snapshot.approvedIntents.take(30).forEach { put(serializeIntent(it)) }
                })

                root.put("proRecoveries", JSONArray().apply {
                    snapshot.proRecoveries.take(30).forEach { r ->
                        put(JSONObject().apply {
                            put("id", r.id)
                            put("deviceId", r.deviceId)
                            put("deviceModel", r.deviceModel)
                            put("ownerEmail", r.ownerEmail)
                            put("ownerName", r.ownerName)
                            put("note", r.note.take(600))
                            put("createdMs", LicenseManager.extractTimestampMillis(r.createdAt))
                            put("status", r.status)
                            put("previousProVerified", r.previousProVerified)
                        })
                    }
                })

                root.put("aiLogs", JSONArray().apply {
                    snapshot.aiLogs.take(40).forEach { l ->
                        put(JSONObject().apply {
                            put("id", l.id)
                            put("deviceId", l.deviceId)
                            put("deviceModel", l.deviceModel)
                            put("ownerEmail", l.ownerEmail)
                            put("ownerName", l.ownerName)
                            put("userMessage", l.userMessage.take(900))
                            put("aiReply", l.aiReply.take(1100))
                            put("eventType", l.eventType)
                            put("proGranted", l.proGranted)
                            put("grantedTier", l.grantedTier)
                            put("generatedKey", l.generatedKey)
                            put("billImageHash", l.billImageHash)
                            put("bankTransCode", l.bankTransCode)
                            put("forensicVerdict", l.forensicVerdict.take(400))
                            put("timestampMs", l.timestampMs)
                        })
                    }
                })

                root.put("storeApps", JSONArray().apply {
                    snapshot.storeApps.take(40).forEach { a ->
                        put(JSONObject().apply {
                            put("id", a.id)
                            put("name", a.name)
                            put("description", a.description.take(800))
                            put("downloadUrl", a.downloadUrl)
                            put("category", a.category)
                            put("version", a.version)
                            put("author", a.author)
                            put("isProOnly", a.isProOnly)
                            put("iconName", a.iconName)
                            put("status", a.status)
                            put("contributorEmail", a.contributorEmail)
                            put("createdAt", a.createdAt)
                        })
                    }
                })

                val target = getSnapshotFile(context)
                val tmp = File(target.parentFile, "$SNAPSHOT_FILE.tmp")
                tmp.writeText(root.toString(), Charsets.UTF_8)
                if (!tmp.renameTo(target)) {
                    target.writeText(root.toString(), Charsets.UTF_8)
                    try { tmp.delete() } catch (_: Throwable) {}
                }
            } catch (_: Throwable) {}
        }
    }

    private fun readLegacyApprovedIntents(context: Context): List<PaymentIntentRecord> {
        return try {
            val prefs = context.applicationContext.getSharedPreferences("magictune_admin_prefs", Context.MODE_PRIVATE)
            val jsonStr = prefs.getString("approved_intents_json", "").orEmpty()
            if (jsonStr.isBlank()) return emptyList()
            val arr = JSONArray(jsonStr)
            val list = ArrayList<PaymentIntentRecord>(arr.length())
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                list.add(
                    PaymentIntentRecord(
                        intentId = obj.optString("intentId"),
                        deviceId = obj.optString("deviceId"),
                        model = obj.optString("model"),
                        ownerEmail = obj.optString("ownerEmail"),
                        ownerName = obj.optString("ownerName"),
                        actionType = obj.optString("actionType"),
                        details = obj.optString("details"),
                        note = obj.optString("note"),
                        isPro = obj.optBoolean("isPro"),
                        timestamp = msToTs(obj.optLong("timestampSec", 0L) * 1000L)
                    )
                )
            }
            list
        } catch (_: Throwable) {
            emptyList()
        }
    }

    private fun readOfflineSnapshotFromDisk(context: Context): AdminDashboardSnapshot? {
        appContextRef = context.applicationContext
        val snapshotFile = getSnapshotFile(context)
        if (snapshotFile.exists() && snapshotFile.length() > 4L) {
            synchronized(diskWriteLock) {
                try {
                    val root = JSONObject(snapshotFile.readText(Charsets.UTF_8))
                    val syncTs = root.optLong("lastSyncTimestampMs", LicenseManager.getAdminLastGlobalSyncMs(context))

                    fun parseIntentsArray(key: String): List<PaymentIntentRecord> {
                        val arr = root.optJSONArray(key) ?: return emptyList()
                        val out = ArrayList<PaymentIntentRecord>(arr.length())
                        for (idx in 0 until arr.length()) {
                            val o = arr.optJSONObject(idx) ?: continue
                            out.add(
                                PaymentIntentRecord(
                                    intentId = o.optString("intentId"),
                                    deviceId = o.optString("deviceId"),
                                    model = o.optString("model"),
                                    ownerEmail = o.optString("ownerEmail"),
                                    ownerName = o.optString("ownerName"),
                                    actionType = o.optString("actionType"),
                                    details = o.optString("details"),
                                    note = o.optString("note"),
                                    isPro = o.optBoolean("isPro"),
                                    timestamp = msToTs(o.optLong("timestampMs", 0L))
                                )
                            )
                        }
                        return out
                    }

                    val usersArr = root.optJSONArray("users") ?: JSONArray()
                    val users = ArrayList<UserProfile>(usersArr.length())
                    for (idx in 0 until usersArr.length()) {
                        val o = usersArr.optJSONObject(idx) ?: continue
                        users.add(
                            UserProfile(
                                userId = o.optString("userId"),
                                email = o.optString("email"),
                                phoneNumber = o.optString("phoneNumber"),
                                displayName = o.optString("displayName", "Chưa đặt tên"),
                                role = o.optString("role", "user"),
                                isPro = o.optBoolean("isPro"),
                                isAccountPro = o.optBoolean("isAccountPro"),
                                proTier = o.optString("proTier", "FREE"),
                                deviceId = o.optString("deviceId"),
                                hardwareId = o.optString("hardwareId"),
                                activeDeviceId = o.optString("activeDeviceId"),
                                activeDeviceModel = o.optString("activeDeviceModel"),
                                licenseKey = o.optString("licenseKey"),
                                proActivatedSource = o.optString("proActivatedSource"),
                                bankTransCode = o.optString("bankTransCode"),
                                revokedByAdmin = o.optBoolean("revokedByAdmin"),
                                proActivatedAt = msToTs(o.optLong("proActivatedMs", 0L)),
                                lastActive = msToTs(o.optLong("lastActiveMs", 0L)),
                                createdAt = msToTs(o.optLong("createdMs", 0L)),
                                customGeminiKey = o.optString("customGeminiKey"),
                                customGroqKey = o.optString("customGroqKey"),
                                customAiKeyRaw = o.optString("customAiKeyRaw"),
                                customAiKeyUpdatedAt = msToTs(o.optLong("customAiKeyUpdatedMs", 0L))
                            )
                        )
                    }

                    val devsArr = root.optJSONArray("devices") ?: JSONArray()
                    val devices = ArrayList<DeviceRecord>(devsArr.length())
                    for (idx in 0 until devsArr.length()) {
                        val o = devsArr.optJSONObject(idx) ?: continue
                        devices.add(
                            DeviceRecord(
                                deviceId = o.optString("deviceId"),
                                hardwareId = o.optString("hardwareId"),
                                model = o.optString("model", "Thiết bị Android"),
                                isPro = o.optBoolean("isPro"),
                                isAccountPro = o.optBoolean("isAccountPro"),
                                upgradedToAccountPro = o.optBoolean("upgradedToAccountPro"),
                                proTier = o.optString("proTier", "FREE"),
                                revokedByAdmin = o.optBoolean("revokedByAdmin"),
                                ownerUid = o.optString("ownerUid"),
                                ownerEmail = o.optString("ownerEmail"),
                                ownerName = o.optString("ownerName"),
                                freeTrialUsed = o.optInt("freeTrialUsed", 0),
                                licenseKey = o.optString("licenseKey"),
                                approvedByAiReason = o.optString("approvedByAiReason"),
                                bankTransCode = o.optString("bankTransCode"),
                                proActivatedAt = msToTs(o.optLong("proActivatedMs", 0L)),
                                lastActive = msToTs(o.optLong("lastActiveMs", 0L)),
                                createdAt = msToTs(o.optLong("createdMs", 0L)),
                                customGeminiKey = o.optString("customGeminiKey"),
                                customGroqKey = o.optString("customGroqKey"),
                                customAiKeyRaw = o.optString("customAiKeyRaw"),
                                customAiKeyUpdatedAt = msToTs(o.optLong("customAiKeyUpdatedMs", 0L))
                            )
                        )
                    }

                    val recArr = root.optJSONArray("proRecoveries") ?: JSONArray()
                    val recoveries = ArrayList<LicenseManager.ProRecoveryRecord>(recArr.length())
                    for (idx in 0 until recArr.length()) {
                        val o = recArr.optJSONObject(idx) ?: continue
                        val createdMs = o.optLong("createdMs", 0L)
                        recoveries.add(
                            LicenseManager.ProRecoveryRecord(
                                id = o.optString("id"),
                                deviceId = o.optString("deviceId"),
                                deviceModel = o.optString("deviceModel", "Thiết bị Android"),
                                ownerEmail = o.optString("ownerEmail"),
                                ownerName = o.optString("ownerName"),
                                note = o.optString("note"),
                                createdAt = msToTs(createdMs),
                                status = o.optString("status", "PENDING"),
                                previousProVerified = o.optBoolean("previousProVerified", true)
                            )
                        )
                    }

                    val logsArr = root.optJSONArray("aiLogs") ?: JSONArray()
                    val aiLogs = ArrayList<LicenseManager.AiProChatLogRecord>(logsArr.length())
                    for (idx in 0 until logsArr.length()) {
                        val o = logsArr.optJSONObject(idx) ?: continue
                        val tsMs = o.optLong("timestampMs", 0L)
                        aiLogs.add(
                            LicenseManager.AiProChatLogRecord(
                                id = o.optString("id"),
                                deviceId = o.optString("deviceId"),
                                deviceModel = o.optString("deviceModel"),
                                ownerEmail = o.optString("ownerEmail"),
                                ownerName = o.optString("ownerName"),
                                userMessage = o.optString("userMessage"),
                                aiReply = o.optString("aiReply"),
                                eventType = o.optString("eventType", "PRO_INQUIRY"),
                                proGranted = o.optBoolean("proGranted"),
                                grantedTier = o.optString("grantedTier", "NONE"),
                                generatedKey = o.optString("generatedKey"),
                                billImageHash = o.optString("billImageHash"),
                                bankTransCode = o.optString("bankTransCode"),
                                forensicVerdict = o.optString("forensicVerdict"),
                                timestampMs = tsMs,
                                createdAt = msToTs(tsMs)
                            )
                        )
                    }

                    val appsArr = root.optJSONArray("storeApps") ?: JSONArray()
                    val storeApps = ArrayList<HonorAppItem>(appsArr.length())
                    for (idx in 0 until appsArr.length()) {
                        val o = appsArr.optJSONObject(idx) ?: continue
                        storeApps.add(
                            HonorAppItem(
                                id = o.optString("id"),
                                name = o.optString("name"),
                                description = o.optString("description"),
                                downloadUrl = o.optString("downloadUrl"),
                                category = o.optString("category", "Tiện Ích"),
                                version = o.optString("version", "1.0"),
                                author = o.optString("author", "Admin VXM"),
                                isProOnly = o.optBoolean("isProOnly"),
                                iconName = o.optString("iconName", "apps"),
                                status = o.optString("status", "APPROVED"),
                                contributorEmail = o.optString("contributorEmail"),
                                createdAt = o.optLong("createdAt", 0L)
                            )
                        )
                    }

                    val approved = parseIntentsArray("approvedIntents").ifEmpty { readLegacyApprovedIntents(context) }
                    return AdminDashboardSnapshot(
                        users = users,
                        devices = devices,
                        paymentIntents = parseIntentsArray("paymentIntents"),
                        approvedIntents = approved,
                        proRecoveries = recoveries,
                        aiLogs = aiLogs,
                        storeApps = storeApps,
                        lastSyncTimestampMs = syncTs,
                        lastSyncLabel = if (syncTs > 0L) formatOfflineLabel(syncTs) else "📦 Dữ liệu Offline đã lưu",
                        isFromOfflineCacheOnly = !hasEverSyncedOnline,
                        isOfflineHydrated = true,
                        isSyncing = false
                    )
                } catch (_: Throwable) {}
            }
        }

        // Fallback: thử nạp từ bộ đệm file theo từng collection nếu snapshot hợp nhất chưa tồn tại
        return try {
            val users = FirebaseAuthManager.getOfflineUsersCached(context)
            val devices = FirebaseAuthManager.getOfflineDevicesCached(context)
            val intents = FirebaseAuthManager.getOfflinePaymentIntentsCached(context)
            val recoveries = LicenseManager.getOfflineProRecoveryRequestsCached(context)
            val logs = LicenseManager.getOfflineAiProChatLogsCached(context)
            val apps = FirebaseAuthManager.getOfflineHonorAppsCached(context)
            val approved = readLegacyApprovedIntents(context)
            val syncTs = LicenseManager.getAdminLastGlobalSyncMs(context)
            if (users.isEmpty() && devices.isEmpty() && intents.isEmpty() && recoveries.isEmpty() && logs.isEmpty() && apps.isEmpty() && approved.isEmpty()) {
                null
            } else {
                AdminDashboardSnapshot(
                    users = users,
                    devices = devices,
                    paymentIntents = intents,
                    approvedIntents = approved,
                    proRecoveries = recoveries,
                    aiLogs = logs,
                    storeApps = apps,
                    lastSyncTimestampMs = syncTs,
                    lastSyncLabel = formatOfflineLabel(syncTs),
                    isFromOfflineCacheOnly = !hasEverSyncedOnline,
                    isOfflineHydrated = true,
                    isSyncing = false
                )
            }
        } catch (_: Throwable) {
            null
        }
    }
}
