package com.example

import com.example.ui.components.SelfPermissionModal
import com.example.core.permission.AppPermissionChecker

import android.content.Intent
import android.provider.Settings
import android.widget.Toast
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import com.example.data.LogItem
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.data.LogType
import com.example.data.SearchableActionItem
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.layout
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicCyanLight
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicSurfaceDark
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextMuted
import com.example.ui.MagicTuneViewModel
import com.example.ui.MainTab
import com.example.ui.components.AppsScreen
import com.example.ui.components.HeaderSection
import com.example.ui.components.NotificationScreen
import com.example.ui.components.RevertModal
import com.example.ui.components.SetupScreen
import com.example.ui.components.ShellRunnerScreen
import com.example.ui.components.ShizukuWlanScreen
import com.example.ui.components.TerminalBottomSheet
import com.example.ui.components.ThermalPrinterScreen
import com.example.ui.components.TuneScreen
import com.example.ui.components.WeatherDetailScreen
import com.example.ui.components.WirelessAdbDialog
import com.example.core.license.LicenseManager
import androidx.compose.runtime.collectAsState
import com.example.ui.theme.MagicDarkBackground
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MagicTuneViewModel by viewModels()
    private var perpetualCalendarOpenTrigger by androidx.compose.runtime.mutableIntStateOf(0)
    @Volatile
    private var lastResumeBackgroundSyncMs: Long = 0L
    private var isFirstResumeAfterCreate: Boolean = true
    private var firestoreRecoveryGate = false

    private val staticScreenIdleHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val staticScreenIdleRunnable = Runnable {
        com.example.core.perf.ScreenPowerOptimizer.applyStaticLowRefreshRate(window)
    }

    private fun scheduleStaticScreenPowerOptimization() {
        staticScreenIdleHandler.removeCallbacks(staticScreenIdleRunnable)
        staticScreenIdleHandler.postDelayed(staticScreenIdleRunnable, 3000L)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (com.example.core.crash.CrashBlackBox.isFirestoreOomRecoveryRequired(applicationContext)) {
            firestoreRecoveryGate = true
            showFirestoreOomRecoveryDialog()
            return
        }
        enableEdgeToEdge()
        configureAdaptiveRefreshRateOnce()
        try {
            com.example.core.perf.ScreenPowerOptimizer.applyFullHonorDisplayOptimization(applicationContext)
            val currentMode = com.example.core.perf.MagicTuneSelfPowerGovernor.getSelfPowerMode(applicationContext)
            if (currentMode == com.example.core.perf.MagicTuneSelfPowerGovernor.SelfPowerMode.ECO_ZERO_DRAIN ||
                currentMode == com.example.core.perf.MagicTuneSelfPowerGovernor.SelfPowerMode.ULTRA_LOW_POWER ||
                com.example.core.perf.PowerBudgetGuard.isThrottleActive()) {
                com.example.core.perf.ScreenPowerOptimizer.applyTrueOledBlackToWindow(window)
            }
        } catch (_: Throwable) {}
        val launchIntentCopy = intent
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                LicenseManager.getAppUiScale(applicationContext)
            } catch (_: Throwable) {}
            try {
                com.example.core.ai.configureAppCheck(applicationContext, launchIntentCopy)
            } catch (_: Throwable) {}
        }
        try {
            handleIncomingPrintIntent(intent)
            checkTargetTabIntent(intent)
        } catch (_: Throwable) {}
        lifecycleScope.launch(Dispatchers.IO) {
            // Nhường 100% tài nguyên Main Thread & WindowManager cho khung hình đầu tiên (SurfaceSyncGroup < 100ms)
            kotlinx.coroutines.delay(1600L)
            try {
                com.example.core.license.LicenseManager.listenToGlobalConfigChanges(applicationContext)
                com.example.core.license.LicenseManager.grantAppReloadBonusTrial(applicationContext)
                com.example.core.auth.FirebaseAuthManager.startSingleDeviceSessionGuard(applicationContext)
                // Giữ trợ năng ngầm ở trạng thái ngủ (Tắt) khi mở app để tiết kiệm điện năng tuyệt đối
                try {
                    com.example.core.service.MagicTuneCtsAccessibilityService.purgeFromSecureSettingsIfIdle(applicationContext)
                } catch (_: Throwable) {}
                com.example.core.service.MagicTuneKeepAliveService.syncServiceNeed(
                    applicationContext,
                    "Đang duy trì Khoanh tròn hỏi AI & Bảng Vẽ Mở App 24/7"
                )
                com.example.core.service.SystemFloatingHudOverlay.refreshNavPillColors(applicationContext)
                com.example.core.service.SystemFloatingHudOverlay.syncNavBarBridge(applicationContext)
            } catch (_: Throwable) {}
        }
        setContent {
            val uiScale by LicenseManager.appUiScaleFlow.collectAsStateWithLifecycle()
            val originalDensity = androidx.compose.ui.platform.LocalDensity.current
            val resolvedDensity = androidx.compose.runtime.remember(originalDensity, uiScale) {
                if (kotlin.math.abs(uiScale - 1.0f) <= 0.005f) {
                    originalDensity
                } else {
                    androidx.compose.ui.unit.Density(
                        density = originalDensity.density * uiScale,
                        fontScale = originalDensity.fontScale * uiScale
                    )
                }
            }
            androidx.compose.runtime.CompositionLocalProvider(
                androidx.compose.ui.platform.LocalDensity provides resolvedDensity
            ) {
                MyApplicationTheme {
                    MagicTuneApp(
                        viewModel = viewModel,
                        perpetualCalendarOpenTrigger = perpetualCalendarOpenTrigger
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        if (firestoreRecoveryGate) return
        setIntent(intent)
        try {
            handleIncomingPrintIntent(intent)
            checkTargetTabIntent(intent)
        } catch (_: Throwable) {}
    }

    private val pickFileLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri: android.net.Uri? ->
        if (uri != null) {
            viewModel.setSharedPrintUri(uri)
        }
    }

    private fun checkTargetTabIntent(intent: android.content.Intent?) {
        val targetTab = intent?.getStringExtra("TARGET_TAB")
        val targetAction = intent?.getStringExtra("TARGET_ACTION")

        if (targetAction == "GLOBAL_SEARCH") {
            viewModel.requestGlobalSearchFocus()
        } else if (targetTab == "ADMIN") {
            val subTab = intent.getIntExtra("ADMIN_SUB_TAB", 2)
            getSharedPreferences("magictune_pro_prefs", MODE_PRIVATE)
                .edit()
                .putInt("pending_admin_sub_tab", subTab)
                .apply()
            viewModel.setTab(MainTab.ADMIN)
        } else if (targetTab == "SETUP") {
            viewModel.setTab(MainTab.SETUP)
        } else if (targetTab == "WEATHER") {
            viewModel.setTab(MainTab.WEATHER)
        } else if (targetTab == "PERPETUAL_CALENDAR") {
            viewModel.setTab(MainTab.WEATHER)
            perpetualCalendarOpenTrigger += 1
        } else if (targetTab == "NOTIFICATIONS") {
            viewModel.setTab(MainTab.NOTIFICATIONS)
        } else if (targetTab == "TUNE") {
            viewModel.setTab(MainTab.TUNE)
        } else if (targetTab == "UNIVERSAL_TUNE") {
            viewModel.setTab(MainTab.UNIVERSAL_TUNE)
        } else if (targetTab == "APPS") {
            viewModel.setTab(MainTab.APPS)
        } else if (targetTab == "APP_STORE") {
            viewModel.setTab(MainTab.APP_STORE)
        } else if (targetTab == "BG_DRAIN_MONITOR") {
            viewModel.openBackgroundDrainMonitor()
        } else if (targetTab == "SHIZUKU") {
            viewModel.setTab(MainTab.SHIZUKU)
        } else if (targetTab == "SHELL" || targetTab == "SHELL_TAB") {
            viewModel.setTab(MainTab.SHELL)
        } else if (targetTab == "CHAT_SUPPORT") {
            viewModel.setTab(MainTab.CHAT_SUPPORT)
        } else if (targetTab == "LOGIN") {
            viewModel.setTab(MainTab.LOGIN)
        } else if (targetTab == "ACCOUNT") {
            viewModel.setTab(MainTab.ACCOUNT)
        } else if (targetTab == "GESTURE_SETTINGS") {
            val assignChar = intent?.getStringExtra("ASSIGN_GESTURE_CHAR")
            if (!assignChar.isNullOrBlank()) {
                getSharedPreferences("magictune_gestures", MODE_PRIVATE)
                    .edit()
                    .putString("pending_assign_char", assignChar)
                    .apply()
            }
            viewModel.setTab(MainTab.GESTURE_SETTINGS)
        } else if (targetTab == "PRINTER") {
            viewModel.setTab(MainTab.PRINTER)
            if (intent.getBooleanExtra("ACTION_PICK_FILE", false)) {
                try {
                    pickFileLauncher.launch("*/*")
                } catch (_: Exception) {
                    Toast.makeText(this, "⚠️ Không tìm thấy trình chọn tệp trên thiết bị.", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun handleIncomingPrintIntent(intent: android.content.Intent) {
        val action = intent.action
        val type = intent.type
        if (android.content.Intent.ACTION_SEND == action && type != null) {
            val uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableExtra(android.content.Intent.EXTRA_STREAM, android.net.Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(android.content.Intent.EXTRA_STREAM) as? android.net.Uri
            }
            if (uri != null) {
                viewModel.setSharedPrintUri(uri)
            }
        } else if (android.content.Intent.ACTION_VIEW == action) {
            intent.data?.let { uri ->
                viewModel.setSharedPrintUri(uri)
            }
        }
    }

    override fun dispatchTouchEvent(ev: android.view.MotionEvent?): Boolean {
        val action = ev?.actionMasked
        if (action == android.view.MotionEvent.ACTION_DOWN || action == android.view.MotionEvent.ACTION_MOVE) {
            com.example.core.perf.ScreenPowerOptimizer.restoreInteractiveRefreshRate(window)
            scheduleStaticScreenPowerOptimization()
        }
        if (action == android.view.MotionEvent.ACTION_DOWN ||
            action == android.view.MotionEvent.ACTION_UP ||
            action == android.view.MotionEvent.ACTION_CANCEL
        ) {
            com.example.core.perf.MagicTuneSelfPowerGovernor.notifyUserTouchOrScrollInApp(2_500L, force = true)
        } else if (action == android.view.MotionEvent.ACTION_MOVE) {
            com.example.core.perf.MagicTuneSelfPowerGovernor.notifyUserTouchOrScrollInApp(2_500L, force = false)
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun onResume() {
        super.onResume()
        if (firestoreRecoveryGate) return
        com.example.core.perf.ScreenPowerOptimizer.restoreInteractiveRefreshRate(window)
        scheduleStaticScreenPowerOptimization()
        com.example.core.crash.CrashBlackBox.startPerformanceMonitoring(applicationContext)
        com.example.core.perf.MagicTuneSelfPowerGovernor.setMainActivityForeground(true)
        val firstLaunch = isFirstResumeAfterCreate
        isFirstResumeAfterCreate = false
        viewModel.setAppInForeground(true)
        // Khi vừa mở app lần đầu (firstLaunch), MagicTuneViewModel.init và onCreate đã đảm nhiệm khởi tạo phân tầng ->
        // Không gọi lặp lại onAppResumed() hay syncDevicePresenceToCloud() lần 2 để tránh tăng vọt tiêu thụ điện!
        if (firstLaunch) return

        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastResumeBackgroundSyncMs >= 5000L) {
            lastResumeBackgroundSyncMs = now
            viewModel.onAppResumed()
            lifecycleScope.launch(Dispatchers.IO) {
                try {
                    // Đảm bảo phiên đăng nhập ổn định khi quay lại app từ nền
                    // Gọi refreshAuthSessionNow() để đồng bộ trạng thái thực tế từ Firebase.auth.currentUser
                    com.example.core.auth.FirebaseAuthManager.refreshAuthSessionNow(applicationContext)
                    com.example.core.auth.FirebaseAuthManager.ensureCentralAuthStateObserver(applicationContext)
                } catch (_: Throwable) {}
                try {
                    com.example.core.license.LicenseManager.listenToGlobalConfigChanges(applicationContext)
                    com.example.core.service.MagicTuneKeepAliveService.syncServiceNeed(
                        applicationContext,
                        "Đang duy trì Khoanh tròn hỏi AI & Bảng Vẽ Mở App 24/7"
                    )
                    com.example.core.service.SystemFloatingHudOverlay.refreshNavPillColors(applicationContext)
                com.example.core.service.SystemFloatingHudOverlay.syncNavBarBridge(applicationContext)
                } catch (_: Throwable) {}
            }
        }
    }

    override fun onPause() {
        super.onPause()
        staticScreenIdleHandler.removeCallbacks(staticScreenIdleRunnable)
        try {
            window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } catch (_: Throwable) {}
        if (firestoreRecoveryGate) return
        com.example.core.crash.CrashBlackBox.stopPerformanceMonitoring()
        com.example.core.perf.MagicTuneSelfPowerGovernor.setMainActivityForeground(false)
        try {
            com.example.core.license.LicenseManager.detachRealtimeListenersOnBackground(applicationContext)
            com.example.core.auth.FirebaseAuthManager.detachSingleDeviceListenerOnBackground()
            com.example.core.auth.AdminSessionCache.detachRealtimeListeners(force = true)
        } catch (_: Throwable) {}
        try {
            viewModel.setAppInForeground(false)
            if (!com.example.core.adb.AdbPairingNotificationManager.isNotificationPairingActive) {
                val scanner = com.example.core.adb.AdbNsdScanner.getInstance(applicationContext)
                scanner.releaseMulticastLock()
                scanner.stopDiscovery(updateStatusText = false)
            }
        } catch (_: Throwable) {}
    }

    override fun onStop() {
        super.onStop()
        staticScreenIdleHandler.removeCallbacks(staticScreenIdleRunnable)
        try {
            window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } catch (_: Throwable) {}
        if (firestoreRecoveryGate) return
        com.example.core.perf.MagicTuneSelfPowerGovernor.setMainActivityForeground(false)
        try {
            com.example.core.license.LicenseManager.detachRealtimeListenersOnBackground(applicationContext)
            com.example.core.auth.FirebaseAuthManager.detachSingleDeviceListenerOnBackground()
            com.example.core.auth.AdminSessionCache.detachRealtimeListeners(force = true)
            com.example.core.adb.AdbNsdScanner.getInstance(applicationContext).stopDiscovery(updateStatusText = false)

            // ZERO-DRAIN BACKGROUND SHIELD: Khi rời khỏi MainActivity và không có tính năng Overlay nào đang bật,
            // dập tắt hoàn toàn dịch vụ nền và đưa Trợ Năng vào giấc ngủ sâu 100% để đạt mức tiêu thụ 0% (0.05% - 0.1%/h)!
            val hasActiveOverlay = com.example.core.widget.GoogleLiveTranslateOverlay.isRunning ||
                com.example.core.widget.MagicLiveFloatingOverlay.isShowing ||
                com.example.core.widget.CircleToSearchOverlayActivity.isOverlayActive ||
                com.example.core.widget.CircleToSearchWindowOverlay.isShowing
            if (!hasActiveOverlay) {
                com.example.core.service.MagicTuneKeepAliveService.syncServiceNeed(applicationContext)
                com.example.core.service.MagicTuneCtsAccessibilityService.enterDeepSleepNow(applicationContext, forceImmediate = true)
            }
        } catch (_: Throwable) {}
    }

    private fun showFirestoreOomRecoveryDialog() {
        android.app.AlertDialog.Builder(this)
            .setTitle("Khôi phục sau lỗi Firestore")
            .setMessage(
                "Hộp đen phát hiện Firestore hết bộ nhớ khi xử lý dữ liệu chờ đồng bộ. " +
                    "Bạn có thể thử lại và giữ nguyên dữ liệu ngoại tuyến, hoặc xóa cache Firestore để bỏ hàng đợi lỗi. " +
                    "Xóa cache có thể làm mất các thay đổi chưa đồng bộ lên máy chủ."
            )
            .setCancelable(false)
            .setPositiveButton("Giữ dữ liệu, thử lại") { _, _ ->
                com.example.core.crash.CrashBlackBox.clearFirestoreOomRecoveryRequired(applicationContext)
                restartAfterFirestoreRecovery()
            }
            .setNegativeButton("Xóa cache Firestore") { _, _ ->
                clearFirestoreCacheAfterConfirmation()
            }
            .show()
    }

    private fun clearFirestoreCacheAfterConfirmation() {
        try {
            com.google.firebase.firestore.FirebaseFirestore.getInstance()
                .clearPersistence()
                .addOnSuccessListener {
                    com.example.core.crash.CrashBlackBox.clearFirestoreOomRecoveryRequired(applicationContext)
                    restartAfterFirestoreRecovery()
                }
                .addOnFailureListener { error ->
                    android.widget.Toast.makeText(
                        this,
                        "Không xóa được cache Firestore: ${error.message ?: "lỗi không rõ"}",
                        android.widget.Toast.LENGTH_LONG
                    ).show()
                    showFirestoreOomRecoveryDialog()
                }
        } catch (error: Throwable) {
            android.widget.Toast.makeText(
                this,
                "Không xóa được cache Firestore: ${error.message ?: "lỗi không rõ"}",
                android.widget.Toast.LENGTH_LONG
            ).show()
            showFirestoreOomRecoveryDialog()
        }
    }

    private fun restartAfterFirestoreRecovery() {
        val relaunch = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        finish()
        startActivity(relaunch)
    }

    /**
     * Cấu hình cửa sổ hiển thị thân thiện tuyệt đối với Android 15/16/17 (SurfaceFlinger ARR)
     * và Honor MagicOS 10/11 (LTPO 1–120Hz/144Hz & APS / SystemManager):
     * - Trên API 35+ (Android 15/16/17): Tôn trọng hoàn toàn Adaptive Refresh Rate (ARR) bản địa,
     *   TUYỆT ĐỐI KHÔNG khóa cứng preferredDisplayModeId để tránh khựng chuyển mode khi onResume
     *   và tránh bị Honor SystemManager/iAware gắn cờ tiêu thụ cao rồi bóp xung CPU.
     * - Dùng LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS trên API 35+ chuẩn Edge-to-Edge không gây relayout.
     */
    private fun configureAdaptiveRefreshRateOnce() {
        try {
            val lp = window.attributes
            var changed = false

            if (Build.VERSION.SDK_INT >= 35) {
                if (lp.layoutInDisplayCutoutMode != android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS) {
                    lp.layoutInDisplayCutoutMode = android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                    changed = true
                }
                if (lp.preferredDisplayModeId != 0) {
                    lp.preferredDisplayModeId = 0
                    changed = true
                }
                if (lp.preferredRefreshRate != 0f) {
                    lp.preferredRefreshRate = 0f
                    changed = true
                }
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R &&
                    lp.layoutInDisplayCutoutMode != android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                ) {
                    lp.layoutInDisplayCutoutMode = android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                    changed = true
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    // SIÊU TIẾT KIỆM PIN (1%/GIỜ): Tuyệt đối KHÔNG khóa cứng preferredRefreshRate ở 120Hz/144Hz liên tục!
                    // Để 0f (mặc định thích ứng ARR / LTPO của hệ thống) giúp màn hình tự động hạ về 10Hz/30Hz/60Hz khi nhìn tĩnh
                    // và chỉ tự tăng tốc mượt mà khi người dùng cuộn chạm (notifyUserTouchOrScrollInApp).
                    // Giảm 65% dòng xả tấm nền màn hình & GPU SurfaceFlinger!
                    if (lp.preferredRefreshRate != 0f) {
                        lp.preferredRefreshRate = 0f
                        changed = true
                    }
                }
            }

            if (changed) {
                window.attributes = lp
            }
        } catch (_: Throwable) {}
    }
}

@Composable
fun MagicTuneApp(
    viewModel: MagicTuneViewModel,
    perpetualCalendarOpenTrigger: Int = 0
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val shellState by viewModel.shellState.collectAsStateWithLifecycle()
    val shizukuInfo by viewModel.shizukuInfo.collectAsStateWithLifecycle()

    val context = androidx.compose.ui.platform.LocalContext.current

    val focusManager = androidx.compose.ui.platform.LocalFocusManager.current
    val keyboardController = androidx.compose.ui.platform.LocalSoftwareKeyboardController.current

    val runtimePermLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) {
        viewModel.checkSelfPermissions()
    }

    androidx.compose.runtime.LaunchedEffect(Unit) {
        try {
            // Đợi khung hình đầu tiên hoàn tất đồng bộ WindowManager (SurfaceSyncGroup) trước khi gọi hộp thoại xin quyền hệ thống
            androidx.compose.runtime.withFrameNanos { }
            kotlinx.coroutines.delay(1500L)
            val permsToRequest = mutableListOf<String>()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    permsToRequest.add(android.Manifest.permission.POST_NOTIFICATIONS)
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (context.checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    permsToRequest.add(android.Manifest.permission.BLUETOOTH_CONNECT)
                }
                if (context.checkSelfPermission(android.Manifest.permission.BLUETOOTH_SCAN) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    permsToRequest.add(android.Manifest.permission.BLUETOOTH_SCAN)
                }
            }
            if (context.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                permsToRequest.add(android.Manifest.permission.RECORD_AUDIO)
            }
            if (permsToRequest.isNotEmpty()) {
                runtimePermLauncher.launch(permsToRequest.toTypedArray())
            }
        } catch (_: Throwable) {}
    }

    // Tự động ẩn bàn phím mỗi khi chuyển Tab an toàn không gây crash focus coordinator
    androidx.compose.runtime.LaunchedEffect(uiState.currentTab) {
        com.example.core.crash.CrashBlackBox.updateActiveScreenName(uiState.currentTab.name)
        try {
            focusManager.clearFocus()
            keyboardController?.hide()
        } catch (_: Throwable) {}
    }

    var lastTabSwitchEpochMs by androidx.compose.runtime.remember { androidx.compose.runtime.mutableLongStateOf(0L) }
    val onSelectTab: (MainTab) -> Unit = androidx.compose.runtime.remember(viewModel, focusManager, keyboardController) {
        { tab ->
            val now = android.os.SystemClock.uptimeMillis()
            if (tab != viewModel.uiState.value.currentTab && now - lastTabSwitchEpochMs >= 80L) {
                lastTabSwitchEpochMs = now
                try {
                    focusManager.clearFocus()
                    keyboardController?.hide()
                } catch (_: Throwable) {}
                viewModel.setTab(tab)
                viewModel.setGlobalSearchQuery("")
            }
        }
    }
    val onOpenRevertModalCb = androidx.compose.runtime.remember(viewModel) { { viewModel.setShowRevertModal(true) } }
    val onOpenWlanDialogCb = androidx.compose.runtime.remember(viewModel) { { viewModel.setShowWlanDialog(true) } }
    val onDisconnectWlanCb = androidx.compose.runtime.remember(viewModel) { { viewModel.disconnectSession() } }
    val onRequestShizukuPermCb = androidx.compose.runtime.remember(viewModel) { { viewModel.requestShizukuPermission() } }
    val onOpenShizukuTabCb = androidx.compose.runtime.remember(viewModel, focusManager, keyboardController) {
        {
            focusManager.clearFocus(force = true)
            keyboardController?.hide()
            viewModel.setTab(MainTab.SHIZUKU)
        }
    }
    val onOpenYouTubeCb = androidx.compose.runtime.remember(viewModel) { { viewModel.openYouTubeChannel() } }
    val onOpenPermissionDialogCb = androidx.compose.runtime.remember(viewModel) { { viewModel.setShowPermissionDialog(true) } }
    val onGlobalSearchChangeCb: (String) -> Unit = androidx.compose.runtime.remember(viewModel) { { viewModel.setGlobalSearchQuery(it) } }
    val onOpenChatSupportCb = androidx.compose.runtime.remember(viewModel, focusManager, keyboardController) {
        {
            focusManager.clearFocus(force = true)
            keyboardController?.hide()
            viewModel.setTab(MainTab.CHAT_SUPPORT)
        }
    }

    val globalSearchQuery by viewModel.globalSearchQuery.collectAsStateWithLifecycle()
    val isGlobalSearchActive by androidx.compose.runtime.remember {
        androidx.compose.runtime.derivedStateOf { globalSearchQuery.isNotBlank() }
    }

    BackHandler(enabled = isGlobalSearchActive || uiState.currentTab != MainTab.SETUP) {
        focusManager.clearFocus(force = true)
        keyboardController?.hide()
        if (isGlobalSearchActive) {
            viewModel.setGlobalSearchQuery("")
            return@BackHandler
        }
        when (uiState.currentTab) {
            MainTab.GESTURE_SETTINGS -> viewModel.setTab(MainTab.TUNE)
            MainTab.BG_DRAIN_MONITOR -> viewModel.navigateBackFromBgDrain()
            MainTab.CHAT_SUPPORT -> viewModel.setTab(MainTab.ACCOUNT)
            MainTab.LOGIN -> viewModel.setTab(MainTab.ACCOUNT)
            else -> viewModel.setTab(MainTab.SETUP)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MagicDarkBackground,
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {

            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                // Header Section (Single unified UI, v1.3 badge, explicit WLAN status & Global Search)
                if (uiState.currentTab != MainTab.CHAT_SUPPORT) {
                    HeaderSection(
                        shellState = shellState,
                        currentTab = uiState.currentTab,
                        onTabSelected = onSelectTab,
                        onOpenRevertModal = onOpenRevertModalCb,
                        onOpenWlanDialog = onOpenWlanDialogCb,
                        onDisconnectWlan = onDisconnectWlanCb,
                        onRequestShizukuPermission = onRequestShizukuPermCb,
                        onOpenShizukuTab = onOpenShizukuTabCb,
                        onOpenYouTube = onOpenYouTubeCb,
                        onOpenPermissionDialog = onOpenPermissionDialogCb,
                        isPermissionFullyGranted = uiState.selfPermissionStatus.isFullyGranted,
                        globalSearchQuery = globalSearchQuery,
                        onGlobalSearchChange = onGlobalSearchChangeCb,
                        onOpenTerminal = { viewModel.setShowTerminalBottomSheet(true) },
                        globalSearchFocusTick = uiState.globalSearchFocusTick,
                        onOpenChatSupport = onOpenChatSupportCb
                    )
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    if (isGlobalSearchActive) {
                        // Global Instant Search View (Pre-normalized index + 100ms debounce + LazyColumn)
                        var debouncedQuery by androidx.compose.runtime.remember {
                            androidx.compose.runtime.mutableStateOf(globalSearchQuery)
                        }
                        androidx.compose.runtime.LaunchedEffect(globalSearchQuery) {
                            kotlinx.coroutines.delay(100L)
                            debouncedQuery = globalSearchQuery
                        }
                        val q = androidx.compose.runtime.remember(debouncedQuery) {
                            debouncedQuery.trim().lowercase()
                        }
                        val catalog = androidx.compose.runtime.remember {
                            listOf(
                                SearchableActionItem("API cá nhân & chọn model", "Thêm khóa Gemini, Groq, OpenAI, OpenRouter hoặc Pollinations; tự dự phòng khóa chung khi lỗi", "12. API Cá Nhân", "api,key,model,mo hinh,gemini,groq,openai,openrouter,pollinations", "personal_api"),
                                // TAB 1: THIẾT LẬP (Ô #00 – #08)
                                SearchableActionItem("[Ô #00] Bản Quyền Pro & Mã Thiết Bị", "Xem Device ID, trạng thái Pro, nhập mã kích hoạt hoặc khôi phục Pro tự động", "1. Thiết Lập (Ô #00)", "o 00,#00,00,0,ban quyen,pro,key,ma thiet bi,device id,khoi phuc pro,nang cap pro,vip", "setup_tab_only"),
                                SearchableActionItem("[Ô #01] Phần Cứng Thời Gian Thực & Pin", "Xem CPU, GPU, RAM, ROM, chu kỳ sạc, nhiệt độ & trạng thái bật/tắt phần cứng", "1. Thiết Lập (Ô #01)", "o 01,#01,01,1,phan cung,cpu,gpu,ram,rom,chu ky sac,suc khoe pin,nhiet do,kernel,cam bien", "setup_tab_only"),
                                SearchableActionItem("[Ô #01] Mở Khóa Dung Lượng Pin Thực 97% / 100%", "Tắt ngắt sạc sớm 80% ảo Honor, chọn sạc thực 97% hoặc 100% dung lượng", "1. Thiết Lập (Ô #01)", "o 01,#01,01,pin,dung luong pin,sac thuc,97%,100%,80% ao,unlock battery,bao ve pin", "unlock_battery_cap"),
                                SearchableActionItem("[Ô #02] Thiết Lập Nhanh 8-trong-1 (Không Cần ADB)", "Cài tiếng Việt, Google, GPS, phím Laban Key cho máy mới 1 chạm", "1. Thiết Lập (Ô #02)", "o 02,#02,02,2,8 trong 1,cai moi,tieng viet,google,labankey,gps,khong can adb", "setup_master"),
                                SearchableActionItem("[Ô #03] Mở Cập Nhật Hệ Điều Hành MagicOS (OUC / HOTA)", "Bật lại mục cập nhật phần mềm hệ thống bị ẩn & mở trang Cập nhật", "1. Thiết Lập (Ô #03)", "o 03,#03,03,3,cap nhat,he dieu hanh,magicos,ouc,hota,ota,phan mem,system update", "fix_system_update"),
                                SearchableActionItem("[Ô #04] Bàn Phím Tiếng Việt Telex, Laban Key & Gboard", "Kích hoạt bàn phím tiếng Việt gõ Telex, giọng nói hoặc cài Laban Key / Gboard", "1. Thiết Lập (Ô #04)", "o 04,#04,04,4,ban phim,telex,magictune keyboard,laban key,gboard,go tieng viet,ime", "setup_keyboard"),
                                SearchableActionItem("[Ô #05] Việt Hóa 100%, Múi Giờ GMT+7 & Giờ 24H", "Ép ngôn ngữ Tiếng Việt (vi-VN), múi giờ Hồ Chí Minh GMT+7 & định dạng 24h", "1. Thiết Lập (Ô #05)", "o 05,#05,05,5,viet hoa,ngon ngu,tieng viet,mui gio,gmt+7,24h,gio viet nam,locale", "setup_vietnamese_locale"),
                                SearchableActionItem("[Ô #06] Đồng Bộ Google Play (GMS) & Danh Bạ", "Bật dịch vụ Google cơ bản, mở CH Play và sửa lỗi đồng bộ Danh bạ Gmail", "1. Thiết Lập (Ô #06)", "o 06,#06,06,6,google play,gms,ch play,danh ba,contacts,dong bo google,play store", "setup_gms_sync"),
                                SearchableActionItem("[Ô #07] Chặn Chợ App Honor Tự Cập Nhật Đè", "Ngăn Honor AppMarket tự cài đè app tiếng Việt sang bản Trung Quốc", "1. Thiết Lập (Ô #07)", "o 07,#07,07,7,update,cho honor,cap nhat,appmarket,market,chan cap nhat", "block_update"),
                                SearchableActionItem("[Ô #08] Đặc Trị GPS, La Bàn, Maps & Timestamp Camera", "Tắt định vị lệch Baidu/AMap, chuyển A-GPS Google & cấp quyền Timestamp Camera", "1. Thiết Lập (Ô #08)", "o 08,#08,08,8,gps,dinh vi,lech vi tri,sai vi tri,timestamp,google maps,la ban,supl,grab", "fix_gps"),

                                // TAB 2: THỜI TIẾT & LỊCH (Ô #09 – #12)
                                SearchableActionItem("[Ô #09] Chọn Khu Vực Thời Tiết 63 Tỉnh Thành & GPS", "Đổi địa điểm xã/phường/huyện/đảo hoặc định vị GPS đồng bộ Widget màn hình chính", "2. Thời Tiết (Ô #09)", "o 09,#09,09,thoi tiet,weather,dia diem,tinh thanh,gps,doi vi tri,khu vuc", "weather_tab"),
                                SearchableActionItem("[Ô #10] Quyển Lịch Vạn Niên (Dương & Âm Lịch)", "Xem lịch tháng Âm - Dương, Can Chi, Giờ Hoàng Đạo & ghim Widget Lịch (Free)", "2. Thời Tiết (Ô #10)", "o 10,#10,10,lich van nien,am lich,duong lich,can chi,hoang dao,widget lich", "weather_tab"),
                                SearchableActionItem("[Ô #11] Tuỳ Chỉnh Widget Đồng Hồ & Thời Tiết", "Ẩn/hiện mục hiển thị, phóng to/thu nhỏ cỡ chữ Widget & khôi phục mặc định 1 chạm", "2. Thời Tiết (Ô #11)", "o 11,#11,11,tuy chinh widget,co chu widget,an hien widget,widget dong ho,widget thoi tiet", "weather_tab"),
                                SearchableActionItem("[Ô #12] Thời Tiết Hiện Tại, Dự Báo 24H & 7 Ngày Tới", "Xem nhiệt độ thực tế, độ ẩm, gió, UV, chất lượng không khí & dự báo 7 ngày", "2. Thời Tiết (Ô #12)", "o 12,#12,12,du bao,24h,7 ngay,nhiet do,do am,gio,uv,mua,thoi tiet hom nay", "weather_tab"),

                                // TAB 3: THÔNG BÁO (Ô #13 – #19)
                                SearchableActionItem("[Ô #13] Mở 100% Thông Báo & Cấp Quyền Chạy Ngầm 24/7", "Chống trễ thông báo Zalo, Messenger, Ngân hàng & cấp full quyền chạy nền", "3. Thông Báo (Ô #13)", "o 13,#13,13,thong bao,chuong,tin nhan,zalo,messenger,instagram,whatsapp,fcm,powergenius,tre thong bao", "fix_notif"),
                                SearchableActionItem("[Ô #14] Sửa Tắt Thông Báo Từng App Mạng Xã Hội", "Mở nhanh cài đặt & sửa lỗi câm lặng cho Messenger, Zalo, Instagram, Gmail", "3. Thông Báo (Ô #14)", "o 14,#14,14,tung ung dung,mang xa hoi,zalo,messenger,instagram,whatsapp,tiktok,telegram,ngan hang", "notif_bar_options"),
                                SearchableActionItem("[Ô #15] Thông Báo Ghim Magiclive, Khoanh Tròn & Vẽ", "Thông báo luôn bật trong app, mở Magiclive, Vẽ và Khoanh tròn khi đủ quyền", "3. Thông Báo (Ô #15)", "o 15,#15,15,thanh thong bao,tim kiem,watt,sac pin,sang man hinh,autowake", "notif_bar_options"),
                                SearchableActionItem("[Ô #16] Ưu Tiên Chuông & Âm Thanh Tin Nhắn", "Ép kênh âm thanh ưu tiên cao nhất cho Zalo, Messenger, Ngân hàng", "3. Thông Báo (Ô #16)", "o 16,#16,16,am thanh,chuong,tin nhan,volume,sound", "prioritize_sounds"),
                                SearchableActionItem("[Ô #17] Cấp Lại FCM Meta & Tự Khởi Chạy (Auto-start)", "Kích hoạt FCM/FBNS và tự khởi chạy cho Messenger, Instagram, Threads, Zalo", "3. Thông Báo (Ô #17)", "o 17,#17,17,meta,messenger,instagram,threads,whatsapp,fcm,auto start,tu khoi chay,zalo", "fix_fb"),
                                SearchableActionItem("[Ô #18] Phá Gom Cụm 0s Gmail & Ưu Tiên VoLTE / VoWiFi", "Nhận Gmail tức thì 0 giây trễ & ưu tiên kết nối cuộc gọi thoại", "3. Thông Báo (Ô #18)", "o 18,#18,18,gmail,gom cum,0s,email,delay,volte,vowifi,cuoc goi", "boost_gmail"),
                                SearchableActionItem("[Ô #19] Sửa Thông Báo WebADB USB & Quét Tiến Trình", "Mở WebADB magictunehonor.ai.studio bật biểu ngữ hàng loạt & chẩn đoán nền", "3. Thông Báo (Ô #19)", "o 19,#19,19,webadb,usb,magictunehonor,bieu ngu,nhe nhang,giam sat,monitor,tien trinh", "system_monitor"),

                                SearchableActionItem("Magiclive • Phiên chat 24 giờ", "Mở từ thông báo ghim; phiên được giữ 24 giờ kể cả qua nửa đêm. Tạo phiên mới trong menu ba chấm.", "4. Tối Ưu & AI", "magiclive,gemini,phien chat,24h,thong bao", "notif_bar_options"),
                                SearchableActionItem("Widget pin • Ẩn/hiện chu kỳ sạc", "Chạm nút chu kỳ trên widget; pin cập nhật theo sự kiện hệ thống khi màn hình sáng.", "7. Pin & Soi Ngầm", "chu ky sac,widget pin,pin thuc,an chu ky,hien chu ky", "bg_drain_monitor"),
                                // TAB 4: TỐI ƯU & AI (Ô #20 – #35)
                                SearchableActionItem("[Ô #20] Khoanh Tròn Hỏi AI & Dịch Màn Hình", "Mở Khoanh tròn từ thông báo ghim sau khi kết nối ADB lần đầu và có quyền đọc màn hình", "4. Tối Ưu & AI (Ô #20)", "o 20,#20,20,search circle,khoanh tron,circle to search,google,dieu huong,dich man hinh", "mod_circle_to_search"),
                                SearchableActionItem("[Ô #20] Vẽ Mở App Từ Thông Báo Ghim", "Mở bảng Vẽ từ thông báo ghim để vẽ chữ mở ứng dụng", "4. Tối Ưu & AI (Ô #20)", "o 20,#20,20,bang ve,ve chu,mo nhanh app,gesture,dieu huong,phim phai", "mod_magic_live"),
                                SearchableActionItem("[Ô #21] Cài Đặt Siêu Tốc Tệp APK (Bỏ Chặn Honor)", "Chọn tệp APK cài đè trực tiếp, bỏ qua cảnh báo chặn bảo mật Honor", "4. Tối Ưu & AI (Ô #21)", "o 21,#21,21,cai apk,apk,install apk,cai dat nhanh", "fast_apk_install"),
                                SearchableActionItem("[Ô #22] Siêu Tiết Kiệm Pin (Zero Delay) & Cảm Ứng Kính Dày", "Tối ưu pin OLED không trễ tin nhắn & tăng độ nhạy vân tay xuyên kính cường lực", "4. Tối Ưu & AI (Ô #22)", "o 22,#22,22,tiet kiem pin,oled,van tay,fingerprint,cuong luc day,cam ung,fod", "boost_touch_fingerprint"),
                                SearchableActionItem("[Ô #22] Quét Lại Vân Tay Sau Khi Dán Cường Lực", "Mở thẳng cài đặt vân tay hệ thống để thêm lại vân tay nhạy hơn", "4. Tối Ưu & AI (Ô #22)", "o 22,#22,22,cai dat van tay,quet van tay,fingerprint setting", "open_fingerprint_setting"),
                                SearchableActionItem("[Ô #23] Ép Màn Hình 120Hz / 144Hz & Chuyển Cảnh 0.5x", "Khóa tần số quét cao mượt mà & tăng tốc hoạt ảnh mở ứng dụng", "4. Tối Ưu & AI (Ô #23)", "o 23,#23,23,120hz,144hz,tan so quet,man hinh,fps,muot,animation,0.5x", "refresh_rate"),
                                SearchableActionItem("[Ô #24] Khóa Độ Phân Giải (1.5K/2K) & Tắt Xung Đột Hãng", "Giữ màn hình sắc nét cao nhất & tắt tiến trình gây nóng máy an toàn ROM", "4. Tối Ưu & AI (Ô #24)", "o 24,#24,24,do phan giai,1.5k,2k,fhd+,dpi,xung dot,ha nhiet,nong may,powergenius", "disable_oem_conflicts"),
                                SearchableActionItem("[Ô #25] Chặn Quảng Cáo Toàn Diện (AdBlocker Pro)", "Chặn quảng cáo toàn hệ thống bằng Private DNS AdGuard", "4. Tối Ưu & AI (Ô #25)", "o 25,#25,25,quang cao,adblock,dns,chan qc", "adblock"),
                                SearchableActionItem("[Ô #26] Tắt Vuốt Xuống Tìm Kiếm Honor (HiSearch)", "Tắt thanh tìm kiếm HiSearch khi vuốt xuống màn hình chính", "4. Tối Ưu & AI (Ô #26)", "o 26,#26,26,hisearch,vuot xuong,tim kiem honor,tat hisearch", "block_hisearch"),
                                SearchableActionItem("[Ô #27] Giảm Tải Nhiệt An Toàn & Tiết Kiệm Pin", "Bật Tiết kiệm pin chuẩn Android qua ADB để giảm tải CPU/nền và hạ nhiệt an toàn", "4. Tối Ưu & AI (Ô #27)", "o 27,#27,27,lam mat,nhiet do,37 do,cooling,nong may,tiet kiem pin,tan nhiet", "auto_cooling"),
                                SearchableActionItem("[Ô #28] Âm Thanh Bluetooth Hi-Fi 48kHz", "Ép Audio Server chuẩn 48kHz, chống rè loa & tai nghe Bluetooth", "4. Tối Ưu & AI (Ô #28)", "o 28,#28,28,am thanh,bluetooth,re loa,hifi,48khz,audio", "fix_audio"),
                                SearchableActionItem("[Ô #29] Đặc Trị Lỗi Android Auto (Màn Hình Xe Hơi)", "Cấp full quyền, chống ngắt kết nối Android Auto trên ô tô", "4. Tối Ưu & AI (Ô #29)", "o 29,#29,29,android auto,xe hoi,oto,car,gearhead", "android_auto"),
                                SearchableActionItem("[Ô #30] Ẩn Trạng Thái Nhà Phát Triển (App Ngân Hàng & Game)", "Vào app tài chính, ngân hàng & game không báo lỗi bật Nhà phát triển", "4. Tối Ưu & AI (Ô #30)", "o 30,#30,30,tai chinh,bank,ngan hang,thanh toan,nha phat trien,dev mode,stealth", "stealth_dev_mode"),
                                SearchableActionItem("[Ô #31] Mở Khóa & Giải Nén Android/data & Android/obb", "Đọc, ghi, giải nén thư mục hạn chế trên Android 11–17", "4. Tối Ưu & AI (Ô #31)", "o 31,#31,31,android data,obb,file he thong,giai nen,saf", "restricted_storage"),
                                SearchableActionItem("[Ô #32] Quyền Riêng Tư Cảm Biến (Camera / Micro / GPS)", "Ngắt quyền truy cập Camera, Micro, Vị trí, Clipboard cấp hệ thống", "4. Tối Ưu & AI (Ô #32)", "o 32,#32,32,quyen rieng tu,camera,micro,vi tri,clipboard,privacy", "deep_privacy"),
                                SearchableActionItem("[Ô #33] Tự Động Hóa & Kịch Bản Macro Game", "Giải phóng RAM, khóa xung Game Turbo & chạy kịch bản hệ thống", "4. Tối Ưu & AI (Ô #33)", "o 33,#33,33,tu dong hoa,kich ban,macro,ram,game turbo", "automation_macros"),
                                SearchableActionItem("[Ô #34] Tăng Tốc Wi-Fi, Link Turbo & Tiết Kiệm Pin Mạng", "Bật Low Latency Wi-Fi, tắt scan nền thừa, Wi-Fi kép 2.4G+5G & tối ưu pin modem", "4. Tối Ưu & AI (Ô #34)", "o 34,#34,34,wifi,tang toc wifi,giam tre,ping,low latency,wifi kep,link turbo", "boost_wifi_speed"),
                                SearchableActionItem("[Ô #35] Mượt Chuẩn iOS ProMotion & MagicOS Fluid Touch", "Chạm 0ms, render sớm VSYNC & 120Hz thích ứng LTPO mượt dính tay", "4. Tối Ưu & AI (Ô #35)", "o 35,#35,35,magicos,promotion,ios,muot ma,dinh tay,0ms,zero lag,fluid touch", "apply_magicos_smoothness"),

                                // TAB 5: KẾT NỐI (Ô #36 – #39)
                                SearchableActionItem("[Ô #36–#39] Kết Nối Không Dây WLAN (Mã 6 Số) & Shizuku", "Ghép đôi WLAN trực tiếp (Ô #36–#37), Shizuku (Ô #38) & chẩn đoán kết nối (Ô #39)", "5. Kết Nối (Ô #36–#39)", "o 36,#36,36,o 37,#37,37,o 38,#38,38,o 39,#39,39,adb,ket noi,wlan,wifi,ma 6 so,direct adb,shizuku,ghep doi", "connect_shizuku"),

                                // TAB 6: DỌN ỨNG DỤNG (Ô #40 – #41)
                                SearchableActionItem("[Ô #40] Dọn Rác Hệ Thống & Cấp Quyền Hàng Loạt", "Tắt dịch vụ ngầm dư thừa an toàn ROM & cấp quyền AppOps hàng loạt", "6. Dọn Ứng Dụng (Ô #40)", "o 40,#40,40,don rac,xung dot,cap quyen hang loat,appops", "debloat"),
                                SearchableActionItem("[Ô #41] Quản Lý Gói Ứng Dụng (Đóng Băng / Gỡ / Khôi Phục)", "Đóng băng hoặc gỡ an toàn app Trung Quốc nội địa, tìm nhanh & khôi phục", "6. Dọn Ứng Dụng (Ô #41)", "o 41,#41,41,go app,xoa app,bloatware,app rac,hiboard,quan ly app,dong bang,khoi phuc app", "debloat"),

                                // TAB 7: PIN & SOI NGẦM (Ô #42 – #45)
                                SearchableActionItem("[Ô #42] Siêu Tiết Kiệm Pin 3 Cấp Độ & Tự Động 24/7", "Đo xả Sáng/Tắt màn (%/h), 3 mức AI 24/7 • Cực Đại • Sinh Tồn & 3 chế độ tự động", "7. Pin & Soi Ngầm (Ô #42)", "o 42,#42,42,pin,sieu tiet kiem pin,tiet kiem pin,autopilot,sinh ton,cuc dai,sang man,tat man,qua dem", "bg_drain_monitor"),
                                SearchableActionItem("[Ô #43] Chế Độ Nền Nội Bộ MagicTune", "Chỉnh mức tiết kiệm & bật/tắt nhanh các mô-đun nền của MagicTune", "7. Pin & Soi Ngầm (Ô #43)", "o 43,#43,43,dien nang noi bo,mo dun nen,magictune pin,ngu dong", "bg_drain_monitor"),
                                SearchableActionItem("[Ô #44] Tổng Quan Pin, Nhiệt Độ & Bộ Nhớ RAM", "Xem nhanh % pin, nhiệt độ pin, thời lượng ước tính & RAM trống siêu mát", "7. Pin & Soi Ngầm (Ô #44)", "o 44,#44,44,nhiet do,ram,nong may,pin mat,tong quan pin", "bg_drain_monitor"),
                                SearchableActionItem("[Ô #45] Danh Sách App Chạy Ngầm & Triệt Tiêu 1 Chạm", "Xem app đang chạy nền, dọn RAM/Cache & đóng băng giữ nguyên thông báo", "7. Pin & Soi Ngầm (Ô #45)", "o 45,#45,45,soi ngam,app chay ngam,triet tieu app,don ram,cache,vip bao ve", "bg_drain_monitor"),

                                // TAB 8: CÀI ĐẶT CHỮ (Ô #46 – #47)
                                SearchableActionItem("[Ô #46–#47] Vẽ Chữ & Viết Tên Mở Nhanh App (A–Z)", "Gán 26 chữ cái A–Z mở app chính xác 100% & tạo nét vẽ mẫu tùy chỉnh", "8. Cài Đặt Chữ (Ô #46–#47)", "o 46,#46,46,o 47,#47,47,ve chu,cai dat chu,gesture,mo nhanh app,viet ten app,a-z", "gesture_settings"),
                                SearchableActionItem("Nhấn Đúp Nút Nguồn • Gọi App Phụ & Thư Mục Tiện Ích", "Hướng dẫn cài phím nguồn gọi Thư mục tiện ích, Khoanh AI, Khoanh Google, Dịch màn, Magiclive, Vẽ mở app", "8. Cài Đặt Chữ", "nut nguon,nhan dup,phim ben,app phu,thu muc tien ich,power button,double power", "gesture_settings"),

                                // TAB 9: ĐA HÃNG OEM (Ô #48 – #49)
                                SearchableActionItem("[Ô #48–#49] Tối Ưu Đa Hãng OEM (Xiaomi, Oppo, Vivo, Samsung)", "Nhận diện máy (Ô #48) & mở thông báo, chống bóp ngầm HyperOS, ColorOS, OneUI (Ô #49)", "9. Đa Hãng OEM (Ô #48–#49)", "o 48,#48,48,o 49,#49,49,da hang,oem,xiaomi,hyperos,oppo,realme,coloros,vivo,originos,samsung,oneui,huawei", "universal_oem"),

                                // TAB 10: MÁY IN K80 (Ô #50 – #55)
                                SearchableActionItem("[Ô #50–#55] Máy In Nhiệt K80 / K57 (LAN / Wi-Fi / Bluetooth)", "Kết nối máy in (Ô #50–#51), chọn PDF/Ảnh (Ô #52), khổ giấy (Ô #53), cắt giấy (Ô #54) & xem trước (Ô #55)", "10. Máy In K80 (Ô #50–#55)", "o 50,#50,50,o 51,#51,51,o 52,#52,52,o 53,#53,53,o 54,#54,54,o 55,#55,55,in,may in,k80,k57,in bill,shopee,tiktok,pdf,cat giay", "printer_k80"),

                                // TAB 11: KHO APP & WIDGET (Ô #56 – #58)
                                SearchableActionItem("[Ô #56–#57] Kho Ứng Dụng Honor & Cộng Đồng", "Tải Google App, Shizuku, Font & Theme Việt Hóa hoặc đóng góp app", "11. Kho App & Widget (Ô #56–#57)", "o 56,#56,56,o 57,#57,57,kho app,app store,tai app,theme,font,yoyo,dang app", "app_store"),
                                SearchableActionItem("[Ô #58] Kho 7 Widget Màn Hình Chính (Free Vĩnh Viễn)", "Ghim nhanh 7 Widget đủ màu: Pin 4×2, Pin Cơ Bản 2×2, RAM/ROM, Đồng hồ-Thời tiết, Lịch, Tìm App, Máy In", "11. Kho App & Widget (Ô #58)", "o 58,#58,58,widget,7 widget,widget pin,widget ram,widget dong ho,widget lich,widget tim app,widget in,man hinh chinh", "app_store"),
                                SearchableActionItem("[Ô #58] Widget Pin Cơ Bản 2×2 (Đơn Giản, Đủ Màu Sắc)", "Widget pin 2×2 gọn gàng: % Pin lớn, thanh pin màu, nhiệt độ, xả %/h & thời lượng dùng cơ bản", "11. Kho App & Widget (Ô #58)", "o 58,#58,58,pin 2x2,widget pin 2x2,pin co ban,pin don gian,pin nho,pin toi gian,2x2", "app_store"),

                                // TAB 12: TÀI KHOẢN & PRO (Ô #59 – #62)
                                SearchableActionItem("[Ô #59] Khôi Phục Quyền Pro Khi Cài Lại Máy", "Gửi yêu cầu đối soát Device ID lên Admin để cấp lại Pro 1 chạm", "12. Tài Khoản (Ô #59)", "o 59,#59,59,mat pro,khoi phuc pro,cai lai may,yeu cau pro", "account_tab"),
                                SearchableActionItem("[Ô #60] Thông Tin Tài Khoản, Đổi Mật Khẩu & Đồng Bộ Máy", "Quản lý tài khoản, đổi tên/email/mật khẩu & đồng bộ Pro Tài Khoản khi đổi máy", "12. Tài Khoản (Ô #60)", "o 60,#60,60,tai khoan,account,doi mat khau,email,dang nhap,pro tai khoan", "account_tab"),
                                SearchableActionItem("[Ô #61–#62] Nâng Cấp Pro VietQR, Nhập Key & So Sánh Quyền Lợi", "Xem quyền lợi Free vs Pro, quét VietQR tự duyệt hoặc nhập mã kích hoạt Pro", "12. Tài Khoản (Ô #61–#62)", "o 61,#61,61,o 62,#62,62,nang cap pro,vietqr,chuyen khoan,nhap key,quyen loi pro,so sanh free pro", "account_tab"),

                                // HỖ TRỢ, TERMINAL & QUẢN TRỊ
                                SearchableActionItem("[Ô #63] Chat Hỗ Trợ Trực Tuyến & Duyệt Pro Tự Động", "Hỏi đáp tính năng MagicTune 24/7 & gửi ảnh biên lai duyệt Pro tự động", "Hỗ Trợ (Ô #63)", "o 63,#63,63,chat,chatbot,ho tro,support,duyet pro,bien lai,bill", "chat_support"),
                                SearchableActionItem("[Ô #64] Terminal ADB Shell Runner (Admin)", "Chạy lệnh ADB trực tiếp, xem log chi tiết & sao chép nhanh lệnh lỗi", "13. Terminal Shell (Ô #64)", "o 64,#64,64,shell,adb,terminal,lenh,command,log", "shell_runner"),
                                SearchableActionItem("[Admin • Ô 1.0–1.9] Bảng Quản Trị, Duyệt Pro & Thu Phóng UI", "Quản lý thiết bị, duyệt đơn Pro, VietQR, upload APK & thu phóng 80%–100%", "14. Quản Trị (Ô 1.0–1.9)", "admin,quan tri,o 1.0,o 1.1,o 1.2,o 1.3,o 1.4,o 1.5,o 1.6,o 1.7,o 1.8,o 1.9,1.9,thu phong,zoom,duyet pro,tao key,don sach du lieu", "admin_panel")
                            )
                        }

                        val indexedCatalog = androidx.compose.runtime.remember(catalog) {
                            fun stripAccentsOnce(input: String): String {
                                val normalized = java.text.Normalizer.normalize(input.lowercase(), java.text.Normalizer.Form.NFD)
                                return normalized.replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
                                    .replace('đ', 'd')
                            }
                            catalog.map { item ->
                                val rawCombined = "${item.title} ${item.description} ${item.tab} ${item.tag}".lowercase()
                                Triple(item, rawCombined, stripAccentsOnce(rawCombined))
                            }
                        }

                        val searchResults = androidx.compose.runtime.remember(q, indexedCatalog) {
                            fun stripAccentsQuery(input: String): String {
                                val normalized = java.text.Normalizer.normalize(input.lowercase(), java.text.Normalizer.Form.NFD)
                                return normalized.replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
                                    .replace('đ', 'd')
                            }
                            val qNorm = stripAccentsQuery(q)
                            val qTokens = qNorm.split(Regex("\\s+")).filter { it.isNotBlank() }
                            indexedCatalog.mapNotNull { (item, rawCombined, normCombined) ->
                                when {
                                    rawCombined.contains(q) -> item
                                    normCombined.contains(qNorm) -> item
                                    qTokens.isNotEmpty() && qTokens.all { token -> normCombined.contains(token) } -> item
                                    else -> null
                                }
                            }
                        }

                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            item(key = "global_search_header") {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "KẾT QUẢ TÌM KIẾM (${searchResults.size})",
                                        color = MagicCyan,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Text(
                                        text = "Từ khóa: \"$debouncedQuery\"",
                                        color = TextMuted,
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            if (searchResults.isEmpty()) {
                                item(key = "global_search_empty") {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(MagicSurfaceDark)
                                            .padding(24.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = TextMuted, modifier = Modifier.size(28.dp))
                                            Text(text = "Không tìm thấy tính năng nào phù hợp", color = TextSecondary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                            Text(text = "Thử gõ: #00..#64, Pin 2x2, Pin, Thời tiết, Lịch, GPS, 120Hz, Vẽ chữ...", color = TextMuted, fontSize = 11.sp)
                                        }
                                    }
                                }
                            } else {
                                items(
                                    items = searchResults,
                                    key = { it.title }
                                ) { action ->
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                when (action.actionType) {
                                                    "setup_tab_only" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.SETUP)
                                                    }
                                                    "unlock_battery_cap" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.SETUP)
                                                        viewModel.toggleDeviceFeature("unlock_battery_97", false)
                                                    }
                                                    "setup_keyboard" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.SETUP)
                                                        viewModel.setupKeyboard()
                                                    }
                                                    "setup_vietnamese_locale" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.SETUP)
                                                        viewModel.setupVietnameseLanguage()
                                                    }
                                                    "setup_gms_sync" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.SETUP)
                                                        viewModel.setupGoogleAndSync()
                                                    }
                                                    "tune_tab_only" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                    }
                                                    "disable_oem_conflicts" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.disableSafeConflictingOemFeatures()
                                                    }
                                                    "admin_panel" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        if (LicenseManager.isCurrentUserAdmin(context)) {
                                                            viewModel.setTab(MainTab.ADMIN)
                                                        } else {
                                                            Toast.makeText(context, "🔒 Tính năng này dành riêng cho Quản trị viên (Admin)!", Toast.LENGTH_SHORT).show()
                                                        }
                                                    }
                                                    "personal_api" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.PERSONAL_API)
                                                    }
                                                    "mod_circle_to_search" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.modNavBarToCircleToSearch()
                                                    }
                                                    "mod_magic_live" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.testTriggerNavAssistantNow()
                                                    }
                                                    "nav_magic_live" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.openPlayStore("com.google.android.apps.bard")
                                                    }
                                                    "enhance_touch" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.enhanceBottomGestureSensitivity()
                                                    }
                                                    "boost_touch_fingerprint" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.boostTouchAndFingerprintSensitivity()
                                                    }
                                                    "open_fingerprint_setting" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        val intents = listOf(
                                                            Intent("android.settings.BIOMETRIC_ENROLL"),
                                                            Intent(Settings.ACTION_SECURITY_SETTINGS),
                                                            Intent(Settings.ACTION_SETTINGS)
                                                        )
                                                        var opened = false
                                                        for (intent in intents) {
                                                            try {
                                                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                                                context.startActivity(intent)
                                                                opened = true
                                                                break
                                                            } catch (_: Exception) {}
                                                        }
                                                        if (!opened) {
                                                            Toast.makeText(context, "Vui lòng mở Cài đặt -> Sinh trắc học & mật khẩu -> ID Vân tay", Toast.LENGTH_LONG).show()
                                                        }
                                                    }
                                                    "smart_battery" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.applySmartBatterySaver()
                                                    }
                                                    "android_auto" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.fixAndroidAuto()
                                                    }
                                                    "boost_wifi_speed" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.boostWifiSpeedAndLatency()
                                                    }
                                                    "boost_dual_wifi" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.boostDualWifiAndLinkTurbo()
                                                    }
                                                    "always_on_network_battery" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.applyAlwaysOnNetworkBatterySaver()
                                                    }
                                                    "restore_network_defaults" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.restoreDefaultNetworkAndBatterySettings()
                                                    }
                                                    "apply_vc_cooling" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.applyVaporChamberCooling()
                                                    }
                                                    "apply_magicos_smoothness" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.applyIosFluidSmoothness()
                                                    }
                                                    "apply_magicos_battery" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.applyIosBatteryEngine()
                                                    }
                                                    "refresh_rate" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.setRefreshRate(144)
                                                    }
                                                    "anim_scale" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.setAnimationScale(0.5f)
                                                    }
                                                    "adblock" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        if (viewModel.tuneStatus.value.isAdBlockerEnabled) viewModel.disableAdBlocker() else viewModel.enableAdBlocker()
                                                    }
                                                    "block_update" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.SETUP)
                                                        viewModel.blockHonorMarket()
                                                    }
                                                    "block_hisearch" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.replaceHonorSearch(true)
                                                    }
                                                    "auto_cooling" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.applyThermalCooling()
                                                    }
                                                    "fix_audio" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.fixAudio()
                                                    }
                                                    "fast_apk_install" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                    }
                                                    "fix_notif" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.NOTIFICATIONS)
                                                        viewModel.fixAllNotifications()
                                                    }
                                                    "fix_fb" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.NOTIFICATIONS)
                                                        viewModel.fixFacebook()
                                                    }
                                                    "boost_gmail" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.NOTIFICATIONS)
                                                        viewModel.boostGmailAndFacebookBatching()
                                                    }
                                                    "notif_bar_options" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.NOTIFICATIONS)
                                                    }
                                                    "prioritize_sounds" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.NOTIFICATIONS)
                                                        viewModel.prioritizeAppCustomSounds()
                                                    }
                                                    "fix_autostart" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.NOTIFICATIONS)
                                                        viewModel.fixFacebook()
                                                    }
                                                    "fix_call" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.NOTIFICATIONS)
                                                        viewModel.boostGmailAndFacebookBatching()
                                                    }
                                                    "system_monitor" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.NOTIFICATIONS)
                                                        viewModel.runDiagnosticScan()
                                                    }
                                                    "debloat" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.APPS)
                                                    }
                                                    "gesture_settings" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.GESTURE_SETTINGS)
                                                    }
                                                    "setup_master" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.SETUP)
                                                        viewModel.runOneClickSetup()
                                                    }
                                                    "fix_gps", "fix_gps_maps" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.SETUP)
                                                        viewModel.setupGpsVietnam()
                                                    }
                                                    "fix_system_update" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.SETUP)
                                                        viewModel.fixMagicOSSystemUpdate()
                                                    }
                                                    "connect_shizuku" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.SHIZUKU)
                                                        viewModel.requestShizukuPermission()
                                                    }
                                                    "printer_k80" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.PRINTER)
                                                    }
                                                    "universal_oem" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.UNIVERSAL_TUNE)
                                                    }
                                                    "stealth_dev_mode" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.enableStealthDeveloperModeBypass()
                                                    }
                                                    "restricted_storage" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.unlockAndInspectRestrictedStorage()
                                                    }
                                                    "deep_privacy" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                    }
                                                    "automation_macros" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.runSystemAutomationMacro("gaming_boost")
                                                    }
                                                    "app_store" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.APP_STORE)
                                                    }
                                                    "chat_support" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.CHAT_SUPPORT)
                                                    }
                                                    "shell_runner" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.SHELL_TAB)
                                                    }
                                                    "bg_drain_monitor" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.openBackgroundDrainMonitor()
                                                    }
                                                    "weather_tab" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.WEATHER)
                                                    }
                                                    "account_tab" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.ACCOUNT)
                                                    }
                                                }
                                            },
                                        shape = RoundedCornerShape(12.dp),
                                        colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicBorder)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                Text(
                                                    text = action.title,
                                                    color = Color.White,
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    lineHeight = 17.sp
                                                )
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Box(
                                                        modifier = Modifier
                                                            .clip(RoundedCornerShape(4.dp))
                                                            .background(MagicCyan.copy(alpha = 0.15f))
                                                            .border(0.5.dp, MagicCyan.copy(alpha = 0.35f), RoundedCornerShape(4.dp))
                                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                                    ) {
                                                        Text(
                                                            text = "📍 ${action.tab}",
                                                            color = MagicCyanLight,
                                                            fontSize = 9.5.sp,
                                                            fontWeight = FontWeight.Bold
                                                        )
                                                    }
                                                }
                                                Text(
                                                    text = action.description,
                                                    color = TextSecondary,
                                                    fontSize = 11.sp,
                                                    lineHeight = 15.sp
                                                )
                                            }
                                            Box(
                                                modifier = Modifier
                                                    .size(32.dp)
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(MagicCyan),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, tint = Color(0xFF020617), modifier = Modifier.size(16.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        Box(modifier = Modifier.fillMaxSize()) {
                            when (uiState.currentTab) {
                                            MainTab.WEATHER -> {
                                                WeatherDetailScreen(
                                                    openPerpetualCalendarTrigger = perpetualCalendarOpenTrigger
                                                )
                                            }
                                            MainTab.SETUP -> {
                                                val setupStatus by viewModel.setupStatus.collectAsStateWithLifecycle()
                                                val deviceInfo by viewModel.deviceInfo.collectAsStateWithLifecycle()
                                                SetupScreen(
                                                    status = setupStatus,
                                                    shizukuInfo = shizukuInfo,
                                                    deviceInfo = deviceInfo,
                                                    isAdbReady = shellState.isAdbReady,
                                                    isBusy = uiState.isBusy,
                                                    onRunSetupAll = { viewModel.runOneClickSetup() },
                                                    onRunSetupForceFull = { viewModel.runOneClickSetupForceFull() },
                                                    onRunSingleSetupItem = { index ->
                                                        when (index) {
                                                            1 -> viewModel.setupVietnameseLanguage()
                                                            2 -> viewModel.setupGoogleAndSync()
                                                            3 -> viewModel.setupKeyboard()
                                                            4 -> viewModel.fixCallerIdAndWifi()
                                                            5 -> viewModel.cleanChineseUi()
                                                            6 -> viewModel.setupGpsVietnam()
                                                            7 -> viewModel.blockHonorMarket()
                                                            8 -> viewModel.fixAllNotifications()
                                                        }
                                                    },
                                                    onOpenPlayStore = { viewModel.openPlayStore(it) },
                                                    onOpenYouTube = { viewModel.openYouTubeChannel() },
                                                    onRefreshDeviceInfo = { viewModel.refreshAll() },
                                                    onOpenPrinter = { viewModel.setTab(MainTab.PRINTER) },
                                                    onRestartShizuku = { viewModel.startShizukuServerDirectly() },
                                                    onRequestShizukuPermission = { viewModel.requestShizukuPermission() },
                                                    onOpenShizukuApp = { viewModel.setTab(MainTab.SHIZUKU) },
                                                    onOpenDirectWlanTab = { viewModel.setTab(MainTab.SHIZUKU) },
                                                    onOpenWlanDialog = { viewModel.setShowWlanDialog(true) },
                                                    onFixMagicOSSystemUpdate = { viewModel.fixMagicOSSystemUpdate() },
                                                    onRefreshSatellites = { viewModel.refreshGpsSatellites() },
                                                    onOpenAiBatteryDoctor = { viewModel.setTab(MainTab.BG_DRAIN_MONITOR) },
                                                    onToggleDeviceFeature = { id, enabled ->
                                                        if (id == "adb_debug") viewModel.setTab(MainTab.SHIZUKU)
                                                        else viewModel.toggleDeviceFeature(id, enabled)
                                                    },
                                                    onNavigateToUniversalFix = { viewModel.setTab(MainTab.UNIVERSAL_TUNE) }
                                                )
                                            }
                                            MainTab.NOTIFICATIONS -> {
                                                val diagnosticScan by viewModel.diagnosticScan.collectAsStateWithLifecycle()
                                                NotificationScreen(
                                                    isBusy = uiState.isBusy,
                                                    diagnosticScan = diagnosticScan,
                                                    onFixAllNotifications = { viewModel.fixNotificationSettingsOnly() },
                                                    onBatchGrantPermissions = { viewModel.fixAppPermissionsOnly() },
                                                    onRunDiagnosticScan = { viewModel.runDiagnosticScan() },
                                                    onResetAndRescan = { viewModel.resetAndRescanNotifications() },
                                                    onFixSingleApp = { pkg, name -> viewModel.fixSingleAppNotificationAndPerm(pkg, name) },
                                                    onOpenAppNotificationSettings = { pkg -> viewModel.openAppNotificationSettings(pkg) },
                                                    onOpenAppDetailsSettings = { pkg -> viewModel.openAppDetailsSettings(pkg) },
                                                    onFixFacebook = { viewModel.fixFacebook() },
                                                    onRestoreGmailAndFacebookDefault = { viewModel.restoreGmailAndFacebookDefault() },
                                                    onBoostBatching = { viewModel.boostGmailAndFacebookBatching() },
                                                    onPrioritizeCustomSounds = { viewModel.prioritizeAppCustomSounds() },
                                                    onRemovePowerGenius = { viewModel.removePowerGenius() },
                                                    onTestNotification = { pkg, name -> viewModel.testPushNotification(pkg, name) },
                                                    isChargingNotificationEnabled = uiState.isChargingNotificationEnabled,
                                                    onToggleChargingNotification = { viewModel.toggleChargingNotification(it) },
                                                    isSearchNotificationEnabled = uiState.isSearchNotificationEnabled,
                                                    onToggleSearchNotification = { viewModel.toggleSearchNotification(it) },
                                                    onNavigateToUniversalFix = { viewModel.setTab(MainTab.UNIVERSAL_TUNE) }
                                                )
                                            }
                                            MainTab.APPS -> {
                                                val appsList by viewModel.appsList.collectAsStateWithLifecycle()
                                                AppsScreen(
                                                    apps = appsList,
                                                    searchQuery = uiState.searchQuery,
                                                    selectedFilter = uiState.selectedAppLevelFilter,
                                                    isBusy = uiState.isBusy,
                                                    onSearchChange = { viewModel.setSearchQuery(it) },
                                                    onFilterChange = { viewModel.setAppLevelFilter(it) },
                                                    onDebloatSafeApps = { viewModel.debloatSafeApps() },
                                                    onGrantAllPermissions = { viewModel.grantAllPermissions() },
                                                    onBlockAppMarketUpdates = { viewModel.blockHonorMarket() },
                                                    onFixSingleAppNotificationAndPerm = { pkg, name ->
                                                        viewModel.fixSingleAppNotificationAndPerm(pkg, name)
                                                    },
                                                    onFreezeApp = { pkg, freeze ->
                                                        viewModel.freezeAppPackage(pkg, freeze)
                                                    },
                                                    onRevokeSensitivePermissions = { pkg ->
                                                        viewModel.revokeSensitivePermissionsFromApp(pkg)
                                                    },
                                                    onUninstallApp = { viewModel.uninstallApp(it) },
                                                    onRestoreApp = { viewModel.restoreApp(it) },
                                                    onNavigateToUniversalFix = { viewModel.setTab(MainTab.UNIVERSAL_TUNE) },
                                                    onRefreshApps = { viewModel.refreshAppsList() },
                                                    onOpenWlanDialog = { viewModel.setShowWlanDialog(true) },
                                                    onOpenBackgroundDrainScreen = { viewModel.openBackgroundDrainMonitor(MainTab.APPS) }
                                                )
                                            }
                                            MainTab.TUNE -> {
                                                val deviceInfo by viewModel.deviceInfo.collectAsStateWithLifecycle()
                                                val tuneStatus by viewModel.tuneStatus.collectAsStateWithLifecycle()
                                                TuneScreen(
                                                    deviceInfo = deviceInfo,
                                                    tuneStatus = tuneStatus,
                                                    isAdbReady = shellState.isAdbReady,
                                                    isBusy = uiState.isBusy,
                                                    onApplyMaxSettings = { viewModel.applyMaxSettings() },
                                                    onApplySmartBatterySaver = { viewModel.applySmartBatterySaver() },
                                                    onEnhanceGestureSensitivity = { viewModel.enhanceBottomGestureSensitivity() },
                                                    onBoostTouchAndFingerprint = { viewModel.boostTouchAndFingerprintSensitivity() },
                                                    onOpenFingerprintEnrollSetting = {
                                                        val intents = listOf(
                                                            Intent("android.settings.BIOMETRIC_ENROLL"),
                                                            Intent(Settings.ACTION_SECURITY_SETTINGS),
                                                            Intent(Settings.ACTION_SETTINGS)
                                                        )
                                                        var opened = false
                                                        for (intent in intents) {
                                                            try {
                                                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                                                context.startActivity(intent)
                                                                opened = true
                                                                break
                                                            } catch (_: Exception) {}
                                                        }
                                                        if (!opened) {
                                                            Toast.makeText(context, "Vui lòng mở Cài đặt -> Sinh trắc học & mật khẩu -> ID Vân tay", Toast.LENGTH_LONG).show()
                                                        }
                                                    },
                                                    onBoostWifiSpeed = { viewModel.boostWifiSpeedAndLatency() },
                                                    onBoostDualWifi = { viewModel.boostDualWifiAndLinkTurbo() },
                                                    onApplyAlwaysOnNetworkBatterySaver = { viewModel.applyAlwaysOnNetworkBatterySaver() },
                                                    onRestoreDefaultNetworkAndBattery = { viewModel.restoreDefaultNetworkAndBatterySettings() },
                                                    onApplyVaporChamberCooling = { viewModel.applyVaporChamberCooling() },
                                                    onApplyIosFluidSmoothness = { viewModel.applyIosFluidSmoothness() },
                                                    onRestoreDefaultSmoothnessAndThermal = { viewModel.restoreDefaultSmoothnessAndThermal() },
                                                    onApplyIosBatteryEngine = { viewModel.applyIosBatteryEngine() },
                                                    onRestoreDefaultBatteryEngine = { viewModel.restoreDefaultBatteryEngine() },
                                                    onSetRefreshRate = { viewModel.setRefreshRate(it) },
                                                    onSetPermanentRefreshRateLock = { rate, lock -> viewModel.setPermanentRefreshRateLock(rate, lock) },
                                                    onSetPermanentResolutionLock = { mode, lock -> viewModel.setPermanentResolutionLock(mode, lock) },
                                                    onDisableSafeConflictingOemFeatures = { viewModel.disableSafeConflictingOemFeatures() },
                                                    onRestoreSafeConflictingOemFeatures = { viewModel.restoreSafeConflictingOemFeatures() },
                                                    onSetAnimationScale = { viewModel.setAnimationScale(it) },
                                                    onDisableYoyoWake = { viewModel.disableYoyoNavigationWake() },
                                                    onRemapNavBarToGoogleAssistant = { viewModel.remapNavBarToGoogleAssistant() },
                                                    onModCircleToSearch = {
                                                        viewModel.modNavBarToCircleToSearch()
                                                    },
                                                    onModMagicLive = {
                                                        viewModel.toggleMagicLive()
                                                    },
                                                    onSetDefaultAssistant = {
                                                        viewModel.setMagicTuneAsDefaultAssistant()
                                                    },
                                                    onTestTriggerNavAssistant = { viewModel.testTriggerNavAssistantNow() },
                                                    onTestCircleToSearch = { viewModel.testCircleToSearchNow() },
                                                    onRestoreYoyoOriginal = { viewModel.restoreYoyoOriginal() },
                                                    onToggleNavPillsCentered = { viewModel.setNavPillsCenteredAndSyncYoyo(it) },
                                                    onToggleNavigationBarPill = { viewModel.toggleNavigationBarPill(it) },
                                                    onHideNavigationBar = { viewModel.hideNavigationBar() },
                                                    onReplaceHonorSearch = { viewModel.replaceHonorSearch(it) },
                                                    onBlockAppMarketUpdates = { viewModel.blockHonorMarket() },
                                                    onUnblockAppMarketUpdates = { viewModel.unblockHonorMarket() },
                                                    onApplyThermalCooling = { viewModel.applyThermalCooling() },
                                                    onFixAudio = { viewModel.fixAudio() },
                                                    onFixAndroidAuto = { viewModel.fixAndroidAuto() },
                                                    onFixGps = { viewModel.setupGpsVietnam() },
                                                    onRefreshSatellites = { viewModel.refreshGpsSatellites() },
                                                    onSetFontLarge = { viewModel.setFontBoldLarge(it) },
                                                    onSetDarkModeOled = { viewModel.setDarkModeOled(it) },
                                                    onEnableAdBlocker = { viewModel.enableAdBlocker() },
                                                    onDisableAdBlocker = { viewModel.disableAdBlocker() },
                                                    onEnableStealthDevMode = { viewModel.enableStealthDeveloperModeBypass() },
                                                    onRestoreDevModeVisibility = { viewModel.restoreDeveloperModeVisibility() },
                                                    onFixMagicOSSystemUpdate = { viewModel.fixMagicOSSystemUpdate() },
                                                    onUnlockRestrictedStorage = { viewModel.unlockAndInspectRestrictedStorage() },
                                                    onExtractAndSyncRestrictedData = { viewModel.extractAndSyncRestrictedObbAndData() },
                                                    onCleanRestrictedCaches = { viewModel.cleanRestrictedAppCaches() },
                                                    onToggleDeepPrivacySensor = { sensor, block -> viewModel.toggleDeepPrivacySensor(sensor, block) },
                                                    onRunAutomationMacro = { macro -> viewModel.runSystemAutomationMacro(macro) },
                                                    onOpenAppsManagerTab = { viewModel.setTab(MainTab.APPS) },
                                                    onOpenPlayStore = { viewModel.openPlayStore(it) },
                                                    onRequestOverlaySettingIntent = { viewModel.openOverlayPermissionSettings() },
                                                    onRefreshDeviceInfo = { viewModel.refreshAll() },
                                                    onToggleDeviceFeature = { id, enabled ->
                                                        if (id == "adb_debug") viewModel.setTab(MainTab.SHIZUKU)
                                                        else viewModel.toggleDeviceFeature(id, enabled)
                                                    },
                                                    onNavigateToUniversalFix = { viewModel.setTab(MainTab.UNIVERSAL_TUNE) },
                                                    onOpenDirectWlanTab = { viewModel.setTab(MainTab.SHIZUKU) },
                                                    onOpenGestureSettings = { viewModel.setTab(MainTab.GESTURE_SETTINGS) },
                                                    onOpenBackgroundDrainScreen = { viewModel.openBackgroundDrainMonitor(MainTab.TUNE) }
                                                )
                                            }
                                            MainTab.SHIZUKU -> {
                                                val adbTelemetry by viewModel.adbTelemetry.collectAsStateWithLifecycle()
                                                val adbDiagnosticReport by viewModel.adbDiagnosticReport.collectAsStateWithLifecycle()
                                                val isRunningAdbDiagnostics by viewModel.isRunningAdbDiagnostics.collectAsStateWithLifecycle()
                                                val onRequestShizukuPermCb = androidx.compose.runtime.remember(viewModel) { { viewModel.requestShizukuPermission() } }
                                                val onOpenShizukuAppCb = androidx.compose.runtime.remember(viewModel) { { viewModel.openShizukuApp() } }
                                                val onOpenDevSettingsCb = androidx.compose.runtime.remember(viewModel) { { viewModel.openDeveloperSettings() } }
                                                val onOpenWlanDialogCbTab = androidx.compose.runtime.remember(viewModel) { { viewModel.setShowWlanDialog(true) } }
                                                val onProtectShizukuCb = androidx.compose.runtime.remember(viewModel) { { viewModel.protectShizukuImmortal() } }
                                                val onAuthorizeCompanionsCb = androidx.compose.runtime.remember(viewModel) { { viewModel.authorizeShizukuCompanions() } }
                                                val onTestShizukuDiagnosticCb = androidx.compose.runtime.remember(viewModel) { { viewModel.testShizukuDiagnostic() } }
                                                val onStartNotifPairingCb = androidx.compose.runtime.remember(viewModel) { { viewModel.startNotificationPairingMode() } }
                                                val onStartShizukuDirectlyCb = androidx.compose.runtime.remember(viewModel) { { viewModel.startShizukuServerDirectly() } }
                                                val onUnlockRestrictedSettingsCb = androidx.compose.runtime.remember(viewModel) { { viewModel.unlockRestrictedSettingsAllApps() } }
                                                val onConnectWlanPortCb = androidx.compose.runtime.remember(viewModel) { { port: Int -> viewModel.connectWirelessAdb(port) } }
                                                val onRunShellCommandCb = androidx.compose.runtime.remember(viewModel) { { cmd: String -> viewModel.runCustomShellCommand(cmd) } }
                                                val onForceResetShizukuCb = androidx.compose.runtime.remember(viewModel) { { viewModel.forceResetShizuku() } }
                                                val onAutoConnectWlanCb = androidx.compose.runtime.remember(viewModel) { { viewModel.autoConnectWlanAdb() } }
                                                val onPingWlanCb = androidx.compose.runtime.remember(viewModel) { { viewModel.pingWlanAdb() } }
                                                val onRunAdbDiagnosticsCb = androidx.compose.runtime.remember(viewModel) { { viewModel.runWlanAdbDiagnostics() } }
                                                val onResetRsaKeysCb = androidx.compose.runtime.remember(viewModel) { { viewModel.resetWirelessAdbKeysAndCache() } }
                                                val onNavToUniversalFixCb = androidx.compose.runtime.remember(viewModel) { { viewModel.setTab(MainTab.UNIVERSAL_TUNE) } }
                                                ShizukuWlanScreen(
                                                    isActive = true,
                                                    shizukuInfo = shizukuInfo,
                                                    shellState = shellState,
                                                    isBusy = uiState.isBusy,
                                                    onRequestShizukuPermission = onRequestShizukuPermCb,
                                                    onOpenShizukuApp = onOpenShizukuAppCb,
                                                    onOpenDeveloperSettings = onOpenDevSettingsCb,
                                                    onOpenWlanDialog = onOpenWlanDialogCbTab,
                                                    onProtectShizuku = onProtectShizukuCb,
                                                    onAuthorizeCompanions = onAuthorizeCompanionsCb,
                                                    onTestShizukuDiagnostic = onTestShizukuDiagnosticCb,
                                                    onStartNotificationPairing = onStartNotifPairingCb,
                                                    onStartShizukuDirectly = onStartShizukuDirectlyCb,
                                                    onUnlockRestrictedSettings = onUnlockRestrictedSettingsCb,
                                                    onConnectWlanPort = onConnectWlanPortCb,
                                                    onRunShellCommand = onRunShellCommandCb,
                                                    onForceResetShizuku = onForceResetShizukuCb,
                                                    adbTelemetry = adbTelemetry,
                                                    adbDiagnosticReport = adbDiagnosticReport,
                                                    isRunningAdbDiagnostics = isRunningAdbDiagnostics,
                                                    onAutoConnectWlan = onAutoConnectWlanCb,
                                                    onPingWlan = onPingWlanCb,
                                                    onRunAdbDiagnostics = onRunAdbDiagnosticsCb,
                                                    onResetRsaKeys = onResetRsaKeysCb,
                                                    onNavigateToUniversalFix = onNavToUniversalFixCb
                                                )
                                            }
                                            MainTab.ACCOUNT -> {
                                                com.example.ui.components.AccountSettingsScreen(
                                                    onNavigateBack = { viewModel.setTab(MainTab.SETUP) },
                                                    onNavigateToLogin = { viewModel.setTab(MainTab.LOGIN) },
                                                    onNavigateToChatSupport = { viewModel.setTab(MainTab.CHAT_SUPPORT) }
                                                )
                                            }
                                            MainTab.ADMIN -> {
                                                com.example.ui.components.AdminManagementScreen(
                                                    isActive = true,
                                                    onNavigateBack = { viewModel.setTab(MainTab.SETUP) }
                                                )
                                            }
                                            MainTab.SHELL, MainTab.SHELL_TAB -> {
                                                val logs by viewModel.logs.collectAsStateWithLifecycle()
                                                ShellRunnerScreen(
                                                    logs = logs,
                                                    isBusy = uiState.isBusy,
                                                    onRunCommand = { viewModel.runCustomShellCommand(it) },
                                                    onClearLogs = { viewModel.clearLogs() },
                                                    onCancelOldCommands = { viewModel.cancelOldCommandsAndFreeTerminal() }
                                                )
                                            }
                                            MainTab.PRINTER -> {
                                                ThermalPrinterScreen(
                                                    sharedUri = uiState.sharedPrintUri,
                                                    isPrinting = uiState.isPrinting,
                                                    statusMessage = uiState.printStatusMessage,
                                                    onSetPrinting = { viewModel.setIsPrinting(it) },
                                                    onSetStatusMessage = { viewModel.setPrintStatusMessage(it) }
                                                )
                                            }
                                            MainTab.LOGIN -> {
                                                com.example.ui.components.LoginScreen(
                                                    onNavigateBack = { viewModel.setTab(MainTab.SETUP) },
                                                    onLoginSuccess = { viewModel.setTab(MainTab.ACCOUNT) },
                                                    onNavigateToAccount = { viewModel.setTab(MainTab.ACCOUNT) }
                                                )
                                            }
                                            MainTab.APP_STORE -> {
                                                com.example.ui.components.AppStoreScreen(
                                                    onNavigateBack = { viewModel.setTab(MainTab.SETUP) }
                                                )
                                            }
                                            MainTab.CHAT_SUPPORT -> {
                                                com.example.ui.components.ChatSupportScreen(
                                                    onNavigateBack = { viewModel.setTab(MainTab.ACCOUNT) }
                                                )
                                            }
                                            MainTab.UNIVERSAL_TUNE -> {
                                                val deviceInfo by viewModel.deviceInfo.collectAsStateWithLifecycle()
                                                com.example.ui.components.UniversalOemFixScreen(
                                                    deviceInfo = deviceInfo,
                                                    isBusy = uiState.isBusy,
                                                     onBack = { viewModel.setTab(MainTab.SETUP) },
                                                     onFixUniversalAll = { viewModel.applyUniversalOemNotificationFix() },
                                                     onFixXiaomi = { viewModel.fixXiaomiMiuiNotificationLag() },
                                                     onFixOppo = { viewModel.fixOppoRealmeNotificationLag() },
                                                     onFixVivo = { viewModel.fixVivoIqooNotificationLag() },
                                                     onFixHuawei = { viewModel.fixHuaweiHarmonyNotificationLag() },
                                                     onFixSamsung = { viewModel.fixSamsungOneUiLag() },
                                                     onFixMeizu = { viewModel.fixMeizuFlymeLag() },
                                                     onFixAsusRog = { viewModel.fixAsusRogLag() },
                                                     onRevertOemOptimization = { viewModel.revertOemOptimization() }
                                                )
                                            }
                                            MainTab.PERSONAL_API -> {
                                                com.example.ui.components.PersonalApiScreen()
                                            }
                                            MainTab.GESTURE_SETTINGS -> {
                                                com.example.ui.components.GestureSettingsScreen()
                                            }
                                            MainTab.BG_DRAIN_MONITOR -> {
                                                com.example.ui.components.BackgroundDrainMonitorScreen(
                                                    onNavigateBack = { viewModel.navigateBackFromBgDrain() },
                                                    onOpenWlanConnection = { viewModel.setShowWlanDialog(true) }
                                                )
                                            }
                                        }
                        }
                    }
                }
            }

            // 🌟 Overlay Xác thực Cloud ngay khi mở ứng dụng (Theo User Request: có thanh tiến trình rõ ràng)
            // Đặt ở cuối Box để đảm bảo hiển thị trên cùng (Z-index cao nhất)
            val onDismissCloudCheckCb = androidx.compose.runtime.remember(viewModel) { { viewModel.dismissCloudCheckOverlay() } }
            com.example.ui.components.CloudProVerificationOverlay(
                isVisible = uiState.showCloudCheckOverlay,
                status = uiState.cloudCheckStatus,
                progress = uiState.cloudCheckProgress,
                result = uiState.cloudCheckResult,
                onDismiss = onDismissCloudCheckCb
            )
        }
    }

    // Floating Terminal Dialog / BottomSheet
    if (uiState.showTerminalBottomSheet) {
        val logs by viewModel.logs.collectAsStateWithLifecycle()
        TerminalBottomSheet(
            logs = logs,
            onDismiss = { viewModel.setShowTerminalBottomSheet(false) },
            onClearLogs = { viewModel.clearLogs() },
            onRunCommand = { viewModel.runCustomShellCommand(it) },
            onCancelOldCommands = { viewModel.cancelOldCommandsAndFreeTerminal() },
            onOpenCrashReport = { viewModel.openCrashReportManual() },
            onOpenPerformanceReport = { viewModel.openPerformanceReportManual() }
        )
    }

    // Dialogs
    if (uiState.showWlanDialog) {
        val adbTelemetry by viewModel.adbTelemetry.collectAsStateWithLifecycle()
        val adbDiagnosticReport by viewModel.adbDiagnosticReport.collectAsStateWithLifecycle()
        val isRunningAdbDiagnostics by viewModel.isRunningAdbDiagnostics.collectAsStateWithLifecycle()
        val isFloatingKeypadEnabled by viewModel.isFloatingKeypadEnabled.collectAsStateWithLifecycle()
        WirelessAdbDialog(
            currentPort = shellState.wirelessAdbPort,
            isConnected = shellState.isWirelessAdbConnected,
            onDismiss = { viewModel.setShowWlanDialog(false) },
            onPair = { port, pin, callback -> viewModel.pairWirelessAdb(port, pin, callback) },
            onConnect = { viewModel.connectWirelessAdb(it) },
            onDisconnect = { viewModel.disconnectWirelessAdb() },
            onOpenDeveloperSettings = { viewModel.openDeveloperSettings() },
            onStartNotificationPairing = { viewModel.startNotificationPairingMode() },
            isShizukuRunning = shizukuInfo.isRunning,
            isShizukuPermissionGranted = shizukuInfo.isPermissionGranted,
            isShizukuInstalled = shizukuInfo.isInstalled,
            onRequestShizukuPermission = { viewModel.requestShizukuPermission() },
            onOpenShizukuApp = { viewModel.openShizukuApp() },
            onStartShizukuDirectly = { viewModel.startShizukuServerDirectly() },
            onResetRsaKeys = { viewModel.resetWirelessAdbKeysAndCache() },
            telemetry = adbTelemetry,
            diagnosticReport = adbDiagnosticReport,
            isRunningDiagnostics = isRunningAdbDiagnostics,
            isFloatingKeypadEnabled = isFloatingKeypadEnabled,
            onAutoConnect = { viewModel.autoConnectWlanAdb() },
            onPing = { viewModel.pingWlanAdb() },
            onRunDiagnostics = { viewModel.runWlanAdbDiagnostics() },
            onToggleFloatingKeypad = { viewModel.setFloatingKeypadEnabled(it) }
        )
    }

    if (uiState.showRevertModal) {
        RevertModal(
            onDismiss = { viewModel.setShowRevertModal(false) },
            onConfirmRevert = { viewModel.restoreFactoryDefault() },
            onRevertSingleCategory = { viewModel.revertSingleCategory(it) },
            onRevertSelectedCategories = { viewModel.revertSelectedCategories(it) }
        )
    }

    if (uiState.showPermissionDialog) {
        SelfPermissionModal(
            status = uiState.selfPermissionStatus,
            isShizukuReady = shellState.isAdbReady || (shizukuInfo.isRunning && shizukuInfo.isPermissionGranted),
            onGrantAllViaShizuku = { viewModel.grantAllSelfPermissionsViaShell() },
            onRequestNotification = { AppPermissionChecker.requestNotificationPermission(context) },
            onRequestOverlay = { AppPermissionChecker.requestOverlayPermission(context) },
            onRequestUsageStats = {
                AppPermissionChecker.requestUsageStatsPermission(context)
                viewModel.checkSelfPermissions()
            },
            onRequestAccessibility = {
                // V4.1: Ô "Trợ Năng Ngầm & Đọc Màn Hình" chỉ tự cấp được khi đã kết nối Gỡ lỗi WLAN.
                // Chưa kết nối -> chuyển thẳng sang bảng ghép nối 6 số thay vì bấm cấp vô dụng.
                viewModel.grantSilentAccessibilityWithFullAuto()
            },
            onRequestAssistant = {
                viewModel.grantAssistantPermission()
            },
            onRequestWriteSecure = {
                if (shellState.isAdbReady) {
                    viewModel.grantAllSelfPermissionsViaShell()
                } else {
                    viewModel.setShowPermissionDialog(false)
                    viewModel.setTab(MainTab.SHIZUKU)
                    viewModel.setShowWlanDialog(true)
                }
            },
            onOpenAppSettings = { AppPermissionChecker.openAppDetailsSettings(context) },
            onOpenHonorAppLaunch = { AppPermissionChecker.openHonorAppLaunchSettings(context) },
            onRepairHonor = { viewModel.repairHonorPermissions() },
            onOpenSpecialAccess = { viewModel.openSpecialAppAccess() },
            onDismiss = { viewModel.setShowPermissionDialog(false) }
        )
    }

    if (uiState.showUpgradeProDialog) {
        com.example.ui.components.UpgradeProRequiredDialog(
            reason = uiState.upgradeDialogReason,
            deviceId = com.example.core.license.LicenseManager.getDeviceId(context),
            onDismiss = { viewModel.setShowUpgradeProDialog(false) },
            onNavigateToAccount = {
                viewModel.setTab(com.example.ui.MainTab.ACCOUNT)
            }
        )
    }

    if (!uiState.crashReportToDisplay.isNullOrBlank()) {
        com.example.ui.components.CrashReportDialog(
            crashLog = uiState.crashReportToDisplay ?: "",
            onDismiss = { viewModel.dismissCrashReportDialog() },
            onClearLog = { viewModel.clearCrashReport() }
        )
    }
    if (!uiState.performanceReportToDisplay.isNullOrBlank()) {
        com.example.ui.components.CrashReportDialog(
            crashLog = uiState.performanceReportToDisplay ?: "",
            onDismiss = { viewModel.dismissPerformanceReportDialog() },
            onClearLog = { viewModel.clearPerformanceReport() },
            title = "Hộp Đen 2.0: Nhiệt & Pin",
            subtitle = "Cảnh báo hiệu năng gần đây"
        )
    }
}


