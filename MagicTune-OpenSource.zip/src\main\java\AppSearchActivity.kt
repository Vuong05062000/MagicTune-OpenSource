package com.example.core.widget

import com.example.core.perf.ScreenPowerOptimizer

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ShortcutManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.LruCache
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import androidx.core.view.WindowCompat
import com.example.MainActivity
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicCyanLight
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.MagicSurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.text.Normalizer

object AppIconMemoryCache {
    private val cache = object : LruCache<String, ImageBitmap>(48) {}

    @Volatile
    private var cacheSizedForDevice = false

    private fun ensureCacheSized(context: Context) {
        if (cacheSizedForDevice) return
        cacheSizedForDevice = true
        try {
            val budget = com.example.core.perf.DeviceMemoryStorageOptimizer.computeBudget(context)
            synchronized(cache) {
                cache.resize(budget.appIconRamCacheSize.coerceIn(24, 48))
            }
        } catch (_: Throwable) {}
    }

    fun get(packageName: String): ImageBitmap? = synchronized(cache) {
        cache.get(packageName)
    }

    fun put(packageName: String, bitmap: ImageBitmap) = synchronized(cache) {
        cache.put(packageName, bitmap)
    }

    fun clearAll() {
        try {
            synchronized(cache) {
                cache.evictAll()
            }
        } catch (_: Throwable) {}
    }

    fun trimMemory(level: Int) {
        try {
            synchronized(cache) {
                if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL ||
                    level >= android.content.ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN
                ) {
                    cache.trimToSize(16)
                } else {
                    cache.trimToSize((cache.maxSize() / 2).coerceIn(16, 24))
                }
            }
        } catch (_: Throwable) {}
    }

    fun warmUpFromDisk(context: Context, limit: Int = 16) {
        ensureCacheSized(context)
        try {
            val dir = java.io.File(
                java.io.File((context.applicationContext ?: context).filesDir, "fast_cache"),
                "icons"
            )
            if (!dir.exists() || !dir.isDirectory) return
            val files = dir.listFiles()
                ?.sortedByDescending { it.lastModified() }
                ?.take(limit)
                .orEmpty()
            for (file in files) {
                val pkg = file.name.removeSuffix(".png")
                if (pkg.isBlank() || get(pkg) != null) continue
                val bmp = com.example.core.perf.DeviceMemoryStorageOptimizer.loadIconFromDisk(context, pkg) ?: continue
                put(pkg, bmp.asImageBitmap())
            }
        } catch (_: Throwable) {}
    }

    private val iconLoadSemaphore = kotlinx.coroutines.sync.Semaphore(permits = 6)

    suspend fun loadIconBitmapThrottled(
        context: Context,
        packageName: String,
        targetSizePx: Int = 96
    ): ImageBitmap? {
        if (packageName.isBlank()) return null
        get(packageName)?.let { return it }
        return iconLoadSemaphore.withPermit {
            get(packageName)?.let { return@withPermit it }
            withContext(Dispatchers.IO) {
                loadIconBitmap(context, packageName, targetSizePx)
            }
        }
    }

    fun loadIconBitmap(context: Context, packageName: String, targetSizePx: Int = 96): ImageBitmap? {
        if (packageName.isBlank()) return null
        ensureCacheSized(context)
        get(packageName)?.let { return it }

        // 1. Ưu tiên đọc từ ROM PNG cache (0.3ms) để tránh gọi Binder PackageManager lặp lại
        com.example.core.perf.DeviceMemoryStorageOptimizer.loadIconFromDisk(context, packageName)?.let { diskBmp ->
            val img = diskBmp.asImageBitmap()
            put(packageName, img)
            return img
        }

        val isLowEnd = com.example.core.compat.DeviceCompatProfile.isLowEndOrLegacyDevice(context)
        val effectiveSizePx = if (isLowEnd) minOf(targetSizePx, 72) else minOf(targetSizePx, 96)
        return try {
            val drawable = context.packageManager.getApplicationIcon(packageName)
            val bitmap = drawableToBitmap(drawable, effectiveSizePx)
            // Nén PNG sang ByteArray xong hẳn trên luồng IO TRƯỚC khi bàn giao Bitmap cho Compose/RenderThread -> triệt tiêu 100% lỗi văng Skia/Vulkan lần nạp đầu
            com.example.core.perf.DeviceMemoryStorageOptimizer.saveIconToDisk(context, packageName, bitmap)
            val imageBitmap = bitmap.asImageBitmap()
            put(packageName, imageBitmap)
            imageBitmap
        } catch (_: Throwable) {
            null
        }
    }

    private fun drawableToBitmap(drawable: Drawable, targetSizePx: Int): Bitmap {
        val safeDrawable = try {
            drawable.constantState?.newDrawable()?.mutate() ?: drawable.mutate()
        } catch (_: Throwable) {
            drawable
        }
        val width = if (safeDrawable.intrinsicWidth > 0) safeDrawable.intrinsicWidth.coerceAtMost(targetSizePx) else targetSizePx
        val height = if (safeDrawable.intrinsicHeight > 0) safeDrawable.intrinsicHeight.coerceAtMost(targetSizePx) else targetSizePx
        // Luôn dùng ARGB_8888 chuẩn để tương thích tuyệt đối với Skia/Vulkan Android 17 (MagicOS 11) & bộ nén PNG
        val bmp = Bitmap.createBitmap(width.coerceAtLeast(1), height.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        safeDrawable.setBounds(0, 0, canvas.width, canvas.height)
        safeDrawable.draw(canvas)
        return bmp
    }
}

@Composable
fun AppIconImage(
    packageName: String,
    label: String,
    modifier: Modifier = Modifier.size(46.dp),
    cornerRadius: Dp = 14.dp
) {
    val context = LocalContext.current
    var iconBitmap by remember(packageName) {
        mutableStateOf(AppIconMemoryCache.get(packageName))
    }

    LaunchedEffect(packageName) {
        if (iconBitmap == null && packageName.isNotBlank()) {
            val cached = AppIconMemoryCache.get(packageName)
            if (cached != null) {
                iconBitmap = cached
                return@LaunchedEffect
            }
            val loaded = AppIconMemoryCache.loadIconBitmapThrottled(context, packageName)
            if (loaded != null) {
                iconBitmap = loaded
            }
        }
    }

    val currentBitmap = iconBitmap
    if (currentBitmap != null) {
        Image(
            bitmap = currentBitmap,
            contentDescription = label,
            contentScale = ContentScale.Fit,
            modifier = modifier.clip(RoundedCornerShape(cornerRadius))
        )
    } else {
        Box(
            modifier = modifier
                .clip(RoundedCornerShape(cornerRadius))
                .background(MagicCyan.copy(alpha = 0.16f))
                .border(1.dp, MagicCyan.copy(alpha = 0.4f), RoundedCornerShape(cornerRadius)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label.take(1).uppercase(),
                color = MagicCyanLight,
                fontSize = 18.sp,
                fontWeight = FontWeight.Black
            )
        }
    }
}

class AppSearchActivity : ComponentActivity() {
    companion object {
        const val ACTION_LAUNCH_PINNED_APP = "com.example.core.widget.ACTION_LAUNCH_PINNED_APP"
        const val EXTRA_PINNED_PACKAGE = "extra_pinned_package"
    }

    private var hasWindowFocusState by mutableStateOf(true)

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        hasWindowFocusState = hasFocus
    }

    override fun onResume() {
        super.onResume()
        hasWindowFocusState = true
        ScreenPowerOptimizer.onFeatureStarted(this, "AppSearch")
        MagicTuneAppSearchWidgetProvider.refreshAllWidgets(this)
    }

    override fun onStop() {
        super.onStop()
        MagicTuneAppSearchWidgetProvider.refreshAllWidgets(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        MagicTuneAppSearchWidgetProvider.refreshAllWidgets(this)
    }

    override fun onPause() {
        super.onPause()
        ScreenPowerOptimizer.onFeatureStopped(this, "AppSearch")
        MagicTuneAppSearchWidgetProvider.refreshAllWidgets(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (handleDirectLaunchOrGestureIntent(intent)) {
            return
        }
        ScreenPowerOptimizer.applyEcoRefreshRateToWindow(window.attributes)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.setSoftInputMode(
            WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE or
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        )

        setContent {
            AppSearchScreen(
                isWindowFocused = hasWindowFocusState,
                onClose = { finish() },
                onOpenGestureDraw = {
                    GestureLauncherOverlay.show(this@AppSearchActivity)
                    finish()
                },
                onOpenGestureSettings = {
                    try {
                        val intent = Intent(this@AppSearchActivity, MainActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                            putExtra("TARGET_TAB", "GESTURE_SETTINGS")
                        }
                        startActivity(intent)
                    } catch (_: Exception) {}
                    finish()
                }
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleDirectLaunchOrGestureIntent(intent)
    }

    private fun handleDirectLaunchOrGestureIntent(intent: Intent?): Boolean {
        if (intent?.action == ACTION_LAUNCH_PINNED_APP || intent?.data?.scheme == "magictune-pin") {
            val targetPkg = intent.getStringExtra(EXTRA_PINNED_PACKAGE)
                ?.takeIf { it.isNotBlank() }
                ?: intent.data?.host.orEmpty()
            if (targetPkg.isNotBlank()) {
                try {
                    val launchIntent = packageManager.getLaunchIntentForPackage(targetPkg)
                    if (launchIntent != null) {
                        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                        MagicTuneAppSearchWidgetProvider.recordAppLaunch(this, targetPkg)
                        startActivity(launchIntent)
                    } else {
                        Toast.makeText(this, "Không tìm thấy ứng dụng để mở", Toast.LENGTH_SHORT).show()
                    }
                } catch (_: Throwable) {
                    Toast.makeText(this, "Không thể mở ứng dụng này", Toast.LENGTH_SHORT).show()
                }
            }
            finish()
            @Suppress("DEPRECATION")
            overridePendingTransition(0, 0)
            return true
        }
        if (intent?.getBooleanExtra("OPEN_GESTURE_OVERLAY", false) == true) {
            GestureLauncherOverlay.show(this)
            finish()
            return true
        }
        return false
    }
}

private data class InstalledAppEntry(
    val label: String,
    val normalizedLabel: String,
    val packageName: String
)

private fun normalizeSearchText(input: String): String {
    val decomposed = Normalizer.normalize(input.lowercase(), Normalizer.Form.NFD)
    return decomposed.replace("\\p{InCombiningDiacriticalMarks}+".toRegex(), "")
        .replace('đ', 'd')
}

private fun renderAppIconForShortcut(context: Context, packageName: String): Bitmap? {
    return try {
        val drawable = context.packageManager.getApplicationIcon(packageName)
        val sizePx = 192
        val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        drawable.setBounds(0, 0, sizePx, sizePx)
        drawable.draw(canvas)
        bmp
    } catch (_: Throwable) {
        null
    }
}

private data class PinShortcutAttempt(
    val shortcutId: String,
    val submitted: Boolean,
    val beforeFeedbackMs: Long
)

private fun isShortcutAlreadyPinned(context: Context, shortcutId: String): Boolean {
    return try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val sm = context.getSystemService(ShortcutManager::class.java)
            sm?.pinnedShortcuts?.any { it.id == shortcutId } == true
        } else {
            false
        }
    } catch (_: Throwable) {
        false
    }
}

/**
 * Luôn tạo Shortcut thuộc chính gói MagicTune (trampoline `AppSearchActivity` với URI `magictune-pin://<pkg>`)
 * để Android 8–15 & launcher hãng (Honor MagicOS, Huawei, Xiaomi, Samsung) chấp nhận ghim 100%,
 * tránh bị hệ thống âm thầm hủy bỏ khi gắn Intent trỏ sang gói ứng dụng thứ 3.
 */
private fun pinAppToHomeScreen(context: Context, app: InstalledAppEntry): PinShortcutAttempt {
    val appCtx = context.applicationContext ?: context
    val beforeFeedbackMs = HomeWidgetPinHelper.lastPinnedFeedbackElapsedMs
    val uniqueId = "pin_app_${app.packageName}_${System.currentTimeMillis() % 100000L}"

    val trampolineIntent = Intent(appCtx, AppSearchActivity::class.java).apply {
        action = AppSearchActivity.ACTION_LAUNCH_PINNED_APP
        data = Uri.parse("magictune-pin://${app.packageName}")
        putExtra(AppSearchActivity.EXTRA_PINNED_PACKAGE, app.packageName)
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
    }

    val iconBitmap = renderAppIconForShortcut(appCtx, app.packageName)
    val iconCompat = if (iconBitmap != null) {
        IconCompat.createWithBitmap(iconBitmap)
    } else {
        IconCompat.createWithResource(appCtx, com.example.R.mipmap.ic_launcher)
    }

    if (ShortcutManagerCompat.isRequestPinShortcutSupported(appCtx)) {
        val callbackIntent = Intent(appCtx, HomeWidgetPinHelper.WidgetPinnedFeedbackReceiver::class.java).apply {
            action = HomeWidgetPinHelper.ACTION_WIDGET_PINNED_FEEDBACK
            putExtra(HomeWidgetPinHelper.EXTRA_WIDGET_TITLE, app.label)
        }
        val callbackPi = PendingIntent.getBroadcast(
            appCtx,
            uniqueId.hashCode(),
            callbackIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val shortcut = ShortcutInfoCompat.Builder(appCtx, uniqueId)
            .setShortLabel(app.label.take(24))
            .setLongLabel(app.label)
            .setIcon(iconCompat)
            .setIntent(trampolineIntent)
            .build()

        val accepted = try {
            ShortcutManagerCompat.requestPinShortcut(context, shortcut, callbackPi.intentSender)
        } catch (_: Throwable) {
            false
        }
        if (accepted) {
            return PinShortcutAttempt(
                shortcutId = uniqueId,
                submitted = true,
                beforeFeedbackMs = beforeFeedbackMs
            )
        }
    }

    // Dự phòng cho launcher đời cũ hỗ trợ INSTALL_SHORTCUT
    val legacySent = try {
        @Suppress("DEPRECATION")
        val legacyIntent = Intent("com.android.launcher.action.INSTALL_SHORTCUT").apply {
            putExtra(Intent.EXTRA_SHORTCUT_INTENT, trampolineIntent)
            putExtra(Intent.EXTRA_SHORTCUT_NAME, app.label)
            if (iconBitmap != null) {
                putExtra(Intent.EXTRA_SHORTCUT_ICON, iconBitmap)
            }
            putExtra("duplicate", false)
        }
        appCtx.sendBroadcast(legacyIntent)
        true
    } catch (_: Throwable) {
        false
    }
    return PinShortcutAttempt(
        shortcutId = uniqueId,
        submitted = legacySent,
        beforeFeedbackMs = beforeFeedbackMs
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppSearchScreen(
    isWindowFocused: Boolean,
    onClose: () -> Unit,
    onOpenGestureDraw: () -> Unit,
    onOpenGestureSettings: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val currentWindowFocused by rememberUpdatedState(isWindowFocused)
    val focusRequester = remember { FocusRequester() }
    var query by remember { mutableStateOf("") }
    var allApps by remember { mutableStateOf<List<InstalledAppEntry>>(emptyList()) }
    var longPressedApp by remember { mutableStateOf<InstalledAppEntry?>(null) }
    var pinPermissionBlockedApp by remember { mutableStateOf<InstalledAppEntry?>(null) }
    var recentPackages by remember {
        mutableStateOf<List<String>>(emptyList())
    }

    LaunchedEffect(currentWindowFocused) {
        if (currentWindowFocused) {
            withContext(Dispatchers.IO) {
                val recents = MagicTuneAppSearchWidgetProvider.getRecentApps(context)
                withContext(Dispatchers.Main) {
                    recentPackages = recents
                }
                MagicTuneAppSearchWidgetProvider.refreshAllWidgets(context)
            }
        }
    }

    LaunchedEffect(Unit) {
        for (attempt in 1..4) {
            try {
                focusRequester.requestFocus()
                keyboardController?.show()
            } catch (_: Exception) {}
            delay(120)
        }
    }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            val pm = context.packageManager
            val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val resolveInfos = try {
                pm.queryIntentActivities(mainIntent, 0)
            } catch (_: Exception) {
                emptyList()
            }
            val loaded = resolveInfos
                .mapNotNull { info ->
                    val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
                    val label = info.loadLabel(pm)?.toString()?.trim().takeUnless { it.isNullOrEmpty() } ?: pkg
                    InstalledAppEntry(
                        label = label,
                        normalizedLabel = normalizeSearchText(label),
                        packageName = pkg
                    )
                }
                .distinctBy { it.packageName }
                .sortedBy { it.label.lowercase() }
            allApps = loaded
        }
    }

    val filteredApps = remember(query, allApps) {
        if (query.isBlank()) {
            allApps
        } else {
            val norm = normalizeSearchText(query.trim())
            allApps.filter {
                it.normalizedLabel.contains(norm) || it.packageName.lowercase().contains(norm)
            }
        }
    }

    val recentApps = remember(recentPackages, allApps) {
        val pm = context.packageManager
        recentPackages.mapNotNull { pkg ->
            allApps.find { it.packageName == pkg } ?: try {
                val ai = pm.getApplicationInfo(pkg, 0)
                val label = pm.getApplicationLabel(ai).toString().trim().takeUnless { it.isEmpty() } ?: pkg
                InstalledAppEntry(
                    label = label,
                    normalizedLabel = normalizeSearchText(label),
                    packageName = pkg
                )
            } catch (_: Throwable) {
                null
            }
        }
    }

    fun launchSelectedApp(app: InstalledAppEntry) {
        try {
            val launchIntent = context.packageManager.getLaunchIntentForPackage(app.packageName)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                MagicTuneAppSearchWidgetProvider.recordAppLaunch(context, app.packageName)
                context.startActivity(launchIntent)
                onClose()
            }
        } catch (_: Exception) {}
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xEE020617))
            .windowInsetsPadding(WindowInsets.systemBars)
            .imePadding()
            .padding(top = 14.dp, start = 16.dp, end = 16.dp, bottom = 12.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            // Header: Hàng nút chức năng riêng & Hàng tiêu đề chữ trắng riêng toàn chiều ngang
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Nút mở nhanh tính năng Vẽ Tìm App
                        Box(
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MagicEmerald.copy(alpha = 0.18f))
                                .border(1.dp, MagicEmerald.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                                .clickable { onOpenGestureDraw() }
                                .padding(horizontal = 12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Vẽ tìm app",
                                    tint = MagicEmerald,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = "Vẽ Chữ",
                                    color = MagicEmerald,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }

                        // Nút mở nhanh trang Tab Cài Đặt Chữ
                        IconButton(
                            onClick = onOpenGestureSettings,
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(MagicCyan.copy(alpha = 0.16f))
                                .border(1.dp, MagicCyan.copy(alpha = 0.5f), CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Cài đặt chữ",
                                tint = MagicCyanLight,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        IconButton(
                            onClick = onClose,
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(MagicSurfaceCard)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Đóng",
                                tint = TextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                Text(
                    text = "⚡ Tìm & Mở Nhanh Ứng Dụng",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    maxLines = 1,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Search Box
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(MagicSurfaceDark)
                    .border(1.5.dp, MagicCyan, RoundedCornerShape(18.dp))
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = null,
                    tint = MagicCyanLight,
                    modifier = Modifier.size(20.dp)
                )
                Box(modifier = Modifier.weight(1f)) {
                    if (query.isEmpty()) {
                        Text(
                            text = "Nhập tên ứng dụng (VD: Zalo, Facebook, Gemini, Ví điện tử)...",
                            color = TextMuted,
                            fontSize = 13.5.sp
                        )
                    }
                    BasicTextField(
                        value = query,
                        onValueChange = { query = it },
                        singleLine = true,
                        textStyle = TextStyle(
                            color = Color.White,
                            fontSize = 14.5.sp,
                            fontWeight = FontWeight.SemiBold
                        ),
                        cursorBrush = SolidColor(MagicCyanLight),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(
                            onSearch = {
                                filteredApps.firstOrNull()?.let { launchSelectedApp(it) }
                            }
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .focusRequester(focusRequester)
                    )
                }
                if (query.isNotEmpty()) {
                    IconButton(
                        onClick = { query = "" },
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Xóa",
                            tint = TextMuted,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // Recent Apps (if query is empty and we have recent apps)
            if (query.isBlank() && recentApps.isNotEmpty()) {
                val displayRecents = recentApps.take(10)
                Text(
                    text = "🕒 10 ỨNG DỤNG MỞ GẦN ĐÂY",
                    color = MagicEmerald,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black
                )
                // Hàng 1 (5 ứng dụng đầu)
                val row1 = displayRecents.take(5)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    row1.forEach { app ->
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MagicSurfaceCard)
                                .combinedClickable(
                                    onClick = { launchSelectedApp(app) },
                                    onLongClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        keyboardController?.hide()
                                        longPressedApp = app
                                    }
                                )
                                .padding(vertical = 8.dp, horizontal = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            AppIconImage(
                                packageName = app.packageName,
                                label = app.label,
                                modifier = Modifier.size(42.dp),
                                cornerRadius = 12.dp
                            )
                            Text(
                                text = app.label,
                                color = Color.White,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                    if (row1.size < 5) {
                        repeat(5 - row1.size) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }

                // Hàng 2 (5 ứng dụng tiếp theo nếu có)
                val row2 = displayRecents.drop(5)
                if (row2.isNotEmpty()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        row2.forEach { app ->
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MagicSurfaceCard)
                                    .combinedClickable(
                                        onClick = { launchSelectedApp(app) },
                                        onLongClick = {
                                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                            keyboardController?.hide()
                                            longPressedApp = app
                                        }
                                    )
                                    .padding(vertical = 8.dp, horizontal = 4.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                AppIconImage(
                                    packageName = app.packageName,
                                    label = app.label,
                                    modifier = Modifier.size(42.dp),
                                    cornerRadius = 12.dp
                                )
                                Text(
                                    text = app.label,
                                    color = Color.White,
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                        if (row2.size < 5) {
                            repeat(5 - row2.size) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }

            // App Grid Header + gợi ý nhấn giữ ghim ra màn hình chính
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (query.isBlank()) "🔠 TẤT CẢ ỨNG DỤNG (${filteredApps.size})"
                    else "🔍 KẾT QUẢ (${filteredApps.size})",
                    color = MagicCyanLight,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "📌 Nhấn giữ để ghim ra Màn hình chính",
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredApps, key = { it.packageName }) { app ->
                    Column(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(MagicSurfaceDark)
                            .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(14.dp))
                            .combinedClickable(
                                onClick = { launchSelectedApp(app) },
                                onLongClick = {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    keyboardController?.hide()
                                    longPressedApp = app
                                }
                            )
                            .padding(vertical = 10.dp, horizontal = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        AppIconImage(
                            packageName = app.packageName,
                            label = app.label,
                            modifier = Modifier.size(48.dp),
                            cornerRadius = 14.dp
                        )
                        Text(
                            text = app.label,
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }

    // Hộp thoại thao tác nhanh khi nhấn giữ ứng dụng -> Đưa ra Màn hình chính
    val targetApp = longPressedApp
    if (targetApp != null) {
        AlertDialog(
            onDismissRequest = { longPressedApp = null },
            containerColor = Color(0xFF0F172A),
            shape = RoundedCornerShape(20.dp),
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    AppIconImage(
                        packageName = targetApp.packageName,
                        label = targetApp.label,
                        modifier = Modifier.size(46.dp),
                        cornerRadius = 13.dp
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = targetApp.label,
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = targetApp.packageName,
                            color = TextMuted,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = {
                            longPressedApp = null
                            scope.launch {
                                try {
                                    val shell = com.example.core.shell.ShellEngine.getInstance(context)
                                    if (shell.state.value.isAdbReady) {
                                        val myPkg = context.packageName
                                        shell.execute(
                                            "cmd appops set $myPkg INSTALL_SHORTCUT allow >/dev/null 2>&1 || appops set $myPkg INSTALL_SHORTCUT allow >/dev/null 2>&1 || true; " +
                                            "cmd appops set --user 0 $myPkg INSTALL_SHORTCUT allow >/dev/null 2>&1 || true; " +
                                            "cmd appops set $myPkg SHORTCUT allow >/dev/null 2>&1 || appops set $myPkg SHORTCUT allow >/dev/null 2>&1 || true; " +
                                            "cmd appops set $myPkg 10017 allow >/dev/null 2>&1 || true; " +
                                            "pm grant --user 0 $myPkg com.android.launcher.permission.INSTALL_SHORTCUT >/dev/null 2>&1 || pm grant $myPkg com.android.launcher.permission.INSTALL_SHORTCUT >/dev/null 2>&1 || true"
                                        )
                                    }
                                } catch (_: Throwable) {}
                                // Chờ 90ms cho hộp thoại hiện tại đóng hẳn rồi mới gọi hộp thoại ghim của hệ thống
                                delay(90L)
                                val attempt = pinAppToHomeScreen(context, targetApp)
                                if (!attempt.submitted) {
                                    pinPermissionBlockedApp = targetApp
                                } else {
                                    // Kiểm tra sau 1.2s: nếu hệ thống không hiện hộp xác nhận & chưa có shortcut nào được ghim -> máy đang chặn quyền Tạo lối tắt
                                    delay(1200L)
                                    val callbackFired = HomeWidgetPinHelper.lastPinnedFeedbackElapsedMs > attempt.beforeFeedbackMs
                                    val pinnedInSystem = isShortcutAlreadyPinned(context, attempt.shortcutId)
                                    if (pinnedInSystem && !callbackFired) {
                                        Toast.makeText(
                                            context,
                                            "✅ Đã đưa \"${targetApp.label}\" ra màn hình chính!",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    } else if (!callbackFired && !pinnedInSystem && currentWindowFocused) {
                                        pinPermissionBlockedApp = targetApp
                                    }
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MagicEmerald,
                            contentColor = Color(0xFF022C22)
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .defaultMinSize(minHeight = 36.dp)
                            .testTag("pin_app_to_home_button")
                    ) {
                        Text(
                            text = "📌 Đưa ra màn hình chính",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                longPressedApp = null
                                launchSelectedApp(targetApp)
                            },
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MagicCyan.copy(alpha = 0.55f)),
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .testTag("launch_app_from_menu_button")
                        ) {
                            Text(
                                text = "🚀 Mở app",
                                color = MagicCyanLight,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1
                            )
                        }

                        OutlinedButton(
                            onClick = {
                                longPressedApp = null
                                try {
                                    val infoIntent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                        data = Uri.parse("package:${targetApp.packageName}")
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    context.startActivity(infoIntent)
                                } catch (_: Throwable) {}
                            },
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155)),
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .testTag("app_info_from_menu_button")
                        ) {
                            Text(
                                text = "⚙️ Thông tin",
                                color = Color(0xFFCBD5E1),
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1
                            )
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(
                    onClick = { longPressedApp = null },
                    modifier = Modifier.testTag("close_pin_menu_button")
                ) {
                    Text(
                        text = "Đóng",
                        color = TextSecondary,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        )
    }

    // Hộp thoại hướng dẫn 1 chạm nếu ROM hãng (Honor MagicOS / Xiaomi / Huawei) đang chặn quyền Tạo lối tắt màn hình chính
    val blockedApp = pinPermissionBlockedApp
    if (blockedApp != null) {
        AlertDialog(
            onDismissRequest = { pinPermissionBlockedApp = null },
            containerColor = Color(0xFF0F172A),
            shape = RoundedCornerShape(20.dp),
            title = {
                Text(
                    text = "⚠️ Máy đang chặn tạo icon màn hình chính",
                    color = Color(0xFFFBBF24),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Trên máy Honor / Huawei / Xiaomi, quyền \"Tạo lối tắt màn hình chính\" thường bị tắt mặc định nên không thể thêm \"${blockedApp.label}\".",
                        color = Color(0xFFE2E8F0),
                        fontSize = 12.5.sp,
                        lineHeight = 18.sp
                    )
                    Text(
                        text = "• Bước 1: Bấm nút bên dưới -> Quyền -> bật \"Tạo lối tắt màn hình chính\"\n• Bước 2: Đảm bảo đã tắt \"Khóa bố cục màn hình chính\" rồi thử ghim lại.",
                        color = Color(0xFF94A3B8),
                        fontSize = 11.5.sp,
                        lineHeight = 17.sp
                    )
                    Button(
                        onClick = {
                            pinPermissionBlockedApp = null
                            try {
                                val permIntent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                    data = Uri.parse("package:${context.packageName}")
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                context.startActivity(permIntent)
                            } catch (_: Throwable) {}
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MagicCyan,
                            contentColor = Color(0xFF020617)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .defaultMinSize(minHeight = 36.dp)
                            .testTag("open_shortcut_permission_settings_button")
                    ) {
                        Text(
                            text = "⚙️ Mở Quyền MagicTune ngay",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(
                    onClick = { pinPermissionBlockedApp = null },
                    modifier = Modifier.testTag("close_pin_blocked_dialog_button")
                ) {
                    Text("Đóng", color = TextSecondary, fontWeight = FontWeight.SemiBold)
                }
            }
        )
    }
}
