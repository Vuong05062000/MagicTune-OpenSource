package com.example.core.widget

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** A centered utility folder; ADB-gated screen actions appear after first activation. */
object DoublePowerDockOverlay {
    @Volatile private var root: View? = null
    @Volatile private var wm: WindowManager? = null

    fun show(context: Context) {
        val app = context.applicationContext
        if (root != null) { dismiss(); return }
        if (!Settings.canDrawOverlays(app)) {
            Toast.makeText(app, "Cần cấp quyền hiển thị trên ứng dụng khác để mở thư mục chức năng.", Toast.LENGTH_LONG).show()
            return
        }
        val density = app.resources.displayMetrics.density
        fun dp(n: Int) = (n * density).toInt()
        val manager = app.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
        val dim = FrameLayout(app).apply { setBackgroundColor(0x66000000); setOnClickListener { dismiss() } }
        val folder = LinearLayout(app).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(14))
            background = GradientDrawable().apply {
                cornerRadius = dp(28).toFloat()
                setColor(0xF01A2233.toInt())
                setStroke(dp(1), 0xAA48BDF8.toInt())
            }
            setOnClickListener { }
        }
        folder.addView(TextView(app).apply {
            text = "Thư mục tiện ích"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 16f
            setPadding(0, 0, 0, dp(8))
        }, LinearLayout.LayoutParams(-1, dp(32)))
        val grid = GridLayout(app).apply { columnCount = 3; rowCount = 2 }
        data class Action(val icon: String, val label: String, val run: () -> Unit)
        val adbActivated = com.example.core.permission.AppPermissionChecker.isFirstTimeWlanActivated(app)
        val actions = buildList {
            add(Action("🌟", "MagicTune") { app.startActivity(Intent(app, com.example.MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)) })
            add(Action("✍️", "Vẽ mở app") { GestureLauncherOverlay.show(app) })
            add(Action("✦", "Magiclive") { MagicLiveFloatingOverlay.showAndStartListening(app) })
            if (adbActivated) {
                add(Action("⭕", "Khoanh AI") { CircleToSearchWindowOverlay.show(app, googleSearch = false) })
                add(Action("🔍", "Tìm Google") { CircleToSearchWindowOverlay.show(app, googleSearch = true) })
                add(Action("文A", "Dịch màn") { GoogleLiveTranslateOverlay.start(app) })
            }
        }
        actions.forEach { action ->
            val tile = LinearLayout(app).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(6), dp(6), dp(6), dp(6))
                background = GradientDrawable().apply { cornerRadius = dp(18).toFloat(); setColor(0x332E9FE6) }
                setOnClickListener { dismiss(); action.run() }
                addView(TextView(app).apply { text = action.icon; gravity = Gravity.CENTER; textSize = 26f }, LinearLayout.LayoutParams(-1, dp(42)))
                addView(TextView(app).apply { text = action.label; gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = 10f; maxLines = 1 }, LinearLayout.LayoutParams(-1, dp(20)))
            }
            grid.addView(tile, GridLayout.LayoutParams().apply {
                width = dp(76); height = dp(68)
                setMargins(dp(3), dp(3), dp(3), dp(3))
            })
        }
        folder.addView(grid)
        dim.addView(folder, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            if (android.os.Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER; windowAnimations = android.R.style.Animation_Dialog }
        try { manager.addView(dim, params); wm = manager; root = dim } catch (_: Throwable) {}
    }

    fun dismiss() {
        val view = root ?: return
        root = null
        try { wm?.removeView(view) } catch (_: Throwable) {}
        wm = null
    }
}
