// Static regression checks. Run from any directory: node tests/widget-layouts.test.cjs
// These checks do not replace APK compilation or a real launcher rendering test.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = name => fs.readFileSync(path.join(root, name), 'utf8');
const pairs = [
    ['Battery', 'battery_live'],
    ['SimpleBattery', 'battery_simple_2x2'],
    ['Memory', 'ram_rom_live'],
    ['AppSearch', 'app_search'],
    ['CalendarWeather', 'calendar_weather'],
    ['PerpetualCalendar', 'perpetual_calendar'],
    ['Printer', 'printer_quick'],
];

// Parse the layout subset used by these widgets; also catch invalid zero-width children.
function parseLayout(xml, file) {
    const stack = [];
    const ids = new Map();
    const allowed = new Set(['LinearLayout', 'ImageView', 'TextView', 'TextClock', 'ProgressBar']);
    const source = xml.replace(/<!--[\s\S]*?-->/g, '').replace(/<\?[\s\S]*?\?>/g, '');
    let roots = 0;
    for (const token of source.match(/<[^>]+>/g) || []) {
        if (token.startsWith('</')) {
            const name = token.slice(2, -1).trim();
            assert.equal(stack.pop()?.name, name, `${file}: mismatched closing ${name}`);
            continue;
        }
        const name = /^<([\w.]+)/.exec(token)?.[1];
        assert.ok(allowed.has(name), `${file}: unexpected widget view ${name}`);
        const attrs = {};
        for (const [, key, value] of token.matchAll(/([\w:]+)\s*=\s*"([^"]*)"/g)) {
            assert.ok(!(key in attrs), `${file}: duplicate attribute ${key}`);
            attrs[key] = value;
        }
        assert.ok(attrs['android:layout_width'], `${file}: ${name} missing width`);
        assert.ok(attrs['android:layout_height'], `${file}: ${name} missing height`);
        const parent = stack.at(-1);
        if (!parent) roots++;
        if (attrs['android:layout_width'] === '0dp') {
            assert.equal(parent?.attrs['android:orientation'], 'horizontal', `${file}: zero width outside horizontal row`);
            assert.ok(Number(attrs['android:layout_weight']) > 0, `${file}: zero width without weight`);
        }
        if (attrs['android:layout_height'] === '0dp') {
            assert.equal(parent?.attrs['android:orientation'], 'vertical', `${file}: zero height outside vertical column`);
            assert.ok(Number(attrs['android:layout_weight']) > 0, `${file}: zero height without weight`);
        }
        const id = attrs['android:id']?.replace('@+id/', '');
        if (id) {
            assert.ok(!ids.has(id), `${file}: duplicate ID ${id}`);
            ids.set(id, {name, attrs, parentId: parent?.attrs['android:id']});
        }
        if (!token.endsWith('/>')) stack.push({name, attrs});
    }
    assert.equal(stack.length, 0, `${file}: unclosed tags`);
    assert.equal(roots, 1, `${file}: expected one root`);
    assert.ok(!/android:layoutMargin/.test(xml), `${file}: misspelled margin attribute`);
    return ids;
}

const layouts = new Map();
for (const [provider, layout] of pairs) {
    const file = `res/layout/widget_${layout}.xml`;
    const ids = parseLayout(read(file), file);
    const code = read(`src/main/java/MagicTune${provider}WidgetProvider.kt`);
    for (const [, id] of code.matchAll(/R\.id\.(\w+)/g)) {
        assert.ok(ids.has(id), `${provider}: missing layout ID ${id}`);
    }
    layouts.set(layout, ids);
    console.log(`PASS ${provider}: layout structure and provider IDs`);
}

const calendar = layouts.get('perpetual_calendar');
for (const kind of ['cell', 'sol', 'lun']) {
    const ids = [...calendar.keys()].filter(id => id.startsWith(`pc_${kind}_`));
    assert.equal(ids.length, 42, `Calendar requires 42 ${kind} IDs`);
    for (let i = 0; i < 42; i++) assert.ok(calendar.has(`pc_${kind}_${String(i).padStart(2, '0')}`));
}
const cycleCode = read('src/main/java/WidgetCycleDisplay.kt');
for (const layout of ['battery_live', 'battery_simple_2x2']) {
    for (const [, id] of cycleCode.matchAll(/R\.id\.(\w+)/g)) assert.ok(layouts.get(layout).has(id), `${layout}: missing shared ID ${id}`);
}
const detailed = layouts.get('battery_live');
assert.equal(detailed.get('widget_header').attrs['android:layout_height'], 'wrap_content');
const printer = layouts.get('printer_quick');
assert.equal(printer.get('widget_printer_pick_label').attrs['android:text'], 'Chọn tệp');
assert.notEqual(printer.get('widget_printer_open_tab').attrs['android:layout_width'], 'wrap_content');

// Guard against shrinking the 2x2 percentage font or hiding Bluetooth battery rings again.
const simpleCode = read('src/main/java/MagicTuneSimpleBatteryWidgetProvider.kt');
assert.match(simpleCode, /if \(widgetHeightDp < 155\) 26f else 32f/);
assert.match(simpleCode, /views\.setViewVisibility\(R\.id\.widget_simple_bat_bt_row, View\.VISIBLE\)/);
const moduleConfig = read('module.toml');
assert.match(moduleConfig, /res = \["res"\]/);
assert.match(moduleConfig, /manifest = "AndroidManifest.xml"/);
assert.match(moduleConfig, /applicationId = "com.magictune.tool"/);
assert.ok(fs.existsSync(path.join(root, 'AndroidManifest.xml')));
console.log('PASS calendar 42 cells, shared battery IDs, compact sizing, printer label, resource paths');

// Verify search widget row visibility thresholds match the compact 2-row fit.
const searchCode = read('src/main/java/MagicTuneAppSearchWidgetProvider.kt');
assert.match(searchCode, /val showRecentApps = widgetHeightDp >= 92f/);
assert.match(searchCode, /val showSecondRecentRow = widgetHeightDp >= 130f/);

const weatherCode = read('src/main/java/MagicTuneCalendarWeatherWidgetProvider.kt');
assert.match(weatherCode, /val fontScale = context\.resources\.configuration\.fontScale\.coerceAtLeast\(1f\)/);
assert.match(weatherCode, /val compactFontScale = 1f/);
assert.match(weatherCode, /views\.setViewVisibility\(R\.id\.widget_forecast_row_24h_slots, if \(customCfg\.showHourly24h\) View\.VISIBLE else View\.GONE\)/);

for (const id of ['widget_btn_reset_scroll', 'widget_btn_toggle_mode', 'widget_btn_calendar_refresh',
    'widget_clock_btn_reset', 'widget_clock_btn_toggle_mode', 'widget_clock_btn_refresh']) {
    const attrs = layouts.get('calendar_weather').get(id).attrs;
    assert.equal(attrs['android:minHeight'], '32dp', `${id}: minimum touch height`);
    assert.equal(attrs['android:minWidth'], '32dp', `${id}: minimum touch width`);
    assert.equal(attrs['android:gravity'], 'center');
}
for (const id of ['widget_pc_btn_today', 'widget_pc_btn_open_app']) {
    assert.equal(calendar.get(id).attrs['android:minHeight'], '32dp');
    assert.equal(calendar.get(id).attrs['android:minWidth'], '48dp');
}
for (const id of ['widget_pc_btn_prev', 'widget_pc_btn_next']) {
    assert.equal(calendar.get(id).attrs['android:layout_height'], '40dp');
    assert.equal(calendar.get(id).attrs['android:layout_width'], '40dp');
}
console.log('PASS recent-app height/font-scale boundaries, weather font-scale guards, larger touch controls');
