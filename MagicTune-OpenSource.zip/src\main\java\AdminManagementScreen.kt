package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.auth.AdminConfigSnapshot
import com.example.core.auth.AdminDerivedUiState
import com.example.core.auth.AdminSessionCache
import com.example.core.auth.DeviceRecord
import com.example.core.auth.FirebaseAuthManager
import com.example.core.auth.UserProfile
import com.example.core.license.LicenseManager
import com.example.ui.theme.*
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Immutable
private data class AdminTab1DevicesState(
    val proDevicesCount: Int = 0,
    val accountProDevicesCount: Int = 0,
    val deviceOnlyProCount: Int = 0,
    val freeDevicesCount: Int = 0,
    val suspiciousDevicesCount: Int = 0,
    val online24hCount: Int = 0,
    val boundCount: Int = 0,
    val guestCount: Int = 0,
    val filteredDevices: List<DeviceRecord> = emptyList()
)

@Immutable
private data class AdminTab2IntentsState(
    val paidActionCount: Int = 0,
    val qrOpenedCount: Int = 0,
    val approvedCount: Int = 0,
    val filteredIntents: List<com.example.core.auth.PaymentIntentRecord> = emptyList()
)

@Immutable
private data class AdminTab3UsersState(
    val adminCount: Int = 0,
    val proUsersCount: Int = 0,
    val accountProCount: Int = 0,
    val deviceProCount: Int = 0,
    val normalUsersCount: Int = 0,
    val revokedCount: Int = 0,
    val online24hCount: Int = 0,
    val multiDeviceCount: Int = 0,
    val filteredUsers: List<UserProfile> = emptyList()
)

@Immutable
private data class AdminTab4RecoveriesState(
    val pendingRecCount: Int = 0,
    val resolvedRecCount: Int = 0,
    val filteredRecoveries: List<LicenseManager.ProRecoveryRecord> = emptyList()
)

@Immutable
private data class AdminTab5AiLogsState(
    val grantedCount: Int = 0,
    val blockedCount: Int = 0,
    val inquiryCount: Int = 0,
    val filteredAiLogs: List<LicenseManager.AiProChatLogRecord> = emptyList()
)

@Immutable
private data class AdminTab6StoreAppsState(
    val pendingCount: Int = 0,
    val approvedCount: Int = 0,
    val rejectedCount: Int = 0,
    val filteredStoreApps: List<com.example.data.HonorAppItem> = emptyList()
)

@Immutable
private data class AdminSubTabDef(
    val id: Int,
    val icon: String,
    val slot: String,
    val title: String,
    val badgeCount: Int? = null,
    val color: Color,
    val selectedBg: Color,
    val unselectedBg: Color,
    val selectedBorder: Color,
    val unselectedBorder: Color
)

@Composable
fun AdminManagementScreen(
    isActive: Boolean = true,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val lazyListState = rememberLazyListState()

    val adminSnapshot by AdminSessionCache.snapshotFlow.collectAsStateWithLifecycle()
    val derivedState by AdminSessionCache.derivedStateFlow.collectAsStateWithLifecycle()
    val cachedConfig by AdminSessionCache.adminConfigFlow.collectAsStateWithLifecycle()

    val authSession by FirebaseAuthManager.authSessionFlow.collectAsStateWithLifecycle()
    var currentUser by remember { mutableStateOf(FirebaseAuthManager.getCurrentUser()) }
    var userProfile by remember { mutableStateOf<UserProfile?>(null) }
    val allUsersList = adminSnapshot.users
    val allDevicesList = adminSnapshot.devices
    val allStoreApps = adminSnapshot.storeApps
    // Cache cấu hình / snapshot offline chỉ phục vụ hiển thị dữ liệu, không phải bằng chứng quyền Admin.
    // Chỉ mở trang sau khi phiên đăng nhập hoặc dấu xác minh Admin hiện có được kiểm tra.
    var isAdmin by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(true) }
    var verifiedAdminSessionKey by remember { mutableStateOf("") }
    val isSyncingMetrics = adminSnapshot.isSyncing
    val lastMetricsSyncTime = adminSnapshot.lastSyncLabel
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Khởi tạo tức thì 0ms từ bộ nhớ đệm RAM AdminConfigSnapshot (đã nạp nền khi mở app)
    var customPriceInput by remember { mutableStateOf(cachedConfig.proPrice) }
    var proOriginalPriceInput by remember { mutableStateOf(cachedConfig.proPriceOriginal) }
    var accountProPriceInput by remember { mutableStateOf(cachedConfig.accountProPrice) }
    var accountProOriginalPriceInput by remember { mutableStateOf(cachedConfig.accountProPriceOriginal) }
    var upgradeAccountProPriceInput by remember { mutableStateOf(cachedConfig.upgradeAccountProPrice) }
    var isProSaleActiveState by remember { mutableStateOf(cachedConfig.isProSaleActive) }
    var autoFreeDaysInput by remember { mutableStateOf(cachedConfig.autoFreeDays) }
    var bankNameInput by remember { mutableStateOf(cachedConfig.bankName) }
    var bankCodeInput by remember { mutableStateOf(cachedConfig.bankCode) }
    var accountNumberInput by remember { mutableStateOf(cachedConfig.accountNumber) }
    var accountHolderInput by remember { mutableStateOf(cachedConfig.accountHolder) }
    var supportLinkInput by remember { mutableStateOf(cachedConfig.supportLink) }
    var youtubeLinkInput by remember { mutableStateOf(cachedConfig.youtubeLink) }
    var globalUpdateLinkInput by remember {
        mutableStateOf(LicenseManager.resolveGoogleDriveApkLink(context, cachedConfig.globalUpdateLink))
    }
    var showFbHeaderIconState by remember { mutableStateOf(cachedConfig.showFbHeaderIcon) }
    var showYtHeaderIconState by remember { mutableStateOf(cachedConfig.showYtHeaderIcon) }
    var showVietQrPreview by remember { mutableStateOf(false) }

    var isAppFreeModeState by remember { mutableStateOf(cachedConfig.isAppFreeMode) }
    var freeTrialLimitInput by remember { mutableStateOf(cachedConfig.freeTrialLimit) }
    var groqApiKeyPoolInput by remember { mutableStateOf(cachedConfig.groqApiKeyPool) }
    var autoApproveProEnabled by remember { mutableStateOf(cachedConfig.autoApproveProEnabled) }

    val adminFocusManager = androidx.compose.ui.platform.LocalFocusManager.current
    val adminKeyboardController = androidx.compose.ui.platform.LocalSoftwareKeyboardController.current

    var unifiedManageMode by remember { mutableStateOf("DEVICES") } // "DEVICES" hoặc "USERS"
    var adminSubTab by remember { mutableIntStateOf(0) }
    var adminConfigVersion by remember { mutableIntStateOf(0) }

    val switchAdminSubTab: (Int) -> Unit = { targetTab ->
        try {
            adminFocusManager.clearFocus(force = true)
            adminKeyboardController?.hide()
        } catch (_: Throwable) {}
        adminSubTab = targetTab
    }

    LaunchedEffect(adminSubTab) {
        try {
            adminFocusManager.clearFocus(force = true)
            adminKeyboardController?.hide()
        } catch (_: Throwable) {}
    }

    // Đồng bộ gọn gàng mọi trường cấu hình trên Dispatchers.IO rồi đổ vào UI 1 lần duy nhất (0ms đơ khung hình đầu)
    var lastAppliedConfigTs by remember { mutableLongStateOf(if (cachedConfig.isLoaded) cachedConfig.updatedAtMs else 0L) }
    LaunchedEffect(cachedConfig.updatedAtMs) {
        if (cachedConfig.isLoaded && cachedConfig.updatedAtMs > lastAppliedConfigTs) {
            lastAppliedConfigTs = cachedConfig.updatedAtMs
            customPriceInput = cachedConfig.proPrice
            proOriginalPriceInput = cachedConfig.proPriceOriginal
            accountProPriceInput = cachedConfig.accountProPrice
            accountProOriginalPriceInput = cachedConfig.accountProPriceOriginal
            upgradeAccountProPriceInput = cachedConfig.upgradeAccountProPrice
            isProSaleActiveState = cachedConfig.isProSaleActive
            autoFreeDaysInput = cachedConfig.autoFreeDays
            bankNameInput = cachedConfig.bankName
            bankCodeInput = cachedConfig.bankCode
            accountNumberInput = cachedConfig.accountNumber
            accountHolderInput = cachedConfig.accountHolder
            supportLinkInput = cachedConfig.supportLink
            youtubeLinkInput = cachedConfig.youtubeLink
            globalUpdateLinkInput = LicenseManager.resolveGoogleDriveApkLink(context, cachedConfig.globalUpdateLink)
            showFbHeaderIconState = cachedConfig.showFbHeaderIcon
            showYtHeaderIconState = cachedConfig.showYtHeaderIcon
            isAppFreeModeState = cachedConfig.isAppFreeMode
            freeTrialLimitInput = cachedConfig.freeTrialLimit
            groqApiKeyPoolInput = cachedConfig.groqApiKeyPool
            autoApproveProEnabled = cachedConfig.autoApproveProEnabled
        }
    }

    LaunchedEffect(Unit) {
        val pendingTab = withContext(Dispatchers.IO) {
            val prefs = context.getSharedPreferences("magictune_pro_prefs", android.content.Context.MODE_PRIVATE)
            val tab = prefs.getInt("pending_admin_sub_tab", -1)
            if (tab in 0..7) {
                prefs.edit().remove("pending_admin_sub_tab").apply()
            }
            tab
        }
        if (pendingTab in 0..7) {
            if (pendingTab == 3) {
                unifiedManageMode = "USERS"
                adminSubTab = 1
            } else {
                adminSubTab = pendingTab
            }
        }
        // Luôn làm mới bản chụp cấu hình từ máy trên luồng IO (không chặn Frame 1) để đồng bộ mọi chỉnh sửa cục bộ
        AdminSessionCache.loadAdminConfigSnapshot(context)
        // Đồng bộ cấu hình mới nhất từ Firestore app_config/global dưới nền (không chặn Main Thread)
        LicenseManager.fetchGlobalConfigNow(context) {
            coroutineScope.launch(Dispatchers.IO) {
                AdminSessionCache.loadAdminConfigSnapshot(context)
            }
        }
    }

    // Search & Quick Filter & Pagination & Confirmation Dialog states
    var deviceSearchQuery by remember { mutableStateOf("") }
    var searchQuery by remember { mutableStateOf("") } // Dùng riêng cho Tab Người Dùng (Users)
    var selectedFilterChip by remember { mutableStateOf("Tất cả") }
    var deviceFilterTab by remember { mutableStateOf("Tất cả") }
    var deviceSortMode by remember { mutableStateOf(AdminUserDeviceSortMode.RECENT_ACTIVE) }
    var userSortMode by remember { mutableStateOf(AdminUserDeviceSortMode.RECENT_ACTIVE) }
    var multiSelectMode by remember { mutableStateOf(false) }
    val selectedDeviceIds = remember { mutableStateListOf<String>() }
    val selectedUserKeys = remember { mutableStateListOf<String>() }
    val expandedDeviceIds = remember { mutableStateListOf<String>() }
    val expandedUserKeys = remember { mutableStateListOf<String>() }
    var showQuickCloudLookupDialog by remember { mutableStateOf(false) }
    var quickCloudLookupQuery by remember { mutableStateOf("") }
    var quickCloudAuditResult by remember { mutableStateOf<LicenseManager.AdminCloudLookupResult?>(null) }
    var isQuickCloudLookingUp by remember { mutableStateOf(false) }
    var deviceCurrentPage by remember { mutableIntStateOf(0) }
    val devicePageSize = 10
    var currentPage by remember { mutableIntStateOf(0) }
    val pageSize = 10
    var hasMoreDevices by remember(authSession.uid) { mutableStateOf(true) }
    var hasMoreUsers by remember(authSession.uid) { mutableStateOf(true) }
    var isLoadingMoreDevices by remember { mutableStateOf(false) }
    var isLoadingMoreUsers by remember { mutableStateOf(false) }

    fun loadMoreAdminDevices() {
        if (isLoadingMoreDevices || !hasMoreDevices) return
        coroutineScope.launch {
            isLoadingMoreDevices = true
            try {
                val page = FirebaseAuthManager.fetchNextDevicesPage()
                AdminSessionCache.appendDevicesPage(page.items)
                hasMoreDevices = page.hasMore
                deviceCurrentPage = 0
                if (page.items.isEmpty() && !page.hasMore) {
                    Toast.makeText(context, "Đã tải hết các thiết bị từ máy chủ.", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Không tải thêm được thiết bị: ${e.localizedMessage ?: "lỗi kết nối"}", Toast.LENGTH_LONG).show()
            } finally {
                isLoadingMoreDevices = false
            }
        }
    }

    fun loadMoreAdminUsers() {
        if (isLoadingMoreUsers || !hasMoreUsers) return
        coroutineScope.launch {
            isLoadingMoreUsers = true
            try {
                val page = FirebaseAuthManager.fetchNextUsersPage()
                AdminSessionCache.appendUsersPage(page.items)
                hasMoreUsers = page.hasMore
                currentPage = 0
                if (page.items.isEmpty() && !page.hasMore) {
                    Toast.makeText(context, "Đã tải hết người dùng từ máy chủ.", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Không tải thêm được người dùng: ${e.localizedMessage ?: "lỗi kết nối"}", Toast.LENGTH_LONG).show()
            } finally {
                isLoadingMoreUsers = false
            }
        }
    }

    // Bộ lọc cho Ô 3: Chờ Duyệt (Payment Intents)
    var intentFilterTab by remember { mutableStateOf("Tất cả") } // "Tất cả", "🔥 BÁO CHUYỂN KHOẢN", "👁️ XEM QR", "✅ ĐÃ DUYỆT"
    var intentSearchQuery by remember { mutableStateOf("") }

    // Bộ lọc cho Ô 5: Khôi Phục Pro (Recovery Requests)
    var recoveryFilterTab by remember { mutableStateOf("Tất cả") } // "Tất cả", "⏳ CHỜ XỬ LÝ", "✅ ĐÃ CẤP LẠI"
    var recoverySearchQuery by remember { mutableStateOf("") }

    // Bộ lọc cho Ô 7: Kho Ứng Dụng (Store Apps)
    var storeAppFilterTab by remember { mutableStateOf("Tất cả") } // "Tất cả", "⏳ CHỜ DUYỆT", "✅ ĐÃ DUYỆT", "❌ TỪ CHỐI"
    var storeAppSearchQuery by remember { mutableStateOf("") }

    var targetUserForAction by remember { mutableStateOf<UserProfile?>(null) }
    var pendingActionType by remember { mutableStateOf<String?>(null) } // "pro" or "admin"
    var targetDeviceForAction by remember { mutableStateOf<DeviceRecord?>(null) }

    // Hộp thoại Hạ Cấp có chọn cấp bậc muốn hạ về (Tài khoản hoặc Thiết bị)
    var downgradeTargetUser by remember { mutableStateOf<UserProfile?>(null) }
    var downgradeTargetDevice by remember { mutableStateOf<DeviceRecord?>(null) }

    // License Key Generator & Pro Upgrade 10x states (0ms từ RAM)
    var genDeviceIdInput by remember { mutableStateOf(cachedConfig.deviceId) }
    LaunchedEffect(cachedConfig.deviceId) {
        if (genDeviceIdInput.isBlank() && cachedConfig.deviceId.isNotBlank()) {
            genDeviceIdInput = cachedConfig.deviceId
        }
    }
    var genReasonInput by remember { mutableStateOf("") }
    var generatedKeyOutput by remember { mutableStateOf("") }
    var proLookupResult by remember { mutableStateOf<LicenseManager.AdminCloudLookupResult?>(null) }
    var isLookingUpProTarget by remember { mutableStateOf(false) }
    var activeProReceipt by remember { mutableStateOf<ProGrantReceiptData?>(null) }
    var showBatchGrantDialog by remember { mutableStateOf(false) }
    var showAutoAdminTesterDialog by remember { mutableStateOf(false) }
    var isCleaningStaleIntents by remember { mutableStateOf(false) }

    val paymentIntentsList = adminSnapshot.paymentIntents
    val approvedIntentsList = adminSnapshot.approvedIntents
    val saveApprovedIntent: (com.example.core.auth.PaymentIntentRecord) -> Unit = { intent ->
        AdminSessionCache.addApprovedIntent(context, intent)
    }
    val proRecoveryRequestsList = adminSnapshot.proRecoveries
    val aiProChatLogsList = adminSnapshot.aiLogs
    var aiLogFilterTab by remember { mutableStateOf("Tất cả") }
    var aiLogSearchQuery by remember { mutableStateOf("") }
    var showCleanupOldDataDialog by remember { mutableStateOf(false) }
    val cleanupProgress by LicenseManager.cleanupProgressFlow.collectAsStateWithLifecycle()
    var lastHandledCleanupTs by remember { mutableLongStateOf(cleanupProgress.lastFinishedAtMs) }

    var autoApprovedCountSession by remember { mutableIntStateOf(0) }
    val autoProcessedDeviceIds = remember { java.util.concurrent.ConcurrentHashMap.newKeySet<String>() }

    val logDetailDateFormatter = remember {
        java.text.SimpleDateFormat("HH:mm:ss dd/MM/yyyy", java.util.Locale.getDefault())
    }

    fun refreshAllAdminMetricsViaRest(showToastOnDone: Boolean = false, force: Boolean = false) {
        AdminSessionCache.refreshFromCloud(
            context = context,
            force = showToastOnDone || force,
            onFinished = if (showToastOnDone) {
                { _, _, _, msg ->
                    if (msg.isNotBlank()) {
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    }
                }
            } else null
        )
    }

    LaunchedEffect(cleanupProgress.lastFinishedAtMs) {
        if (cleanupProgress.lastFinishedAtMs > lastHandledCleanupTs) {
            lastHandledCleanupTs = cleanupProgress.lastFinishedAtMs
            if (cleanupProgress.lastCompletedResult?.success == true) {
                refreshAllAdminMetricsViaRest(showToastOnDone = false, force = true)
            }
        }
    }

    // Đồng bộ hồ sơ người dùng & kiểm tra quyền Admin hoàn toàn trên Dispatchers.IO (0ms Main Thread)
    LaunchedEffect(authSession) {
        // Thu hồi trạng thái trước khi xác minh phiên mới, tránh giữ quyền Admin cũ khi đổi tài khoản.
        isAdmin = false
        isLoading = true
        verifiedAdminSessionKey = ""
        userProfile = null
        errorMessage = null
        val (u, alreadyVerifiedAdmin) = withContext(Dispatchers.IO) {
            val user = FirebaseAuthManager.getCurrentUser()
            val verified = FirebaseAuthManager.isCurrentAdmin(context, null) ||
                LicenseManager.isCurrentUserAdmin(context)
            user to verified
        }
        if (u != null || currentUser == null) {
            currentUser = u
        }
        val email = (u?.email ?: authSession.email).trim()
        val verifiedSessionKey = authSession.uid.ifBlank {
            email.lowercase().ifBlank { u?.uid ?: if (alreadyVerifiedAdmin) "local_admin" else "" }
        }
        if ((u != null && email.equals("admin@example.com", ignoreCase = true)) || alreadyVerifiedAdmin) {
            isAdmin = true
            verifiedAdminSessionKey = verifiedSessionKey
            isLoading = false
            if (email.isNotBlank()) {
                withContext(Dispatchers.IO) {
                    LicenseManager.markLocalAdminVerified(context, email)
                }
            }
            if (u != null) {
                coroutineScope.launch(Dispatchers.IO) {
                    try {
                        val p = FirebaseAuthManager.syncUserProfile(context, force = false)
                        withContext(Dispatchers.Main) { userProfile = p }
                    } catch (_: Exception) {}
                }
            }
        } else if (u != null) {
            coroutineScope.launch(Dispatchers.IO) {
                try {
                    val p = FirebaseAuthManager.syncUserProfile(context, force = false)
                    val verifiedAfterSync = FirebaseAuthManager.isCurrentAdmin(context, p) ||
                        LicenseManager.isCurrentUserAdmin(context)
                    withContext(Dispatchers.Main) {
                        userProfile = p
                        isAdmin = verifiedAfterSync
                        verifiedAdminSessionKey = if (verifiedAfterSync) verifiedSessionKey else ""
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        isAdmin = false
                        verifiedAdminSessionKey = ""
                        userProfile = null
                        errorMessage = "Lỗi tải hồ sơ: ${e.localizedMessage}"
                    }
                } finally {
                    withContext(Dispatchers.Main) {
                        isLoading = false
                    }
                }
            }
        } else {
            isAdmin = alreadyVerifiedAdmin
            isLoading = false
        }
    }

    // Nạp tức thì dữ liệu Offline đã lưu trên máy & đồng bộ nhẹ nhàng từ Cloud (chỉ chạy khi tab Admin đang hiển thị)
    LaunchedEffect(isActive, isAdmin) {
        if (isActive && isAdmin) {
            AdminSessionCache.ensureOfflineHydrated(context)
            refreshAllAdminMetricsViaRest(showToastOnDone = false, force = false)
        }
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, isActive, isAdmin) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME && isActive && isAdmin) {
                AdminSessionCache.attachRealtimeListeners(context)
            } else if (event == Lifecycle.Event.ON_STOP || event == Lifecycle.Event.ON_PAUSE) {
                AdminSessionCache.detachRealtimeListeners(force = true)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        if (isActive && isAdmin) {
            AdminSessionCache.attachRealtimeListeners(context)
        }
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            AdminSessionCache.detachRealtimeListeners(force = true)
        }
    }

    // Dọn dẹp bộ nhớ đệm và ngắt kết nối listeners khi rời khỏi Tab Admin sang tab khác
    LaunchedEffect(isActive) {
        if (!isActive) {
            AdminSessionCache.detachRealtimeListeners(force = true)
        }
    }

    // HỆ THỐNG AUTO-ADMIN THÔNG MINH (CHỐNG KÍCH HOẠT KHI CHƯA THANH TOÁN):
    // Chạy trên Dispatchers.Default/IO để không bao giờ gây đơ UI Thread khi danh sách thiết bị/người dùng lớn.
    LaunchedEffect(isAdmin, autoApproveProEnabled, proRecoveryRequestsList, allDevicesList, aiProChatLogsList) {
        if (isAdmin && autoApproveProEnabled && proRecoveryRequestsList.isNotEmpty()) {
            val processedSnapshot = autoProcessedDeviceIds.toSet()
            val devicesSnapshot = allDevicesList
            val logsSnapshot = aiProChatLogsList
            val pendingSnapshot = proRecoveryRequestsList

            val matchedToRestore = withContext(Dispatchers.Default) {
                val candidates = pendingSnapshot.filter {
                    it.status == "PENDING" && it.deviceId.isNotBlank() && !processedSnapshot.contains("REC_${it.deviceId}")
                }
                if (candidates.isEmpty()) return@withContext emptyList<LicenseManager.ProRecoveryRecord>()

                val validProDevicesByNormId = devicesSnapshot
                    .filter { !it.revokedByAdmin && it.isPro }
                    .groupBy { LicenseManager.normalizeDeviceIdForMatch(it.deviceId) }
                val validAiLogsByNormId = logsSnapshot
                    .filter { it.proGranted && it.bankTransCode.length >= 5 }
                    .associateBy { LicenseManager.normalizeDeviceIdForMatch(it.deviceId) }

                candidates.filter { req ->
                    val normReqId = LicenseManager.normalizeDeviceIdForMatch(req.deviceId)
                    val expectedDeviceKey = LicenseManager.generateLicenseKeyForDevice(req.deviceId)
                    val expectedAccountKey = LicenseManager.generateAccountProLicenseKeyForDevice(req.deviceId)
                    val verifiedInDevices = validProDevicesByNormId[normReqId]?.any { d ->
                        d.licenseKey.equals(expectedDeviceKey, ignoreCase = true) ||
                            d.licenseKey.equals(expectedAccountKey, ignoreCase = true) ||
                            d.bankTransCode.isNotBlank() ||
                            d.approvedByAiReason.contains("ADMIN", ignoreCase = true)
                    } == true
                    val verifiedInAiLogs = validAiLogsByNormId.containsKey(normReqId)
                    verifiedInDevices || verifiedInAiLogs
                }
            }

            for (req in matchedToRestore) {
                val keyTag = "REC_${req.deviceId}"
                if (autoProcessedDeviceIds.contains(keyTag)) continue
                autoProcessedDeviceIds.add(keyTag)
                withContext(Dispatchers.IO) {
                    try {
                        val isAccHint = req.note.contains("Tài Khoản", ignoreCase = true) || req.note.contains("TKPRO", ignoreCase = true)
                        LicenseManager.adminRestoreProForDevice(
                            deviceId = req.deviceId,
                            context = context,
                            requestDocId = req.id,
                            ownerEmail = req.ownerEmail,
                            isAccountProHint = isAccHint
                        ) { _ -> }
                        LicenseManager.executeVerifiedProGrant(
                            context = context,
                            rawTargetDeviceId = req.deviceId,
                            grantAccountPro = isAccHint,
                            reason = "AUTO_ADMIN_VERIFIED_RECOVERY_APPROVED"
                        )
                        withContext(Dispatchers.Main) {
                            autoApprovedCountSession++
                        }
                    } catch (_: Exception) {}
                }
            }
        }
    }

    // derivedState được tính sẵn trên Dispatchers.Default bên trong AdminSessionCache & giữ nguyên giữa các lần chuyển tab

    val globalMergedDevices = derivedState.mergedDevices
    val globalMergedUsers = derivedState.mergedUsers
    val aiBillLogByNormDevId = derivedState.aiBillLogByNormDevId
    val aiBillLogByEmail = derivedState.aiBillLogByEmail
    val userByUid = derivedState.userByUid
    val userByNormDevId = derivedState.userByNormDevId
    val userByEmail = derivedState.userByEmail
    val deviceByOwnerUid = derivedState.deviceByOwnerUid
    val deviceByNormDevId = derivedState.deviceByNormDevId
    val totalAccountProCount = derivedState.totalAccountProCount
    val totalDeviceProCount = derivedState.totalDeviceProCount
    val deduplicatedPaymentIntents = derivedState.deduplicatedPaymentIntents
    val totalPendingCount = deduplicatedPaymentIntents.size
    val blockedFraudOrUnpaidCount = derivedState.blockedFraudOrUnpaidCount
    val aiBlockedAlertByNormDevId = derivedState.aiBlockedAlertByNormDevId
    val aiBlockedAlertByEmail = derivedState.aiBlockedAlertByEmail

    val linkedDevicesByUserKey = derivedState.linkedDevicesByUserKey
    val online24hDevicesCount = derivedState.online24hDevicesCount
    val online24hUsersCount = derivedState.online24hUsersCount
    val guestDevicesCount = derivedState.guestDevicesCount
    val boundDevicesCount = derivedState.boundDevicesCount

    var notificationPaymentEnabled by remember { mutableStateOf(cachedConfig.autoApproveProEnabled) }
    var isNotifListenerGranted by remember { mutableStateOf(cachedConfig.isNotifListenerGranted) }
    var simulateFreeMode by remember { mutableStateOf(cachedConfig.simulateFreeMode) }
    LaunchedEffect(cachedConfig.updatedAtMs) {
        if (cachedConfig.isLoaded) {
            notificationPaymentEnabled = cachedConfig.autoApproveProEnabled
            isNotifListenerGranted = cachedConfig.isNotifListenerGranted
            simulateFreeMode = cachedConfig.simulateFreeMode
        }
    }
    LaunchedEffect(notificationPaymentEnabled) {
        if (notificationPaymentEnabled) {
            withContext(Dispatchers.IO) {
                LicenseManager.autoEnableNotificationListenerIfAdmin(context)
            }
            kotlinx.coroutines.delay(600L)
            isNotifListenerGranted = withContext(Dispatchers.IO) {
                LicenseManager.isNotificationListenerGranted(context)
            }
        }
    }
    // Đồng bộ simulateFreeMode trên Dispatchers.IO không gây recompose root khi proStateVersionFlow bắn các sự kiện khác
    LaunchedEffect(Unit) {
        LicenseManager.proStateVersionFlow.collect {
            val latest = withContext(Dispatchers.IO) {
                LicenseManager.isAdminSimulateFreeMode(context)
            }
            if (latest != simulateFreeMode) {
                simulateFreeMode = latest
            }
        }
    }

    var intentVisibleLimit by remember { mutableIntStateOf(20) }
    LaunchedEffect(intentFilterTab, intentSearchQuery) { intentVisibleLimit = 20 }
    var recoveryVisibleLimit by remember { mutableIntStateOf(20) }
    LaunchedEffect(recoveryFilterTab, recoverySearchQuery) { recoveryVisibleLimit = 20 }
    var aiLogVisibleLimit by remember { mutableIntStateOf(20) }
    LaunchedEffect(aiLogSearchQuery, aiLogFilterTab) { aiLogVisibleLimit = 20 }
    var storeAppVisibleLimit by remember { mutableIntStateOf(20) }
    LaunchedEffect(storeAppFilterTab, storeAppSearchQuery) { storeAppVisibleLimit = 20 }

    val quickPendingRecoveryBadge = remember(proRecoveryRequestsList) {
        proRecoveryRequestsList.count { it.status == "PENDING" }
    }
    val quickPendingStoreBadge = remember(allStoreApps) {
        allStoreApps.count { it.status == "PENDING" }
    }

    var tab1State by remember { mutableStateOf(AdminTab1DevicesState()) }
    LaunchedEffect(adminSubTab, unifiedManageMode, globalMergedDevices, aiBillLogByNormDevId, deviceFilterTab, deviceSearchQuery, deviceSortMode) {
        if (adminSubTab != 1 || unifiedManageMode != "DEVICES") return@LaunchedEffect
        val devs = globalMergedDevices
        val billMap = aiBillLogByNormDevId
        val filter = deviceFilterTab
        val sortMode = deviceSortMode
        val q = deviceSearchQuery.trim()
        val computed = withContext(Dispatchers.Default) {
            var pro = 0
            var accPro = 0
            var devPro = 0
            var free = 0
            var suspect = 0
            var online24 = 0
            var bound = 0
            var guest = 0
            val nowMs = System.currentTimeMillis()
            for (dev in devs) {
                if ((dev.lastActive?.toDate()?.time ?: 0L) >= nowMs - 86_400_000L) online24++
                val isGuestDev = !dev.ownerEmail.contains("@") ||
                    dev.ownerEmail.contains("Khách vãng lai", true) ||
                    dev.ownerEmail.contains("Chưa đăng nhập", true)
                if (isGuestDev) guest++ else bound++

                val isEffectivePro = dev.isPro && !dev.revokedByAdmin
                val normId = LicenseManager.normalizeDeviceIdForMatch(dev.deviceId)
                val isInvalidFormat = dev.deviceId.trim().length < 4
                val isSuspectNoProof = isEffectivePro &&
                    dev.licenseKey.isBlank() &&
                    dev.approvedByAiReason.isBlank() &&
                    dev.bankTransCode.isBlank() &&
                    !billMap.containsKey(normId)
                val isSuspect = isEffectivePro && (isInvalidFormat || isSuspectNoProof)
                if (isSuspect) suspect++
                if (isEffectivePro && !isInvalidFormat) {
                    pro++
                    if (dev.isAccountPro || dev.proTier == "ACCOUNT_PRO") accPro++ else devPro++
                }
                if (!isEffectivePro) free++
            }
            val filteredList = devs.filter { d ->
                val isEffectivePro = d.isPro && !d.revokedByAdmin
                val normId = LicenseManager.normalizeDeviceIdForMatch(d.deviceId)
                val isInvalidFormat = d.deviceId.trim().length < 4
                val isSuspectNoProof = isEffectivePro &&
                    d.licenseKey.isBlank() &&
                    d.approvedByAiReason.isBlank() &&
                    d.bankTransCode.isBlank() &&
                    !billMap.containsKey(normId)
                val isSuspectPro = isEffectivePro && (isInvalidFormat || isSuspectNoProof)
                val isAccountProDev = isEffectivePro && (d.isAccountPro || d.proTier == "ACCOUNT_PRO")
                val isDeviceProDev = isEffectivePro && !d.isAccountPro && d.proTier != "ACCOUNT_PRO"
                val isOnline = (d.lastActive?.toDate()?.time ?: 0L) >= nowMs - 86_400_000L
                val isGuestDev = !d.ownerEmail.contains("@") ||
                    d.ownerEmail.contains("Khách vãng lai", true) ||
                    d.ownerEmail.contains("Chưa đăng nhập", true)
                val matchesTab = when (filter) {
                    "🟢 Online 24h" -> isOnline
                    "⚡ ĐÃ LÊN PRO" -> isEffectivePro && !isInvalidFormat
                    "👑 PRO TÀI KHOẢN" -> isAccountProDev && !isInvalidFormat
                    "📱 PRO THIẾT BỊ" -> isDeviceProDev && !isInvalidFormat
                    "👤 CÓ TÀI KHOẢN" -> !isGuestDev
                    "🚀 KHÁCH VÃNG LAI" -> isGuestDev
                    "🔓 CHƯA LÊN PRO" -> !isEffectivePro
                    "🚨 NGHI VẤN" -> isSuspectPro
                    else -> true
                }
                val matchesSearch = q.isBlank() ||
                    d.deviceId.contains(q, true) ||
                    d.hardwareId.contains(q, true) ||
                    d.model.contains(q, true) ||
                    d.ownerEmail.contains(q, true) ||
                    d.ownerName.contains(q, true) ||
                    d.licenseKey.contains(q, true)
                matchesTab && matchesSearch
            }
            val sorted = when (sortMode) {
                AdminUserDeviceSortMode.RECENT_ACTIVE -> filteredList.sortedWith(
                    compareByDescending<DeviceRecord> { it.lastActive?.toDate()?.time ?: it.proActivatedAt?.toDate()?.time ?: it.createdAt?.toDate()?.time ?: 0L }
                        .thenByDescending { it.isPro && !it.revokedByAdmin }
                )
                AdminUserDeviceSortMode.PRO_ACTIVATED -> filteredList.sortedWith(
                    compareByDescending<DeviceRecord> { it.isPro && !it.revokedByAdmin }
                        .thenByDescending { it.proActivatedAt?.toDate()?.time ?: it.lastActive?.toDate()?.time ?: 0L }
                )
                AdminUserDeviceSortMode.NAME_OR_ID -> filteredList.sortedBy {
                    it.model.ifBlank { it.deviceId }.lowercase()
                }
                AdminUserDeviceSortMode.MOST_TRIALS -> filteredList.sortedWith(
                    compareByDescending<DeviceRecord> { it.freeTrialUsed }
                        .thenByDescending { it.lastActive?.toDate()?.time ?: 0L }
                )
            }
            AdminTab1DevicesState(pro, accPro, devPro, free, suspect, online24, bound, guest, sorted)
        }
        tab1State = computed
    }

    var tab2State by remember { mutableStateOf(AdminTab2IntentsState()) }
    LaunchedEffect(adminSubTab, deduplicatedPaymentIntents, approvedIntentsList, intentFilterTab, intentSearchQuery) {
        if (adminSubTab != 2) return@LaunchedEffect
        val pendingList = deduplicatedPaymentIntents
        val approvedList = approvedIntentsList
        val filter = intentFilterTab
        val q = intentSearchQuery.trim()
        val computed = withContext(Dispatchers.Default) {
            val intents = if (filter == "✅ ĐÃ DUYỆT") approvedList else pendingList
            var paid = 0
            var qr = 0
            for (item in pendingList) {
                if (item.actionType == "CLICKED_I_PAID") paid++
                else if (item.actionType == "OPENED_VIET_QR") qr++
            }
            val approvedCount = approvedList.size
            val filtered = intents.filter { intent ->
                val matchesTab = when (filter) {
                    "🔥 BÁO CHUYỂN KHOẢN" -> intent.actionType == "CLICKED_I_PAID"
                    "👁️ XEM QR" -> intent.actionType == "OPENED_VIET_QR"
                    "✅ ĐÃ DUYỆT" -> true
                    else -> true
                }
                val matchesSearch = q.isBlank() ||
                    intent.deviceId.contains(q, ignoreCase = true) ||
                    intent.ownerEmail.contains(q, ignoreCase = true) ||
                    intent.actionType.contains(q, ignoreCase = true) ||
                    intent.details.contains(q, ignoreCase = true) ||
                    intent.note.contains(q, ignoreCase = true) ||
                    intent.model.contains(q, ignoreCase = true)
                matchesTab && matchesSearch
            }.sortedByDescending { it.timestamp?.toDate()?.time ?: 0L }
            AdminTab2IntentsState(paid, qr, approvedCount, filtered)
        }
        tab2State = computed
    }

    var tab3State by remember { mutableStateOf(AdminTab3UsersState()) }
    LaunchedEffect(adminSubTab, unifiedManageMode, globalMergedUsers, linkedDevicesByUserKey, selectedFilterChip, searchQuery, userSortMode) {
        if (adminSubTab != 1 || unifiedManageMode != "USERS") return@LaunchedEffect
        val users = globalMergedUsers
        val linkedMap = linkedDevicesByUserKey
        val chip = selectedFilterChip
        val sortMode = userSortMode
        val q = searchQuery.trim()
        val computed = withContext(Dispatchers.Default) {
            var adm = 0
            var pro = 0
            var acc = 0
            var dev = 0
            var norm = 0
            var rev = 0
            var online24 = 0
            var multiDev = 0
            val nowMs = System.currentTimeMillis()
            for (u in users) {
                if ((u.lastActive?.toDate()?.time ?: 0L) >= nowMs - 86_400_000L) online24++
                val linked = linkedMap[u.userId] ?: linkedMap[u.email.trim().lowercase()] ?: emptyList()
                if (linked.size > 1) multiDev++
                if (u.role == "admin") adm++
                if (u.isPro && !u.revokedByAdmin) {
                    pro++
                    if (u.isAccountPro || u.proTier == "ACCOUNT_PRO") acc++ else dev++
                }
                if (!u.isPro && u.role != "admin" && !u.revokedByAdmin) norm++
                if (u.revokedByAdmin) rev++
            }
            val filtered = users.filter { u ->
                val linked = linkedMap[u.userId] ?: linkedMap[u.email.trim().lowercase()] ?: emptyList()
                val matchesSearch = q.isBlank() ||
                    u.displayName.contains(q, true) ||
                    u.email.contains(q, true) ||
                    u.phoneNumber.contains(q, true) ||
                    u.deviceId.contains(q, true) ||
                    u.activeDeviceId.contains(q, true) ||
                    u.userId.contains(q, true) ||
                    linked.any { it.deviceId.contains(q, true) || it.model.contains(q, true) }
                val isAccPro = u.isPro && !u.revokedByAdmin && (u.isAccountPro || u.proTier == "ACCOUNT_PRO")
                val isDevPro = u.isPro && !u.revokedByAdmin && !u.isAccountPro && u.proTier != "ACCOUNT_PRO"
                val isOnline = (u.lastActive?.toDate()?.time ?: 0L) >= nowMs - 86_400_000L
                val matchesChip = when (chip) {
                    "🟢 Online 24h" -> isOnline
                    "📱 Đa Thiết Bị" -> linked.size > 1
                    "👑 Admin" -> u.role == "admin"
                    "⚡ Pro" -> u.isPro && !u.revokedByAdmin
                    "👑 Pro TK" -> isAccPro
                    "📱 Pro Máy" -> isDevPro
                    "👤 User" -> !u.isPro && u.role != "admin" && !u.revokedByAdmin
                    "🚫 Đã Hạ Cấp" -> u.revokedByAdmin
                    else -> true
                }
                matchesSearch && matchesChip
            }
            val sorted = when (sortMode) {
                AdminUserDeviceSortMode.RECENT_ACTIVE -> filtered.sortedWith(
                    compareByDescending<UserProfile> { it.lastActive?.toDate()?.time ?: it.proActivatedAt?.toDate()?.time ?: it.createdAt?.toDate()?.time ?: 0L }
                        .thenByDescending { it.isPro && !it.revokedByAdmin }
                )
                AdminUserDeviceSortMode.PRO_ACTIVATED -> filtered.sortedWith(
                    compareByDescending<UserProfile> { it.isPro && !it.revokedByAdmin }
                        .thenByDescending { it.proActivatedAt?.toDate()?.time ?: it.lastActive?.toDate()?.time ?: 0L }
                )
                AdminUserDeviceSortMode.NAME_OR_ID -> filtered.sortedBy {
                    it.displayName.ifBlank { it.email }.lowercase()
                }
                AdminUserDeviceSortMode.MOST_TRIALS -> filtered
            }
            AdminTab3UsersState(adm, pro, acc, dev, norm, rev, online24, multiDev, sorted)
        }
        tab3State = computed
    }

    var tab4State by remember { mutableStateOf(AdminTab4RecoveriesState()) }
    LaunchedEffect(adminSubTab, proRecoveryRequestsList, recoveryFilterTab, recoverySearchQuery) {
        if (adminSubTab != 4) return@LaunchedEffect
        val recs = proRecoveryRequestsList
        val filter = recoveryFilterTab
        val q = recoverySearchQuery.trim()
        val computed = withContext(Dispatchers.Default) {
            var pending = 0
            for (r in recs) {
                if (r.status == "PENDING") pending++
            }
            val resolved = recs.size - pending
            val filtered = recs.filter { req ->
                val matchesTab = when (filter) {
                    "⏳ CHỜ XỬ LÝ" -> req.status == "PENDING"
                    "✅ ĐÃ CẤP LẠI" -> req.status != "PENDING"
                    else -> true
                }
                val matchesSearch = q.isBlank() ||
                    req.deviceId.contains(q, ignoreCase = true) ||
                    req.ownerEmail.contains(q, ignoreCase = true) ||
                    req.ownerName.contains(q, ignoreCase = true) ||
                    req.deviceModel.contains(q, ignoreCase = true) ||
                    req.note.contains(q, ignoreCase = true)
                matchesTab && matchesSearch
            }
            AdminTab4RecoveriesState(pending, resolved, filtered)
        }
        tab4State = computed
    }

    var tab5State by remember { mutableStateOf(AdminTab5AiLogsState()) }
    LaunchedEffect(adminSubTab, aiProChatLogsList, aiLogFilterTab, aiLogSearchQuery) {
        if (adminSubTab != 5) return@LaunchedEffect
        val logs = aiProChatLogsList
        val filter = aiLogFilterTab
        val q = aiLogSearchQuery.trim()
        val computed = withContext(Dispatchers.Default) {
            var granted = 0
            var blocked = 0
            var inquiry = 0
            for (it in logs) {
                if (it.proGranted) granted++
                else if (it.eventType == "FAKE_BILL_DETECTED" ||
                    it.eventType == "REUSED_BILL_BLOCKED" ||
                    it.eventType == "BILL_REJECTED" ||
                    it.eventType == "UNPAID_PRO_REQUEST_BLOCKED"
                ) blocked++
                else if (it.eventType == "PRO_INQUIRY") inquiry++
            }
            val filtered = logs.filter { log ->
                val matchesTab = when (filter) {
                    "✅ Đã Cấp Pro" -> log.proGranted
                    "🛡️ Chặn Chưa TT" -> !log.proGranted && (
                        log.eventType == "FAKE_BILL_DETECTED" ||
                            log.eventType == "REUSED_BILL_BLOCKED" ||
                            log.eventType == "BILL_REJECTED" ||
                            log.eventType == "UNPAID_PRO_REQUEST_BLOCKED"
                        )
                    "💬 Hỏi Đáp" -> !log.proGranted && log.eventType == "PRO_INQUIRY"
                    else -> true
                }
                val matchesSearch = q.isBlank() ||
                    log.deviceId.contains(q, ignoreCase = true) ||
                    log.ownerEmail.contains(q, ignoreCase = true) ||
                    log.ownerName.contains(q, ignoreCase = true) ||
                    log.userMessage.contains(q, ignoreCase = true) ||
                    log.aiReply.contains(q, ignoreCase = true) ||
                    log.bankTransCode.contains(q, ignoreCase = true) ||
                    log.forensicVerdict.contains(q, ignoreCase = true)
                matchesTab && matchesSearch
            }
            AdminTab5AiLogsState(granted, blocked, inquiry, filtered)
        }
        tab5State = computed
    }

    var tab6State by remember { mutableStateOf(AdminTab6StoreAppsState()) }
    LaunchedEffect(adminSubTab, allStoreApps, storeAppFilterTab, storeAppSearchQuery) {
        if (adminSubTab != 6) return@LaunchedEffect
        val apps = allStoreApps
        val filter = storeAppFilterTab
        val q = storeAppSearchQuery.trim().lowercase()
        val computed = withContext(Dispatchers.Default) {
            var pending = 0
            var approved = 0
            var rejected = 0
            for (a in apps) {
                when (a.status) {
                    "PENDING" -> pending++
                    "APPROVED" -> approved++
                    "REJECTED" -> rejected++
                }
            }
            val filtered = apps.filter { app ->
                val matchesTab = when (filter) {
                    "⏳ CHỜ DUYỆT" -> app.status == "PENDING"
                    "✅ ĐÃ DUYỆT" -> app.status == "APPROVED"
                    "❌ TỪ CHỐI" -> app.status == "REJECTED"
                    else -> true
                }
                val matchesSearch = q.isBlank() ||
                    app.name.lowercase().contains(q) ||
                    app.author.lowercase().contains(q) ||
                    app.contributorEmail.lowercase().contains(q) ||
                    app.description.lowercase().contains(q) ||
                    app.category.lowercase().contains(q) ||
                    app.id.lowercase().contains(q)
                matchesTab && matchesSearch
            }.sortedByDescending { it.status == "PENDING" }
            AdminTab6StoreAppsState(pending, approved, rejected, filtered)
        }
        tab6State = computed
    }

    val todayStr = remember { java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date()) }
    val yesterdayStr = remember {
        val cal = java.util.Calendar.getInstance()
        cal.add(java.util.Calendar.DAY_OF_YEAR, -1)
        java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(cal.time)
    }


    val totalDevicePages = ((tab1State.filteredDevices.size - 1) / devicePageSize) + 1
    val safeDevicePage = deviceCurrentPage.coerceIn(0, (totalDevicePages - 1).coerceAtLeast(0))
    val paginatedDevices = remember(tab1State.filteredDevices, safeDevicePage) {
        val list = tab1State.filteredDevices
        val start = safeDevicePage * devicePageSize
        val end = (start + devicePageSize).coerceAtMost(list.size)
        if (start in 0 until list.size) list.subList(start, end).toList() else emptyList()
    }
    val visibleIntents = remember(tab2State.filteredIntents, intentVisibleLimit) {
        tab2State.filteredIntents.take(intentVisibleLimit)
    }
    val totalPages = maxOf(1, (tab3State.filteredUsers.size + pageSize - 1) / pageSize)
    val safeCurrentPage = minOf(currentPage, totalPages - 1)
    val pagedUsers = remember(tab3State.filteredUsers, safeCurrentPage) {
        val list = tab3State.filteredUsers
        val start = safeCurrentPage * pageSize
        val end = (start + pageSize).coerceAtMost(list.size)
        if (start in 0 until list.size) list.subList(start, end).toList() else emptyList()
    }
    val visibleRecoveries = remember(tab4State.filteredRecoveries, recoveryVisibleLimit) {
        tab4State.filteredRecoveries.take(recoveryVisibleLimit)
    }
    val visibleAiLogs = remember(tab5State.filteredAiLogs, aiLogVisibleLimit) {
        tab5State.filteredAiLogs.take(aiLogVisibleLimit)
    }
    val visibleStoreApps = remember(tab6State.filteredStoreApps, storeAppVisibleLimit) {
        tab6State.filteredStoreApps.take(storeAppVisibleLimit)
    }

    val activeBroadcast by LicenseManager.globalBroadcastFlow.collectAsStateWithLifecycle()
    var broadcastTitleInput by remember {
        mutableStateOf(
            activeBroadcast?.title?.takeIf { it.isNotBlank() }
                ?: "🚀 Đã có phiên bản Magictune_Tool mới!"
        )
    }
    var broadcastMessageInput by remember {
        mutableStateOf(
            activeBroadcast?.message?.takeIf { it.isNotBlank() }
                ?: "Đã có bản cập nhật mới với nhiều tính năng sửa lỗi và tối ưu mượt hơn! Quý khách vui lòng ấn vào nút 'Bản cập nhật' ở góc trên cùng màn hình (Header) để tải và cài đặt phiên bản mới nhất nhé."
        )
    }
    var broadcastTypeInput by remember {
        mutableStateOf(activeBroadcast?.type ?: "UPDATE")
    }
    var updateLinkInput by remember {
        mutableStateOf(
            activeBroadcast?.actionUrl?.takeIf { it.isNotBlank() }
                ?: cachedConfig.globalUpdateLink
        )
    }
    LaunchedEffect(cachedConfig.globalUpdateLink) {
        if (updateLinkInput.isBlank() && cachedConfig.globalUpdateLink.isNotBlank()) {
            updateLinkInput = cachedConfig.globalUpdateLink
        }
    }

    val clipboardManager = LocalClipboardManager.current

    LazyColumn(
        state = lazyListState,
        modifier = Modifier
            .fillMaxSize()
            .background(MagicDarkBackground),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Top Bar
        item(key = "admin_top_bar", contentType = "top_bar") {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(onClick = onNavigateBack) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại", tint = Color.White)
                }
                Text(
                    text = "Quản Trị Hệ Thống",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isAdmin) MagicPurple.copy(alpha = 0.3f) else MagicRose.copy(alpha = 0.3f))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = if (isAdmin) "👑 ADMIN QUYỀN CAO NHẤT" else "⚠️ CHƯA CÓ QUYỀN ADMIN",
                    color = if (isAdmin) MagicPurpleLight else MagicRoseLight,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        }

        val effectiveUser = currentUser ?: FirebaseAuthManager.getCurrentUser()
        val isUserLoggedIn = effectiveUser != null || (authSession.isLoggedIn && authSession.email.isNotBlank())
        val effectiveEmail = (effectiveUser?.email ?: authSession.email).trim()
        val activeSessionKey = authSession.uid.ifBlank {
            authSession.email.trim().lowercase().ifBlank {
                effectiveUser?.uid ?: if (LicenseManager.isCurrentUserAdmin(context)) "local_admin" else ""
            }
        }
        val hasAdminAccess = isAdmin && verifiedAdminSessionKey.isNotBlank() &&
            verifiedAdminSessionKey.equals(activeSessionKey, ignoreCase = true)

        if (!hasAdminAccess) {
            if (!isUserLoggedIn) {
                item(key = "admin_unauth_card", contentType = "status_card") {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
                        border = BorderStroke(1.dp, MagicAmber)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = MagicAmber, modifier = Modifier.size(54.dp))
                            Text(
                                text = "YÊU CẦU ĐĂNG NHẬP ADMIN",
                                color = MagicAmber,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            Text(
                                text = "Vui lòng đăng nhập tài khoản Quản trị viên (Admin) để xác thực và truy cập bảng điều khiển hệ thống!",
                                color = Color.White.copy(alpha = 0.9f),
                                fontSize = 13.sp,
                                lineHeight = 18.sp,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Button(
                                    onClick = onNavigateBack,
                                    colors = ButtonDefaults.buttonColors(containerColor = MagicSurfaceCard),
                                    border = BorderStroke(1.dp, MagicBorder)
                                ) {
                                    Text("Quay Lại", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                                Button(
                                    onClick = {
                                        try {
                                            val intent = android.content.Intent(context, com.example.MainActivity::class.java).apply {
                                                flags = android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP or android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP
                                                putExtra("TARGET_TAB", "LOGIN")
                                            }
                                            context.startActivity(intent)
                                        } catch (_: Exception) {}
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = MagicAmber, contentColor = Color(0xFF020617))
                                ) {
                                    Text("Đăng Nhập Ngay", fontWeight = FontWeight.Black)
                                }
                            }
                        }
                    }
                }
            } else {
                item(key = "admin_no_perm_card", contentType = "status_card") {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
                        border = BorderStroke(1.dp, MagicRose)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = MagicRoseLight, modifier = Modifier.size(48.dp))
                            Text(
                                text = "Tài khoản hiện tại ($effectiveEmail) không có quyền Quản trị viên (Admin)!",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            Button(
                                onClick = onNavigateBack,
                                colors = ButtonDefaults.buttonColors(containerColor = MagicSurfaceCard),
                                border = BorderStroke(1.dp, MagicBorder)
                            ) {
                                Text("Quay Lại", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        } else {
            // ADMIN DASHBOARD WITH SUB-TABS (LazyColumn items - 120fps)
            val isGuestAdmin = !isUserLoggedIn || (effectiveUser?.email.isNullOrBlank() && authSession.email.isBlank())
            if (isGuestAdmin) {
                item(key = "admin_guest_warning", contentType = "warning_card") {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF261C05)),
                        border = BorderStroke(1.2.dp, MagicAmber)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = MagicAmber,
                                modifier = Modifier.size(28.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "⚠️ ADMIN CHƯA ĐĂNG NHẬP GOOGLE",
                                    color = MagicAmber,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black
                                )
                                Text(
                                    text = "Bạn đang vào với quyền Máy Quen của Admin. Hãy bấm Đăng Nhập để token Google chuẩn được cấp phát, đảm bảo mọi thao tác duyệt/xóa/đồng bộ gửi thẳng vào Firebase 100% không bị chặn quyền!",
                                    color = Color(0xFFFDE68A),
                                    fontSize = 10.5.sp,
                                    lineHeight = 14.sp
                                )
                            }
                            Button(
                                onClick = {
                                    try {
                                        val intent = android.content.Intent(context, com.example.MainActivity::class.java).apply {
                                            flags = android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP or android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP
                                            putExtra("TARGET_TAB", "LOGIN")
                                        }
                                        context.startActivity(intent)
                                    } catch (_: Exception) {}
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MagicAmber, contentColor = Color(0xFF020617)),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text("Đăng Nhập", fontWeight = FontWeight.Black, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }

            item(key = "admin_quick_actions_bar", contentType = "quick_actions_bar") {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (lastMetricsSyncTime.isNotBlank()) {
                            Text(
                                text = lastMetricsSyncTime,
                                color = if (adminSnapshot.isFromOfflineCacheOnly) {
                                    MagicAmber.copy(alpha = 0.92f)
                                } else {
                                    MagicEmeraldLight.copy(alpha = 0.85f)
                                },
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                        } else {
                            Spacer(modifier = Modifier.weight(1f))
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(MagicCyan.copy(alpha = 0.16f))
                                .border(1.dp, MagicCyan.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                .clickable(enabled = !isSyncingMetrics) {
                                    refreshAllAdminMetricsViaRest(showToastOnDone = true)
                                }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = if (isSyncingMetrics) "⏳ Đang nạp..." else "🔄 Làm mới",
                                color = MagicCyanLight,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(MagicAmber.copy(alpha = 0.14f))
                                .border(1.dp, MagicAmber.copy(alpha = 0.65f), RoundedCornerShape(8.dp))
                                .clickable { showCleanupOldDataDialog = true }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                                .testTag("admin_cleanup_old_data_button")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                if (cleanupProgress.isRunning) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(12.dp),
                                        color = MagicAmber,
                                        strokeWidth = 1.8.dp
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.DeleteSweep,
                                        contentDescription = "Dọn Sạch Dữ Liệu Ngày Cũ",
                                        tint = MagicAmber,
                                        modifier = Modifier.size(13.dp)
                                    )
                                }
                                Text(
                                    text = if (cleanupProgress.isRunning) {
                                        "Đang dọn (${cleanupProgress.deletedDocs})"
                                    } else {
                                        "Dọn Ngày Cũ"
                                    },
                                    color = MagicAmber,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }

                    if (cleanupProgress.isRunning) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(MagicAmber.copy(alpha = 0.08f))
                                .border(1.dp, MagicAmber.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(14.dp),
                                color = MagicAmber,
                                strokeWidth = 2.dp
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${cleanupProgress.currentStage} (Đã xóa ${cleanupProgress.deletedDocs} / Quét ${cleanupProgress.scannedDocs})",
                                    color = Color.White,
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Đang chạy dưới nền • Bạn có thể chuyển tab hoặc làm việc khác bình thường.",
                                    color = TextSecondary,
                                    fontSize = 9.5.sp
                                )
                            }
                        }
                    }
                }
            }

            // TRUNG TÂM HỢP NHẤT: AUTO-ADMIN DUYỆT & GÁN PRO TỰ ĐỘNG QUA THÔNG BÁO NGÂN HÀNG, SMS & BILL AI
            item(key = "admin_auto_approve_card", contentType = "switch_card") {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                    border = BorderStroke(1.2.dp, if (notificationPaymentEnabled) MagicEmerald else MagicRose)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = if (notificationPaymentEnabled) MagicEmerald else MagicRoseLight,
                                    modifier = Modifier.size(20.dp)
                                )
                                Column {
                                    Text(
                                        text = "🤖 TRUNG TÂM AUTO-ADMIN & DUYỆT PRO TỰ ĐỘNG (BANK / SMS / BILL AI)",
                                        color = if (notificationPaymentEnabled) MagicEmeraldLight else MagicRoseLight,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Text(
                                        text = if (notificationPaymentEnabled)
                                            "🟢 ĐANG BẬT RẢNH TAY 100% • Đã tự động gán Pro: $autoApprovedCountSession máy"
                                        else
                                            "🔴 ĐANG TẮT • Chế độ duyệt thủ công (Khóa tự động duyệt)",
                                        color = TextSecondary,
                                        fontSize = 9.5.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                            Switch(
                                checked = notificationPaymentEnabled,
                                onCheckedChange = { enabled ->
                                    notificationPaymentEnabled = enabled
                                    autoApproveProEnabled = enabled
                                    LicenseManager.setAutoApproveNotificationPaymentEnabled(context, enabled)
                                    if (enabled) {
                                        LicenseManager.autoEnableNotificationListenerIfAdmin(context)
                                    }
                                    Toast.makeText(
                                        context,
                                        if (enabled) "🤖 Đã BẬT Trung tâm Auto-Admin tự động duyệt Pro qua Thông báo Ngân hàng & Bill AI!" else "🔴 Đã TẮT chế độ tự động duyệt để chuyển sang duyệt thủ công!",
                                        Toast.LENGTH_LONG
                                    ).show()
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = MagicEmerald
                                )
                            )
                        }
                        Text(
                            text = "💡 Chống gian lận 7 lớp: Tự động gán Pro khi (1) Nhận thông báo biến động +VNĐ từ App/SMS Ngân Hàng chính thống (chặn Zalo/Messenger/SĐT cá nhân), (2) Khách gửi ảnh Bill chuyển khoản hợp lệ, hoặc (3) Khớp mã Key SHA-256 / Thiết bị Pro trên Cloud.",
                            color = TextSecondary,
                            fontSize = 9.5.sp,
                            lineHeight = 13.5.sp
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isNotifListenerGranted) MagicEmerald.copy(alpha = 0.14f) else MagicAmber.copy(alpha = 0.16f))
                                    .border(1.dp, if (isNotifListenerGranted) MagicEmerald.copy(alpha = 0.5f) else MagicAmber.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                                    .padding(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = if (isNotifListenerGranted)
                                        "✅ Quyền đọc Thông Báo Ngân Hàng: ĐÃ CẤP (24/7)"
                                    else
                                        "⚠️ Quyền đọc Thông Báo: CHƯA BẬT",
                                    color = if (isNotifListenerGranted) MagicEmeraldLight else MagicAmber,
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            OutlinedButton(
                                onClick = {
                                    LicenseManager.autoEnableNotificationListenerIfAdmin(context)
                                    isNotifListenerGranted = LicenseManager.isNotificationListenerGranted(context)
                                    if (!isNotifListenerGranted) {
                                        try {
                                            val intent = android.content.Intent(android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).apply {
                                                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                                            }
                                            context.startActivity(intent)
                                        } catch (_: Exception) {}
                                    } else {
                                        Toast.makeText(context, "✅ Đã bật quyền đọc Thông báo Ngân hàng cho máy Admin!", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier.defaultMinSize(minHeight = 36.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = MagicCyanLight),
                                border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.6f))
                            ) {
                                Text(
                                    text = if (isNotifListenerGranted) "🔄 Kiểm tra" else "🔓 Cấp quyền",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                            Button(
                                onClick = { switchAdminSubTab(5) },
                                colors = ButtonDefaults.buttonColors(containerColor = MagicCyan),
                                modifier = Modifier.defaultMinSize(minHeight = 36.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(imageVector = Icons.Default.History, contentDescription = null, tint = Color(0xFF020617), modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "📜 Lịch Sử AI (${aiProChatLogsList.size})",
                                    color = Color(0xFF020617),
                                    fontWeight = FontWeight.Black,
                                    fontSize = 10.sp
                                )
                            }
                        }
                        OutlinedButton(
                            onClick = { showAutoAdminTesterDialog = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 36.dp)
                                .testTag("open_auto_admin_tester_btn"),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.55f)),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Science, contentDescription = null, tint = MagicCyanLight, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "🧪 Test Bộ Lọc Auto-Admin 7 Lớp & Giả Lập Duyệt Bill",
                                color = MagicCyanLight,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }
            }

            // TRẢI NGHIỆM CHẾ ĐỘ NGƯỜI DÙNG FREE CHO ADMIN
            item(key = "admin_simulate_free_card", contentType = "switch_card") {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                    border = BorderStroke(1.2.dp, if (simulateFreeMode) MagicAmber else MagicCyan)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Science,
                                    contentDescription = null,
                                    tint = if (simulateFreeMode) MagicAmber else MagicCyan,
                                    modifier = Modifier.size(20.dp)
                                )
                                Column {
                                    Text(
                                        text = "🧪 TRẢI NGHIỆM GIAO DIỆN FREE (TẠM ẨN PRO)",
                                        color = if (simulateFreeMode) MagicAmber else MagicCyanLight,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Text(
                                        text = if (simulateFreeMode)
                                            "⚠️ ĐANG GIẢ LẬP KHÁCH THƯỜNG • Bản thân đang thấy giao diện chưa có Pro"
                                        else
                                            "🟢 BÌNH THƯỜNG • Đang có đầy đủ quyền Quản trị & Pro",
                                        color = TextSecondary,
                                        fontSize = 9.5.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                            Switch(
                                checked = simulateFreeMode,
                                onCheckedChange = { enabled ->
                                    simulateFreeMode = enabled
                                    LicenseManager.setAdminSimulateFreeMode(context, enabled)
                                    Toast.makeText(
                                        context,
                                        if (enabled) "🧪 Đã ẩn Pro của bạn để trải nghiệm góc nhìn người dùng Free!" else "👑 Đã khôi phục trạng thái Pro đầy đủ cho Admin!",
                                        Toast.LENGTH_LONG
                                    ).show()
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = MagicAmber
                                )
                            )
                        }
                        Text(
                            text = "💡 Tính năng này giúp Admin tự trải nghiệm xem người dùng chưa có Pro nhìn thấy những gì (Banner nhắc nâng cấp, giới hạn dùng thử, nút Mua Pro...), giúp thấu hiểu khách hàng tốt hơn.",
                            color = TextSecondary,
                            fontSize = 9.5.sp
                        )
                    }
                }
            }

            // Sub-tab Bar (2 rows of 3 equal, distinctively colored tabs)
            item(key = "admin_subtab_bar", contentType = "subtab_bar") {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val row1Tabs = listOf(
                        AdminSubTabDef(
                            id = 0,
                            icon = "⚙️",
                            slot = "[Ô 1]",
                            title = "Cài Đặt",
                            badgeCount = null,
                            color = MagicCyan,
                            selectedBg = Color(0xFF083344),
                            unselectedBg = Color(0xFF041824),
                            selectedBorder = Color(0xFF22D3EE),
                            unselectedBorder = Color(0xFF0E7490).copy(alpha = 0.55f)
                        ),
                        AdminSubTabDef(
                            id = 1,
                            icon = "👥",
                            slot = "[Ô 2]",
                            title = "User & Máy\n${globalMergedDevices.size}M • ${globalMergedUsers.size}U",
                            badgeCount = globalMergedDevices.size + globalMergedUsers.size,
                            color = Color(0xFFA855F7),
                            selectedBg = Color(0xFF3B0764),
                            unselectedBg = Color(0xFF1E0A38),
                            selectedBorder = Color(0xFFC084FC),
                            unselectedBorder = Color(0xFF7E22CE).copy(alpha = 0.55f)
                        ),
                        AdminSubTabDef(
                            id = 2,
                            icon = "⏳",
                            slot = "[Ô 3]",
                            title = "Chờ Duyệt",
                            badgeCount = deduplicatedPaymentIntents.size,
                            color = MagicAmber,
                            selectedBg = Color(0xFF451A03),
                            unselectedBg = Color(0xFF260E02),
                            selectedBorder = Color(0xFFFBBF24),
                            unselectedBorder = Color(0xFFB45309).copy(alpha = 0.6f)
                        )
                    )
                    val row2Tabs = listOf(
                        AdminSubTabDef(
                            id = 4,
                            icon = "🔄",
                            slot = "[Ô 4]",
                            title = "Khôi Phục",
                            badgeCount = quickPendingRecoveryBadge,
                            color = MagicEmerald,
                            selectedBg = Color(0xFF064E3B),
                            unselectedBg = Color(0xFF032219),
                            selectedBorder = Color(0xFF34D399),
                            unselectedBorder = Color(0xFF047857).copy(alpha = 0.55f)
                        ),
                        AdminSubTabDef(
                            id = 5,
                            icon = "📜",
                            slot = "[Ô 5]",
                            title = "Lịch Sử AI",
                            badgeCount = aiProChatLogsList.size,
                            color = MagicRose,
                            selectedBg = Color(0xFF4C0519),
                            unselectedBg = Color(0xFF2B030E),
                            selectedBorder = Color(0xFFFB7185),
                            unselectedBorder = Color(0xFFBE123C).copy(alpha = 0.55f)
                        ),
                        AdminSubTabDef(
                            id = 6,
                            icon = "📦",
                            slot = "[Ô 6]",
                            title = "Kho App",
                            badgeCount = quickPendingStoreBadge,
                            color = Color(0xFF38BDF8),
                            selectedBg = Color(0xFF1E1B4B),
                            unselectedBg = Color(0xFF0B1120),
                            selectedBorder = Color(0xFF818CF8),
                            unselectedBorder = Color(0xFF4338CA).copy(alpha = 0.55f)
                        )
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        row1Tabs.forEach { tabDef ->
                            val selected = adminSubTab == tabDef.id
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(72.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (selected) tabDef.selectedBg else tabDef.unselectedBg)
                                    .border(
                                        width = if (selected) 1.6.dp else 1.dp,
                                        color = if (selected) tabDef.selectedBorder else tabDef.unselectedBorder,
                                        shape = RoundedCornerShape(10.dp)
                                    )
                                    .clickable {
                                        switchAdminSubTab(tabDef.id)
                                        currentPage = 0
                                    }
                                    .padding(horizontal = 2.dp, vertical = 5.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxSize(),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.Center
                                    ) {
                                        Text(
                                            text = tabDef.icon,
                                            fontSize = 11.5.sp
                                        )
                                        Spacer(modifier = Modifier.width(2.5.dp))
                                        Text(
                                            text = tabDef.slot,
                                            color = if (selected) Color.White else tabDef.color,
                                            fontSize = 10.5.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                        if (tabDef.badgeCount != null) {
                                            Spacer(modifier = Modifier.width(2.5.dp))
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(10.dp))
                                                    .background(if (selected) tabDef.color else tabDef.color.copy(alpha = 0.25f))
                                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                                            ) {
                                                Text(
                                                    text = "${tabDef.badgeCount}",
                                                    color = if (selected) Color.Black else tabDef.color,
                                                    fontSize = 8.5.sp,
                                                    fontWeight = FontWeight.Black
                                                )
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(3.dp))
                                    Text(
                                        text = tabDef.title,
                                        color = if (selected) Color.White else Color(0xFFCBD5E1),
                                        fontSize = 10.sp,
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                        textAlign = TextAlign.Center,
                                        lineHeight = 13.sp,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        row2Tabs.forEach { tabDef ->
                            val selected = adminSubTab == tabDef.id
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(72.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (selected) tabDef.selectedBg else tabDef.unselectedBg)
                                    .border(
                                        width = if (selected) 1.6.dp else 1.dp,
                                        color = if (selected) tabDef.selectedBorder else tabDef.unselectedBorder,
                                        shape = RoundedCornerShape(10.dp)
                                    )
                                    .clickable {
                                        switchAdminSubTab(tabDef.id)
                                        currentPage = 0
                                    }
                                    .padding(horizontal = 2.dp, vertical = 5.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxSize(),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.Center
                                    ) {
                                        Text(
                                            text = tabDef.icon,
                                            fontSize = 11.5.sp
                                        )
                                        Spacer(modifier = Modifier.width(2.5.dp))
                                        Text(
                                            text = tabDef.slot,
                                            color = if (selected) Color.White else tabDef.color,
                                            fontSize = 10.5.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                        if (tabDef.badgeCount != null) {
                                            Spacer(modifier = Modifier.width(2.5.dp))
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(10.dp))
                                                    .background(if (selected) tabDef.color else tabDef.color.copy(alpha = 0.25f))
                                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                                            ) {
                                                Text(
                                                    text = "${tabDef.badgeCount}",
                                                    color = if (selected) Color.Black else tabDef.color,
                                                    fontSize = 8.5.sp,
                                                    fontWeight = FontWeight.Black
                                                )
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(3.dp))
                                    Text(
                                        text = tabDef.title,
                                        color = if (selected) Color.White else Color(0xFFCBD5E1),
                                        fontSize = 10.sp,
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                        textAlign = TextAlign.Center,
                                        lineHeight = 13.sp,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }

            when (adminSubTab) {
                0 -> {
                    // TAB 0: CÀI ĐẶT HỆ THỐNG & TẠO KEY (Tách từng Card thành lazy item 120fps)
                    item(key = "tab0_admin_apk_upload", contentType = "admin_setting_card") {
                        AdminApkReleaseCard(
                            onPublishedUrl = { publishedUrl ->
                                updateLinkInput = publishedUrl
                            }
                        )
                    }

                    item(key = "tab0_prices", contentType = "admin_setting_card") {
                            // Tùy chỉnh giá gốc & giá giảm Pro Thiết Bị / Pro Tài Khoản / Phí Nâng Cấp
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                                border = BorderStroke(1.dp, MagicBorder)
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxWidth().padding(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = "[Ô 1.1] 💰 CẤU HÌNH BẢNG GIÁ & ĐỢT GIẢM GIÁ GÓI PRO TOÀN HỆ THỐNG",
                                        color = MagicPurpleLight,
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Text(
                                        text = "Nhập giá gốc và giá giảm (giá bán thực tế). Người dùng sẽ thấy giá gốc gạch ngang và giá giảm nổi bật kèm huy hiệu 'Đợt Giảm Giá' để kích thích mua Pro!",
                                        color = TextSecondary,
                                        fontSize = 10.sp,
                                        lineHeight = 14.5.sp
                                    )
                                    // Row 1: Pro Thiết Bị (Giá Gốc + Giá Giảm)
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        OutlinedTextField(
                                            value = proOriginalPriceInput,
                                            onValueChange = { proOriginalPriceInput = it },
                                            modifier = Modifier.weight(1f),
                                            label = { Text("📱 Giá gốc Pro Máy (VD: 80.000đ)", fontSize = 10.sp) },
                                            singleLine = true,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        OutlinedTextField(
                                            value = customPriceInput,
                                            onValueChange = { customPriceInput = it },
                                            modifier = Modifier.weight(1f),
                                            label = { Text("🔥 Giá GIẢM Pro Máy (VD: 50.000đ)", fontSize = 10.sp) },
                                            singleLine = true,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                    }
                                    // Row 2: Pro Tài Khoản (Giá Gốc + Giá Giảm)
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        OutlinedTextField(
                                            value = accountProOriginalPriceInput,
                                            onValueChange = { accountProOriginalPriceInput = it },
                                            modifier = Modifier.weight(1f),
                                            label = { Text("👑 Giá gốc Pro TK (VD: 160.000đ)", fontSize = 10.sp) },
                                            singleLine = true,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        OutlinedTextField(
                                            value = accountProPriceInput,
                                            onValueChange = { accountProPriceInput = it },
                                            modifier = Modifier.weight(1f),
                                            label = { Text("🔥 Giá GIẢM Pro TK (VD: 99.000đ)", fontSize = 10.sp) },
                                            singleLine = true,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                    }
                                    // Row 3: Phí Nâng Cấp & Công Tắc Giảm Giá
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        OutlinedTextField(
                                            value = upgradeAccountProPriceInput,
                                            onValueChange = { upgradeAccountProPriceInput = it },
                                            modifier = Modifier.weight(1.1f),
                                            label = { Text("🚀 Phí nâng Pro Máy -> TK (+50.000đ)", fontSize = 9.8.sp) },
                                            singleLine = true,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        Row(
                                            modifier = Modifier.weight(0.9f),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Switch(
                                                checked = isProSaleActiveState,
                                                onCheckedChange = { isProSaleActiveState = it },
                                                colors = SwitchDefaults.colors(
                                                    checkedThumbColor = Color.White,
                                                    checkedTrackColor = MagicRose,
                                                    uncheckedThumbColor = Color.Gray,
                                                    uncheckedTrackColor = MagicSurfaceCard
                                                )
                                            )
                                            Text(
                                                text = if (isProSaleActiveState) "🔥 Đang Giảm Giá" else "⚪ Giá Cố Định",
                                                color = if (isProSaleActiveState) MagicRoseLight else TextSecondary,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                    // Row 4: Nút Lưu Bảng Giá
                                    Button(
                                        onClick = {
                                            LicenseManager.saveAllProPrices(
                                                context = context,
                                                proPrice = customPriceInput,
                                                accountProPrice = accountProPriceInput,
                                                upgradeAccountProPrice = upgradeAccountProPriceInput,
                                                proPriceOriginal = proOriginalPriceInput,
                                                accountProPriceOriginal = accountProOriginalPriceInput,
                                                isProSaleActive = isProSaleActiveState
                                            ) { syncedCloud ->
                                                customPriceInput = LicenseManager.getProPrice(context)
                                                proOriginalPriceInput = LicenseManager.getProOriginalPrice(context)
                                                accountProPriceInput = LicenseManager.getAccountProPrice(context)
                                                accountProOriginalPriceInput = LicenseManager.getAccountProOriginalPrice(context)
                                                upgradeAccountProPriceInput = LicenseManager.getUpgradeToAccountProPrice(context)
                                                isProSaleActiveState = LicenseManager.isProSaleActive(context)
                                                Toast.makeText(
                                                    context,
                                                    if (syncedCloud) "✅ Đã lưu & đồng bộ bảng giá giảm lên Firebase Cloud!"
                                                    else "✅ Đã lưu bảng giá giảm trên máy!",
                                                    Toast.LENGTH_LONG
                                                ).show()
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = MagicPurpleLight),
                                        modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 36.dp),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(Icons.Default.Save, contentDescription = null, tint = Color(0xFF020617), modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Lưu Bảng Giá & Đợt Giảm Giá", color = Color(0xFF020617), fontWeight = FontWeight.Black, fontSize = 12.sp)
                                    }
                                }
                            }
                    }

                    item(key = "tab0_auto_free", contentType = "admin_setting_card") {
                            // Thẻ Cấu Hình Cơ Chế Tự Động Miễn Phí (Dead Man Switch khi không có Admin quản lý)
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                                border = BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.8f))
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text("🎁", fontSize = 18.sp)
                                        Column {
                                            Text(
                                                text = "[Ô 1.2] 🎁 Cơ Chế Tự Động Miễn Phí (Dead Man Switch)",
                                                color = Color.White,
                                                fontSize = 13.5.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = "Nếu trong số ngày này không có Admin nào truy cập ứng dụng, toàn bộ app sẽ tự động mở khóa 100% MIỄN PHÍ vĩnh viễn cho tất cả người dùng!",
                                                color = Color(0xFF94A3B8),
                                                fontSize = 10.5.sp
                                            )
                                        }
                                    }

                                    OutlinedTextField(
                                        value = autoFreeDaysInput,
                                        onValueChange = { autoFreeDaysInput = it.filter { ch -> ch.isDigit() } },
                                        modifier = Modifier.fillMaxWidth(),
                                        label = { Text("Số ngày không có Admin truy cập (Mặc định: 30 ngày)", fontSize = 10.5.sp) },
                                        singleLine = true,
                                        shape = RoundedCornerShape(8.dp)
                                    )

                                    Button(
                                        onClick = {
                                            val days = autoFreeDaysInput.toIntOrNull() ?: 30
                                            LicenseManager.setAutoFreeInactivityDays(context, days) { ok ->
                                                Toast.makeText(
                                                    context,
                                                    if (ok) "✅ Đã lưu: Tự động miễn phí toàn bộ app sau $days ngày nếu không có Admin!"
                                                    else "✅ Đã lưu cấu hình $days ngày trên thiết bị",
                                                    Toast.LENGTH_LONG
                                                ).show()
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.fillMaxWidth().height(42.dp),
                                        contentPadding = PaddingValues(vertical = 8.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Save, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Lưu Số Ngày Miễn Phí Tự Động", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                                    }
                                }
                            }
                    }

                    item(key = "tab0_payment", contentType = "admin_setting_card") {
                            // Cài đặt Tài Khoản Nhận Tiền Chuyển Khoản & VietQR
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                                border = BorderStroke(1.dp, MagicAmber.copy(alpha = 0.8f))
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.AccountBalance,
                                            contentDescription = null,
                                            tint = MagicAmber,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Text(
                                            text = "[Ô 1.3] 💳 CÀI ĐẶT TÀI KHOẢN NHẬN TIỀN & VIETQR",
                                            color = MagicAmber,
                                            fontSize = 11.5.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                    Text(
                                        text = "Tài khoản nhận tiền và mã VietQR sẽ tự động đồng bộ thời gian thực tới tất cả máy người dùng.",
                                        color = TextSecondary,
                                        fontSize = 10.5.sp
                                    )

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        OutlinedTextField(
                                            value = bankNameInput,
                                            onValueChange = { bankNameInput = it },
                                            modifier = Modifier.weight(1.2f),
                                            label = { Text("Đơn vị nhận (VD: MBBank)", fontSize = 10.5.sp) },
                                            placeholder = { Text("MBBank") },
                                            singleLine = true,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        OutlinedTextField(
                                            value = bankCodeInput,
                                            onValueChange = { bankCodeInput = it },
                                            modifier = Modifier.weight(0.8f),
                                            label = { Text("Mã VietQR", fontSize = 10.5.sp) },
                                            placeholder = { Text("MB") },
                                            singleLine = true,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        OutlinedTextField(
                                            value = accountNumberInput,
                                            onValueChange = { accountNumberInput = it },
                                            modifier = Modifier.weight(1f),
                                            label = { Text("Số TK / SĐT Momo", fontSize = 10.5.sp) },
                                            placeholder = { Text("0000000000") },
                                            singleLine = true,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        OutlinedTextField(
                                            value = accountHolderInput,
                                            onValueChange = { accountHolderInput = it },
                                            modifier = Modifier.weight(1f),
                                            label = { Text("Chủ Tài Khoản", fontSize = 10.5.sp) },
                                            placeholder = { Text("ACCOUNT_HOLDER") },
                                            singleLine = true,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = {
                                                LicenseManager.setPaymentAccount(
                                                    context,
                                                    bankName = bankNameInput,
                                                    bankCode = bankCodeInput,
                                                    accountNumber = accountNumberInput,
                                                    accountHolder = accountHolderInput
                                                )
                                                Toast.makeText(context, "✅ Đã lưu & đồng bộ tài khoản nhận tiền lên hệ thống!", Toast.LENGTH_SHORT).show()
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = MagicAmber),
                                            modifier = Modifier.weight(1.3f).defaultMinSize(minHeight = 36.dp),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Icon(imageVector = Icons.Default.Save, contentDescription = null, tint = Color(0xFF020617), modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Lưu & Đồng Bộ TK", color = Color(0xFF020617), fontWeight = FontWeight.Black, fontSize = 11.sp)
                                        }

                                        OutlinedButton(
                                            onClick = { showVietQrPreview = !showVietQrPreview },
                                            modifier = Modifier.fillMaxHeight().weight(0.9f).defaultMinSize(minHeight = 36.dp),
                                            shape = RoundedCornerShape(8.dp),
                                            border = BorderStroke(1.dp, MagicCyan)
                                        ) {
                                            Text(
                                                text = if (showVietQrPreview) "🙈 Ẩn QR Mẫu" else "👁️ Xem Thử QR",
                                                color = MagicCyanLight,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 10.5.sp
                                            )
                                        }
                                    }

                                    if (showVietQrPreview) {
                                        val sampleAmount = LicenseManager.getProPrice(context).filter { it.isDigit() }.ifBlank { "50000" }
                                        val sampleMemo = java.net.URLEncoder.encode("PRO ${LicenseManager.getDeviceId(context)}", "UTF-8")
                                        val sampleHolder = java.net.URLEncoder.encode(accountHolderInput.trim(), "UTF-8")
                                        val sampleQrUrl = "https://img.vietqr.io/image/${bankCodeInput.trim()}-${accountNumberInput.trim()}-compact2.png?amount=$sampleAmount&addInfo=$sampleMemo&accountName=$sampleHolder"
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(Color.White)
                                                .padding(10.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Text(
                                                text = "MÃ VIETQR HIỂN THỊ CHO KHÁCH HÀNG (KIỂM TRA TRỰC QUAN)",
                                                color = Color(0xFF0F172A),
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Black
                                            )
                                            coil.compose.AsyncImage(
                                                model = sampleQrUrl,
                                                contentDescription = "VietQR Preview",
                                                modifier = Modifier.size(190.dp)
                                            )
                                            Text(
                                                text = "Đơn vị nhận: $bankNameInput ($bankCodeInput) • STK: $accountNumberInput\nChủ TK: $accountHolderInput • Số tiền mẫu: $customPriceInput",
                                                color = Color(0xFF334155),
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                textAlign = TextAlign.Center
                                            )
                                        }
                                    }
                                }
                            }
                    }

                    item(key = "tab0_support_links", contentType = "admin_setting_card") {
                            // CẤU HÌNH LINK HỖ TRỢ KHÁCH HÀNG (FACEBOOK / ZALO), LINK YOUTUBE HEADER & LINK BẢN CẬP NHẬT CHÍNH THỨC
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                                border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.6f))
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.SupportAgent, contentDescription = null, tint = MagicCyanLight, modifier = Modifier.size(20.dp))
                                        Text(
                                            text = "[Ô 1.4] 🔗 CẤU HÌNH LINK & ẨN/HIỆN FACEBOOK / YOUTUBE TRÊN HEADER",
                                            color = MagicCyanLight,
                                            fontSize = 11.5.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                    Text(
                                        text = "Bật/tắt hiển thị biểu tượng Facebook & YouTube trên thanh Header trên cùng, đồng thời đồng bộ đường dẫn toàn cầu.",
                                        color = TextSecondary,
                                        fontSize = 10.5.sp
                                    )

                                    // 2 Công tắc Admin Ẩn/Hiện biểu tượng Facebook & YouTube trên Header
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(MagicSurfaceCard)
                                            .border(1.dp, MagicCyan.copy(alpha = 0.45f), RoundedCornerShape(8.dp))
                                            .padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = if (showFbHeaderIconState) "👍 Biểu tượng Facebook trên Header: ĐANG HIỆN" else "🙈 Biểu tượng Facebook trên Header: ĐANG ẨN",
                                                    color = if (showFbHeaderIconState) MagicCyanLight else TextSecondary,
                                                    fontSize = 11.5.sp,
                                                    fontWeight = FontWeight.Black
                                                )
                                                Text(
                                                    text = "Nút biểu tượng Facebook nằm cạnh nút Bản cập nhật trên Header",
                                                    color = TextSecondary,
                                                    fontSize = 10.sp
                                                )
                                            }
                                            Switch(
                                                checked = showFbHeaderIconState,
                                                onCheckedChange = { enabled ->
                                                    showFbHeaderIconState = enabled
                                                    LicenseManager.setFacebookHeaderIconVisible(context, enabled)
                                                    Toast.makeText(
                                                        context,
                                                        if (enabled) "✅ Đã HIỆN biểu tượng Facebook trên Header!" else "🙈 Đã ẨN biểu tượng Facebook trên Header!",
                                                        Toast.LENGTH_SHORT
                                                    ).show()
                                                },
                                                colors = SwitchDefaults.colors(
                                                    checkedThumbColor = Color.White,
                                                    checkedTrackColor = MagicCyan
                                                )
                                            )
                                        }

                                        HorizontalDivider(color = MagicBorder.copy(alpha = 0.5f))

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = if (showYtHeaderIconState) "▶️ Biểu tượng YouTube trên Header: ĐANG HIỆN" else "🙈 Biểu tượng YouTube trên Header: ĐANG ẨN",
                                                    color = if (showYtHeaderIconState) MagicRose else TextSecondary,
                                                    fontSize = 11.5.sp,
                                                    fontWeight = FontWeight.Black
                                                )
                                                Text(
                                                    text = "Nút biểu tượng YouTube nằm cạnh nút Kết nối / Hoàn tác trên Header",
                                                    color = TextSecondary,
                                                    fontSize = 10.sp
                                                )
                                            }
                                            Switch(
                                                checked = showYtHeaderIconState,
                                                onCheckedChange = { enabled ->
                                                    showYtHeaderIconState = enabled
                                                    LicenseManager.setYouTubeHeaderIconVisible(context, enabled)
                                                    Toast.makeText(
                                                        context,
                                                        if (enabled) "✅ Đã HIỆN biểu tượng YouTube trên Header!" else "🙈 Đã ẨN biểu tượng YouTube trên Header!",
                                                        Toast.LENGTH_SHORT
                                                    ).show()
                                                },
                                                colors = SwitchDefaults.colors(
                                                    checkedThumbColor = Color.White,
                                                    checkedTrackColor = MagicRose
                                                )
                                            )
                                        }
                                    }

                                    OutlinedTextField(
                                        value = youtubeLinkInput,
                                        onValueChange = { youtubeLinkInput = it },
                                        modifier = Modifier.fillMaxWidth(),
                                        label = { Text("▶️ Đường Link Nút YouTube Trên Header", fontSize = 10.5.sp) },
                                        placeholder = { Text("https://youtube.com/@hanoioptical...", fontSize = 10.sp) },
                                        singleLine = true,
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    OutlinedTextField(
                                        value = supportLinkInput,
                                        onValueChange = { supportLinkInput = it },
                                        modifier = Modifier.fillMaxWidth(),
                                        label = { Text("💬 Link Facebook / Zalo Hỗ Trợ Khách Hàng", fontSize = 10.5.sp) },
                                        singleLine = true,
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    OutlinedTextField(
                                        value = globalUpdateLinkInput,
                                        onValueChange = { globalUpdateLinkInput = it },
                                        modifier = Modifier.fillMaxWidth(),
                                        label = { Text("📥 Link GitHub hoặc Google Drive tải APK / cập nhật", fontSize = 10.5.sp) },
                                        placeholder = { Text("https://github.com/.../releases/download/.../app.apk hoặc drive.google.com/file/d/...", fontSize = 10.sp) },
                                        singleLine = true,
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    Button(
                                        onClick = {
                                            if (!LicenseManager.isSupportedApkUpdateLink(globalUpdateLinkInput)) {
                                                Toast.makeText(context, "Hãy nhập link GitHub (Releases/Raw .apk) hoặc Google Drive công khai hợp lệ.", Toast.LENGTH_LONG).show()
                                            } else {
                                                LicenseManager.setCustomYouTubeUrl(context, youtubeLinkInput)
                                                LicenseManager.setFacebookLink(context, supportLinkInput)
                                                LicenseManager.setUpdateLink(context, globalUpdateLinkInput)
                                                LicenseManager.setFacebookHeaderIconVisible(context, showFbHeaderIconState)
                                                LicenseManager.setYouTubeHeaderIconVisible(context, showYtHeaderIconState)
                                                globalUpdateLinkInput = LicenseManager.getGoogleDriveUpdateLink(context)
                                                updateLinkInput = globalUpdateLinkInput
                                                Toast.makeText(context, "✅ Đã lưu & đồng bộ cấu hình Facebook, YouTube Header và Link Cập Nhật!", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = MagicCyan),
                                        modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 36.dp),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Save, contentDescription = null, tint = Color(0xFF020617), modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Lưu Cấu Hình Facebook, YouTube & Cập Nhật", color = Color(0xFF020617), fontWeight = FontWeight.Black, fontSize = 11.5.sp)
                                    }
                                }
                            }
                    }

                    item(key = "tab0_trial_mode", contentType = "admin_setting_card") {
                            // Trạng thái Miễn phí & Dùng thử đồng bộ toàn cầu từ LicenseManager
                            // Tùy chỉnh chế độ Trả phí / Miễn phí 100% & Số lượt dùng thử
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                                border = BorderStroke(1.dp, if (isAppFreeModeState) MagicEmerald else MagicPurple)
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = if (isAppFreeModeState) "[Ô 1.5] 🎁 ĐANG BẬT: APP MIỄN PHÍ 100%" else "[Ô 1.5] 💰 ĐANG BẬT: CHẾ ĐỘ THU PHÍ PRO",
                                                color = if (isAppFreeModeState) MagicEmerald else MagicPurpleLight,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Black
                                            )
                                            Text(
                                                text = if (isAppFreeModeState) "Mọi tính năng Pro và lượt dùng thử đều được mở cho tất cả người dùng; không hiện yêu cầu thanh toán." else "Người dùng phải mua Pro sau khi hết số lượt dùng thử miễn phí.",
                                                color = TextSecondary,
                                                fontSize = 10.sp
                                            )
                                        }
                                        Switch(
                                            checked = isAppFreeModeState,
                                            onCheckedChange = { checked ->
                                                isAppFreeModeState = checked
                                                LicenseManager.setAppFreeMode(context, checked)
                                                Toast.makeText(context, if (checked) "Đã chuyển app thành MIỄN PHÍ cho mọi người!" else "Đã bật chế độ THU PHÍ PRO toàn hệ thống!", Toast.LENGTH_SHORT).show()
                                            }
                                        )
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        OutlinedTextField(
                                            value = freeTrialLimitInput,
                                            onValueChange = { freeTrialLimitInput = it.filter { ch -> ch.isDigit() } },
                                            modifier = Modifier.weight(1f),
                                            label = { Text("Số lượt dùng thử miễn phí (Đặt 0 = Khóa 100%)", fontSize = 10.5.sp) },
                                            singleLine = true,
                                            shape = RoundedCornerShape(8.dp),
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                                        )
                                        Button(
                                            onClick = {
                                                val limit = (freeTrialLimitInput.toIntOrNull() ?: 1).coerceAtLeast(0)
                                                freeTrialLimitInput = limit.toString()
                                                LicenseManager.setFreeTrialLimit(context, limit)
                                                Toast.makeText(context, "✅ Đã lưu & đồng bộ Firebase: Số lượt dùng thử là $limit lần", Toast.LENGTH_SHORT).show()
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = MagicCyan),
                                            modifier = Modifier.defaultMinSize(minHeight = 36.dp)
                                        ) {
                                            Text("Lưu Lượt", color = Color(0xFF020617), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                    }

                    item(key = "tab0_keygen", contentType = "admin_setting_card") {
                            // License Key Generator Card
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                                border = BorderStroke(1.dp, MagicCyan)
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxWidth().padding(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "[Ô 1.6] 🔑 TRUNG TÂM TRA CỨU & CẤP PRO",
                                            color = MagicCyan,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Black,
                                            modifier = Modifier.fillMaxHeight().weight(1f)
                                        )
                                        OutlinedButton(
                                            onClick = { showBatchGrantDialog = true },
                                            modifier = Modifier
                                                .defaultMinSize(minHeight = 36.dp)
                                                .testTag("open_batch_pro_grant_btn"),
                                            shape = RoundedCornerShape(8.dp),
                                            border = BorderStroke(1.dp, MagicAmber.copy(alpha = 0.7f)),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                        ) {
                                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MagicAmberLight, modifier = Modifier.size(14.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text("⚡ Cấp Hàng Loạt", color = MagicAmberLight, fontSize = 10.sp, fontWeight = FontWeight.Black)
                                        }
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        OutlinedTextField(
                                            value = genDeviceIdInput,
                                            onValueChange = {
                                                genDeviceIdInput = it
                                                proLookupResult = null
                                            },
                                            modifier = Modifier.weight(1f),
                                            label = { Text("Device ID (MT-...) hoặc Email Google", fontSize = 11.sp) },
                                            placeholder = { Text("Nhập MT-xxxx hoặc email@gmail.com", fontSize = 10.5.sp) },
                                            singleLine = true,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        Button(
                                            enabled = !isLookingUpProTarget && genDeviceIdInput.isNotBlank(),
                                            onClick = {
                                                coroutineScope.launch {
                                                    isLookingUpProTarget = true
                                                    try {
                                                        proLookupResult = LicenseManager.adminLookupTargetViaCloud(context, genDeviceIdInput)
                                                    } catch (_: Throwable) {
                                                    } finally {
                                                        isLookingUpProTarget = false
                                                    }
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = MagicCyan),
                                            modifier = Modifier
                                                .defaultMinSize(minHeight = 36.dp)
                                                .testTag("admin_cloud_lookup_btn"),
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp)
                                        ) {
                                            if (isLookingUpProTarget) {
                                                CircularProgressIndicator(color = Color(0xFF020617), strokeWidth = 2.dp, modifier = Modifier.size(15.dp))
                                            } else {
                                                Icon(Icons.Default.Search, contentDescription = "Tra cứu Cloud", tint = Color(0xFF020617), modifier = Modifier.size(17.dp))
                                                Spacer(Modifier.width(4.dp))
                                                Text("Tra Cloud", color = Color(0xFF020617), fontWeight = FontWeight.Black, fontSize = 10.5.sp)
                                            }
                                        }
                                    }

                                    OutlinedTextField(
                                        value = genReasonInput,
                                        onValueChange = { genReasonInput = it },
                                        modifier = Modifier.fillMaxWidth(),
                                        label = { Text("Lý do / Mã giao dịch (tùy chọn)", fontSize = 10.5.sp) },
                                        placeholder = { Text("VD: CK VCB 100k / Bảo hành đổi máy", fontSize = 10.sp) },
                                        singleLine = true,
                                        shape = RoundedCornerShape(8.dp)
                                    )

                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .horizontalScroll(rememberScrollState()),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        listOf("CK VCB 100k", "CK MB 50k", "Bảo hành đổi máy", "Khách VIP").forEach { tag ->
                                            AssistChip(
                                                onClick = { genReasonInput = tag },
                                                label = { Text(tag, fontSize = 10.sp) }
                                            )
                                        }
                                    }

                                    proLookupResult?.let { lk ->
                                        val tierColor = when (lk.proTier) {
                                            "ACCOUNT_PRO" -> MagicAmberLight
                                            "DEVICE_PRO" -> MagicEmeraldLight
                                            "REVOKED" -> MagicRoseLight
                                            else -> MagicCyanLight
                                        }
                                        Card(
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(10.dp),
                                            colors = CardDefaults.cardColors(containerColor = Color(0xFF091224)),
                                            border = BorderStroke(1.dp, tierColor.copy(alpha = 0.6f))
                                        ) {
                                            Column(
                                                modifier = Modifier.fillMaxWidth().padding(10.dp),
                                                verticalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = if (lk.foundOnCloud) "🔍 HỒ SƠ CLOUD: ${lk.proTier}" else "⚠️ CHƯA CÓ TRÊN CLOUD (SẼ KHỞI TẠO MỚI)",
                                                        color = tierColor,
                                                        fontSize = 10.5.sp,
                                                        fontWeight = FontWeight.Black
                                                    )
                                                    Text(lk.sourceSummary, color = TextMuted, fontSize = 9.sp)
                                                }
                                                if (lk.resolvedDeviceId.isNotBlank()) {
                                                    Text("• Máy: ${lk.resolvedDeviceId} ${if (lk.deviceModel.isNotBlank()) "(${lk.deviceModel})" else ""}", color = Color.White, fontSize = 10.5.sp)
                                                }
                                                if (lk.resolvedEmail.contains("@")) {
                                                    Text("• Email: ${lk.resolvedEmail}", color = MagicCyanLight, fontSize = 10.5.sp)
                                                }
                                                if (lk.licenseKeyOnCloud.isNotBlank()) {
                                                    Text("• Key trên Cloud: ${lk.licenseKeyOnCloud}", color = MagicEmeraldLight, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                }
                                                if (lk.lastReason.isNotBlank()) {
                                                    Text("• Nguồn duyệt: ${lk.lastReason}", color = TextMuted, fontSize = 9.5.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                                }
                                                Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                    if (lk.resolvedUserId.isNotBlank() && lk.isAccountPro) {
                                                        OutlinedButton(
                                                            onClick = {
                                                                LicenseManager.adminResetUserActiveDeviceSession(lk.resolvedUserId) { ok ->
                                                                    Toast.makeText(
                                                                        context,
                                                                        if (ok) "🔓 Đã mở khóa phiên 1 máy để khách đổi máy!" else "❌ Lỗi mở khóa phiên",
                                                                        Toast.LENGTH_SHORT
                                                                    ).show()
                                                                }
                                                            },
                                                            modifier = Modifier.defaultMinSize(minHeight = 36.dp),
                                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                            border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.6f))
                                                        ) {
                                                            Text("🔓 Mở Khóa Đổi Máy", color = MagicCyanLight, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                        }
                                                    }
                                                    if (lk.isPro) {
                                                        OutlinedButton(
                                                            onClick = {
                                                                LicenseManager.adminRevokeProCompletely(
                                                                    context = context,
                                                                    userId = lk.resolvedUserId,
                                                                    deviceId = lk.resolvedDeviceId,
                                                                    ownerEmail = lk.resolvedEmail
                                                                ) { ok, msg ->
                                                                    if (ok) proLookupResult = lk.copy(isPro = false, isAccountPro = false, revokedByAdmin = true, proTier = "REVOKED")
                                                                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                                                }
                                                            },
                                                            modifier = Modifier.defaultMinSize(minHeight = 36.dp),
                                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                            border = BorderStroke(1.dp, MagicRose.copy(alpha = 0.6f))
                                                        ) {
                                                            Text("🚫 Thu Hồi Pro", color = MagicRoseLight, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            onClick = {
                                                val raw = genDeviceIdInput.trim()
                                                if (raw.contains("@")) {
                                                    Toast.makeText(context, "⚠️ Key Pro Máy (PRO-xxxx) sinh theo phần cứng máy, vui lòng nhập Device ID!", Toast.LENGTH_LONG).show()
                                                } else if (raw.isNotBlank()) {
                                                    val cleanDev = raw.uppercase()
                                                    val key = LicenseManager.generateLicenseKeyForDevice(cleanDev)
                                                    generatedKeyOutput = key
                                                    LicenseManager.registerAdminGeneratedKeyToCloud(cleanDev, key, isAccountPro = false, context = context)
                                                    activeProReceipt = ProGrantReceiptData(
                                                        targetDeviceId = cleanDev,
                                                        isAccountPro = false,
                                                        generatedKey = key,
                                                        reasonNote = genReasonInput.trim().ifBlank { "Tạo Key Pro Máy (SHA-256)" },
                                                        cloudSyncMessage = "Đã ghi nhận Key Pro Máy lên Cloud (devices + pro_devices)"
                                                    )
                                                } else {
                                                    Toast.makeText(context, "Vui lòng nhập Device ID hợp lệ!", Toast.LENGTH_SHORT).show()
                                                }
                                            },
                                            modifier = Modifier.weight(1f).defaultMinSize(minHeight = 36.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = MagicCyan)
                                        ) {
                                            Text("📱 Key Pro Máy", color = Color(0xFF020617), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                        }
                                        Button(
                                            onClick = {
                                                val raw = genDeviceIdInput.trim()
                                                if (raw.isNotBlank()) {
                                                    val isEmail = raw.contains("@")
                                                    val key = if (isEmail) {
                                                        LicenseManager.generateAccountProKeyForEmail(raw)
                                                    } else {
                                                        LicenseManager.generateAccountProLicenseKeyForDevice(raw.uppercase())
                                                    }
                                                    generatedKeyOutput = key
                                                    LicenseManager.registerAdminGeneratedKeyToCloud(raw, key, isAccountPro = true, context = context)
                                                    activeProReceipt = ProGrantReceiptData(
                                                        targetDeviceId = if (isEmail) "" else raw.uppercase(),
                                                        targetEmail = if (isEmail) raw.lowercase() else "",
                                                        isAccountPro = true,
                                                        generatedKey = key,
                                                        reasonNote = genReasonInput.trim().ifBlank { "Tạo Key Pro Tài Khoản (SHA-256)" },
                                                        cloudSyncMessage = "Đã đồng bộ Key Pro Tài Khoản lên Cloud!"
                                                    )
                                                } else {
                                                    Toast.makeText(context, "Vui lòng nhập Device ID hoặc Email!", Toast.LENGTH_SHORT).show()
                                                }
                                            },
                                            modifier = Modifier.weight(1f).defaultMinSize(minHeight = 36.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = MagicAmber)
                                        ) {
                                            Text("👑 Key Pro TK", color = Color(0xFF020617), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                        }
                                    }
                                    Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            onClick = {
                                                val raw = genDeviceIdInput.trim()
                                                if (raw.contains("@")) {
                                                    Toast.makeText(context, "⚠️ Cấp Pro Máy gắn theo phần cứng nên cần Device ID. Để cấp theo Email, hãy bấm 'Cấp Pro TK Từ Xa'!", Toast.LENGTH_LONG).show()
                                                } else if (raw.isNotBlank()) {
                                                    val targetId = raw.uppercase()
                                                    val reasonNote = genReasonInput.trim().ifBlank { "ADMIN_REMOTE_GRANT_DEVICE_PRO" }
                                                    LicenseManager.adminGrantTierForUserOrDevice(
                                                        userId = proLookupResult?.resolvedUserId.orEmpty(),
                                                        deviceId = targetId,
                                                        ownerEmail = proLookupResult?.resolvedEmail.orEmpty(),
                                                        grantAccountPro = false,
                                                        context = context,
                                                        noteOrReason = reasonNote
                                                    ) { ok, msg ->
                                                        if (ok) {
                                                            val normT = LicenseManager.normalizeDeviceIdForMatch(targetId)
                                                            val devKey = LicenseManager.generateLicenseKeyForDevice(targetId)
                                                            generatedKeyOutput = devKey
                                                            AdminSessionCache.updateSnapshot(context) { cur ->
                                                                cur.copy(
                                                                    devices = cur.devices.map { d ->
                                                                        if (LicenseManager.normalizeDeviceIdForMatch(d.deviceId) == normT) {
                                                                            d.copy(isPro = true, isAccountPro = false, proTier = "DEVICE_PRO", revokedByAdmin = false, licenseKey = devKey)
                                                                        } else d
                                                                    },
                                                                    users = cur.users.map { u ->
                                                                        if (LicenseManager.normalizeDeviceIdForMatch(u.deviceId) == normT) {
                                                                            u.copy(isPro = true, isAccountPro = false, proTier = "DEVICE_PRO", revokedByAdmin = false)
                                                                        } else u
                                                                    }
                                                                )
                                                            }
                                                            refreshAllAdminMetricsViaRest(showToastOnDone = false)
                                                            activeProReceipt = ProGrantReceiptData(
                                                                targetDeviceId = targetId,
                                                                targetEmail = proLookupResult?.resolvedEmail.orEmpty(),
                                                                isAccountPro = false,
                                                                generatedKey = devKey,
                                                                reasonNote = reasonNote,
                                                                cloudSyncMessage = msg
                                                            )
                                                        }
                                                        Toast.makeText(context, if (ok) "📱 $msg" else "❌ $msg", Toast.LENGTH_LONG).show()
                                                    }
                                                }
                                            },
                                            modifier = Modifier.weight(1f).defaultMinSize(minHeight = 36.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald)
                                        ) {
                                            Text("⚡ Cấp Pro Máy Từ Xa", color = Color(0xFF020617), fontWeight = FontWeight.Bold, fontSize = 10.5.sp)
                                        }
                                        Button(
                                            onClick = {
                                                val raw = genDeviceIdInput.trim()
                                                if (raw.isNotBlank()) {
                                                    val isEmail = raw.contains("@")
                                                    val targetEmail = if (isEmail) raw.lowercase() else proLookupResult?.resolvedEmail.orEmpty()
                                                    val targetDevId = if (!isEmail) raw.uppercase() else proLookupResult?.resolvedDeviceId.orEmpty()
                                                    val reasonNote = genReasonInput.trim().ifBlank { "ADMIN_REMOTE_GRANT_ACCOUNT_PRO" }
                                                    LicenseManager.adminGrantTierForUserOrDevice(
                                                        userId = proLookupResult?.resolvedUserId.orEmpty(),
                                                        deviceId = targetDevId,
                                                        ownerEmail = targetEmail,
                                                        grantAccountPro = true,
                                                        context = context,
                                                        noteOrReason = reasonNote
                                                    ) { ok, msg ->
                                                        if (ok) {
                                                            val normTarget = LicenseManager.normalizeDeviceIdForMatch(targetDevId)
                                                            val accKey = if (targetDevId.isNotBlank()) {
                                                                LicenseManager.generateAccountProLicenseKeyForDevice(targetDevId)
                                                            } else {
                                                                LicenseManager.generateAccountProKeyForEmail(targetEmail)
                                                            }
                                                            generatedKeyOutput = accKey
                                                            AdminSessionCache.updateSnapshot(context) { cur ->
                                                                cur.copy(
                                                                    devices = cur.devices.map { d ->
                                                                        val match = if (isEmail) d.ownerEmail.equals(targetEmail, ignoreCase = true)
                                                                        else LicenseManager.normalizeDeviceIdForMatch(d.deviceId) == normTarget
                                                                        if (match) {
                                                                            d.copy(isPro = true, isAccountPro = true, proTier = "ACCOUNT_PRO", revokedByAdmin = false, licenseKey = LicenseManager.generateAccountProLicenseKeyForDevice(d.deviceId))
                                                                        } else d
                                                                    },
                                                                    users = cur.users.map { u ->
                                                                        val match = if (isEmail) u.email.equals(targetEmail, ignoreCase = true)
                                                                        else LicenseManager.normalizeDeviceIdForMatch(u.deviceId) == normTarget
                                                                        if (match) {
                                                                            u.copy(isPro = true, isAccountPro = true, proTier = "ACCOUNT_PRO", revokedByAdmin = false)
                                                                        } else u
                                                                    }
                                                                )
                                                            }
                                                            refreshAllAdminMetricsViaRest(showToastOnDone = false)
                                                            activeProReceipt = ProGrantReceiptData(
                                                                targetDeviceId = targetDevId,
                                                                targetEmail = targetEmail,
                                                                isAccountPro = true,
                                                                generatedKey = accKey,
                                                                reasonNote = reasonNote,
                                                                cloudSyncMessage = msg
                                                            )
                                                        }
                                                        Toast.makeText(context, if (ok) "👑 $msg" else "❌ $msg", Toast.LENGTH_LONG).show()
                                                    }
                                                }
                                            },
                                            modifier = Modifier.weight(1f).defaultMinSize(minHeight = 36.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = MagicAmber)
                                        ) {
                                            Text("👑 Cấp Pro TK Từ Xa", color = Color(0xFF020617), fontWeight = FontWeight.Bold, fontSize = 10.5.sp)
                                        }
                                    }

                                    if (generatedKeyOutput.isNotBlank()) {
                                        Card(
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(8.dp),
                                            colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
                                            border = BorderStroke(1.dp, MagicEmerald)
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth().padding(8.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.fillMaxHeight().weight(1f)) {
                                                    Text(text = "Mã Pro đã tạo:", color = TextMuted, fontSize = 9.sp)
                                                    Text(text = generatedKeyOutput, color = MagicEmerald, fontSize = 13.sp, fontWeight = FontWeight.Black)
                                                }
                                                IconButton(
                                                    onClick = {
                                                        activeProReceipt = ProGrantReceiptData(
                                                            targetDeviceId = if (genDeviceIdInput.contains("@")) "" else genDeviceIdInput.trim().uppercase(),
                                                            targetEmail = if (genDeviceIdInput.contains("@")) genDeviceIdInput.trim().lowercase() else "",
                                                            isAccountPro = generatedKeyOutput.startsWith("TKPR-"),
                                                            generatedKey = generatedKeyOutput,
                                                            reasonNote = genReasonInput.trim(),
                                                            cloudSyncMessage = "Biên nhận Key SHA-256 sẵn sàng gửi khách"
                                                        )
                                                    }
                                                ) {
                                                    Icon(imageVector = Icons.AutoMirrored.Filled.Send, contentDescription = "Tin nhắn trả khách", tint = MagicAmberLight)
                                                }
                                                IconButton(
                                                    onClick = {
                                                        val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
                                                        if (clipboard != null) {
                                                            val clip = android.content.ClipData.newPlainText("Pro License Key", generatedKeyOutput)
                                                            clipboard.setPrimaryClip(clip)
                                                            Toast.makeText(context, "Đã sao chép mã Key!", Toast.LENGTH_SHORT).show()
                                                        } else {
                                                            Toast.makeText(context, "Không truy cập được Clipboard", Toast.LENGTH_SHORT).show()
                                                        }
                                                    }
                                                ) {
                                                    Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy", tint = MagicCyan)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                    }

                    item(key = "tab0_branding", contentType = "admin_setting_card") {
                            // App Renaming & Header Version / Font Size Card
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                                border = BorderStroke(1.dp, MagicPurple)
                            ) {
                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(
                                        text = "[Ô 1.7] 🏷️ ĐỔI TÊN ỨNG DỤNG, SỐ V & ĐỘ TO CHỮ TRÊN HEADER",
                                        color = MagicPurpleLight,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Text(
                                        text = "Chỉ đồng bộ lên các máy đang cài đúng cùng tệp APK bản ${com.example.data.APP_VERSION_NAME} (không làm đổi tên/số phiên bản trên máy người dùng đang dùng APK cũ).",
                                        color = MagicCyanLight,
                                        fontSize = 10.sp
                                    )
                                    var appNameInput by remember { mutableStateOf(LicenseManager.getAppName(context)) }
                                    var appVerInput by remember { mutableStateOf(LicenseManager.getAppVersionLabel(context)) }
                                    var appFontSizeInput by remember { mutableFloatStateOf(LicenseManager.getAppNameFontSizeSp(context)) }

                                    // Khung xem trước trực tiếp
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(MagicSurfaceCard)
                                            .border(1.dp, MagicCyan.copy(alpha = 0.45f), RoundedCornerShape(8.dp))
                                            .padding(10.dp)
                                    ) {
                                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Text(
                                                text = "XEM TRƯỚC HEADER TRỰC TIẾP (${((appFontSizeInput * 10).toInt()) / 10f} sp):",
                                                color = TextSecondary,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            val previewHeader = if (appVerInput.trim().isNotEmpty()) {
                                                "${appNameInput.ifBlank { "Magictune_Tool" }}_${appVerInput.trim()}"
                                            } else {
                                                appNameInput.ifBlank { "Magictune_Tool" }
                                            }
                                            Text(
                                                text = previewHeader,
                                                color = Color.White,
                                                fontSize = appFontSizeInput.sp,
                                                fontWeight = FontWeight.Black,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        OutlinedTextField(
                                            value = appNameInput,
                                            onValueChange = { appNameInput = it },
                                            label = { Text("Tên ứng dụng trên Header") },
                                            modifier = Modifier.weight(1.3f),
                                            singleLine = true,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        OutlinedTextField(
                                            value = appVerInput,
                                            onValueChange = { appVerInput = it },
                                            label = { Text("Số v (VD: v5.6)") },
                                            modifier = Modifier.weight(0.9f),
                                            singleLine = true,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                    }

                                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "📏 Thanh trượt chỉnh độ to tên ứng dụng trên Header:",
                                                color = Color.White,
                                                fontSize = 11.5.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = "${((appFontSizeInput * 10).toInt()) / 10f} sp",
                                                color = MagicEmeraldLight,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Black
                                            )
                                        }
                                        Slider(
                                            value = appFontSizeInput,
                                            onValueChange = {
                                                appFontSizeInput = it
                                                LicenseManager.setAppNameFontSizeSp(context, it)
                                            },
                                            valueRange = 8f..20f,
                                            colors = SliderDefaults.colors(
                                                thumbColor = MagicCyan,
                                                activeTrackColor = MagicEmerald
                                            )
                                        )
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = {
                                                LicenseManager.setHeaderBrandingConfig(
                                                    context = context,
                                                    appName = appNameInput,
                                                    versionLabel = appVerInput,
                                                    fontSizeSp = appFontSizeInput
                                                )
                                                Toast.makeText(
                                                    context,
                                                    "✅ Đã lưu tên app: ${appNameInput}_${appVerInput} (${((appFontSizeInput * 10).toInt()) / 10f}sp)",
                                                    Toast.LENGTH_SHORT
                                                ).show()
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = MagicPurple),
                                            modifier = Modifier.weight(1.4f).defaultMinSize(minHeight = 36.dp)
                                        ) {
                                            Text("Lưu Tên, Số v & Cỡ Chữ", fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                                        }

                                        OutlinedButton(
                                            onClick = {
                                                appNameInput = "Magictune_Tool"
                                                appVerInput = com.example.data.APP_VERSION_NAME.lowercase()
                                                appFontSizeInput = 11.5f
                                                LicenseManager.setHeaderBrandingConfig(
                                                    context = context,
                                                    appName = appNameInput,
                                                    versionLabel = appVerInput,
                                                    fontSizeSp = appFontSizeInput
                                                )
                                                Toast.makeText(context, "✅ Đã khôi phục mặc định Header", Toast.LENGTH_SHORT).show()
                                            },
                                            modifier = Modifier.weight(0.8f).defaultMinSize(minHeight = 36.dp),
                                            border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.5f))
                                        ) {
                                            Text("Mặc Định", color = MagicCyanLight, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                    }

                    item(key = "tab0_ui_scale", contentType = "admin_setting_card") {
                            // [Ô 1.8] 🔍 ĐIỀU CHỈNH MỨC THU PHÓNG GIAO DIỆN ỨNG DỤNG (MIN 80% - MAX 100%)
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.35f))
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "[Ô 1.8] 🔍 ĐIỀU CHỈNH MỨC THU PHÓNG GIAO DIỆN (80% - 100%)",
                                            color = MagicCyanLight,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                        Icon(
                                            imageVector = Icons.Default.Settings,
                                            contentDescription = null,
                                            tint = MagicCyan,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }

                                    val activeUiScale by LicenseManager.appUiScaleFlow.collectAsState()
                                    var uiScaleInput by remember {
                                        mutableFloatStateOf(LicenseManager.getAppUiScale(context).coerceIn(0.80f, 1.00f))
                                    }
                                    LaunchedEffect(activeUiScale) {
                                        val cleanActive = activeUiScale.coerceIn(0.80f, 1.00f)
                                        if (kotlin.math.abs(uiScaleInput - cleanActive) >= 0.005f) {
                                            uiScaleInput = cleanActive
                                        }
                                    }
                                    val currentScalePercent = kotlin.math.round(uiScaleInput * 100).toInt().coerceIn(80, 100)

                                    Text(
                                        text = "Thanh trượt điều chỉnh tỷ lệ hiển thị toàn bộ giao diện ứng dụng (chữ, icon, khoảng cách). Phạm vi cho phép: 80% (nhỏ gọn) đến 100% (kích thước tối đa). Tự động lưu vĩnh viễn & đồng bộ Cloud ngay khi kéo!",
                                        color = TextSecondary,
                                        fontSize = 10.5.sp,
                                        lineHeight = 14.sp
                                    )

                                    // Khung xem trước trực tiếp mức thu phóng
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(MagicSurfaceCard)
                                            .border(1.dp, MagicEmerald.copy(alpha = 0.45f), RoundedCornerShape(8.dp))
                                            .padding(10.dp)
                                    ) {
                                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = "TỶ LỆ THU PHÓNG ĐANG ÁP DỤNG:",
                                                    color = TextSecondary,
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                Text(
                                                    text = "$currentScalePercent% (Đã lưu)",
                                                    color = if (currentScalePercent == 85) MagicEmerald else MagicAmber,
                                                    fontSize = 13.5.sp,
                                                    fontWeight = FontWeight.Black
                                                )
                                            }

                                            LinearProgressIndicator(
                                                progress = { ((uiScaleInput - 0.80f) / (1.00f - 0.80f)).coerceIn(0f, 1f) },
                                                modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                                                color = MagicCyan,
                                                trackColor = Color(0xFF1E293B)
                                            )

                                            Text(
                                                text = when {
                                                    currentScalePercent <= 84 -> "🔍 Mức 80% - 84%: Nhỏ gọn, hiển thị nhiều nội dung hơn."
                                                    currentScalePercent <= 90 -> "🔍 Mức 85% - 90%: Cân đối giữa độ thoáng và kích thước chữ (Mặc định 85%)."
                                                    currentScalePercent <= 95 -> "🔍 Mức 91% - 95%: Hiển thị to rõ, dễ đọc hơn."
                                                    else -> "🔍 Mức 96% - 100%: Kích thước tối đa, sắc nét và dễ nhìn nhất."
                                                },
                                                color = MagicCyanLight,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }

                                    // Thanh trượt Slider Min 80% Max 100%
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(text = "80% (Min)", color = TextMuted, fontSize = 9.5.sp)
                                        Text(
                                            text = "Kéo để chỉnh: $currentScalePercent%",
                                            color = MagicAmber,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(text = "100% (Max)", color = TextMuted, fontSize = 9.5.sp)
                                    }

                                    Slider(
                                        value = uiScaleInput.coerceIn(0.80f, 1.00f),
                                        onValueChange = { newValue ->
                                            val stepped = (kotlin.math.round(newValue * 100f) / 100f).coerceIn(0.80f, 1.00f)
                                            uiScaleInput = stepped
                                            if (kotlin.math.abs(stepped - LicenseManager.appUiScaleFlow.value) >= 0.005f) {
                                                LicenseManager.setAppUiScale(context, stepped, syncCloud = false)
                                            }
                                        },
                                        onValueChangeFinished = {
                                            LicenseManager.setAppUiScale(context, uiScaleInput, syncCloud = true)
                                            Toast.makeText(
                                                context,
                                                "✅ Đã lưu & đồng bộ toàn cầu mức thu phóng ${kotlin.math.round(uiScaleInput * 100).toInt()}%!",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        },
                                        valueRange = 0.80f..1.00f,
                                        steps = 19,
                                        colors = SliderDefaults.colors(
                                            thumbColor = MagicCyan,
                                            activeTrackColor = MagicCyan,
                                            inactiveTrackColor = Color(0xFF334155)
                                        ),
                                        modifier = Modifier.fillMaxWidth().testTag("admin_ui_scale_slider")
                                    )

                                    // Các nút chọn nhanh (Presets)
                                    Row(
                                        modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        listOf(0.80f, 0.85f, 0.90f, 0.95f, 1.00f).forEach { preset ->
                                            val pLabel = "${(preset * 100).toInt()}%"
                                            val isSelected = kotlin.math.abs(uiScaleInput - preset) < 0.015f
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = if (isSelected) MagicCyan.copy(alpha = 0.25f) else Color(0xFF0F172A),
                                                border = BorderStroke(1.dp, if (isSelected) MagicCyan else Color(0xFF334155)),
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clickable {
                                                        uiScaleInput = preset
                                                        LicenseManager.setAppUiScale(context, preset, syncCloud = true)
                                                        Toast.makeText(
                                                            context,
                                                            "✅ Đã lưu & đồng bộ mức thu phóng ${(preset * 100).toInt()}%!",
                                                            Toast.LENGTH_SHORT
                                                        ).show()
                                                    }
                                            ) {
                                                Text(
                                                    text = pLabel,
                                                    color = if (isSelected) MagicCyan else TextSecondary,
                                                    fontSize = 9.5.sp,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                                    modifier = Modifier.padding(vertical = 6.dp)
                                                )
                                            }
                                        }
                                    }

                                    // Nút Lưu và Khôi phục
                                    Row(
                                        modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Button(
                                            onClick = {
                                                LicenseManager.setAppUiScale(context, uiScaleInput, syncCloud = true)
                                                Toast.makeText(
                                                    context,
                                                    "✅ Đã áp dụng & đồng bộ toàn cầu mức thu phóng $currentScalePercent%!",
                                                    Toast.LENGTH_SHORT
                                                ).show()
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = MagicCyan),
                                            modifier = Modifier.weight(1.3f).defaultMinSize(minHeight = 36.dp)
                                        ) {
                                            Text("Áp Dụng Thu Phóng ($currentScalePercent%)", color = Color(0xFF020617), fontWeight = FontWeight.Black, fontSize = 11.sp)
                                        }

                                        OutlinedButton(
                                            onClick = {
                                                uiScaleInput = 0.85f
                                                LicenseManager.setAppUiScale(context, 0.85f, syncCloud = true)
                                                Toast.makeText(context, "✅ Đã khôi phục mức thu phóng mặc định 85%", Toast.LENGTH_SHORT).show()
                                            },
                                            modifier = Modifier.weight(0.7f).defaultMinSize(minHeight = 36.dp),
                                            border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.5f))
                                        ) {
                                            Text("Mặc Định (85%)", color = MagicCyanLight, fontWeight = FontWeight.Bold, fontSize = 10.5.sp)
                                        }
                                    }
                                }
                            }
                    }
                }
                1 -> {
                    // TAB 1 HỢP NHẤT: TRUNG TÂM QUẢN LÝ USER & THIẾT BỊ THỰC TẾ 10X (120fps)
                    val proDevicesCount = tab1State.proDevicesCount
                    val accountProDevicesCount = tab1State.accountProDevicesCount
                    val deviceOnlyProCount = tab1State.deviceOnlyProCount
                    val freeDevicesCount = tab1State.freeDevicesCount
                    val suspiciousDevicesCount = tab1State.suspiciousDevicesCount
                    val filteredDevices = tab1State.filteredDevices

                    val adminCount = tab3State.adminCount
                    val proUsersCount = tab3State.proUsersCount
                    val accountProCount = tab3State.accountProCount
                    val deviceProCount = tab3State.deviceProCount
                    val normalUsersCount = tab3State.normalUsersCount
                    val revokedCount = tab3State.revokedCount
                    val filteredUsers = tab3State.filteredUsers

                    item(key = "tab1_unified_summary", contentType = "unified_summary") {
                        AdminUserDeviceSummaryHeader(
                            totalDevices = globalMergedDevices.size,
                            proDevicesCount = proDevicesCount,
                            accountProDevicesCount = accountProDevicesCount,
                            deviceOnlyProCount = deviceOnlyProCount,
                            freeDevicesCount = freeDevicesCount,
                            suspiciousDevicesCount = suspiciousDevicesCount,
                            online24hDevicesCount = online24hDevicesCount,
                            boundDevicesCount = boundDevicesCount,
                            guestDevicesCount = guestDevicesCount,
                            totalUsers = globalMergedUsers.size,
                            proUsersCount = proUsersCount,
                            accountProCount = accountProCount,
                            deviceProCount = deviceProCount,
                            normalUsersCount = normalUsersCount,
                            adminCount = adminCount,
                            revokedCount = revokedCount,
                            online24hUsersCount = online24hUsersCount,
                            unifiedManageMode = unifiedManageMode,
                            multiSelectMode = multiSelectMode,
                            onSelectMode = { mode ->
                                unifiedManageMode = mode
                                selectedDeviceIds.clear()
                                selectedUserKeys.clear()
                                if (mode == "DEVICES") deviceCurrentPage = 0 else currentPage = 0
                            },
                            onToggleMultiSelect = {
                                multiSelectMode = !multiSelectMode
                                if (!multiSelectMode) {
                                    selectedDeviceIds.clear()
                                    selectedUserKeys.clear()
                                }
                            },
                            onExportProSummary = {
                                val report = buildString {
                                    appendLine("=== MAGICTUNE PRO SUMMARY ===")
                                    appendLine("Tổng Máy: ${globalMergedDevices.size} (Pro: $proDevicesCount [TK: $accountProDevicesCount | Máy: $deviceOnlyProCount], Online 24h: $online24hDevicesCount)")
                                    appendLine("Tổng User: ${globalMergedUsers.size} (Pro: $proUsersCount [TK: $accountProCount | Máy: $deviceProCount], Admin: $adminCount)")
                                    appendLine("--- DANH SÁCH MÁY PRO ---")
                                    globalMergedDevices.filter { it.isPro && !it.revokedByAdmin }.take(80).forEach { d ->
                                        val tier = if (d.isAccountPro || d.proTier == "ACCOUNT_PRO") "PRO_TK" else "PRO_MAY"
                                        appendLine("${d.deviceId} | $tier | ${d.model} | ${d.ownerEmail}")
                                    }
                                }.trim()
                                val cb = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
                                if (cb != null) {
                                    cb.setPrimaryClip(android.content.ClipData.newPlainText("MagicTune Pro Summary", report))
                                    Toast.makeText(context, "📋 Đã copy báo cáo ${proDevicesCount} máy Pro & ${proUsersCount} user Pro!", Toast.LENGTH_LONG).show()
                                }
                            },
                            onQuickLookupCloud = {
                                quickCloudLookupQuery = ""
                                quickCloudAuditResult = null
                                showQuickCloudLookupDialog = true
                            }
                        )
                    }

                    // Thanh thao tác hàng loạt khi Multi-Select đang bật
                    if (multiSelectMode) {
                        item(key = "tab1_batch_bar", contentType = "batch_bar") {
                            val activeCount = if (unifiedManageMode == "DEVICES") selectedDeviceIds.size else selectedUserKeys.size
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF2E1065)),
                                border = BorderStroke(1.2.dp, MagicPurpleLight)
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxWidth().padding(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "☑️ Đang chọn: $activeCount mục",
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Text(
                                                text = "Chọn trang này",
                                                color = MagicCyanLight,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.clickable {
                                                    if (unifiedManageMode == "DEVICES") {
                                                        paginatedDevices.forEach { d ->
                                                            if (!selectedDeviceIds.contains(d.deviceId)) selectedDeviceIds.add(d.deviceId)
                                                        }
                                                    } else {
                                                        pagedUsers.forEach { u ->
                                                            val k = u.userId.ifBlank { u.email }
                                                            if (k.isNotBlank() && !selectedUserKeys.contains(k)) selectedUserKeys.add(k)
                                                        }
                                                    }
                                                }
                                            )
                                            Text(
                                                text = "Bỏ chọn",
                                                color = MagicRoseLight,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.clickable {
                                                    selectedDeviceIds.clear()
                                                    selectedUserKeys.clear()
                                                }
                                            )
                                        }
                                    }
                                    if (activeCount > 0) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min).horizontalScroll(rememberScrollState()),
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Button(
                                                onClick = {
                                                    val targets = if (unifiedManageMode == "DEVICES") selectedDeviceIds.toList() else emptyList()
                                                    val userTargets = if (unifiedManageMode == "USERS") {
                                                        globalMergedUsers.filter { selectedUserKeys.contains(it.userId.ifBlank { it.email }) }
                                                    } else emptyList()
                                                    coroutineScope.launch(Dispatchers.IO) {
                                                        var done = 0
                                                        targets.forEach { id ->
                                                            val dev = globalMergedDevices.firstOrNull { it.deviceId == id }
                                                            LicenseManager.adminGrantTierForUserOrDevice(
                                                                userId = dev?.ownerUid.orEmpty(),
                                                                deviceId = id,
                                                                ownerEmail = dev?.ownerEmail.orEmpty(),
                                                                grantAccountPro = true,
                                                                context = context,
                                                                noteOrReason = "ADMIN_BATCH_MULTI_SELECT_PRO_TK"
                                                            ) { ok, _ -> if (ok) done++ }
                                                        }
                                                        userTargets.forEach { u ->
                                                            LicenseManager.adminGrantTierForUserOrDevice(
                                                                userId = u.userId,
                                                                deviceId = u.activeDeviceId.ifBlank { u.deviceId },
                                                                ownerEmail = u.email,
                                                                grantAccountPro = true,
                                                                context = context,
                                                                noteOrReason = "ADMIN_BATCH_MULTI_SELECT_PRO_TK"
                                                            ) { ok, _ -> if (ok) done++ }
                                                        }
                                                        withContext(Dispatchers.Main) {
                                                            Toast.makeText(context, "👑 Đã gửi lệnh Cấp Pro Tài Khoản hàng loạt!", Toast.LENGTH_LONG).show()
                                                            selectedDeviceIds.clear()
                                                            selectedUserKeys.clear()
                                                        }
                                                        refreshAllAdminMetricsViaRest(showToastOnDone = false, force = true)
                                                    }
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = MagicAmber),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.defaultMinSize(minHeight = 36.dp)
                                            ) {
                                                Text("👑 Cấp Pro TK ($activeCount)", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Black)
                                            }
                                            if (unifiedManageMode == "DEVICES") {
                                                Button(
                                                    onClick = {
                                                        val targets = selectedDeviceIds.toList()
                                                        targets.forEach { id ->
                                                            LicenseManager.adminResetDeviceTrialCount(id, 0) { }
                                                        }
                                                        Toast.makeText(context, "🎯 Đã reset lượt dùng thử về 0 cho ${targets.size} máy!", Toast.LENGTH_LONG).show()
                                                        selectedDeviceIds.clear()
                                                        refreshAllAdminMetricsViaRest(showToastOnDone = false, force = true)
                                                    },
                                                    colors = ButtonDefaults.buttonColors(containerColor = MagicCyan),
                                                    shape = RoundedCornerShape(8.dp),
                                                    modifier = Modifier.defaultMinSize(minHeight = 36.dp)
                                                ) {
                                                    Text("🎯 Reset Trial ($activeCount)", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Black)
                                                }
                                            }
                                            Button(
                                                onClick = {
                                                    val targets = if (unifiedManageMode == "DEVICES") selectedDeviceIds.toList() else emptyList()
                                                    val userTargets = if (unifiedManageMode == "USERS") {
                                                        globalMergedUsers.filter { selectedUserKeys.contains(it.userId.ifBlank { it.email }) }
                                                    } else emptyList()
                                                    coroutineScope.launch(Dispatchers.IO) {
                                                        targets.forEach { id ->
                                                            val dev = globalMergedDevices.firstOrNull { it.deviceId == id }
                                                            LicenseManager.adminRevokeProCompletely(
                                                                context = context,
                                                                userId = dev?.ownerUid.orEmpty(),
                                                                deviceId = id,
                                                                ownerEmail = dev?.ownerEmail.orEmpty()
                                                            )
                                                        }
                                                        userTargets.forEach { u ->
                                                            LicenseManager.adminRevokeProCompletely(
                                                                context = context,
                                                                userId = u.userId,
                                                                deviceId = u.activeDeviceId.ifBlank { u.deviceId },
                                                                ownerEmail = u.email
                                                            )
                                                        }
                                                        withContext(Dispatchers.Main) {
                                                            Toast.makeText(context, "🚫 Đã thu hồi Pro hàng loạt!", Toast.LENGTH_LONG).show()
                                                            selectedDeviceIds.clear()
                                                            selectedUserKeys.clear()
                                                        }
                                                        refreshAllAdminMetricsViaRest(showToastOnDone = false, force = true)
                                                    }
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = MagicRose),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.defaultMinSize(minHeight = 36.dp)
                                            ) {
                                                Text("🚫 Thu Hồi ($activeCount)", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Black)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (unifiedManageMode == "DEVICES") {
                        item(key = "tab1_controls", contentType = "tab_controls") {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                                ) {
                                    val filterTabs = listOf(
                                        "Tất cả" to "Tất cả (${globalMergedDevices.size})",
                                        "🟢 Online 24h" to "🟢 Online 24h (${tab1State.online24hCount})",
                                        "⚡ ĐÃ LÊN PRO" to "⚡ Pro ($proDevicesCount)",
                                        "👑 PRO TÀI KHOẢN" to "👑 Pro TK ($accountProDevicesCount)",
                                        "📱 PRO THIẾT BỊ" to "📱 Pro Máy ($deviceOnlyProCount)",
                                        "👤 CÓ TÀI KHOẢN" to "👤 Gắn TK (${tab1State.boundCount})",
                                        "🚀 KHÁCH VÃNG LAI" to "Khách (${tab1State.guestCount})",
                                        "🔓 CHƯA LÊN PRO" to "🔓 Free ($freeDevicesCount)",
                                        "🚨 NGHI VẤN" to "🚨 Nghi vấn ($suspiciousDevicesCount)"
                                    )
                                    filterTabs.forEach { (tabKey, tabLabel) ->
                                        val isSelected = deviceFilterTab == tabKey
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(
                                                    when {
                                                        isSelected && tabKey == "🚨 NGHI VẤN" -> MagicRose.copy(alpha = 0.3f)
                                                        isSelected && tabKey.contains("PRO") -> MagicEmerald.copy(alpha = 0.25f)
                                                        isSelected && tabKey == "🔓 CHƯA LÊN PRO" -> MagicAmber.copy(alpha = 0.25f)
                                                        isSelected -> MagicCyan.copy(alpha = 0.25f)
                                                        else -> MagicSurfaceDark
                                                    }
                                                )
                                                .border(
                                                    1.dp,
                                                    when {
                                                        isSelected && tabKey == "🚨 NGHI VẤN" -> MagicRose
                                                        isSelected && tabKey.contains("PRO") -> MagicEmerald
                                                        isSelected && tabKey == "🔓 CHƯA LÊN PRO" -> MagicAmber
                                                        isSelected -> MagicCyan
                                                        else -> MagicBorder
                                                    },
                                                    RoundedCornerShape(8.dp)
                                                )
                                                .clickable {
                                                    deviceFilterTab = tabKey
                                                    deviceCurrentPage = 0
                                                }
                                                .padding(vertical = 8.dp, horizontal = 10.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = tabLabel,
                                                color = when {
                                                    isSelected && tabKey == "🚨 NGHI VẤN" -> MagicRoseLight
                                                    isSelected && tabKey.contains("PRO") -> MagicEmeraldLight
                                                    isSelected && tabKey == "🔓 CHƯA LÊN PRO" -> MagicAmber
                                                    isSelected -> MagicCyanLight
                                                    else -> TextSecondary
                                                },
                                                fontSize = 9.5.sp,
                                                fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                                                maxLines = 1
                                            )
                                        }
                                    }
                                }

                                AdminSortSelectorRow(
                                    selectedSort = deviceSortMode,
                                    showTrialsSort = true,
                                    onSelectSort = { deviceSortMode = it; deviceCurrentPage = 0 }
                                )

                                if (deviceFilterTab == "🚨 NGHI VẤN" && suspiciousDevicesCount > 0) {
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = CardDefaults.cardColors(containerColor = MagicRose.copy(alpha = 0.15f)),
                                        border = BorderStroke(1.2.dp, MagicRose)
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(10.dp),
                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Text(
                                                text = "🚨 PHÁT HIỆN $suspiciousDevicesCount THIẾT BỊ NGHI VẤN TỰ PHONG PRO HOẶC THIẾU CHỨNG TỪ",
                                                color = MagicRoseLight,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            )
                                            Text(
                                                text = "Các máy này có ID không hợp lệ hoặc bật cờ Pro mà thiếu cả License Key, AI Log lẫn Mã Giao Dịch ngân hàng.",
                                                color = Color.White.copy(alpha = 0.85f),
                                                fontSize = 10.sp
                                            )
                                            Button(
                                                onClick = {
                                                    coroutineScope.launch {
                                                        var count = 0
                                                        filteredDevices.forEach { dev ->
                                                            try {
                                                                FirebaseAuthManager.toggleDeviceProStatus(
                                                                    deviceId = dev.deviceId,
                                                                    isPro = false,
                                                                    context = context,
                                                                    userId = dev.ownerUid,
                                                                    ownerEmail = dev.ownerEmail
                                                                )
                                                                count++
                                                            } catch (_: Exception) {}
                                                        }
                                                        Toast.makeText(context, "🚫 Đã thu hồi quyền Pro của $count thiết bị nghi vấn!", Toast.LENGTH_LONG).show()
                                                        refreshAllAdminMetricsViaRest(showToastOnDone = false, force = true)
                                                    }
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = MagicRose),
                                                modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 36.dp),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Text("🚫 THU HỒI PRO TẤT CẢ $suspiciousDevicesCount MÁY NGHI VẤN", color = Color.White, fontWeight = FontWeight.Black, fontSize = 10.5.sp)
                                            }
                                        }
                                    }
                                }

                                OutlinedTextField(
                                    value = deviceSearchQuery,
                                    onValueChange = { deviceSearchQuery = it; deviceCurrentPage = 0 },
                                    modifier = Modifier.fillMaxWidth(),
                                    label = { Text("Tìm Device ID, Tên máy, Email, Key...", fontSize = 11.sp) },
                                    singleLine = true,
                                    shape = RoundedCornerShape(8.dp),
                                    leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = MagicCyan, modifier = Modifier.size(18.dp)) },
                                    trailingIcon = {
                                        if (deviceSearchQuery.isNotBlank()) {
                                            IconButton(onClick = { deviceSearchQuery = ""; deviceCurrentPage = 0 }) {
                                                Icon(imageVector = Icons.Default.Clear, contentDescription = "Xóa tìm kiếm", tint = Color.White, modifier = Modifier.size(16.dp))
                                            }
                                        }
                                    }
                                )
                            }
                        }

                        if (filteredDevices.isEmpty()) {
                            item(key = "tab1_empty", contentType = "empty_state") {
                                Box(modifier = Modifier.fillMaxWidth().height(100.dp), contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "Chưa có thiết bị nào phù hợp bộ lọc.",
                                        color = TextMuted,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        } else {
                            items(
                                items = paginatedDevices,
                                key = { dev ->
                                    val norm = LicenseManager.normalizeDeviceIdForMatch(dev.deviceId)
                                    "dev_${norm.ifBlank { dev.hardwareId.ifBlank { dev.ownerEmail.trim().lowercase().ifBlank { dev.hashCode().toString() } } }}"
                                },
                                contentType = { "device_card" }
                            ) { dev ->
                                val normDevId = LicenseManager.normalizeDeviceIdForMatch(dev.deviceId)
                                val matchedAiBillLog = if (normDevId.isNotBlank()) aiBillLogByNormDevId[normDevId] else null
                                val cleanOwnerEmail = dev.ownerEmail.trim().lowercase()
                                val matchedOwnerUser = (if (dev.ownerUid.isNotBlank()) userByUid[dev.ownerUid] else null)
                                    ?: (if (cleanOwnerEmail.contains("@")) userByEmail[cleanOwnerEmail] else null)
                                    ?: (if (normDevId.isNotBlank()) userByNormDevId[normDevId] else null)
                                val isChecked = selectedDeviceIds.contains(dev.deviceId)
                                val isExpanded = expandedDeviceIds.contains(dev.deviceId)

                                AdminDeviceCardCompact(
                                    dev = dev,
                                    matchedOwnerUser = matchedOwnerUser,
                                    matchedAiBillLog = matchedAiBillLog,
                                    multiSelectMode = multiSelectMode,
                                    isChecked = isChecked,
                                    isExpanded = isExpanded,
                                    onToggleCheck = {
                                        if (isChecked) selectedDeviceIds.remove(dev.deviceId)
                                        else selectedDeviceIds.add(dev.deviceId)
                                    },
                                    onToggleExpand = {
                                        if (isExpanded) expandedDeviceIds.remove(dev.deviceId)
                                        else expandedDeviceIds.add(dev.deviceId)
                                    },
                                    onJumpToOwnerUser = { email ->
                                        unifiedManageMode = "USERS"
                                        selectedFilterChip = "Tất cả"
                                        searchQuery = email
                                        currentPage = 0
                                    },
                                    onLookupCloud = { queryId ->
                                        quickCloudLookupQuery = queryId
                                        quickCloudAuditResult = null
                                        showQuickCloudLookupDialog = true
                                        isQuickCloudLookingUp = true
                                        coroutineScope.launch {
                                            try {
                                                quickCloudAuditResult = LicenseManager.adminLookupTargetViaCloud(context, queryId)
                                            } catch (_: Throwable) {
                                            } finally {
                                                isQuickCloudLookingUp = false
                                            }
                                        }
                                    },
                                    onResetTrial = { targetDev ->
                                        LicenseManager.adminResetDeviceTrialCount(targetDev.deviceId, 0) { ok ->
                                            if (ok) {
                                                AdminSessionCache.updateSnapshot(context) { cur ->
                                                    val normT = LicenseManager.normalizeDeviceIdForMatch(targetDev.deviceId)
                                                    cur.copy(devices = cur.devices.map { d ->
                                                        if (LicenseManager.normalizeDeviceIdForMatch(d.deviceId) == normT) d.copy(freeTrialUsed = 0) else d
                                                    })
                                                }
                                                Toast.makeText(context, "🎯 Đã reset lượt dùng thử máy ${targetDev.deviceId} về 0!", Toast.LENGTH_SHORT).show()
                                            } else {
                                                Toast.makeText(context, "⚠️ Không thể reset lượt dùng thử!", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    },
                                    onUnlockSession = { ownerU ->
                                        LicenseManager.adminResetUserActiveDeviceSession(ownerU.userId, ownerU.email) { ok ->
                                            Toast.makeText(
                                                context,
                                                if (ok) "🔓 Đã mở khóa phiên 1 máy cho ${ownerU.email}!" else "❌ Lỗi khi mở khóa phiên thiết bị!",
                                                Toast.LENGTH_LONG
                                            ).show()
                                        }
                                    },
                                    onGenerateKey = { targetDev ->
                                        genDeviceIdInput = targetDev.deviceId
                                        val isAcc = targetDev.isAccountPro || targetDev.proTier == "ACCOUNT_PRO"
                                        val key = if (isAcc) LicenseManager.generateAccountProLicenseKeyForDevice(targetDev.deviceId)
                                        else LicenseManager.generateLicenseKeyForDevice(targetDev.deviceId)
                                        generatedKeyOutput = key
                                        LicenseManager.registerAdminGeneratedKeyToCloud(targetDev.deviceId, key, isAccountPro = isAcc, context = context, ownerEmailHint = targetDev.ownerEmail)
                                        activeProReceipt = ProGrantReceiptData(
                                            targetDeviceId = targetDev.deviceId,
                                            targetEmail = targetDev.ownerEmail,
                                            isAccountPro = isAcc,
                                            generatedKey = key,
                                            reasonNote = "Tạo Key từ danh sách Thiết Bị",
                                            cloudSyncMessage = "Đã tạo Key SHA-256 & đồng bộ lên Cloud!"
                                        )
                                    },
                                    onDowngrade = { targetDev -> downgradeTargetDevice = targetDev },
                                    onGrantOrChangeTier = { targetDev -> targetDeviceForAction = targetDev }
                                )
                            }

                            if (totalDevicePages > 1) {
                                item(key = "tab1_pager", contentType = "pager") {
                                    Row(
                                        modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min).padding(vertical = 4.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        OutlinedButton(
                                            onClick = { if (safeDevicePage > 0) deviceCurrentPage = safeDevicePage - 1 },
                                            enabled = safeDevicePage > 0,
                                            modifier = Modifier.defaultMinSize(minHeight = 36.dp),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text("← Trang trước", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                        Text(
                                            text = "Trang ${safeDevicePage + 1} / $totalDevicePages (${filteredDevices.size})",
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        OutlinedButton(
                                            onClick = { if (safeDevicePage < totalDevicePages - 1) deviceCurrentPage = safeDevicePage + 1 },
                                            enabled = safeDevicePage < totalDevicePages - 1,
                                            modifier = Modifier.defaultMinSize(minHeight = 36.dp),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text("Trang sau →", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                        if (hasMoreDevices) {
                            item(key = "tab1_load_more", contentType = "pagination") {
                                Column(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = "Đã tải ${allDevicesList.size} mục; máy chủ tải tiếp theo lô 150 để giữ RAM ổn định.",
                                        color = TextMuted,
                                        fontSize = 10.sp,
                                        textAlign = TextAlign.Center
                                    )
                                    OutlinedButton(
                                        onClick = { loadMoreAdminDevices() },
                                        enabled = !isLoadingMoreDevices,
                                        modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 36.dp)
                                    ) {
                                        if (isLoadingMoreDevices) {
                                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                            Spacer(Modifier.width(8.dp))
                                            Text("Đang tải thiết bị…", fontSize = 11.sp)
                                        } else {
                                            Text("Tải thêm thiết bị", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        item(key = "tab3_controls", contentType = "tab_controls") {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    val filterChips = listOf(
                                        "Tất cả" to "Tất cả (${globalMergedUsers.size})",
                                        "🟢 Online 24h" to "🟢 Online 24h (${tab3State.online24hCount})",
                                        "⚡ Pro" to "⚡ Pro ($proUsersCount)",
                                        "👑 Pro TK" to "👑 Pro TK ($accountProCount)",
                                        "📱 Pro Máy" to "📱 Pro Máy ($deviceProCount)",
                                        "📱 Đa Thiết Bị" to "📱 ≥2 Máy (${tab3State.multiDeviceCount})",
                                        "👑 Admin" to "Admin ($adminCount)",
                                        "👤 User" to "User Free ($normalUsersCount)",
                                        "🚫 Đã Hạ Cấp" to "Hạ Cấp ($revokedCount)"
                                    )
                                    filterChips.forEach { (chipKey, chipLabel) ->
                                        val selected = selectedFilterChip == chipKey
                                        FilterChip(
                                            selected = selected,
                                            onClick = { selectedFilterChip = chipKey; currentPage = 0 },
                                            label = { Text(chipLabel, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = when {
                                                    chipKey == "🚫 Đã Hạ Cấp" -> MagicRose.copy(alpha = 0.35f)
                                                    chipKey.contains("Pro") || chipKey == "⚡ Pro" -> MagicEmerald.copy(alpha = 0.3f)
                                                    else -> MagicCyan.copy(alpha = 0.3f)
                                                },
                                                selectedLabelColor = when {
                                                    chipKey == "🚫 Đã Hạ Cấp" -> MagicRoseLight
                                                    chipKey.contains("Pro") || chipKey == "⚡ Pro" -> MagicEmeraldLight
                                                    else -> MagicCyanLight
                                                },
                                                containerColor = MagicSurfaceDark,
                                                labelColor = TextSecondary
                                            )
                                        )
                                    }
                                }

                                AdminSortSelectorRow(
                                    selectedSort = userSortMode,
                                    showTrialsSort = false,
                                    onSelectSort = { userSortMode = it; currentPage = 0 }
                                )

                                OutlinedTextField(
                                    value = searchQuery,
                                    onValueChange = { searchQuery = it; currentPage = 0 },
                                    modifier = Modifier.fillMaxWidth(),
                                    label = { Text("Tìm User (Tên, Email, SĐT, Device ID)...", fontSize = 11.sp) },
                                    singleLine = true,
                                    shape = RoundedCornerShape(8.dp),
                                    leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = MagicCyan, modifier = Modifier.size(18.dp)) },
                                    trailingIcon = {
                                        if (searchQuery.isNotBlank()) {
                                            IconButton(onClick = { searchQuery = ""; currentPage = 0 }) {
                                                Icon(imageVector = Icons.Default.Clear, contentDescription = "Xóa tìm kiếm", tint = Color.White, modifier = Modifier.size(16.dp))
                                            }
                                        }
                                    }
                                )
                            }
                        }

                        if (filteredUsers.isEmpty()) {
                            item(key = "tab3_empty", contentType = "empty_state") {
                                Box(modifier = Modifier.fillMaxWidth().height(100.dp), contentAlignment = Alignment.Center) {
                                    Text(text = "Không tìm thấy người dùng phù hợp bộ lọc.", color = TextMuted, fontSize = 12.sp)
                                }
                            }
                        } else {
                            items(
                                items = pagedUsers,
                                key = { u ->
                                    "user_${u.userId.ifBlank { u.email.trim().lowercase().ifBlank { u.deviceId.trim().uppercase().ifBlank { u.hashCode().toString() } } }}"
                                },
                                contentType = { "user_card" }
                            ) { u ->
                                val uKey = u.userId.ifBlank { u.email }
                                val linkedDevs = linkedDevicesByUserKey[u.userId]
                                    ?: linkedDevicesByUserKey[u.email.trim().lowercase()]
                                    ?: emptyList()
                                val targetDevIdNorm = LicenseManager.normalizeDeviceIdForMatch(u.activeDeviceId.ifBlank { u.deviceId })
                                val matchedBillLog = (if (targetDevIdNorm.isNotBlank()) aiBillLogByNormDevId[targetDevIdNorm] else null)
                                    ?: (u.email.trim().lowercase().takeIf { it.isNotBlank() }?.let { aiBillLogByEmail[it] })
                                val isChecked = selectedUserKeys.contains(uKey)
                                val isExpanded = expandedUserKeys.contains(uKey)

                                AdminUserCardCompact(
                                    u = u,
                                    linkedDevices = linkedDevs,
                                    matchedBillLog = matchedBillLog,
                                    multiSelectMode = multiSelectMode,
                                    isChecked = isChecked,
                                    isExpanded = isExpanded,
                                    onToggleCheck = {
                                        if (isChecked) selectedUserKeys.remove(uKey)
                                        else selectedUserKeys.add(uKey)
                                    },
                                    onToggleExpand = {
                                        if (isExpanded) expandedUserKeys.remove(uKey)
                                        else expandedUserKeys.add(uKey)
                                    },
                                    onJumpToDevice = { devIdTarget ->
                                        unifiedManageMode = "DEVICES"
                                        deviceFilterTab = "Tất cả"
                                        deviceSearchQuery = devIdTarget
                                        deviceCurrentPage = 0
                                    },
                                    onLookupCloud = { query ->
                                        quickCloudLookupQuery = query
                                        quickCloudAuditResult = null
                                        showQuickCloudLookupDialog = true
                                        isQuickCloudLookingUp = true
                                        coroutineScope.launch {
                                            try {
                                                quickCloudAuditResult = LicenseManager.adminLookupTargetViaCloud(context, query)
                                            } catch (_: Throwable) {
                                            } finally {
                                                isQuickCloudLookingUp = false
                                            }
                                        }
                                    },
                                    onUnlockSession = { usr ->
                                        LicenseManager.adminResetUserActiveDeviceSession(usr.userId, usr.email) { ok ->
                                            Toast.makeText(
                                                context,
                                                if (ok) "🔓 Đã mở khóa phiên 1 máy cho ${usr.displayName.ifBlank { usr.email }}!" else "❌ Lỗi khi mở khóa phiên thiết bị!",
                                                Toast.LENGTH_LONG
                                            ).show()
                                        }
                                    },
                                    onUpgradeAdmin = { usr ->
                                        targetUserForAction = usr
                                        pendingActionType = "admin"
                                    },
                                    onDowngrade = { usr -> downgradeTargetUser = usr },
                                    onGrantOrChangeTier = { usr ->
                                        targetUserForAction = usr
                                        pendingActionType = "pro"
                                    }
                                )
                            }

                            if (totalPages > 1) {
                                item(key = "tab3_pager", contentType = "pager") {
                                    Row(
                                        modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min).padding(vertical = 4.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        OutlinedButton(
                                            onClick = { if (safeCurrentPage > 0) currentPage = safeCurrentPage - 1 },
                                            enabled = safeCurrentPage > 0,
                                            modifier = Modifier.defaultMinSize(minHeight = 36.dp)
                                        ) {
                                            Text("← Trang trước", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                        Text(
                                            text = "Trang ${safeCurrentPage + 1} / $totalPages (${filteredUsers.size})",
                                            color = TextSecondary,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        OutlinedButton(
                                            onClick = { if (safeCurrentPage < totalPages - 1) currentPage = safeCurrentPage + 1 },
                                            enabled = safeCurrentPage < totalPages - 1,
                                            modifier = Modifier.defaultMinSize(minHeight = 36.dp)
                                        ) {
                                            Text("Trang sau →", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                        if (hasMoreUsers) {
                            item(key = "tab3_load_more", contentType = "pagination") {
                                Column(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = "Đã tải ${allUsersList.size} mục; máy chủ tải tiếp theo lô 150 để giữ RAM ổn định.",
                                        color = TextMuted,
                                        fontSize = 10.sp,
                                        textAlign = TextAlign.Center
                                    )
                                    OutlinedButton(
                                        onClick = { loadMoreAdminUsers() },
                                        enabled = !isLoadingMoreUsers,
                                        modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 36.dp)
                                    ) {
                                        if (isLoadingMoreUsers) {
                                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                            Spacer(Modifier.width(8.dp))
                                            Text("Đang tải người dùng…", fontSize = 11.sp)
                                        } else {
                                            Text("Tải thêm người dùng", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                2 -> {
                    // TAB 2: KHÁCH HÀNG ĐANG THANH TOÁN / CHỜ DUYỆT (LazyColumn items - 120fps)
                    val paidActionCount = tab2State.paidActionCount
                    val qrOpenedCount = tab2State.qrOpenedCount
                    val filteredIntents = tab2State.filteredIntents

                    item(key = "tab2_controls", contentType = "tab_controls") {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "💳 HÀNH ĐỘNG & GIAO DỊCH THANH TOÁN CỦA KHÁCH HÀNG (REAL-TIME)",
                                color = MagicAmber,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "Admin có thể thấy ngay khi khách bấm 'Tôi đã chuyển khoản' hoặc mở QR thanh toán và bấm Cấp Pro ngay lập tức.",
                                color = TextSecondary,
                                fontSize = 10.5.sp
                            )

                            // Thanh tìm kiếm và bộ lọc nhanh cho Tab 2 Chờ Duyệt
                            OutlinedTextField(
                                value = intentSearchQuery,
                                onValueChange = { intentSearchQuery = it },
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text("Tìm theo Device ID, email, ghi chú...", fontSize = 11.sp) },
                                singleLine = true,
                                shape = RoundedCornerShape(8.dp),
                                leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = MagicAmber, modifier = Modifier.size(18.dp)) },
                                trailingIcon = {
                                    if (intentSearchQuery.isNotBlank()) {
                                        IconButton(onClick = { intentSearchQuery = "" }) {
                                            Icon(imageVector = Icons.Default.Clear, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            )

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                val intentTabs = listOf(
                                    "Tất cả" to "Tất cả (${deduplicatedPaymentIntents.size})",
                                    "🔥 BÁO CHUYỂN KHOẢN" to "Đã báo CK ($paidActionCount)",
                                    "👁️ XEM QR" to "Mở xem QR ($qrOpenedCount)",
                                    "✅ ĐÃ DUYỆT" to "Đã duyệt (${tab2State.approvedCount})"
                                )
                                intentTabs.forEach { (tabKey, tabLabel) ->
                                    val isSelected = intentFilterTab == tabKey
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = { intentFilterTab = tabKey },
                                        label = { Text(tabLabel, fontSize = 10.5.sp, fontWeight = FontWeight.Bold) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = if (tabKey.contains("BÁO")) MagicEmerald.copy(alpha = 0.35f) else MagicAmber.copy(alpha = 0.35f),
                                            selectedLabelColor = if (tabKey.contains("BÁO")) MagicEmeraldLight else MagicAmber,
                                            containerColor = MagicSurfaceDark,
                                            labelColor = TextSecondary
                                        )
                                    )
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    enabled = !isCleaningStaleIntents && paymentIntentsList.isNotEmpty(),
                                    onClick = {
                                        coroutineScope.launch {
                                            isCleaningStaleIntents = true
                                            try {
                                                val proNormIds = globalMergedDevices
                                                    .filter { it.isPro && !it.revokedByAdmin }
                                                    .map { LicenseManager.normalizeDeviceIdForMatch(it.deviceId) }
                                                    .filter { it.isNotBlank() }
                                                    .toSet()
                                                val (deletedCount, deletedIds) = LicenseManager.cleanupStalePaymentIntents(
                                                    context = context,
                                                    existingIntents = paymentIntentsList,
                                                    proNormDeviceIds = proNormIds
                                                )
                                                if (deletedIds.isNotEmpty()) {
                                                    AdminSessionCache.updateSnapshot(context) { cur ->
                                                        cur.copy(paymentIntents = cur.paymentIntents.filter { !deletedIds.contains(it.intentId) })
                                                    }
                                                }
                                                Toast.makeText(
                                                    context,
                                                    if (deletedCount > 0) "🧹 Đã dọn $deletedCount đơn xem QR quá hạn / đã kích hoạt Pro!"
                                                    else "✅ Danh sách chờ duyệt đã sạch, chưa có đơn rác.",
                                                    Toast.LENGTH_SHORT
                                                ).show()
                                            } catch (e: Throwable) {
                                                Toast.makeText(context, "⚠️ Lỗi dọn dẹp: ${e.localizedMessage ?: e.message}", Toast.LENGTH_SHORT).show()
                                            } finally {
                                                isCleaningStaleIntents = false
                                            }
                                        }
                                    },
                                    modifier = Modifier.weight(1f).defaultMinSize(minHeight = 36.dp),
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.5f)),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = if (isCleaningStaleIntents) "⏳ Đang dọn..." else "🧹 Dọn Đơn Rác (>24h / Đã Pro)",
                                        color = MagicCyanLight,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                OutlinedButton(
                                    onClick = { showBatchGrantDialog = true },
                                    modifier = Modifier.fillMaxHeight().weight(0.75f).defaultMinSize(minHeight = 36.dp),
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(1.dp, MagicAmber.copy(alpha = 0.55f)),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text("⚡ Cấp Hàng Loạt", color = MagicAmberLight, fontSize = 10.sp, fontWeight = FontWeight.Black)
                                }
                            }
                        }
                    }

                    if (filteredIntents.isEmpty()) {
                        item(key = "tab2_empty", contentType = "empty_state") {
                            Box(modifier = Modifier.fillMaxWidth().height(100.dp), contentAlignment = Alignment.Center) {
                                if (isSyncingMetrics) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        CircularProgressIndicator(
                                            color = MagicCyan,
                                            strokeWidth = 2.dp,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text(
                                            text = "⏳ Đang đồng bộ danh sách đơn chờ duyệt...",
                                            color = MagicCyanLight,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                } else {
                                    Text(text = "Không tìm thấy giao dịch nào phù hợp bộ lọc.", color = TextMuted, fontSize = 12.sp)
                                }
                            }
                        }
                    } else {
                        items(
                            items = visibleIntents,
                            key = { intent ->
                                "intent_${intent.intentId.ifBlank { "${LicenseManager.normalizeDeviceIdForMatch(intent.deviceId)}_${intent.timestamp?.toDate()?.time ?: intent.hashCode()}" }}"
                            },
                            contentType = { "intent_card" }
                        ) { intent ->
                                        val isPaidAction = intent.actionType == "CLICKED_I_PAID"
                                        val normIntentDevId = LicenseManager.normalizeDeviceIdForMatch(intent.deviceId)
                                        val matchedDev = if (normIntentDevId.isNotBlank()) deviceByNormDevId[normIntentDevId] else null
                                        val cleanIntentEmail = intent.ownerEmail.trim().lowercase().substringBefore(" (").trim()
                                        val matchedUsr = (if (normIntentDevId.isNotBlank()) userByNormDevId[normIntentDevId] else null)
                                            ?: (if (cleanIntentEmail.contains("@")) userByEmail[cleanIntentEmail] else null)

                                        val isDevPro = matchedDev != null && matchedDev.isPro && !matchedDev.revokedByAdmin
                                        val isUsrPro = matchedUsr != null && matchedUsr.isPro && !matchedUsr.revokedByAdmin
                                        val isCurrentlyPro = isDevPro || isUsrPro

                                        val isCurrentlyAccountPro = isCurrentlyPro && (
                                            (matchedDev?.isAccountPro == true || matchedDev?.proTier == "ACCOUNT_PRO") ||
                                            (matchedUsr?.isAccountPro == true || matchedUsr?.proTier == "ACCOUNT_PRO")
                                        )
                                        val isCurrentlyDevicePro = isCurrentlyPro && !isCurrentlyAccountPro
                                        val isCurrentlyFree = !isCurrentlyPro

                                        val combinedIntentText = "${intent.actionType} ${intent.details} ${intent.note}".lowercase()
                                        // CHỈ coi là đơn nâng cấp Pro TK khi thiết bị HIỆN TẠI THỰC SỰ ĐÃ CÓ PRO THIẾT BỊ
                                        val isUpgradeFromDeviceProOrder = isCurrentlyDevicePro && (
                                            combinedIntentText.contains("pro máy lên pro tài khoản") ||
                                            combinedIntentText.contains("pro thiết bị lên pro") ||
                                            combinedIntentText.contains("pro_to_account") ||
                                            combinedIntentText.contains("nang_cap_pro_tk") ||
                                            combinedIntentText.contains("nâng cấp pro máy") ||
                                            combinedIntentText.contains("pro máy -> pro tk") ||
                                            combinedIntentText.contains("package=2") ||
                                            combinedIntentText.contains("package = 2")
                                        )

                                        Card(
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(10.dp),
                                            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                                            border = BorderStroke(
                                                1.2.dp,
                                                if (isCurrentlyAccountPro) MagicCyan else if (isCurrentlyDevicePro) MagicAmber else if (isPaidAction) MagicEmerald else MagicAmber.copy(alpha = 0.6f)
                                            )
                                        ) {
                                            Column(
                                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                                verticalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = "📱 ${intent.deviceId}",
                                                        color = Color.White,
                                                        fontWeight = FontWeight.Black,
                                                        fontSize = 12.5.sp
                                                    )
                                                    Box(
                                                        modifier = Modifier
                                                            .clip(RoundedCornerShape(4.dp))
                                                            .background(
                                                                when (intent.actionType) {
                                                                    "CLICKED_I_PAID" -> MagicEmerald.copy(alpha = 0.25f)
                                                                    "OPENED_VIET_QR" -> MagicCyan.copy(alpha = 0.25f)
                                                                    else -> MagicAmber.copy(alpha = 0.25f)
                                                                }
                                                            )
                                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                                    ) {
                                                        Text(
                                                            text = when (intent.actionType) {
                                                                "CLICKED_I_PAID" -> "🔥 ĐÃ BÁO CHUYỂN KHOẢN"
                                                                "OPENED_VIET_QR" -> "👁️ ĐANG XEM MÃ QR"
                                                                "OPENED_PRO_UPGRADE_DIALOG" -> "⚡ MỞ HỘP THOẠI PRO"
                                                                else -> "📌 ${intent.actionType}"
                                                            },
                                                            color = when (intent.actionType) {
                                                                "CLICKED_I_PAID" -> MagicEmeraldLight
                                                                "OPENED_VIET_QR" -> MagicCyanLight
                                                                else -> MagicAmber
                                                            },
                                                            fontSize = 9.5.sp,
                                                            fontWeight = FontWeight.Black
                                                        )
                                                    }
                                                }

                                                // HIỂN THỊ CHÍNH XÁC TÌNH TRẠNG BẢN QUYỀN HIỆN TẠI CỦA THIẾT BỊ / KHÁCH
                                                if (isCurrentlyAccountPro) {
                                                    Box(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .clip(RoundedCornerShape(6.dp))
                                                            .background(MagicCyan.copy(alpha = 0.16f))
                                                            .border(1.dp, MagicCyan.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                                            .padding(horizontal = 8.dp, vertical = 5.dp)
                                                    ) {
                                                        Text(
                                                            text = "👑 HIỆN TẠI: ĐÃ LÀ PRO TÀI KHOẢN (Vĩnh Viễn)",
                                                            color = MagicCyanLight,
                                                            fontSize = 10.5.sp,
                                                            fontWeight = FontWeight.Black
                                                        )
                                                    }
                                                } else if (isCurrentlyDevicePro) {
                                                    Box(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .clip(RoundedCornerShape(6.dp))
                                                            .background(MagicAmber.copy(alpha = 0.16f))
                                                            .border(1.dp, MagicAmber.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                                            .padding(horizontal = 8.dp, vertical = 5.dp)
                                                    ) {
                                                        Text(
                                                            text = "📱 HIỆN TẠI: ĐÃ CÓ PRO THIẾT BỊ ➔ Khách đang yêu cầu nâng cấp lên 👑 Pro Tài Khoản",
                                                            color = MagicAmber,
                                                            fontSize = 10.5.sp,
                                                            fontWeight = FontWeight.Black
                                                        )
                                                    }
                                                } else {
                                                    Box(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .clip(RoundedCornerShape(6.dp))
                                                            .background(MagicEmerald.copy(alpha = 0.16f))
                                                            .border(1.dp, MagicEmerald.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                                            .padding(horizontal = 8.dp, vertical = 5.dp)
                                                    ) {
                                                        Text(
                                                            text = "🆓 HIỆN TẠI: MÁY MIỄN PHÍ (Chưa có Pro) ➔ Khách đăng ký gói Pro mới",
                                                            color = MagicEmeraldLight,
                                                            fontSize = 10.5.sp,
                                                            fontWeight = FontWeight.Black
                                                        )
                                                    }
                                                }

                                                val blockedLogAlert = (if (normIntentDevId.isNotBlank()) aiBlockedAlertByNormDevId[normIntentDevId] else null)
                                                    ?: (if (cleanIntentEmail.contains("@")) aiBlockedAlertByEmail[cleanIntentEmail] else null)
                                                if (blockedLogAlert != null) {
                                                    Box(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .clip(RoundedCornerShape(6.dp))
                                                            .background(MagicRose.copy(alpha = 0.16f))
                                                            .border(1.dp, MagicRose.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                                    ) {
                                                        Text(
                                                            text = "🚨 CẢNH BÁO AI: Từng bị chặn [${blockedLogAlert.eventType}] ${if (blockedLogAlert.forensicVerdict.isNotBlank()) "• ${blockedLogAlert.forensicVerdict.take(90)}" else ""}",
                                                            color = MagicRoseLight,
                                                            fontSize = 9.5.sp,
                                                            fontWeight = FontWeight.Bold
                                                        )
                                                    }
                                                }

                                                Text(
                                                    text = "🕒 Thời gian: ${intent.getTimestampFormatted()}",
                                                    color = MagicCyanLight,
                                                    fontSize = 10.5.sp,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                                Text(
                                                    text = "👤 Khách: ${intent.ownerEmail.ifBlank { "Khách vãng lai" }} • Máy: ${intent.model}",
                                                    color = TextSecondary,
                                                    fontSize = 11.sp
                                                )
                                                if (intent.deviceId.isNotBlank()) {
                                                    val previewKey = if (isUpgradeFromDeviceProOrder) LicenseManager.generateAccountProLicenseKeyForDevice(intent.deviceId)
                                                    else LicenseManager.generateLicenseKeyForDevice(intent.deviceId)
                                                    Text(
                                                        text = "🔑 Key dự phòng đề xuất: $previewKey",
                                                        color = MagicCyanLight,
                                                        fontSize = 9.5.sp,
                                                        fontWeight = FontWeight.SemiBold
                                                    )
                                                }
                                                if (intent.details.isNotBlank()) {
                                                    Text(
                                                        text = "📝 Chi tiết: ${intent.details}",
                                                        color = TextMuted,
                                                        fontSize = 10.sp
                                                    )
                                                }

                                                Row(
                                                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    if (!isUpgradeFromDeviceProOrder) {
                                                        TextButton(
                                                            onClick = {
                                                                genDeviceIdInput = intent.deviceId
                                                                val key = LicenseManager.generateLicenseKeyForDevice(intent.deviceId)
                                                                generatedKeyOutput = key
                                                                LicenseManager.registerAdminGeneratedKeyToCloud(intent.deviceId, key, isAccountPro = false, context = context, ownerEmailHint = intent.ownerEmail)
                                                                LicenseManager.deletePaymentIntentsForDevice(intent.deviceId, context)
                                                                saveApprovedIntent(intent.copy(isPro = true, note = "[PRO MÁY] Key: $key"))
                                                                val normTargetId = LicenseManager.normalizeDeviceIdForMatch(intent.deviceId)
                                                                val nowTs = com.google.firebase.Timestamp.now()
                                                                AdminSessionCache.updateSnapshot(context) { cur ->
                                                                    var foundInDevs = false
                                                                    val nextDevs = cur.devices.map { d ->
                                                                        if (LicenseManager.normalizeDeviceIdForMatch(d.deviceId) == normTargetId) {
                                                                            foundInDevs = true
                                                                            d.copy(
                                                                                isPro = true,
                                                                                isAccountPro = false,
                                                                                proTier = "DEVICE_PRO",
                                                                                revokedByAdmin = false,
                                                                                licenseKey = key,
                                                                                proActivatedAt = nowTs
                                                                            )
                                                                        } else d
                                                                    }.let { mapped ->
                                                                        if (!foundInDevs && intent.deviceId.isNotBlank()) {
                                                                            mapped + DeviceRecord(
                                                                                deviceId = intent.deviceId,
                                                                                ownerEmail = intent.ownerEmail,
                                                                                model = intent.model.ifBlank { "Thiết bị tạo key" },
                                                                                isPro = true,
                                                                                isAccountPro = false,
                                                                                proTier = "DEVICE_PRO",
                                                                                licenseKey = key,
                                                                                proActivatedAt = nowTs,
                                                                                createdAt = nowTs,
                                                                                lastActive = nowTs
                                                                            )
                                                                        } else mapped
                                                                    }
                                                                    cur.copy(
                                                                        paymentIntents = cur.paymentIntents.filter { it.deviceId != intent.deviceId && LicenseManager.normalizeDeviceIdForMatch(it.deviceId) != normTargetId },
                                                                        devices = nextDevs,
                                                                        users = cur.users.map { u ->
                                                                            if ((normTargetId.isNotBlank() && LicenseManager.normalizeDeviceIdForMatch(u.deviceId) == normTargetId) ||
                                                                                (intent.ownerEmail.isNotBlank() && u.email.trim().equals(intent.ownerEmail.trim(), ignoreCase = true))) {
                                                                                u.copy(isPro = true, isAccountPro = false, proTier = "DEVICE_PRO", revokedByAdmin = false)
                                                                            } else u
                                                                        }
                                                                    )
                                                                }
                                                                refreshAllAdminMetricsViaRest(showToastOnDone = false, force = true)
                                                                activeProReceipt = ProGrantReceiptData(
                                                                    targetDeviceId = intent.deviceId,
                                                                    targetEmail = intent.ownerEmail,
                                                                    isAccountPro = false,
                                                                    generatedKey = key,
                                                                    reasonNote = "Tạo Key & Duyệt từ Tab Chờ Duyệt",
                                                                    cloudSyncMessage = "Đã ghi nhận Key Pro Máy lên Cloud & lưu đơn đã duyệt!"
                                                                )
                                                            },
                                                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
                                                        ) {
                                                            Icon(imageVector = Icons.Default.Key, contentDescription = null, tint = MagicCyan, modifier = Modifier.size(14.dp))
                                                            Spacer(modifier = Modifier.width(3.dp))
                                                            Text("Tạo Key", color = MagicCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                        }

                                                        Button(
                                                            onClick = {
                                                                LicenseManager.adminGrantTierForUserOrDevice(
                                                                    userId = "",
                                                                    deviceId = intent.deviceId,
                                                                    ownerEmail = intent.ownerEmail,
                                                                    grantAccountPro = false,
                                                                    context = context,
                                                                    noteOrReason = "ADMIN_PENDING_TAB_APPROVED_DEVICE_PRO"
                                                                ) { ok, msg ->
                                                                    if (ok) {
                                                                        val normTargetId = LicenseManager.normalizeDeviceIdForMatch(intent.deviceId)
                                                                        val key = LicenseManager.generateLicenseKeyForDevice(intent.deviceId)
                                                                        val nowTs = com.google.firebase.Timestamp.now()
                                                                        saveApprovedIntent(intent.copy(isPro = true, note = "[PRO MÁY] Key: $key"))
                                                                        AdminSessionCache.updateSnapshot(context) { cur ->
                                                                            var foundInDevs = false
                                                                            val nextDevs = cur.devices.map { d ->
                                                                                if (LicenseManager.normalizeDeviceIdForMatch(d.deviceId) == normTargetId) {
                                                                                    foundInDevs = true
                                                                                    d.copy(
                                                                                        isPro = true,
                                                                                        isAccountPro = false,
                                                                                        proTier = "DEVICE_PRO",
                                                                                        revokedByAdmin = false,
                                                                                        licenseKey = key,
                                                                                        proActivatedAt = nowTs
                                                                                    )
                                                                                } else d
                                                                            }.let { mapped ->
                                                                                if (!foundInDevs && intent.deviceId.isNotBlank()) {
                                                                                    mapped + DeviceRecord(
                                                                                        deviceId = intent.deviceId,
                                                                                        ownerEmail = intent.ownerEmail,
                                                                                        model = intent.model.ifBlank { "Thiết bị duyệt bill" },
                                                                                        isPro = true,
                                                                                        isAccountPro = false,
                                                                                        proTier = "DEVICE_PRO",
                                                                                        licenseKey = key,
                                                                                        proActivatedAt = nowTs,
                                                                                        createdAt = nowTs,
                                                                                        lastActive = nowTs
                                                                                    )
                                                                                } else mapped
                                                                            }
                                                                            cur.copy(
                                                                                paymentIntents = cur.paymentIntents.filter { it.deviceId != intent.deviceId && LicenseManager.normalizeDeviceIdForMatch(it.deviceId) != normTargetId },
                                                                                devices = nextDevs,
                                                                                users = cur.users.map { u ->
                                                                                    if ((normTargetId.isNotBlank() && LicenseManager.normalizeDeviceIdForMatch(u.deviceId) == normTargetId) ||
                                                                                        (intent.ownerEmail.isNotBlank() && u.email.trim().equals(intent.ownerEmail.trim(), ignoreCase = true))) {
                                                                                        u.copy(isPro = true, isAccountPro = false, proTier = "DEVICE_PRO", revokedByAdmin = false)
                                                                                    } else u
                                                                                }
                                                                            )
                                                                        }
                                                                        refreshAllAdminMetricsViaRest(showToastOnDone = false, force = true)
                                                                        activeProReceipt = ProGrantReceiptData(
                                                                            targetDeviceId = intent.deviceId,
                                                                            targetEmail = intent.ownerEmail,
                                                                            isAccountPro = false,
                                                                            generatedKey = key,
                                                                            reasonNote = "Duyệt thủ công từ Tab Chờ Duyệt",
                                                                            cloudSyncMessage = msg
                                                                        )
                                                                    }
                                                                    Toast.makeText(context, if (ok) "📱 $msg" else "❌ $msg", Toast.LENGTH_LONG).show()
                                                                }
                                                            },
                                                            colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald),
                                                            modifier = Modifier.weight(1f).defaultMinSize(minHeight = 36.dp),
                                                            shape = RoundedCornerShape(8.dp),
                                                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)
                                                        ) {
                                                            Text("📱 Duyệt Pro Máy", color = Color(0xFF020617), fontWeight = FontWeight.Black, fontSize = 10.sp)
                                                        }
                                                    }

                                                    Button(
                                                        onClick = {
                                                            LicenseManager.adminGrantTierForUserOrDevice(
                                                                userId = "",
                                                                deviceId = intent.deviceId,
                                                                ownerEmail = intent.ownerEmail,
                                                                grantAccountPro = true,
                                                                context = context,
                                                                noteOrReason = if (isUpgradeFromDeviceProOrder) "ADMIN_UPGRADE_PRO_DEVICE_TO_ACCOUNT" else "ADMIN_PENDING_TAB_APPROVED_ACCOUNT_PRO"
                                                            ) { ok, msg ->
                                                                if (ok) {
                                                                    val normTargetId = LicenseManager.normalizeDeviceIdForMatch(intent.deviceId)
                                                                    val accKey = if (intent.deviceId.isNotBlank()) LicenseManager.generateAccountProLicenseKeyForDevice(intent.deviceId)
                                                                    else LicenseManager.generateAccountProKeyForEmail(intent.ownerEmail)
                                                                    val nowTs = com.google.firebase.Timestamp.now()
                                                                    saveApprovedIntent(intent.copy(isPro = true, note = "[PRO TK] Key: $accKey"))
                                                                    AdminSessionCache.updateSnapshot(context) { cur ->
                                                                        var foundInDevs = false
                                                                        val nextDevs = cur.devices.map { d ->
                                                                            if (LicenseManager.normalizeDeviceIdForMatch(d.deviceId) == normTargetId) {
                                                                                foundInDevs = true
                                                                                d.copy(
                                                                                    isPro = true,
                                                                                    isAccountPro = true,
                                                                                    proTier = "ACCOUNT_PRO",
                                                                                    revokedByAdmin = false,
                                                                                    licenseKey = accKey,
                                                                                    proActivatedAt = nowTs
                                                                                )
                                                                            } else d
                                                                        }.let { mapped ->
                                                                            if (!foundInDevs && intent.deviceId.isNotBlank()) {
                                                                                mapped + DeviceRecord(
                                                                                    deviceId = intent.deviceId,
                                                                                    ownerEmail = intent.ownerEmail,
                                                                                    model = intent.model.ifBlank { "Thiết bị duyệt bill TK" },
                                                                                    isPro = true,
                                                                                    isAccountPro = true,
                                                                                    proTier = "ACCOUNT_PRO",
                                                                                    licenseKey = accKey,
                                                                                    proActivatedAt = nowTs,
                                                                                    createdAt = nowTs,
                                                                                    lastActive = nowTs
                                                                                )
                                                                            } else mapped
                                                                        }
                                                                        var foundInUsers = false
                                                                        val nextUsers = cur.users.map { u ->
                                                                            if ((normTargetId.isNotBlank() && LicenseManager.normalizeDeviceIdForMatch(u.deviceId) == normTargetId) ||
                                                                                (intent.ownerEmail.isNotBlank() && u.email.trim().equals(intent.ownerEmail.trim(), ignoreCase = true))) {
                                                                                foundInUsers = true
                                                                                u.copy(
                                                                                    isPro = true,
                                                                                    isAccountPro = true,
                                                                                    proTier = "ACCOUNT_PRO",
                                                                                    revokedByAdmin = false
                                                                                )
                                                                            } else u
                                                                        }.let { mapped ->
                                                                            if (!foundInUsers && intent.ownerEmail.isNotBlank()) {
                                                                                mapped + UserProfile(
                                                                                    userId = "manual_${System.currentTimeMillis()}",
                                                                                    email = intent.ownerEmail,
                                                                                    displayName = intent.ownerEmail.substringBefore("@"),
                                                                                    deviceId = intent.deviceId,
                                                                                    isPro = true,
                                                                                    isAccountPro = true,
                                                                                    proTier = "ACCOUNT_PRO",
                                                                                    createdAt = nowTs,
                                                                                    lastActive = nowTs
                                                                                )
                                                                            } else mapped
                                                                        }
                                                                        cur.copy(
                                                                            paymentIntents = cur.paymentIntents.filter { it.deviceId != intent.deviceId && LicenseManager.normalizeDeviceIdForMatch(it.deviceId) != normTargetId },
                                                                            devices = nextDevs,
                                                                            users = nextUsers
                                                                        )
                                                                    }
                                                                    refreshAllAdminMetricsViaRest(showToastOnDone = false, force = true)
                                                                    activeProReceipt = ProGrantReceiptData(
                                                                        targetDeviceId = intent.deviceId,
                                                                        targetEmail = intent.ownerEmail,
                                                                        isAccountPro = true,
                                                                        generatedKey = accKey,
                                                                        reasonNote = if (isUpgradeFromDeviceProOrder) "Nâng cấp Pro Máy -> Pro Tài Khoản" else "Duyệt thủ công từ Tab Chờ Duyệt",
                                                                        cloudSyncMessage = msg
                                                                    )
                                                                }
                                                                Toast.makeText(context, if (ok) "👑 $msg" else "❌ $msg", Toast.LENGTH_LONG).show()
                                                            }
                                                        },
                                                        colors = ButtonDefaults.buttonColors(containerColor = MagicAmber),
                                                        modifier = Modifier.weight(1f).defaultMinSize(minHeight = 36.dp),
                                                        shape = RoundedCornerShape(8.dp),
                                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)
                                                    ) {
                                                        Text(
                                                            text = if (isUpgradeFromDeviceProOrder) "👑 Duyệt Nâng Cấp Pro TK" else "👑 Duyệt Pro TK",
                                                            color = Color(0xFF020617),
                                                            fontWeight = FontWeight.Black,
                                                            fontSize = if (isUpgradeFromDeviceProOrder) 11.sp else 10.sp
                                                        )
                                                    }

                                                    IconButton(
                                                        onClick = {
                                                            LicenseManager.deletePaymentIntentsForDevice(intent.deviceId, context)
                                                            val normTargetId = LicenseManager.normalizeDeviceIdForMatch(intent.deviceId)
                                                            AdminSessionCache.updateSnapshot(context) { cur ->
                                                                cur.copy(
                                                                    paymentIntents = cur.paymentIntents.filter { it.deviceId != intent.deviceId && LicenseManager.normalizeDeviceIdForMatch(it.deviceId) != normTargetId }
                                                                )
                                                            }
                                                            refreshAllAdminMetricsViaRest(showToastOnDone = false, force = true)
                                                            Toast.makeText(context, "🗑️ Đã xóa đơn chờ duyệt của ${intent.deviceId}", Toast.LENGTH_SHORT).show()
                                                        },
                                                        modifier = Modifier.size(36.dp)
                                                    ) {
                                                        Icon(imageVector = Icons.Default.DeleteOutline, contentDescription = "Xóa đơn", tint = MagicRoseLight, modifier = Modifier.size(18.dp))
                                                    }
                                                }
                                            }
                                        }
                                    }
                        if (filteredIntents.size > intentVisibleLimit) {
                            item(key = "tab2_load_more", contentType = "load_more") {
                                OutlinedButton(
                                    onClick = { intentVisibleLimit += 20 },
                                    modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 36.dp),
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, MagicAmber.copy(alpha = 0.6f))
                                ) {
                                    Text(
                                        text = "⬇️ Xem thêm đơn chờ duyệt (${filteredIntents.size - intentVisibleLimit} đơn còn lại)",
                                        color = MagicAmber,
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                4 -> {
                    // TAB 4: YÊU CẦU KHÔI PHỤC PRO TỪ THIẾT BỊ (LazyColumn items - 120fps)
                    val pendingRecCount = tab4State.pendingRecCount
                    val resolvedRecCount = tab4State.resolvedRecCount
                    val filteredRecoveries = tab4State.filteredRecoveries

                    item(key = "tab4_controls", contentType = "tab_controls") {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                                border = BorderStroke(1.dp, MagicAmber.copy(alpha = 0.6f))
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = "🔄 QUẢN LÝ YÊU CẦU KHÔI PHỤC QUYỀN PRO",
                                        color = MagicAmber,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Text(
                                        text = "Danh sách thiết bị gửi cảnh báo mất quyền Pro (do cài lại máy / đổi thiết bị). Admin có thể đối soát và bấm 1 chạm 'Cấp lại Pro ngay' để hệ thống tự động kích hoạt lại vĩnh viễn cho thiết bị đó từ xa.",
                                        color = Color(0xFF94A3B8),
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            // Thanh tìm kiếm và bộ lọc nhanh cho Tab 4 Khôi Phục Pro
                            OutlinedTextField(
                                value = recoverySearchQuery,
                                onValueChange = { recoverySearchQuery = it },
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text("Tìm theo Device ID, email, dòng máy, ghi chú...", fontSize = 11.sp) },
                                singleLine = true,
                                shape = RoundedCornerShape(8.dp),
                                leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = MagicAmber, modifier = Modifier.size(18.dp)) },
                                trailingIcon = {
                                    if (recoverySearchQuery.isNotBlank()) {
                                        IconButton(onClick = { recoverySearchQuery = "" }) {
                                            Icon(imageVector = Icons.Default.Clear, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            )

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                val recTabs = listOf(
                                    "Tất cả" to "Tất cả (${proRecoveryRequestsList.size})",
                                    "⏳ CHỜ XỬ LÝ" to "Chờ xử lý ($pendingRecCount)",
                                    "✅ ĐÃ CẤP LẠI" to "Đã cấp lại ($resolvedRecCount)"
                                )
                                recTabs.forEach { (tabKey, tabLabel) ->
                                    val isSelected = recoveryFilterTab == tabKey
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = { recoveryFilterTab = tabKey },
                                        label = { Text(tabLabel, fontSize = 10.5.sp, fontWeight = FontWeight.Bold) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = if (tabKey.contains("CHỜ")) MagicAmber.copy(alpha = 0.35f) else MagicEmerald.copy(alpha = 0.35f),
                                            selectedLabelColor = if (tabKey.contains("CHỜ")) MagicAmber else MagicEmeraldLight,
                                            containerColor = MagicSurfaceDark,
                                            labelColor = TextSecondary
                                        )
                                    )
                                }
                            }
                        }
                    }

                    if (filteredRecoveries.isEmpty()) {
                        item(key = "tab4_empty", contentType = "empty_state") {
                            Box(
                                modifier = Modifier.fillMaxWidth().padding(32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("Không tìm thấy yêu cầu khôi phục nào phù hợp.", color = TextMuted, fontSize = 12.sp)
                            }
                        }
                    } else {
                        items(
                            items = visibleRecoveries,
                            key = { req -> "rec_${req.id.ifBlank { "${req.deviceId}_${req.createdAt}_${req.hashCode()}" }}" },
                            contentType = { "recovery_card" }
                        ) { req ->
                                    val isPending = req.status == "PENDING"
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
                                        border = BorderStroke(1.dp, if (isPending) MagicAmber else MagicEmerald)
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(14.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = "📱 ${req.deviceId}",
                                                    color = Color.White,
                                                    fontSize = 12.5.sp,
                                                    fontWeight = FontWeight.Black
                                                )
                                                Box(
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(6.dp))
                                                        .background(if (isPending) MagicAmber.copy(alpha = 0.25f) else MagicEmerald.copy(alpha = 0.25f))
                                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                                ) {
                                                    Text(
                                                        text = if (isPending) "⏳ CHỜ XỬ LÝ" else "✅ ĐÃ CẤP LẠI",
                                                        color = if (isPending) MagicAmber else MagicEmerald,
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            }

                                            Text(text = "Thiết bị: ${req.deviceModel}", color = TextSecondary, fontSize = 11.sp)
                                            Text(text = "Người dùng: ${req.ownerName} (${req.ownerEmail})", color = TextSecondary, fontSize = 11.sp)
                                            Text(text = "Nội dung: ${req.note}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Medium)

                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(6.dp))
                                                        .background(MagicEmerald.copy(alpha = 0.2f))
                                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                                ) {
                                                    Text(text = "🛡️ ĐÃ XÁC THỰC LỊCH SỬ PRO", color = MagicEmerald, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }

                                            if (isPending) {
                                                val normTargetId = LicenseManager.normalizeDeviceIdForMatch(req.deviceId)
                                                val matchedDevRec = if (normTargetId.isNotBlank()) deviceByNormDevId[normTargetId] else null
                                                val cleanRecEmail = req.ownerEmail.trim().lowercase().substringBefore(" (").trim()
                                                val matchedUsrRec = (if (normTargetId.isNotBlank()) userByNormDevId[normTargetId] else null)
                                                    ?: (if (cleanRecEmail.contains("@")) userByEmail[cleanRecEmail] else null)
                                                val isAccProHint = (matchedDevRec?.isAccountPro == true || matchedDevRec?.proTier == "ACCOUNT_PRO") ||
                                                    (matchedUsrRec?.isAccountPro == true || matchedUsrRec?.proTier == "ACCOUNT_PRO") ||
                                                    req.note.contains("Tài Khoản", ignoreCase = true) ||
                                                    req.note.contains("ACCOUNT_PRO", ignoreCase = true) ||
                                                    req.note.contains("TKPRO", ignoreCase = true) ||
                                                    req.note.contains("TKPR", ignoreCase = true)

                                                val recActionKey = req.id.ifBlank { normTargetId.ifBlank { req.deviceId } }
                                                val isProcessingThisRec = autoProcessedDeviceIds.contains("BUSY_REC_$recActionKey")

                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    Button(
                                                        enabled = !isProcessingThisRec,
                                                        onClick = {
                                                            val busyTag = "BUSY_REC_$recActionKey"
                                                            if (autoProcessedDeviceIds.contains(busyTag)) return@Button
                                                            autoProcessedDeviceIds.add(busyTag)
                                                            Toast.makeText(context, "⏳ Đang cấp lại quyền Pro cho ${req.deviceId}...", Toast.LENGTH_SHORT).show()
                                                            LicenseManager.adminRestoreProForDevice(
                                                                deviceId = req.deviceId,
                                                                context = context,
                                                                requestDocId = req.id,
                                                                ownerEmail = req.ownerEmail,
                                                                isAccountProHint = isAccProHint
                                                            ) { success ->
                                                                autoProcessedDeviceIds.remove(busyTag)
                                                                if (success) {
                                                                    val resolvedTier = if (isAccProHint) "ACCOUNT_PRO" else "DEVICE_PRO"
                                                                    val nowTs = com.google.firebase.Timestamp.now()
                                                                    AdminSessionCache.updateSnapshot(context) { cur ->
                                                                        var foundInDevs = false
                                                                        val nextDevs = cur.devices.map { d ->
                                                                            if (normTargetId.isNotBlank() && LicenseManager.normalizeDeviceIdForMatch(d.deviceId) == normTargetId) {
                                                                                foundInDevs = true
                                                                                d.copy(
                                                                                    isPro = true,
                                                                                    isAccountPro = isAccProHint,
                                                                                    proTier = resolvedTier,
                                                                                    revokedByAdmin = false,
                                                                                    proActivatedAt = nowTs
                                                                                )
                                                                            } else d
                                                                        }.let { mapped ->
                                                                            if (!foundInDevs && req.deviceId.isNotBlank()) {
                                                                                mapped + DeviceRecord(
                                                                                    deviceId = req.deviceId,
                                                                                    ownerEmail = req.ownerEmail,
                                                                                    model = req.deviceModel.ifBlank { "Thiết bị khôi phục Pro" },
                                                                                    isPro = true,
                                                                                    isAccountPro = isAccProHint,
                                                                                    proTier = resolvedTier,
                                                                                    proActivatedAt = nowTs,
                                                                                    createdAt = nowTs,
                                                                                    lastActive = nowTs
                                                                                )
                                                                            } else mapped
                                                                        }
                                                                        cur.copy(
                                                                            proRecoveries = cur.proRecoveries.map {
                                                                                if (it.id == req.id || (normTargetId.isNotBlank() && LicenseManager.normalizeDeviceIdForMatch(it.deviceId) == normTargetId)) {
                                                                                    it.copy(status = "RESTORED")
                                                                                } else it
                                                                            },
                                                                            devices = nextDevs,
                                                                            users = cur.users.map { u ->
                                                                                if ((normTargetId.isNotBlank() && LicenseManager.normalizeDeviceIdForMatch(u.deviceId) == normTargetId) ||
                                                                                    (cleanRecEmail.contains("@") && u.email.trim().equals(cleanRecEmail, ignoreCase = true))) {
                                                                                    u.copy(isPro = true, isAccountPro = isAccProHint, proTier = resolvedTier, revokedByAdmin = false)
                                                                                } else u
                                                                            }
                                                                        )
                                                                    }
                                                                    refreshAllAdminMetricsViaRest(showToastOnDone = false, force = true)
                                                                    val restoredKey = if (isAccProHint) LicenseManager.generateAccountProLicenseKeyForDevice(req.deviceId)
                                                                    else LicenseManager.generateLicenseKeyForDevice(req.deviceId)
                                                                    activeProReceipt = ProGrantReceiptData(
                                                                        targetDeviceId = req.deviceId,
                                                                        targetEmail = req.ownerEmail,
                                                                        isAccountPro = isAccProHint,
                                                                        generatedKey = restoredKey,
                                                                        reasonNote = "Khôi phục Pro từ xa",
                                                                        cloudSyncMessage = "Đã cấp lại quyền Pro vĩnh viễn cho máy ${req.deviceId}!"
                                                                    )
                                                                    Toast.makeText(context, "✅ Đã cấp lại quyền Pro vĩnh viễn cho thiết bị ${req.deviceId} từ xa thành công!", Toast.LENGTH_LONG).show()
                                                                } else {
                                                                    Toast.makeText(context, "❌ Không thể cấp lại Pro lúc này, vui lòng kiểm tra mạng và thử lại!", Toast.LENGTH_LONG).show()
                                                                }
                                                            }
                                                        },
                                                        colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald),
                                                        shape = RoundedCornerShape(8.dp),
                                                        modifier = Modifier.weight(1.2f)
                                                    ) {
                                                        if (isProcessingThisRec) {
                                                            CircularProgressIndicator(
                                                                color = Color(0xFF020617),
                                                                strokeWidth = 2.dp,
                                                                modifier = Modifier.size(14.dp)
                                                            )
                                                            Spacer(modifier = Modifier.width(6.dp))
                                                            Text("Đang cấp...", color = Color(0xFF020617), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                        } else {
                                                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF020617), modifier = Modifier.size(15.dp))
                                                            Spacer(modifier = Modifier.width(4.dp))
                                                            Text("⚡ Cấp Lại Pro", color = Color(0xFF020617), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                        }
                                                    }

                                                    OutlinedButton(
                                                        enabled = !isProcessingThisRec,
                                                        onClick = {
                                                            val busyTag = "BUSY_REC_$recActionKey"
                                                            autoProcessedDeviceIds.add(busyTag)
                                                            LicenseManager.adminDeleteRecoveryRequest(context, req.id, req.deviceId) { ok ->
                                                                autoProcessedDeviceIds.remove(busyTag)
                                                                if (ok) {
                                                                    AdminSessionCache.updateSnapshot(context) { cur ->
                                                                        cur.copy(
                                                                            proRecoveries = cur.proRecoveries.filter {
                                                                                it.id != req.id && (normTargetId.isBlank() || LicenseManager.normalizeDeviceIdForMatch(it.deviceId) != normTargetId)
                                                                            }
                                                                        )
                                                                    }
                                                                    refreshAllAdminMetricsViaRest(showToastOnDone = false, force = true)
                                                                    Toast.makeText(context, "🗑️ Đã từ chối/xóa yêu cầu khôi phục", Toast.LENGTH_SHORT).show()
                                                                } else {
                                                                    Toast.makeText(context, "❌ Lỗi khi xóa yêu cầu khôi phục!", Toast.LENGTH_SHORT).show()
                                                                }
                                                            }
                                                        },
                                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MagicRose),
                                                        border = BorderStroke(1.dp, MagicRose.copy(alpha = 0.6f)),
                                                        shape = RoundedCornerShape(8.dp),
                                                        modifier = Modifier.weight(0.8f)
                                                    ) {
                                                        Icon(imageVector = Icons.Default.Delete, contentDescription = null, tint = MagicRose, modifier = Modifier.size(14.dp))
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text("Từ Chối", color = MagicRose, fontSize = 11.sp)
                                                    }
                                                }
                                            } else {
                                                val normTargetId = LicenseManager.normalizeDeviceIdForMatch(req.deviceId)
                                                Row(
                                                    modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                                                    horizontalArrangement = Arrangement.End
                                                ) {
                                                    OutlinedButton(
                                                        onClick = {
                                                            LicenseManager.adminDeleteRecoveryRequest(context, req.id, req.deviceId) { ok ->
                                                                if (ok) {
                                                                    AdminSessionCache.updateSnapshot(context) { cur ->
                                                                        cur.copy(
                                                                            proRecoveries = cur.proRecoveries.filter {
                                                                                it.id != req.id && (normTargetId.isBlank() || LicenseManager.normalizeDeviceIdForMatch(it.deviceId) != normTargetId)
                                                                            }
                                                                        )
                                                                    }
                                                                    refreshAllAdminMetricsViaRest(showToastOnDone = false, force = true)
                                                                    Toast.makeText(context, "Đã xóa bản ghi lưu trữ", Toast.LENGTH_SHORT).show()
                                                                } else {
                                                                    Toast.makeText(context, "Lỗi khi xóa bản ghi!", Toast.LENGTH_SHORT).show()
                                                                }
                                                            }
                                                        },
                                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Gray),
                                                        border = BorderStroke(1.dp, Color.Gray.copy(alpha = 0.4f)),
                                                        shape = RoundedCornerShape(8.dp)
                                                    ) {
                                                        Icon(imageVector = Icons.Default.Delete, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(14.dp))
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text("Xóa bản ghi", color = Color.Gray, fontSize = 11.sp)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                        if (filteredRecoveries.size > recoveryVisibleLimit) {
                            item(key = "tab4_load_more", contentType = "load_more") {
                                OutlinedButton(
                                    onClick = { recoveryVisibleLimit += 20 },
                                    modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 36.dp),
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, MagicAmber.copy(alpha = 0.6f))
                                ) {
                                    Text(
                                        text = "⬇️ Xem thêm yêu cầu khôi phục (${filteredRecoveries.size - recoveryVisibleLimit} yêu cầu còn lại)",
                                        color = MagicAmber,
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
                5 -> {
                    // TAB 5: TRANG LƯU TRỮ LỊCH SỬ TRÒ CHUYỆN CẤP PRO CỦA AI (LazyColumn items - 120fps)
                    val grantedCount = tab5State.grantedCount
                    val blockedCount = tab5State.blockedCount
                    val inquiryCount = tab5State.inquiryCount
                    val filteredAiLogs = tab5State.filteredAiLogs

                    item(key = "tab5_controls", contentType = "tab_controls") {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                                border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.6f))
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = "📜 LỊCH SỬ TRÒ CHUYỆN CẤP PRO CỦA AI (HẬU KIỂM ADMIN)",
                                        color = MagicCyanLight,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Text(
                                        text = "Ghi lại toàn bộ các cuộc trò chuyện liên quan đến xét duyệt bill, cấp Pro, khôi phục máy quen thuộc và chặn yêu cầu xin Pro khi chưa thanh toán giữa người dùng và AI. Admin có thể xem lại từng tình huống và Cấp Pro hoặc Thu Hồi Pro ngay bằng 1 chạm.",
                                        color = TextSecondary,
                                        fontSize = 11.sp,
                                        lineHeight = 15.sp
                                    )

                                    // Thanh tìm kiếm lịch sử chat AI
                                    OutlinedTextField(
                                        value = aiLogSearchQuery,
                                        onValueChange = { aiLogSearchQuery = it },
                                        placeholder = { Text("Tìm theo Device ID, Email, nội dung chat...", fontSize = 11.sp, color = TextMuted) },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = MagicCyan,
                                            unfocusedBorderColor = MagicBorder,
                                            focusedTextColor = Color.White,
                                            unfocusedTextColor = Color.White
                                        )
                                    )

                                    // Bộ lọc nhanh theo tình huống
                                    val filterOptions = listOf(
                                        "Tất cả" to "Tất cả (${aiProChatLogsList.size})",
                                        "✅ Đã Cấp Pro" to "✅ Đã Cấp ($grantedCount)",
                                        "🛡️ Chặn Chưa TT" to "🛡️ Đã Chặn ($blockedCount)",
                                        "💬 Hỏi Đáp" to "💬 Hỏi Đáp ($inquiryCount)"
                                    )
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .horizontalScroll(rememberScrollState()),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        filterOptions.forEach { (key, label) ->
                                            val isSel = aiLogFilterTab == key
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(if (isSel) MagicCyan.copy(alpha = 0.25f) else MagicSurfaceCard)
                                                    .border(1.dp, if (isSel) MagicCyan else MagicBorder, RoundedCornerShape(8.dp))
                                                    .clickable { aiLogFilterTab = key }
                                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                                            ) {
                                                Text(
                                                    text = label,
                                                    color = if (isSel) MagicCyanLight else TextSecondary,
                                                    fontSize = 10.5.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (filteredAiLogs.isEmpty()) {
                        item(key = "tab5_empty", contentType = "empty_state") {
                            Box(
                                modifier = Modifier.fillMaxWidth().padding(32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "Chưa có bản ghi trò chuyện cấp Pro nào khớp bộ lọc.",
                                    color = TextMuted,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    } else {
                        items(
                            items = visibleAiLogs,
                            key = { log -> "ailog_${log.id.ifBlank { "${log.deviceId}_${log.timestampMs}_${log.hashCode()}" }}" },
                            contentType = { "ai_log_card" }
                        ) { log ->
                                    val badgeText = when {
                                        log.proGranted && log.eventType == "CLOUD_FAMILIAR_RESTORED" -> "🔄 ĐÃ KHÔI PHỤC MÁY QUEN (${log.grantedTier})"
                                        log.proGranted -> "✅ ĐÃ CẤP PRO (${log.grantedTier})"
                                        log.eventType == "FAKE_BILL_DETECTED" -> "🚨 PHÁT HIỆN BILL GIẢ / CHỈNH SỬA"
                                        log.eventType == "REUSED_BILL_BLOCKED" -> "⛔ CHẶN BILL / MÃ GD TRÙNG LẶP"
                                        log.eventType == "BILL_REJECTED" -> "🚫 TỪ CHỐI BILL KHÔNG HỢP LỆ"
                                        log.eventType == "UNPAID_PRO_REQUEST_BLOCKED" -> "🛡️ ĐÃ CHẶN (CHƯA THANH TOÁN)"
                                        else -> "💬 HỎI ĐÁP / TƯ VẤN PRO"
                                    }
                                    val badgeColor = when {
                                        log.proGranted -> MagicEmerald
                                        log.eventType == "FAKE_BILL_DETECTED" ||
                                            log.eventType == "REUSED_BILL_BLOCKED" ||
                                            log.eventType == "BILL_REJECTED" ||
                                            log.eventType == "UNPAID_PRO_REQUEST_BLOCKED" -> MagicRoseLight
                                        else -> MagicAmber
                                    }

                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
                                        border = BorderStroke(1.dp, badgeColor.copy(alpha = 0.6f))
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(14.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = "📱 ${log.deviceId} (${log.deviceModel})",
                                                        color = Color.White,
                                                        fontSize = 12.sp,
                                                        fontWeight = FontWeight.Black
                                                    )
                                                    Text(
                                                        text = "👤 ${log.ownerName} • ${log.ownerEmail} • 🕒 ${log.getFormattedTime()}",
                                                        color = TextSecondary,
                                                        fontSize = 10.sp
                                                    )
                                                }
                                                Box(
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(6.dp))
                                                        .background(badgeColor.copy(alpha = 0.2f))
                                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                                ) {
                                                    Text(
                                                        text = badgeText,
                                                        color = badgeColor,
                                                        fontSize = 9.5.sp,
                                                        fontWeight = FontWeight.Black
                                                    )
                                                }
                                            }

                                            // Nội dung khách nhắn
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(MagicSurfaceDark)
                                                    .border(0.5.dp, MagicBorder, RoundedCornerShape(8.dp))
                                                    .padding(10.dp)
                                            ) {
                                                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                                    Text(
                                                        text = "👤 Người dùng nhắn:",
                                                        color = MagicCyanLight,
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                    Text(
                                                        text = log.userMessage,
                                                        color = Color.White,
                                                        fontSize = 11.5.sp,
                                                        lineHeight = 16.sp
                                                    )
                                                }
                                            }

                                            // Nội dung AI trả lời & Kết quả giám định Bill
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(Color(0xFF0F172A))
                                                    .border(0.5.dp, badgeColor.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                                                    .padding(10.dp)
                                            ) {
                                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                    Text(
                                                        text = "🤖 Phản hồi & quyết định của AI:",
                                                        color = badgeColor,
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                    Text(
                                                        text = log.aiReply,
                                                        color = Color(0xFFE2E8F0),
                                                        fontSize = 11.sp,
                                                        lineHeight = 15.5.sp
                                                    )
                                                    if (log.forensicVerdict.isNotBlank()) {
                                                        Text(
                                                            text = "🔍 Giám định Bill 5 Lớp: ${log.forensicVerdict}",
                                                            color = if (log.proGranted) MagicCyanLight else MagicAmber,
                                                            fontSize = 10.sp,
                                                            fontWeight = FontWeight.SemiBold
                                                        )
                                                    }
                                                    if (log.bankTransCode.isNotBlank() || log.billImageHash.isNotBlank()) {
                                                        Text(
                                                            text = "🏦 Mã GD: ${log.bankTransCode.ifBlank { "Không có" }} • SHA-256: ${log.billImageHash.take(14).ifBlank { "N/A" }}...",
                                                            color = TextSecondary,
                                                            fontSize = 9.5.sp
                                                        )
                                                    }
                                                    if (log.generatedKey.isNotBlank()) {
                                                        Text(
                                                            text = "🔑 Key đã cấp: ${log.generatedKey}",
                                                            color = MagicEmerald,
                                                            fontSize = 10.5.sp,
                                                            fontWeight = FontWeight.Bold
                                                        )
                                                    }
                                                }
                                            }

                                            // Hàng nút can thiệp 1 chạm cho Admin (Cấp Pro Máy / Cấp Pro TK / Thu hồi Pro / Xóa bản ghi)
                                            val normLogDevId = LicenseManager.normalizeDeviceIdForMatch(log.deviceId)
                                            val logMatchedDev = if (normLogDevId.isNotBlank()) deviceByNormDevId[normLogDevId] else null
                                            val logCleanEmail = log.ownerEmail.trim().lowercase().substringBefore(" (").trim()
                                            val logMatchedUsr = (if (normLogDevId.isNotBlank()) userByNormDevId[normLogDevId] else null)
                                                ?: (if (logCleanEmail.contains("@")) userByEmail[logCleanEmail] else null)
                                            val logAlreadyHasDevicePro = (logMatchedDev != null && logMatchedDev.isPro && !logMatchedDev.revokedByAdmin &&
                                                !logMatchedDev.isAccountPro && logMatchedDev.proTier != "ACCOUNT_PRO") ||
                                                (logMatchedUsr != null && logMatchedUsr.isPro && !logMatchedUsr.revokedByAdmin &&
                                                    !logMatchedUsr.isAccountPro && logMatchedUsr.proTier != "ACCOUNT_PRO")
                                            val logTextLower = "${log.userMessage} ${log.aiReply} ${log.forensicVerdict}".lowercase()
                                            val isLogUpgradeOrder = logAlreadyHasDevicePro ||
                                                logTextLower.contains("nâng cấp từ pro máy") ||
                                                logTextLower.contains("pro máy lên pro tài khoản") ||
                                                logTextLower.contains("pro thiết bị lên pro tài khoản")

                                            Row(
                                                modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                if (!isLogUpgradeOrder) {
                                                    Button(
                                                        onClick = {
                                                            coroutineScope.launch {
                                                                try {
                                                                    val grantRes = withContext(Dispatchers.IO) {
                                                                        LicenseManager.executeVerifiedProGrant(
                                                                            context = context,
                                                                            rawTargetDeviceId = log.deviceId,
                                                                            grantAccountPro = false,
                                                                            reason = "ADMIN_AUDIT_LOG_GRANT_DEVICE_PRO"
                                                                        )
                                                                    }
                                                                    refreshAllAdminMetricsViaRest(showToastOnDone = false)
                                                                    activeProReceipt = ProGrantReceiptData(
                                                                        targetDeviceId = grantRes.targetDeviceId,
                                                                        targetEmail = log.ownerEmail,
                                                                        isAccountPro = false,
                                                                        generatedKey = grantRes.generatedKey,
                                                                        reasonNote = "Cấp từ Lịch sử AI Audit",
                                                                        bankTransCode = log.bankTransCode,
                                                                        cloudSyncMessage = grantRes.summaryMessage
                                                                    )
                                                                    Toast.makeText(context, "⚡ Đã cấp Pro Thiết Bị cho ${log.deviceId}!", Toast.LENGTH_SHORT).show()
                                                                } catch (e: Exception) {
                                                                    Toast.makeText(context, "Lỗi khi cấp Pro: ${e.localizedMessage ?: e.message}", Toast.LENGTH_LONG).show()
                                                                }
                                                            }
                                                        },
                                                        colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald),
                                                        shape = RoundedCornerShape(6.dp),
                                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                                        modifier = Modifier.weight(1f).defaultMinSize(minHeight = 36.dp)
                                                    ) {
                                                        Text("⚡ Cấp Pro Máy", color = Color(0xFF020617), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                    }
                                                }

                                                Button(
                                                    onClick = {
                                                        coroutineScope.launch {
                                                            try {
                                                                val grantRes = withContext(Dispatchers.IO) {
                                                                    LicenseManager.executeVerifiedProGrant(
                                                                        context = context,
                                                                        rawTargetDeviceId = log.deviceId,
                                                                        grantAccountPro = true,
                                                                        reason = "ADMIN_AUDIT_LOG_GRANT_ACCOUNT_PRO"
                                                                    )
                                                                }
                                                                refreshAllAdminMetricsViaRest(showToastOnDone = false)
                                                                activeProReceipt = ProGrantReceiptData(
                                                                    targetDeviceId = grantRes.targetDeviceId,
                                                                    targetEmail = log.ownerEmail,
                                                                    isAccountPro = true,
                                                                    generatedKey = grantRes.generatedKey,
                                                                    reasonNote = "Cấp Pro TK từ Lịch sử AI Audit",
                                                                    bankTransCode = log.bankTransCode,
                                                                    cloudSyncMessage = grantRes.summaryMessage
                                                                )
                                                                Toast.makeText(context, "👑 Đã cấp Pro Tài Khoản cho ${log.deviceId}!", Toast.LENGTH_SHORT).show()
                                                            } catch (e: Exception) {
                                                                Toast.makeText(context, "Lỗi khi cấp Pro TK: ${e.localizedMessage ?: e.message}", Toast.LENGTH_LONG).show()
                                                            }
                                                        }
                                                    },
                                                    colors = ButtonDefaults.buttonColors(containerColor = MagicAmber),
                                                    shape = RoundedCornerShape(6.dp),
                                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                                    modifier = Modifier.weight(1f).defaultMinSize(minHeight = 36.dp)
                                                ) {
                                                    Text("👑 Cấp Pro TK", color = Color(0xFF020617), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                }

                                                Button(
                                                    onClick = {
                                                        coroutineScope.launch {
                                                            try {
                                                                FirebaseAuthManager.toggleDeviceProStatus(
                                                                    deviceId = log.deviceId,
                                                                    isPro = false,
                                                                    context = context,
                                                                    ownerEmail = log.ownerEmail
                                                                )
                                                                Toast.makeText(context, "🚫 Đã THU HỒI quyền Pro của thiết bị ${log.deviceId}!", Toast.LENGTH_LONG).show()
                                                            } catch (e: Exception) {
                                                                Toast.makeText(context, "Lỗi thu hồi: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                                            }
                                                        }
                                                    },
                                                    colors = ButtonDefaults.buttonColors(containerColor = MagicRose),
                                                    shape = RoundedCornerShape(6.dp),
                                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                                    modifier = Modifier.weight(1f).defaultMinSize(minHeight = 36.dp)
                                                ) {
                                                    Text("🚫 Thu Hồi Pro", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                }

                                                IconButton(
                                                    onClick = {
                                                        LicenseManager.deleteAiProChatLog(
                                                            logId = log.id,
                                                            context = context,
                                                            deviceId = log.deviceId,
                                                            timestampMs = log.timestampMs
                                                        )
                                                        AdminSessionCache.updateSnapshot(context) { cur ->
                                                            cur.copy(
                                                                aiLogs = cur.aiLogs.filterNot {
                                                                    it.id == log.id || (log.deviceId.isNotBlank() && log.timestampMs > 0L && it.deviceId == log.deviceId && it.timestampMs == log.timestampMs)
                                                                }
                                                            )
                                                        }
                                                        Toast.makeText(context, "🗑️ Đã xóa vĩnh viễn bản ghi chat AI.", Toast.LENGTH_SHORT).show()
                                                    },
                                                    modifier = Modifier.size(34.dp)
                                                ) {
                                                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Xóa bản ghi", tint = TextMuted, modifier = Modifier.size(18.dp))
                                                }
                                            }
                                        }
                                    }
                                }
                        if (filteredAiLogs.size > aiLogVisibleLimit) {
                            item(key = "tab5_load_more", contentType = "load_more") {
                                OutlinedButton(
                                    onClick = { aiLogVisibleLimit += 20 },
                                    modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 36.dp),
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.6f))
                                ) {
                                    Text(
                                        text = "⬇️ Xem thêm nhật ký AI (${filteredAiLogs.size - aiLogVisibleLimit} bản ghi còn lại)",
                                        color = MagicCyanLight,
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
                6 -> {
                    // TAB 6: QUẢN LÝ KHO APP & DUYỆT ĐÓNG GÓP (LazyColumn items - 120fps)
                    val pendingAppsCount = tab6State.pendingCount
                    val approvedAppsCount = tab6State.approvedCount
                    val rejectedAppsCount = tab6State.rejectedCount
                    val filteredStoreApps = tab6State.filteredStoreApps

                    item(key = "tab6_controls", contentType = "tab_controls") {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                                border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.6f))
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = "📦 QUẢN LÝ KHO ỨNG DỤNG & DUYỆT ĐÓNG GÓP",
                                        color = MagicCyanLight,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Text(
                                        text = "Nơi Admin xét duyệt các ứng dụng do cộng đồng người dùng đóng góp. Ứng dụng chỉ xuất hiện trong Kho App công khai sau khi được Admin bấm Duyệt.",
                                        color = TextSecondary,
                                        fontSize = 11.sp,
                                        lineHeight = 15.sp
                                    )
                                    
                                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text("⌛ Chờ duyệt: $pendingAppsCount", color = MagicAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        Text("✅ Đã duyệt: $approvedAppsCount", color = MagicEmerald, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        Text("❌ Từ chối: $rejectedAppsCount", color = MagicRoseLight, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            // Thanh tìm kiếm và bộ lọc trạng thái cho Tab 6 Kho Ứng Dụng
                            OutlinedTextField(
                                value = storeAppSearchQuery,
                                onValueChange = { storeAppSearchQuery = it },
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text("Tìm theo tên ứng dụng, tác giả, mô tả...", fontSize = 11.sp) },
                                singleLine = true,
                                shape = RoundedCornerShape(8.dp),
                                leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = MagicCyan, modifier = Modifier.size(18.dp)) },
                                trailingIcon = {
                                    if (storeAppSearchQuery.isNotBlank()) {
                                        IconButton(onClick = { storeAppSearchQuery = "" }) {
                                            Icon(imageVector = Icons.Default.Clear, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            )

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                val storeTabs = listOf(
                                    "Tất cả" to "Tất cả (${allStoreApps.size})",
                                    "⏳ CHỜ DUYỆT" to "Chờ duyệt ($pendingAppsCount)",
                                    "✅ ĐÃ DUYỆT" to "Đã duyệt ($approvedAppsCount)",
                                    "❌ TỪ CHỐI" to "Từ chối ($rejectedAppsCount)"
                                )
                                storeTabs.forEach { (tabKey, tabLabel) ->
                                    val isSelected = storeAppFilterTab == tabKey
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = { storeAppFilterTab = tabKey },
                                        label = { Text(tabLabel, fontSize = 10.5.sp, fontWeight = FontWeight.Bold) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = when {
                                                tabKey.contains("CHỜ") -> MagicAmber.copy(alpha = 0.35f)
                                                tabKey.contains("DUYỆT") -> MagicEmerald.copy(alpha = 0.35f)
                                                tabKey.contains("TỪ CHỐI") -> MagicRose.copy(alpha = 0.35f)
                                                else -> MagicCyan.copy(alpha = 0.35f)
                                            },
                                            selectedLabelColor = when {
                                                tabKey.contains("CHỜ") -> MagicAmber
                                                tabKey.contains("DUYỆT") -> MagicEmeraldLight
                                                tabKey.contains("TỪ CHỐI") -> MagicRoseLight
                                                else -> MagicCyanLight
                                            },
                                            containerColor = MagicSurfaceDark,
                                            labelColor = TextSecondary
                                        )
                                    )
                                }
                            }
                        }
                    }

                    if (filteredStoreApps.isEmpty()) {
                        item(key = "tab6_empty", contentType = "empty_state") {
                            Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                Text("Không tìm thấy ứng dụng nào phù hợp bộ lọc.", color = TextMuted)
                            }
                        }
                    } else {
                        items(
                            items = visibleStoreApps,
                            key = { app -> "store_${app.id.ifBlank { "${app.name}_${app.hashCode()}" }}" },
                            contentType = { "admin_store_card" }
                        ) { app ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
                                        border = BorderStroke(1.dp, when(app.status) {
                                            "PENDING" -> MagicAmber.copy(alpha = 0.5f)
                                            "APPROVED" -> MagicEmerald.copy(alpha = 0.3f)
                                            else -> MagicRose.copy(alpha = 0.3f)
                                        })
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(text = app.name, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Black)
                                                    Text(text = "Đóng góp bởi: ${app.contributorEmail.ifBlank { app.author }}", color = TextSecondary, fontSize = 10.sp)
                                                }
                                                Box(
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(6.dp))
                                                        .background(when(app.status) {
                                                            "PENDING" -> MagicAmber.copy(alpha = 0.2f)
                                                            "APPROVED" -> MagicEmerald.copy(alpha = 0.2f)
                                                            else -> MagicRose.copy(alpha = 0.2f)
                                                        })
                                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                                ) {
                                                    Text(
                                                        text = when(app.status) {
                                                            "PENDING" -> "CHỜ DUYỆT"
                                                            "APPROVED" -> "ĐÃ DUYỆT"
                                                            else -> "TỪ CHỐI"
                                                        },
                                                        color = when(app.status) {
                                                            "PENDING" -> MagicAmber
                                                            "APPROVED" -> MagicEmerald
                                                            else -> MagicRoseLight
                                                        },
                                                        fontSize = 9.sp,
                                                        fontWeight = FontWeight.Black
                                                    )
                                                }
                                            }
                                            
                                            Text(text = app.description, color = TextSecondary, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                            
                                            Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                if (app.status == "PENDING") {
                                                    Button(
                                                        onClick = {
                                                            coroutineScope.launch {
                                                                try {
                                                                    FirebaseAuthManager.updateHonorAppStatus(app.id, "APPROVED")
                                                                    AdminSessionCache.updateSnapshot(context) { cur ->
                                                                        cur.copy(storeApps = cur.storeApps.map { if (it.id == app.id) it.copy(status = "APPROVED") else it })
                                                                    }
                                                                    Toast.makeText(context, "✅ Đã duyệt app thành công!", Toast.LENGTH_SHORT).show()
                                                                } catch (e: Exception) {
                                                                    Toast.makeText(context, "Lỗi: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                                                }
                                                            }
                                                        },
                                                        colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald),
                                                        modifier = Modifier.weight(1f).defaultMinSize(minHeight = 36.dp),
                                                        contentPadding = PaddingValues(0.dp)
                                                    ) {
                                                        Text("Duyệt App", fontSize = 10.sp, color = Color(0xFF020617), fontWeight = FontWeight.Bold)
                                                    }
                                                    
                                                    Button(
                                                        onClick = {
                                                            coroutineScope.launch {
                                                                try {
                                                                    FirebaseAuthManager.updateHonorAppStatus(app.id, "REJECTED")
                                                                    AdminSessionCache.updateSnapshot(context) { cur ->
                                                                        cur.copy(storeApps = cur.storeApps.map { if (it.id == app.id) it.copy(status = "REJECTED") else it })
                                                                    }
                                                                    Toast.makeText(context, "❌ Đã từ chối app.", Toast.LENGTH_SHORT).show()
                                                                } catch (e: Exception) {
                                                                    Toast.makeText(context, "Lỗi: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                                                }
                                                            }
                                                        },
                                                        colors = ButtonDefaults.buttonColors(containerColor = MagicRose),
                                                        modifier = Modifier.weight(1f).defaultMinSize(minHeight = 36.dp),
                                                        contentPadding = PaddingValues(0.dp)
                                                    ) {
                                                        Text("Từ Chối", fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                                    }
                                                } else if (app.status == "APPROVED") {
                                                    Button(
                                                        onClick = {
                                                            coroutineScope.launch {
                                                                try {
                                                                    FirebaseAuthManager.updateHonorAppStatus(app.id, "REJECTED")
                                                                    AdminSessionCache.updateSnapshot(context) { cur ->
                                                                        cur.copy(storeApps = cur.storeApps.map { if (it.id == app.id) it.copy(status = "REJECTED") else it })
                                                                    }
                                                                    Toast.makeText(context, "🚫 Đã thu hồi (từ chối) app.", Toast.LENGTH_SHORT).show()
                                                                } catch (e: Exception) {
                                                                    Toast.makeText(context, "Lỗi: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                                                }
                                                            }
                                                        },
                                                        colors = ButtonDefaults.buttonColors(containerColor = MagicRose),
                                                        modifier = Modifier.weight(1f).defaultMinSize(minHeight = 36.dp),
                                                        contentPadding = PaddingValues(0.dp)
                                                    ) {
                                                        Text("Thu Hồi App", fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                                
                                                IconButton(
                                                    onClick = {
                                                        coroutineScope.launch {
                                                            try {
                                                                FirebaseAuthManager.deleteHonorApp(app.id)
                                                                AdminSessionCache.updateSnapshot(context) { cur ->
                                                                    cur.copy(storeApps = cur.storeApps.filter { it.id != app.id })
                                                                }
                                                                Toast.makeText(context, "🗑️ Đã xóa app khỏi kho.", Toast.LENGTH_SHORT).show()
                                                            } catch (e: Exception) {
                                                                Toast.makeText(context, "Lỗi: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                                            }
                                                        }
                                                    },
                                                    modifier = Modifier.size(32.dp)
                                                ) {
                                                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Xóa", tint = TextMuted, modifier = Modifier.size(16.dp))
                                                }
                                            }
                                        }
                                    }
                                }
                        if (filteredStoreApps.size > storeAppVisibleLimit) {
                            item(key = "tab6_load_more", contentType = "load_more") {
                                OutlinedButton(
                                    onClick = { storeAppVisibleLimit += 20 },
                                    modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 36.dp),
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.6f))
                                ) {
                                    Text(
                                        text = "⬇️ Xem thêm ứng dụng (${filteredStoreApps.size - storeAppVisibleLimit} app còn lại)",
                                        color = MagicCyanLight,
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }



    // Dialog XÁC NHẬN DỌN DẸP TIẾT KIỆM CHI PHÍ (Chạy dưới nền, chỉ xóa dữ liệu MagicTune ngày cũ, giữ lại hôm nay)
    if (showCleanupOldDataDialog) {
        AlertDialog(
            onDismissRequest = { showCleanupOldDataDialog = false },
            containerColor = MagicSurfaceDark,
            shape = RoundedCornerShape(16.dp),
            title = {
                Text(
                    text = "⚠️ XÁC NHẬN DỌN DẸP TIẾT KIỆM CHI PHÍ:",
                    color = MagicAmber,
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp
                )
            },
            text = {
                ScrollableDialogColumn(thumbColor = MagicAmber, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (cleanupProgress.isRunning) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(MagicAmber.copy(alpha = 0.12f))
                                .border(1.dp, MagicAmber.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = MagicAmber,
                                strokeWidth = 2.dp
                            )
                            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(
                                    text = cleanupProgress.currentStage.ifBlank { "Đang dọn dữ liệu ngày cũ dưới nền..." },
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Đã xóa ${cleanupProgress.deletedDocs} / Đã quét ${cleanupProgress.scannedDocs} bản ghi MagicTune",
                                    color = MagicAmber,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    } else {
                        Text(
                            text = "Hệ thống sẽ quét và dọn sạch các bản ghi nhật ký và phiên QR cũ trước hôm nay của MagicTune để tối ưu hóa dung lượng Firestore và tiết kiệm chi phí vận hành.\n\nToàn bộ dữ liệu của ngày hôm nay và các cấu hình hệ thống sẽ được giữ nguyên an toàn.",
                            color = TextSecondary,
                            fontSize = 12.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            },
            confirmButton = {
                if (cleanupProgress.isRunning) {
                    Button(
                        onClick = { showCleanupOldDataDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = MagicCyan, contentColor = Color(0xFF020617)),
                        modifier = Modifier.testTag("hide_cleanup_to_background_button")
                    ) {
                        Text(
                            text = "Ẩn Xuống Nền",
                            fontWeight = FontWeight.Black,
                            fontSize = 12.sp
                        )
                    }
                } else {
                    Button(
                        onClick = {
                            showCleanupOldDataDialog = false
                            LicenseManager.cleanupOldLogsAndQrSessionsKeepToday(context)
                            Toast.makeText(
                                context,
                                "🧹 Đang dọn dữ liệu ngày cũ của MagicTune dưới nền — Bạn có thể tiếp tục làm việc khác!",
                                Toast.LENGTH_SHORT
                            ).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MagicAmber, contentColor = Color(0xFF020617)),
                        modifier = Modifier.testTag("confirm_cleanup_old_data_button")
                    ) {
                        Text(
                            text = "Tiếp Tục Dọn Sạch",
                            fontWeight = FontWeight.Black,
                            fontSize = 12.sp
                        )
                    }
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showCleanupOldDataDialog = false }
                ) {
                    Text(if (cleanupProgress.isRunning) "Đóng" else "Hủy", color = TextSecondary, fontSize = 12.sp)
                }
            }
        )
    }



    // Confirmation Dialog for Device Pro Toggle / Tier Selection
    targetDeviceForAction?.let { dev ->
        val isEffectivePro = dev.isPro && !dev.revokedByAdmin
        AlertDialog(
            onDismissRequest = { targetDeviceForAction = null },
            containerColor = MagicSurfaceDark,
            title = {
                Text(
                    text = if (isEffectivePro) "Quản lý / Gỡ quyền Pro thiết bị" else "Chọn gói Pro cấp cho thiết bị",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            },
            text = {
                ScrollableDialogColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "• Device ID: ${dev.deviceId}\n• Máy: ${dev.model}\n• Chủ sở hữu: ${dev.ownerEmail.ifBlank { "Khách vãng lai" }}",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                    Button(
                        onClick = {
                            LicenseManager.adminGrantTierForUserOrDevice(
                                userId = dev.ownerUid,
                                deviceId = dev.deviceId,
                                ownerEmail = dev.ownerEmail,
                                grantAccountPro = false,
                                context = context
                            ) { ok, msg ->
                                if (ok) {
                                    val normDevId = LicenseManager.normalizeDeviceIdForMatch(dev.deviceId)
                                    val devKey = LicenseManager.generateLicenseKeyForDevice(dev.deviceId)
                                    AdminSessionCache.updateSnapshot(context) { cur ->
                                        cur.copy(
                                            devices = cur.devices.map { d ->
                                                if (LicenseManager.normalizeDeviceIdForMatch(d.deviceId) == normDevId) {
                                                    d.copy(isPro = true, isAccountPro = false, proTier = "DEVICE_PRO", revokedByAdmin = false, licenseKey = devKey)
                                                } else d
                                            },
                                            users = cur.users.map { u ->
                                                if ((dev.ownerUid.isNotBlank() && u.userId == dev.ownerUid) ||
                                                    LicenseManager.normalizeDeviceIdForMatch(u.deviceId) == normDevId
                                                ) {
                                                    u.copy(isPro = true, isAccountPro = false, proTier = "DEVICE_PRO", revokedByAdmin = false)
                                                } else u
                                            }
                                        )
                                    }
                                    refreshAllAdminMetricsViaRest(showToastOnDone = false)
                                    activeProReceipt = ProGrantReceiptData(
                                        targetDeviceId = dev.deviceId,
                                        targetEmail = dev.ownerEmail,
                                        isAccountPro = false,
                                        generatedKey = devKey,
                                        reasonNote = "Cấp từ Quản lý Thiết Bị",
                                        cloudSyncMessage = msg
                                    )
                                }
                                Toast.makeText(context, if (ok) "📱 $msg" else "❌ $msg", Toast.LENGTH_LONG).show()
                                targetDeviceForAction = null
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("📱 Cấp Pro Thiết Bị (Gắn Theo Máy)", color = Color(0xFF020617), fontWeight = FontWeight.Black, fontSize = 11.5.sp)
                    }
                    Button(
                        onClick = {
                            LicenseManager.adminGrantTierForUserOrDevice(
                                userId = dev.ownerUid,
                                deviceId = dev.deviceId,
                                ownerEmail = dev.ownerEmail,
                                grantAccountPro = true,
                                context = context
                            ) { ok, msg ->
                                if (ok) {
                                    val normDevId = LicenseManager.normalizeDeviceIdForMatch(dev.deviceId)
                                    val accKey = LicenseManager.generateAccountProLicenseKeyForDevice(dev.deviceId)
                                    AdminSessionCache.updateSnapshot(context) { cur ->
                                        cur.copy(
                                            devices = cur.devices.map { d ->
                                                if (LicenseManager.normalizeDeviceIdForMatch(d.deviceId) == normDevId) {
                                                    d.copy(isPro = true, isAccountPro = true, proTier = "ACCOUNT_PRO", revokedByAdmin = false, licenseKey = accKey)
                                                } else d
                                            },
                                            users = cur.users.map { u ->
                                                if ((dev.ownerUid.isNotBlank() && u.userId == dev.ownerUid) ||
                                                    LicenseManager.normalizeDeviceIdForMatch(u.deviceId) == normDevId
                                                ) {
                                                    u.copy(isPro = true, isAccountPro = true, proTier = "ACCOUNT_PRO", revokedByAdmin = false)
                                                } else u
                                            }
                                        )
                                    }
                                    refreshAllAdminMetricsViaRest(showToastOnDone = false)
                                    activeProReceipt = ProGrantReceiptData(
                                        targetDeviceId = dev.deviceId,
                                        targetEmail = dev.ownerEmail,
                                        isAccountPro = true,
                                        generatedKey = accKey,
                                        reasonNote = "Nâng cấp từ Quản lý Thiết Bị",
                                        cloudSyncMessage = msg
                                    )
                                }
                                Toast.makeText(context, if (ok) "👑 $msg" else "❌ $msg", Toast.LENGTH_LONG).show()
                                targetDeviceForAction = null
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MagicAmber),
                        modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 40.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        Text("👑 Cấp / Nâng Lên Pro Tài Khoản", color = Color(0xFF020617), fontWeight = FontWeight.Black, fontSize = 11.5.sp, textAlign = TextAlign.Center)
                    }
                    if (isEffectivePro) {
                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    try {
                                        LicenseManager.adminRevokeProCompletely(
                                            context = context,
                                            userId = dev.ownerUid,
                                            deviceId = dev.deviceId,
                                            ownerEmail = dev.ownerEmail
                                        )
                                        val normDevId = LicenseManager.normalizeDeviceIdForMatch(dev.deviceId)
                                        AdminSessionCache.updateSnapshot(context) { cur ->
                                            cur.copy(
                                                devices = cur.devices.map { d ->
                                                    if (LicenseManager.normalizeDeviceIdForMatch(d.deviceId) == normDevId) {
                                                        d.copy(isPro = false, isAccountPro = false, proTier = "FREE", revokedByAdmin = true, licenseKey = "")
                                                    } else d
                                                },
                                                users = cur.users.map { u ->
                                                    if ((dev.ownerUid.isNotBlank() && u.userId == dev.ownerUid) ||
                                                        LicenseManager.normalizeDeviceIdForMatch(u.deviceId) == normDevId
                                                    ) {
                                                        u.copy(isPro = false, isAccountPro = false, proTier = "FREE", revokedByAdmin = true)
                                                    } else u
                                                }
                                            )
                                        }
                                        refreshAllAdminMetricsViaRest(showToastOnDone = false)
                                        Toast.makeText(context, "🚫 Đã thu hồi quyền Pro của thiết bị ${dev.deviceId}!", Toast.LENGTH_SHORT).show()
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Lỗi: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                                    } finally {
                                        targetDeviceForAction = null
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MagicRose),
                            modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 40.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            Text("🚫 Thu Hồi (Gỡ) Quyền Pro", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.5.sp, textAlign = TextAlign.Center)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { targetDeviceForAction = null }) {
                    Text("Đóng", color = TextSecondary, fontSize = 12.sp)
                }
            }
        )
    }

    // Confirmation Dialog for User Account
    targetUserForAction?.let { u ->
        if (pendingActionType != null) {
            val isProAction = pendingActionType == "pro"
            AlertDialog(
                onDismissRequest = { targetUserForAction = null; pendingActionType = null },
                containerColor = MagicSurfaceDark,
                title = {
                    Text(
                        text = if (isProAction) "Quản lý gói Pro cho Tài khoản" else "Xác nhận nâng cấp lên Admin",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                },
                text = {
                    ScrollableDialogColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (isProAction) {
                            Text(
                                text = "• Tên: ${u.displayName}\n• Email: ${u.email.ifBlank { "Không có" }}\n• Device ID: ${u.deviceId.ifBlank { "Không rõ" }}",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                            Button(
                                onClick = {
                                    val targetDevId = u.activeDeviceId.ifBlank { u.deviceId }
                                    LicenseManager.adminGrantTierForUserOrDevice(
                                        userId = u.userId,
                                        deviceId = targetDevId,
                                        ownerEmail = u.email,
                                        grantAccountPro = false,
                                        context = context
                                    ) { ok, msg ->
                                        if (ok) {
                                            val normTargetDevId = LicenseManager.normalizeDeviceIdForMatch(targetDevId)
                                            AdminSessionCache.updateSnapshot(context) { cur ->
                                                cur.copy(
                                                    users = cur.users.map { usr ->
                                                        if (usr.userId == u.userId || (u.email.isNotBlank() && usr.email.equals(u.email, ignoreCase = true))) {
                                                            usr.copy(isPro = true, isAccountPro = false, proTier = "DEVICE_PRO", revokedByAdmin = false)
                                                        } else usr
                                                    },
                                                    devices = cur.devices.map { d ->
                                                        if ((normTargetDevId.isNotBlank() && LicenseManager.normalizeDeviceIdForMatch(d.deviceId) == normTargetDevId) ||
                                                            (u.email.isNotBlank() && d.ownerEmail.equals(u.email, ignoreCase = true))
                                                        ) {
                                                            d.copy(isPro = true, isAccountPro = false, proTier = "DEVICE_PRO", revokedByAdmin = false)
                                                        } else d
                                                    }
                                                )
                                            }
                                            refreshAllAdminMetricsViaRest(showToastOnDone = false)
                                            val devKey = if (targetDevId.isNotBlank()) LicenseManager.generateLicenseKeyForDevice(targetDevId) else ""
                                            activeProReceipt = ProGrantReceiptData(
                                                targetDeviceId = targetDevId,
                                                targetEmail = u.email,
                                                isAccountPro = false,
                                                generatedKey = devKey,
                                                reasonNote = "Cấp từ Quản lý Tài Khoản",
                                                cloudSyncMessage = msg
                                            )
                                        }
                                        Toast.makeText(context, if (ok) "📱 $msg" else "❌ $msg", Toast.LENGTH_LONG).show()
                                        targetUserForAction = null
                                        pendingActionType = null
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald),
                                modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 40.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Text("📱 Cấp Pro Thiết Bị", color = Color(0xFF020617), fontWeight = FontWeight.Black, fontSize = 11.5.sp, textAlign = TextAlign.Center)
                            }
                            Button(
                                onClick = {
                                    val targetDevId = u.activeDeviceId.ifBlank { u.deviceId }
                                    LicenseManager.adminGrantTierForUserOrDevice(
                                        userId = u.userId,
                                        deviceId = targetDevId,
                                        ownerEmail = u.email,
                                        grantAccountPro = true,
                                        context = context
                                    ) { ok, msg ->
                                        if (ok) {
                                            val normTargetDevId = LicenseManager.normalizeDeviceIdForMatch(targetDevId)
                                            AdminSessionCache.updateSnapshot(context) { cur ->
                                                cur.copy(
                                                    users = cur.users.map { usr ->
                                                        if (usr.userId == u.userId || (u.email.isNotBlank() && usr.email.equals(u.email, ignoreCase = true))) {
                                                            usr.copy(isPro = true, isAccountPro = true, proTier = "ACCOUNT_PRO", revokedByAdmin = false)
                                                        } else usr
                                                    },
                                                    devices = cur.devices.map { d ->
                                                        if ((normTargetDevId.isNotBlank() && LicenseManager.normalizeDeviceIdForMatch(d.deviceId) == normTargetDevId) ||
                                                            (u.email.isNotBlank() && d.ownerEmail.equals(u.email, ignoreCase = true))
                                                        ) {
                                                            d.copy(isPro = true, isAccountPro = true, proTier = "ACCOUNT_PRO", revokedByAdmin = false)
                                                        } else d
                                                    }
                                                )
                                            }
                                            refreshAllAdminMetricsViaRest(showToastOnDone = false)
                                            val accKey = if (targetDevId.isNotBlank()) LicenseManager.generateAccountProLicenseKeyForDevice(targetDevId)
                                            else LicenseManager.generateAccountProKeyForEmail(u.email)
                                            activeProReceipt = ProGrantReceiptData(
                                                targetDeviceId = targetDevId,
                                                targetEmail = u.email,
                                                isAccountPro = true,
                                                generatedKey = accKey,
                                                reasonNote = "Cấp Pro TK từ Quản lý Tài Khoản",
                                                cloudSyncMessage = msg
                                            )
                                        }
                                        Toast.makeText(context, if (ok) "👑 $msg" else "❌ $msg", Toast.LENGTH_LONG).show()
                                        targetUserForAction = null
                                        pendingActionType = null
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MagicAmber),
                                modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 40.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Text("👑 Cấp / Nâng Lên Pro Tài Khoản (Đổi Máy)", color = Color(0xFF020617), fontWeight = FontWeight.Black, fontSize = 11.5.sp, textAlign = TextAlign.Center)
                            }
                            if (u.isPro) {
                                Button(
                                    onClick = {
                                        coroutineScope.launch {
                                            try {
                                                LicenseManager.adminRevokeProCompletely(
                                                    context = context,
                                                    userId = u.userId,
                                                    deviceId = u.activeDeviceId.ifBlank { u.deviceId },
                                                    ownerEmail = u.email
                                                )
                                                AdminSessionCache.updateSnapshot(context) { cur ->
                                                    cur.copy(
                                                        users = cur.users.map { usr ->
                                                            if (usr.userId == u.userId || (u.email.isNotBlank() && usr.email.equals(u.email, ignoreCase = true))) {
                                                                usr.copy(isPro = false, isAccountPro = false, proTier = "FREE", revokedByAdmin = true)
                                                            } else usr
                                                        },
                                                        devices = cur.devices.map { d ->
                                                            if (u.email.isNotBlank() && d.ownerEmail.equals(u.email, ignoreCase = true)) {
                                                                d.copy(isPro = false, isAccountPro = false, proTier = "FREE", revokedByAdmin = true, licenseKey = "")
                                                            } else d
                                                        }
                                                    )
                                                }
                                                refreshAllAdminMetricsViaRest(showToastOnDone = false)
                                                Toast.makeText(context, "🚫 Đã gỡ trạng thái Pro của tài khoản & thiết bị!", Toast.LENGTH_SHORT).show()
                                            } catch (e: Exception) {
                                                Toast.makeText(context, "Lỗi: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                                            } finally {
                                                targetUserForAction = null
                                                pendingActionType = null
                                            }
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = MagicRose),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("🚫 Gỡ Quyền Pro Tài Khoản Này", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                                }
                            }
                        } else {
                            Text(
                                text = "Bạn có chắc chắn muốn nâng cấp tài khoản:\n• Tên: ${u.displayName}\n• Email: ${u.email.ifBlank { "Không có" }}\nlên quyền Quản trị viên (Admin)?",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }
                },
                confirmButton = {
                    if (!isProAction) {
                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    try {
                                        FirebaseAuthManager.upgradeUserToAdmin(u.userId)
                                        AdminSessionCache.updateSnapshot(context) { cur ->
                                            cur.copy(
                                                users = cur.users.map { usr ->
                                                    if (usr.userId == u.userId) usr.copy(role = "admin") else usr
                                                }
                                            )
                                        }
                                        Toast.makeText(context, "Đã nâng cấp ${u.displayName} lên Admin thành công!", Toast.LENGTH_SHORT).show()
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Lỗi: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                                    } finally {
                                        targetUserForAction = null
                                        pendingActionType = null
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MagicCyan)
                        ) {
                            Text("Xác Nhận Nâng Admin", color = Color(0xFF020617), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                },
                dismissButton = {
                    TextButton(onClick = { targetUserForAction = null; pendingActionType = null }) {
                        Text("Đóng", color = TextSecondary, fontSize = 12.sp)
                    }
                }
            )
        }
    }

    // HỘP THOẠI HẠ CẤP THIẾT BỊ: ADMIN ĐƯỢC CHỌN CẤP BẬC MUỐN HẠ VỀ
    downgradeTargetDevice?.let { dev ->
        val isAccountPro = dev.isAccountPro || dev.proTier == "ACCOUNT_PRO"
        AlertDialog(
            onDismissRequest = { downgradeTargetDevice = null },
            containerColor = MagicSurfaceDark,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.RemoveCircleOutline, null, tint = MagicRose, modifier = Modifier.size(22.dp))
                    Text("CHỌN CẤP BẬC HẠ CHO THIẾT BỊ", color = MagicRoseLight, fontWeight = FontWeight.Black, fontSize = 14.sp)
                }
            },
            text = {
                ScrollableDialogColumn(verticalArrangement = Arrangement.spacedBy(10.dp), thumbColor = MagicRose) {
                    Text(
                        text = "• Device ID: ${dev.deviceId}\n• Dòng máy: ${dev.model}\n• Cấp hiện tại: ${if (isAccountPro) "👑 PRO TÀI KHOẢN" else "📱 PRO THIẾT BỊ"}\n• Chủ máy: ${dev.ownerEmail.ifBlank { "Khách vãng lai" }}",
                        color = TextSecondary,
                        fontSize = 11.5.sp,
                        lineHeight = 16.sp
                    )
                    Text(
                        text = "Vui lòng chọn cấp bậc bạn muốn hạ về:",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )

                    // Lựa chọn 1: Nếu đang là Pro Tài Khoản -> Cho phép hạ về Pro Thiết Bị (Khóa 1 máy)
                    if (isAccountPro) {
                        Button(
                            onClick = {
                                LicenseManager.adminDowngradeToSpecificTier(
                                    context = context,
                                    userId = dev.ownerUid,
                                    deviceId = dev.deviceId,
                                    ownerEmail = dev.ownerEmail,
                                    targetTier = "DEVICE_PRO"
                                ) { ok, msg ->
                                    val normDevId = LicenseManager.normalizeDeviceIdForMatch(dev.deviceId)
                                    AdminSessionCache.updateSnapshot(context) { cur ->
                                        cur.copy(
                                            devices = cur.devices.map { d ->
                                                if (LicenseManager.normalizeDeviceIdForMatch(d.deviceId) == normDevId) {
                                                    d.copy(isPro = true, isAccountPro = false, proTier = "DEVICE_PRO", revokedByAdmin = false)
                                                } else d
                                            },
                                            users = cur.users.map { u ->
                                                if ((dev.ownerUid.isNotBlank() && u.userId == dev.ownerUid) ||
                                                    LicenseManager.normalizeDeviceIdForMatch(u.deviceId) == normDevId
                                                ) {
                                                    u.copy(isPro = true, isAccountPro = false, proTier = "DEVICE_PRO", revokedByAdmin = false)
                                                } else u
                                            }
                                        )
                                    }
                                    Toast.makeText(context, if (ok) msg else "⚠️ $msg", Toast.LENGTH_LONG).show()
                                    downgradeTargetDevice = null
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MagicCyan),
                            modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 36.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("📱 Hạ về Pro Thiết Bị (Khóa 1 máy)", color = Color(0xFF020617), fontWeight = FontWeight.Black, fontSize = 11.5.sp)
                        }
                    }

                    // Lựa chọn 2: Thu hồi hoàn toàn về Bản Miễn Phí (Free)
                    Button(
                        onClick = {
                            LicenseManager.adminDowngradeToSpecificTier(
                                context = context,
                                userId = dev.ownerUid,
                                deviceId = dev.deviceId,
                                ownerEmail = dev.ownerEmail,
                                targetTier = "FREE"
                            ) { ok, msg ->
                                val normDevId = LicenseManager.normalizeDeviceIdForMatch(dev.deviceId)
                                AdminSessionCache.updateSnapshot(context) { cur ->
                                    cur.copy(
                                        devices = cur.devices.map { d ->
                                            if (LicenseManager.normalizeDeviceIdForMatch(d.deviceId) == normDevId) {
                                                d.copy(isPro = false, isAccountPro = false, proTier = "FREE", revokedByAdmin = true, licenseKey = "")
                                            } else d
                                        },
                                        users = cur.users.map { u ->
                                            if ((dev.ownerUid.isNotBlank() && u.userId == dev.ownerUid) ||
                                                LicenseManager.normalizeDeviceIdForMatch(u.deviceId) == normDevId
                                            ) {
                                                u.copy(isPro = false, isAccountPro = false, proTier = "FREE", revokedByAdmin = true)
                                            } else u
                                        }
                                    )
                                }
                                Toast.makeText(context, if (ok) "🚫 Đã hạ về bản Miễn Phí (Free) & thu hồi Pro của máy ${dev.deviceId}!" else "⚠️ $msg", Toast.LENGTH_LONG).show()
                                downgradeTargetDevice = null
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MagicRose),
                        modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("🚫 Hạ về Bản Miễn Phí (Gỡ Pro hoàn toàn)", color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.5.sp)
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { downgradeTargetDevice = null }) {
                    Text("Hủy", color = TextSecondary, fontSize = 12.sp)
                }
            }
        )
    }

    // HỘP THOẠI HẠ CẤP TÀI KHOẢN: ADMIN ĐƯỢC CHỌN CẤP BẬC MUỐN HẠ VỀ
    downgradeTargetUser?.let { u ->
        val isAccountPro = u.isAccountPro || u.proTier == "ACCOUNT_PRO"
        AlertDialog(
            onDismissRequest = { downgradeTargetUser = null },
            containerColor = MagicSurfaceDark,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.RemoveCircleOutline, null, tint = MagicRose, modifier = Modifier.size(22.dp))
                    Text("CHỌN CẤP BẬC HẠ CHO TÀI KHOẢN", color = MagicRoseLight, fontWeight = FontWeight.Black, fontSize = 14.sp)
                }
            },
            text = {
                val devId = u.activeDeviceId.ifBlank { u.deviceId }
                ScrollableDialogColumn(verticalArrangement = Arrangement.spacedBy(10.dp), thumbColor = MagicRose) {
                    Text(
                        text = "• Tài khoản: ${u.displayName.ifBlank { "Người dùng" }}\n• Email: ${u.email}\n• Cấp hiện tại: ${if (isAccountPro) "👑 PRO TÀI KHOẢN" else "📱 PRO THIẾT BỊ"}\n• Device ID: ${devId.ifBlank { "Không rõ" }}",
                        color = TextSecondary,
                        fontSize = 11.5.sp,
                        lineHeight = 16.sp
                    )
                    Text(
                        text = "Vui lòng chọn cấp bậc bạn muốn hạ về:",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )

                    // Lựa chọn 1: Nếu đang là Pro Tài Khoản -> Cho phép hạ về Pro Thiết Bị
                    if (isAccountPro) {
                        Button(
                            onClick = {
                                LicenseManager.adminDowngradeToSpecificTier(
                                    context = context,
                                    userId = u.userId,
                                    deviceId = devId,
                                    ownerEmail = u.email,
                                    targetTier = "DEVICE_PRO"
                                ) { ok, msg ->
                                    val normDevId = LicenseManager.normalizeDeviceIdForMatch(devId)
                                    AdminSessionCache.updateSnapshot(context) { cur ->
                                        cur.copy(
                                            users = cur.users.map { item ->
                                                if (item.userId == u.userId || (u.email.isNotBlank() && item.email.equals(u.email, ignoreCase = true))) {
                                                    item.copy(isPro = true, isAccountPro = false, proTier = "DEVICE_PRO", revokedByAdmin = false)
                                                } else item
                                            },
                                            devices = if (normDevId.isNotBlank()) {
                                                cur.devices.map { d ->
                                                    if (LicenseManager.normalizeDeviceIdForMatch(d.deviceId) == normDevId) {
                                                        d.copy(isPro = true, isAccountPro = false, proTier = "DEVICE_PRO", revokedByAdmin = false)
                                                    } else d
                                                }
                                            } else cur.devices
                                        )
                                    }
                                    Toast.makeText(context, if (ok) msg else "⚠️ $msg", Toast.LENGTH_LONG).show()
                                    downgradeTargetUser = null
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MagicCyan),
                            modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 36.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("📱 Hạ về Pro Thiết Bị (Khóa theo máy, bỏ đổi máy)", color = Color(0xFF020617), fontWeight = FontWeight.Black, fontSize = 11.5.sp)
                        }
                    }

                    // Lựa chọn 2: Thu hồi hoàn toàn về Bản Miễn Phí (Free)
                    Button(
                        onClick = {
                            LicenseManager.adminDowngradeToSpecificTier(
                                context = context,
                                userId = u.userId,
                                deviceId = devId,
                                ownerEmail = u.email,
                                targetTier = "FREE"
                            ) { ok, msg ->
                                val normDevId = LicenseManager.normalizeDeviceIdForMatch(devId)
                                AdminSessionCache.updateSnapshot(context) { cur ->
                                    cur.copy(
                                        users = cur.users.map { item ->
                                            if (item.userId == u.userId || (u.email.isNotBlank() && item.email.equals(u.email, ignoreCase = true))) {
                                                item.copy(isPro = false, isAccountPro = false, proTier = "FREE", revokedByAdmin = true)
                                            } else item
                                        },
                                        devices = if (normDevId.isNotBlank()) {
                                            cur.devices.map { d ->
                                                if (LicenseManager.normalizeDeviceIdForMatch(d.deviceId) == normDevId) {
                                                    d.copy(isPro = false, isAccountPro = false, proTier = "FREE", revokedByAdmin = true, licenseKey = "")
                                                } else d
                                            }
                                        } else cur.devices
                                    )
                                }
                                Toast.makeText(context, if (ok) "🚫 Đã hạ về bản Miễn Phí (Free) & thu hồi Pro của tài khoản ${u.displayName.ifBlank { u.email }}!" else "⚠️ $msg", Toast.LENGTH_LONG).show()
                                downgradeTargetUser = null
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MagicRose),
                        modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("🚫 Hạ về Bản Miễn Phí (Gỡ Pro hoàn toàn)", color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.5.sp)
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { downgradeTargetUser = null }) {
                    Text("Hủy", color = TextSecondary, fontSize = 12.sp)
                }
            }
        )
    }

    activeProReceipt?.let { receipt ->
        ProGrantReceiptDialog(
            data = receipt,
            onDismiss = { activeProReceipt = null }
        )
    }

    if (showBatchGrantDialog) {
        AdminBatchGrantDialog(
            onDismiss = { showBatchGrantDialog = false },
            onBatchComplete = { refreshAllAdminMetricsViaRest(showToastOnDone = false, force = true) }
        )
    }

    if (showAutoAdminTesterDialog) {
        AutoAdminBankTesterDialog(
            onDismiss = { showAutoAdminTesterDialog = false },
            onExecuteRealGrant = { targetDevId, grantAccountPro, bankTrans ->
                LicenseManager.adminGrantTierForUserOrDevice(
                    userId = "",
                    deviceId = targetDevId,
                    ownerEmail = "",
                    grantAccountPro = grantAccountPro,
                    context = context,
                    noteOrReason = "AUTO_ADMIN_TESTER_VERIFIED",
                    bankTransCode = bankTrans
                ) { ok, msg ->
                    if (ok) {
                        val key = if (grantAccountPro) LicenseManager.generateAccountProLicenseKeyForDevice(targetDevId)
                        else LicenseManager.generateLicenseKeyForDevice(targetDevId)
                        refreshAllAdminMetricsViaRest(showToastOnDone = false, force = true)
                        activeProReceipt = ProGrantReceiptData(
                            targetDeviceId = targetDevId,
                            isAccountPro = grantAccountPro,
                            generatedKey = key,
                            reasonNote = "Duyệt trực tiếp từ Bộ Test Auto-Admin",
                            bankTransCode = bankTrans,
                            cloudSyncMessage = msg
                        )
                    }
                    Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                }
            }
        )
    }

    if (showQuickCloudLookupDialog) {
        AlertDialog(
            onDismissRequest = { showQuickCloudLookupDialog = false },
            containerColor = MagicSurfaceDark,
            title = {
                Text(
                    text = "🔍 Tra Cứu & Đối Soát Live Cloud",
                    color = MagicCyanLight,
                    fontWeight = FontWeight.Black,
                    fontSize = 15.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = quickCloudLookupQuery,
                        onValueChange = { quickCloudLookupQuery = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Device ID (MT-...) hoặc Email Google", fontSize = 11.sp) },
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )
                    Button(
                        onClick = {
                            if (quickCloudLookupQuery.isNotBlank()) {
                                isQuickCloudLookingUp = true
                                coroutineScope.launch {
                                    try {
                                        quickCloudAuditResult = LicenseManager.adminLookupTargetViaCloud(context, quickCloudLookupQuery)
                                    } catch (_: Throwable) {
                                    } finally {
                                        isQuickCloudLookingUp = false
                                    }
                                }
                            }
                        },
                        enabled = quickCloudLookupQuery.isNotBlank() && !isQuickCloudLookingUp,
                        colors = ButtonDefaults.buttonColors(containerColor = MagicCyan),
                        modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = if (isQuickCloudLookingUp) "⏳ Đang truy vấn Firestore..." else "🔍 KIỂM TRA TRÊN CLOUD",
                            color = Color.Black,
                            fontWeight = FontWeight.Black,
                            fontSize = 11.sp
                        )
                    }
                    quickCloudAuditResult?.let { lk ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(MagicSurfaceCard)
                                .border(1.dp, if (lk.isPro) MagicEmerald else MagicAmber, RoundedCornerShape(8.dp))
                                .padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "Trạng thái: ${lk.proTier} (${if (lk.isPro) "✅ PRO ACTIVE" else if (lk.revokedByAdmin) "🚫 REVOKED" else "🔓 FREE"})",
                                color = if (lk.isPro) MagicEmeraldLight else MagicAmber,
                                fontWeight = FontWeight.Black,
                                fontSize = 11.5.sp
                            )
                            Text("• Device ID: ${lk.resolvedDeviceId.ifBlank { "Chưa có" }}", color = Color.White, fontSize = 10.5.sp)
                            Text("• Email: ${lk.resolvedEmail.ifBlank { "Khách vãng lai" }}", color = TextSecondary, fontSize = 10.5.sp)
                            Text("• Model: ${lk.deviceModel.ifBlank { "Chưa rõ" }}", color = TextSecondary, fontSize = 10.5.sp)
                            val srcLine = listOf(lk.sourceSummary, lk.lastReason, lk.bankTransCode)
                                .filter { it.isNotBlank() }
                                .distinct()
                                .joinToString(" • ")
                            if (srcLine.isNotBlank()) {
                                Text("• Nguồn duyệt: $srcLine", color = MagicCyanLight, fontSize = 10.sp)
                            }
                            val keyLine = lk.licenseKeyOnCloud.ifBlank { lk.accountProKey.ifBlank { lk.deviceProKey } }
                            if (keyLine.isNotBlank()) {
                                Text("• Key: $keyLine", color = MagicAmber, fontSize = 10.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showQuickCloudLookupDialog = false }) {
                    Text("Đóng", color = MagicCyanLight, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

fun formatDateVn(dateStr: String): String {
    return try {
        val parts = dateStr.split("-")
        if (parts.size == 3) "${parts[2]}/${parts[1]}/${parts[0]}" else dateStr
    } catch (_: Throwable) { dateStr }
}
