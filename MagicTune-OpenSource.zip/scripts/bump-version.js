const fs = require('fs');
const path = require('path');

const versionFilePath = path.join(__dirname, '..', 'src', 'lib', 'version.ts');

try {
  let content = fs.readFileSync(versionFilePath, 'utf8');
  
  // Tìm số phiên bản vXX
  const match = content.match(/APP_RELEASE_VERSION\s*=\s*["']v(\d+)(\.\d+)?["']/);
  
  let newVersion = 'v19';
  if (match) {
    const currentNum = parseInt(match[1], 10);
    newVersion = `v${currentNum + 1}`;
  }
  
  const now = new Date();
  const dateStr = now.toISOString().split('T')[0];
  const timeStr = now.toTimeString().split(' ')[0];
  
  const updatedContent = `/**
 * MagicTune Application Release Versioning
 * Tự động tăng phiên bản (v18 -> v19 -> v20...) mỗi lần build xuất bản
 */
export const APP_RELEASE_VERSION = "${newVersion}";
export const APP_BUILD_TIMESTAMP = "${dateStr} ${timeStr}";
`;

  fs.writeFileSync(versionFilePath, updatedContent, 'utf8');
  console.log(`[Version Bump] Đã tự động tăng phiên bản ứng dụng lên: ${newVersion} (${dateStr} ${timeStr})`);
} catch (err) {
  console.error('[Version Bump Error]', err);
}
