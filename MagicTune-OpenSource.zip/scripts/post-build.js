const fs = require('fs');
const path = require('path');

const outDir = path.join(__dirname, '..', 'out');

// Đảm bảo tương thích hoàn hảo giữa /route, /route/, /route.html
const routes = ['admin', 'auth/qr-confirm', 'privacy', 'terms', 'about', 'contact'];

routes.forEach(route => {
  const dir = path.join(outDir, route);
  const indexHtml = path.join(dir, 'index.html');
  const directHtml = path.join(outDir, `${route}.html`);

  if (fs.existsSync(indexHtml) && !fs.existsSync(directHtml)) {
    fs.copyFileSync(indexHtml, directHtml);
    console.log(`[Post-Build] Đã tạo alias: ${route}.html <- ${route}/index.html`);
  } else if (fs.existsSync(directHtml) && !fs.existsSync(indexHtml)) {
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.copyFileSync(directHtml, indexHtml);
    console.log(`[Post-Build] Đã tạo alias: ${route}/index.html <- ${route}.html`);
  }
});
