package com.example.core.keyboard

import android.app.Notification
import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.service.notification.StatusBarNotification
import java.util.concurrent.CopyOnWriteArrayList
import java.util.regex.Pattern

/**
 * Quản Lý & Tự Động Trích Xuất Mã OTP Từ Thông Báo & SMS (Magic OTP Manager):
 * - Tự động phát hiện thông báo chứa mã OTP từ SMS, App Ngân Hàng, Zalo, Google, Facebook, Telegram...
 * - Trích xuất mã số xác thực (4 đến 8 chữ số) và nguồn gửi.
 * - Cung cấp thanh điền nhanh 1-chạm (hoặc tự động điền) trực tiếp trên Bàn phím hệ thống MagicTune.
 * - Tự động hủy mã sau 5 phút để bảo vệ an toàn.
 */
object MagicOtpManager {

    private const val PREFS_NAME = "magictune_keyboard_prefs"
    private const val KEY_AUTO_FILL_OTP = "auto_fill_otp_enabled"
    const val OTP_VALIDITY_MS = 90 * 1000L // 90 giây (chỉ hiển thị khi vừa có mã OTP mới thực sự)

    data class OtpInfo(
        val code: String,
        val sender: String,
        val timestamp: Long = System.currentTimeMillis(),
        val fullMessage: String = ""
    )

    @Volatile
    private var latestOtpInfo: OtpInfo? = null

    // Lưu các mã OTP hoặc tin nhắn đã điền / đã bấm đóng (✕) để không bao giờ tự hiện lại
    private val consumedOrDismissedKeys = java.util.Collections.synchronizedSet( LinkedHashSet<String>() )

    private val otpListeners = CopyOnWriteArrayList<(OtpInfo?) -> Unit>()

    private val otpRegexPatterns = listOf(
        // Dạng 1: "Mã OTP của quý khách là 849201", "Mã xác thực: 482910", "verification code: 123456"
        Pattern.compile("(?i)(?:\\botp\\b|mã\\s+(?:xác\\s+thực|xác\\s+minh|bảo\\s+mật|đăng\\s+nhập|otp)|ma\\s+(?:xac\\s+thuc|xac\\s+minh|bao\\s+mat|dang\\s+nhap|otp)|(?:verification|security|login|auth|authentication)\\s+code)(?:\\s+(?:của\\s+bạn|cua\\s+ban|của\\s+quý\\s+khách|cua\\s+quy\\s+khach|là|la|is))?[^\\d\\n]{0,20}?\\b(\\d{4,8})\\b"),
        // Dạng 2: "849201 là mã OTP", "123456 la ma xac thuc", "123456 is your verification code"
        Pattern.compile("(?i)\\b(\\d{4,8})\\b\\s+(?:là|la|is)\\s+(?:your\\s+)?(?:mã\\s+(?:otp|xác\\s+thực|xác\\s+minh|bảo\\s+mật|đăng\\s+nhập)|ma\\s+(?:otp|xac\\s+thuc|xac\\s+minh|bao\\s+mat|dang\\s+nhap)|(?:otp|verification|security|login|authentication)\\s+code|\\botp\\b)"),
        // Dạng 3: "[G-123456]" hoặc "G-123456 là mã xác minh Google"
        Pattern.compile("(?i)\\bG-(\\d{6})\\b")
    )

    private val strictOtpKeywords = listOf(
        "otp", "mã xác thực", "ma xac thuc", "mã xác minh", "ma xac minh",
        "verification code", "security code", "mã bảo mật", "ma bao mat",
        "mã đăng nhập", "ma dang nhap", "login code", "auth code", "one-time password"
    )

    private val ignoredPackages = setOf(
        "android",
        "com.android.systemui",
        "com.android.settings",
        "com.android.providers.downloads",
        "com.android.vending"
    )

    fun addOtpListener(listener: (OtpInfo?) -> Unit) {
        if (!otpListeners.contains(listener)) {
            otpListeners.add(listener)
        }
    }

    fun removeOtpListener(listener: (OtpInfo?) -> Unit) {
        otpListeners.remove(listener)
    }

    private fun notifyOtpChanged(otp: OtpInfo?) {
        for (l in otpListeners) {
            try {
                l.invoke(otp)
            } catch (_: Throwable) {}
        }
    }

    fun getRecentValidOtp(): OtpInfo? {
        val current = latestOtpInfo ?: return null
        if (System.currentTimeMillis() - current.timestamp > OTP_VALIDITY_MS) {
            latestOtpInfo = null
            notifyOtpChanged(null)
            return null
        }
        return current
    }

    fun clearLatestOtp() {
        val current = latestOtpInfo
        if (current != null) {
            rememberConsumed(current.code, current.fullMessage)
        }
        latestOtpInfo = null
        notifyOtpChanged(null)
    }

    private fun rememberConsumed(code: String, fullMessage: String) {
        synchronized(consumedOrDismissedKeys) {
            if (consumedOrDismissedKeys.size > 60) {
                val it = consumedOrDismissedKeys.iterator()
                if (it.hasNext()) {
                    it.next()
                    it.remove()
                }
            }
            consumedOrDismissedKeys.add("CODE:$code")
            if (fullMessage.isNotBlank()) {
                consumedOrDismissedKeys.add("MSG:${fullMessage.hashCode()}")
            }
        }
    }

    fun isAutoFillEnabled(context: Context): Boolean {
        return try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.getBoolean(KEY_AUTO_FILL_OTP, true)
        } catch (_: Throwable) {
            true
        }
    }

    fun setAutoFillEnabled(context: Context, enabled: Boolean) {
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit().putBoolean(KEY_AUTO_FILL_OTP, enabled).apply()
        } catch (_: Throwable) {}
    }

    /**
     * Trích xuất mã OTP từ tin nhắn văn bản thuần (chỉ từ SMS / Thông báo mới thực sự).
     */
    fun processRawText(context: Context, rawText: String, senderHint: String = "SMS"): Boolean {
        val clean = rawText.trim()
        if (clean.length < 6 || clean.length > 600) return false

        // Bỏ qua nếu tin nhắn này đã từng được xử lý/đóng trước đó
        if (consumedOrDismissedKeys.contains("MSG:${clean.hashCode()}")) return false

        val lower = clean.lowercase()
        val hasOtpKeyword = strictOtpKeywords.any { lower.contains(it) }
        if (!hasOtpKeyword) return false

        var extractedOtp: String? = null

        // Chỉ chấp nhận khi khớp đúng ngữ cảnh OTP chuẩn (KHÔNG đoán mò số 4-8 chữ số bất kỳ trong câu)
        for (pattern in otpRegexPatterns) {
            val matcher = pattern.matcher(clean)
            if (matcher.find()) {
                val candidate = matcher.group(1)?.trim()
                if (candidate != null && candidate.length in 4..8 && !isLikelyCurrencyOrYear(clean, matcher.start(1), matcher.end(1), candidate)) {
                    extractedOtp = candidate
                    break
                }
            }
        }

        if (extractedOtp.isNullOrBlank()) return false
        if (consumedOrDismissedKeys.contains("CODE:$extractedOtp")) return false

        val info = OtpInfo(
            code = extractedOtp,
            sender = senderHint,
            timestamp = System.currentTimeMillis(),
            fullMessage = clean
        )
        latestOtpInfo = info
        notifyOtpChanged(info)
        return true
    }

    private fun isLikelyCurrencyOrYear(text: String, startIdx: Int, endIdx: Int, code: String): Boolean {
        // Loại bỏ số năm phổ biến nếu vô tình đứng cạnh
        if (code == "2024" || code == "2025" || code == "2026" || code == "2027") return true
        // Kiểm tra ký tự ngay trước (ví dụ +50000, -20000, $1000)
        if (startIdx > 0) {
            val prev = text[startIdx - 1]
            if (prev == '+' || prev == '$' || prev == '¥' || prev == '€' || prev == '₫') return true
        }
        // Kiểm tra hậu tố tiền tệ ngay sau số (ví dụ 50000đ, 50000 VND, 100k)
        val tail = text.substring(endIdx, (endIdx + 6).coerceAtMost(text.length)).trim().lowercase()
        if (tail.startsWith("đ") || tail.startsWith("vnd") || tail.startsWith("vnđ") ||
            tail.startsWith("usd") || tail.startsWith("₫") || tail.startsWith("%")
        ) {
            return true
        }
        return false
    }

    /**
     * Phân tích thông báo StatusBarNotification mới nhận từ hệ thống để trích xuất OTP.
     */
    fun processNotification(context: Context, sbn: StatusBarNotification): Boolean {
        try {
            if (sbn.isOngoing) return false
            // Chỉ nhận thông báo mới vừa tới trong vòng 45 giây (bỏ qua thông báo cũ tồn đọng trên thanh trạng thái)
            val ageMs = System.currentTimeMillis() - sbn.postTime
            if (ageMs > 45_000L) return false

            val pkg = sbn.packageName?.trim().orEmpty()
            if (pkg.isBlank() || pkg == context.packageName || ignoredPackages.contains(pkg)) return false

            val notification = sbn.notification ?: return false
            if ((notification.flags and Notification.FLAG_ONGOING_EVENT) != 0) return false
            val extras = notification.extras ?: return false

            val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
            val bigTitle = extras.getCharSequence(Notification.EXTRA_TITLE_BIG)?.toString()?.trim().orEmpty()
            val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
            val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.trim().orEmpty()

            val linesBuilder = StringBuilder()
            if (bigText.isNotBlank()) linesBuilder.append(bigText).append(" ")
            if (text.isNotBlank() && !bigText.contains(text)) linesBuilder.append(text).append(" ")

            val textLines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
            if (textLines != null) {
                for (line in textLines) {
                    val l = line?.toString()?.trim().orEmpty()
                    if (l.isNotBlank() && !linesBuilder.contains(l)) {
                        linesBuilder.append(l).append(" ")
                    }
                }
            }

            val effectiveTitle = bigTitle.ifBlank { title }
            val fullBody = "$effectiveTitle ${linesBuilder.toString().trim()}".trim()

            if (fullBody.isBlank()) return false

            // Xác định tên nguồn gửi (SMS Brandname / Ngân Hàng / App Mạng Xã Hội)
            val senderName = resolveSenderName(pkg, effectiveTitle)

            return processRawText(context, fullBody, senderName)
        } catch (_: Throwable) {
            return false
        }
    }

    private fun resolveSenderName(packageName: String, title: String): String {
        if (title.isNotBlank() && title.length in 2..20 && !title.contains("tin nhắn", ignoreCase = true)) {
            return title
        }
        return when {
            packageName.contains("messaging", ignoreCase = true) || packageName.contains("mms", ignoreCase = true) -> "Tin nhắn SMS"
            packageName.contains("vcb", ignoreCase = true) || packageName.contains("vietcombank", ignoreCase = true) -> "Vietcombank"
            packageName.contains("mb", ignoreCase = true) && packageName.contains("bank", ignoreCase = true) -> "MB Bank"
            packageName.contains("techcombank", ignoreCase = true) -> "Techcombank"
            packageName.contains("bidv", ignoreCase = true) -> "BIDV"
            packageName.contains("tpb", ignoreCase = true) || packageName.contains("tpbank", ignoreCase = true) -> "TPBank"
            packageName.contains("zalo", ignoreCase = true) -> "Zalo"
            packageName.contains("telegram", ignoreCase = true) -> "Telegram"
            packageName.contains("whatsapp", ignoreCase = true) -> "WhatsApp"
            packageName.contains("facebook", ignoreCase = true) || packageName.contains("orca", ignoreCase = true) -> "Facebook"
            packageName.contains("shopee", ignoreCase = true) -> "Shopee"
            else -> title.ifBlank { "Mã OTP" }
        }
    }
}
