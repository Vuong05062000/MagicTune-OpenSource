package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.auth.DeviceRecord
import com.example.core.auth.UserProfile
import com.example.core.license.LicenseManager
import com.example.ui.theme.*

enum class AdminUserDeviceSortMode(val label: String) {
    RECENT_ACTIVE("Hoạt động mới"),
    PRO_ACTIVATED("Lên Pro gần nhất"),
    NAME_OR_ID("Tên / Mã A-Z"),
    MOST_TRIALS("Dùng thử nhiều")
}

private fun copyTextAdminQuick(context: Context, label: String, value: String) {
    val cb = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
    if (cb != null) {
        cb.setPrimaryClip(ClipData.newPlainText(label, value))
        Toast.makeText(context, "📋 Đã copy $label: $value", Toast.LENGTH_SHORT).show()
    } else {
        Toast.makeText(context, "Không truy cập được Clipboard", Toast.LENGTH_SHORT).show()
    }
}

internal fun isOnlineWithin24h(ts: com.google.firebase.Timestamp?): Boolean {
    val ms = ts?.toDate()?.time ?: 0L
    if (ms <= 0L) return false
    return (System.currentTimeMillis() - ms) <= 86_400_000L
}

@Composable
fun AdminUserDeviceSummaryHeader(
    totalDevices: Int,
    proDevicesCount: Int,
    accountProDevicesCount: Int,
    deviceOnlyProCount: Int,
    freeDevicesCount: Int,
    suspiciousDevicesCount: Int,
    online24hDevicesCount: Int,
    boundDevicesCount: Int,
    guestDevicesCount: Int,
    totalUsers: Int,
    proUsersCount: Int,
    accountProCount: Int,
    deviceProCount: Int,
    normalUsersCount: Int,
    adminCount: Int,
    revokedCount: Int,
    online24hUsersCount: Int,
    unifiedManageMode: String,
    multiSelectMode: Boolean,
    onSelectMode: (String) -> Unit,
    onToggleMultiSelect: () -> Unit,
    onExportProSummary: () -> Unit,
    onQuickLookupCloud: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
        border = BorderStroke(1.2.dp, MagicCyan.copy(alpha = 0.55f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "👥 & 📱 QUẢN LÝ USER / MÁY THỰC TẾ",
                    color = MagicCyanLight,
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.weight(1f)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (multiSelectMode) MagicPurple.copy(alpha = 0.35f) else MagicSurfaceCard)
                            .border(1.dp, if (multiSelectMode) MagicPurpleLight else MagicBorder, RoundedCornerShape(8.dp))
                            .clickable { onToggleMultiSelect() }
                            .padding(horizontal = 8.dp, vertical = 5.dp)
                            .testTag("admin_toggle_multiselect")
                    ) {
                        Text(
                            text = if (multiSelectMode) "☑️ Đang chọn nhiều" else "☑️ Chọn nhiều",
                            color = if (multiSelectMode) Color.White else TextSecondary,
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(MagicEmerald.copy(alpha = 0.18f))
                            .border(1.dp, MagicEmerald.copy(alpha = 0.55f), RoundedCornerShape(8.dp))
                            .clickable { onExportProSummary() }
                            .padding(horizontal = 8.dp, vertical = 5.dp)
                            .testTag("admin_export_pro_list")
                    ) {
                        Text(
                            text = "📋 Xuất DS Pro",
                            color = MagicEmeraldLight,
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val isDevMode = unifiedManageMode == "DEVICES"
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isDevMode) MagicCyan.copy(alpha = 0.16f) else MagicSurfaceCard)
                        .border(
                            width = if (isDevMode) 1.6.dp else 1.dp,
                            color = if (isDevMode) MagicCyan else MagicBorder,
                            shape = RoundedCornerShape(10.dp)
                        )
                        .clickable { onSelectMode("DEVICES") }
                        .padding(10.dp)
                        .testTag("admin_mode_devices")
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "📱 TỔNG MÁY",
                                color = if (isDevMode) MagicCyanLight else TextSecondary,
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "🟢 $online24hDevicesCount/24h",
                                color = MagicEmeraldLight,
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = "$totalDevices máy",
                            color = Color.White,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "⚡ $proDevicesCount Pro ($accountProDevicesCount TK • $deviceOnlyProCount Máy)\n🔓 $freeDevicesCount Free • 👤 $boundDevicesCount TK / $guestDevicesCount Khách${if (suspiciousDevicesCount > 0) "\n🚨 $suspiciousDevicesCount Nghi vấn" else ""}",
                            color = TextSecondary,
                            fontSize = 9.sp,
                            lineHeight = 12.5.sp
                        )
                    }
                }

                val isUserMode = unifiedManageMode == "USERS"
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isUserMode) MagicAmber.copy(alpha = 0.15f) else MagicSurfaceCard)
                        .border(
                            width = if (isUserMode) 1.6.dp else 1.dp,
                            color = if (isUserMode) MagicAmber else MagicBorder,
                            shape = RoundedCornerShape(10.dp)
                        )
                        .clickable { onSelectMode("USERS") }
                        .padding(10.dp)
                        .testTag("admin_mode_users")
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "👥 TỔNG USER",
                                color = if (isUserMode) MagicAmber else TextSecondary,
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "🟢 $online24hUsersCount/24h",
                                color = MagicEmeraldLight,
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = "$totalUsers tài khoản",
                            color = Color.White,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "⚡ $proUsersCount Pro ($accountProCount TK • $deviceProCount Máy)\n👤 $normalUsersCount Free • 👑 $adminCount Admin${if (revokedCount > 0) " • 🚫 $revokedCount Gỡ" else ""}",
                            color = TextSecondary,
                            fontSize = 9.sp,
                            lineHeight = 12.5.sp
                        )
                    }
                }
            }

            // Quick Cloud Lookup CTA — Tách nút "TRA NGAY →" sang hàng riêng rộng rãi, không bị bóp hẹp
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(MagicSurfaceCard)
                    .border(1.dp, MagicCyan.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
                    .clickable { onQuickLookupCloud() }
                    .padding(horizontal = 10.dp, vertical = 9.dp)
                    .testTag("admin_quick_cloud_lookup_btn"),
                verticalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Tra cứu Cloud Firestore",
                        tint = MagicCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "Tra cứu & đối soát nhanh 1 máy/email trực tiếp từ Cloud Firestore",
                        color = MagicCyanLight,
                        fontSize = 10.8.sp,
                        fontWeight = FontWeight.SemiBold,
                        lineHeight = 14.5.sp,
                        modifier = Modifier.weight(1f)
                    )
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MagicCyan.copy(alpha = 0.18f))
                        .border(1.dp, MagicCyan.copy(alpha = 0.65f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 12.dp, vertical = 7.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "🔍 TRA NGAY →",
                        color = MagicCyanLight,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
fun AdminSortSelectorRow(
    selectedSort: AdminUserDeviceSortMode,
    showTrialsSort: Boolean,
    onSelectSort: (AdminUserDeviceSortMode) -> Unit
) {
    val options = remember(showTrialsSort) {
        if (showTrialsSort) {
            AdminUserDeviceSortMode.entries
        } else {
            listOf(
                AdminUserDeviceSortMode.RECENT_ACTIVE,
                AdminUserDeviceSortMode.PRO_ACTIVATED,
                AdminUserDeviceSortMode.NAME_OR_ID
            )
        }
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "Sắp xếp:",
            color = TextMuted,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold
        )
        options.forEach { mode ->
            val selected = mode == selectedSort
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (selected) MagicPurple.copy(alpha = 0.28f) else MagicSurfaceDark)
                    .border(
                        1.dp,
                        if (selected) MagicPurpleLight else MagicBorder,
                        RoundedCornerShape(8.dp)
                    )
                    .clickable { onSelectSort(mode) }
                    .padding(horizontal = 9.dp, vertical = 5.dp)
            ) {
                Text(
                    text = mode.label,
                    color = if (selected) Color.White else TextSecondary,
                    fontSize = 9.5.sp,
                    fontWeight = if (selected) FontWeight.Black else FontWeight.Medium
                )
            }
        }
    }
}

@Composable
fun AdminDeviceCardCompact(
    dev: DeviceRecord,
    matchedOwnerUser: UserProfile?,
    matchedAiBillLog: LicenseManager.AiProChatLogRecord?,
    multiSelectMode: Boolean,
    isChecked: Boolean,
    isExpanded: Boolean,
    onToggleCheck: () -> Unit,
    onToggleExpand: () -> Unit,
    onJumpToOwnerUser: (String) -> Unit,
    onLookupCloud: (String) -> Unit,
    onResetTrial: (DeviceRecord) -> Unit,
    onUnlockSession: (UserProfile) -> Unit,
    onGenerateKey: (DeviceRecord) -> Unit,
    onDowngrade: (DeviceRecord) -> Unit,
    onGrantOrChangeTier: (DeviceRecord) -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val isEffectivePro = dev.isPro && !dev.revokedByAdmin
    val isAccPro = isEffectivePro && (dev.isAccountPro || dev.proTier == "ACCOUNT_PRO")
    val isOwnerAccPro = matchedOwnerUser != null &&
        matchedOwnerUser.isPro &&
        !matchedOwnerUser.revokedByAdmin &&
        (matchedOwnerUser.isAccountPro || matchedOwnerUser.proTier == "ACCOUNT_PRO")
    val isGuestDevice = !dev.ownerEmail.contains("@") ||
        dev.ownerEmail.contains("Khách vãng lai", ignoreCase = true) ||
        dev.ownerEmail.contains("Chưa đăng nhập", ignoreCase = true)
    val onlineNow = isOnlineWithin24h(dev.lastActive)
    val isInvalidFormat = dev.deviceId.trim().length < 4
    val isUnverifiedSource = isEffectivePro &&
        dev.licenseKey.isBlank() &&
        dev.approvedByAiReason.isBlank() &&
        dev.bankTransCode.isBlank() &&
        matchedAiBillLog == null

    val borderColor = when {
        isChecked -> MagicPurpleLight
        isEffectivePro && (isInvalidFormat || isUnverifiedSource) -> MagicRose.copy(alpha = 0.75f)
        isAccPro -> MagicAmber.copy(alpha = 0.75f)
        isEffectivePro -> MagicEmerald.copy(alpha = 0.65f)
        dev.revokedByAdmin -> MagicRose.copy(alpha = 0.45f)
        else -> MagicBorder
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("admin_device_card_${dev.deviceId}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
        border = BorderStroke(if (isChecked) 1.5.dp else 1.dp, borderColor)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(11.dp),
            verticalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            // Row 1: ID + Copy + Tier Badge + Live status dot
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    if (multiSelectMode) {
                        Checkbox(
                            checked = isChecked,
                            onCheckedChange = { onToggleCheck() },
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Text(
                        text = if (onlineNow) "🟢" else "📱",
                        fontSize = 12.sp
                    )
                    Text(
                        text = dev.deviceId,
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 12.5.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    IconButton(
                        onClick = { copyTextAdminQuick(context, "Device ID", dev.deviceId) },
                        modifier = Modifier.size(26.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy Device ID",
                            tint = MagicCyan,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(
                            when {
                                isAccPro -> MagicAmber.copy(alpha = 0.22f)
                                isEffectivePro -> MagicEmerald.copy(alpha = 0.2f)
                                dev.revokedByAdmin -> MagicRose.copy(alpha = 0.2f)
                                else -> MagicSurfaceCard
                            }
                        )
                        .border(
                            0.8.dp,
                            when {
                                isAccPro -> MagicAmber.copy(alpha = 0.6f)
                                isEffectivePro -> MagicEmerald.copy(alpha = 0.5f)
                                dev.revokedByAdmin -> MagicRose.copy(alpha = 0.5f)
                                else -> MagicBorder
                            },
                            RoundedCornerShape(6.dp)
                        )
                        .padding(horizontal = 7.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = when {
                            isInvalidFormat && isEffectivePro -> "🚨 LỖI ID"
                            isAccPro -> "👑 PRO TK"
                            isEffectivePro -> "📱 PRO MÁY"
                            dev.revokedByAdmin -> "🚫 BỊ GỠ"
                            else -> "🔓 FREE"
                        },
                        color = when {
                            isInvalidFormat && isEffectivePro -> MagicRoseLight
                            isAccPro -> MagicAmber
                            isEffectivePro -> MagicEmeraldLight
                            dev.revokedByAdmin -> MagicRoseLight
                            else -> TextSecondary
                        },
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            // Row 2: Model + Last Active + Trial pill
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = dev.model.ifBlank { "Thiết bị Android" },
                    color = Color.White.copy(alpha = 0.9f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = dev.getLastActiveFormatted(),
                        color = if (onlineNow) MagicEmeraldLight else MagicCyanLight,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(5.dp))
                            .background(MagicSurfaceCard)
                            .padding(horizontal = 5.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "🎯 ${dev.freeTrialUsed} lượt",
                            color = if (dev.freeTrialUsed >= 6 && !isEffectivePro) MagicAmber else TextMuted,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Row 3: Cross-linked Owner Pill (1-tap jump to User profile!)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                if (!isGuestDevice) {
                    Box(
                        modifier = Modifier
                            .weight(1f, fill = false)
                            .clip(RoundedCornerShape(6.dp))
                            .background(MagicCyan.copy(alpha = 0.1f))
                            .border(0.8.dp, MagicCyan.copy(alpha = 0.35f), RoundedCornerShape(6.dp))
                            .clickable { onJumpToOwnerUser(dev.ownerEmail) }
                            .padding(horizontal = 7.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "👤 ${dev.ownerEmail}${if (matchedOwnerUser?.role == "admin") " (👑 Admin)" else if (isOwnerAccPro) " (👑 Chủ Pro TK)" else ""} ↗",
                            color = MagicCyanLight,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MagicAmber.copy(alpha = 0.12f))
                            .border(0.8.dp, MagicAmber.copy(alpha = 0.35f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 7.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "👤 Khách vãng lai (Chưa liên kết Email)",
                            color = MagicAmber,
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                if (isUnverifiedSource) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "⚠️ Thiếu chứng từ",
                        color = MagicAmber,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            // Row 4: Clean Action Row
            Row(
                modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = { onGrantOrChangeTier(dev) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isEffectivePro) MagicSurfaceCard else MagicEmerald
                    ),
                    border = if (isEffectivePro) BorderStroke(1.dp, MagicCyan.copy(alpha = 0.45f)) else null,
                    modifier = Modifier
                        .fillMaxHeight()
                        .weight(1f)
                        .defaultMinSize(minHeight = 36.dp),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = if (isEffectivePro) Icons.Default.Settings else Icons.Default.FlashOn,
                        contentDescription = null,
                        tint = if (isEffectivePro) MagicCyanLight else Color(0xFF020617),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isEffectivePro) "Đổi Gói Pro" else "⚡ Cấp Pro",
                        color = if (isEffectivePro) MagicCyanLight else Color(0xFF020617),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        maxLines = 1
                    )
                }

                if (isEffectivePro) {
                    Button(
                        onClick = { onDowngrade(dev) },
                        colors = ButtonDefaults.buttonColors(containerColor = MagicRose),
                        modifier = Modifier
                            .fillMaxHeight()
                            .weight(0.95f)
                            .defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.RemoveCircleOutline,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Hạ Cấp",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            maxLines = 1
                        )
                    }
                } else if (dev.freeTrialUsed > 0) {
                    OutlinedButton(
                        onClick = { onResetTrial(dev) },
                        border = BorderStroke(1.dp, MagicAmber.copy(alpha = 0.6f)),
                        modifier = Modifier
                            .fillMaxHeight()
                            .weight(0.95f)
                            .defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "🎯 Reset Lượt",
                            color = MagicAmber,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Black,
                            maxLines = 1
                        )
                    }
                }

                FilledTonalIconButton(
                    onClick = onToggleExpand,
                    modifier = Modifier.size(48.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = IconButtonDefaults.filledTonalIconButtonColors(
                        containerColor = MagicSurfaceCard,
                        contentColor = MagicCyanLight
                    )
                ) {
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = if (isExpanded) "Thu gọn chi tiết máy" else "Mở rộng chi tiết máy",
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // Expandable Forensic & Power Management Section
            AnimatedVisibility(visible = isExpanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MagicSurfaceCard)
                        .border(0.8.dp, MagicBorder, RoundedCornerShape(8.dp))
                        .padding(9.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Text(
                        text = "📅 Thêm: ${dev.getCreatedAtFormatted()}${if (dev.hardwareId.isNotBlank()) " • HW: ${dev.hardwareId.take(12)}" else ""}",
                        color = TextSecondary,
                        fontSize = 10.sp
                    )
                    if (dev.ownerName.isNotBlank() && !dev.ownerName.equals("Khách vãng lai", true)) {
                        Text(
                            text = "🪪 Tên khách: ${dev.ownerName}${if (!matchedOwnerUser?.phoneNumber.isNullOrBlank()) " • SĐT: ${matchedOwnerUser?.phoneNumber}" else ""}",
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 10.sp
                        )
                    }
                    if (isEffectivePro) {
                        val proTimeDisplay = when {
                            dev.proActivatedAt != null -> dev.getProActivatedAtFormatted()
                            matchedOwnerUser?.proActivatedAt != null -> matchedOwnerUser.getProActivatedAtFormatted()
                            matchedAiBillLog != null -> matchedAiBillLog.getFormattedTime()
                            dev.createdAt != null -> "${dev.getCreatedAtFormatted()} (Theo ngày tạo)"
                            else -> "⚠️ Chưa có mốc giờ"
                        }
                        val proSourceDisplay = when {
                            dev.approvedByAiReason.isNotBlank() -> dev.getProSourceFormatted()
                            matchedAiBillLog != null -> "🤖 AI duyệt Bill (GD: ${matchedAiBillLog.bankTransCode.ifBlank { "Có bill" }})"
                            matchedOwnerUser?.proActivatedSource?.isNotBlank() == true -> matchedOwnerUser.getProSourceFormatted()
                            dev.licenseKey.isNotBlank() -> "🔑 Mã Key (${dev.licenseKey.take(10)}...)"
                            else -> "⚠️ Chưa rõ nguồn duyệt — Nên tra Cloud / đối soát!"
                        }
                        Text(
                            text = "⏰ Lên Pro: $proTimeDisplay",
                            color = if (isUnverifiedSource) MagicAmber else MagicEmeraldLight,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "📌 Nguồn: $proSourceDisplay",
                            color = TextSecondary,
                            fontSize = 10.sp
                        )
                    }
                    if (dev.licenseKey.isNotBlank()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "🔑 Key: ${dev.licenseKey}",
                                color = MagicCyanLight,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "Copy Key",
                                color = MagicCyan,
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Black,
                                modifier = Modifier.clickable { copyTextAdminQuick(context, "License Key", dev.licenseKey) }
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OutlinedButton(
                            onClick = { onLookupCloud(dev.deviceId) },
                            modifier = Modifier.fillMaxHeight().defaultMinSize(minHeight = 36.dp),
                            shape = RoundedCornerShape(7.dp),
                            contentPadding = PaddingValues(horizontal = 9.dp, vertical = 2.dp)
                        ) {
                            Text("🔍 Tra Cloud Live", color = MagicCyanLight, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(
                            onClick = { onGenerateKey(dev) },
                            modifier = Modifier.fillMaxHeight().defaultMinSize(minHeight = 36.dp),
                            shape = RoundedCornerShape(7.dp),
                            contentPadding = PaddingValues(horizontal = 9.dp, vertical = 2.dp)
                        ) {
                            Text("🔑 Tạo Key & Biên Nhận", color = MagicEmeraldLight, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                        if (dev.freeTrialUsed > 0) {
                            OutlinedButton(
                                onClick = { onResetTrial(dev) },
                                modifier = Modifier.fillMaxHeight().defaultMinSize(minHeight = 36.dp),
                                shape = RoundedCornerShape(7.dp),
                                contentPadding = PaddingValues(horizontal = 9.dp, vertical = 2.dp)
                            ) {
                                Text("🎯 Reset Trial → 0", color = MagicAmber, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        if (matchedOwnerUser != null && (matchedOwnerUser.activeDeviceId.isNotBlank() || isOwnerAccPro)) {
                            OutlinedButton(
                                onClick = { onUnlockSession(matchedOwnerUser) },
                                modifier = Modifier.fillMaxHeight().defaultMinSize(minHeight = 36.dp),
                                shape = RoundedCornerShape(7.dp),
                                contentPadding = PaddingValues(horizontal = 9.dp, vertical = 2.dp)
                            ) {
                                Text("🔓 Mở Khóa 1 Máy Chủ TK", color = MagicPurpleLight, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminUserCardCompact(
    u: UserProfile,
    linkedDevices: List<DeviceRecord>,
    matchedBillLog: LicenseManager.AiProChatLogRecord?,
    multiSelectMode: Boolean,
    isChecked: Boolean,
    isExpanded: Boolean,
    onToggleCheck: () -> Unit,
    onToggleExpand: () -> Unit,
    onJumpToDevice: (String) -> Unit,
    onLookupCloud: (String) -> Unit,
    onUnlockSession: (UserProfile) -> Unit,
    onUpgradeAdmin: (UserProfile) -> Unit,
    onDowngrade: (UserProfile) -> Unit,
    onGrantOrChangeTier: (UserProfile) -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val isEffectivePro = u.isPro && !u.revokedByAdmin
    val isAccPro = isEffectivePro && (u.isAccountPro || u.proTier == "ACCOUNT_PRO")
    val onlineNow = isOnlineWithin24h(u.lastActive)
    val primaryDev = linkedDevices.firstOrNull()
    val normActive = LicenseManager.normalizeDeviceIdForMatch(u.activeDeviceId.ifBlank { u.deviceId })

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("admin_user_card_${u.email.ifBlank { u.userId }}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
        border = BorderStroke(
            if (isChecked) 1.5.dp else 1.dp,
            when {
                isChecked -> MagicPurpleLight
                u.role == "admin" -> MagicPurple.copy(alpha = 0.75f)
                isAccPro -> MagicAmber.copy(alpha = 0.7f)
                isEffectivePro -> MagicEmerald.copy(alpha = 0.65f)
                u.revokedByAdmin -> MagicRose.copy(alpha = 0.5f)
                else -> MagicBorder
            }
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(11.dp),
            verticalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            // Row 1: Name + Role + Tier
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    if (multiSelectMode) {
                        Checkbox(
                            checked = isChecked,
                            onCheckedChange = { onToggleCheck() },
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Text(
                        text = if (onlineNow) "🟢" else "👤",
                        fontSize = 12.sp
                    )
                    Text(
                        text = u.displayName.ifBlank { u.email.ifBlank { "Người dùng" } },
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 12.5.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    if (u.role == "admin") {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(5.dp))
                                .background(MagicPurple.copy(alpha = 0.3f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("👑 ADMIN", color = MagicPurpleLight, fontSize = 9.sp, fontWeight = FontWeight.Black)
                        }
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(5.dp))
                            .background(
                                when {
                                    isAccPro -> MagicAmber.copy(alpha = 0.24f)
                                    isEffectivePro -> MagicEmerald.copy(alpha = 0.2f)
                                    u.revokedByAdmin -> MagicRose.copy(alpha = 0.2f)
                                    else -> MagicSurfaceCard
                                }
                            )
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = when {
                                isAccPro -> "👑 PRO TK"
                                isEffectivePro -> "📱 PRO MÁY"
                                u.revokedByAdmin -> "🚫 HẠ CẤP"
                                else -> "FREE"
                            },
                            color = when {
                                isAccPro -> MagicAmber
                                isEffectivePro -> MagicEmeraldLight
                                u.revokedByAdmin -> MagicRoseLight
                                else -> TextSecondary
                            },
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }

            // Row 2: Email (copyable) + Online time
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = u.email.ifBlank { "Chưa có Email (${u.userId.take(10)})" },
                        color = TextSecondary,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (u.email.contains("@")) {
                        IconButton(
                            onClick = { copyTextAdminQuick(context, "Email", u.email) },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy Email",
                                tint = MagicCyan,
                                modifier = Modifier.size(13.dp)
                            )
                        }
                    }
                }
                Text(
                    text = u.getLastActiveFormatted(),
                    color = if (onlineNow) MagicEmeraldLight else MagicCyanLight,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            // Row 3: Linked Devices Cross-Navigation Strip (Chỉ kích hoạt horizontalScroll khi có từ 3 máy trở lên để tối ưu 120fps cuộn)
            if (linkedDevices.isNotEmpty() || u.activeDeviceId.isNotBlank() || u.deviceId.isNotBlank()) {
                val shouldScrollDevices = linkedDevices.size > 2
                Row(
                    modifier = if (shouldScrollDevices) {
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
                    } else {
                        Modifier.fillMaxWidth()
                    },
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (linkedDevices.size > 1) "📱 ${linkedDevices.size} máy:" else "📱 Máy:",
                        color = if (linkedDevices.size > 1) MagicAmber else TextMuted,
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                    if (linkedDevices.isNotEmpty()) {
                        linkedDevices.take(4).forEach { ld ->
                            val isActiveSession = normActive.isNotBlank() &&
                                LicenseManager.normalizeDeviceIdForMatch(ld.deviceId) == normActive
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isActiveSession) MagicCyan.copy(alpha = 0.14f) else MagicSurfaceCard)
                                    .border(
                                        0.8.dp,
                                        if (isActiveSession) MagicCyan.copy(alpha = 0.45f) else MagicBorder,
                                        RoundedCornerShape(6.dp)
                                    )
                                    .clickable { onJumpToDevice(ld.deviceId) }
                                    .padding(horizontal = 6.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = "${ld.model.ifBlank { ld.deviceId }} (${ld.deviceId.take(11)}) ↗",
                                    color = if (isActiveSession) MagicCyanLight else TextSecondary,
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1
                                )
                            }
                        }
                    } else {
                        val fallbackId = u.activeDeviceId.ifBlank { u.deviceId }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicSurfaceCard)
                                .border(0.8.dp, MagicBorder, RoundedCornerShape(6.dp))
                                .clickable { onJumpToDevice(fallbackId) }
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "${u.activeDeviceModel.ifBlank { "Thiết bị" }} ($fallbackId) ↗",
                                color = MagicCyanLight,
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1
                            )
                        }
                    }
                }
            }

            // Row 4: Clean Primary Actions
            Row(
                modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = { onGrantOrChangeTier(u) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isEffectivePro) MagicSurfaceCard else MagicEmerald
                    ),
                    border = if (isEffectivePro) BorderStroke(1.dp, MagicCyan.copy(alpha = 0.45f)) else null,
                    modifier = Modifier
                        .fillMaxHeight()
                        .weight(1f)
                        .defaultMinSize(minHeight = 36.dp),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (isEffectivePro) "⚙️ Đổi Gói" else "⚡ Cấp Pro",
                        color = if (isEffectivePro) MagicCyanLight else Color(0xFF020617),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        maxLines = 1
                    )
                }

                if (u.activeDeviceId.isNotBlank() || isAccPro) {
                    OutlinedButton(
                        onClick = { onUnlockSession(u) },
                        border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .fillMaxHeight()
                            .weight(1f)
                            .defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "🔓 Đổi Máy",
                            color = MagicCyanLight,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Black,
                            maxLines = 1
                        )
                    }
                }

                if (isEffectivePro) {
                    Button(
                        onClick = { onDowngrade(u) },
                        colors = ButtonDefaults.buttonColors(containerColor = MagicRose),
                        modifier = Modifier
                            .fillMaxHeight()
                            .weight(0.9f)
                            .defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "🚫 Hạ Cấp",
                            color = Color.White,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Black,
                            maxLines = 1
                        )
                    }
                }

                FilledTonalIconButton(
                    onClick = onToggleExpand,
                    modifier = Modifier.size(48.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = IconButtonDefaults.filledTonalIconButtonColors(
                        containerColor = MagicSurfaceCard,
                        contentColor = MagicCyanLight
                    )
                ) {
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = if (isExpanded) "Thu gọn hồ sơ user" else "Mở rộng hồ sơ user",
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            AnimatedVisibility(visible = isExpanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MagicSurfaceCard)
                        .border(0.8.dp, MagicBorder, RoundedCornerShape(8.dp))
                        .padding(9.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Text(
                        text = "📅 Tham gia: ${u.getCreatedAtFormatted()} • UID: ${u.userId.take(14)}",
                        color = TextSecondary,
                        fontSize = 10.sp
                    )
                    if (u.phoneNumber.isNotBlank()) {
                        Text(
                            text = "📞 SĐT: ${u.phoneNumber}",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    if (isEffectivePro) {
                        val userProTimeStr = when {
                            u.proActivatedAt != null -> u.getProActivatedAtFormatted()
                            primaryDev?.proActivatedAt != null -> primaryDev.getProActivatedAtFormatted()
                            matchedBillLog != null -> matchedBillLog.getFormattedTime()
                            else -> "⚠️ Chưa có mốc giờ lên Pro"
                        }
                        val userProSourceStr = when {
                            u.proActivatedSource.isNotBlank() -> u.getProSourceFormatted()
                            primaryDev?.approvedByAiReason?.isNotBlank() == true -> primaryDev.getProSourceFormatted()
                            matchedBillLog != null -> "🤖 AI duyệt Bill (GD: ${matchedBillLog.bankTransCode.ifBlank { "Có bill" }})"
                            else -> "⚠️ Chưa rõ nguồn duyệt"
                        }
                        Text(
                            text = "⏰ Lên Pro: $userProTimeStr",
                            color = MagicEmeraldLight,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "📌 Nguồn: $userProSourceStr",
                            color = TextSecondary,
                            fontSize = 10.sp
                        )
                    }
                    if (u.hasPersonalAiKey()) {
                        Text(
                            text = "🔑 Đã nạp API Key AI riêng (${u.getPersonalGeminiKeysList().size} Gemini • ${u.getPersonalGroqKeysList().size} Groq)",
                            color = MagicCyanLight,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OutlinedButton(
                            onClick = { onLookupCloud(u.email.ifBlank { u.activeDeviceId.ifBlank { u.userId } }) },
                            modifier = Modifier.fillMaxHeight().defaultMinSize(minHeight = 36.dp),
                            shape = RoundedCornerShape(7.dp),
                            contentPadding = PaddingValues(horizontal = 9.dp, vertical = 2.dp)
                        ) {
                            Text("🔍 Tra Cloud Live", color = MagicCyanLight, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                        if (u.role != "admin") {
                            OutlinedButton(
                                onClick = { onUpgradeAdmin(u) },
                                modifier = Modifier.fillMaxHeight().defaultMinSize(minHeight = 36.dp),
                                shape = RoundedCornerShape(7.dp),
                                contentPadding = PaddingValues(horizontal = 9.dp, vertical = 2.dp)
                            ) {
                                Text("👑 Nâng Admin", color = MagicPurpleLight, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
