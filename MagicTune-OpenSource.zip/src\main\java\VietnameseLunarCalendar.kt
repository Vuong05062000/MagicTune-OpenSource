package com.example.core.widget

import java.util.Calendar
import java.util.Date
import kotlin.math.PI
import kotlin.math.floor
import kotlin.math.sin

/**
 * Bộ tính Lịch Vạn Niên (Âm - Dương Việt Nam) chuẩn xác theo thuật toán thiên văn Hồ Ngọc Đức (Múi giờ UTC+7).
 * Hỗ trợ:
 * - Quy đổi Dương lịch <-> Âm lịch chính xác cả tháng Nhuận (năm 1900 - 2100+)
 * - Tính Can Chi Năm, Tháng, Ngày
 * - Tính Giờ Hoàng Đạo theo ngày
 * - Nhận diện Lễ Tết Âm lịch & Dương lịch Việt Nam
 * - Dựng lưới 42 ô (6 tuần x 7 ngày từ Thứ 2 -> Chủ Nhật) cho Quyển Lịch Tháng
 */
object VietnameseLunarCalendar {

    private val CAN = arrayOf("Giáp", "Ất", "Bính", "Đinh", "Mậu", "Kỷ", "Canh", "Tân", "Nhâm", "Quý")
    private val CHI = arrayOf("Tý", "Sửu", "Dần", "Mão", "Thìn", "Tỵ", "Ngọ", "Mùi", "Thân", "Dậu", "Tuất", "Hợi")

    private val GIO_HOANG_DAO = arrayOf(
        "Tý (23-1h), Sửu (1-3h), Mão (5-7h), Ngọ (11-13h), Thân (15-17h), Dậu (17-19h)", // Tý, Ngọ
        "Dần (3-5h), Mão (5-7h), Tỵ (9-11h), Thân (15-17h), Tuất (19-21h), Hợi (21-23h)", // Sửu, Mùi
        "Tý (23-1h), Sửu (1-3h), Thìn (7-9h), Tỵ (9-11h), Mùi (13-15h), Tuất (19-21h)", // Dần, Thân
        "Tý (23-1h), Dần (3-5h), Mão (5-7h), Ngọ (11-13h), Mùi (13-15h), Dậu (17-19h)", // Mão, Dậu
        "Dần (3-5h), Thìn (7-9h), Tỵ (9-11h), Thân (15-17h), Dậu (17-19h), Hợi (21-23h)", // Thìn, Tuất
        "Sửu (1-3h), Thìn (7-9h), Ngọ (11-13h), Mùi (13-15h), Tuất (19-21h), Hợi (21-23h)" // Tỵ, Hợi
    )

    private val MONTH_NAMES_VI = arrayOf(
        "Giêng", "Hai", "Ba", "Tư", "Năm", "Sáu", "Bảy", "Tám", "Chín", "Mười", "Một", "Chạp"
    )

    data class LunarDate(
        val day: Int,
        val month: Int,
        val year: Int,
        val isLeapMonth: Boolean,
        val julianDay: Int
    ) {
        val yearCanChi: String
            get() = "${CAN[(year + 6) % 10]} ${CHI[(year + 8) % 12]}"

        val monthCanChi: String
            get() {
                val canIdx = (year * 12 + month + 3) % 10
                val chiIdx = (month + 1) % 12
                return "${CAN[canIdx]} ${CHI[chiIdx]}"
            }

        val dayCanChi: String
            get() = "${CAN[(julianDay + 9) % 10]} ${CHI[(julianDay + 1) % 12]}"

        val zodiacHours: String
            get() {
                val dayChiIdx = (julianDay + 1) % 12
                return GIO_HOANG_DAO[dayChiIdx % 6]
            }

        val lunarMonthName: String
            get() {
                val base = MONTH_NAMES_VI.getOrNull(month - 1) ?: month.toString()
                return if (isLeapMonth) "Tháng $base (Nhuận)" else "Tháng $base"
            }

        val shortDisplay: String
            get() = if (day == 1) {
                if (isLeapMonth) "1/${month}N" else "1/$month"
            } else {
                day.toString()
            }
    }

    data class CalendarDayCell(
        val solarDay: Int,
        val solarMonth: Int,
        val solarYear: Int,
        val dayOfWeekCol: Int, // 0 = T2 ... 5 = T7, 6 = CN
        val isCurrentMonth: Boolean,
        val isToday: Boolean,
        val lunar: LunarDate,
        val holidayName: String?
    ) {
        val isSpecialLunar: Boolean
            get() = lunar.day == 1 || lunar.day == 15 || !holidayName.isNullOrBlank()
    }

    fun jdFromDate(dd: Int, mm: Int, yy: Int): Int {
        val a = (14 - mm) / 12
        val y = yy + 4800 - a
        val m = mm + 12 * a - 3
        var jd = dd + (153 * m + 2) / 5 + 365 * y + y / 4 - y / 100 + y / 400 - 32045
        if (jd < 2299161) {
            jd = dd + (153 * m + 2) / 5 + 365 * y + y / 4 - 32083
        }
        return jd
    }

    private fun getNewMoonDay(k: Int, timeZone: Double = 7.0): Int {
        val t = k / 1236.85
        val t2 = t * t
        val t3 = t2 * t
        val dr = PI / 180.0
        var jd1 = 2415020.75933 + 29.53058868 * k + 0.0001178 * t2 - 0.000000155 * t3
        jd1 += 0.00033 * sin((166.56 + 132.87 * t - 0.009173 * t2) * dr)
        val m = 359.2242 + 29.10535608 * k - 0.0000333 * t2 - 0.00000347 * t3
        val mpr = 306.0253 + 385.81691806 * k + 0.0107306 * t2 + 0.00001236 * t3
        val f = 21.2964 + 390.67050646 * k - 0.0016528 * t2 - 0.00000239 * t3
        var c1 = (0.1734 - 0.000393 * t) * sin(m * dr) + 0.0021 * sin(2 * dr * m)
        c1 = c1 - 0.4068 * sin(mpr * dr) + 0.0161 * sin(dr * 2 * mpr)
        c1 -= 0.0004 * sin(dr * 3 * mpr)
        c1 = c1 + 0.0104 * sin(dr * 2 * f) - 0.0051 * sin(dr * (m + mpr))
        c1 = c1 - 0.0074 * sin(dr * (m - mpr)) + 0.0004 * sin(dr * (2 * f + m))
        c1 = c1 - 0.0004 * sin(dr * (2 * f - m)) - 0.0006 * sin(dr * (2 * f + mpr))
        c1 = c1 + 0.0010 * sin(dr * (2 * f - mpr)) + 0.0005 * sin(dr * (2 * mpr + m))
        val deltat = if (t < -11.0) {
            0.001 + 0.000839 * t + 0.0002261 * t2 - 0.00000845 * t3 - 0.000000081 * t * t3
        } else {
            -0.000278 + 0.000265 * t + 0.000262 * t2
        }
        val jdNew = jd1 + c1 - deltat
        return floor(jdNew + 0.5 + timeZone / 24.0).toInt()
    }

    private fun getSunLongitude(jdn: Int, timeZone: Double = 7.0): Int {
        val t = (jdn - 2451545.5 - timeZone / 24.0) / 36525.0
        val t2 = t * t
        val dr = PI / 180.0
        val m = 357.52910 + 35999.05030 * t - 0.0001559 * t2 - 0.00000048 * t * t2
        val l0 = 280.46645 + 36000.76983 * t + 0.0003032 * t2
        var dl = (1.914600 - 0.004817 * t - 0.000014 * t2) * sin(dr * m)
        dl += (0.019993 - 0.000101 * t) * sin(dr * 2 * m) + 0.000290 * sin(dr * 3 * m)
        var l = (l0 + dl) * dr
        l -= PI * 2 * floor(l / (PI * 2))
        return floor(l / PI * 6.0).toInt()
    }

    private fun getLunarMonth11(yy: Int, timeZone: Double = 7.0): Int {
        val off = jdFromDate(31, 12, yy) - 2415021
        val k = floor(off / 29.530588853).toInt()
        var nm = getNewMoonDay(k, timeZone)
        val sunLong = getSunLongitude(nm, timeZone)
        if (sunLong >= 9) {
            nm = getNewMoonDay(k - 1, timeZone)
        }
        return nm
    }

    private fun getLeapMonthOffset(a11: Int, timeZone: Double = 7.0): Int {
        val k = floor((a11 - 2415021.076998695) / 29.530588853 + 0.5).toInt()
        var last: Int
        var i = 1
        var arc = getSunLongitude(getNewMoonDay(k + i, timeZone), timeZone)
        do {
            last = arc
            i++
            arc = getSunLongitude(getNewMoonDay(k + i, timeZone), timeZone)
        } while (arc != last && i < 14)
        return i - 1
    }

    fun convertSolar2Lunar(dd: Int, mm: Int, yy: Int, timeZone: Double = 7.0): LunarDate {
        val dayNumber = jdFromDate(dd, mm, yy)
        val k = floor((dayNumber - 2415021.076998695) / 29.530588853).toInt()
        var monthStart = getNewMoonDay(k + 1, timeZone)
        if (monthStart > dayNumber) {
            monthStart = getNewMoonDay(k, timeZone)
        }
        var a11 = getLunarMonth11(yy, timeZone)
        var b11 = a11
        val lunarYear: Int
        if (a11 >= monthStart) {
            lunarYear = yy
            a11 = getLunarMonth11(yy - 1, timeZone)
        } else {
            lunarYear = yy + 1
            b11 = getLunarMonth11(yy + 1, timeZone)
        }
        val lunarDay = dayNumber - monthStart + 1
        val diff = floor((monthStart - a11) / 29.0).toInt()
        var lunarLeap = false
        var lunarMonth = diff + 11
        if (b11 - a11 > 365) {
            val leapMonthDiff = getLeapMonthOffset(a11, timeZone)
            if (diff >= leapMonthDiff) {
                lunarMonth = diff + 10
                if (diff == leapMonthDiff) {
                    lunarLeap = true
                }
            }
        }
        if (lunarMonth > 12) {
            lunarMonth -= 12
        }
        if (lunarMonth >= 11 && diff < 4) {
            // Year already belongs to previous lunar year when month is 11 or 12 near end of solar year
            return LunarDate(lunarDay, lunarMonth, lunarYear - 1, lunarLeap, dayNumber)
        }
        return LunarDate(lunarDay, lunarMonth, lunarYear, lunarLeap, dayNumber)
    }

    fun getHolidayName(solarDay: Int, solarMonth: Int, lunar: LunarDate): String? {
        if (!lunar.isLeapMonth) {
            when (lunar.month to lunar.day) {
                1 to 1 -> return "Mùng 1 Tết Nguyên Đán"
                1 to 2 -> return "Mùng 2 Tết Nguyên Đán"
                1 to 3 -> return "Mùng 3 Tết Nguyên Đán"
                1 to 15 -> return "Rằm Tháng Giêng"
                3 to 3 -> return "Tết Hàn Thực"
                3 to 10 -> return "Giỗ Tổ Hùng Vương"
                4 to 15 -> return "Lễ Phật Đản"
                5 to 5 -> return "Tết Đoan Ngọ"
                7 to 15 -> return "Lễ Vu Lan"
                8 to 15 -> return "Tết Trung Thu"
                10 to 10 -> return "Tết Thường Tân"
                12 to 23 -> return "Ông Công Ông Táo"
            }
        }
        return when (solarMonth to solarDay) {
            1 to 1 -> "Tết Dương Lịch"
            2 to 14 -> "Lễ Tình Nhân"
            3 to 8 -> "Quốc Tế Phụ Nữ"
            4 to 30 -> "Giải Phóng Miền Nam"
            5 to 1 -> "Quốc Tế Lao Động"
            6 to 1 -> "Quốc Tế Thiếu Nhi"
            9 to 2 -> "Quốc Khánh 2/9"
            10 to 20 -> "Phụ Nữ Việt Nam"
            11 to 20 -> "Nhà Giáo Việt Nam"
            12 to 25 -> "Lễ Giáng Sinh"
            else -> null
        }
    }

    fun formatCompactLunar(date: Date): String {
        val cal = Calendar.getInstance().apply { time = date }
        val lunar = convertSolar2Lunar(
            cal.get(Calendar.DAY_OF_MONTH),
            cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.YEAR)
        )
        val leapText = if (lunar.isLeapMonth) " (Nhuận)" else ""
        return "Ngày ${lunar.day}/${lunar.month}$leapText • Năm ${lunar.yearCanChi}"
    }

    fun buildDayCell(solarYear: Int, solarMonth: Int, solarDay: Int, isCurrentMonth: Boolean = true): CalendarDayCell {
        val todayCal = Calendar.getInstance()
        val isToday = solarYear == todayCal.get(Calendar.YEAR) &&
            solarMonth == (todayCal.get(Calendar.MONTH) + 1) &&
            solarDay == todayCal.get(Calendar.DAY_OF_MONTH)

        val cal = Calendar.getInstance().apply {
            set(solarYear, solarMonth - 1, solarDay, 12, 0, 0)
        }
        val dow = cal.get(Calendar.DAY_OF_WEEK)
        // Monday = 0, Tuesday = 1, ..., Sunday = 6
        val col = if (dow == Calendar.SUNDAY) 6 else (dow - Calendar.MONDAY)
        val lunar = convertSolar2Lunar(solarDay, solarMonth, solarYear)
        val holiday = getHolidayName(solarDay, solarMonth, lunar)
        return CalendarDayCell(
            solarDay = solarDay,
            solarMonth = solarMonth,
            solarYear = solarYear,
            dayOfWeekCol = col,
            isCurrentMonth = isCurrentMonth,
            isToday = isToday,
            lunar = lunar,
            holidayName = holiday
        )
    }

    /**
     * Tạo đủ 42 ô (6 hàng x 7 cột từ Thứ 2 -> Chủ Nhật) cho tháng dương lịch [month] (1..12), [year].
     */
    fun buildMonthGrid(year: Int, month: Int): List<CalendarDayCell> {
        val firstDayCal = Calendar.getInstance().apply {
            set(year, month - 1, 1, 12, 0, 0)
        }
        val dow = firstDayCal.get(Calendar.DAY_OF_WEEK)
        val leadingEmpty = if (dow == Calendar.SUNDAY) 6 else (dow - Calendar.MONDAY)
        val daysInMonth = firstDayCal.getActualMaximum(Calendar.DAY_OF_MONTH)

        val prevCal = Calendar.getInstance().apply {
            set(year, month - 1, 1, 12, 0, 0)
            add(Calendar.MONTH, -1)
        }
        val prevYear = prevCal.get(Calendar.YEAR)
        val prevMonth = prevCal.get(Calendar.MONTH) + 1
        val daysInPrevMonth = prevCal.getActualMaximum(Calendar.DAY_OF_MONTH)

        val nextCal = Calendar.getInstance().apply {
            set(year, month - 1, 1, 12, 0, 0)
            add(Calendar.MONTH, 1)
        }
        val nextYear = nextCal.get(Calendar.YEAR)
        val nextMonth = nextCal.get(Calendar.MONTH) + 1

        val cells = ArrayList<CalendarDayCell>(42)

        // Các ngày cuối tháng trước
        for (i in 0 until leadingEmpty) {
            val d = daysInPrevMonth - leadingEmpty + 1 + i
            cells.add(buildDayCell(prevYear, prevMonth, d, isCurrentMonth = false))
        }

        // Các ngày trong tháng hiện tại
        for (d in 1..daysInMonth) {
            cells.add(buildDayCell(year, month, d, isCurrentMonth = true))
        }

        // Các ngày đầu tháng sau cho đủ 42 ô (6 tuần)
        var nextDay = 1
        while (cells.size < 42) {
            cells.add(buildDayCell(nextYear, nextMonth, nextDay++, isCurrentMonth = false))
        }

        return cells
    }
}
