package com.example.core.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object PersonalAi {
    enum class Provider(val title: String, val base: String) {
        GEMINI("Gemini", "https://generativelanguage.googleapis.com/v1beta"),
        GROQ("Groq", "https://api.groq.com/openai/v1"),
        OPENAI("OpenAI", "https://api.openai.com/v1"),
        OPENROUTER("OpenRouter", "https://openrouter.ai/api/v1"),
        POLLINATIONS("Pollinations", "https://gen.pollinations.ai")
    }
    enum class Use(val title: String) { CHAT("Chat"), VISION("Đọc ảnh"), IMAGE("Tạo ảnh") }
    data class Account(val id: String, val provider: Provider, val name: String, val key: String)
    data class Model(val id: String, val title: String, val date: Long)
    data class Choice(val account: String, val model: String)
    private const val ALIAS = "magictune_personal_ai_v1"
    private val cooldown = java.util.concurrent.ConcurrentHashMap<String, Long>()

    private fun prefs(context: Context) = context.getSharedPreferences("personal_ai_v1", Context.MODE_PRIVATE)
    private fun encryptionKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply {
            init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        }.generateKey()
    }
    @Synchronized
    fun accounts(context: Context): List<Account> {
        val value = prefs(context).getString("vault", null) ?: return emptyList()
        val parts = value.split(".")
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, encryptionKey(), GCMParameterSpec(128, Base64.decode(parts[0], Base64.NO_WRAP)))
        val array = JSONArray(String(cipher.doFinal(Base64.decode(parts[1], Base64.NO_WRAP)), Charsets.UTF_8))
        return (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            Account(o.getString("id"), Provider.valueOf(o.getString("provider")), o.getString("name"), o.getString("key"))
        }
    }
    @Synchronized
    private fun write(context: Context, accounts: List<Account>) {
        val array = JSONArray()
        accounts.forEach { array.put(JSONObject().put("id", it.id).put("provider", it.provider.name).put("name", it.name).put("key", it.key)) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, encryptionKey())
        val encrypted = cipher.doFinal(array.toString().toByteArray(Charsets.UTF_8))
        check(prefs(context).edit().putString("vault", Base64.encodeToString(cipher.iv, Base64.NO_WRAP) + "." +
            Base64.encodeToString(encrypted, Base64.NO_WRAP)).commit()) { "Không lưu được khóa trên thiết bị." }
    }
    @Synchronized
    fun save(context: Context, provider: Provider, name: String, key: String, id: String? = null): String {
        require(key.isNotBlank()) { "Hãy nhập API key." }
        val list = accounts(context).toMutableList()
        val accountId = id ?: java.util.UUID.randomUUID().toString()
        list.removeAll { it.id == accountId }
        list.add(Account(accountId, provider, name.trim().ifBlank { provider.title }, key.trim()))
        write(context, list)
        cooldown.remove(accountId)
        return accountId
    }
    @Synchronized
    fun delete(context: Context, id: String) {
        write(context, accounts(context).filter { it.id != id })
        val editor = prefs(context).edit().remove("models_$id").remove("status_$id")
        Use.entries.forEach { if (choice(context, it)?.account == id) editor.remove("choice_${it.name}") }
        editor.apply()
        cooldown.remove(id)
    }
    fun choose(context: Context, use: Use, account: String, model: String) {
        prefs(context).edit().putString("choice_${use.name}", JSONObject().put("account", account).put("model", model).toString()).apply()
        cooldown.remove(account)
    }
    fun clearChoice(context: Context, use: Use) { prefs(context).edit().remove("choice_${use.name}").apply() }
    fun choice(context: Context, use: Use): Choice? = try {
        val o = JSONObject(prefs(context).getString("choice_${use.name}", "")!!)
        Choice(o.getString("account"), o.getString("model"))
    } catch (_: Exception) { null }
    fun status(context: Context, id: String) = prefs(context).getString("status_$id", "Chưa kiểm tra")!!
    private fun setStatus(context: Context, id: String, text: String) {
        prefs(context).edit().putString("status_$id", text).apply()
    }
    private fun modelArray(models: List<Model>): JSONArray = JSONArray().apply {
        models.forEach { put(JSONObject().put("id", it.id).put("title", it.title).put("date", it.date)) }
    }
    fun cachedModels(context: Context, id: String): List<Model> = try {
        val a = JSONArray(prefs(context).getString("models_$id", "[]"))
        (0 until a.length()).map { a.getJSONObject(it).let { o -> Model(o.getString("id"), o.getString("title"), o.optLong("date")) } }
    } catch (_: Exception) { emptyList() }

    // Dates from providers take priority. Natural version ordering is the fallback.
    fun sortModels(models: List<Model>): List<Model> = models.distinctBy { it.id }.sortedWith { a, b ->
        if (a.date != b.date) return@sortedWith b.date.compareTo(a.date)
        val left = Regex("""\d+|\D+""").findAll(a.id).map { it.value }.toList()
        val right = Regex("""\d+|\D+""").findAll(b.id).map { it.value }.toList()
        for (i in 0 until minOf(left.size, right.size)) {
            val x = left[i].toLongOrNull()
            val y = right[i].toLongOrNull()
            val c = if (x != null && y != null) y.compareTo(x) else right[i].compareTo(left[i], ignoreCase = true)
            if (c != 0) return@sortedWith c
        }
        right.size.compareTo(left.size)
    }
    private class ApiFailure(val code: Int) : Exception()
    private fun connection(account: Account, path: String, payload: JSONObject? = null): HttpURLConnection {
        return (URL(account.provider.base + path).openConnection() as HttpURLConnection).apply {
            instanceFollowRedirects = false
            connectTimeout = 8_000
            readTimeout = 60_000
            if (account.provider == Provider.GEMINI) setRequestProperty("x-goog-api-key", account.key)
            else setRequestProperty("Authorization", "Bearer ${account.key}")
            if (payload != null) {
                requestMethod = "POST"
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
            }
        }
    }
    private fun request(account: Account, path: String, payload: JSONObject? = null): String {
        val conn = connection(account, path, payload)
        try {
            if (payload != null) conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            if (conn.responseCode !in 200..299) throw ApiFailure(conn.responseCode)
            return conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally { conn.disconnect() }
    }
    private fun date(o: JSONObject): Long {
        val created = o.optLong("created", o.optLong("created_at", 0))
        if (created > 0) return if (created < 100_000_000_000L) created * 1000 else created
        val release = o.optString("release_date")
        return try {
            java.time.Instant.parse(release).toEpochMilli()
        } catch (_: Exception) {
            try { java.time.LocalDate.parse(release).atStartOfDay(java.time.ZoneOffset.UTC).toInstant().toEpochMilli() }
            catch (_: Exception) { 0 }
        }
    }
    suspend fun refresh(context: Context, id: String): List<Model> = withContext(Dispatchers.IO) {
        val account = accounts(context).first { it.id == id }
        try {
            val models = mutableListOf<Model>()
            if (account.provider == Provider.GEMINI) {
                var token = ""
                do {
                    val root = JSONObject(request(account, "/models?pageSize=100" +
                        if (token.isEmpty()) "" else "&pageToken=" + URLEncoder.encode(token, "UTF-8")))
                    val data = root.optJSONArray("models") ?: JSONArray()
                    for (i in 0 until data.length()) {
                        val o = data.getJSONObject(i)
                        val methods = o.optJSONArray("supportedGenerationMethods")?.toString().orEmpty()
                        if (methods.contains("generateContent")) models.add(Model(o.getString("name").removePrefix("models/"), o.optString("displayName"), date(o)))
                    }
                    token = root.optString("nextPageToken")
                } while (token.isNotEmpty())
            } else {
                val body = request(account, if (account.provider == Provider.POLLINATIONS) "/image/models" else "/models")
                val data = if (body.trim().startsWith("[")) JSONArray(body) else JSONObject(body).getJSONArray("data")
                for (i in 0 until data.length()) {
                    val o = data.getJSONObject(i)
                    val model = o.optString("id", o.optString("name"))
                    if (model.isNotBlank()) models.add(Model(model, o.optString("title", o.optString("name", model)), date(o)))
                }
            }
            val sorted = sortModels(models)
            prefs(context).edit().putString("models_$id", modelArray(sorted).toString()).apply()
            setStatus(context, id, "Đã tải ${sorted.size} model. Quyền gọi và hạn mức được kiểm tra khi dùng.")
            cooldown.remove(id)
            sorted
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) {
            setStatus(context, id, if (e is ApiFailure) "Lỗi HTTP ${e.code}. Khi gọi thất bại sẽ dùng khóa chung." else "Không tải được danh sách. Kiểm tra mạng hoặc khóa API.")
            throw IllegalStateException(status(context, id))
        }
    }
    private fun account(context: Context, use: Use): Pair<Account, String>? {
        val selected = choice(context, use) ?: return null
        val account = accounts(context).firstOrNull { it.id == selected.account } ?: return null
        if (android.os.SystemClock.elapsedRealtime() < (cooldown[account.id] ?: 0L)) return null
        return account to selected.model
    }
    private fun failed(context: Context, account: Account, e: Exception) {
        cooldown[account.id] = android.os.SystemClock.elapsedRealtime() + 60_000L
        setStatus(context, account.id, "Đang dự phòng sang khóa chung • " +
            if (e is ApiFailure) "HTTP ${e.code}" else "Không nhận được kết quả hợp lệ")
    }
    suspend fun reply(context: Context, system: String, prompt: String, image: String?,
        history: List<Pair<String, String>>, maxTokens: Int): String? = withContext(Dispatchers.IO) {
        if (com.example.core.perf.CpuHeatGuard.isHot()) return@withContext null
        var active: Account? = null
        try {
            val (account, model) = account(context, if (image.isNullOrBlank()) Use.CHAT else Use.VISION) ?: return@withContext null
            active = account
            if (account.provider == Provider.POLLINATIONS) return@withContext null
            val result = if (account.provider == Provider.GEMINI) {
                val contents = JSONArray()
                history.takeLast(8).forEach { (role, text) -> contents.put(JSONObject()
                    .put("role", if (role == "assistant" || role == "model") "model" else "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", text.take(2000))))) }
                val parts = JSONArray().put(JSONObject().put("text", prompt))
                if (!image.isNullOrBlank()) parts.put(JSONObject().put("inlineData",
                    JSONObject().put("mimeType", "image/jpeg").put("data", image.substringAfter("base64,", image))))
                contents.put(JSONObject().put("role", "user").put("parts", parts))
                val root = JSONObject(request(account, "/models/${model.removePrefix("models/")}:generateContent", JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                    .put("contents", contents).put("generationConfig", JSONObject().put("maxOutputTokens", maxTokens.coerceIn(64,4096)))))
                val response = root.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                (0 until (response?.length() ?: 0)).joinToString("") { response!!.getJSONObject(it).optString("text") }
            } else {
                val messages = JSONArray().put(JSONObject().put("role", "system").put("content", system))
                history.takeLast(8).forEach { (role,text) -> messages.put(JSONObject().put("role", if(role=="model") "assistant" else role).put("content",text.take(2000))) }
                val user = JSONObject().put("role","user")
                user.put("content", if (image.isNullOrBlank()) prompt else JSONArray()
                    .put(JSONObject().put("type","text").put("text",prompt))
                    .put(JSONObject().put("type","image_url").put("image_url",JSONObject().put("url","data:image/jpeg;base64,"+image.substringAfter("base64,", image)))))
                messages.put(user)
                val payload = JSONObject().put("model", model).put("messages", messages)
                val tokenParameter = if (account.provider == Provider.OPENAI) "max_completion_tokens" else "max_tokens"
                payload.put(tokenParameter, maxTokens.coerceIn(64, 4096))
                val root = JSONObject(request(account, "/chat/completions", payload))
                root.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content").orEmpty()
            }
            if (result.isBlank()) throw IllegalStateException()
            setStatus(context, account.id, "Đã dùng model $model")
            result
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { active?.let { failed(context,it,e) }; null }
    }
    suspend fun image(context: Context, prompt: String): Bitmap? = withContext(Dispatchers.IO) {
        if (com.example.core.perf.CpuHeatGuard.isHot()) return@withContext null
        var active: Account? = null
        try {
            val (account, model) = account(context, Use.IMAGE) ?: return@withContext null
            active = account
            val bytes = when (account.provider) {
                Provider.POLLINATIONS -> {
                    val path = "/image/" + URLEncoder.encode(prompt, "UTF-8") +
                        "?model=" + URLEncoder.encode(model, "UTF-8") +
                        "&width=768&height=768&seed=" + System.currentTimeMillis()
                    val conn = connection(account, path)
                    try {
                        if (conn.responseCode !in 200..299) throw ApiFailure(conn.responseCode)
                        conn.inputStream.use { it.readBytes() }
                    } finally {
                        conn.disconnect()
                    }
                }
                Provider.OPENAI -> {
                    val payload = JSONObject().put("model", model).put("prompt", prompt).put("n", 1)
                    if (model.startsWith("dall-e")) payload.put("response_format", "b64_json")
                    val root = JSONObject(request(account, "/images/generations", payload))
                    val data = root.getJSONArray("data").getJSONObject(0)
                    Base64.decode(data.getString("b64_json"), Base64.DEFAULT)
                }
                Provider.GEMINI -> {
                    val parts = JSONArray().put(JSONObject().put("text", prompt))
                    val contents = JSONArray().put(JSONObject().put("parts", parts))
                    val config = JSONObject().put("responseModalities", JSONArray().put("TEXT").put("IMAGE"))
                    val payload = JSONObject().put("contents", contents).put("generationConfig", config)
                    val root = JSONObject(request(account,
                        "/models/${model.removePrefix("models/")}:generateContent", payload))
                    val responseParts = root.getJSONArray("candidates").getJSONObject(0)
                        .getJSONObject("content").getJSONArray("parts")
                    val data = (0 until responseParts.length()).firstNotNullOfOrNull {
                        responseParts.getJSONObject(it).optJSONObject("inlineData")
                    } ?: throw IllegalStateException()
                    Base64.decode(data.getString("data"), Base64.DEFAULT)
                }
                Provider.OPENROUTER -> {
                    val messages = JSONArray().put(JSONObject().put("role", "user").put("content", prompt))
                    val payload = JSONObject().put("model", model).put("messages", messages)
                        .put("modalities", JSONArray().put("image").put("text"))
                    val root = JSONObject(request(account, "/chat/completions", payload))
                    val url = root.getJSONArray("choices").getJSONObject(0).getJSONObject("message")
                        .getJSONArray("images").getJSONObject(0).getJSONObject("image_url").getString("url")
                    check(url.startsWith("data:image/") && url.contains("base64,"))
                    Base64.decode(url.substringAfter("base64,"), Base64.DEFAULT)
                }
                Provider.GROQ -> throw IllegalStateException()
            }
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IllegalStateException()
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1536) sample *= 2
            val options = BitmapFactory.Options().apply { inSampleSize = sample }
            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
                ?: throw IllegalStateException()
            setStatus(context, account.id, "Đã tạo ảnh bằng $model")
            bitmap
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            active?.let { failed(context, it, e) }
            null
        }
    }
}
