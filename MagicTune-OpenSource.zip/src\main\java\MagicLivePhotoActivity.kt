package com.example.core.widget

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File

class MagicLivePhotoActivity : ComponentActivity() {
    private var cameraFile: File? = null
    private val camera = registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        consume(if (success) cameraFile?.let { Uri.fromFile(it) } else null)
    }
    private val gallery = registerForActivityResult(ActivityResultContracts.GetContent()) { uri -> consume(uri) }
    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) capture() else consume(null)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraFile = savedInstanceState?.getString("cameraFile")?.let(::File)
        if (savedInstanceState != null) return
        try {
            if (intent.getStringExtra("source") == "camera") {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) capture()
                else permission.launch(Manifest.permission.CAMERA)
            } else gallery.launch("image/*")
        } catch (_: Exception) {
            Toast.makeText(this, "Không mở được camera hoặc thư viện ảnh.", Toast.LENGTH_LONG).show()
            consume(null)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putString("cameraFile", cameraFile?.absolutePath)
        super.onSaveInstanceState(outState)
    }

    private fun capture() {
        try {
            val file = File.createTempFile("magiclive_camera_", ".jpg", cacheDir)
            cameraFile = file
            camera.launch(FileProvider.getUriForFile(this, "$packageName.fileprovider", file))
        } catch (_: Exception) {
            Toast.makeText(this, "Không mở được ứng dụng camera.", Toast.LENGTH_LONG).show()
            consume(null)
        }
    }

    private fun consume(uri: Uri?) {
        lifecycleScope.launch {
            val encoded = withContext(Dispatchers.IO) {
                try {
                    if (uri == null) return@withContext null
                    val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                    if (opts.outWidth <= 0 || opts.outHeight <= 0) return@withContext null
                    opts.inJustDecodeBounds = false
                    var sample = 1
                    while (maxOf(opts.outWidth, opts.outHeight) / sample > 1600) sample *= 2
                    opts.inSampleSize = sample
                    val bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                        ?: return@withContext null
                    val orientation = try {
                        contentResolver.openInputStream(uri)?.use {
                            android.media.ExifInterface(it).getAttributeInt(
                                android.media.ExifInterface.TAG_ORIENTATION, android.media.ExifInterface.ORIENTATION_NORMAL)
                        }
                    } catch (_: Exception) { null }
                    val transform = Matrix()
                    when (orientation) {
                        2 -> transform.setScale(-1f, 1f)
                        3 -> transform.setRotate(180f)
                        4 -> transform.setScale(1f, -1f)
                        5 -> { transform.setRotate(90f); transform.postScale(-1f, 1f) }
                        6 -> transform.setRotate(90f)
                        7 -> { transform.setRotate(270f); transform.postScale(-1f, 1f) }
                        8 -> transform.setRotate(270f)
                    }
                    val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, transform, true)
                    try {
                        val out = ByteArrayOutputStream()
                        rotated.compress(Bitmap.CompressFormat.JPEG, 85, out)
                        Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
                    } finally {
                        if (rotated !== bitmap) rotated.recycle()
                        bitmap.recycle()
                    }
                } catch (_: Exception) { null }
                finally { cameraFile?.delete() }
            }
            val circle = intent.getBooleanExtra("circle", false)
            if (circle) {
                val googleSearch = intent.getBooleanExtra("googleSearch", false)
                if (googleSearch) {
                    if (encoded != null) CircleToSearchWindowOverlay.searchCapturedPhoto(applicationContext, encoded)
                    else CircleToSearchWindowOverlay.show(applicationContext, googleSearch = true)
                } else if (encoded != null) MagicLiveFloatingOverlay.showWithAttachedScreenQuery(this@MagicLivePhotoActivity, encoded)
                else CircleToSearchWindowOverlay.show(applicationContext)
            } else {
                MagicLiveFloatingOverlay.resumeAfterPhotoPicker(applicationContext, encoded)
            }
            if (uri != null && encoded == null) Toast.makeText(this@MagicLivePhotoActivity, "Không đọc được ảnh đã chọn.", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    companion object {
        fun launch(context: android.content.Context, source: String, circle: Boolean = false, googleSearch: Boolean = false) {
            context.startActivity(Intent(context, MagicLivePhotoActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                putExtra("source", source)
                putExtra("circle", circle)
                putExtra("googleSearch", googleSearch)
            })
        }
    }
}
