package com.example.ui.components

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.runtime.collectAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import com.example.core.auth.FirebaseAuthManager
import com.example.core.license.LicenseManager
import com.example.data.APP_VERSION_NAME
import com.example.ui.theme.MagicAmber
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicCyanLight
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicEmeraldLight
import com.example.ui.theme.MagicPurple
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.MagicSurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch

@Composable
fun LoginScreen(
    onNavigateBack: () -> Unit,
    onLoginSuccess: () -> Unit,
    onNavigateToAccount: () -> Unit = {}
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }
    val scrollState = rememberScrollState()

    val authSession by FirebaseAuthManager.authSessionFlow.collectAsState()
    var currentUser by remember(authSession) { mutableStateOf(FirebaseAuthManager.getCurrentUser()) }
    var emailInput by remember { mutableStateOf("") }
    var passwordInput by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    var isSignUpMode by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var isSuccessMessage by remember { mutableStateOf(false) }

    val proStateVersion by LicenseManager.proStateVersionFlow.collectAsState()
    val isSimulateFree = remember(proStateVersion) { LicenseManager.isAdminSimulateFreeMode(context) }
    val isProActivated = remember(proStateVersion) { !isSimulateFree && LicenseManager.isProActivated(context) }
    val isAdminUser = remember(proStateVersion, authSession) { !isSimulateFree && (authSession.isAdmin || LicenseManager.isCurrentUserAdmin(context)) }

    LaunchedEffect(authSession) {
        currentUser = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            FirebaseAuthManager.getCurrentUser()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(scrollState)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Top Header Bar với nút Quay lại
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(MagicSurfaceCard)
                    .border(1.dp, MagicBorder, RoundedCornerShape(10.dp))
                    .clickable { onNavigateBack() }
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Quay lại", tint = Color.White, modifier = Modifier.size(16.dp))
                    Text(text = "Trở Về", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(MagicCyan.copy(alpha = 0.15f))
                    .border(1.dp, MagicCyan.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "☁️ MAGICTUNE CLOUD ${APP_VERSION_NAME.uppercase()}",
                    color = MagicCyanLight,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black
                )
            }
        }

        // Trường hợp ĐÃ ĐĂNG NHẬP -> Hiển thị Thẻ Hồ Sơ Trực Quan
        if (currentUser != null) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                border = BorderStroke(1.5.dp, Brush.horizontalGradient(listOf(MagicEmerald, MagicCyan)))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(listOf(MagicCyan, MagicPurple))),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = Color.White, modifier = Modifier.size(28.dp))
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = currentUser?.displayName?.ifBlank { "Thành Viên MagicTune" } ?: "Thành Viên MagicTune",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = currentUser?.email ?: "Email xác thực qua Cloud",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isAdminUser) MagicAmber.copy(alpha = 0.2f) else MagicEmerald.copy(alpha = 0.2f))
                                .border(1.dp, if (isAdminUser) MagicAmber else MagicEmerald, RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            val isAccPro = remember(isProActivated) { LicenseManager.isAccountProActivated(context) }
                            Text(
                                text = when {
                                    isAdminUser -> "👑 ADMIN"
                                    isProActivated && isAccPro -> "👑 PRO TÀI KHOẢN"
                                    isProActivated -> "💎 PRO THIẾT BỊ"
                                    else -> "👤 USER"
                                },
                                color = if (isAdminUser) MagicAmber else MagicEmeraldLight,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF020617))
                            .padding(12.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = MagicEmerald, modifier = Modifier.size(16.dp))
                                Text(text = "Đã xác thực tài khoản an toàn", color = MagicEmerald, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Text(
                                text = "Bản quyền Pro và cấu hình máy của bạn đã được lưu vĩnh viễn trên đám mây Firebase Cloud. Bạn có thể sử dụng đầy đủ các tính năng độc quyền.",
                                color = TextSecondary,
                                fontSize = 11.sp,
                                lineHeight = 15.5.sp
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onNavigateToAccount() },
                            modifier = Modifier.weight(1f).heightIn(min = 44.dp),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MagicCyan, contentColor = Color(0xFF020617))
                        ) {
                            Icon(imageVector = Icons.Default.Person, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "Quản Lý Tài Khoản", fontSize = 11.5.sp, fontWeight = FontWeight.Black)
                        }

                        Button(
                            onClick = {
                                FirebaseAuthManager.signOut(context, credentialManager, coroutineScope) {
                                    currentUser = null
                                    Toast.makeText(context, "Đã đăng xuất tài khoản", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.heightIn(min = 44.dp),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626), contentColor = Color.White)
                        ) {
                            Text(text = "Đăng Xuất", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        } else {
            // Trường hợp CHƯA ĐĂNG NHẬP -> Form Đăng Nhập / Đăng Ký Đẹp Mắt
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                border = BorderStroke(1.5.dp, Brush.horizontalGradient(listOf(MagicCyan, MagicPurple)))
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Chữ Tiêu đề + Icon Account
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(MagicCyan.copy(alpha = 0.15f))
                                .border(1.dp, MagicCyan, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.AccountCircle, contentDescription = null, tint = MagicCyan, modifier = Modifier.size(26.dp))
                        }
                        Column {
                            Text(
                                text = if (isSignUpMode) "ĐĂNG KÝ TÀI KHOẢN CLOUD" else "ĐĂNG NHẬP MAGICTUNE CLOUD",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "Đồng bộ cấu hình & kích hoạt bản quyền Pro vĩnh viễn",
                                color = TextSecondary,
                                fontSize = 11.5.sp
                            )
                        }
                    }

                    // Input Email
                    OutlinedTextField(
                        value = emailInput,
                        onValueChange = { emailInput = it },
                        label = { Text("Địa chỉ Email", fontSize = 11.5.sp) },
                        placeholder = { Text("nhap_email@gmail.com", fontSize = 11.sp, color = TextMuted) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = MagicCyan) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MagicCyan,
                            unfocusedBorderColor = MagicBorder,
                            focusedLabelColor = MagicCyan,
                            unfocusedLabelColor = TextSecondary,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Gợi ý Email nhanh (Quick Email Chips)
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "💡 Gợi ý nhập nhanh Email:",
                            color = TextSecondary,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            val emailChips = listOf(
                                "@gmail.com",
                                "@icloud.com",
                                "@outlook.com",
                                "@yahoo.com",
                                "admin@magictune.com",
                                "vip@magictune.com"
                            )
                            emailChips.forEach { chip ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(MagicCyan.copy(alpha = 0.15f))
                                        .border(1.dp, MagicCyan.copy(alpha = 0.45f), RoundedCornerShape(8.dp))
                                        .clickable {
                                            if (chip.startsWith("@")) {
                                                val prefix = if (emailInput.contains("@")) emailInput.substringBefore("@") else emailInput
                                                emailInput = if (prefix.isBlank()) "user$chip" else "$prefix$chip"
                                            } else {
                                                emailInput = chip
                                            }
                                        }
                                        .padding(horizontal = 8.dp, vertical = 5.dp)
                                ) {
                                    Text(
                                        text = chip,
                                        color = MagicCyanLight,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    // Input Mật khẩu
                    OutlinedTextField(
                        value = passwordInput,
                        onValueChange = { passwordInput = it },
                        label = { Text("Mật khẩu", fontSize = 11.5.sp) },
                        singleLine = true,
                        visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = MagicCyan) },
                        trailingIcon = {
                            Icon(
                                imageVector = if (isPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = "Hiện/Ẩn mật khẩu",
                                tint = TextSecondary,
                                modifier = Modifier.clickable { isPasswordVisible = !isPasswordVisible }
                            )
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MagicCyan,
                            unfocusedBorderColor = MagicBorder,
                            focusedLabelColor = MagicCyan,
                            unfocusedLabelColor = TextSecondary,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Nút Quên mật khẩu
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Text(
                            text = "🔑 Quên mật khẩu?",
                            color = MagicAmber,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable {
                                if (emailInput.isBlank()) {
                                    statusMessage = "⚠️ Vui lòng nhập địa chỉ Email vào ô bên trên để gửi liên kết khôi phục mật khẩu!"
                                    isSuccessMessage = false
                                } else {
                                    coroutineScope.launch {
                                        isLoading = true
                                        statusMessage = "⏳ Đang gửi email khôi phục mật khẩu tới $emailInput..."
                                        isSuccessMessage = false
                                        try {
                                            FirebaseAuthManager.sendPasswordResetEmail(emailInput.trim())
                                            isLoading = false
                                            isSuccessMessage = true
                                            statusMessage = "📧 Đã gửi liên kết khôi phục mật khẩu tới $emailInput! Vui lòng kiểm tra hộp thư (bao gồm cả thư rác/spam)."
                                        } catch (e: Exception) {
                                            isLoading = false
                                            isSuccessMessage = false
                                            statusMessage = "❌ ${FirebaseAuthManager.translateAuthError(e)}"
                                        }
                                    }
                                }
                            }
                        )
                    }

                    // Hiển thị Thông Báo Trạng Thái
                    if (statusMessage != null) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSuccessMessage) MagicEmerald.copy(alpha = 0.2f) else Color(0xFFEF4444).copy(alpha = 0.2f))
                                .border(1.dp, if (isSuccessMessage) MagicEmerald else Color(0xFFEF4444), RoundedCornerShape(10.dp))
                                .padding(10.dp)
                        ) {
                            Text(
                                text = statusMessage ?: "",
                                color = if (isSuccessMessage) MagicEmeraldLight else Color(0xFFFF8888),
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Nút Đăng Nhập / Đăng Ký
                    Button(
                        onClick = {
                            val trimmedEmail = emailInput.trim()
                            val trimmedPass = passwordInput.trim()
                            if (trimmedEmail.isBlank()) {
                                statusMessage = "⚠️ Vui lòng nhập địa chỉ Email!"
                                isSuccessMessage = false
                                return@Button
                            }
                            if (!trimmedEmail.contains("@") || !trimmedEmail.contains(".")) {
                                statusMessage = "⚠️ Địa chỉ Email không đúng định dạng chuẩn (ví dụ: user@gmail.com)!"
                                isSuccessMessage = false
                                return@Button
                            }
                            if (trimmedPass.isBlank()) {
                                statusMessage = "⚠️ Vui lòng nhập Mật khẩu!"
                                isSuccessMessage = false
                                return@Button
                            }
                            if (isSignUpMode && trimmedPass.length < 6) {
                                statusMessage = "⚠️ Mật khẩu đăng ký phải có ít nhất 6 ký tự!"
                                isSuccessMessage = false
                                return@Button
                            }

                            coroutineScope.launch {
                                isLoading = true
                                statusMessage = "⏳ Đang xử lý tài khoản..."
                                isSuccessMessage = false
                                try {
                                    val user = if (isSignUpMode) {
                                        FirebaseAuthManager.signUpWithEmail(
                                            email = trimmedEmail,
                                            pass = trimmedPass,
                                            name = trimmedEmail.substringBefore("@")
                                        )
                                    } else {
                                        FirebaseAuthManager.signInWithEmail(
                                            email = trimmedEmail,
                                            pass = trimmedPass
                                        )
                                    }
                                    coroutineScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                                        try {
                                            FirebaseAuthManager.syncUserProfile(context)
                                        } catch (_: Exception) {}
                                    }
                                    isLoading = false
                                    currentUser = user
                                    isSuccessMessage = true
                                    statusMessage = if (isSignUpMode) "🎉 Đăng ký tài khoản thành công!" else "🎉 Đăng nhập thành công!"
                                    onLoginSuccess()
                                } catch (e: Exception) {
                                    isLoading = false
                                    isSuccessMessage = false
                                    statusMessage = "❌ ${FirebaseAuthManager.translateAuthError(e)}"
                                }
                            }
                        },
                        enabled = !isLoading,
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MagicCyan, contentColor = Color(0xFF020617))
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color(0xFF020617), strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Đang xử lý...", fontWeight = FontWeight.Black, fontSize = 12.5.sp)
                        } else {
                            Text(
                                text = if (isSignUpMode) "TẠO TÀI KHOẢN MỚI" else "ĐĂNG NHẬP NGAY",
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp
                            )
                        }
                    }

                    // Nút Chuyển Đổi Đăng Nhập <-> Đăng Ký
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isSignUpMode) "Đã có tài khoản?" else "Chưa có tài khoản?",
                            color = TextSecondary,
                            fontSize = 11.5.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isSignUpMode) "Đăng nhập ngay" else "Đăng ký mới",
                            color = MagicCyanLight,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.clickable {
                                isSignUpMode = !isSignUpMode
                                statusMessage = null
                            }
                        )
                    }
                }
            }
        }

        // Bảng Đặc Quyền Quyền Lợi Tài Khoản MagicTune Cloud
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(imageVector = Icons.Default.Star, contentDescription = null, tint = MagicAmber, modifier = Modifier.size(16.dp))
                    Text(text = "ĐẶC QUYỀN TÀI KHOẢN MAGICTUNE CLOUD", color = MagicAmber, fontSize = 12.sp, fontWeight = FontWeight.Black)
                }

                val perks = listOf(
                    "👑 Xác thực bản quyền Pro chính chủ trên thiết bị quen thuộc hoặc đã kích hoạt",
                    "☁️ Tự động lưu & đồng bộ thiết lập mượt mà qua đám mây Firebase",
                    "📦 Quyền gửi & chia sẻ ứng dụng độc quyền lên Kho App Cộng Đồng",
                    "💬 Chat trực tiếp với Trợ lý AI MagicTune & Đội ngũ hỗ trợ kỹ thuật"
                )

                perks.forEach { perk ->
                    Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(text = "•", color = MagicCyan, fontSize = 12.sp, fontWeight = FontWeight.Black)
                        Text(text = perk, color = Color.White.copy(alpha = 0.9f), fontSize = 11.sp, lineHeight = 15.sp)
                    }
                }
            }
        }
    }
}
