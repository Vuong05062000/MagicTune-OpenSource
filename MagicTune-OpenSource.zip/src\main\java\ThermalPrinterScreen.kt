package com.example.ui.components

import android.Manifest
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.DisposableEffect
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.printer.ConnectionType
import com.example.core.printer.CustomReceiptData
import com.example.core.printer.EscPosThermalPrinter
import com.example.core.printer.PairedBluetoothPrinter
import com.example.core.printer.PrintSourceMode
import com.example.core.printer.PrinterConfig
import com.example.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ThermalPrinterScreen(
    sharedUri: Uri?,
    isPrinting: Boolean,
    statusMessage: String,
    onSetPrinting: (Boolean) -> Unit,
    onSetStatusMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val initialConfig = remember { EscPosThermalPrinter.loadSavedConfig(context) }

    var connectionType by remember { mutableStateOf(initialConfig.connectionType) }
    var printerIp by remember { mutableStateOf(initialConfig.ip) }
    var printerPort by remember { mutableStateOf(initialConfig.port.toString()) }
    var bluetoothAddress by remember { mutableStateOf(initialConfig.bluetoothAddress) }
    var bluetoothName by remember { mutableStateOf(initialConfig.bluetoothName) }

    var paperWidthDots by remember { mutableIntStateOf(initialConfig.paperWidthDots) } // 576 = K80, 512 = K76, 384 = K57
    var densityLevel by remember { mutableIntStateOf(initialConfig.densityLevel) } // 1..5
    var autoCut by remember { mutableStateOf(initialConfig.autoCut) }
    var boldDilation by remember { mutableStateOf(initialConfig.boldFontDilation) }
    var autoTrimBottom by remember { mutableStateOf(initialConfig.autoTrimBottom) }
    var feedLines by remember { mutableIntStateOf(initialConfig.feedLinesAfterPrint) }
    var marginLeftDots by remember { mutableIntStateOf(initialConfig.marginLeftDots) }
    var marginRightDots by remember { mutableIntStateOf(initialConfig.marginRightDots) }
    var copiesCount by remember { mutableIntStateOf(initialConfig.copiesCount) }

    var selectedUri by remember { mutableStateOf<Uri?>(sharedUri) }
    var pdfPageCount by remember { mutableIntStateOf(0) }
    var currentPdfPage by remember { mutableIntStateOf(0) }

    var savedIps by remember { mutableStateOf(EscPosThermalPrinter.getSavedIpHistory(context)) }
    var discoveredIps by remember { mutableStateOf<List<String>>(emptyList()) }
    var pairedBtPrinters by remember { mutableStateOf<List<PairedBluetoothPrinter>>(emptyList()) }
    var isScanning by remember { mutableStateOf(false) }
    var previewBitmap by remember { mutableStateOf<Bitmap?>(null) }

    DisposableEffect(Unit) {
        onDispose {
            previewBitmap = null
        }
    }
    val phoneWifiIp = remember { EscPosThermalPrinter.getPhoneWifiIpAddress() }

    fun buildCurrentConfig(): PrinterConfig {
        return PrinterConfig(
            connectionType = connectionType,
            ip = printerIp.trim(),
            port = printerPort.toIntOrNull() ?: 9100,
            bluetoothAddress = bluetoothAddress,
            bluetoothName = bluetoothName,
            paperWidthDots = paperWidthDots,
            autoCut = autoCut,
            densityLevel = densityLevel,
            boldFontDilation = boldDilation,
            autoTrimBottom = autoTrimBottom,
            openCashDrawer = false,
            feedLinesAfterPrint = feedLines,
            marginLeftDots = marginLeftDots,
            marginRightDots = marginRightDots,
            copiesCount = copiesCount
        )
    }

    // Tự động lưu cấu hình mỗi khi người dùng thay đổi thiết lập
    LaunchedEffect(
        connectionType, printerIp, printerPort, bluetoothAddress, bluetoothName,
        paperWidthDots, densityLevel, autoCut, boldDilation, autoTrimBottom,
        feedLines, marginLeftDots, marginRightDots, copiesCount
    ) {
        EscPosThermalPrinter.saveConfig(context, buildCurrentConfig())
    }

    // Nhận tệp mới khi người dùng bấm Chia sẻ (Share) từ Shopee / TikTok / Zalo sang MagicTune
    LaunchedEffect(sharedUri) {
        if (sharedUri != null) {
            selectedUri = sharedUri
            currentPdfPage = 0
            onSetStatusMessage("📥 Đã nhận tệp in từ ứng dụng ngoài: ${sharedUri.lastPathSegment ?: "Tài liệu/Đơn hàng"}")
        }
    }

    val btPermLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val granted = result.values.all { it }
        if (granted || EscPosThermalPrinter.hasBluetoothPermission(context)) {
            val list = EscPosThermalPrinter.getPairedBluetoothPrinters(context)
            pairedBtPrinters = list
            val firstBt = list.firstOrNull()
            if (firstBt != null && bluetoothAddress.isBlank()) {
                bluetoothAddress = firstBt.address
                bluetoothName = firstBt.name
            }
            onSetStatusMessage(
                if (list.isNotEmpty()) "📘 Đã tìm thấy ${list.size} thiết bị Bluetooth đã ghép đôi."
                else "⚠️ Chưa có máy in Bluetooth nào được ghép đôi trong Cài đặt máy."
            )
        } else {
            onSetStatusMessage("⚠️ Cần cấp quyền Kết nối Thiết bị lân cận (Bluetooth) để tìm máy in Bluetooth.")
        }
    }

    // Tự động tải danh sách Bluetooth khi chuyển sang chế độ Bluetooth
    LaunchedEffect(connectionType) {
        if (connectionType == ConnectionType.BLUETOOTH) {
            if (EscPosThermalPrinter.hasBluetoothPermission(context)) {
                val list = EscPosThermalPrinter.getPairedBluetoothPrinters(context)
                pairedBtPrinters = list
                val firstBt = list.firstOrNull()
                if (firstBt != null && bluetoothAddress.isBlank()) {
                    bluetoothAddress = firstBt.address
                    bluetoothName = firstBt.name
                }
            }
        }
    }

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedUri = uri
            currentPdfPage = 0
            onSetStatusMessage("📄 Đã tải tệp: ${uri.lastPathSegment ?: "Đơn hàng"}")
        }
    }

    // Cập nhật Live Preview tức thì khi thay đổi tệp in, trang PDF hoặc thông số chất lượng
    LaunchedEffect(
        selectedUri, currentPdfPage, paperWidthDots,
        boldDilation, densityLevel, autoTrimBottom, marginLeftDots, marginRightDots
    ) {
        val targetUri = selectedUri
        if (targetUri == null) {
            pdfPageCount = 0
            previewBitmap = null
            return@LaunchedEffect
        }
        val bmpPair = withContext(Dispatchers.IO) {
            try {
                val mime = context.contentResolver.getType(targetUri).orEmpty()
                val uriStr = targetUri.toString()
                val isPdf = mime.contains("pdf", true) ||
                    uriStr.contains("pdf", true) ||
                    targetUri.path?.endsWith(".pdf", true) == true
                if (isPdf) {
                    val count = EscPosThermalPrinter.getPdfPageCount(context, targetUri)
                    val safePage = if (count > 0) currentPdfPage.coerceIn(0, count - 1) else 0
                    val rendered = EscPosThermalPrinter.renderPdfPageToBitmap(
                        context = context,
                        pdfUri = targetUri,
                        pageIndex = safePage,
                        targetWidth = paperWidthDots
                    )
                    Pair(rendered, count)
                } else {
                    val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    context.contentResolver.openInputStream(targetUri)?.use { input ->
                        BitmapFactory.decodeStream(input, null, boundsOpts)
                    }
                    var sampleSize = 1
                    val maxDim = maxOf(boundsOpts.outWidth, boundsOpts.outHeight)
                    if (maxDim > 2048) {
                        while ((maxDim / sampleSize) > 2048) {
                            sampleSize *= 2
                        }
                    }
                    val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sampleSize }
                    val decoded = context.contentResolver.openInputStream(targetUri)?.use { input ->
                        BitmapFactory.decodeStream(input, null, decodeOpts)
                    }
                    if (decoded != null) {
                        Pair(decoded, 0)
                    } else {
                        // Thử fallback coi như PDF nếu tên file không có đuôi .pdf
                        val fallbackCount = EscPosThermalPrinter.getPdfPageCount(context, targetUri)
                        if (fallbackCount > 0) {
                            val safePage = currentPdfPage.coerceIn(0, fallbackCount - 1)
                            val rendered = EscPosThermalPrinter.renderPdfPageToBitmap(
                                context = context,
                                pdfUri = targetUri,
                                pageIndex = safePage,
                                targetWidth = paperWidthDots
                            )
                            Pair(rendered, fallbackCount)
                        } else {
                            Pair(null, 0)
                        }
                    }
                }
            } catch (_: Throwable) {
                Pair(null, 0)
            }
        }

        pdfPageCount = bmpPair.second
        val rawBmp = bmpPair.first
        previewBitmap = if (rawBmp != null && rawBmp.width > 0 && rawBmp.height > 0) {
            try {
                withContext(Dispatchers.Default) {
                    EscPosThermalPrinter.createPreviewBitmap(
                        sourceBitmap = rawBmp,
                        paperWidthDots = paperWidthDots,
                        marginLeftDots = marginLeftDots,
                        marginRightDots = marginRightDots,
                        boldFontDilation = boldDilation,
                        densityLevel = densityLevel,
                        autoTrimBottom = autoTrimBottom,
                        maxHeightPx = 3072
                    )
                }
            } catch (t: Throwable) {
                onSetStatusMessage("⚠️ Không thể tạo bản xem trước tệp này (${t.localizedMessage ?: "Tệp quá lớn hoặc lỗi định dạng"}). Hãy thử ảnh/PDF khác.")
                null
            }
        } else {
            null
        }
    }

    val printerScrollState = rememberScrollState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(printerScrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // ==================== HEADER & TRẠNG THÁI TỔNG QUAN ====================
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
            border = BorderStroke(1.2.dp, MagicCyan.copy(alpha = 0.45f))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicCyan.copy(alpha = 0.22f))
                                .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "Ô #50",
                                color = MagicCyanLight,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.Print,
                            contentDescription = null,
                            tint = MagicCyan,
                            modifier = Modifier.size(19.dp)
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicCyan.copy(alpha = 0.16f))
                                .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 7.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = if (connectionType == ConnectionType.WIFI_LAN) "Wi-Fi / LAN" else "Bluetooth",
                                color = MagicCyanLight,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicEmerald.copy(alpha = 0.2f))
                                .border(1.dp, MagicEmerald, RoundedCornerShape(6.dp))
                                .padding(horizontal = 7.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = when (paperWidthDots) {
                                    576 -> "K80 (80mm)"
                                    512 -> "K76 (76mm)"
                                    else -> "K57 (58mm)"
                                },
                                color = MagicEmeraldLight,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
                Text(
                    text = "MÁY IN NHIỆT K80 / K57 PRO",
                    color = MagicCyan,
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    text = statusMessage.ifBlank {
                        "Sẵn sàng in đơn Shopee, TikTok Shop, Lazada, ViettelPost, hóa đơn PDF nhiều trang & ảnh qua mạng Wi-Fi/LAN (Cổng 9100) hoặc Bluetooth SPP."
                    },
                    color = TextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 16.5.sp
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF0F172A))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Text(
                        text = "📱 IP Wi-Fi máy: $phoneWifiIp",
                        color = MagicCyanLight,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        text = "💡 Hỗ trợ Chia sẻ (Share) trực tiếp từ Shopee/Zalo",
                        color = MagicEmeraldLight,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // ==================== 1. CẤU HÌNH KẾT NỐI MÁY IN (WI-FI/LAN & BLUETOOTH) ====================
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = BorderStroke(1.dp, MagicBorder)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MagicCyan.copy(alpha = 0.22f))
                            .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text("Ô #51", color = MagicCyanLight, fontSize = 10.sp, fontWeight = FontWeight.Black)
                    }
                }
                Text(
                    text = "1. PHƯƠNG THỨC KẾT NỐI MÁY IN",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.fillMaxWidth()
                )

                // Chuyển đổi Wi-Fi/LAN và Bluetooth
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { connectionType = ConnectionType.WIFI_LAN },
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 44.dp)
                            .testTag("printer_mode_wifi_btn"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (connectionType == ConnectionType.WIFI_LAN) MagicCyan else MagicSurfaceCard,
                            contentColor = if (connectionType == ConnectionType.WIFI_LAN) Color(0xFF020617) else Color.White
                        )
                    ) {
                        Icon(imageVector = Icons.Default.Wifi, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Wi-Fi / LAN (9100)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { connectionType = ConnectionType.BLUETOOTH },
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 44.dp)
                            .testTag("printer_mode_bt_btn"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (connectionType == ConnectionType.BLUETOOTH) MagicCyan else MagicSurfaceCard,
                            contentColor = if (connectionType == ConnectionType.BLUETOOTH) Color(0xFF020617) else Color.White
                        )
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Bluetooth SPP", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                if (connectionType == ConnectionType.WIFI_LAN) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = printerIp,
                            onValueChange = { printerIp = it },
                            label = { Text("IP Máy in (VD: 192.168.1.200)") },
                            modifier = Modifier
                                .weight(2f)
                                .testTag("printer_ip_input"),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )
                        OutlinedTextField(
                            value = printerPort,
                            onValueChange = { printerPort = it.filter { ch -> ch.isDigit() } },
                            label = { Text("Cổng") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("printer_port_input"),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    // Danh sách IP lịch sử / Tìm thấy để chọn nhanh 1 chạm
                    val combinedIps = remember(savedIps, discoveredIps) {
                        (discoveredIps + savedIps).distinct().take(6)
                    }
                    if (combinedIps.isNotEmpty()) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = if (discoveredIps.isNotEmpty()) "🟢 IP máy in tìm thấy / Đã lưu (Chạm để chọn):"
                                else "🕘 IP máy in gần đây (Chạm để chọn nhanh):",
                                color = MagicEmeraldLight,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                combinedIps.forEach { ip ->
                                    val isSelected = EscPosThermalPrinter.normalizeIpv4Address(printerIp) == ip
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(
                                                if (isSelected) MagicEmerald.copy(alpha = 0.28f)
                                                else MagicSurfaceCard
                                            )
                                            .border(
                                                1.dp,
                                                if (isSelected) MagicEmerald else MagicBorder,
                                                RoundedCornerShape(8.dp)
                                            )
                                            .clickable {
                                                printerIp = ip
                                                onSetStatusMessage("📌 Đã chọn địa chỉ IP máy in: $ip")
                                            }
                                            .padding(horizontal = 10.dp, vertical = 6.dp)
                                    ) {
                                        Text(
                                            text = ip,
                                            color = if (isSelected) MagicEmeraldLight else Color.White,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    onSetPrinting(true)
                                    try {
                                        onSetStatusMessage("⏳ Đang kiểm tra kết nối tới $printerIp:$printerPort...")
                                        val config = buildCurrentConfig()
                                        val res = EscPosThermalPrinter.testConnection(config, context)
                                        val msg = if (res.isSuccess) res.getOrNull() ?: "Thành công" else res.exceptionOrNull()?.message ?: "Lỗi kết nối"
                                        savedIps = EscPosThermalPrinter.getSavedIpHistory(context)
                                        onSetStatusMessage(msg)
                                        Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                    } catch (e: Throwable) {
                                        onSetStatusMessage("⚠️ Lỗi kiểm tra: ${e.localizedMessage ?: e.message}")
                                    } finally {
                                        onSetPrinting(false)
                                    }
                                }
                            },
                            enabled = !isPrinting && !isScanning,
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 46.dp)
                                .testTag("printer_test_conn_btn"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MagicCyan, contentColor = Color(0xFF020617))
                        ) {
                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Kiểm tra kết nối", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    isScanning = true
                                    try {
                                        onSetStatusMessage("🔍 Đang quét toàn dải mạng Wi-Fi tìm máy in mở cổng ${printerPort.ifBlank { "9100" }}...")
                                        val found = EscPosThermalPrinter.discoverLocalPrinters(printerPort.toIntOrNull() ?: 9100, context)
                                        discoveredIps = found
                                        savedIps = EscPosThermalPrinter.getSavedIpHistory(context)
                                        val firstIp = found.firstOrNull()
                                        if (firstIp != null) {
                                            printerIp = firstIp
                                            onSetStatusMessage("🟢 Đã tìm thấy ${found.size} máy in! Đã tự động điền IP: $firstIp")
                                        } else {
                                            onSetStatusMessage("⚠️ Không tìm thấy máy in mở cổng ${printerPort.ifBlank { "9100" }} trong cùng mạng Wi-Fi.")
                                        }
                                    } catch (e: Throwable) {
                                        onSetStatusMessage("⚠️ Lỗi quét mạng: ${e.localizedMessage ?: e.message}")
                                    } finally {
                                        isScanning = false
                                    }
                                }
                            },
                            enabled = !isPrinting && !isScanning,
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 46.dp)
                                .testTag("printer_scan_wifi_btn"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MagicSurfaceCard),
                            border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.5f))
                        ) {
                            if (isScanning) {
                                CircularProgressIndicator(modifier = Modifier.size(15.dp), color = MagicCyan, strokeWidth = 2.dp)
                            } else {
                                Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = MagicCyan, modifier = Modifier.size(16.dp))
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isScanning) "Đang quét..." else "Quét IP Wi-Fi",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                } else {
                    // Giao diện Kết nối Bluetooth SPP
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(MagicSurfaceCard)
                                .border(1.dp, MagicCyan.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                                .padding(12.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = if (bluetoothAddress.isNotBlank()) "📘 Máy in đã chọn: ${bluetoothName.ifBlank { "Máy in Bluetooth" }}"
                                    else "⚠️ Chưa chọn máy in Bluetooth",
                                    color = if (bluetoothAddress.isNotBlank()) MagicEmeraldLight else MagicAmber,
                                    fontSize = 12.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (bluetoothAddress.isNotBlank()) "Địa chỉ MAC: $bluetoothAddress"
                                    else "Hãy ghép đôi máy in trong Cài đặt Bluetooth trước, sau đó bấm 'Tìm Máy In Bluetooth' bên dưới.",
                                    color = TextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !EscPosThermalPrinter.hasBluetoothPermission(context)) {
                                        btPermLauncher.launch(
                                            arrayOf(
                                                Manifest.permission.BLUETOOTH_CONNECT,
                                                Manifest.permission.BLUETOOTH_SCAN
                                            )
                                        )
                                    } else {
                                        val list = EscPosThermalPrinter.getPairedBluetoothPrinters(context)
                                        pairedBtPrinters = list
                                        val firstBt = list.firstOrNull()
                                        if (firstBt != null && bluetoothAddress.isBlank()) {
                                            bluetoothAddress = firstBt.address
                                            bluetoothName = firstBt.name
                                        }
                                        onSetStatusMessage(
                                            if (list.isNotEmpty()) "📘 Đã tải ${list.size} thiết bị Bluetooth đã ghép đôi."
                                            else "⚠️ Chưa có thiết bị Bluetooth nào được ghép đôi. Hãy bấm 'Mở Cài Đặt BT' để ghép đôi máy in."
                                        )
                                    }
                                },
                                modifier = Modifier
                                    .weight(1.2f)
                                    .heightIn(min = 44.dp),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MagicCyan, contentColor = Color(0xFF020617))
                            ) {
                                Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Tìm Máy In BT", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = {
                                    try {
                                        context.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
                                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                        })
                                    } catch (_: Exception) {}
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 44.dp),
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, MagicBorder)
                            ) {
                                Icon(imageVector = Icons.Default.Settings, contentDescription = null, tint = MagicCyanLight, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Mở Cài Đặt BT", fontSize = 11.5.sp, color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }

                        if (pairedBtPrinters.isNotEmpty()) {
                            Text(
                                text = "Danh sách thiết bị Bluetooth đã ghép đôi (Chạm để chọn):",
                                color = MagicCyanLight,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                pairedBtPrinters.forEach { btDev ->
                                    val isSelected = btDev.address == bluetoothAddress
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(if (isSelected) MagicCyan.copy(alpha = 0.18f) else MagicSurfaceCard)
                                            .border(
                                                1.dp,
                                                if (isSelected) MagicCyan else MagicBorder,
                                                RoundedCornerShape(10.dp)
                                            )
                                            .clickable {
                                                bluetoothAddress = btDev.address
                                                bluetoothName = btDev.name
                                                onSetStatusMessage("📘 Đã chọn máy in Bluetooth: ${btDev.name} (${btDev.address})")
                                            }
                                            .padding(horizontal = 12.dp, vertical = 9.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(
                                            modifier = Modifier.weight(1f),
                                            verticalArrangement = Arrangement.spacedBy(3.dp)
                                        ) {
                                            if (btDev.isLikelyPrinter) {
                                                Box(
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(4.dp))
                                                        .background(MagicEmerald.copy(alpha = 0.2f))
                                                        .padding(horizontal = 6.dp, vertical = 1.5.dp)
                                                ) {
                                                    Text("Máy in", color = MagicEmeraldLight, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                            Text(
                                                text = btDev.name,
                                                color = Color.White,
                                                fontSize = 12.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.fillMaxWidth()
                                            )
                                            Text(text = btDev.address, color = TextMuted, fontSize = 10.5.sp)
                                        }
                                        if (isSelected) {
                                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = MagicEmeraldLight, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                }
                            }
                        }

                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    onSetPrinting(true)
                                    try {
                                        onSetStatusMessage("⏳ Đang kiểm tra kết nối Bluetooth tới $bluetoothName ($bluetoothAddress)...")
                                        val res = EscPosThermalPrinter.testConnection(buildCurrentConfig(), context)
                                        val msg = if (res.isSuccess) res.getOrNull() ?: "Thành công" else res.exceptionOrNull()?.message ?: "Lỗi kết nối"
                                        onSetStatusMessage(msg)
                                        Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                    } catch (e: Throwable) {
                                        onSetStatusMessage("⚠️ Lỗi Bluetooth: ${e.localizedMessage ?: e.message}")
                                    } finally {
                                        onSetPrinting(false)
                                    }
                                }
                            },
                            enabled = !isPrinting && bluetoothAddress.isNotBlank(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 44.dp),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald, contentColor = Color(0xFF020617))
                        ) {
                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Kiểm Tra Kết Nối Máy In Bluetooth", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // ==================== 2. CHỌN FILE PDF / ẢNH ĐƠN HÀNG CẦN IN ====================
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = BorderStroke(1.dp, MagicBorder)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MagicCyan.copy(alpha = 0.22f))
                            .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text("Ô #52", color = MagicCyanLight, fontSize = 10.sp, fontWeight = FontWeight.Black)
                    }
                }
                Text(
                    text = "2. CHỌN FILE PDF / ẢNH ĐƠN HÀNG CẦN IN",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            try {
                                filePickerLauncher.launch("application/pdf")
                            } catch (_: Exception) {
                                Toast.makeText(context, "⚠️ Thiết bị chưa có trình chọn tệp hệ thống (Files).", Toast.LENGTH_LONG).show()
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 44.dp)
                            .testTag("printer_pick_pdf_btn"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MagicCyan, contentColor = Color(0xFF020617))
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Chọn File PDF", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            try {
                                filePickerLauncher.launch("image/*")
                            } catch (_: Exception) {
                                Toast.makeText(context, "⚠️ Thiết bị chưa có trình chọn ảnh/tệp hệ thống.", Toast.LENGTH_LONG).show()
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 44.dp)
                            .testTag("printer_pick_image_btn"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MagicSurfaceCard),
                        border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.5f))
                    ) {
                        Icon(imageVector = Icons.Default.Image, contentDescription = null, tint = MagicCyan, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Chọn Ảnh Đơn", fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }

                if (selectedUri != null) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(MagicSurfaceCard)
                            .border(1.dp, MagicEmerald.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "📎 Tệp đang mở: ${selectedUri?.lastPathSegment ?: "Đơn hàng"}",
                                color = MagicEmeraldLight,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = if (pdfPageCount > 0) "Tài liệu PDF gồm $pdfPageCount trang (Hỗ trợ in lẻ từng trang hoặc in hàng loạt)"
                                else "Hình ảnh vận đơn / hóa đơn",
                                color = TextSecondary,
                                fontSize = 10.5.sp
                            )
                        }
                        TextButton(
                            onClick = {
                                selectedUri = null
                                pdfPageCount = 0
                                currentPdfPage = 0
                                onSetStatusMessage("Đã đóng tệp hiện tại.")
                            }
                        ) {
                            Text("Xóa", color = MagicAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Điều hướng chọn trang nếu tệp PDF có nhiều trang
                if (pdfPageCount > 1) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF0F172A))
                            .border(1.dp, MagicCyan.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = { if (currentPdfPage > 0) currentPdfPage-- },
                            enabled = currentPdfPage > 0,
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.heightIn(min = 34.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("◀ Trang trước", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Text(
                            text = "📑 Trang ${currentPdfPage + 1} / $pdfPageCount",
                            color = MagicCyanLight,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Black
                        )

                        OutlinedButton(
                            onClick = { if (currentPdfPage < pdfPageCount - 1) currentPdfPage++ },
                            enabled = currentPdfPage < pdfPageCount - 1,
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.heightIn(min = 34.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Trang sau ▶", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // ==================== 3. KHỔ GIẤY, ĐỘ ĐẬM ĐẦU NHIỆT, CĂN LỀ & SỐ BẢN IN ====================
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = BorderStroke(1.dp, MagicBorder)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MagicCyan.copy(alpha = 0.22f))
                            .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text("Ô #53", color = MagicCyanLight, fontSize = 10.sp, fontWeight = FontWeight.Black)
                    }
                }
                Text(
                    text = "3. KHỔ GIẤY, ĐỘ ĐẬM ĐẦU NHIỆT & CĂN LỀ",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.fillMaxWidth()
                )

                // Chọn khổ giấy: K80 (576), K76 (512), K57 (384)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val paperOptions = listOf(
                        576 to "K80 (80mm)",
                        512 to "K76 (76mm)",
                        384 to "K57 (58mm)"
                    )
                    paperOptions.forEach { (dots, title) ->
                        val selected = paperWidthDots == dots
                        Button(
                            onClick = { paperWidthDots = dots },
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 42.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selected) MagicCyan else MagicSurfaceCard,
                                contentColor = if (selected) Color(0xFF020617) else Color.White
                            )
                        ) {
                            Text(title, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                        }
                    }
                }

                // Chọn độ đậm đầu nhiệt (Density Level 1..5)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Text(
                            text = "🔥 Độ đậm đầu nhiệt (Bảo vệ mã QR):",
                            color = Color.White,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(
                            text = when (densityLevel) {
                                1 -> "Mức 1: Nhạt (Tiết kiệm)"
                                2 -> "Mức 2: Vừa phải"
                                3 -> "Mức 3: Chuẩn nét QR (Khuyên dùng)"
                                4 -> "Mức 4: Đậm tăng cường"
                                else -> "Mức 5: Cực đậm (Giấy mờ)"
                            },
                            color = MagicCyanLight,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        (1..5).forEach { lvl ->
                            val selected = densityLevel == lvl
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (selected) MagicEmerald else MagicSurfaceCard)
                                    .border(
                                        1.dp,
                                        if (selected) MagicEmeraldLight else MagicBorder,
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable { densityLevel = lvl },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "Mức $lvl",
                                    color = if (selected) Color(0xFF020617) else Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // Số lượng bản in (Số liên) & Số dòng đẩy giấy
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Số bản in
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MagicSurfaceCard)
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text("📑 Số liên / Số bản in:", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedButton(
                                onClick = { if (copiesCount > 1) copiesCount-- },
                                modifier = Modifier.size(34.dp),
                                contentPadding = PaddingValues(0.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("-", fontWeight = FontWeight.Black, fontSize = 15.sp)
                            }
                            Text(
                                text = "$copiesCount bản",
                                color = MagicCyanLight,
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Black
                            )
                            OutlinedButton(
                                onClick = { if (copiesCount < 10) copiesCount++ },
                                modifier = Modifier.size(34.dp),
                                contentPadding = PaddingValues(0.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("+", fontWeight = FontWeight.Black, fontSize = 15.sp)
                            }
                        }
                    }

                    // Số dòng đẩy giấy trước khi cắt
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MagicSurfaceCard)
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text("⏬ Đẩy giấy sau khi in:", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedButton(
                                onClick = { if (feedLines > 0) feedLines-- },
                                modifier = Modifier.size(34.dp),
                                contentPadding = PaddingValues(0.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("-", fontWeight = FontWeight.Black, fontSize = 15.sp)
                            }
                            Text(
                                text = "$feedLines dòng",
                                color = MagicEmeraldLight,
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Black
                            )
                            OutlinedButton(
                                onClick = { if (feedLines < 8) feedLines++ },
                                modifier = Modifier.size(34.dp),
                                contentPadding = PaddingValues(0.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("+", fontWeight = FontWeight.Black, fontSize = 15.sp)
                            }
                        }
                    }
                }

                // Căn lề Trái / Phải (dots)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "⬅️ Lề trái: ${marginLeftDots}px",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Slider(
                            value = marginLeftDots.toFloat(),
                            onValueChange = { marginLeftDots = it.toInt() },
                            valueRange = 0f..64f,
                            steps = 7
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "➡️ Lề phải: ${marginRightDots}px",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Slider(
                            value = marginRightDots.toFloat(),
                            onValueChange = { marginRightDots = it.toInt() },
                            valueRange = 0f..64f,
                            steps = 7
                        )
                    }
                }

                HorizontalDivider(color = MagicBorder, thickness = 0.8.dp)

                // Các công tắc nâng cao
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("✂️ Cắt giấy tự động (Auto-Cut)", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text("Tự động cắt rời từng đơn hàng sau khi in xong", color = TextSecondary, fontSize = 10.5.sp)
                    }
                    Switch(checked = autoCut, onCheckedChange = { autoCut = it })
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("🅱️ Làm đậm nét chữ & Bảo vệ QR (Bold Dilation)", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text("Làm dày chữ nhỏ trong PDF mà không làm dính vạch mã QR/Barcode", color = TextSecondary, fontSize = 10.5.sp)
                    }
                    Switch(checked = boldDilation, onCheckedChange = { boldDilation = it })
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("📐 Cắt bỏ khoảng trắng thừa cuối đơn (Auto-Trim)", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text("Tiết kiệm giấy nhiệt khi in file PDF có phần chân trang trống", color = TextSecondary, fontSize = 10.5.sp)
                    }
                    Switch(checked = autoTrimBottom, onCheckedChange = { autoTrimBottom = it })
                }
            }
        }

        // ==================== 4. CÔNG CỤ ĐIỀU KHIỂN PHẦN CỨNG MÁY IN 1-CHẠM ====================
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = BorderStroke(1.dp, MagicBorder)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MagicCyan.copy(alpha = 0.22f))
                            .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text("Ô #54", color = MagicCyanLight, fontSize = 10.sp, fontWeight = FontWeight.Black)
                    }
                }
                Text(
                    text = "4. LỆNH ĐIỀU KHIỂN PHẦN CỨNG NHANH",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            coroutineScope.launch {
                                onSetStatusMessage("⏬ Đang gửi lệnh đẩy giấy (Feed 3 dòng)...")
                                val res = EscPosThermalPrinter.sendHardwareActionCommand(
                                    config = buildCurrentConfig(),
                                    commandBytes = byteArrayOf(0x1B, 0x64, 0x03),
                                    actionLabel = "Đẩy giấy 3 dòng",
                                    context = context
                                )
                                val msg = res.getOrNull() ?: res.exceptionOrNull()?.message ?: "Lỗi"
                                onSetStatusMessage(msg)
                            }
                        },
                        enabled = !isPrinting,
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 42.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.5f))
                    ) {
                        Text("⏬ Đẩy Giấy", fontSize = 12.sp, color = MagicCyanLight, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = {
                            coroutineScope.launch {
                                onSetStatusMessage("✂️ Đang gửi lệnh cắt giấy tự động (Test Dao Cắt)...")
                                val res = EscPosThermalPrinter.sendHardwareActionCommand(
                                    config = buildCurrentConfig(),
                                    commandBytes = byteArrayOf(0x1B, 0x64, 0x02, 0x1D, 0x56, 0x42, 0x00),
                                    actionLabel = "Cắt giấy ngay",
                                    context = context
                                )
                                val msg = res.getOrNull() ?: res.exceptionOrNull()?.message ?: "Lỗi"
                                onSetStatusMessage(msg)
                            }
                        },
                        enabled = !isPrinting,
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 42.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, MagicEmerald.copy(alpha = 0.5f))
                    ) {
                        Text("✂️ Cắt Giấy", fontSize = 12.sp, color = MagicEmeraldLight, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // ==================== 5. MÀN HÌNH XEM TRƯỚC BẢN IN NHIỆT THỰC TẾ (LIVE PREVIEW) ====================
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = BorderStroke(1.dp, MagicBorder)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Tiêu đề Ô #51 ở hàng riêng đầy đủ, thoáng đãng không bị bóp nghẹt
                val activePreviewBmp = previewBitmap
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MagicCyan.copy(alpha = 0.22f))
                            .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text("Ô #55", color = MagicCyanLight, fontSize = 10.5.sp, fontWeight = FontWeight.Black)
                    }
                    if (activePreviewBmp != null) {
                        Text(
                            text = "Kích thước đốt nhiệt: ${activePreviewBmp.width} x ${activePreviewBmp.height} dots",
                            color = MagicCyanLight,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
                Text(
                    text = "5. XEM TRƯỚC BẢN IN NHIỆT (MONOCHROME)",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.fillMaxWidth()
                )
                if (activePreviewBmp == null) {
                    Text(
                        text = "Bản xem trước chế độ đốt nhiệt thực tế máy in K80 / K57",
                        color = TextMuted,
                        fontSize = 10.5.sp,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // Hàng riêng biệt cho nút "Đổi Tệp Khác" (rộng rãi, đẹp mắt, không bị chèn ép bên cạnh tiêu đề)
                OutlinedButton(
                    onClick = {
                        try {
                            filePickerLauncher.launch("*/*")
                        } catch (_: Exception) {
                            Toast.makeText(context, "⚠️ Thiết bị chưa có trình chọn tệp hệ thống (Files).", Toast.LENGTH_LONG).show()
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 42.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = MagicSurfaceCard,
                        contentColor = Color.White
                    ),
                    border = BorderStroke(1.2.dp, MagicCyan.copy(alpha = 0.65f))
                ) {
                    Icon(
                        imageVector = Icons.Default.Image,
                        contentDescription = null,
                        tint = MagicCyan,
                        modifier = Modifier.size(17.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "📁 Đổi Tệp Khác (Chọn Ảnh hoặc PDF Khác)",
                        fontSize = 12.sp,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }

                val activeDisplayBmp = previewBitmap
                val cachedPreviewImage = remember(activeDisplayBmp) {
                    activeDisplayBmp?.takeIf { !it.isRecycled && it.width > 0 && it.height > 0 }?.asImageBitmap()
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 180.dp, max = 380.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (cachedPreviewImage != null) Color.White else MagicSurfaceCard)
                        .border(2.dp, if (cachedPreviewImage != null) Color(0xFFCBD5E1) else MagicBorder, RoundedCornerShape(12.dp))
                        .padding(14.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (cachedPreviewImage != null) {
                        Image(
                            bitmap = cachedPreviewImage,
                            contentDescription = "Xem trước hóa đơn nhiệt",
                            modifier = Modifier.fillMaxWidth(),
                            contentScale = ContentScale.FillWidth
                        )
                    } else if (selectedUri != null) {
                        CircularProgressIndicator(color = MagicCyan)
                    } else {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Print,
                                contentDescription = null,
                                tint = MagicCyanLight,
                                modifier = Modifier.size(32.dp)
                            )
                            Text(
                                text = "Chưa chọn tệp đơn hàng cần in",
                                color = Color.White,
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = "Hãy bấm 'Chọn File PDF', 'Chọn Ảnh Đơn' ở mục 2 hoặc Chia sẻ (Share) đơn hàng trực tiếp từ Shopee / TikTok / Zalo sang MagicTune.",
                                color = TextSecondary,
                                fontSize = 11.sp,
                                textAlign = TextAlign.Center,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            }
        }

        // ==================== NÚT IN NGAY & IN HÀNG LOẠT TRANG PDF ====================
        Button(
            onClick = {
                val bmpToPrint = previewBitmap ?: return@Button
                coroutineScope.launch {
                    onSetPrinting(true)
                    try {
                        onSetStatusMessage("🖨️ Đang gửi dữ liệu in tới máy in nhiệt...")
                        val config = buildCurrentConfig()
                        val res = EscPosThermalPrinter.printBitmapToEscPos(
                            bitmap = bmpToPrint,
                            config = config,
                            context = context,
                            onProgress = { progressMsg -> onSetStatusMessage(progressMsg) }
                        )
                        val msg = if (res.isSuccess) res.getOrNull() ?: "In thành công" else res.exceptionOrNull()?.message ?: "Lỗi in"
                        savedIps = EscPosThermalPrinter.getSavedIpHistory(context)
                        onSetStatusMessage(msg)
                        Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                    } catch (e: Throwable) {
                        onSetStatusMessage("⚠️ Lỗi in: ${e.localizedMessage ?: e.message}")
                    } finally {
                        onSetPrinting(false)
                    }
                }
            },
            enabled = !isPrinting && previewBitmap != null,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 56.dp)
                .testTag("printer_print_now_btn"),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = MagicEmerald,
                contentColor = Color(0xFF020617)
            )
        ) {
            if (isPrinting) {
                CircularProgressIndicator(modifier = Modifier.size(22.dp), color = Color(0xFF020617), strokeWidth = 2.5.dp)
                Spacer(modifier = Modifier.width(10.dp))
                Text("ĐANG TRUYỀN DỮ LIỆU IN...", fontSize = 14.5.sp, fontWeight = FontWeight.Black)
            } else {
                Icon(imageVector = Icons.Default.Print, contentDescription = null, modifier = Modifier.size(22.dp))
                Spacer(modifier = Modifier.width(8.dp))
                val label = when {
                    pdfPageCount > 1 ->
                        "IN TRANG HIỆN TẠI (TRANG ${currentPdfPage + 1}/$pdfPageCount) - $copiesCount BẢN"
                    copiesCount > 1 ->
                        "IN ĐƠN HÀNG NGAY ($copiesCount BẢN LIÊN TIẾP)"
                    else ->
                        "IN ĐƠN HÀNG NGAY LẬP TỨC"
                }
                Text(label, fontSize = 14.sp, fontWeight = FontWeight.Black)
            }
        }

        // Nút In Toàn Bộ Các Trang PDF (chỉ hiện khi mở file PDF có nhiều hơn 1 trang)
        if (selectedUri != null && pdfPageCount > 1) {
            Button(
                onClick = {
                    val targetUri = selectedUri ?: return@Button
                    coroutineScope.launch {
                        onSetPrinting(true)
                        try {
                            onSetStatusMessage("📚 Bắt đầu in hàng loạt $pdfPageCount trang PDF...")
                            val config = buildCurrentConfig()
                            val res = EscPosThermalPrinter.printAllPdfPagesToEscPos(
                                context = context,
                                pdfUri = targetUri,
                                config = config,
                                onProgress = { progressMsg -> onSetStatusMessage(progressMsg) }
                            )
                            val msg = if (res.isSuccess) res.getOrNull() ?: "Đã in hết các trang PDF"
                            else res.exceptionOrNull()?.message ?: "Lỗi in hàng loạt"
                            savedIps = EscPosThermalPrinter.getSavedIpHistory(context)
                            onSetStatusMessage(msg)
                            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                        } catch (e: Throwable) {
                            onSetStatusMessage("⚠️ Lỗi in hàng loạt: ${e.localizedMessage ?: e.message}")
                        } finally {
                            onSetPrinting(false)
                        }
                    }
                },
                enabled = !isPrinting,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 52.dp)
                    .testTag("printer_print_all_pdf_btn"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MagicCyan,
                    contentColor = Color(0xFF020617)
                )
            ) {
                Icon(imageVector = Icons.Default.List, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "IN HÀNG LOẠT TẤT CẢ $pdfPageCount TRANG PDF (${pdfPageCount * copiesCount} PHIẾU)",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black
                )
            }
        }
    }
}
