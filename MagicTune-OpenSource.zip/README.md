# MagicTune Tool (Open Source)

MagicTune Tool is an open-source Android utility built with Jetpack Compose, Wireless ADB (`libadb-android`), Shizuku, Material 3, and ML Kit, designed for Honor MagicOS and modern Android devices.

> **Open Source License:** Released under the [MIT License](LICENSE). Anyone worldwide is free to fork, modify, learn from, and distribute this project.

---

## Features / Tính năng chính

- **Wireless ADB & Shizuku Bridge**: On-device NSD WLAN ADB pairing & shell execution without a PC.
- **Home Screen Widgets**:
  - 3×2 & 2×2 Live Battery Widgets (charging wattage, mAh fuel-gauge drain analytics, Bluetooth device battery rings, cycle count toggle)
  - App Search & Gesture Draw Widget (recent apps + handwriting app launcher)
  - RAM & ROM Optimizer Widget
  - Clock, Weather & 24h/7d Forecast Widget + Perpetual Lunar Calendar Widget
  - Global widget background transparency slider (0%–100%)
- **Notification & OEM Tuning**: Background keep-alive tuning for Android / Honor / Xiaomi / OPPO / Vivo / Samsung.
- **AI & Screen Utilities**: On-device ML Kit OCR screen translator, Circle-to-Search overlay, gesture letter app launcher, and thermal ESC/POS printer support (K80 / K57 via LAN/Wi-Fi/Bluetooth).
- **In-App Updater**: Supports direct APK updates hosted on **GitHub Releases** or **Google Drive**.

---

## Tech Stack

- **Language:** Kotlin, Jetpack Compose (Material 3)
- **Min / Target / Compile SDK:** `24` / `36` / `36`
- **Build System:** Gradle `9.3.1`, Android Gradle Plugin `9.1.1`, Java `17+`
- **Core Libraries:** `libadb-android`, `conscrypt-android`, Shizuku API, ML Kit Text Recognition (Latin & Chinese), Firebase (optional — Auth, Firestore, AI)

---

## Getting Started / Hướng dẫn build

### 1. Prerequisites
- **JDK 17** or **JDK 21**
- **Android SDK** with **Platform 36** and **Build-Tools 36.0.0**
- Create `local.properties` in the project root:
  ```properties
  sdk.dir=/path/to/Android/Sdk
  ```
  *(On Windows: `sdk.dir=C\:\\Users\\<You>\\AppData\\Local\\Android\\Sdk`)*

### 2. Optional Configuration Files
1. **Private config (`private.properties`)** — copy `private.properties.example` to `private.properties`:
   ```properties
   ADMIN_EMAIL=admin@example.com
   ADMIN_PHONE=0000000000
   PRO_SECRET_SALT=your_custom_salt
   PRO_ACCOUNT_SALT=your_custom_account_salt
   GROQ_API_KEY=
   ```
   *(If omitted, safe open-source defaults are used so debug builds work immediately.)*

2. **Firebase (`google-services.json`, optional)**:
   - Copy `google-services.json.example` to `google-services.json` and fill in values from your own Firebase Console for package `com.magictune.tool` (or change `applicationId` in `build.gradle.kts`).
   - If `google-services.json` is omitted, the Google Services plugin is skipped automatically during build.

3. **Release Signing (`keystore.properties`, optional)**:
   - Copy `keystore.properties.example` to `keystore.properties` and point `storeFile` to your `.p12` / `.jks` keystore.

### 3. Build Commands

**Debug APK:**
```bash
# macOS / Linux
chmod +x gradlew
./gradlew assembleDebug

# Windows (PowerShell / CMD)
gradlew.bat assembleDebug
```
Output: `build/outputs/apk/debug/`

**Release APK:**
```bash
./gradlew assembleRelease
# or on Windows:
gradlew.bat assembleRelease
```
Output: `build/outputs/apk/release/`

### 4. Static Layout Tests
Requires Node.js:
```bash
node tests/widget-layouts.test.cjs
```

---

## Project Structure

```text
.
├── AndroidManifest.xml       # App manifest (components, receivers, widget metadata)
├── build.gradle.kts          # Gradle configuration & dependencies
├── gradle/                   # Gradle wrapper & libs.versions.toml catalog
├── res/                      # Android XML layouts, drawables, widget metadata
├── src/main/java/            # Kotlin source files (UI, widgets, ADB/shell, AI)
├── tests/                    # Static XML layout validation checks
├── LICENSE                   # MIT License
└── README.md
```

---

## Security Notice for Contributors
Never commit `private.properties`, `keystore.properties`, `google-services.json`, `.p12`/`.jks` keystores, or personal credentials. All of these are ignored in `.gitignore`.
