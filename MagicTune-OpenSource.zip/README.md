# MagicTune WebADB - Open Source

> Bộ công cụ WebADB tối ưu hóa, tinh chỉnh và sửa lỗi Android trực tuyến 100% miễn phí.

## Giới thiệu
MagicTune WebADB là nền tảng hoạt động trực tiếp trên trình duyệt web thông qua giao thức WebUSB, cho phép người dùng kết nối điện thoại Android với máy tính mà không cần cài đặt phần mềm phức tạp.

- **Website trực tuyến:** [https://magictune.web.app](https://magictune.web.app)
- **Mã nguồn GitHub:** [https://github.com/Vuong05062000/MagicTune-OpenSource](https://github.com/Vuong05062000/MagicTune-OpenSource)

## Tính năng chính
- Tối ưu hóa thông báo 0s chuông (Facebook, Messenger, Zalo, Gmail)
- Ép hiển thị bảng gỡ lỗi USB với cặp khóa RSA mới
- Tối ưu hóa tần số quét màn hình 120Hz
- Hỗ trợ gỡ bỏ ứng dụng mặc định không cần thiết (Debloat an toàn)
- Cài đặt tệp APK/APKS trực tiếp qua trình duyệt
- Cầu nối hỗ trợ Shizuku Engine

## Hướng dẫn phát triển cục bộ
```bash
# Cài đặt thư viện phụ thuộc
npm install

# Khởi chạy máy chủ phát triển
npm run dev

# Xây dựng bản phát hành tĩnh
npm run build
```
