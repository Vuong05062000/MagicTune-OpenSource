package com.example.ui.components

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.os.Build
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import com.example.core.widget.MagicTunePerpetualCalendarWidgetProvider
import com.example.core.widget.VietnameseLunarCalendar
import com.example.ui.theme.MagicAmber
import com.example.ui.theme.MagicAmberLight
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicCyanLight
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicEmeraldLight
import com.example.ui.theme.MagicRoseLight
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.MagicSurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import java.util.Calendar
import java.util.Locale

private val BookHeaderBrush = Brush.horizontalGradient(
    listOf(Color(0xFF991B1B), Color(0xFFB45309))
)

fun requestPinPerpetualCalendarWidget(context: Context) {
    try {
        val awm = AppWidgetManager.getInstance(context)
        val provider = ComponentName(context, MagicTunePerpetualCalendarWidgetProvider::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && awm.isRequestPinAppWidgetSupported) {
            val accepted = awm.requestPinAppWidget(provider, null, null)
            if (accepted) {
                Toast.makeText(
                    context,
                    "📅 Đã gửi yêu cầu thêm Widget Lịch Vạn Niên ra Màn hình chính!",
                    Toast.LENGTH_LONG
                ).show()
                return
            }
        }
        Toast.makeText(
            context,
            "Nhấn giữ khoảng trống Màn hình chính -> Tiện ích (Widgets) -> chọn \"MagicTune Lịch Vạn Niên\".",
            Toast.LENGTH_LONG
        ).show()
    } catch (_: Throwable) {
        Toast.makeText(
            context,
            "Nhấn giữ Màn hình chính -> Tiện ích (Widgets) -> chọn \"MagicTune Lịch Vạn Niên\".",
            Toast.LENGTH_LONG
        ).show()
    }
}

@Composable
fun PerpetualCalendarDialog(
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val todayCal = remember { Calendar.getInstance() }
    val todayYear = remember { todayCal.get(Calendar.YEAR) }
    val todayMonth = remember { todayCal.get(Calendar.MONTH) + 1 }
    val todayDay = remember { todayCal.get(Calendar.DAY_OF_MONTH) }

    var viewYear by remember { mutableIntStateOf(todayYear) }
    var viewMonth by remember { mutableIntStateOf(todayMonth) }
    var selectedYear by remember { mutableIntStateOf(todayYear) }
    var selectedMonth by remember { mutableIntStateOf(todayMonth) }
    var selectedDay by remember { mutableIntStateOf(todayDay) }

    val grid = remember(viewYear, viewMonth) {
        VietnameseLunarCalendar.buildMonthGrid(viewYear, viewMonth)
    }

    val selectedCell = remember(grid, selectedYear, selectedMonth, selectedDay) {
        grid.firstOrNull {
            it.solarYear == selectedYear && it.solarMonth == selectedMonth && it.solarDay == selectedDay
        } ?: VietnameseLunarCalendar.buildDayCell(selectedYear, selectedMonth, selectedDay, true)
    }

    val currentMonthCells = remember(grid) { grid.filter { it.isCurrentMonth } }
    val firstLunar = currentMonthCells.firstOrNull()?.lunar
    val lastLunar = currentMonthCells.lastOrNull()?.lunar
    val lunarMonthBanner = if (firstLunar != null && lastLunar != null) {
        val mStr = if (firstLunar.month == lastLunar.month && firstLunar.isLeapMonth == lastLunar.isLeapMonth) {
            firstLunar.lunarMonthName
        } else {
            "${firstLunar.lunarMonthName} - ${lastLunar.lunarMonthName.removePrefix("Tháng ")}"
        }
        "🌙 $mStr • Năm ${lastLunar.yearCanChi}"
    } else {
        "🌙 Lịch Âm Dương Việt Nam"
    }

    fun shiftMonth(delta: Int) {
        val c = Calendar.getInstance().apply {
            set(viewYear, viewMonth - 1, 1, 12, 0, 0)
            add(Calendar.MONTH, delta)
        }
        val ny = c.get(Calendar.YEAR)
        val nm = c.get(Calendar.MONTH) + 1
        viewYear = ny
        viewMonth = nm
        selectedYear = ny
        selectedMonth = nm
        selectedDay = if (ny == todayYear && nm == todayMonth) todayDay else 1
    }

    val dowNames = remember { arrayOf("Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy", "Chủ Nhật") }

    AlertDialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 14.dp),
        containerColor = MagicSurfaceDark,
        shape = RoundedCornerShape(20.dp),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "📅 QUYỂN LỊCH VẠN NIÊN",
                        color = MagicAmberLight,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "Âm - Dương lịch Việt Nam chuẩn thiên văn",
                        color = TextSecondary,
                        fontSize = 10.5.sp
                    )
                }
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Đóng Lịch Vạn Niên",
                        tint = TextSecondary
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 520.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Header Quyển lịch
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(BookHeaderBrush)
                        .border(1.dp, MagicAmber.copy(alpha = 0.7f), RoundedCornerShape(14.dp))
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color.Black.copy(alpha = 0.28f))
                            .clickable { shiftMonth(-1) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text("◀", color = Color(0xFFFEF3C7), fontSize = 14.sp, fontWeight = FontWeight.Black)
                    }

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "THÁNG $viewMonth • $viewYear",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = lunarMonthBanner,
                            color = Color(0xFFFDE68A),
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    if (viewYear != todayYear || viewMonth != todayMonth || selectedDay != todayDay) {
                        Box(
                            modifier = Modifier
                                .padding(end = 6.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MagicCyan.copy(alpha = 0.25f))
                                .border(1.dp, MagicCyanLight.copy(alpha = 0.7f), RoundedCornerShape(8.dp))
                                .clickable {
                                    viewYear = todayYear
                                    viewMonth = todayMonth
                                    selectedYear = todayYear
                                    selectedMonth = todayMonth
                                    selectedDay = todayDay
                                }
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            Text("Hôm nay", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Black)
                        }
                    }

                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color.Black.copy(alpha = 0.28f))
                            .clickable { shiftMonth(1) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text("▶", color = Color(0xFFFEF3C7), fontSize = 14.sp, fontWeight = FontWeight.Black)
                    }
                }

                // Hàng thứ T2 -> CN
                Row(modifier = Modifier.fillMaxWidth()) {
                    val headers = listOf("T2", "T3", "T4", "T5", "T6", "T7", "CN")
                    headers.forEachIndexed { idx, label ->
                        Text(
                            text = label,
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.Center,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            color = when (idx) {
                                5 -> MagicAmberLight
                                6 -> MagicRoseLight
                                else -> TextSecondary
                            }
                        )
                    }
                }

                // Lưới 6 tuần x 7 ngày
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    for (week in 0 until 6) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            for (col in 0 until 7) {
                                val cell = grid[week * 7 + col]
                                val isSelected = cell.solarYear == selectedYear &&
                                    cell.solarMonth == selectedMonth &&
                                    cell.solarDay == selectedDay

                                val bg = when {
                                    cell.isToday -> MagicCyan.copy(alpha = 0.28f)
                                    isSelected -> MagicAmber.copy(alpha = 0.26f)
                                    cell.isCurrentMonth && cell.isSpecialLunar -> MagicAmber.copy(alpha = 0.1f)
                                    else -> Color(0xFF0B1220)
                                }
                                val borderColor = when {
                                    cell.isToday -> MagicCyanLight
                                    isSelected -> MagicAmberLight
                                    cell.isCurrentMonth && cell.isSpecialLunar -> MagicAmber.copy(alpha = 0.45f)
                                    else -> Color.Transparent
                                }

                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .heightIn(min = 44.dp)
                                        .clip(RoundedCornerShape(9.dp))
                                        .background(bg)
                                        .border(1.dp, borderColor, RoundedCornerShape(9.dp))
                                        .clickable {
                                            viewYear = cell.solarYear
                                            viewMonth = cell.solarMonth
                                            selectedYear = cell.solarYear
                                            selectedMonth = cell.solarMonth
                                            selectedDay = cell.solarDay
                                        }
                                        .padding(vertical = 4.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Text(
                                        text = cell.solarDay.toString(),
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Black,
                                        color = when {
                                            cell.isToday -> Color.White
                                            !cell.isCurrentMonth -> TextMuted.copy(alpha = 0.55f)
                                            col == 6 -> MagicRoseLight
                                            col == 5 -> MagicAmberLight
                                            else -> Color.White
                                        }
                                    )
                                    Text(
                                        text = cell.lunar.shortDisplay,
                                        fontSize = 9.sp,
                                        fontWeight = if (cell.lunar.day == 1 || cell.lunar.day == 15) FontWeight.Bold else FontWeight.Normal,
                                        color = when {
                                            cell.isToday -> MagicCyanLight
                                            !cell.isCurrentMonth -> TextMuted.copy(alpha = 0.45f)
                                            cell.lunar.day == 1 -> MagicRoseLight
                                            cell.lunar.day == 15 || !cell.holidayName.isNullOrBlank() -> MagicAmberLight
                                            else -> TextSecondary
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                // Thẻ chi tiết ngày đang chọn
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
                    border = BorderStroke(1.dp, MagicAmber.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        val dowLabel = dowNames.getOrNull(selectedCell.dayOfWeekCol) ?: ""
                        val leapTag = if (selectedCell.lunar.isLeapMonth) " (Tháng Nhuận)" else ""

                        Text(
                            text = String.format(
                                Locale.US,
                                "📅 %s, ngày %02d/%02d/%d (Dương lịch)",
                                dowLabel,
                                selectedCell.solarDay,
                                selectedCell.solarMonth,
                                selectedCell.solarYear
                            ),
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = String.format(
                                Locale.US,
                                "🌙 Âm lịch: Ngày %02d/%02d%s • Năm %s",
                                selectedCell.lunar.day,
                                selectedCell.lunar.month,
                                leapTag,
                                selectedCell.lunar.yearCanChi
                            ),
                            color = MagicAmberLight,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "✨ Can Chi: Ngày ${selectedCell.lunar.dayCanChi} • Tháng ${selectedCell.lunar.monthCanChi}",
                            color = MagicCyanLight,
                            fontSize = 11.2.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "⏰ Giờ Hoàng Đạo: ${selectedCell.lunar.zodiacHours}",
                            color = TextSecondary,
                            fontSize = 10.5.sp,
                            lineHeight = 14.5.sp
                        )
                        if (!selectedCell.holidayName.isNullOrBlank()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MagicEmerald.copy(alpha = 0.16f))
                                    .border(1.dp, MagicEmerald.copy(alpha = 0.45f), RoundedCornerShape(8.dp))
                                    .padding(horizontal = 8.dp, vertical = 5.dp)
                            ) {
                                Text(
                                    text = "🎉 Sự kiện / Ngày lễ: ${selectedCell.holidayName}",
                                    color = MagicEmeraldLight,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(IntrinsicSize.Min),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .weight(0.75f)
                        .fillMaxHeight()
                        .heightIn(min = 40.dp, max = 44.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, MagicBorder)
                ) {
                    Text("Đóng", color = TextSecondary, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                }
                Button(
                    onClick = { requestPinPerpetualCalendarWidget(context) },
                    modifier = Modifier
                        .weight(1.65f)
                        .fillMaxHeight()
                        .heightIn(min = 40.dp, max = 44.dp)
                        .testTag("pin_perpetual_calendar_widget_button"),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MagicAmber,
                        contentColor = Color(0xFF020617)
                    )
                ) {
                    Text(
                        text = "📌 Đưa Widget Lịch ra Màn hình",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    )
}
