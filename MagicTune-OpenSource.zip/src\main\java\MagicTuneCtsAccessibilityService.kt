package com.example.core.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.util.Log
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.core.shell.ShellEngine
import com.example.core.widget.MagicTuneAppSearchWidgetProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

/**
 * Dịch Vụ Trợ Năng Ngầm Tự Kích Hoạt & Tự Tàng Hình (Stealth Auto-Accessibility Service).
 *
 * MỤC TIÊU & ĐẶC TÍNH:
 * 1. Hoạt động full 100% tính năng (Đọc cây giao diện 0ms, chụp màn hình API 30+ không hiện hộp thoại, chạm cuộn tự động).
 * 2. KHÔNG CẦN CẤP TRỢ NĂNG THẬT TRONG CÀI ĐẶT:
 *    - Tự động kích hoạt ngầm qua quyền WRITE_SECURE_SETTINGS / WLAN ADB kết nối trực tiếp.
 * 3. AN TOÀN TUYỆT ĐỐI VỚI APP NGÂN HÀNG & CHÍNH PHỦ (MB Bank, Techcombank, VCB, VNeID...):
 *    - Ngay khi phát hiện app ngân hàng mở lên tiền cảnh, tự động GỠ BỎ và TẮT NGẦM khỏi danh sách
 *      `enabled_accessibility_services` trong 0ms.
 *    - Khi ngân hàng quét hệ thống, danh sách trợ năng hoàn toàn TRỐNG (0 dịch vụ), không bao giờ bị báo vi phạm.
 *    - Khi người dùng thoát app ngân hàng quay lại app thường (Taobao, 1688, Zalo...), tự động khôi phục ngầm.
 */
class MagicTuneCtsAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        val appCtx = applicationContext ?: this
        val liveFg = resolveFreshForegroundPackage(appCtx)
        val hasRestrictedWindow = try {
            windows?.any { win ->
                val wPkg = win.root?.packageName?.toString().orEmpty()
                wPkg.isNotBlank() && (NoAccessibilityScreenEngine.isSensitiveBankingPackage(wPkg) || isSystemSettingsPackage(wPkg))
            } == true
        } catch (_: Throwable) { false }

        if (hasRestrictedWindow ||
            (liveFg.isNotBlank() && (NoAccessibilityScreenEngine.isSensitiveBankingPackage(liveFg) || isSystemSettingsPackage(liveFg)))
        ) {
            val isBanking = hasRestrictedWindow && liveFg.isBlank() ||
                (liveFg.isNotBlank() && NoAccessibilityScreenEngine.isSensitiveBankingPackage(liveFg))
            disableServiceViaSecureSettings(appCtx, forceRemoveFromSettings = true, isBankingBlock = isBanking)
            return
        }

        instance = this
        Log.d(TAG, "MagicTuneCtsAccessibilityService connected")
        applyRuntimeServiceConfig(this, NoAccessibilityScreenEngine.isLiveScrollTranslateActive && com.example.core.widget.GoogleLiveTranslateOverlay.isRunning)

        synchronized(serviceConnectLock) {
            serviceConnectLock.notifyAll()
        }

        if (!isAnyFeatureActive()) {
            disableServiceIfIdle(appCtx, 80L)
        } else if (NoAccessibilityScreenEngine.isLiveScrollTranslateActive && liveScrollLeaseUntilMs > 0L) {
            scheduleInactivitySleepCheck(appCtx)
        }

        if (!hasAttemptedUsageStatsGrantOnConnect) {
            hasAttemptedUsageStatsGrantOnConnect = true
            try {
                if (!hasUsageStatsPermission(applicationContext)) {
                    val shell = com.example.core.shell.ShellEngine.getInstance(applicationContext)
                    if (shell.state.value.isAdbReady) {
                        val myPkg = packageName
                        helperScope.launch {
                            try {
                                shell.execute(
                                    "cmd appops set $myPkg GET_USAGE_STATS allow || cmd appops set --user 0 $myPkg GET_USAGE_STATS allow || true; " +
                                    "pm grant -u 0 $myPkg android.permission.PACKAGE_USAGE_STATS >/dev/null 2>&1 || pm grant --user 0 $myPkg android.permission.PACKAGE_USAGE_STATS >/dev/null 2>&1 || pm grant $myPkg android.permission.PACKAGE_USAGE_STATS >/dev/null 2>&1 || true"
                                )
                            } catch (_: Throwable) {}
                        }
                    }
                }
            } catch (_: Throwable) {}
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (!isAnyFeatureActive() && event.eventType != AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
            return
        }

        val eventType = event.eventType
        val eventPkg = event.packageName?.toString().orEmpty()

        // 0. BẢO VỆ PIN & CPU (DEEP SLEEP): Nếu màn hình đang tắt, lập tức return để tránh đánh thức CPU
        // Ngoại lệ duy nhất: TYPE_NOTIFICATION_STATE_CHANGED để bắt mã OTP đến khi màn hình đang khóa
        val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager
        if (pm?.isInteractive == false) {
            if (eventType != AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
                return
            }
        }

        // 1. Khi người dùng thực sự vuốt cuộn màn hình (TYPE_VIEW_SCROLLED):
        // Chỉ chạy khi Dịch Cuộn đang bật và bỏ qua sự kiện từ chính MagicTune overlay / SystemUI
        if (eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED) {
            if (NoAccessibilityScreenEngine.isLiveScrollTranslateActive &&
                com.example.core.widget.GoogleLiveTranslateOverlay.isRunning &&
                !com.example.core.widget.GoogleLiveTranslateOverlay.isPausedForSleep() &&
                eventPkg != packageName &&
                eventPkg != "com.android.systemui"
            ) {
                touchLiveScrollLease(applicationContext ?: this, LIVE_SCROLL_IDLE_SLEEP_MS)
                NoAccessibilityScreenEngine.onLiveScrollEventCallback?.invoke(true)
            } else if (!isAnyFeatureActive()) {
                disableServiceIfIdle(applicationContext ?: this, 60L)
            }
            return
        }

        // 2. Lắng nghe OTP từ thông báo (Notification) trên luồng nền (không xử lý nặng trên Main Thread)
        if (eventType == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
            val textList = event.text
            if (textList.isNullOrEmpty()) return
            val full = textList.joinToString(" ")
            val sender = eventPkg.ifBlank { "Thông báo" }
            val appCtx = applicationContext
            helperScope.launch(Dispatchers.Default) {
                try {
                    com.example.core.keyboard.MagicOtpManager.processRawText(appCtx, full, sender)
                } catch (_: Throwable) {}
            }
            return
        }

        // 3. Chuyển cửa sổ tiền cảnh: đẩy toàn bộ kiểm tra bảo mật ngân hàng & HUD sang Dispatchers.Default
        if (eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            if (eventPkg.isBlank() || eventPkg == "com.android.systemui") return
            if (eventPkg == cachedForegroundPackage && !isBankingBlocked && !isAccessibilityAutoHidden) return
            cachedForegroundPackage = eventPkg
            NoAccessibilityScreenEngine.notifyForegroundPackageChanged(eventPkg)
            val appCtx = applicationContext
            val ownPkg = packageName
            helperScope.launch(Dispatchers.Default) {
                try {
                    if (eventPkg != ownPkg) {
                        SystemFloatingHudOverlay.onForegroundAppChanged(appCtx, eventPkg)
                        if (!isHomeLauncherPackage(appCtx, eventPkg)) {
                            MagicTuneAppSearchWidgetProvider.recordAppLaunch(appCtx, eventPkg)
                        } else {
                            MagicTuneAppSearchWidgetProvider.refreshAllWidgets(appCtx)
                        }
                    }
                    if (NoAccessibilityScreenEngine.isSensitiveBankingPackage(eventPkg)) {
                        Log.w(TAG, "Sensitive banking / VNeID app detected ($eventPkg). Stealth mode: Disabling accessibility immediately!")
                        isBankingBlocked = true
                        isAccessibilityAutoHidden = true
                        temporaryBurstUntilMs = 0L
                        NoAccessibilityScreenEngine.clearCachedScreenNodes()
                        disableServiceViaSecureSettings(appCtx, forceRemoveFromSettings = true, isBankingBlock = true)
                        NoAccessibilityScreenEngine.notifyBankingTransition(appCtx, enteredBanking = true)

                        val now = System.currentTimeMillis()
                        if (now - lastBankingToastMs > 10_000L) {
                            lastBankingToastMs = now
                            mainHandler.post {
                                try {
                                    SystemFloatingHudOverlay.showSecurityPill(appCtx, eventPkg)
                                } catch (_: Throwable) {}
                            }
                        }
                    } else if (isSystemSettingsPackage(eventPkg)) {
                        disableServiceViaSecureSettings(appCtx, forceRemoveFromSettings = true, isBankingBlock = false)
                    } else {
                        mainHandler.post {
                            try {
                                SystemFloatingHudOverlay.hideSecurityPill(appCtx)
                            } catch (_: Throwable) {}
                        }
                        if (isBankingBlocked || isAccessibilityAutoHidden) {
                            isBankingBlocked = false
                            isAccessibilityAutoHidden = false
                            NoAccessibilityScreenEngine.notifyBankingTransition(appCtx, enteredBanking = false)
                        }
                    }
                } catch (_: Throwable) {}
            }
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        if (instance === this) {
            instance = null
        }
        if (!isAnyFeatureActive()) {
            enforceComponentDisabled(applicationContext)
        }
        super.onDestroy()
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        if (instance === this) {
            instance = null
        }
        if (!isAnyFeatureActive()) {
            enforceComponentDisabled(applicationContext)
        }
        return super.onUnbind(intent)
    }

    data class WakeUpResult(
        val connected: Boolean,
        val statusMessage: String
    )

    companion object {
        private const val TAG = "MagicTuneA11yService"

        @Volatile
        var instance: MagicTuneCtsAccessibilityService? = null
            private set

        private val helperScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        private val serviceConnectLock = Object()
        private val serviceStateMutationLock = Object()
        private val mainHandler = android.os.Handler(Looper.getMainLooper())

        @Volatile
        private var lastAppContextRef: Context? = null

        @Volatile
        var isAccessibilityAutoHidden: Boolean = false

        @Volatile
        var isBankingBlocked: Boolean = false

        private const val LIVE_SCROLL_IDLE_SLEEP_MS = 8_000L

        @Volatile
        private var temporaryBurstUntilMs: Long = 0L

        @Volatile
        private var manualWakeUntilMs: Long = 0L

        @Volatile
        private var liveScrollLeaseUntilMs: Long = 0L

        private val activeBurstDepth = java.util.concurrent.atomic.AtomicInteger(0)

        @Volatile
        private var cachedForegroundPackage: String = ""

        @Volatile
        private var lastBankingToastMs: Long = 0L

        private val idleStandbyRunnable = Runnable {
            val ctx = lastAppContextRef ?: return@Runnable
            purgeFromSecureSettingsIfIdle(ctx)
        }

        private val burstSafetySleepRunnable = Runnable {
            activeBurstDepth.set(0)
            temporaryBurstUntilMs = 0L
            manualWakeUntilMs = 0L
            val ctx = lastAppContextRef ?: return@Runnable
            purgeFromSecureSettingsIfIdle(ctx)
        }

        private fun scheduleInactivitySleepCheck(context: Context) {
            val appCtx = context.applicationContext ?: context
            lastAppContextRef = appCtx
            val now = System.currentTimeMillis()
            val maxActiveUntil = maxOf(temporaryBurstUntilMs, maxOf(manualWakeUntilMs, liveScrollLeaseUntilMs))
            val delayMs = (maxActiveUntil - now + 100L).coerceAtLeast(80L)
            mainHandler.removeCallbacks(idleStandbyRunnable)
            mainHandler.postDelayed(idleStandbyRunnable, delayMs)
        }

        @Volatile
        private var lastAutoGrantSilentlyMs: Long = 0L

        @Volatile
        private var hasAttemptedUsageStatsGrantOnConnect: Boolean = false

        fun buildConfiguredEventTypes(liveScrollActive: Boolean): Int {
            return if (liveScrollActive) {
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                    AccessibilityEvent.TYPE_VIEW_SCROLLED
            } else {
                // 0% CPU khi nhàn rỗi: Tắt hoàn toàn lắng nghe sự kiện khi chưa bật Dịch Cuộn
                0
            }
        }

        private fun applyRuntimeServiceConfig(svc: AccessibilityService, liveScrollActive: Boolean) {
            try {
                val info = svc.serviceInfo ?: return
                val targetTypes = buildConfiguredEventTypes(liveScrollActive)
                val activeFlags = android.accessibilityservice.AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                    android.accessibilityservice.AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
                // Luôn bật FLAG_RETRIEVE_INTERACTIVE_WINDOWS khi dịch vụ đang được gọi On-Demand
                // để đọc xuyên qua mọi lớp phủ trong 2ms (khi không dùng, dịch vụ bị gỡ khỏi Settings.Secure và disableSelf hoàn toàn -> 0% CPU)
                val targetFlags = if (liveScrollActive) {
                    (info.flags or activeFlags) and
                        android.accessibilityservice.AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS.inv()
                } else {
                    0
                }
                // Scroll scans already wait for the viewport to settle; sub-100ms callbacks add work.
                val targetTimeout = if (liveScrollActive) 100L else 60_000L
                if (info.eventTypes != targetTypes || info.flags != targetFlags || info.notificationTimeout != targetTimeout) {
                    info.eventTypes = targetTypes
                    info.flags = targetFlags
                    info.notificationTimeout = targetTimeout
                    svc.serviceInfo = info
                }
            } catch (_: Throwable) {}
        }

        fun updateEventSubscriptionForLiveScroll(active: Boolean) {
            val svc = instance ?: return
            val enableOnlyIfTranslatorStillRunning = active &&
                NoAccessibilityScreenEngine.isLiveScrollTranslateActive &&
                com.example.core.widget.GoogleLiveTranslateOverlay.isRunning
            if (Looper.myLooper() == Looper.getMainLooper()) {
                applyRuntimeServiceConfig(svc, enableOnlyIfTranslatorStillRunning)
            } else {
                mainHandler.post {
                    instance?.let { currentSvc ->
                        val stillActive = enableOnlyIfTranslatorStillRunning &&
                            NoAccessibilityScreenEngine.isLiveScrollTranslateActive &&
                            com.example.core.widget.GoogleLiveTranslateOverlay.isRunning
                        applyRuntimeServiceConfig(currentSvc, stillActive)
                    }
                }
            }
        }

        fun hasUsageStatsPermission(context: Context): Boolean {
            return try {
                val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? android.app.AppOpsManager
                val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    appOps?.unsafeCheckOpNoThrow(
                        android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,
                        android.os.Process.myUid(),
                        context.packageName
                    )
                } else {
                    @Suppress("DEPRECATION")
                    appOps?.checkOpNoThrow(
                        android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,
                        android.os.Process.myUid(),
                        context.packageName
                    )
                }
                if (mode == android.app.AppOpsManager.MODE_ALLOWED) return true
                context.checkCallingOrSelfPermission(android.Manifest.permission.PACKAGE_USAGE_STATS) ==
                    android.content.pm.PackageManager.PERMISSION_GRANTED
            } catch (_: Throwable) {
                false
            }
        }

        private fun isHomeLauncherPackage(context: Context, pkg: String): Boolean {
            if (pkg.isBlank()) return true
            return try {
                val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                val resolveInfo = context.packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
                val defaultHome = resolveInfo?.activityInfo?.packageName
                pkg == defaultHome || pkg.contains(".launcher", ignoreCase = true) ||
                    pkg == "com.hihonor.android.launcher" || pkg == "com.huawei.android.launcher" ||
                    pkg == "com.google.android.apps.nexuslauncher"
            } catch (_: Throwable) {
                false
            }
        }

        fun ensureAssistSettingsEnabledIfNeeded(context: Context) {
            try {
                val cr = context.contentResolver
                if (Settings.Secure.getInt(cr, "assist_structure_enabled", 0) != 1) {
                    Settings.Secure.putInt(cr, "assist_structure_enabled", 1)
                }
                if (Settings.Secure.getInt(cr, "assist_screenshot_enabled", 0) != 1) {
                    Settings.Secure.putInt(cr, "assist_screenshot_enabled", 1)
                }
                if (Settings.Secure.getInt(cr, "assist_disclosure_enabled", 0) != 1) {
                    Settings.Secure.putInt(cr, "assist_disclosure_enabled", 1)
                }
            } catch (_: Throwable) {}
        }

        fun isSystemSettingsPackage(pkg: String): Boolean {
            val p = pkg.lowercase()
            return p == "com.android.settings" ||
                p == "com.hihonor.settings" ||
                p == "com.huawei.settings" ||
                p == "com.samsung.android.settings" ||
                p == "com.coloros.settings" ||
                p == "com.oplus.settings" ||
                p == "com.vivo.settings" ||
                p == "com.miui.securitycenter" ||
                p == "com.miui.accessibility" ||
                p == "com.google.android.settings.intelligence" ||
                p.contains("settings.accessibility") ||
                p.contains("accessibilitysettings")
        }

        fun isComponentEnabled(context: Context): Boolean {
            val appCtx = context.applicationContext ?: context
            return try {
                val cn = android.content.ComponentName(appCtx, MagicTuneCtsAccessibilityService::class.java)
                appCtx.packageManager.getComponentEnabledSetting(cn) ==
                    android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_ENABLED
            } catch (_: Throwable) {
                false
            }
        }

        private fun resolveFreshForegroundPackage(appCtx: Context): String {
            if (instance == null) {
                NoAccessibilityScreenEngine.invalidateForegroundPackageCache()
            }
            val queried = NoAccessibilityScreenEngine.getActiveForegroundPackage(appCtx, forceFresh = true).orEmpty()
            if (queried.isNotBlank()) {
                cachedForegroundPackage = queried
                return queried
            }
            if (instance != null && cachedForegroundPackage.isNotBlank()) {
                return cachedForegroundPackage
            }
            return ""
        }

        fun enforceComponentDisabled(context: Context) {
            val appCtx = context.applicationContext ?: context
            try {
                val cn = android.content.ComponentName(appCtx, MagicTuneCtsAccessibilityService::class.java)
                val curState = appCtx.packageManager.getComponentEnabledSetting(cn)
                if (curState != android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_DISABLED) {
                    appCtx.packageManager.setComponentEnabledSetting(
                        cn,
                        android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                        android.content.pm.PackageManager.DONT_KILL_APP
                    )
                }
            } catch (_: Throwable) {}
        }

        fun enforceComponentEnabled(context: Context): Boolean {
            val appCtx = context.applicationContext ?: context
            return try {
                val cn = android.content.ComponentName(appCtx, MagicTuneCtsAccessibilityService::class.java)
                val curState = appCtx.packageManager.getComponentEnabledSetting(cn)
                if (curState != android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_ENABLED) {
                    appCtx.packageManager.setComponentEnabledSetting(
                        cn,
                        android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                        android.content.pm.PackageManager.DONT_KILL_APP
                    )
                    true // vừa chuyển từ DISABLED -> ENABLED
                } else {
                    false
                }
            } catch (_: Throwable) {
                false
            }
        }

        /**
         * Tự động cấp quyền nền và cấu hình Trợ năng ngầm On-Demand qua WRITE_SECURE_SETTINGS / ShellEngine.
         * CHẾ ĐỘ ON-DEMAND TÀNG HÌNH: Khi ở trạng thái nghỉ, dịch vụ LUÔN TẮT (gỡ khỏi enabled_accessibility_services,
         * khóa Component DISABLED để ẩn khỏi Cài đặt -> Trợ năng & Bank/VNeID, và disableSelf).
         */
        fun autoGrantAndEnableSilently(context: Context): Boolean {
            val appCtx = context.applicationContext ?: context
            lastAppContextRef = appCtx

            if (!isAnyFeatureActive()) {
                enforceComponentDisabled(appCtx)
            }
            val shell = ShellEngine.getInstance(appCtx)
            helperScope.launch {
                try {
                    val liveFg = resolveFreshForegroundPackage(appCtx)
                    if (liveFg.isNotBlank() && NoAccessibilityScreenEngine.isSensitiveBankingPackage(liveFg)) {
                        disableServiceViaSecureSettings(appCtx, forceRemoveFromSettings = true, isBankingBlock = true)
                    } else {
                        purgeFromSecureSettingsIfIdle(appCtx)
                    }
                    val now = android.os.SystemClock.elapsedRealtime()
                    val kvPrefs = appCtx.getSharedPreferences("magictune_persisted_kv", Context.MODE_PRIVATE)
                    val needsShellRestore = !kvPrefs.getBoolean("auto_restored_power_pkgs_shell_v70", false)
                    val needsAutoGrant = needsShellRestore ||
                        !shell.hasWriteSecureSettingsPermission() ||
                        !android.provider.Settings.canDrawOverlays(appCtx)
                    if (shell.state.value.isAdbReady && needsAutoGrant && (lastAutoGrantSilentlyMs == 0L || now - lastAutoGrantSilentlyMs >= 60_000L)) {
                        lastAutoGrantSilentlyMs = now
                        shell.autoGrantSelfPermissions()
                        reinforceHonorMagicOsKeepAlive(appCtx)
                    }
                    purgeFromSecureSettingsIfIdle(appCtx)
                } catch (_: Throwable) {}
            }

            return true
        }

        fun isServiceEnabledInSettings(context: Context): Boolean {
            val appCtx = context.applicationContext ?: context
            return try {
                val enabled = Settings.Secure.getString(
                    appCtx.contentResolver,
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
                ) ?: ""
                enabled.contains(appCtx.packageName) && enabled.contains("MagicTuneCtsAccessibilityService")
            } catch (_: Throwable) {
                false
            }
        }

        /**
         * Bạch danh Doze mode, Standby Bucket, TARE VIP và bảo vệ chạy nền trên Honor MagicOS 10 / 11 & Android 17
         */
        fun reinforceHonorMagicOsKeepAlive(context: Context) {
            val appCtx = context.applicationContext ?: context
            val pkg = appCtx.packageName
            val shell = ShellEngine.getInstance(appCtx)
            if (shell.state.value.isAdbReady && !shell.wasSelfPermsAutoGrantedRecently()) {
                helperScope.launch {
                    try {
                        val cmd = shell.buildSafeKeepAliveCommands(pkg)
                        shell.execute(cmd)
                    } catch (_: Throwable) {}
                }
            }
        }

        fun isAnyFeatureActive(): Boolean {
            val now = System.currentTimeMillis()
            val hasActiveBurst = activeBurstDepth.get() > 0 && now < temporaryBurstUntilMs
            val hasManualWakeWindow = now < manualWakeUntilMs
            val isLiveScrollRunning = com.example.core.widget.GoogleLiveTranslateOverlay.isRunning &&
                !com.example.core.widget.GoogleLiveTranslateOverlay.isPausedForSleep() &&
                NoAccessibilityScreenEngine.isLiveScrollTranslateActive &&
                now < liveScrollLeaseUntilMs
            return hasActiveBurst ||
                hasManualWakeWindow ||
                isLiveScrollRunning
        }

        fun touchLiveScrollLease(context: Context, leaseMs: Long = LIVE_SCROLL_IDLE_SLEEP_MS) {
            val appCtx = context.applicationContext ?: context
            lastAppContextRef = appCtx
            val safeLease = leaseMs.coerceIn(1_500L, 12_000L)
            liveScrollLeaseUntilMs = System.currentTimeMillis() + safeLease
            scheduleInactivitySleepCheck(appCtx)
        }

        fun clearLiveScrollLease() {
            liveScrollLeaseUntilMs = 0L
        }

        fun beginTemporaryBurst(durationMs: Long = 1500L) {
            val safeDuration = durationMs.coerceIn(250L, 10_000L)
            activeBurstDepth.incrementAndGet()
            temporaryBurstUntilMs = maxOf(temporaryBurstUntilMs, System.currentTimeMillis() + safeDuration)
            mainHandler.removeCallbacks(idleStandbyRunnable)
            mainHandler.removeCallbacks(burstSafetySleepRunnable)
            mainHandler.postDelayed(burstSafetySleepRunnable, safeDuration + 120L)
        }

        /**
         * ĐƯA TRỢ NĂNG VÀO NGỦ SÂU TỨC THÌ (Instant Deep Sleep 0ms):
         * - Đặt eventTypes = 0 & flags = 0 trên instance: Android system_server ngừng bắn 100% sự kiện -> 0% CPU, 0 Binder IPC.
         * - Xóa sạch burst counter, manual wake window và lease thừa.
         * - Xóa sạch cache node & giải phóng bộ nhớ.
         * - Gỡ khỏi ENABLED_ACCESSIBILITY_SERVICES và vô hiệu hóa component ngay để dòng xả về 0 mA và an toàn 100% trước Bank / VNeID.
         */
        fun enterDeepSleepNow(context: Context, forceImmediate: Boolean = true) {
            val appCtx = context.applicationContext ?: context
            lastAppContextRef = appCtx
            mainHandler.removeCallbacks(idleStandbyRunnable)
            mainHandler.removeCallbacks(burstSafetySleepRunnable)

            val liveScrollActuallyRunning =
                com.example.core.widget.GoogleLiveTranslateOverlay.isRunning &&
                    NoAccessibilityScreenEngine.isLiveScrollTranslateActive
            if (!liveScrollActuallyRunning) {
                // Clear stale feature state so an already-closed overlay cannot keep Accessibility awake.
                NoAccessibilityScreenEngine.isLiveScrollTranslateActive = false
                liveScrollLeaseUntilMs = 0L
            }

            // 1. Cắt đứt ngay lập tức mọi event từ Android system_server (0% CPU trong 0ms)
            instance?.let { svc ->
                try {
                    val info = svc.serviceInfo
                    if (info != null && (info.eventTypes != 0 || info.flags != 0)) {
                        info.eventTypes = 0
                        info.flags = 0
                        info.notificationTimeout = 60_000L
                        svc.serviceInfo = info
                    }
                } catch (_: Throwable) {}
            }

            // 2. Xóa sạch mọi cửa sổ duy trì thức
            activeBurstDepth.set(0)
            temporaryBurstUntilMs = 0L
            manualWakeUntilMs = 0L
            if (!liveScrollActuallyRunning) liveScrollLeaseUntilMs = 0L

            // 3. Xóa sạch bộ nhớ đệm giao diện
            NoAccessibilityScreenEngine.clearCachedScreenNodes()

            // 4. Nếu không có tính năng dịch cuộn đang chạy, tiến hành gỡ bỏ khỏi Secure Settings
            if (!liveScrollActuallyRunning) {
                if (forceImmediate) {
                    disableServiceViaSecureSettings(appCtx, forceRemoveFromSettings = true, isBankingBlock = false)
                } else {
                    mainHandler.postDelayed(idleStandbyRunnable, 40L)
                }
            }
        }

        fun endTemporaryBurstAndIdle(context: Context, idleDelayMs: Long = 80L) {
            val appCtx = context.applicationContext ?: context
            val remaining = activeBurstDepth.decrementAndGet()
            if (remaining <= 0) {
                activeBurstDepth.set(0)
                temporaryBurstUntilMs = 0L
                manualWakeUntilMs = 0L
                mainHandler.removeCallbacks(burstSafetySleepRunnable)
                if (!isAnyFeatureActive()) {
                    enterDeepSleepNow(appCtx, forceImmediate = (idleDelayMs <= 40L))
                } else {
                    scheduleInactivitySleepCheck(appCtx)
                }
            }
        }

        fun resetAutoHiddenFlagIfSafe(context: Context) {
            val appCtx = context.applicationContext ?: context
            val liveFg = NoAccessibilityScreenEngine.getActiveForegroundPackage(appCtx) ?: cachedForegroundPackage
            if (liveFg.isBlank() || !NoAccessibilityScreenEngine.isSensitiveBankingPackage(liveFg)) {
                cachedForegroundPackage = liveFg
                isBankingBlocked = false
                isAccessibilityAutoHidden = false
            }
        }

        fun isServiceConnected(): Boolean = instance != null && !isBankingBlocked && !isAccessibilityAutoHidden

        /**
         * Kích hoạt ngầm dịch vụ đọc màn hình qua WRITE_SECURE_SETTINGS (hoặc ADB Shell) theo nhu cầu (On-Demand <5ms),
         * và tự động khóa/gỡ ngay lập tức nếu đang ở trong ứng dụng Ngân hàng / VNeID hoặc Cài đặt.
         */
        private fun waitForInstalledRegistrationIfNeeded(appCtx: Context, maxWaitMs: Long = 380L) {
            if (Looper.myLooper() == Looper.getMainLooper()) return
            val am = try {
                appCtx.getSystemService(Context.ACCESSIBILITY_SERVICE) as? android.view.accessibility.AccessibilityManager
            } catch (_: Throwable) { null } ?: return
            val pkg = appCtx.packageName
            val deadline = android.os.SystemClock.elapsedRealtime() + maxWaitMs
            while (android.os.SystemClock.elapsedRealtime() < deadline) {
                val registered = try {
                    am.installedAccessibilityServiceList.any { info ->
                        val si = info.resolveInfo?.serviceInfo
                        si != null && si.packageName == pkg && si.name.contains("MagicTuneCtsAccessibilityService")
                    }
                } catch (_: Throwable) { false }
                if (registered) return
                try { Thread.sleep(12L) } catch (_: InterruptedException) { return }
            }
        }

        fun ensureServiceEnabledViaSecureSettings(context: Context, forceRebindPoke: Boolean = false): Boolean {
            val appCtx = context.applicationContext ?: context
            lastAppContextRef = appCtx
            mainHandler.removeCallbacks(idleStandbyRunnable)

            val liveFg = resolveFreshForegroundPackage(appCtx)
            if (liveFg.isNotBlank() && NoAccessibilityScreenEngine.isSensitiveBankingPackage(liveFg)) {
                disableServiceViaSecureSettings(appCtx, forceRemoveFromSettings = true, isBankingBlock = true)
                return false
            }
            if (liveFg.isNotBlank() && isSystemSettingsPackage(liveFg)) {
                disableServiceViaSecureSettings(appCtx, forceRemoveFromSettings = true, isBankingBlock = false)
                return false
            }

            val justEnabledComponent = enforceComponentEnabled(appCtx)
            if (justEnabledComponent && Looper.myLooper() != Looper.getMainLooper()) {
                waitForInstalledRegistrationIfNeeded(appCtx, 380L)
            }

            synchronized(serviceStateMutationLock) {
                if (!forceRebindPoke && instance != null && !isBankingBlocked && !isAccessibilityAutoHidden) {
                    return true
                }

                isBankingBlocked = false
                isAccessibilityAutoHidden = false

                val cr = appCtx.contentResolver
                val pkg = appCtx.packageName
                val targetService = "$pkg/${MagicTuneCtsAccessibilityService::class.java.name}"

                val hasWriteSecure = try {
                    appCtx.checkCallingOrSelfPermission(android.Manifest.permission.WRITE_SECURE_SETTINGS) ==
                        android.content.pm.PackageManager.PERMISSION_GRANTED
                } catch (_: Throwable) { false }

                if (hasWriteSecure) {
                    try {
                        ensureAssistSettingsEnabledIfNeeded(appCtx)
                        val current = Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
                        val entries = current.split(":").map { it.trim() }.filter { it.isNotEmpty() }.toMutableList()
                        val alreadyListed = entries.any { it.contains(pkg) && it.contains("MagicTuneCtsAccessibilityService") }
                        if (forceRebindPoke && alreadyListed && instance == null) {
                            val withoutSelf = entries.filterNot { it.contains(pkg) && it.contains("MagicTuneCtsAccessibilityService") }
                            Settings.Secure.putString(
                                cr,
                                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
                                withoutSelf.joinToString(":")
                            )
                            if (Looper.myLooper() != Looper.getMainLooper()) {
                                try { Thread.sleep(20L) } catch (_: InterruptedException) {}
                            }
                        }
                        if (!alreadyListed || forceRebindPoke || justEnabledComponent) {
                            val updatedEntries = entries.filterNot { it.contains(pkg) && it.contains("MagicTuneCtsAccessibilityService") }.toMutableList()
                            updatedEntries.add(targetService)
                            Settings.Secure.putString(
                                cr,
                                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
                                updatedEntries.joinToString(":")
                            )
                        }
                        if (Settings.Secure.getInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 0) != 1) {
                            Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
                        }
                        return true
                    } catch (_: Throwable) {}
                }

                val shell = ShellEngine.getInstance(appCtx)
                if (shell.state.value.isAdbReady) {
                    helperScope.launch {
                        try {
                            val cmd = "pm grant --user 0 $pkg android.permission.WRITE_SECURE_SETTINGS >/dev/null 2>&1 || pm grant $pkg android.permission.WRITE_SECURE_SETTINGS >/dev/null 2>&1 || true; " +
                                "pm enable --user 0 '$targetService' >/dev/null 2>&1 || pm enable '$targetService' >/dev/null 2>&1 || true; " +
                                "curr=\$(settings get secure enabled_accessibility_services 2>/dev/null || true); " +
                                "if [ -z \"\$curr\" ] || [ \"\$curr\" = \"null\" ]; then " +
                                "settings put secure enabled_accessibility_services '$targetService' >/dev/null 2>&1 || true; " +
                                "elif ! printf '%s' \"\$curr\" | grep -qF '$targetService'; then " +
                                "settings put secure enabled_accessibility_services \"\$curr:$targetService\" >/dev/null 2>&1 || true; fi; " +
                                "settings put secure accessibility_enabled 1 >/dev/null 2>&1 || true"
                            shell.execute(cmd)
                        } catch (_: Throwable) {}
                    }
                    return true
                }

                return isServiceConnected()
            }
        }

        /**
         * Chế độ Tàng Hình An Toàn Tuyệt Đối cho App Ngân Hàng, VNeID, Cài đặt & Trạng Thái Nghỉ:
         * - Luôn gỡ ngay MagicTune khỏi `Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES`, gọi `disableSelf()`,
         *   VÀ LUÔN khóa Component (`enforceComponentDisabled`) để MagicTune biến mất 100% khỏi
         *   Cài đặt -> Trợ năng lẫn danh sách AccessibilityManager của mọi app Ngân hàng / Chính phủ.
         * - Nếu không còn dịch vụ trợ năng nào khác đang bật trên máy, đặt lại `ACCESSIBILITY_ENABLED = 0`.
         */
        fun disableServiceViaSecureSettings(
            context: Context,
            forceRemoveFromSettings: Boolean = false,
            isBankingBlock: Boolean = false
        ) {
            val appCtx = context.applicationContext ?: context
            mainHandler.removeCallbacks(idleStandbyRunnable)
            mainHandler.removeCallbacks(burstSafetySleepRunnable)
            synchronized(serviceStateMutationLock) {
                activeBurstDepth.set(0)
                temporaryBurstUntilMs = 0L
                manualWakeUntilMs = 0L
                liveScrollLeaseUntilMs = 0L
                cachedForegroundPackage = ""
                if (isBankingBlock) {
                    isBankingBlocked = true
                    isAccessibilityAutoHidden = true
                    NoAccessibilityScreenEngine.clearCachedScreenNodes()
                } else {
                    isBankingBlocked = false
                    isAccessibilityAutoHidden = false
                    NoAccessibilityScreenEngine.clearForegroundPackageCache()
                }

                // LUÔN khóa component khi tắt/nghỉ để không bao giờ lộ diện trong Settings -> Trợ năng hay app Bank/VNeID
                enforceComponentDisabled(appCtx)

                val cr = appCtx.contentResolver
                val pkg = appCtx.packageName
                val hasWriteSecure = try {
                    appCtx.checkCallingOrSelfPermission(android.Manifest.permission.WRITE_SECURE_SETTINGS) ==
                        android.content.pm.PackageManager.PERMISSION_GRANTED
                } catch (_: Throwable) { false }

                var stillNeedsShellRemoval = false
                if (hasWriteSecure) {
                    try {
                        val current = Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
                        val entries = current.split(":").map { it.trim() }.filter { it.isNotEmpty() }
                        val remaining = entries.filterNot { it.contains(pkg) }
                        val filtered = remaining.joinToString(":")
                        if (current.contains(pkg)) {
                            Settings.Secure.putString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, filtered)
                        }
                        if (remaining.isEmpty() && Settings.Secure.getInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 0) != 0) {
                            Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 0)
                        }
                    } catch (_: Throwable) {
                        stillNeedsShellRemoval = true
                    }
                } else {
                    stillNeedsShellRemoval = try {
                        val current = Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
                        current.contains(pkg) || (current.isBlank() && Settings.Secure.getInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 0) != 0)
                    } catch (_: Throwable) {
                        false
                    }
                }

                if (stillNeedsShellRemoval) {
                    val shell = ShellEngine.getInstance(appCtx)
                    if (shell.state.value.isAdbReady) {
                        helperScope.launch {
                            try {
                                val cmd = "curr=\$(settings get secure enabled_accessibility_services 2>/dev/null || true); " +
                                    "if [ -n \"\$curr\" ] && [ \"\$curr\" != \"null\" ] && printf '%s' \"\$curr\" | grep -qF '$pkg'; then " +
                                    "updated=\$(printf '%s' \"\$curr\" | tr ':' '\\n' | grep -vF '$pkg' | grep -v '^\$' | paste -sd ':' -); " +
                                    "if [ -n \"\$updated\" ]; then settings put secure enabled_accessibility_services \"\$updated\" >/dev/null 2>&1 || true; " +
                                    "else settings delete secure enabled_accessibility_services >/dev/null 2>&1 || true; settings put secure accessibility_enabled 0 >/dev/null 2>&1 || true; fi; " +
                                    "elif [ -z \"\$curr\" ] || [ \"\$curr\" = \"null\" ]; then settings put secure accessibility_enabled 0 >/dev/null 2>&1 || true; fi; true"
                                shell.execute(cmd)
                            } catch (_: Throwable) {}
                        }
                    }
                }

                try {
                    instance?.disableSelf()
                } catch (_: Throwable) {}
                instance = null
            }
        }

        fun purgeFromSecureSettingsIfIdle(context: Context) {
            val appCtx = context.applicationContext ?: context
            lastAppContextRef = appCtx

            // Khi người dùng đang trực tiếp chạm/cuộn trang ngay bên trong MainActivity của MagicTune
            // (100% không phải đang mở App Ngân hàng hay Cài đặt máy) và Trợ năng đang nghỉ:
            // Tạm hoãn toàn bộ lệnh Binder IPC (PackageManager & Settings.Secure) sang sau khi ngừng cuộn 2.6s
            // để trình bảo mật SystemManager của máy không quét ngang gây khựng khung hình.
            if (instance == null &&
                !isAnyFeatureActive() &&
                com.example.core.perf.MagicTuneSelfPowerGovernor.isUserActivelyInteractingInApp()
            ) {
                mainHandler.removeCallbacks(idleStandbyRunnable)
                mainHandler.postDelayed(idleStandbyRunnable, 2_600L)
                return
            }

            val inSettingsList = isServiceEnabledInSettings(appCtx)
            val compEnabled = isComponentEnabled(appCtx)
            val cr = appCtx.contentResolver
            val hasOrphanedMasterFlag = try {
                val enabledList = Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
                enabledList.isBlank() && Settings.Secure.getInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 0) != 0
            } catch (_: Throwable) {
                false
            }

            // Fast-path 0ms: Chỉ thoát sớm khi đã gỡ sạch khỏi Settings, đã disableSelf(), component đã DISABLED và accessibility_enabled đã sạch
            if (!inSettingsList && instance == null && !compEnabled && !hasOrphanedMasterFlag) {
                return
            }

            val liveFg = resolveFreshForegroundPackage(appCtx)
            val isBanking = liveFg.isNotBlank() && NoAccessibilityScreenEngine.isSensitiveBankingPackage(liveFg)
            val isInSettings = liveFg.isNotBlank() && isSystemSettingsPackage(liveFg)

            if (isBanking) {
                disableServiceViaSecureSettings(appCtx, forceRemoveFromSettings = true, isBankingBlock = true)
            } else if (isInSettings) {
                disableServiceViaSecureSettings(appCtx, forceRemoveFromSettings = true, isBankingBlock = false)
            } else if (!isAnyFeatureActive()) {
                disableServiceViaSecureSettings(appCtx, forceRemoveFromSettings = true, isBankingBlock = false)
            }
        }

        fun forceDisableServiceNow(context: Context) {
            mainHandler.removeCallbacks(idleStandbyRunnable)
            disableServiceViaSecureSettings(context, forceRemoveFromSettings = true, isBankingBlock = true)
        }

        fun disableServiceIfIdle(context: Context, idleDelayMs: Long = 250L) {
            val appCtx = context.applicationContext ?: context
            lastAppContextRef = appCtx
            mainHandler.removeCallbacks(idleStandbyRunnable)
            if (idleDelayMs <= 0L) {
                purgeFromSecureSettingsIfIdle(appCtx)
            } else {
                mainHandler.postDelayed(idleStandbyRunnable, idleDelayMs)
            }
        }

        /**
         * Đánh thức Trợ năng ngầm tức thì theo yêu cầu chủ động của người dùng ("Đánh thức trợ năng"):
         * 1. Xóa sạch trạng thái khóa/cache cũ (trừ khi thực sự đang đứng trong app Ngân hàng/VNeID).
         * 2. Mở component (`ENABLED`), chờ AccessibilityManagerService cập nhật danh sách dịch vụ đã cài.
         * 3. Ghi chu kỳ làm mới `ENABLED_ACCESSIBILITY_SERVICES` + `ACCESSIBILITY_ENABLED = 1` (qua `WRITE_SECURE_SETTINGS`
         *    và cả `ShellEngine` nếu đang có ADB/Shizuku).
         * 4. Chờ bind tối đa `maxWaitMs` và giữ burst 10 giây để các tính năng đọc màn hình hoạt động ngay.
         */
        suspend fun wakeUpAccessibilityService(
            context: Context,
            maxWaitMs: Long = 1600L
        ): WakeUpResult = withContext(Dispatchers.IO) {
            val appCtx = context.applicationContext ?: context
            lastAppContextRef = appCtx
            mainHandler.removeCallbacks(idleStandbyRunnable)

            NoAccessibilityScreenEngine.invalidateForegroundPackageCache()
            val liveFg = NoAccessibilityScreenEngine.getActiveForegroundPackage(appCtx, forceFresh = true).orEmpty()
            if (liveFg.isNotBlank() && NoAccessibilityScreenEngine.isSensitiveBankingPackage(liveFg)) {
                disableServiceViaSecureSettings(appCtx, forceRemoveFromSettings = true, isBankingBlock = true)
                return@withContext WakeUpResult(
                    connected = false,
                    statusMessage = "🛡️ Đang trong ứng dụng Ngân hàng/VNeID, giữ ẩn Trợ năng để bảo mật."
                )
            }
            if (liveFg.isNotBlank() && isSystemSettingsPackage(liveFg)) {
                return@withContext WakeUpResult(
                    connected = false,
                    statusMessage = "⚙️ Hãy thoát khỏi Cài đặt hệ thống để Trợ năng ngầm tự động bật lại."
                )
            }

            isBankingBlocked = false
            isAccessibilityAutoHidden = false
            cachedForegroundPackage = ""
            NoAccessibilityScreenEngine.clearForegroundPackageCache()
            NoAccessibilityScreenEngine.clearCachedScreenNodes()

            // FAST-PATH 0ms: Nếu instance đang kết nối sẵn -> SỐNG LẠI TỨC THÌ TRONG 0MS!
            val existingSvc = instance
            if (existingSvc != null) {
                manualWakeUntilMs = System.currentTimeMillis() + 1_500L
                if (NoAccessibilityScreenEngine.isLiveScrollTranslateActive &&
                    com.example.core.widget.GoogleLiveTranslateOverlay.isRunning
                ) {
                    liveScrollLeaseUntilMs = System.currentTimeMillis() + LIVE_SCROLL_IDLE_SLEEP_MS
                }
                mainHandler.removeCallbacks(idleStandbyRunnable)
                mainHandler.removeCallbacks(burstSafetySleepRunnable)
                mainHandler.post {
                    try {
                        applyRuntimeServiceConfig(existingSvc, NoAccessibilityScreenEngine.isLiveScrollTranslateActive)
                    } catch (_: Throwable) {}
                }
                return@withContext WakeUpResult(
                    connected = true,
                    statusMessage = "⚡ Đã đánh thức Trợ năng tức thì (0ms)!"
                )
            }

            manualWakeUntilMs = System.currentTimeMillis() + 1_800L
            if (NoAccessibilityScreenEngine.isLiveScrollTranslateActive &&
                com.example.core.widget.GoogleLiveTranslateOverlay.isRunning
            ) {
                liveScrollLeaseUntilMs = System.currentTimeMillis() + LIVE_SCROLL_IDLE_SLEEP_MS
            }
            mainHandler.removeCallbacks(idleStandbyRunnable)
            mainHandler.removeCallbacks(burstSafetySleepRunnable)
            mainHandler.postDelayed(burstSafetySleepRunnable, 2_000L)

            val hasWriteSecure = try {
                appCtx.checkCallingOrSelfPermission(android.Manifest.permission.WRITE_SECURE_SETTINGS) ==
                    android.content.pm.PackageManager.PERMISSION_GRANTED
            } catch (_: Throwable) { false }
            val shell = ShellEngine.getInstance(appCtx)
            val isAdbReady = shell.state.value.isAdbReady

            if (!hasWriteSecure && !isAdbReady && instance == null) {
                return@withContext WakeUpResult(
                    connected = false,
                    statusMessage = "⚠️ Quyền WRITE_SECURE_SETTINGS chưa có & WLAN ADB đang ngắt. Hãy kết nối Gỡ lỗi Wi-Fi 1 lần để khôi phục."
                )
            }

            val justEnabled = enforceComponentEnabled(appCtx)
            if (justEnabled) {
                waitForInstalledRegistrationIfNeeded(appCtx, 280L)
            }

            val pkg = appCtx.packageName
            val targetService = "$pkg/${MagicTuneCtsAccessibilityService::class.java.name}"

            if (isAdbReady) {
                try {
                    shell.execute(
                        "pm grant --user 0 $pkg android.permission.WRITE_SECURE_SETTINGS >/dev/null 2>&1 || pm grant $pkg android.permission.WRITE_SECURE_SETTINGS >/dev/null 2>&1 || true; " +
                            "pm enable --user 0 '$targetService' >/dev/null 2>&1 || pm enable '$targetService' >/dev/null 2>&1 || true; " +
                            "curr=\$(settings get secure enabled_accessibility_services 2>/dev/null || true); " +
                            "if [ -z \"\$curr\" ] || [ \"\$curr\" = \"null\" ]; then " +
                            "settings put secure enabled_accessibility_services '$targetService' >/dev/null 2>&1 || true; " +
                            "elif ! printf '%s' \"\$curr\" | grep -qF '$targetService'; then " +
                            "settings put secure enabled_accessibility_services \"\$curr:$targetService\" >/dev/null 2>&1 || true; fi; " +
                            "settings put secure accessibility_enabled 1 >/dev/null 2>&1 || true"
                    )
                } catch (_: Throwable) {}
            }

            ensureServiceEnabledViaSecureSettings(appCtx, forceRebindPoke = instance == null)

            var pokeStep = 0
            val start = System.currentTimeMillis()
            synchronized(serviceConnectLock) {
                while (instance == null && System.currentTimeMillis() - start < maxWaitMs) {
                    val elapsed = System.currentTimeMillis() - start
                    if ((pokeStep == 0 && elapsed >= 90L) ||
                        (pokeStep == 1 && elapsed >= 280L) ||
                        (pokeStep == 2 && elapsed >= 550L)
                    ) {
                        pokeStep++
                        try {
                            ensureServiceEnabledViaSecureSettings(appCtx, forceRebindPoke = true)
                        } catch (_: Throwable) {}
                    }
                    try {
                        (serviceConnectLock as Object).wait(10L)
                    } catch (_: InterruptedException) {
                        break
                    }
                }
            }

            val connectedSvc = instance
            if (connectedSvc != null) {
                mainHandler.post {
                    try {
                        applyRuntimeServiceConfig(connectedSvc, NoAccessibilityScreenEngine.isLiveScrollTranslateActive)
                    } catch (_: Throwable) {}
                }
                return@withContext WakeUpResult(
                    connected = true,
                    statusMessage = "⚡ Đã đánh thức Trợ năng! Sẵn sàng đọc màn hình."
                )
            }

            return@withContext WakeUpResult(
                connected = false,
                statusMessage = "⚠️ Honor vừa giữ chậm kết nối Trợ năng. Hãy bấm Đánh thức lại hoặc kiểm tra Gỡ lỗi Wi-Fi."
            )
        }

        fun awaitServiceInstance(context: Context, maxWaitMs: Long = 750L): MagicTuneCtsAccessibilityService? {
            // Chống ANR tuyệt đối: Nếu được gọi từ Main Thread, không bao giờ dùng lock.wait() làm đơ UI
            if (Looper.myLooper() == Looper.getMainLooper()) {
                return instance
            }
            val appCtx = context.applicationContext ?: context
            val liveFg = resolveFreshForegroundPackage(appCtx)
            if (liveFg.isNotBlank() && (NoAccessibilityScreenEngine.isSensitiveBankingPackage(liveFg) || isSystemSettingsPackage(liveFg))) {
                disableServiceViaSecureSettings(
                    appCtx,
                    forceRemoveFromSettings = true,
                    isBankingBlock = NoAccessibilityScreenEngine.isSensitiveBankingPackage(liveFg)
                )
                return null
            }
            // Nếu đã thoát app Ngân hàng/Cài đặt -> tự động mở khóa lại để gọi thức Trợ năng khi cần đọc màn hình
            if (isBankingBlocked || isAccessibilityAutoHidden) {
                isBankingBlocked = false
                isAccessibilityAutoHidden = false
            }

            val inst = instance
            if (inst != null) return inst

            if (!ensureServiceEnabledViaSecureSettings(appCtx, forceRebindPoke = false)) {
                return null
            }
            instance?.let { return it }

            var pokeCount = 0
            val start = System.currentTimeMillis()
            synchronized(serviceConnectLock) {
                while (instance == null && System.currentTimeMillis() - start < maxWaitMs) {
                    val elapsed = System.currentTimeMillis() - start
                    if ((pokeCount == 0 && elapsed >= 90L) ||
                        (pokeCount == 1 && elapsed >= 280L) ||
                        (pokeCount == 2 && elapsed >= 480L)
                    ) {
                        pokeCount++
                        try {
                            ensureServiceEnabledViaSecureSettings(appCtx, forceRebindPoke = true)
                        } catch (_: Throwable) {}
                    }
                    try {
                        (serviceConnectLock as Object).wait(15L)
                    } catch (_: InterruptedException) {
                        break
                    }
                }
            }
            return instance
        }

        @androidx.annotation.RequiresApi(Build.VERSION_CODES.R)
        private object TakeScreenshotApi30 {
            suspend fun capture(appCtx: Context, svc: AccessibilityService): Bitmap? {
                return withTimeoutOrNull(900L) {
                    suspendCancellableCoroutine<Bitmap?> { cont ->
                        try {
                            svc.takeScreenshot(
                                Display.DEFAULT_DISPLAY,
                                appCtx.mainExecutor,
                                object : TakeScreenshotCallback {
                                    override fun onSuccess(screenshot: ScreenshotResult) {
                                        val bmp = try {
                                            val hwBuf = screenshot.hardwareBuffer
                                            val colorSpace = screenshot.colorSpace
                                            val wrapped = Bitmap.wrapHardwareBuffer(hwBuf, colorSpace)
                                            val softBmp = try {
                                                wrapped?.copy(Bitmap.Config.ARGB_8888, false)
                                            } finally {
                                                try { wrapped?.recycle() } catch (_: Throwable) {}
                                                try { hwBuf.close() } catch (_: Throwable) {}
                                            }
                                            softBmp
                                        } catch (_: Throwable) { null }
                                        if (cont.isActive) cont.resume(bmp)
                                    }

                                    override fun onFailure(errorCode: Int) {
                                        if (cont.isActive) cont.resume(null)
                                    }
                                }
                            )
                        } catch (_: Throwable) {
                            if (cont.isActive) cont.resume(null)
                        }
                    }
                }
            }
        }

        /**
         * Chụp ảnh màn hình qua Accessibility API (Android 11+ / API 30+) theo cơ chế On-Demand ~100ms:
         * Tự động bật ngầm trong tích tắc để chụp màn hình gốc rồi lập tức tắt & ẩn lại nếu đang nghỉ.
         */
        suspend fun captureScreenViaAccessibility(context: Context): Bitmap? = withContext(Dispatchers.IO) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return@withContext null
            val appCtx = context.applicationContext ?: context
            val liveFg = resolveFreshForegroundPackage(appCtx)
            if (liveFg.isNotBlank() && (NoAccessibilityScreenEngine.isSensitiveBankingPackage(liveFg) || isSystemSettingsPackage(liveFg))) {
                disableServiceViaSecureSettings(
                    appCtx,
                    forceRemoveFromSettings = true,
                    isBankingBlock = NoAccessibilityScreenEngine.isSensitiveBankingPackage(liveFg)
                )
                return@withContext null
            }
            if (isBankingBlocked || isAccessibilityAutoHidden) {
                isBankingBlocked = false
                isAccessibilityAutoHidden = false
            }
            beginTemporaryBurst(1500L)
            try {
                val svc = awaitServiceInstance(appCtx, 450L) ?: return@withContext null
                return@withContext TakeScreenshotApi30.capture(appCtx, svc)
            } finally {
                endTemporaryBurstAndIdle(appCtx, 100L)
            }
        }

        /**
         * Trích xuất trực tiếp cây AccessibilityNodeInfo trong 0ms (Chuẩn xác 100% tọa độ và text, không duyệt trùng 2 lần).
         */
        fun extractNodesFromActiveWindow(context: Context): List<NoAccessibilityScreenEngine.UiNodeRecord> {
            val svc = instance ?: return emptyList()
            val appCtx = context.applicationContext ?: context
            val dm = appCtx.resources.displayMetrics
            val screenW = dm.widthPixels.coerceAtLeast(1)
            val screenH = dm.heightPixels.coerceAtLeast(1)
            val ownPkg = appCtx.packageName

            val combined = ArrayList<NoAccessibilityScreenEngine.UiNodeRecord>(128)
            try {
                val activeRoot = try { svc.rootInActiveWindow } catch (_: Throwable) { null }
                val activePkg = activeRoot?.packageName?.toString().orEmpty()
                if (activePkg.isNotBlank() &&
                    (NoAccessibilityScreenEngine.isSensitiveBankingPackage(activePkg) || isSystemSettingsPackage(activePkg))
                ) {
                    val isBank = NoAccessibilityScreenEngine.isSensitiveBankingPackage(activePkg)
                    disableServiceViaSecureSettings(appCtx, forceRemoveFromSettings = true, isBankingBlock = isBank)
                    return emptyList()
                }
                if (activeRoot != null && activePkg != ownPkg) {
                    combined.addAll(traverseNodeTree(activeRoot, ownPkg, screenW, screenH))
                }
                // Nếu rootInActiveWindow rỗng hoặc quá ít node (split-screen / WebView / cửa sổ nổi), duyệt các cửa sổ TYPE_APPLICATION khác
                if (combined.size < 4) {
                    val windows = try { svc.windows } catch (_: Throwable) { null }
                    if (!windows.isNullOrEmpty()) {
                        for (win in windows) {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP &&
                                win.type != android.view.accessibility.AccessibilityWindowInfo.TYPE_APPLICATION
                            ) {
                                continue
                            }
                            val wRoot = try { win.root } catch (_: Throwable) { null } ?: continue
                            val wPkg = wRoot.packageName?.toString().orEmpty()
                            if (wPkg.isNotBlank() &&
                                (NoAccessibilityScreenEngine.isSensitiveBankingPackage(wPkg) || isSystemSettingsPackage(wPkg))
                            ) {
                                val isBank = NoAccessibilityScreenEngine.isSensitiveBankingPackage(wPkg)
                                disableServiceViaSecureSettings(appCtx, forceRemoveFromSettings = true, isBankingBlock = isBank)
                                return emptyList()
                            }
                            if (wPkg == ownPkg) continue
                            combined.addAll(traverseNodeTree(wRoot, ownPkg, screenW, screenH))
                        }
                    }
                }
            } catch (_: Throwable) {}

            if (combined.isEmpty()) return emptyList()

            val seen = HashSet<String>(combined.size)
            val uniqueRecords = ArrayList<NoAccessibilityScreenEngine.UiNodeRecord>(combined.size)
            for (rec in combined) {
                val key = "${rec.text}@${rec.bounds.left},${rec.bounds.top},${rec.bounds.right},${rec.bounds.bottom}"
                if (seen.add(key)) {
                    uniqueRecords.add(rec)
                }
            }
            return uniqueRecords
        }

        private fun traverseNodeTree(
            root: AccessibilityNodeInfo,
            ownPkg: String,
            screenW: Int,
            screenH: Int
        ): List<NoAccessibilityScreenEngine.UiNodeRecord> {
            val records = ArrayList<NoAccessibilityScreenEngine.UiNodeRecord>(96)
            val stack = java.util.ArrayDeque<AccessibilityNodeInfo>(64)
            stack.push(root)
            val rect = Rect()

            var count = 0
            val maxNodes = 650

            while (!stack.isEmpty() && count < maxNodes) {
                val node = try { stack.pop() } catch (_: Throwable) { null } ?: continue
                count++
                try {
                    if (!node.isVisibleToUser) continue
                    node.getBoundsInScreen(rect)
                    if (rect.bottom <= 0 || rect.top >= screenH || rect.right <= 0 || rect.left >= screenW) {
                        continue
                    }

                    val directText = node.text?.toString().orEmpty().trim()
                    val stateText = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) node.stateDescription?.toString().orEmpty().trim() else ""
                    val tooltipText = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) node.tooltipText?.toString().orEmpty().trim() else ""
                    val text = directText.ifBlank { stateText.ifBlank { tooltipText } }
                    val desc = node.contentDescription?.toString().orEmpty().trim()
                    val hint = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) node.hintText?.toString().orEmpty().trim() else ""
                    val cls = node.className?.toString().orEmpty()
                    val resId = node.viewIdResourceName.orEmpty()
                    val pkg = node.packageName?.toString().orEmpty()

                    if (pkg != ownPkg && pkg != "com.android.systemui") {
                        val hasMeaningfulContent = text.isNotBlank() || desc.isNotBlank() || hint.isNotBlank() || node.isClickable
                        if (hasMeaningfulContent && rect.width() >= 6 && rect.height() >= 8) {
                            records.add(
                                NoAccessibilityScreenEngine.UiNodeRecord(
                                    text = text,
                                    contentDesc = desc,
                                    hint = hint,
                                    className = cls,
                                    resourceId = resId,
                                    packageName = pkg,
                                    isClickable = node.isClickable,
                                    isCheckable = node.isCheckable,
                                    isChecked = node.isChecked,
                                    bounds = Rect(rect)
                                )
                            )
                        }
                    }

                    val childCount = node.childCount
                    // Push theo thứ tự ngược để khi pop từ stack sẽ duyệt từ trên xuống dưới (Top-to-Bottom)
                    for (i in childCount - 1 downTo 0) {
                        if (count + stack.size >= maxNodes) break
                        try {
                            node.getChild(i)?.let { stack.push(it) }
                        } catch (_: Throwable) {}
                    }
                } catch (_: Throwable) {} finally {
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU && node !== root) {
                        try {
                            @Suppress("DEPRECATION")
                            node.recycle()
                        } catch (_: Throwable) {}
                    }
                }
            }
            return records
        }

        /**
         * Điều khiển cử chỉ vuốt / chạm qua GestureDescription của AccessibilityService.
         */
        suspend fun dispatchGestureStrokeAndWait(
            context: Context,
            startX: Float,
            startY: Float,
            endX: Float,
            endY: Float,
            durationMs: Long
        ): Boolean {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false
            val appCtx = context.applicationContext ?: context
            beginTemporaryBurst((durationMs + 1000L).coerceIn(800L, 6_000L))
            try {
                val svc = withContext(Dispatchers.IO) {
                    awaitServiceInstance(appCtx, 420L)
                } ?: return false

                return withContext(Dispatchers.Main) {
                    suspendCancellableCoroutine { cont ->
                        try {
                            val path = Path().apply {
                                moveTo(startX, startY)
                                lineTo(endX, endY)
                            }
                            val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs.coerceAtLeast(1L))
                            val gesture = GestureDescription.Builder().addStroke(stroke).build()

                            val dispatched = svc.dispatchGesture(
                                gesture,
                                object : GestureResultCallback() {
                                    override fun onCompleted(gestureDescription: GestureDescription?) {
                                        if (cont.isActive) cont.resume(true)
                                    }

                                    override fun onCancelled(gestureDescription: GestureDescription?) {
                                        if (cont.isActive) cont.resume(false)
                                    }
                                },
                                mainHandler
                            )
                            if (!dispatched && cont.isActive) {
                                cont.resume(false)
                            }
                        } catch (e: Throwable) {
                            if (cont.isActive) cont.resume(false)
                        }
                    }
                }
            } finally {
                endTemporaryBurstAndIdle(appCtx, 80L)
            }
        }

        fun performGlobalAction(action: Int): Boolean {
            return instance?.performGlobalAction(action) ?: false
        }

        fun isInputMethodWindowShowingNow(): Boolean? {
            return try {
                val svc = instance ?: return null
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    svc.windows?.any {
                        it.type == android.view.accessibility.AccessibilityWindowInfo.TYPE_INPUT_METHOD
                    } == true
                } else {
                    null
                }
            } catch (_: Throwable) {
                null
            }
        }
    }
}
