import type { Metadata } from 'next';
import Link from 'next/link';
import { Mail, Globe, ShieldCheck, Clock } from 'lucide-react';
import { PolicyPageLayout } from '@/components/common/PolicyPageLayout';

export const metadata: Metadata = {
  title: 'Liên Hệ & Hỗ Trợ Kỹ Thuật (Contact) | MagicTune',
  description:
    'Thông tin liên hệ chính thức của ban quản trị MagicTune để hỗ trợ kỹ thuật WebADB, góp ý nội dung và trao đổi bản quyền.',
  alternates: {
    canonical: 'https://magictune.web.app/contact/',
  },
};

export default function ContactPage() {
  return (
    <PolicyPageLayout
      title="Liên Hệ &amp; Hỗ Trợ Kỹ Thuật"
      subtitle="Kênh tiếp nhận phản hồi, báo lỗi kỹ thuật, góp ý nội dung và trao đổi chính thức của website MagicTune."
      activePath="/contact/"
    >
      <section className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="p-4 rounded-2xl bg-[#0A0F1D]/80 border border-cyan-500/20 space-y-2">
          <div className="flex items-center gap-2 text-cyan-400 font-bold text-sm">
            <Mail className="w-4 h-4 shrink-0" />
            <span>Email Quản Trị Chính Thức</span>
          </div>
          <p className="text-xs text-slate-300">
            Tiếp nhận hỗ trợ kỹ thuật, khiếu nại bản quyền, bảo mật dữ liệu và hợp tác:
          </p>
          <a
            href="mailto:vuongdhkmhn@gmail.com"
            className="inline-block font-mono text-sm font-bold text-[#00F0FF] hover:underline"
          >
            vuongdhkmhn@gmail.com
          </a>
        </div>

        <div className="p-4 rounded-2xl bg-[#0A0F1D]/80 border border-cyan-500/20 space-y-2">
          <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
            <Globe className="w-4 h-4 shrink-0" />
            <span>Website Chính Thức</span>
          </div>
          <p className="text-xs text-slate-300">
            Cổng truy cập WebADB trực tuyến và tải ứng dụng đồng bộ:
          </p>
          <Link
            href="/"
            className="inline-block font-mono text-sm font-bold text-emerald-400 hover:underline"
          >
            https://magictune.web.app
          </Link>
        </div>

        <div className="p-4 rounded-2xl bg-[#0A0F1D]/80 border border-cyan-500/20 space-y-2">
          <div className="flex items-center gap-2 text-purple-400 font-bold text-sm">
            <Clock className="w-4 h-4 shrink-0" />
            <span>Thời Gian Phản Hồi</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Các yêu cầu qua email thường được kiểm tra và phản hồi trong vòng <strong>24 – 48 giờ làm việc</strong> (Thứ 2 đến Chủ Nhật, giờ Việt Nam GMT+7).
          </p>
        </div>

        <div className="p-4 rounded-2xl bg-[#0A0F1D]/80 border border-cyan-500/20 space-y-2">
          <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
            <ShieldCheck className="w-4 h-4 shrink-0" />
            <span>Hỗ Trợ Trực Tuyến Trên Web</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Bạn có thể nhấn nút <strong>Hỗ Trợ / Trợ Lý AI</strong> ngay trên thanh tiêu đề ở{' '}
            <Link href="/" className="text-cyan-400 underline">
              Trang Chủ
            </Link>{' '}
            để được giải đáp các bước bật Gỡ lỗi USB nhanh chóng.
          </p>
        </div>
      </section>

      <section className="space-y-2 pt-2">
        <h2 className="text-lg font-bold text-white">Hướng dẫn gửi thông tin báo lỗi hiệu quả</h2>
        <p>
          Để chúng tôi hỗ trợ nhanh nhất khi bạn gặp lỗi kết nối hoặc cần tối ưu trên dòng máy mới, vui lòng đính kèm trong email:
        </p>
        <ul className="list-disc list-inside space-y-1 text-slate-300">
          <li>Tên thiết bị, phiên bản Android và giao diện hệ thống (MagicOS, HyperOS, ColorOS, OriginOS, One UI...).</li>
          <li>Trình duyệt và hệ điều hành máy tính bạn đang dùng (Chrome/Edge trên Windows/macOS hoặc điện thoại OTG).</li>
          <li>Nội dung dòng báo lỗi hiển thị trong khung <strong>ADB Cockpit Terminal</strong> (nếu có).</li>
        </ul>
      </section>
    </PolicyPageLayout>
  );
}
