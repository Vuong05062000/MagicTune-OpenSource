'use client';

import React, { useEffect, useState, Suspense } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { auth, approveQrLoginSession } from '@/lib/firebase/config';
import { onAuthStateChanged, User } from 'firebase/auth';
import { CheckCircle2, ShieldCheck, AlertCircle, Smartphone, ArrowRight } from 'lucide-react';

function QrConfirmContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const sessionId = searchParams.get('session');

  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [approving, setApproving] = useState(false);
  const [success, setSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
      setLoading(false);
    });
    return () => unsub();
  }, []);

  const handleApprove = async () => {
    if (!sessionId || !currentUser) return;
    setApproving(true);
    setErrorMsg(null);

    const ok = await approveQrLoginSession(sessionId, currentUser);
    if (ok) {
      setSuccess(true);
      setTimeout(() => {
        router.push('/');
      }, 2000);
    } else {
      setErrorMsg('Không thể xác nhận phiên đăng nhập. Mã QR có thể đã hết hạn.');
    }
    setApproving(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0A0F1D] flex items-center justify-center text-white text-xs">
        Đang kiểm tra tài khoản...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0A0F1D] flex items-center justify-center p-4">
      <div className="relative w-full max-w-md rounded-2xl border border-cyan-500/30 bg-[#111A2E] p-8 shadow-2xl text-center space-y-5">
        <div className="w-16 h-16 rounded-3xl bg-cyan-500/10 border border-cyan-500/30 text-[#00F0FF] mx-auto flex items-center justify-center">
          <Smartphone className="w-8 h-8" />
        </div>

        <div>
          <h2 className="text-xl font-bold text-white tracking-wide">Xác Nhận Đăng Nhập Trên PC</h2>
          <p className="text-xs text-slate-400 mt-1">
            Thiết bị máy tính đang yêu cầu đăng nhập bằng tài khoản của bạn
          </p>
        </div>

        {errorMsg && (
          <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center space-x-2 text-left">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {success ? (
          <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center justify-center space-x-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            <span className="font-bold">Đã xác nhận thành công! Máy tính của bạn đã được đăng nhập.</span>
          </div>
        ) : currentUser ? (
          <div className="space-y-4">
            <div className="p-3 rounded-xl bg-[#0A0F1D] border border-slate-800 text-xs text-left space-y-1">
              <div className="text-slate-500">Tài khoản xác thực:</div>
              <div className="font-bold text-[#00F0FF] truncate">
                {currentUser.displayName || currentUser.email || currentUser.phoneNumber}
              </div>
            </div>

            <button
              onClick={handleApprove}
              disabled={approving || !sessionId}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-[#00F0FF] to-blue-600 hover:from-cyan-400 text-black font-extrabold text-xs shadow-lg shadow-cyan-500/25 flex items-center justify-center space-x-2 transition-all disabled:opacity-50"
            >
              {approving ? (
                <span>Đang xác nhận...</span>
              ) : (
                <>
                  <span>Cho Phép Đăng Nhập Trên PC</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            <p className="text-xs text-amber-300 bg-amber-500/10 p-3 rounded-xl border border-amber-500/20">
              Bạn cần đăng nhập trên điện thoại này trước khi có thể duyệt mã QR cho máy tính.
            </p>
            <button
              onClick={() => router.push('/')}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold"
            >
              Về Trang Chủ Đăng Nhập
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default function QrConfirmPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-[#0A0F1D] flex items-center justify-center text-white text-xs">Đang tải...</div>}>
      <QrConfirmContent />
    </Suspense>
  );
}
