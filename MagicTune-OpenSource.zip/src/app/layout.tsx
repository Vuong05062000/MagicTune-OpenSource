import type { Metadata, Viewport } from "next";
import { APP_RELEASE_VERSION } from "@/lib/version";
import "./globals.css";

export const viewport: Viewport = {
  themeColor: "#0A0F1D",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: "cover",
};

export const metadata: Metadata = {
  metadataBase: new URL("https://magictune.web.app"),
  title: "MagicTune - Bộ công cụ WebADB tối ưu Android & Đa Hệ Điều Hành",
  description: "Bộ công cụ WebADB trực tuyến giúp tối ưu hóa, sửa triệt để trễ thông báo Facebook, Gmail, Zalo, cài Shizuku và gỡ ứng dụng rác cho mọi điện thoại Android nội địa (HyperOS, OriginOS, ColorOS, One UI, MagicOS).",
  keywords: [
    "MagicTune",
    "WebADB Android",
    "HyperOS",
    "OriginOS",
    "ColorOS",
    "One UI",
    "MagicOS",
    "Fix trễ thông báo Android",
    "Fix thông báo Facebook Gmail Zalo",
    "Shizuku",
    "Debloat Android"
  ],
  authors: [{ name: "MagicTune Community" }],
  icons: {
    icon: [
      { url: "/favicon.ico", sizes: "any" },
      { url: "/favicon-48x48.png", sizes: "48x48", type: "image/png" },
      { url: "/icon-96.png", sizes: "96x96", type: "image/png" },
      { url: "/icon-192.png", sizes: "192x192", type: "image/png" },
      { url: "/icon.png", sizes: "512x512", type: "image/png" },
    ],
    apple: [
      { url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" },
    ],
    shortcut: "/favicon.ico",
  },
  manifest: "/manifest.json",
  openGraph: {
    type: "website",
    locale: "vi_VN",
    url: "https://magictune.web.app",
    title: "MagicTune - Tối Ưu & Fix Thông Báo Mọi Hãng Android",
    description: "Bộ công cụ WebADB trực tuyến sửa triệt để trễ thông báo Facebook, Gmail, Zalo, cài Shizuku và debloat cho mọi điện thoại Android nội địa.",
    siteName: "MagicTune",
    images: [
      {
        url: "/og-image.png",
        width: 512,
        height: 512,
        alt: "MagicTune - Universal WebADB Toolkit for Android",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "MagicTune - Bộ công cụ WebADB tối ưu Đa Hãng Android",
    description: "Sửa trễ thông báo FB, Gmail, Zalo, kích hoạt Shizuku, gỡ rác an toàn cho mọi điện thoại Android ngay trên trình duyệt web.",
    images: ["/og-image.png"],
  },
  other: {
    "google-adsense-account": "ca-pub-4256214784202059",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="vi" className="dark" suppressHydrationWarning>
      <head>
        {/* Nạp trực tiếp bộ CSS biên dịch đầy đủ kèm mã phiên bản để tránh cache CSS cũ */}
        <link rel="stylesheet" href={`/tailwind.css?v=${APP_RELEASE_VERSION}`} />

        {/* Chuẩn Favicon nhận diện Google Search (Bội số 48px: 48x48, 96x96, 192x192) và Trình duyệt */}
        <link rel="icon" href="/favicon.ico" sizes="any" />
        <link rel="shortcut icon" href="/favicon.ico" />
        <link rel="icon" type="image/png" sizes="48x48" href="/favicon-48x48.png" />
        <link rel="icon" type="image/png" sizes="96x96" href="/icon-96.png" />
        <link rel="icon" type="image/png" sizes="192x192" href="/icon-192.png" />
        <link rel="icon" type="image/png" sizes="512x512" href="/icon-512.png" />
        <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png" />

        {/* Định danh tên Website chính thức cho Google Search (Thay thế chữ Google mặc định của domain .web.app) */}
        <meta name="application-name" content="MagicTune" />
        <meta name="apple-mobile-web-app-title" content="MagicTune" />
        <meta property="og:site_name" content="MagicTune" />

        {/* Cấu trúc dữ liệu Google Search Schema.org WebSite để định danh tên website trên kết quả tìm kiếm */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "WebSite",
              "name": "MagicTune",
              "alternateName": [
                "MagicTune Tool",
                "MagicTune WebADB",
                "MagicTune Android",
                "MagicTune Hub"
              ],
              "url": "https://magictune.web.app",
              "description": "Bộ công cụ WebADB trực tuyến sửa triệt để trễ thông báo Facebook, Gmail, Zalo, cài Shizuku và tối ưu hóa điện thoại Android.",
              "inLanguage": "vi-VN"
            }),
          }}
        />

        {/* Dữ liệu Schema.org SoftwareApplication */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "SoftwareApplication",
              "name": "MagicTune",
              "operatingSystem": "Android",
              "applicationCategory": "UtilitiesApplication",
              "url": "https://magictune.web.app",
              "image": "https://magictune.web.app/icon.png",
              "description": "Bộ công cụ WebADB trực tuyến giúp tối ưu hóa, sửa triệt để trễ thông báo và cài Shizuku cho điện thoại Android.",
              "offers": {
                "@type": "Offer",
                "price": "0",
                "priceCurrency": "VND"
              }
            }),
          }}
        />

        {/* Google AdSense Script - Xác thực tài khoản nhà xuất bản ca-pub-4256214784202059 */}
        <script
          async
          src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-4256214784202059"
          crossOrigin="anonymous"
        />
      </head>
      <body
        suppressHydrationWarning
        className="bg-[#0A0F1D] text-slate-100 min-h-screen flex flex-col font-sans antialiased selection:bg-cyan-500 selection:text-black"
      >
        {children}
      </body>
    </html>
  );
}
