'use client';

import React, { useState, useEffect, useRef } from 'react';
import {
  Terminal,
  Trash2,
  Copy,
  Check,
  CornerDownLeft,
  Download,
  Zap,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  X,
  ChevronDown,
  ChevronUp,
  Maximize2,
  Minimize2,
  Activity,
  Sparkles
} from 'lucide-react';
import { AdbLogEntry, AdbDeviceState, ActivePipelineProgress, adbDriver } from '@/lib/adb/web-usb-driver';

interface AdbConsoleProps {
  onRunCustomCommand?: (command: string) => void;
  className?: string;
  isAdmin?: boolean;
}

export const AdbConsole: React.FC<AdbConsoleProps> = ({ onRunCustomCommand, className = '', isAdmin = false }) => {
  const [logs, setLogs] = useState<AdbLogEntry[]>([
    {
      id: 'init-1',
      timestamp: '--:--:--',
      type: 'info',
      text: 'Động cơ ADB MagicTune Universal sẵn sàng hoạt động.'
    },
    {
      id: 'init-2',
      timestamp: '--:--:--',
      type: 'info',
      text: 'Trung tâm giám sát tiến trình tập trung (Unified Pipeline Cockpit) đã kích hoạt.'
    }
  ]);

  useEffect(() => {
    const nowStr = new Date().toLocaleTimeString('vi-VN', { hour12: false });
    setLogs((prev) =>
      prev.map((l) => (l.timestamp === '--:--:--' ? { ...l, timestamp: nowStr } : l))
    );
  }, []);

  const [filterType, setFilterType] = useState<'all' | 'command' | 'success' | 'warning' | 'error'>('all');
  const [inputCmd, setInputCmd] = useState('');
  const [copied, setCopied] = useState(false);
  const [isExecuting, setIsExecuting] = useState(false);
  const [isExpandedHeight, setIsExpandedHeight] = useState(false);
  const [isHudCollapsed, setIsHudCollapsed] = useState(false);
  const [autoScroll, setAutoScroll] = useState(true);

  // Lịch sử lệnh đã gõ (Command History)
  const [cmdHistory, setCmdHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState<number>(-1);

  // Trạng thái thiết bị và tiến trình tập trung
  const [deviceState, setDeviceState] = useState<AdbDeviceState>({ connectionState: 'disconnected' });
  const [pipelineProgress, setPipelineProgress] = useState<ActivePipelineProgress | null>(() => adbDriver.getActivePipeline());

  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Lắng nghe Logs
  useEffect(() => {
    const unsubscribe = adbDriver.onLog((entry) => {
      setLogs((prev) => [...prev.slice(-400), entry]);
    });

    return () => {
      unsubscribe();
    };
  }, []);

  // Lắng nghe Trạng thái Thiết bị
  useEffect(() => {
    const unsubscribeState = adbDriver.onStateChange((state) => {
      setDeviceState(state);
    });
    return () => unsubscribeState();
  }, []);

  // Lắng nghe Tiến trình Pipeline toàn cục
  useEffect(() => {
    const unsubscribePipeline = adbDriver.onPipelineProgress((prog) => {
      setPipelineProgress(prog ? { ...prog } : null);
    });
    return () => unsubscribePipeline();
  }, []);

  // Đếm thời gian thực thi pipeline thuần túy (tránh gọi Date.now() trực tiếp trong render)
  const [elapsedSec, setElapsedSec] = useState<number>(0);
  useEffect(() => {
    if (!pipelineProgress || pipelineProgress.durationMs) {
      setElapsedSec(0);
      return;
    }
    const updateElapsed = () => {
      const now = Date.now();
      const sec = Math.max(0, (now - pipelineProgress.startTime) / 1000);
      setElapsedSec(sec);
    };
    updateElapsed();
    const interval = setInterval(updateElapsed, 200);
    return () => clearInterval(interval);
  }, [pipelineProgress?.id, pipelineProgress?.durationMs, pipelineProgress?.startTime]);

  // Tự động cuộn xuống cuối khi có log mới
  useEffect(() => {
    if (autoScroll && scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs, autoScroll]);

  const handleClear = () => {
    setLogs([]);
  };

  const handleCopyLogs = () => {
    const text = filteredLogs.map((l) => `[${l.timestamp}] [${l.type.toUpperCase()}] ${l.text}`).join('\n');
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleExportLogs = () => {
    const text = filteredLogs.map((l) => `[${l.timestamp}] [${l.type.toUpperCase()}] ${l.text}`).join('\n');
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `magictune_adb_log_${new Date().toISOString().slice(0, 10)}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleExecuteInput = async (cmdToRun?: string, e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const cmd = (cmdToRun !== undefined ? cmdToRun : inputCmd).trim();
    if (!cmd || isExecuting) return;

    // Bộ lọc an toàn ngăn chặn injection lệnh nguy hại
    const lowerCmd = cmd.toLowerCase();
    const isDangerous = 
      lowerCmd.includes('rm -rf /') || 
      lowerCmd.includes('rm -rf /system') || 
      lowerCmd.includes('rm -rf /data') || 
      lowerCmd.startsWith('dd if=') || 
      lowerCmd.includes('format ') || 
      lowerCmd.includes('fastboot oem unlock');

    if (isDangerous) {
      const confirmDanger = typeof window !== 'undefined' ? window.confirm(
        `⚠️ CẢNH BÁO NGUY HIỂM:\n\nLệnh "${cmd}" có nguy cơ làm mất dữ liệu hoặc brick thiết bị!\n\nBạn có chắc chắn muốn thực thi không?`
      ) : false;
      if (!confirmDanger) {
        return;
      }
    }

    if (lowerCmd.includes('reboot bootloader') || lowerCmd.includes('reboot fastboot')) {
      const confirmReboot = typeof window !== 'undefined' ? window.confirm(
        '⚠️ Thiết bị sẽ khởi động vào chế độ Fastboot/Bootloader và ngắt kết nối ADB hiện tại. Bạn có muốn tiếp tục?'
      ) : false;
      if (!confirmReboot) {
        return;
      }
    }

    // Lưu vào lịch sử lệnh
    setCmdHistory((prev) => [cmd, ...prev.filter((c) => c !== cmd).slice(0, 49)]);
    setHistoryIndex(-1);

    setIsExecuting(true);
    setInputCmd('');

    try {
      if (onRunCustomCommand) {
        onRunCustomCommand(cmd);
      } else {
        await adbDriver.executeCommand(cmd);
      }
    } catch (err: any) {
      // Driver đã log lỗi
    } finally {
      setIsExecuting(false);
    }
  };

  // Điều hướng lịch sử lệnh bằng phím Mũi Tên Lên / Xuống
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (cmdHistory.length === 0) return;
      const nextIndex = historyIndex + 1 < cmdHistory.length ? historyIndex + 1 : historyIndex;
      setHistoryIndex(nextIndex);
      setInputCmd(cmdHistory[nextIndex] || '');
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyIndex > 0) {
        const nextIndex = historyIndex - 1;
        setHistoryIndex(nextIndex);
        setInputCmd(cmdHistory[nextIndex] || '');
      } else if (historyIndex === 0) {
        setHistoryIndex(-1);
        setInputCmd('');
      }
    }
  };

  const renderLogBadge = (type: AdbLogEntry['type']) => {
    switch (type) {
      case 'success':
        return <span className="text-[#00F0FF] font-semibold">[THÀNH CÔNG]</span>;
      case 'error':
        return <span className="text-rose-400 font-semibold">[LỖI]</span>;
      case 'warning':
        return <span className="text-amber-400 font-semibold">[CẢNH BÁO]</span>;
      case 'command':
        return <span className="text-purple-400 font-semibold">[LỆNH]</span>;
      default:
        return <span className="text-slate-400 font-semibold">[HỆ THỐNG]</span>;
    }
  };

  const filteredLogs = logs.filter((l) => {
    // Với người dùng thông thường: Ẩn toàn bộ log lệnh raw để bảo vệ bí quyết công nghệ trước đối thủ
    if (!isAdmin && l.type === 'command') return false;
    if (filterType === 'all') return true;
    return l.type === filterType;
  }).map((l) => {
    if (!isAdmin) {
      // Làm sạch bất kỳ log hệ thống nào vô tình để lộ chuỗi lệnh nội bộ
      if (l.text.includes('dumpsys') || l.text.includes('appops') || l.text.includes('bastet') || l.text.includes('set-standby-bucket') || l.text.includes('netpolicy') || l.text.includes('powergenie')) {
        return {
          ...l,
          text: '⚡ [Bảo Mật] Đang cấu hình đặc quyền nền & mở khóa Doze Whitelist...'
        };
      }
    }
    return l;
  });

  const isConnected = deviceState.connectionState === 'connected';
  const deviceTitle = isConnected
    ? `${deviceState.manufacturerName ? `${deviceState.manufacturerName} ` : ''}${deviceState.productName || 'Thiết Bị'}`
    : 'Chưa Kết Nối';

  // Lệnh mẫu chẩn đoán nhanh
  const quickChips = [
    { label: 'Pin & Nhiệt Độ', cmd: 'dumpsys battery' },
    { label: 'Whitelist Nền', cmd: 'dumpsys deviceidle whitelist' },
    { label: 'Model Máy', cmd: 'getprop ro.product.model' },
    { label: 'App Người Dùng', cmd: 'pm list packages -3' },
    { label: 'Kích Thước Màn', cmd: 'wm size' }
  ];

  return (
    <div
      className={`rounded-2xl border border-cyan-500/25 bg-[#0A0F1D]/95 backdrop-blur-xl shadow-2xl shadow-cyan-950/30 flex flex-col overflow-hidden font-mono text-xs ${className}`}
    >
      {/* 1. THANH TIÊU ĐỀ COCKPIT TERMINAL HIỆN ĐẠI */}
      <div className="flex flex-wrap items-center justify-between px-3.5 py-2.5 bg-[#060A14] border-b border-cyan-500/20 select-none gap-2">
        {/* Nút bấm traffic light + Tiêu đề + Trạng thái thiết bị */}
        <div className="flex items-center space-x-2.5">
          <div className="flex items-center space-x-1.5">
            <button
              onClick={handleClear}
              className="w-3 h-3 rounded-full bg-rose-500/90 hover:brightness-125 transition-all cursor-pointer shadow-sm shadow-rose-500/30"
              title="Xóa toàn bộ log"
            />
            <button
              onClick={() => setIsHudCollapsed((prev) => !prev)}
              className="w-3 h-3 rounded-full bg-amber-500/90 hover:brightness-125 transition-all cursor-pointer shadow-sm shadow-amber-500/30"
              title="Thu gọn / Mở rộng Cockpit Tiến Trình"
            />
            <button
              onClick={() => setIsExpandedHeight((prev) => !prev)}
              className="w-3 h-3 rounded-full bg-emerald-500/90 hover:brightness-125 transition-all cursor-pointer shadow-sm shadow-emerald-500/30"
              title="Phóng to / Thu nhỏ chiều cao Console"
            />
          </div>

          <div className="flex items-center space-x-1.5 text-slate-200 font-sans font-bold text-xs">
            <Terminal className="w-4 h-4 text-[#00F0FF]" />
            <span className="tracking-wide">ADB Cockpit Terminal</span>
          </div>

          {/* Device Online Status Pill */}
          <div
            className={`px-2 py-0.5 rounded-full text-[10px] font-sans font-semibold border flex items-center space-x-1.5 ${
              isConnected
                ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                : 'bg-slate-800 text-slate-400 border-slate-700'
            }`}
          >
            <span
              className={`w-1.5 h-1.5 rounded-full ${isConnected ? 'bg-emerald-400 animate-pulse' : 'bg-slate-500'}`}
            />
            <span className="truncate max-w-[130px] sm:max-w-[180px]">{deviceTitle}</span>
          </div>
        </div>

        {/* Các nút công cụ thao tác */}
        <div className="flex flex-wrap items-center gap-1 font-sans text-xs">
          {(!isConnected || deviceState.connectionState === 'unauthorized' || deviceState.connectionState === 'authorizing') && (
            <button
              onClick={() => adbDriver.forceNewRsaKeyAndReconnect()}
              className="px-2 py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-[11px] font-bold transition-all flex items-center space-x-1"
              title="Xóa khóa RSA cũ, tạo cặp khóa mới tinh và ép điện thoại Android bật lại bảng Cho phép gỡ lỗi USB"
            >
              <Zap className="w-3 h-3 text-amber-400 fill-current" />
              <span>Ép RSA Mới</span>
            </button>
          )}
          <button
            onClick={() => setAutoScroll((prev) => !prev)}
            className={`px-2 py-1 rounded-lg border text-[11px] font-medium transition-all ${
              autoScroll
                ? 'bg-cyan-500/15 text-[#00F0FF] border-cyan-500/30'
                : 'bg-slate-800/80 text-slate-400 border-slate-700 hover:text-white'
            }`}
            title="Bật/Tắt tự động cuộn theo log mới"
          >
            {autoScroll ? 'Cuộn: Bật' : 'Cuộn: Khóa'}
          </button>
          <button
            onClick={() => {
              if (scrollRef.current) scrollRef.current.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
            }}
            className="p-1 rounded-lg bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 hover:text-white transition-all text-xs"
            title="Cuộn xuống cuối nhật ký console"
          >
            ↓ Cuối
          </button>
          <button
            onClick={handleCopyLogs}
            className="flex items-center space-x-1 px-2.5 py-1 rounded-lg bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 hover:text-white transition-all text-xs"
            title="Sao chép toàn bộ nhật ký"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-[#00F0FF]" /> : <Copy className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline">{copied ? 'Đã chép' : 'Chép'}</span>
          </button>
          <button
            onClick={handleExportLogs}
            className="flex items-center space-x-1 px-2 py-1 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 text-[#00F0FF] border border-cyan-500/25 transition-all text-xs"
            title="Xuất file nhật ký .txt"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Xuất</span>
          </button>
          <button
            onClick={handleClear}
            className="flex items-center space-x-1 px-2 py-1 rounded-lg bg-slate-800/80 hover:bg-rose-900/40 text-slate-300 hover:text-rose-300 transition-all text-xs"
            title="Xóa nhật ký màn hình"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Xóa</span>
          </button>
          <button
            onClick={() => setIsExpandedHeight((prev) => !prev)}
            className="p-1 rounded-lg bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 hover:text-white transition-all text-xs"
            title={isExpandedHeight ? 'Thu nhỏ chiều cao' : 'Mở rộng chiều cao'}
          >
            {isExpandedHeight ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* 2. THANH TIẾN TRÌNH HỢP NHẤT TOÀN DIỆN (UNIFIED PIPELINE PROGRESS COCKPIT) */}
      {pipelineProgress && (
        <div className="border-b border-cyan-500/25 bg-gradient-to-br from-[#0c1324] via-[#090e1b] to-[#060a14] p-3 space-y-2.5 transition-all select-none">
          {/* Hàng Tiêu Đề & Trạng Thái Tiến Trình */}
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center space-x-2 min-w-0">
              {pipelineProgress.status === 'running' ? (
                <span className="relative flex h-3 w-3 shrink-0">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#00F0FF] opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-[#00F0FF]"></span>
                </span>
              ) : pipelineProgress.status === 'completed' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              )}

              <div className="min-w-0">
                <div className="flex items-center space-x-2">
                  <span className="font-sans font-bold text-xs sm:text-sm text-white truncate">
                    {pipelineProgress.title || 'Tiến Trình Kịch Bản ADB'}
                  </span>
                  <span
                    className={`text-[10px] px-2 py-0.2 rounded-full font-sans font-semibold border ${
                      pipelineProgress.status === 'running'
                        ? 'bg-cyan-500/20 text-[#00F0FF] border-cyan-500/40 animate-pulse'
                        : pipelineProgress.status === 'completed'
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                        : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                    }`}
                  >
                    {pipelineProgress.status === 'running'
                      ? 'ĐANG THỰC THI'
                      : pipelineProgress.status === 'completed'
                      ? 'HOÀN TẤT 100%'
                      : 'HOÀN TẤT (CÓ LỖI)'}
                  </span>
                </div>
              </div>
            </div>

            {/* Chỉ số bước & Tỷ lệ % */}
            <div className="flex items-center space-x-2 shrink-0">
              <span className="font-mono text-xs font-bold text-slate-300">
                Bước {pipelineProgress.current} / {pipelineProgress.total}
              </span>
              <span className="font-mono text-xs sm:text-sm font-extrabold text-[#00F0FF] px-2 py-0.5 rounded bg-cyan-500/15 border border-cyan-500/30">
                {pipelineProgress.percent}%
              </span>
              {pipelineProgress.status !== 'running' && (
                <button
                  onClick={() => adbDriver.clearActivePipeline()}
                  className="p-1 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-all"
                  title="Đóng bảng tiến trình"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* Thanh Tiến Trình Neon Đột Phá */}
          {!isHudCollapsed && (
            <>
              <div className="relative w-full h-2.5 bg-slate-950/90 rounded-full border border-cyan-500/30 overflow-hidden p-0.5 shadow-inner">
                <div
                  className={`h-full rounded-full transition-all duration-300 ease-out relative ${
                    pipelineProgress.status === 'completed'
                      ? 'bg-gradient-to-r from-teal-500 via-emerald-400 to-[#00F0FF] shadow-[0_0_12px_rgba(52,211,153,0.7)]'
                      : pipelineProgress.status === 'error'
                      ? 'bg-gradient-to-r from-rose-500 via-amber-400 to-cyan-400 shadow-[0_0_12px_rgba(244,63,94,0.7)]'
                      : 'bg-gradient-to-r from-cyan-500 via-blue-500 to-purple-500 shadow-[0_0_14px_rgba(0,240,255,0.8)]'
                  }`}
                  style={{ width: `${Math.max(4, Math.min(100, pipelineProgress.percent))}%` }}
                >
                  {/* Hiệu ứng tia sáng quét ngang (Shimmer) */}
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent animate-shimmer" />
                </div>
              </div>

              {/* Bảng Đồng Hồ Thống Kê 4 Chỉ Số (Live Metric HUD) */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 font-sans text-[11px]">
                <div className="p-1.5 rounded-lg bg-[#0E1729] border border-emerald-500/30 flex items-center justify-between">
                  <span className="text-slate-300 flex items-center space-x-1">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block" />
                    <span>Thành công:</span>
                  </span>
                  <span className="font-mono font-bold text-emerald-300 text-xs">{pipelineProgress.successCount}</span>
                </div>

                <div className="p-1.5 rounded-lg bg-[#0E1729] border border-amber-500/30 flex items-center justify-between">
                  <span className="text-slate-300 flex items-center space-x-1">
                    <span className="w-2 h-2 rounded-full bg-amber-400 inline-block" />
                    <span>Bỏ qua/Cảnh báo:</span>
                  </span>
                  <span className="font-mono font-bold text-amber-300 text-xs">{pipelineProgress.warningCount}</span>
                </div>

                <div className="p-1.5 rounded-lg bg-[#0E1729] border border-rose-500/30 flex items-center justify-between">
                  <span className="text-slate-300 flex items-center space-x-1">
                    <span className="w-2 h-2 rounded-full bg-rose-400 inline-block" />
                    <span>Thất bại:</span>
                  </span>
                  <span className="font-mono font-bold text-rose-300 text-xs">{pipelineProgress.failCount}</span>
                </div>

                <div className="p-1.5 rounded-lg bg-[#0E1729] border border-cyan-500/30 flex items-center justify-between">
                  <span className="text-slate-300 flex items-center space-x-1">
                    <Zap className="w-3 h-3 text-[#00F0FF]" />
                    <span>Thời gian:</span>
                  </span>
                  <span className="font-mono font-bold text-cyan-300 text-xs">
                    {pipelineProgress.durationMs
                      ? `${(pipelineProgress.durationMs / 1000).toFixed(1)}s`
                      : `${elapsedSec.toFixed(1)}s`}
                  </span>
                </div>
              </div>

              {/* Chi tiết lệnh đang chạy tại thời điểm thực */}
              <div className="p-2 rounded-lg bg-[#070B16] border border-slate-800 text-[11px] space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 font-sans">Thao tác hiện tại:</span>
                  {pipelineProgress.pkg && (
                    <span className="text-purple-300 font-mono text-[10px] bg-purple-950/40 px-1.5 py-0.5 rounded border border-purple-500/30">
                      {pipelineProgress.pkg}
                    </span>
                  )}
                </div>
                <div className="font-sans font-semibold text-cyan-200 truncate">
                  {pipelineProgress.currentLabel || pipelineProgress.currentCmd || 'Đang chuẩn bị lệnh...'}
                </div>
                {isAdmin && pipelineProgress.currentCmd && (
                  <div className="font-mono text-[10px] text-slate-500 truncate select-text">
                    &gt; {pipelineProgress.currentCmd}
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      )}

      {/* Thông báo trạng thái sẵn sàng khi chưa có kịch bản chạy */}
      {!pipelineProgress && (
        <div className="px-3.5 py-2 bg-[#080D1A] border-b border-cyan-500/15 flex items-center justify-between text-[11px] font-sans text-slate-400 select-none">
          <div className="flex items-center space-x-2">
            <Activity className="w-3.5 h-3.5 text-[#00F0FF] animate-pulse" />
            <span>
              <strong className="text-slate-200">Trình Giám Sát Tiến Trình:</strong> Mọi kịch bản ADB từ các Mục (Ưu Tiên, Mục 1 đến 11) sẽ tự động hiển thị tiến trình và đếm thành công/thất bại tại đây.
            </span>
          </div>
        </div>
      )}

      {/* 3. THANH BỘ LỌC LOẠI NHẬT KÝ (LOG FILTER BAR) */}
      <div className="flex flex-wrap items-center gap-1.5 px-3 py-1.5 bg-[#060A14] border-b border-slate-800 font-sans text-[11px] select-none">
        <span className="text-slate-500 mr-1">Bộ lọc:</span>
        <button
          onClick={() => setFilterType('all')}
          className={`px-2 py-0.5 rounded transition-all ${
            filterType === 'all' ? 'bg-cyan-500/20 text-[#00F0FF] font-bold border border-cyan-500/40' : 'text-slate-400 hover:text-white'
          }`}
        >
          Tất cả ({logs.length})
        </button>
        {isAdmin && (
          <button
            onClick={() => setFilterType('command')}
            className={`px-2 py-0.5 rounded transition-all ${
              filterType === 'command' ? 'bg-purple-500/20 text-purple-300 font-bold border border-purple-500/40' : 'text-slate-400 hover:text-white'
            }`}
          >
            Lệnh ({logs.filter((l) => l.type === 'command').length})
          </button>
        )}
        <button
          onClick={() => setFilterType('success')}
          className={`px-2 py-0.5 rounded transition-all ${
            filterType === 'success' ? 'bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/40' : 'text-slate-400 hover:text-white'
          }`}
        >
          Thành công ({logs.filter((l) => l.type === 'success').length})
        </button>
        <button
          onClick={() => setFilterType('warning')}
          className={`px-2 py-0.5 rounded transition-all ${
            filterType === 'warning' ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40' : 'text-slate-400 hover:text-white'
          }`}
        >
          Cảnh báo ({logs.filter((l) => l.type === 'warning').length})
        </button>
        <button
          onClick={() => setFilterType('error')}
          className={`px-2 py-0.5 rounded transition-all ${
            filterType === 'error' ? 'bg-rose-500/20 text-rose-300 font-bold border border-rose-500/40' : 'text-slate-400 hover:text-white'
          }`}
        >
          Lỗi ({logs.filter((l) => l.type === 'error').length})
        </button>
      </div>

      {/* 4. VÙNG HIỂN THỊ LOG ADBCONSOLE THỜI GIAN THỰC */}
      <div
        ref={scrollRef}
        className={`p-3.5 overflow-y-scroll space-y-1.5 bg-[#050811] text-slate-300 selection:bg-[#00F0FF]/30 select-text [overflow-anchor:none] scrollbar-thin scrollbar-thumb-sky-600 scrollbar-track-slate-900 border-b border-cyan-500/10 transition-all ${
          isExpandedHeight ? 'h-[440px]' : 'h-[270px]'
        }`}
        style={{ willChange: 'scroll-position', scrollbarWidth: 'thin', scrollbarColor: '#0284c7 #0f172a' }}
      >
        {filteredLogs.length === 0 ? (
          <div className="text-slate-600 italic py-8 text-center select-none font-sans">
            Không có nhật ký nào phù hợp với bộ lọc hiện tại.
          </div>
        ) : (
          filteredLogs.map((log) => (
            <div key={log.id} className="leading-relaxed break-words flex items-start space-x-2">
              <span className="text-slate-500 shrink-0 select-none text-[11px]">{log.timestamp}</span>
              <span className="shrink-0 select-none">{renderLogBadge(log.type)}</span>
              <span
                className={
                  log.type === 'error'
                    ? 'text-rose-400 font-medium'
                    : log.type === 'warning'
                    ? 'text-amber-300 font-medium'
                    : log.type === 'success'
                    ? 'text-[#00F0FF] font-medium'
                    : log.type === 'command'
                    ? 'text-purple-300 font-semibold'
                    : 'text-slate-300'
                }
              >
                {log.text}
              </span>
            </div>
          ))
        )}
      </div>

      {/* 5 & 6. Ô NHẬP LỆNH: DÀNH RIÊNG CHO QUẢN TRỊ VIÊN / BẢO MẬT BẢN QUYỀN CHO KHÁCH HÀNG */}
      {isAdmin ? (
        <>
          <div className="flex items-center space-x-1.5 px-3 py-1.5 bg-[#080D1A] border-b border-slate-800/80 overflow-x-auto scrollbar-none select-none">
            <span className="text-[10px] text-slate-500 shrink-0 font-sans font-medium">Lệnh nhanh:</span>
            {quickChips.map((chip, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setInputCmd(chip.cmd);
                  if (inputRef.current) inputRef.current.focus();
                }}
                className="px-2 py-0.5 rounded-md bg-slate-800/80 hover:bg-cyan-950/60 text-slate-300 hover:text-[#00F0FF] border border-slate-700/80 hover:border-cyan-500/40 text-[10px] shrink-0 transition-all font-mono"
                title={`Nhập lệnh: ${chip.cmd}`}
              >
                {chip.label}
              </button>
            ))}
          </div>

          <form onSubmit={(e) => handleExecuteInput(undefined, e)} className="flex items-center bg-[#060A14] px-3.5 py-2.5">
            <span className="text-[#00F0FF] mr-2.5 text-sm font-bold select-none">&gt;</span>
            <input
              ref={inputRef}
              type="text"
              value={inputCmd}
              onChange={(e) => setInputCmd(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Nhập lệnh adb shell (dành cho Quản trị viên)..."
              className="flex-1 bg-transparent text-slate-100 placeholder-slate-500 focus:outline-none text-xs sm:text-sm font-mono py-0.5"
              disabled={isExecuting}
            />
            <button
              type="submit"
              disabled={!inputCmd.trim() || isExecuting}
              className="ml-2 px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-[#00F0FF] to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-sans text-xs font-bold flex items-center space-x-1 disabled:opacity-40 transition-all shadow-md shadow-cyan-500/20 active:scale-95"
            >
              {isExecuting ? (
                <div className="w-3.5 h-3.5 border-2 border-black border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <span>Gửi Lệnh</span>
                  <CornerDownLeft className="w-3 h-3 text-black" />
                </>
              )}
            </button>
          </form>
        </>
      ) : (
        <div className="flex items-center justify-between gap-2 bg-[#060A14] px-4 py-2.5 text-[11px] font-sans border-t border-slate-800/80 text-slate-400">
          <div className="flex items-center space-x-2">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <span>Chế độ Khách Hàng: Quy trình tối ưu chạy tự động khép kín theo tiêu chuẩn bảo mật.</span>
          </div>
          <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 shrink-0 font-medium">
            Đã Khóa Bản Quyền
          </span>
        </div>
      )}
    </div>
  );
};
