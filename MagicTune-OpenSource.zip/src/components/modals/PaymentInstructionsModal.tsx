'use client';

import React, { useState } from 'react';
import {
  CreditCard,
  QrCode,
  ShieldCheck,
  CheckCircle2,
  Copy,
  ExternalLink,
  MessageSquare,
  Sparkles,
  Zap,
  Info,
  X,
  Crown,
  RotateCcw
} from 'lucide-react';
import { recordUserActivity, db } from '@/lib/firebase/config';
import { collection, addDoc } from 'firebase/firestore';

interface PaymentInstructionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser?: any;
  bankInfo?: {
    bankName: string;
    accountNumber: string;
    accountHolder: string;
  };
  vipPriceVnd?: number;
  onOpenChatSupport?: () => void;
  isAdminPreview?: boolean;
  onVipSuccess?: () => void;
  isMonetizationEnabled?: boolean;
}

export const PaymentInstructionsModal: React.FC<PaymentInstructionsModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  bankInfo = {
    bankName: 'MB Bank',
    accountNumber: '',
    accountHolder: 'BAN QUẢN TRỊ MAGICTUNE'
  },
  vipPriceVnd = 199000,
  onOpenChatSupport,
  isAdminPreview = false,
  onVipSuccess,
  isMonetizationEnabled = true
}) => {
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [isNotifyingAdmin, setIsNotifyingAdmin] = useState(false);
  const [notifiedSuccess, setNotifiedSuccess] = useState(false);

  // Các chế độ hiển thị: 'form' (VietQR) | 'fast_processing' (Đang quét ngân hàng) | 'vip_activated' (Chúc mừng VIP)
  const [modalMode, setModalMode] = useState<'form' | 'fast_processing' | 'vip_activated'>('form');
  const [simulationStep, setSimulationStep] = useState<number>(1);
  const [simulationProgress, setSimulationProgress] = useState<number>(20);
  const [simulatedTxId, setSimulatedTxId] = useState<string>('MT-VIP-8869');

  if (!isOpen) return null;

  // Nội dung chuyển khoản chuẩn hóa
  const userIdentifier = currentUser?.email || currentUser?.phoneNumber || currentUser?.uid?.substring(0, 8) || 'KHACH';
  const cleanId = userIdentifier.replace(/[^a-zA-Z0-9]/g, '').toLowerCase().substring(0, 15);
  const transferContent = `VIP ${cleanId}`;

  // Chuẩn hóa mã ngân hàng cho VietQR API (Ví dụ: "MB Bank" -> "MB", "Vietcombank" -> "VCB", "ACB" -> "ACB")
  const getStandardBankCode = (rawBank: string) => {
    const b = (rawBank || '').toUpperCase().trim();
    if (b.includes('MB') || b.includes('QUÂN ĐỘI')) return 'MB';
    if (b.includes('VIETCOM') || b.includes('VCB')) return 'VCB';
    if (b.includes('TECHCOM') || b.includes('TCB')) return 'TCB';
    if (b.includes('VIETIN') || b.includes('CTG')) return 'CTG';
    if (b.includes('BIDV')) return 'BIDV';
    if (b.includes('ACB')) return 'ACB';
    if (b.includes('VPB') || b.includes('THỊNH VƯỢNG')) return 'VPB';
    if (b.includes('TPB') || b.includes('TIÊN PHONG')) return 'TPB';
    if (b.includes('SACOM') || b.includes('STB')) return 'STB';
    if (b.includes('HDB')) return 'HDB';
    if (b.includes('OCB')) return 'OCB';
    if (b.includes('VIB')) return 'VIB';
    if (b.includes('MOMO')) return 'MOMO';
    return b.replace(/[^a-zA-Z0-9]/g, '');
  };

  const bankCode = getStandardBankCode(bankInfo.bankName);
  // Mã VietQR link tự động với số tiền và nội dung
  const vietQrUrl = `https://img.vietqr.io/image/${bankCode}-${bankInfo.accountNumber}-compact2.png?amount=${vipPriceVnd}&addInfo=${encodeURIComponent(transferContent)}&accountName=${encodeURIComponent(bankInfo.accountHolder)}`;

  const handleCopy = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2500);
  };

  // Quy trình mô phỏng Gia Hạn VIP Siêu Tốc (Dành cho Admin trải nghiệm 100% cảm giác của khách trong 2.5s)
  const handleFastTrackSimulate = () => {
    setModalMode('fast_processing');
    setSimulationStep(1);
    setSimulationProgress(25);
    const newTx = `MT-VIP-${Math.floor(1000 + Math.random() * 9000)}`;
    setSimulatedTxId(newTx);

    // Bước 1: Quét biến động số dư VietQR sau 850ms
    setTimeout(() => {
      setSimulationStep(2);
      setSimulationProgress(65);
    }, 850);

    // Bước 2: Khớp lệnh thành công & nạp quyền VIP sau 1700ms
    setTimeout(() => {
      setSimulationStep(3);
      setSimulationProgress(95);
    }, 1700);

    // Bước 3: Hoàn tất & mở màn hình chúc mừng VIP sau 2500ms
    setTimeout(() => {
      setSimulationProgress(100);
      setModalMode('vip_activated');
      if (onVipSuccess) {
        onVipSuccess();
      }
      recordUserActivity('Mô phỏng gia hạn VIP siêu tốc thành công (Admin Demo)', newTx);
    }, 2500);
  };

  // Nút người dùng báo "Tôi đã chuyển tiền xong" để đẩy thông báo về Firestore cho Admin
  const handleNotifyTransferCompleted = async () => {
    if (isAdminPreview) {
      handleFastTrackSimulate();
      return;
    }

    setIsNotifyingAdmin(true);
    try {
      const transferReport = {
        userId: currentUser?.uid || 'anonymous',
        userEmail: currentUser?.email || 'N/A',
        phoneNumber: currentUser?.phoneNumber || 'N/A',
        amount: vipPriceVnd,
        transferContent,
        bankName: bankInfo.bankName,
        accountNumber: bankInfo.accountNumber,
        status: 'pending_review',
        timestamp: new Date().toLocaleString('vi-VN'),
        createdAt: Date.now()
      };

      await addDoc(collection(db, 'payment_transactions'), transferReport);
      recordUserActivity('Thông báo đã chuyển khoản mua VIP', `Nội dung: ${transferContent} - Số tiền: ${vipPriceVnd.toLocaleString()} đ`);
      setNotifiedSuccess(true);
    } catch (e) {
      console.error('Lỗi gửi báo cáo chuyển khoản:', e);
      // Vẫn lưu vào local và thông báo thành công cho user
      recordUserActivity('Thông báo đã chuyển tiền VIP (Offline Mode)', transferContent);
      setNotifiedSuccess(true);
    } finally {
      setIsNotifyingAdmin(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-xl rounded-3xl bg-[#0D1629] border border-cyan-500/30 shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Banner Admin Fast Track */}
        {isAdminPreview && modalMode === 'form' && (
          <div className="bg-gradient-to-r from-amber-500/20 via-orange-500/20 to-amber-500/20 border-b border-amber-500/30 px-4 py-2 flex flex-wrap items-center justify-between text-xs gap-2">
            <div className="flex items-center space-x-2">
              <Zap className="w-4 h-4 text-amber-400 animate-pulse shrink-0" />
              <span className="text-amber-200 font-semibold text-[11px]">
                👁️ Chế độ Admin: Trải nghiệm quy trình gia hạn như khách hàng thật (Siêu tốc 2.5s)
              </span>
            </div>
            <button
              onClick={handleFastTrackSimulate}
              className="px-2.5 py-1 rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 hover:from-amber-300 text-black font-extrabold text-[10px] shadow-sm flex items-center space-x-1 transition-all active:scale-95"
            >
              <span>⚡ Gia Hạn Siêu Tốc (2.5s)</span>
            </button>
          </div>
        )}

        {/* Header Modal */}
        <div className="p-4 sm:p-5 bg-[#111A2E] border-b border-cyan-500/20 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-white flex items-center space-x-2">
                <span>
                  {modalMode === 'vip_activated'
                    ? '🎉 Gia Hạn & Kích Hoạt VIP Thành Công'
                    : 'Hướng Dẫn Chuyển Tiền Mua Dịch Vụ / VIP'}
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-gradient-to-r from-amber-500/20 to-orange-500/20 text-amber-300 border border-amber-500/30 font-bold uppercase">
                  {modalMode === 'vip_activated' ? 'Đã Kích Hoạt' : 'Tự Động Kích Hoạt'}
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">
                {modalMode === 'vip_activated'
                  ? 'Biên lai điện tử & danh sách đặc quyền người dùng vừa nhận được'
                  : 'Quét mã QR hoặc chuyển khoản để mở khóa toàn bộ đặc quyền không giới hạn'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-all text-xs"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* 1. MÀN HÌNH ĐANG XỬ LÝ SIÊU TỐC (FAST PROCESSING) */}
        {modalMode === 'fast_processing' && (
          <div className="p-6 sm:p-8 flex flex-col items-center justify-center space-y-5 text-center my-auto min-h-[360px]">
            <div className="relative">
              <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-cyan-500 via-amber-400 to-emerald-400 p-1 animate-spin">
                <div className="w-full h-full bg-[#0D1629] rounded-full flex items-center justify-center">
                  <Zap className="w-8 h-8 text-amber-400" />
                </div>
              </div>
              <span className="absolute -bottom-1 -right-1 px-2 py-0.5 rounded-full bg-emerald-500 text-black font-black text-[9px] uppercase tracking-wider">
                Fast Track
              </span>
            </div>

            <div className="space-y-1 max-w-md">
              <h4 className="text-base font-bold text-white">Đang Soát Lệnh &amp; Kích Hoạt Gia Hạn VIP...</h4>
              <p className="text-xs text-slate-400">
                Hệ thống tự động kết nối đối soát VietQR và kích hoạt đặc quyền VIP cho bạn.
              </p>
            </div>

            {/* Thanh Tiến Trình Animated */}
            <div className="w-full max-w-sm space-y-1.5">
              <div className="flex items-center justify-between text-[11px] font-mono text-cyan-300">
                <span>Tiến trình xử lý:</span>
                <span className="font-bold">{simulationProgress}%</span>
              </div>
              <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden border border-slate-700">
                <div
                  className="h-full bg-gradient-to-r from-[#00F0FF] via-emerald-400 to-amber-400 transition-all duration-300 rounded-full"
                  style={{ width: `${simulationProgress}%` }}
                />
              </div>
            </div>

            {/* Danh sách 3 bước kiểm tra ngân hàng */}
            <div className="w-full max-w-sm space-y-2 text-left text-xs bg-[#0A0F1D] p-3.5 rounded-2xl border border-slate-800">
              <div className={`flex items-center space-x-2.5 transition-all ${simulationStep >= 1 ? 'text-emerald-300' : 'text-slate-500'}`}>
                {simulationStep > 1 ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                ) : (
                  <div className="w-4 h-4 rounded-full border-2 border-cyan-400 border-t-transparent animate-spin shrink-0" />
                )}
                <span className="font-semibold text-[11px]">1. Đang kết nối API ngân hàng thụ hưởng ({bankInfo.bankName})</span>
              </div>

              <div className={`flex items-center space-x-2.5 transition-all ${simulationStep >= 2 ? 'text-emerald-300' : 'text-slate-500'}`}>
                {simulationStep > 2 ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                ) : simulationStep === 2 ? (
                  <div className="w-4 h-4 rounded-full border-2 border-cyan-400 border-t-transparent animate-spin shrink-0" />
                ) : (
                  <div className="w-4 h-4 rounded-full border border-slate-700 shrink-0" />
                )}
                <span className="font-semibold text-[11px]">2. Đã nhận diện giao dịch +{vipPriceVnd.toLocaleString('vi-VN')} đ (Khớp nội dung)</span>
              </div>

              <div className={`flex items-center space-x-2.5 transition-all ${simulationStep >= 3 ? 'text-amber-300' : 'text-slate-500'}`}>
                {simulationStep >= 3 ? (
                  <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
                ) : (
                  <div className="w-4 h-4 rounded-full border border-slate-700 shrink-0" />
                )}
                <span className="font-semibold text-[11px]">3. Ghi nhận quyền VIP Trọn Đời vào hệ thống</span>
              </div>
            </div>
          </div>
        )}

        {/* 2. MÀN HÌNH CHÚC MỪNG & BIÊN LAI KÍCH HOẠT VIP (VIP ACTIVATED) */}
        {modalMode === 'vip_activated' && (
          <div className="p-5 sm:p-6 space-y-4 text-center my-auto overflow-y-auto max-h-[82vh]">
            <div className="relative inline-flex flex-col items-center justify-center pt-1">
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-3xl bg-gradient-to-tr from-amber-400 via-yellow-300 to-amber-600 p-1 shadow-xl shadow-amber-500/25 flex items-center justify-center animate-bounce duration-1000">
                <Crown className="w-9 h-9 sm:w-11 sm:h-11 text-black fill-black" />
              </div>
              <div className="mt-2.5 space-y-1">
                <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-black uppercase tracking-wider">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span>Gia Hạn &amp; Nâng Cấp Thành Công!</span>
                </div>
                <h3 className="text-base sm:text-lg font-black text-white">
                  Chào Mừng Bạn Đến Với Gói VIP MagicTune Trọn Đời
                </h3>
                <p className="text-xs text-slate-300 max-w-md mx-auto">
                  Tài khoản của bạn đã được kích hoạt đầy đủ mọi đặc quyền cao cấp nhất. Không còn giới hạn, không còn quảng cáo!
                </p>
              </div>
            </div>

            {/* Chi Tiết Hóa Đơn / Biên Lai Điện Tử */}
            <div className="bg-[#0A0F1D] p-3.5 rounded-2xl border border-cyan-500/30 text-xs text-left space-y-2 max-w-md mx-auto shadow-inner">
              <div className="flex items-center justify-between pb-1.5 border-b border-slate-800">
                <span className="text-slate-400">Mã giao dịch / Biên lai:</span>
                <span className="font-mono font-bold text-cyan-300">{simulatedTxId}</span>
              </div>
              <div className="flex items-center justify-between pb-1.5 border-b border-slate-800">
                <span className="text-slate-400">Gói bản quyền:</span>
                <span className="font-bold text-white">VIP License (Vĩnh Viễn / Trọn Đời)</span>
              </div>
              <div className="flex items-center justify-between pb-1.5 border-b border-slate-800">
                <span className="text-slate-400">Số tiền thanh toán:</span>
                <span className="font-mono font-black text-amber-300">{vipPriceVnd.toLocaleString('vi-VN')} VNĐ</span>
              </div>
              <div className="flex items-center justify-between pb-1.5 border-b border-slate-800">
                <span className="text-slate-400">Tài khoản thụ hưởng:</span>
                <span className="text-slate-200 truncate max-w-[200px]">{currentUser?.email || currentUser?.phoneNumber || 'Tài khoản người dùng'}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Trạng thái kích hoạt:</span>
                <span className="inline-flex items-center space-x-1 text-emerald-400 font-bold">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Hoạt Động (Active Lifetime)</span>
                </span>
              </div>
            </div>

            {/* Lưới 4 Đặc Quyền VIP Người Dùng Trải Nghiệm */}
            <div className="grid grid-cols-2 gap-2 text-left max-w-md mx-auto text-[11px]">
              <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-0.5">
                <div className="font-bold text-cyan-300 flex items-center space-x-1">
                  <Zap className="w-3.5 h-3.5 text-[#00F0FF]" />
                  <span>Fix Trễ 0s Thông Báo</span>
                </div>
                <p className="text-slate-400 text-[10px]">Đến tức thì như máy quốc tế</p>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-0.5">
                <div className="font-bold text-purple-300 flex items-center space-x-1">
                  <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                  <span>120Hz &amp; Tối Ưu DPI Màn Hình</span>
                </div>
                <p className="text-slate-400 text-[10px]">Tối ưu độ phân giải sắc nét</p>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-0.5">
                <div className="font-bold text-amber-300 flex items-center space-x-1">
                  <Crown className="w-3.5 h-3.5 text-amber-400" />
                  <span>Gỡ App Rác Sạch 100%</span>
                </div>
                <p className="text-slate-400 text-[10px]">Tối ưu pin &amp; giải phóng RAM</p>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-0.5">
                <div className="font-bold text-emerald-300 flex items-center space-x-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Hỗ Trợ Kỹ Thuật 24/7</span>
                </div>
                <p className="text-slate-400 text-[10px]">Trợ lý AI &amp; Admin ưu tiên</p>
              </div>
            </div>

            {/* Các nút bấm hành động */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-2 pt-1 max-w-md mx-auto">
              <button
                onClick={onClose}
                className="w-full sm:flex-1 py-3 rounded-2xl bg-gradient-to-r from-amber-400 via-orange-500 to-amber-500 text-black font-extrabold text-xs shadow-lg shadow-amber-500/25 flex items-center justify-center space-x-1.5 transition-all hover:scale-[1.02] active:scale-[0.98]"
              >
                <Sparkles className="w-4 h-4 text-black" />
                <span>Trải Nghiệm Tính Năng VIP Ngay</span>
              </button>

              <button
                onClick={() => {
                  setModalMode('form');
                  setNotifiedSuccess(false);
                }}
                className="w-full sm:w-auto px-4 py-3 rounded-2xl bg-[#111A2E] hover:bg-slate-800 text-cyan-300 border border-cyan-500/30 font-bold text-xs flex items-center justify-center space-x-1 transition-all"
                title="Đặt lại để thử lại quy trình gia hạn"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Thử Lại Quy Trình</span>
              </button>
            </div>
          </div>
        )}

        {/* 3. MÀN HÌNH NẠP TIỀN / CHUYỂN KHOẢN CHUẨN (FORM) */}
        {modalMode === 'form' && (
          <div className="p-4 sm:p-6 overflow-y-auto space-y-5 text-xs">
            {/* Banner khi Admin Tắt Thu Phí -> Toàn bộ tính năng Miễn Phí kể cả VIP */}
            {isMonetizationEnabled === false && (
              <div className="p-4 rounded-2xl bg-emerald-500/15 border-2 border-emerald-500/40 text-emerald-300 space-y-2.5">
                <div className="flex items-center space-x-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                  <span className="font-extrabold text-sm text-white">Chế Độ Miễn Phí Toàn Diện Đang Bật</span>
                </div>
                <p className="text-xs text-emerald-200 leading-relaxed">
                  Quản trị viên đã <strong>tắt tính năng thu phí</strong>. Hiện tại toàn bộ 100% tính năng trên MagicTune (bao gồm các tính năng <strong>VIP Đặc Trị Meta Push, Bank OTP 0s</strong>) đều đang được mở <strong>HOÀN TOÀN MIỄN PHÍ</strong>. Bạn không cần thanh toán bất kỳ chi phí nào!
                </p>
                <button
                  onClick={() => {
                    if (onVipSuccess) onVipSuccess();
                    onClose();
                  }}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-400 to-cyan-400 hover:from-emerald-300 text-black font-extrabold text-xs shadow-md shadow-emerald-500/20 active:scale-98 transition-all flex items-center justify-center space-x-1.5"
                >
                  <Crown className="w-4 h-4 fill-black text-black" />
                  <span>Kích Hoạt &amp; Dùng Toàn Bộ Tính Năng VIP Miễn Phí Ngay</span>
                </button>
              </div>
            )}

            {/* Banner thông tin gói VIP */}
            <div className="p-4 rounded-2xl bg-gradient-to-r from-cyan-950/40 via-purple-950/40 to-slate-900 border border-cyan-500/30 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="space-y-1 text-center sm:text-left">
                <div className="text-[11px] font-bold text-cyan-300 flex items-center justify-center sm:justify-start space-x-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span>GÓI VIP TRỌN ĐỜI (MỌI TÍNH NĂNG MỌI DÒNG MÁY)</span>
                </div>
                <div className="text-xl font-black text-white font-mono">
                  {vipPriceVnd.toLocaleString('vi-VN')} <span className="text-xs text-amber-400 font-sans">VNĐ</span>
                </div>
                <div className="text-[10px] text-slate-400">
                  Fix trễ thông báo + Việt Hóa + Debloat + Hỗ trợ Android vĩnh viễn
                </div>
              </div>

              <div className="text-[11px] bg-[#0A0F1D] px-3 py-2 rounded-xl border border-slate-700 text-slate-300 space-y-1">
                <div>Định danh tài khoản:</div>
                <div className="font-bold text-[#00F0FF] truncate max-w-[180px]">
                  {currentUser?.email || currentUser?.phoneNumber || 'Khách vãng lai'}
                </div>
              </div>
            </div>

            {/* Vùng Mã QR Chuyển Khoản & Thông Tin Chi Tiết */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
              {/* Ảnh VietQR chuẩn */}
              <div className="p-3 bg-white rounded-2xl flex flex-col items-center justify-center border-2 border-cyan-400/50 shadow-lg text-center">
                <img
                  src={vietQrUrl}
                  alt="Mã VietQR Chuyển Khoản Nhanh"
                  className="w-48 h-48 object-contain rounded-lg"
                  loading="lazy"
                />
                <div className="text-[10px] text-slate-600 font-semibold mt-1.5 flex items-center space-x-1">
                  <QrCode className="w-3 h-3 text-cyan-600" />
                  <span>Quét bằng mọi ứng dụng Ngân hàng / MoMo</span>
                </div>
              </div>

              {/* Chi tiết tài khoản ngân hàng */}
              <div className="space-y-2.5">
                <div className="p-2.5 rounded-xl bg-[#0A0F1D] border border-slate-800">
                  <div className="text-[10px] text-slate-500 uppercase font-semibold">Ngân hàng thụ hưởng:</div>
                  <div className="font-bold text-white text-xs mt-0.5">{bankInfo.bankName}</div>
                </div>

                <div className="p-2.5 rounded-xl bg-[#0A0F1D] border border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="text-[10px] text-slate-500 uppercase font-semibold">Số tài khoản / STK:</div>
                    <div className="font-mono font-bold text-[#00F0FF] text-sm mt-0.5">{bankInfo.accountNumber}</div>
                  </div>
                  <button
                    onClick={() => handleCopy(bankInfo.accountNumber, 'accNum')}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-all flex items-center space-x-1 text-[10px]"
                  >
                    <Copy className="w-3 h-3" />
                    <span>{copiedField === 'accNum' ? 'Đã chép' : 'Sao chép'}</span>
                  </button>
                </div>

                <div className="p-2.5 rounded-xl bg-[#0A0F1D] border border-slate-800">
                  <div className="text-[10px] text-slate-500 uppercase font-semibold">Tên chủ tài khoản:</div>
                  <div className="font-bold text-amber-300 text-xs mt-0.5 uppercase">{bankInfo.accountHolder}</div>
                </div>

                {/* Bắt buộc: Nội dung chuyển tiền */}
                <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between">
                  <div>
                    <div className="text-[10px] text-amber-400 uppercase font-bold flex items-center space-x-1">
                      <span>Nội dung chuyển khoản (Bắt buộc):</span>
                    </div>
                    <div className="font-mono font-extrabold text-white text-sm mt-0.5 tracking-wider bg-black/40 px-2 py-0.5 rounded">
                      {transferContent}
                    </div>
                  </div>
                  <button
                    onClick={() => handleCopy(transferContent, 'content')}
                    className="p-1.5 rounded-lg bg-amber-500 text-black font-extrabold transition-all flex items-center space-x-1 text-[10px] hover:bg-amber-400"
                  >
                    <Copy className="w-3 h-3" />
                    <span>{copiedField === 'content' ? 'Đã chép' : 'Sao chép'}</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Hướng Dẫn Các Bước Chi Tiết */}
            <div className="p-4 rounded-2xl bg-[#0A0F1D] border border-slate-800 space-y-2">
              <div className="font-bold text-white flex items-center space-x-1.5 text-xs">
                <Info className="w-4 h-4 text-cyan-400" />
                <span>Admin Xác Nhận &amp; Cấp Quyền Như Thế Nào?</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                1. <strong>Hệ thống đối soát tự động:</strong> Khi nhận được chuyển khoản với nội dung <code className="text-cyan-300 font-bold">{transferContent}</code>, hệ thống và Admin sẽ tra cứu theo email/UID này để bấm <strong>Cấp Quyền VIP / Tính Năng</strong> ngay trong Trang Quản Trị.
              </p>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                2. <strong>Xác nhận nhanh:</strong> Sau khi chuyển tiền xong, bạn hãy bấm nút <strong>&quot;Tôi Đã Chuyển Tiền Xong&quot;</strong> bên dưới để tạo yêu cầu đối soát tức thì gửi đến Admin.
              </p>
            </div>

            {/* Trạng thái Báo đã chuyển tiền */}
            {notifiedSuccess ? (
              <div className="p-3.5 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                  <div>
                    <div className="font-bold">Đã gửi thông báo chuyển tiền tới Admin!</div>
                    <div className="text-[10px] text-emerald-400/80">Admin đang đối soát và sẽ kích hoạt tài khoản của bạn trong 1 - 3 phút.</div>
                  </div>
                </div>
                {onOpenChatSupport && (
                  <button
                    onClick={onOpenChatSupport}
                    className="px-3 py-1.5 rounded-xl bg-emerald-500 text-black font-bold text-[11px] shrink-0"
                  >
                    Nhắn Tin Admin
                  </button>
                )}
              </div>
            ) : (
              <div className="flex flex-col sm:flex-row items-center gap-2.5 pt-1">
                <button
                  onClick={handleNotifyTransferCompleted}
                  disabled={isNotifyingAdmin}
                  className="w-full sm:flex-1 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 text-black font-extrabold text-xs flex items-center justify-center space-x-2 shadow-lg shadow-emerald-500/20 transition-all hover:scale-[1.01] active:scale-[0.99]"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>
                    {isNotifyingAdmin
                      ? 'Đang gửi thông báo...'
                      : isAdminPreview
                      ? 'Tôi Đã Chuyển Tiền Xong (Thử Nghiệm Tức Thì)'
                      : 'Tôi Đã Chuyển Tiền Xong (Báo Admin Duyệt)'}
                  </span>
                </button>

                {isAdminPreview && (
                  <button
                    onClick={handleFastTrackSimulate}
                    className="w-full sm:w-auto px-4 py-3 rounded-2xl bg-gradient-to-r from-amber-500/20 to-orange-500/20 hover:from-amber-500/30 text-amber-300 border border-amber-500/40 font-bold text-xs flex items-center justify-center space-x-1.5 transition-all"
                  >
                    <Zap className="w-4 h-4 text-amber-400" />
                    <span>⚡ Kích Hoạt Nhanh</span>
                  </button>
                )}

                {onOpenChatSupport && (
                  <button
                    onClick={onOpenChatSupport}
                    className="w-full sm:w-auto px-4 py-3 rounded-2xl bg-[#111A2E] hover:bg-slate-800 text-cyan-300 border border-cyan-500/30 font-bold text-xs flex items-center justify-center space-x-1.5 transition-all"
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span>Chat Hỗ Trợ / Gặp Admin</span>
                  </button>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
