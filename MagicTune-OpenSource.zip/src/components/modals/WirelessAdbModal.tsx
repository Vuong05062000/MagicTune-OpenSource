'use client';

import React, { useState, useEffect } from 'react';
import {
  Wifi,
  Copy,
  Check,
  ArrowRight,
  QrCode,
  Smartphone,
  ShieldCheck,
  AlertTriangle,
  RotateCcw,
  Sparkles,
  Usb,
  Cpu,
  Layers,
  Wrench
} from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';

interface WirelessAdbModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConnectCustomIp?: (ip: string, port: string, code?: string) => void;
}

export const WirelessAdbModal: React.FC<WirelessAdbModalProps> = ({
  isOpen,
  onClose,
  onConnectCustomIp
}) => {
  const [tab, setTab] = useState<'manual_code' | 'on_device' | 'qr_scan' | 'fix_usb'>('manual_code');
  
  // Thông số Ghép nối qua QR tự động
  const [serviceName, setServiceName] = useState('');
  const [pairingPassword, setPairingPassword] = useState('');
  const [qrString, setQrString] = useState('');

  // Thông số thủ công
  const [ipAddress, setIpAddress] = useState('192.168.1.');
  const [port, setPort] = useState('5555');
  const [pairingPort, setPairingPort] = useState('37000');
  const [pairingCode, setPairingCode] = useState('');
  const [copiedCmd, setCopiedCmd] = useState(false);
  const [copiedRepairCmd, setCopiedRepairCmd] = useState(false);
  const [isSimulatingPair, setIsSimulatingPair] = useState(false);
  const [pairSuccess, setPairSuccess] = useState(false);

  // Tạo thông số ngẫu nhiên chuẩn Android ADB QR Pairing (WIFI:T:ADB;S:<name>;P:<password>;;)
  const generateQrPairing = () => {
    const randomId = Math.random().toString(36).substring(2, 8).toUpperCase();
    const svc = `MagicTune-${randomId}`;
    const pwd = Math.random().toString(36).substring(2, 12);
    setServiceName(svc);
    setPairingPassword(pwd);
    // Định dạng Google Android Standard ADB Wireless QR Pairing:
    setQrString(`WIFI:T:ADB;S:${svc};P:${pwd};;`);
    setPairSuccess(false);
  };

  useEffect(() => {
    if (isOpen) {
      generateQrPairing();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const quickCommand = `adb pair ${ipAddress}:${pairingPort} ${pairingCode || '123456'} && adb connect ${ipAddress}:${port}`;
  const winUsbRepairCmd = `powershell -Command "Restart-Service -Name '*adb*' -Force -ErrorAction SilentlyContinue; taskkill /F /IM adb.exe 2>$null; echo 'ADB Daemon đã được khởi động lại sạch sẽ!' "`;

  const handleCopyCmd = () => {
    navigator.clipboard.writeText(quickCommand);
    setCopiedCmd(true);
    setTimeout(() => setCopiedCmd(false), 2000);
  };

  const handleCopyRepairCmd = () => {
    navigator.clipboard.writeText(winUsbRepairCmd);
    setCopiedRepairCmd(true);
    setTimeout(() => setCopiedRepairCmd(false), 2000);
  };

  const handlePairAndConnect = () => {
    if (onConnectCustomIp) {
      onConnectCustomIp(ipAddress, port, pairingCode);
    }
  };

  const handleUseLocalhost = () => {
    setIpAddress('127.0.0.1');
    setPort('5555');
  };

  const handleOpenDevSettings = () => {
    window.location.href = 'intent:#Intent;action=android.settings.APPLICATION_DEVELOPMENT_SETTINGS;end';
  };

  const handleOpenShizuku = () => {
    window.location.href = 'intent://#Intent;package=moe.shizuku.privileged.api;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;end';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-xl rounded-2xl border border-cyan-500/30 bg-[#111A2E] p-5 sm:p-6 shadow-2xl shadow-cyan-950/40 max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-cyan-500/20">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-[#00F0FF]">
              <Wifi className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center space-x-2">
                <span>Ghép Nối Gỡ Lỗi Không Dây (Wireless ADB)</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-[#00F0FF] font-mono border border-cyan-500/30">
                  Android
                </span>
              </h3>
              <p className="text-xs text-slate-400">Hỗ trợ quét QR 1-chạm hoặc mã 6 số cho MagicOS, HyperOS, One UI, ColorOS...</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-all text-xs"
          >
            ✕
          </button>
        </div>

        {/* 4 Tabs điều hướng */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 my-4 p-1 rounded-xl bg-[#0A0F1D] border border-slate-800 text-xs">
          <button
            onClick={() => setTab('manual_code')}
            className={`py-2 px-2 sm:px-3 rounded-lg font-bold flex items-center justify-center space-x-1.5 transition-all ${
              tab === 'manual_code'
                ? 'bg-gradient-to-r from-purple-500 to-indigo-500 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Mã 6 Số / IP</span>
          </button>

          <button
            onClick={() => setTab('on_device')}
            className={`py-2 px-2 sm:px-3 rounded-lg font-bold flex items-center justify-center space-x-1.5 transition-all ${
              tab === 'on_device'
                ? 'bg-gradient-to-r from-[#00F0FF] to-blue-500 text-black shadow-md'
                : 'text-cyan-400 hover:text-cyan-300'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>1-Máy (Shizuku)</span>
          </button>

          <button
            onClick={() => setTab('qr_scan')}
            className={`py-2 px-2 sm:px-3 rounded-lg font-bold flex items-center justify-center space-x-1.5 transition-all ${
              tab === 'qr_scan'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-black shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <QrCode className="w-3.5 h-3.5" />
            <span>Quét QR PC</span>
          </button>

          <button
            onClick={() => setTab('fix_usb')}
            className={`py-2 px-2 sm:px-3 rounded-lg font-bold flex items-center justify-center space-x-1.5 transition-all ${
              tab === 'fix_usb'
                ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-black shadow-md'
                : 'text-amber-400 hover:text-amber-300'
            }`}
          >
            <Wrench className="w-3.5 h-3.5" />
            <span>Sửa Lỗi ADB</span>
          </button>
        </div>

        {/* TAB ON-DEVICE: KẾT NỐI TRÊN CÙNG 1 ĐIỆN THOẠI QUA SHIZUKU (KHÔNG CẦN THIẾT BỊ THỨ 2) */}
        {tab === 'on_device' && (
          <div className="space-y-4">
            <div className="p-4 rounded-xl bg-gradient-to-r from-purple-950/40 to-indigo-950/40 border border-purple-500/30 space-y-3">
              <div className="flex items-center space-x-2 text-purple-300 font-bold text-sm">
                <Smartphone className="w-4 h-4 text-purple-400" />
                <span>Quy trình ghép nối Shizuku trực tiếp trên chính điện thoại này</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Trên Android, bạn có thể kích hoạt quyền ADB cho Shizuku độc lập ngay trên máy mà không cần máy tính hay điện thoại thứ hai:
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                <button
                  onClick={handleOpenDevSettings}
                  className="p-2.5 rounded-xl bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 text-xs font-bold flex items-center justify-center space-x-2 hover:bg-cyan-500/25 active:scale-95 transition-all"
                >
                  <Wrench className="w-4 h-4 text-[#00F0FF]" />
                  <span>1. Mở Cài Đặt Gỡ Lỗi Wi-Fi</span>
                </button>
                <button
                  onClick={handleOpenShizuku}
                  className="p-2.5 rounded-xl bg-purple-500/20 border border-purple-500/40 text-purple-300 text-xs font-bold flex items-center justify-center space-x-2 hover:bg-purple-500/30 active:scale-95 transition-all"
                >
                  <Sparkles className="w-4 h-4 text-purple-400" />
                  <span>2. Mở Ứng Dụng Shizuku</span>
                </button>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-[#0A0F1D] border border-slate-800 space-y-2 text-xs text-slate-300">
              <div className="font-bold text-cyan-400">Các bước ghép nối trong 30 giây:</div>
              <ol className="list-decimal list-inside space-y-1.5 text-[11px] text-slate-300 leading-relaxed">
                <li>Bấm nút <strong>1. Mở Cài Đặt Gỡ Lỗi Wi-Fi</strong> &gt; Bật công tắc <em>Gỡ lỗi không dây</em> &gt; Nhấn <em>Ghép nối bằng mã ghép nối</em>.</li>
                <li>Hệ thống hiện thông báo mã 6 chữ số kèm cổng kết nối.</li>
                <li>Kéo thanh thông báo xuống hoặc bấm nút <strong>2. Mở Ứng Dụng Shizuku</strong> &gt; Nhập mã 6 chữ số vào ô của Shizuku.</li>
                <li>Shizuku sẽ chuyển sang trạng thái <strong>&quot;Shizuku đang chạy (Running)&quot;</strong> hoàn toàn độc lập trên máy!</li>
              </ol>
            </div>

            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between text-xs">
              <span className="text-slate-400 text-[11px]">Dùng cổng ADB cục bộ trên thiết bị này:</span>
              <button
                onClick={() => {
                  handleUseLocalhost();
                  setTab('manual_code');
                }}
                className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-[#00F0FF] to-blue-500 text-black font-extrabold text-[11px] active:scale-95 transition-all"
              >
                Điền 127.0.0.1:5555 &amp; Kết Nối
              </button>
            </div>
          </div>
        )}

        {/* TAB QR: GHÉP NỐI BẰNG QUÉT MÃ QR (Mở trên máy tính để điện thoại quét) */}
        {tab === 'qr_scan' && (
          <div className="space-y-4">
            <div className="p-4 rounded-xl bg-[#0A0F1D] border border-cyan-500/20 flex flex-col sm:flex-row items-center gap-4">
              {/* QR Container */}
              <div className="p-3 bg-white rounded-2xl shadow-lg shrink-0 flex flex-col items-center justify-center">
                <QRCodeSVG
                  value={qrString}
                  size={155}
                  level="H"
                  includeMargin={true}
                />
                <span className="text-[10px] text-slate-800 font-bold font-mono mt-1">Chuẩn Android ADB QR</span>
              </div>

              {/* Hướng dẫn quét */}
              <div className="space-y-2 text-xs text-slate-300">
                <div className="font-bold text-white flex items-center space-x-1.5 text-sm">
                  <Sparkles className="w-4 h-4 text-[#00F0FF]" />
                  <span>Cách ghép nối qua Camera điện thoại:</span>
                </div>
                <ol className="list-decimal list-inside space-y-1.5 text-[11px] text-slate-300 leading-relaxed">
                  <li>Mở màn hình này trên <strong>Máy Tính (PC/Laptop)</strong>.</li>
                  <li>Trên điện thoại, mở <strong>Cài đặt &gt; Tùy chọn nhà phát triển &gt; Gỡ lỗi không dây</strong>.</li>
                  <li>Bấm vào dòng chữ <strong>&quot;Ghép nối thiết bị bằng mã QR&quot;</strong> (Pair device with QR code).</li>
                  <li>Hướng camera điện thoại quét mã QR bên cạnh. <strong>Hai máy sẽ ghép nối tự động tức thì!</strong></li>
                </ol>

                <div className="pt-2 flex flex-wrap items-center gap-2">
                  <button
                    onClick={generateQrPairing}
                    className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] flex items-center space-x-1"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Làm mới mã QR</span>
                  </button>
                  <button
                    onClick={() => setTab('manual_code')}
                    className="px-3 py-1.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 text-[#00F0FF] border border-cyan-500/30 text-[11px] font-bold flex items-center space-x-1"
                  >
                    <span>Nhập Thủ Công IP &rarr;</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: NHẬP MÃ 6 SỐ THỦ CÔNG */}
        {tab === 'manual_code' && (
          <div className="space-y-4">
            <div className="space-y-2 text-xs text-slate-300">
              <div className="p-3 rounded-xl bg-[#0A0F1D] border border-cyan-500/15 space-y-1 text-[11px]">
                <div className="text-purple-400 font-bold">Lấy mã 6 số từ điện thoại:</div>
                <p className="text-slate-400 leading-relaxed">
                  Tại màn hình <strong>Gỡ lỗi không dây</strong>, nhấn <em>&quot;Ghép nối thiết bị bằng mã ghép nối&quot;</em>. Nhập chính xác IP, Cổng (Port) và Mã số hiện trên điện thoại vào bên dưới:
                </p>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2.5">
              <div className="col-span-1">
                <label className="block text-[11px] text-slate-400 mb-1">Địa chỉ IP:</label>
                <input
                  type="text"
                  value={ipAddress}
                  onChange={(e) => setIpAddress(e.target.value)}
                  className="w-full bg-[#0A0F1D] border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono"
                />
              </div>
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Cổng kết nối:</label>
                <input
                  type="text"
                  value={port}
                  onChange={(e) => setPort(e.target.value)}
                  className="w-full bg-[#0A0F1D] border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono"
                />
              </div>
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Mã 6 chữ số:</label>
                <input
                  type="text"
                  value={pairingCode}
                  onChange={(e) => setPairingCode(e.target.value)}
                  placeholder="123456"
                  className="w-full bg-[#0A0F1D] border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono"
                />
              </div>
            </div>

            {/* Khung chép lệnh */}
            <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800">
              <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1.5 font-mono">
                <span>Hoặc chạy trực tiếp trên máy tính qua Terminal:</span>
                <button
                  onClick={handleCopyCmd}
                  className="text-[#00F0FF] hover:underline flex items-center space-x-1"
                >
                  {copiedCmd ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedCmd ? 'Đã sao chép' : 'Sao chép lệnh'}</span>
                </button>
              </div>
              <code className="text-[11px] text-cyan-300 font-mono break-all">{quickCommand}</code>
            </div>

            <div className="flex justify-end">
              <button
                onClick={handlePairAndConnect}
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-400 text-white text-xs font-bold transition-all flex items-center space-x-1.5 shadow-md shadow-purple-500/20"
              >
                <span>Bắt Đầu Ghép Nối &amp; Kết Nối</span>
                <ArrowRight className="w-3.5 h-3.5 text-white" />
              </button>
            </div>
          </div>
        )}

        {/* TAB 3: BỘ SỬA LỖI MÁY TÍNH KHÔNG HIỆN THIẾT BỊ DÙ ĐÃ BẬT GỠ LỖI USB */}
        {tab === 'fix_usb' && (
          <div className="space-y-3.5 text-xs">
            <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 space-y-2">
              <div className="font-bold text-amber-300 flex items-center space-x-2 text-sm">
                <AlertTriangle className="w-4 h-4 text-amber-400" />
                <span>Tại sao điện thoại đã bật Gỡ lỗi USB nhưng cắm vào máy tính không hiện?</span>
              </div>
              <p className="text-slate-300 leading-relaxed text-[11px]">
                Đây là lỗi rất phổ biến trên Windows do <strong>chế độ kết nối USB của điện thoại mặc định là &quot;Chỉ Sạc&quot;</strong>, driver ADB Windows bị treo tiến trình chạy ngầm, hoặc chưa cấp quyền máy tính tin cậy (RSA Key).
              </p>
            </div>

            {/* 4 Bước xử lý triệt để */}
            <div className="space-y-2.5">
              <div className="p-3 rounded-xl bg-[#0A0F1D] border border-slate-800 flex items-start space-x-2.5">
                <div className="w-5 h-5 rounded-full bg-cyan-500/20 text-[#00F0FF] font-bold flex items-center justify-center shrink-0 text-xs">1</div>
                <div>
                  <div className="font-bold text-white">Chuyển chế độ kết nối USB sang &quot;Truyền tệp&quot; (MTP):</div>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Khi cắm cáp, vuốt thanh thông báo từ mép trên màn hình điện thoại xuống ➔ Bấm vào thông báo <em>&quot;Đang sạc qua USB&quot;</em> ➔ Chọn chuyển sang <strong>&quot;Truyền tệp / Android Auto (Transfer Files)&quot;</strong>.
                  </p>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-[#0A0F1D] border border-slate-800 flex items-start space-x-2.5">
                <div className="w-5 h-5 rounded-full bg-purple-500/20 text-purple-400 font-bold flex items-center justify-center shrink-0 text-xs">2</div>
                <div>
                  <div className="font-bold text-white">Bật &quot;Cho phép gỡ lỗi ADB khi chỉ sạc&quot; (Charge only):</div>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Trên MagicOS / HyperOS / ColorOS: Vào <strong>Tùy chọn nhà phát triển</strong> ➔ Tìm và BẬT công tắc <strong>&quot;Cho phép gỡ lỗi ADB ở chế độ chỉ sạc&quot;</strong>.
                  </p>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-[#0A0F1D] border border-slate-800 flex items-start space-x-2.5">
                <div className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-400 font-bold flex items-center justify-center shrink-0 text-xs">3</div>
                <div>
                  <div className="font-bold text-white">Thu hồi quyền gỡ lỗi USB cũ để hiện lại bảng hỏi:</div>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Vào <strong>Tùy chọn nhà phát triển</strong> ➔ Bấm vào dòng <strong>&quot;Thu hồi ủy quyền gỡ lỗi USB&quot; (Revoke USB debugging authorizations)</strong> ➔ Bấm OK ➔ Rút dây cáp ra và cắm lại.
                  </p>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-[#0A0F1D] border border-slate-800 flex items-start space-x-2.5">
                <div className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center shrink-0 text-xs">4</div>
                <div className="flex-1">
                  <div className="font-bold text-white">Reset tiến trình ADB bị kẹt trên máy tính (1-Click):</div>
                  <p className="text-[11px] text-slate-400 mt-0.5 mb-1.5">
                    Nếu phần mềm giả lập (LDPlayer, Nox, BlueStacks...) đang chạy, nó sẽ khóa cổng ADB khiến WebADB không nhận được máy.
                  </p>
                  <button
                    onClick={handleCopyRepairCmd}
                    className="px-3 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/30 font-mono text-[11px] flex items-center space-x-1.5"
                  >
                    {copiedRepairCmd ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedRepairCmd ? 'Đã sao chép lệnh sửa lỗi!' : 'Sao chép lệnh Reset ADB Service'}</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="flex items-center justify-between pt-4 mt-4 border-t border-slate-800">
          <span className="text-[11px] text-slate-400">
            {tab === 'qr_scan' && 'Quét mã QR là cách nhanh và tiện lợi nhất hiện nay'}
            {tab === 'manual_code' && 'Hỗ trợ tất cả các mạng Wi-Fi băng tần 2.4GHz & 5GHz'}
            {tab === 'fix_usb' && 'Khắc phục 100% lỗi không nhận thiết bị khi cắm cáp'}
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs hover:bg-slate-700 transition-all"
          >
            Đóng
          </button>
        </div>
      </div>
    </div>
  );
};
