'use client';

import React, { useState, useRef, useEffect } from 'react';
import {
  MessageSquare,
  Bot,
  User,
  Send,
  X,
  Phone,
  Mail,
  ExternalLink,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  Clock,
  HelpCircle,
  QrCode
} from 'lucide-react';
import { recordUserActivity, db, auth } from '@/lib/firebase/config';
import { collection, addDoc, query, orderBy, limit, onSnapshot } from 'firebase/firestore';

interface SupportChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  adminContact?: {
    email: string;
    phone: string;
    bankName?: string;
    accountNumber?: string;
  };
  isMonetizationEnabled?: boolean;
  showAdminTab?: boolean;
  groqConfig?: {
    apiKey?: string;
    model?: string;
    systemPrompt?: string;
  };
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'ai' | 'admin';
  text: string;
  timestamp: string;
}

export const SupportChatModal: React.FC<SupportChatModalProps> = ({
  isOpen,
  onClose,
  adminContact = {
    email: 'support@magictune.web.app',
    phone: 'Hỗ trợ trực tuyến'
  },
  isMonetizationEnabled = false,
  showAdminTab = false,
  groqConfig
}) => {
  const [activeTab, setActiveTab] = useState<'ai' | 'admin'>('ai');

  // Đảm bảo nếu Admin tắt tab Admin thì activeTab chuyển về 'ai'
  useEffect(() => {
    if (!showAdminTab && activeTab === 'admin') {
      setActiveTab('ai');
    }
  }, [showAdminTab, activeTab]);
  const [inputMsg, setInputMsg] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Tin nhắn mở đầu tự nhiên, thân thiện từ Trợ lý Groq AI
  const [aiMessages, setAiMessages] = useState<ChatMessage[]>([
    {
      id: 'init-1',
      sender: 'ai',
      text: 'Xin chào bạn! Mình là Trợ lý Hỗ trợ Kỹ thuật & Khách hàng của MagicTune. Bạn đang gặp vướng mắc gì về kết nối WebADB, lỗi trễ thông báo hay cần tối ưu dòng máy nào cứ nhắn tự nhiên cho mình nhé!',
      timestamp: 'Vừa xong'
    }
  ]);

  // Cuộn xuống tin mới nhất
  const scrollToBottom = () => {
    try {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    } catch {
      // safe fallback
    }
  };

  useEffect(() => {
    if (isOpen) {
      const timer = setTimeout(() => {
        scrollToBottom();
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [isOpen, aiMessages, activeTab]);

  if (!isOpen) return null;

  // Xử lý gửi tin nhắn AI thông minh qua Groq API
  const handleSendAi = async (textToSend?: string) => {
    const text = (textToSend || inputMsg).trim();
    if (!text || isTyping) return;

    const userMsg: ChatMessage = {
      id: 'user_' + Date.now(),
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })
    };

    const nextMessages = [...aiMessages, userMsg];
    setAiMessages(nextMessages);
    if (!textToSend) setInputMsg('');
    setIsTyping(true);

    recordUserActivity('Chat với MagicTune AI', text);

    const apiKey = groqConfig?.apiKey || process.env.NEXT_PUBLIC_GROQ_API_KEY || '';
    const model = groqConfig?.model || 'llama-3.3-70b-versatile';
    const defaultSystemPrompt = `Bạn là Trợ lý Hỗ trợ Khách hàng & Kỹ thuật chuyên nghiệp của nền tảng MagicTune (https://magictune.web.app - bộ công cụ WebADB trực tuyến).
Phong cách trò chuyện:
- Trò chuyện tự nhiên, xưng hô thân mật ("mình" hoặc "tôi" với "bạn"), giải thích lưu loát như một kỹ sư công nghệ người thật.
- Câu trả lời súc tích, đi thẳng vào trọng tâm kỹ thuật, dễ hiểu và không dùng văn mẫu dập khuôn.
- Kiến thức chuyên sâu:
  + Kết nối WebADB: Bật Gỡ lỗi USB (USB Debugging) trong Cài đặt > Tùy chọn nhà phát triển, cắm cáp chọn "Luôn cho phép từ máy tính này", sử dụng trình duyệt Chrome/Edge có hỗ trợ WebUSB API.
  + Fix trễ thông báo Facebook, Messenger, Gmail, Zalo (0s Miss): Vào tab "Fix Trễ FB, Gmail, Zalo (0s)", bấm "Kích Hoạt FCM Push Siêu Tốc" để gỡ Doze Mode và đưa app vào danh sách trắng ngầm.
  + Nút "⚡ Ép Hiện Bảng Cho Phép (RSA Mới)": Khắc phục triệt để khi điện thoại Android/Honor không chịu hiện hộp thoại Cho phép gỡ lỗi USB. Nút này xóa toàn bộ chứng chỉ RSA cũ trong IndexedDB ("Tango", "WebADB") và bộ nhớ trình duyệt, sinh cặp khóa RSA-2048 mới tinh và phát gói tin bắt tay ép điện thoại bật sáng màn hình hiện lại bảng hỏi RSA ngay lập tức.
  + Shizuku Engine: Hướng dẫn kích hoạt Shizuku qua WebADB để sau này điện thoại tự can thiệp hệ thống không cần máy tính.
  + Gỡ ứng dụng rác (Debloat): An toàn, giữ lại ứng dụng hệ thống cốt lõi.
  + Đa hãng Android: Hỗ trợ HyperOS, OriginOS, ColorOS, MagicOS, One UI, Pixel.
  + Chi phí: Cả website WebADB và app MagicTune APK trên GitHub đều hoàn toàn MIỄN PHÍ 100%, không cần đăng nhập hay nâng cấp Pro.`;
    const systemPrompt = groqConfig?.systemPrompt || defaultSystemPrompt;

    let reply = '';

    if (apiKey.trim()) {
      try {
        const formattedHistory = nextMessages.slice(-6).map((m) => ({
          role: m.sender === 'user' ? ('user' as const) : ('assistant' as const),
          content: m.text
        }));

        const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey.trim()}`
          },
          body: JSON.stringify({
            model: model,
            messages: [
              { role: 'system', content: systemPrompt },
              ...formattedHistory
            ],
            temperature: 0.7,
            max_tokens: 1024
          })
        });

        if (response.ok) {
          const data = await response.json();
          const content = data?.choices?.[0]?.message?.content;
          if (content && typeof content === 'string') {
            reply = content.trim();
          }
        } else {
          console.warn('[Groq API Error]', response.status, await response.text());
        }
      } catch (err) {
        console.error('[Groq Fetch Exception]', err);
      }
    }

    // Nếu Groq API Key chưa được cài đặt hoặc gặp sự cố mạng, phản hồi thông minh tự nhiên:
    if (!reply) {
      const lower = text.toLowerCase();
      if (lower.includes('chào') || lower.includes('hello') || lower.includes('hi ') || lower.includes('alo')) {
        reply = `Chào bạn nhé! Rất vui được hỗ trợ bạn. Bạn đang cần tối ưu dòng máy nào hoặc gặp lỗi gì với thông báo hay kết nối WebADB, cứ chia sẻ tự nhiên với mình nhé!`;
      } else if (lower.includes('thanh toán') || lower.includes('mua') || lower.includes('vip') || lower.includes('giá') || lower.includes('tiền') || lower.includes('phí')) {
        reply = `Bạn yên tâm nhé, hiện tại website MagicTune trên máy tính đang mở **hoàn toàn MIỄN PHÍ 100%** toàn bộ tính năng (bao gồm cả Fix thông báo 0s, gỡ app rác, tối ưu hiệu năng). Bạn cứ cắm cáp kết nối và sử dụng thoải mái không mất bất kỳ chi phí nào!`;
      } else if (lower.includes('thông báo') || lower.includes('facebook') || lower.includes('zalo') || lower.includes('gmail') || lower.includes('trễ') || lower.includes('miss')) {
        reply = `Để sửa triệt để trễ thông báo FB, Gmail, Zalo, bạn làm như sau nhé:\n1. Kết nối điện thoại với WebADB qua cáp Type-C.\n2. Chọn tab **"Fix Trễ FB, Gmail, Zalo (0s)"** trên thanh menu.\n3. Nhấn nút **"Kích Hoạt FCM Push Siêu Tốc"** tương ứng với app bạn muốn.\nLệnh này sẽ gỡ bỏ chế độ ngủ sâu (Doze Mode) và đưa app vào danh sách ưu tiên chạy nền vĩnh viễn, tin nhắn sẽ nổ chuông ngay lập tức không trễ 1 giây nào!`;
      } else if (lower.includes('rsa') || lower.includes('ép hiện') || lower.includes('bảng cho phép') || lower.includes('không hiện bảng') || lower.includes('không hỏi quyền')) {
        reply = `⚡ **CƠ CHẾ NÚT "ÉP HIỆN BẢNG CHO PHÉP (RSA MỚI)":**\n\nKhi bạn bấm nút này, MagicTune sẽ thực hiện tuần tự 4 bước kỹ thuật tự động:\n1. **Vô hiệu hóa & ngắt kết nối cũ**: Đóng mọi phiên kết nối USB đang bị kẹt hoặc treo.\n2. **Xóa sạch kho lưu trữ chứng chỉ cũ**: Xóa hoàn toàn IndexedDB ("Tango", "WebADB", "MagicTune") và Storage của trình duyệt — tương tự thao tác "Quên thiết bị này" trên điện thoại.\n3. **Sinh cặp khóa RSA-2048 mới tinh**: Trình duyệt tạo một chứng minh thư mã hóa mới hoàn toàn.\n4. **Đẩy gói tin bắt tay kèm RSA mới xuống adbd điện thoại**: Vì tiến trình adbd trên Android chưa từng ghi nhận cặp khóa mới này trong danh sách tin tưởng (/data/misc/adb/adb_keys), Android lập tức coi đây là thiết bị mới lạ và cưỡng bức bật sáng màn hình, hiện ngay bảng hỏi:\n*"Cho phép gỡ lỗi USB? Dấu vân tay khóa RSA của máy tính này là..."*\n\nBạn chỉ cần tích chọn **"Luôn cho phép"** và bấm **[OK]** là kết nối thành công 100%!`;
      } else if (lower.includes('kết nối') || lower.includes('adb') || lower.includes('không nhận') || lower.includes('nhận diện') || lower.includes('cáp') || lower.includes('usb')) {
        reply = `Nếu máy tính chưa nhận điện thoại, bạn kiểm tra 3 bước này giúp mình nhé:\n1. Vào **Cài đặt > Thông tin điện thoại > chạm 7 lần vào "Số hiệu bản dựng"** để mở Tùy chọn nhà phát triển.\n2. Vào Tùy chọn nhà phát triển bật **"Gỡ lỗi USB" (USB Debugging)**.\n3. Khi cắm cáp, màn hình điện thoại hiện bảng hỏi RSA, bạn tích chọn **"Luôn cho phép từ máy tính này"** rồi bấm Cho phép/OK.\nNhớ dùng trình duyệt Chrome hoặc Edge để có WebUSB nhé!`;
      } else if (lower.includes('shizuku')) {
        reply = `Shizuku là cầu nối cực kỳ tiện lợi! Bạn chỉ cần vào tab **"Cầu Nối Shizuku Engine"** trên web, bấm **"Khởi Chạy Shizuku Qua WebADB"**. Sau khi kích hoạt thành công, các ứng dụng can thiệp hệ thống trên điện thoại có thể hoạt động độc lập mà không cần phải cắm lại máy tính nữa.`;
      } else if (lower.includes('rác') || lower.includes('debloat') || lower.includes('xóa app') || lower.includes('gỡ')) {
        reply = `Bạn có thể vào tab **"Gỡ Ứng Dụng Rác"** để xóa các app quảng cáo, app mặc định không dùng của nhà sản xuất. MagicTune đã phân loại sẵn mức độ an toàn (Xanh: An toàn tuyệt đối, Vàng: Chú ý, Đỏ: App hệ thống cốt lõi không nên gỡ) để máy bạn luôn chạy nhẹ và mát mẻ nhất!`;
      } else {
        reply = `Mình đã ghi nhận câu hỏi của bạn về "${text}".\n\nNếu bạn đang gặp lỗi kỹ thuật cụ thể (như thông báo không nổ chuông, máy tính không nhận điện thoại, hay cần tối ưu HyperOS/OriginOS/MagicOS), bạn cứ mô tả chi tiết dòng máy và hiện tượng, mình sẽ hướng dẫn từng bước xử lý ngay nhé!`;
      }
    }

    setAiMessages((prev) => [
      ...prev,
      {
        id: 'ai_' + Date.now(),
        sender: 'ai',
        text: reply,
        timestamp: new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })
      }
    ]);
    setIsTyping(false);
  };

  return (
    <div 
      className="fixed inset-0 z-[100] flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div 
        className="w-full max-w-xl rounded-3xl bg-[#0D1629] border border-cyan-500/30 shadow-2xl overflow-hidden flex flex-col h-[600px] max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Modal */}
        <div className="p-4 bg-[#111A2E] border-b border-cyan-500/20 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-[#00F0FF]">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex flex-wrap items-center gap-1.5">
                <span>Trung Tâm Hỗ Trợ Khách Hàng &amp; Kỹ Thuật</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-[#00F0FF] border border-cyan-500/30 font-mono whitespace-nowrap shrink-0">
                  Groq LLaMA 3.3
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-mono whitespace-nowrap shrink-0">
                  Online 24/7
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">
                Hỗ trợ kỹ thuật 24/7, hướng dẫn sử dụng công cụ miễn phí 100% và gặp Quản trị viên
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Đóng hộp thoại hỗ trợ"
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-all text-xs shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Lựa chọn: AI Nội Bộ vs Gặp Admin (Admin có thể cấu hình ẩn/hiện tab Admin) */}
        {showAdminTab ? (
          <div className="flex border-b border-slate-800 bg-[#0A0F1D] p-1.5 gap-1.5">
            <button
              onClick={() => setActiveTab('ai')}
              className={`flex-1 py-2 rounded-xl text-xs font-bold flex items-center justify-center space-x-2 transition-all ${
                activeTab === 'ai'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-black shadow-md shadow-cyan-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Bot className="w-4 h-4" />
              <span>Chat Với MagicTune AI (Nội Bộ)</span>
            </button>

            <button
              onClick={() => setActiveTab('admin')}
              className={`flex-1 py-2 rounded-xl text-xs font-bold flex items-center justify-center space-x-2 transition-all ${
                activeTab === 'admin'
                  ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-black shadow-md shadow-amber-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <User className="w-4 h-4" />
              <span>Gặp Trực Tiếp Quản Trị Viên (Admin)</span>
            </button>
          </div>
        ) : (
          <div className="flex items-center space-x-2 border-b border-slate-800 bg-[#0A0F1D] px-4 py-2.5 text-xs font-bold text-cyan-300">
            <Bot className="w-4 h-4 text-[#00F0FF]" />
            <span>Kênh Trợ Lý Trí Tuệ Nhân Tạo MagicTune AI</span>
          </div>
        )}

        {/* Nội Dung Tab 1: AI Chat Nội Bộ */}
        {activeTab === 'ai' && (
          <div className="flex-1 flex flex-col min-h-0 bg-[#070B16]">
            {/* Vùng Tin Nhắn */}
            <div className="flex-1 p-4 overflow-y-auto space-y-3.5 text-xs">
              {aiMessages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex items-start space-x-2.5 ${
                    msg.sender === 'user' ? 'flex-row-reverse space-x-reverse' : ''
                  }`}
                >
                  <div
                    className={`w-7 h-7 rounded-xl flex items-center justify-center shrink-0 text-xs font-bold ${
                      msg.sender === 'user'
                        ? 'bg-purple-600 text-white'
                        : 'bg-cyan-500/20 text-[#00F0FF] border border-cyan-500/40'
                    }`}
                  >
                    {msg.sender === 'user' ? <User className="w-3.5 h-3.5" /> : <Bot className="w-3.5 h-3.5" />}
                  </div>

                  <div
                    className={`max-w-[85%] rounded-2xl p-3 leading-relaxed whitespace-pre-wrap ${
                      msg.sender === 'user'
                        ? 'bg-cyan-500 text-black font-medium rounded-tr-none'
                        : 'bg-[#111A2E] text-slate-200 border border-slate-800 rounded-tl-none shadow-sm'
                    }`}
                  >
                    {msg.text}
                    <div
                      className={`text-[9px] mt-1 text-right ${
                        msg.sender === 'user' ? 'text-black/60 font-semibold' : 'text-slate-500'
                      }`}
                    >
                      {msg.timestamp}
                    </div>
                  </div>
                </div>
              ))}

              {isTyping && (
                <div className="flex items-center space-x-2 text-slate-400 text-xs italic">
                  <div className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                  <span>MagicTune AI đang soạn câu trả lời...</span>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input Gửi Tin Nhắn */}
            <div className="p-3 bg-[#0D1629] border-t border-cyan-500/20 flex items-center space-x-2">
              <input
                type="text"
                value={inputMsg}
                onChange={(e) => setInputMsg(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendAi()}
                placeholder="Nhập câu hỏi kỹ thuật (Trợ lý Groq AI trò chuyện tự nhiên 24/7)..."
                className="flex-1 bg-[#0A0F1D] border border-cyan-500/30 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
              />
              <button
                onClick={() => handleSendAi()}
                disabled={!inputMsg.trim() || isTyping}
                className="p-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 disabled:opacity-40 text-black font-bold transition-all shrink-0"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Nội Dung Tab 2: Liên Hệ Gặp Admin Trực Tiếp */}
        {activeTab === 'admin' && (
          <div className="flex-1 p-5 overflow-y-auto bg-[#070B16] space-y-5 text-xs">
            <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/10 to-orange-500/10 border border-amber-500/30 flex items-start space-x-3">
              <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-300 shrink-0">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-amber-300 text-sm">Hỗ Trợ Kỹ Thuật Trực Tiếp 1 - 1 Từ Quản Trị Viên</h4>
                <p className="text-slate-300 mt-1 leading-relaxed text-[11px]">
                  Nếu bạn đã chuyển khoản mua dịch vụ nhưng chưa được kích hoạt, hoặc gặp lỗi thiết bị phức tạp cần UltraViewer / Anydesk can thiệp, hãy liên hệ trực tiếp với Admin qua các kênh dưới đây.
                </p>
              </div>
            </div>

            {/* Các Kênh Liên Hệ Nhanh */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {/* Kênh Zalo & SĐT */}
              <a
                href={`https://zalo.me/${adminContact.phone}`}
                target="_blank"
                rel="noreferrer"
                className="p-4 rounded-2xl bg-[#111A2E] hover:bg-[#16223d] border border-cyan-500/20 hover:border-cyan-400 transition-all flex items-center justify-between group"
              >
                <div className="flex items-center space-x-3">
                  <div className="p-2.5 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-400 font-semibold uppercase">Hotline &amp; Zalo Trực Tiếp</div>
                    <div className="font-bold text-white text-sm group-hover:text-cyan-300 font-mono">
                      {adminContact.phone}
                    </div>
                  </div>
                </div>
                <ExternalLink className="w-4 h-4 text-slate-500 group-hover:text-cyan-400 transition-colors" />
              </a>

              {/* Kênh Email */}
              <a
                href={`mailto:${adminContact.email}?subject=Kích hoạt dịch vụ MagicTune&body=Chào Admin, tôi đã chuyển khoản kích hoạt tài khoản...`}
                className="p-4 rounded-2xl bg-[#111A2E] hover:bg-[#16223d] border border-purple-500/20 hover:border-purple-400 transition-all flex items-center justify-between group"
              >
                <div className="flex items-center space-x-3">
                  <div className="p-2.5 rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div className="truncate">
                    <div className="text-[10px] text-slate-400 font-semibold uppercase">Email Quản Trị</div>
                    <div className="font-bold text-white text-xs group-hover:text-purple-300 font-mono truncate max-w-[150px]">
                      {adminContact.email}
                    </div>
                  </div>
                </div>
                <ExternalLink className="w-4 h-4 text-slate-500 group-hover:text-purple-400 transition-colors" />
              </a>
            </div>

            {/* Thông Tin Mã Nguồn Mở & Miễn Phí 100% */}
            <div className="p-4 rounded-2xl bg-[#0A0F1D] border border-emerald-500/30 space-y-2.5">
              <h5 className="font-bold text-white flex items-center space-x-1.5 text-xs">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Cam kết Miễn Phí 100% &amp; Mã Nguồn Mở:</span>
              </h5>
              <div className="space-y-1.5 text-[11px] text-slate-300 leading-relaxed">
                <div>• Cả website MagicTune WebADB và app MagicTune APK đều đã được công khai mã nguồn trên GitHub.</div>
                <div>• Mọi tính năng tối ưu pin, fix trễ thông báo 0s, 120Hz, gỡ ứng dụng rác đều mở khóa vĩnh viễn 100% miễn phí.</div>
                <div>• Người dùng không cần tạo tài khoản hay đăng nhập, cắm cáp kết nối là sử dụng ngay!</div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
