'use client';

import React, { useState } from 'react';
import {
  HelpCircle,
  X,
  Smartphone,
  Usb,
  Wifi,
  ShieldAlert,
  CheckCircle2,
  AlertTriangle,
  ExternalLink,
  ChevronRight,
  Sparkles,
  Info,
  Monitor
} from 'lucide-react';

interface ConnectionGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ConnectionGuideModal({ isOpen, onClose }: ConnectionGuideModalProps) {
  const [activeTab, setActiveTab] = useState<'easy_step' | 'troubleshoot' | 'video'>('easy_step');

  if (!isOpen) return null;

  return (
    <div role="dialog" aria-modal="true" aria-label="Hướng dẫn kết nối" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-2xl max-h-[90vh] flex flex-col rounded-3xl bg-[#0D1629] border border-cyan-500/30 shadow-2xl relative text-slate-100 overflow-hidden">
        {/* Header */}
        <div className="px-6 py-5 border-b border-cyan-500/20 bg-[#0A0F1D]/80 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center">
              <HelpCircle className="w-5 h-5 text-[#00F0FF]" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white flex items-center space-x-2">
                <span>Hướng Dẫn Kết Nối Cho Mọi Người</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold">
                  Dễ Dàng 100%
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Kể cả người lớn tuổi hay người mới dùng lần đầu cũng làm được trong 1 phút!
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Đóng hướng dẫn kết nối"
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Thông báo điều kiện tiên quyết quan trọng */}
        <div className="px-6 py-3 bg-gradient-to-r from-blue-950/60 via-cyan-950/40 to-slate-900 border-b border-cyan-500/20 flex items-center space-x-2.5 text-xs">
          <Monitor className="w-4 h-4 text-[#00F0FF] shrink-0" />
          <span className="text-slate-200 leading-tight">
            <strong>LƯU Ý QUAN TRỌNG:</strong> WebADB yêu cầu mở trang web này trên <strong>Máy tính (PC/Laptop dùng Google Chrome hoặc Microsoft Edge)</strong> rồi cắm cáp USB nối sang điện thoại. Nếu mở web bằng chính điện thoại đó, bạn vui lòng kích hoạt <strong>Cầu Nối Shizuku</strong> hoặc kết nối từ máy tính.
          </span>
        </div>

        {/* Tab switchers */}
        <div className="px-6 pt-3 flex items-center space-x-2 border-b border-slate-800 bg-[#0A0F1D]/40">
          <button
            onClick={() => setActiveTab('easy_step')}
            className={`pb-3 text-xs font-bold transition-all border-b-2 flex items-center space-x-1.5 ${
              activeTab === 'easy_step'
                ? 'border-[#00F0FF] text-[#00F0FF]'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>3 Bước Kết Nối Cực Đơn Giản</span>
          </button>

          <button
            onClick={() => setActiveTab('troubleshoot')}
            className={`pb-3 text-xs font-bold transition-all border-b-2 flex items-center space-x-1.5 ${
              activeTab === 'troubleshoot'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Xử Lý Lỗi Máy Không Nhận Cáp</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-xs">
          {activeTab === 'easy_step' && (
            <div className="space-y-4">
              {/* Bước 1 */}
              <div className="p-4 rounded-2xl bg-[#0A0F1D] border border-cyan-500/20 flex items-start space-x-3.5">
                <div className="w-8 h-8 rounded-xl bg-cyan-500 text-black font-black text-sm flex items-center justify-center shrink-0 shadow-lg shadow-cyan-500/20">
                  1
                </div>
                <div className="space-y-1.5">
                  <h4 className="font-bold text-sm text-white flex items-center space-x-2">
                    <span>Bật &quot;Tùy chọn nhà phát triển&quot; trên điện thoại</span>
                  </h4>
                  <p className="text-slate-300 leading-relaxed">
                    Vào <strong>Cài đặt (Settings)</strong> ➔ <strong>Giới thiệu điện thoại (About Phone)</strong> ➔ Nhấn liên tục <strong>7 lần</strong> vào dòng chữ <strong>&quot;Số bản dựng&quot; (Build Number)</strong> cho đến khi máy báo <em>&quot;Bạn đã là nhà phát triển&quot;</em>.
                  </p>
                </div>
              </div>

              {/* Bước 2 */}
              <div className="p-4 rounded-2xl bg-[#0A0F1D] border border-cyan-500/20 flex items-start space-x-3.5">
                <div className="w-8 h-8 rounded-xl bg-purple-500 text-white font-black text-sm flex items-center justify-center shrink-0 shadow-lg shadow-purple-500/20">
                  2
                </div>
                <div className="space-y-1.5">
                  <h4 className="font-bold text-sm text-white">
                    Bật &quot;Gỡ lỗi USB&quot; (USB Debugging)
                  </h4>
                  <p className="text-slate-300 leading-relaxed">
                    Vào <strong>Cài đặt</strong> ➔ <strong>Hệ thống &amp; Cập nhật</strong> ➔ <strong>Tùy chọn cho nhà phát triển</strong> ➔ Gạt bật công tắc <strong>&quot;Gỡ lỗi USB&quot; (USB Debugging)</strong>.
                  </p>
                  <div className="p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-300 text-[11px]">
                    💡 <strong>Mẹo nhỏ:</strong> Nếu có mục <em>&quot;Cho phép gỡ lỗi ADB khi chỉ sạc&quot;</em> hoặc <em>&quot;Gỡ lỗi qua Wi-Fi&quot;</em>, hãy bật luôn để lần sau không cần cắm dây.
                  </div>
                </div>
              </div>

              {/* Bước 3 */}
              <div className="p-4 rounded-2xl bg-[#0A0F1D] border border-cyan-500/20 flex items-start space-x-3.5">
                <div className="w-8 h-8 rounded-xl bg-emerald-500 text-black font-black text-sm flex items-center justify-center shrink-0 shadow-lg shadow-emerald-500/20">
                  3
                </div>
                <div className="space-y-1.5">
                  <h4 className="font-bold text-sm text-white">
                    Cắm cáp sạc vào máy tính &amp; Bấm &quot;Kết Nối Cáp USB&quot;
                  </h4>
                  <p className="text-slate-300 leading-relaxed">
                    Cắm dây cáp nối điện thoại với máy tính. Trên ứng dụng này, bấm nút màu xanh <strong className="text-cyan-400">&quot;Kết Nối Cáp USB&quot;</strong> ở góc trên bên phải.
                  </p>
                  <p className="text-emerald-400 font-semibold text-[11px] flex items-center space-x-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Trên màn hình điện thoại hiện bảng hỏi &quot;Cho phép gỡ lỗi USB?&quot;, bạn tick vào ô <strong>&quot;Luôn cho phép&quot;</strong> rồi bấm <strong>OK</strong> là xong!</span>
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'troubleshoot' && (
            <div className="space-y-3.5">
              <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 space-y-2">
                <h4 className="font-bold text-rose-300 flex items-center space-x-2 text-sm">
                  <ShieldAlert className="w-4 h-4 text-rose-400" />
                  <span>Trường hợp 1: Bấm nút nhưng trình duyệt báo &quot;Không tìm thấy thiết bị&quot;?</span>
                </h4>
                <ul className="list-disc list-inside text-slate-300 space-y-1 pl-1 leading-relaxed">
                  <li>Hãy dùng cáp sạc <strong>truyền được dữ liệu</strong> (tránh dùng các loại dây sạc giá rẻ chỉ hỗ trợ sạc điện).</li>
                  <li>Cắm sang cổng USB khác trên máy tính (ưu tiên cắm cổng USB phía sau thùng máy đối với PC bàn).</li>
                  <li>Trên điện thoại, vuốt từ mép trên xuống chọn chế độ USB là <strong>&quot;Truyền tệp (File Transfer / MTP)&quot;</strong> thay vì &quot;Chỉ sạc&quot;.</li>
                </ul>
              </div>

              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 space-y-2">
                <h4 className="font-bold text-amber-300 flex items-center space-x-2 text-sm">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  <span>Trường hợp 2: Điện thoại không hiện thông báo hỏi &quot;Cho phép gỡ lỗi USB&quot;?</span>
                </h4>
                <ul className="list-disc list-inside text-slate-300 space-y-1 pl-1 leading-relaxed">
                  <li>Vào lại <strong>Tùy chọn nhà phát triển</strong>, cuộn tìm dòng <strong>&quot;Thu hồi quyền gỡ lỗi USB&quot; (Revoke USB debugging authorizations)</strong>, bấm OK rồi rút cáp ra cắm lại.</li>
                  <li>Tắt và bật lại công tắc <strong>&quot;Gỡ lỗi USB&quot;</strong>.</li>
                </ul>
              </div>

              <div className="p-4 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 space-y-2">
                <h4 className="font-bold text-cyan-300 flex items-center space-x-2 text-sm">
                  <Sparkles className="w-4 h-4 text-cyan-400" />
                  <span>Trường hợp 3: Không có máy tính hoặc không có dây cáp?</span>
                </h4>
                <p className="text-slate-300 leading-relaxed">
                  Bạn có thể dùng cáp OTG nối với một chiếc điện thoại Android khác hoặc cắm cáp USB vào máy tính để kích hoạt <strong className="text-white">&quot;Cầu Nối Shizuku&quot;</strong>, sau đó điện thoại có thể tự duy trì quyền hạn tối ưu ngầm!
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-[#0A0F1D] flex items-center justify-between">
          <span className="text-[11px] text-slate-400 flex items-center space-x-1">
            <Info className="w-3.5 h-3.5 text-cyan-400" />
            <span>Hỗ trợ miễn phí trọn đời cho người dùng Android &amp; MagicOS</span>
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-cyan-500 text-black font-extrabold text-xs shadow-lg shadow-cyan-500/20 hover:bg-cyan-400 transition-all"
          >
            Đóng Hướng Dẫn
          </button>
        </div>
      </div>
    </div>
  );
}
