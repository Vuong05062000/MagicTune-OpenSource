'use client';

import React, { useState } from 'react';
import {
  Smartphone,
  CheckCircle2,
  XCircle,
  HelpCircle,
  AlertTriangle,
  RefreshCw,
  RotateCw,
  Usb,
  Sparkles,
  Zap,
  Radio
} from 'lucide-react';
import { DeviceProfiler } from '@/lib/adb/honor-scripts';
import { adbDriver } from '@/lib/adb/web-usb-driver';

interface DeviceInfoCardProps {
  profiler: DeviceProfiler | null;
  isConnected: boolean;
  onRefresh?: () => void;
  isInspecting?: boolean;
  onOpenGuide?: () => void;
  supportedAndroidRange?: string;
  onSelectTab?: (tabId: any) => void;
}

export const DeviceInfoCard: React.FC<DeviceInfoCardProps> = ({
  profiler,
  isConnected,
  onRefresh,
  isInspecting = false,
  onOpenGuide,
  supportedAndroidRange = 'Android',
  onSelectTab
}) => {
  const [isRebooting, setIsRebooting] = useState(false);
  const [rebootDone, setRebootDone] = useState(false);
  const [rebootMsg, setRebootMsg] = useState<string | null>(null);
  const [isOneClickOptimizing, setIsOneClickOptimizing] = useState(false);
  const [oneClickDone, setOneClickDone] = useState(false);

  const handleRebootDevice = async (mode: 'normal' | 'recovery' = 'normal') => {
    if (!isConnected || isRebooting) return;
    const confirmText = mode === 'recovery' 
      ? 'Bạn có chắc chắn muốn khởi động lại vào Recovery Mode không?' 
      : 'Khởi động lại điện thoại ngay bây giờ? Sau khi khởi động, kết nối cáp sẽ ngắt và tự kết nối lại.';
    if (!window.confirm(confirmText)) return;

    setIsRebooting(true);
    setRebootDone(false);
    setRebootMsg('Đang gửi lệnh Reboot...');
    try {
      if (mode === 'recovery') {
        const { HonorAdbScripts } = await import('@/lib/adb/honor-scripts');
        const cmds = HonorAdbScripts.getRebootDeviceCommands(mode);
        await adbDriver.executePipeline(cmds);
      } else {
        await adbDriver.rebootDevice();
      }
      setRebootDone(true);
      setRebootMsg('Đã gửi lệnh! Điện thoại đang khởi động lại...');
      setTimeout(() => {
        setRebootMsg(null);
        setRebootDone(false);
      }, 6000);
    } catch (e: any) {
      setRebootMsg('Lỗi gửi lệnh reboot: ' + (e.message || e));
    } finally {
      setIsRebooting(false);
    }
  };

  // Trạng thái: CHƯA KẾT NỐI QUA ADB/CÁP USB
  if (!isConnected) {
    return (
      <div className="relative rounded-2xl border border-cyan-500/30 bg-gradient-to-br from-[#0F172A] via-[#111A2E] to-[#0A0F1D] backdrop-blur-xl p-5 overflow-hidden space-y-4 shadow-xl">
        <div className="flex items-center space-x-3 text-left">
          <div className="w-11 h-11 rounded-2xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-[#00F0FF] shrink-0 shadow-md">
            <Usb className="w-6 h-6" />
          </div>
          <div>
            <div className="text-sm font-extrabold text-white flex items-center space-x-2">
              <span>Chưa Kết Nối Cáp USB</span>
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Vui lòng kết nối điện thoại qua cáp USB và bật Gỡ lỗi USB
            </p>
          </div>
        </div>

        <div className="p-3 rounded-xl bg-[#0A0F1D]/80 border border-slate-800 text-[11px] text-slate-300 space-y-1.5">
          <div className="text-[10px] uppercase font-bold text-cyan-400 tracking-wider">
            Yêu cầu kết nối:
          </div>
          <ul className="list-disc list-inside space-y-1 text-slate-400">
            <li>Dùng cáp USB truyền được dữ liệu (tránh cáp chỉ hỗ trợ sạc).</li>
            <li>Bật <strong className="text-white">Gỡ lỗi USB (USB Debugging)</strong> trong Cài đặt nhà phát triển.</li>
            <li>Khi cắm cáp, nhấn <strong className="text-[#00F0FF]">&quot;Luôn cho phép từ máy tính này&quot;</strong>.</li>
          </ul>
        </div>

        <button
          onClick={() => adbDriver.forceNewRsaKeyAndReconnect()}
          className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-500/15 via-teal-500/15 to-blue-500/15 hover:from-cyan-500/25 hover:to-blue-500/25 text-[#00F0FF] border border-cyan-500/35 text-xs font-bold transition-all flex items-center justify-center space-x-1.5 shadow-sm active:scale-98"
          title="Xóa khóa RSA cũ, tạo chứng minh thư mới và ép điện thoại Android bật lại hộp thoại Cho phép gỡ lỗi USB"
        >
          <Zap className="w-3.5 h-3.5 text-[#00F0FF] fill-current" />
          <span>Ép Hiện Bảng Cho Phép (RSA Mới)</span>
        </button>

        {onOpenGuide && (
          <button
            onClick={onOpenGuide}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-500/20 to-blue-500/20 hover:from-cyan-500/30 hover:to-blue-500/30 text-[#00F0FF] border border-cyan-500/40 text-xs font-bold transition-all flex items-center justify-center space-x-1.5 shadow-md shadow-cyan-500/10 active:scale-98"
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Xem Hướng Dẫn Bật Gỡ Lỗi USB (1 Phút)</span>
          </button>
        )}
      </div>
    );
  }

  // Xác định tên hãng sản xuất chuẩn xác
  const brandDisplay = (() => {
    const raw = `${profiler?.marketName || ''} ${profiler?.model || ''}`.toUpperCase();
    if (raw.includes('HONOR')) return 'HONOR';
    if (raw.includes('HUAWEI')) return 'HUAWEI';
    if (raw.includes('XIAOMI') || raw.includes('REDMI') || raw.includes('POCO')) return 'XIAOMI / REDMI';
    if (raw.includes('SAMSUNG')) return 'SAMSUNG';
    if (raw.includes('OPPO')) return 'OPPO';
    if (raw.includes('VIVO') || raw.includes('IQOO')) return 'VIVO / IQOO';
    if (raw.includes('ONEPLUS')) return 'ONEPLUS';
    if (raw.includes('REALME')) return 'REALME';
    if (raw.includes('PIXEL') || raw.includes('GOOGLE')) return 'GOOGLE PIXEL';
    return profiler?.marketName || 'ANDROID';
  })();

  const deviceNameDisplay = profiler?.marketName || profiler?.model || 'Thiết Bị Android';

  // Gợi ý tính năng tối ưu chính xác dựa trên danh mục chuẩn 13 Mục của MagicTune
  const recommendedConfig = (() => {
    switch (brandDisplay) {
      case 'HONOR':
      case 'HUAWEI':
        return {
          tip: '[ƯU TIÊN] (Fix Trễ FB, Gmail, Zalo 0s) & [Mục 1] (Fix Máy Nội Địa - Bastet/PowerGenie) để nổ chuông thông báo 0 giây 100%.',
          primaryTab: 'notifications',
          primaryBadge: 'ƯU TIÊN',
          primaryLabel: 'Fix Trễ 0s',
          secondaryTab: 'chinarom',
          secondaryBadge: 'Mục 1',
          secondaryLabel: 'Fix ROM Nội Địa'
        };
      case 'XIAOMI / REDMI':
        return {
          tip: '[Mục 8] (Fix Đa Hãng - Đóng Băng Joyose & PowerKeeper) & [ƯU TIÊN] (Fix Trễ 0s) để giữ FPS và nổ chuông tức thì.',
          primaryTab: 'multibrand',
          primaryBadge: 'Mục 8',
          primaryLabel: 'Fix HyperOS / Joyose',
          secondaryTab: 'notifications',
          secondaryBadge: 'ƯU TIÊN',
          secondaryLabel: 'Fix Trễ 0s'
        };
      case 'SAMSUNG':
        return {
          tip: '[Mục 8] (Fix Đa Hãng - Tối Ưu One UI & GOS) & [Mục 4] (Gỡ Ứng Dụng Rác) để máy mượt, phản hồi nhanh tức thì.',
          primaryTab: 'multibrand',
          primaryBadge: 'Mục 8',
          primaryLabel: 'Tối Ưu One UI',
          secondaryTab: 'debloat',
          secondaryBadge: 'Mục 4',
          secondaryLabel: 'Gỡ App Rác'
        };
      case 'OPPO':
      case 'REALME':
      case 'ONEPLUS':
        return {
          tip: '[Mục 8] (Fix Đa Hãng - ColorOS Tweaks) & [ƯU TIÊN] (Fix Trễ 0s) để giữ mạng khi tắt màn hình và cấp quyền chạy ngầm.',
          primaryTab: 'multibrand',
          primaryBadge: 'Mục 8',
          primaryLabel: 'ColorOS Tweaks',
          secondaryTab: 'notifications',
          secondaryBadge: 'ƯU TIÊN',
          secondaryLabel: 'Fix Trễ 0s'
        };
      case 'VIVO / IQOO':
        return {
          tip: '[Mục 8] (Fix Đa Hãng - OriginOS Tweaks) & [Mục 6] (120Hz & Tối Ưu Màn Hình) để tối ưu tiến trình ngầm và màn hình siêu mượt.',
          primaryTab: 'multibrand',
          primaryBadge: 'Mục 8',
          primaryLabel: 'OriginOS Tweaks',
          secondaryTab: 'performance',
          secondaryBadge: 'Mục 6',
          secondaryLabel: '120Hz & Tối Ưu Màn'
        };
      case 'GOOGLE PIXEL':
        return {
          tip: '[ƯU TIÊN] (Fix Trễ FB, Gmail, Zalo 0s) & [Mục 4] (Gỡ Ứng Dụng Rác) để tối ưu thời lượng pin và dịch vụ nền.',
          primaryTab: 'notifications',
          primaryBadge: 'ƯU TIÊN',
          primaryLabel: 'Fix Trễ 0s',
          secondaryTab: 'debloat',
          secondaryBadge: 'Mục 4',
          secondaryLabel: 'Gỡ App Rác'
        };
      default:
        return {
          tip: '[ƯU TIÊN] (Fix Trễ FB, Gmail, Zalo 0s) & [Mục 4] (Gỡ Ứng Dụng Rác) để máy mượt, pin bền và nhận tin tức thì.',
          primaryTab: 'notifications',
          primaryBadge: 'ƯU TIÊN',
          primaryLabel: 'Fix Trễ 0s',
          secondaryTab: 'debloat',
          secondaryBadge: 'Mục 4',
          secondaryLabel: 'Gỡ App Rác'
        };
    }
  })();

  const handleOneClickAllInOne = async () => {
    if (!isConnected || isOneClickOptimizing) return;
    setIsOneClickOptimizing(true);
    setOneClickDone(false);

    try {
      const brand = brandDisplay.toUpperCase();
      const cmds: string[] = [
        '# --- 1-CLICK TỐI ƯU TOÀN DIỆN THIẾT BỊ ---',
        'settings put global adaptive_battery_management_enabled 1',
        'settings put global auto_sync 1',
        'settings put global wifi_sleep_policy 2',
        'settings put global mobile_data_always_on 1',
        'settings put global window_animation_scale 0.75',
        'settings put global transition_animation_scale 0.75',
        'settings put global animator_duration_scale 0.75'
      ];

      // Tối ưu theo từng hãng
      if (brand.includes('HONOR') || brand.includes('HUAWEI')) {
        cmds.push(
          'pm disable-user --user 0 com.hihonor.bastet.service',
          'pm disable-user --user 0 com.hihonor.powergenie',
          'pm disable-user --user 0 com.hihonor.logupload',
          'pm disable-user --user 0 com.hihonor.analytics'
        );
      } else if (brand.includes('XIAOMI') || brand.includes('REDMI') || brand.includes('POCO')) {
        cmds.push(
          'pm disable-user --user 0 com.xiaomi.joyose',
          'pm disable-user --user 0 com.miui.powerkeeper',
          'pm disable-user --user 0 com.miui.analytics',
          'pm disable-user --user 0 com.miui.msa.global'
        );
      } else if (brand.includes('OPPO') || brand.includes('REALME') || brand.includes('ONEPLUS')) {
        cmds.push(
          'pm disable-user --user 0 com.oppo.qualityprotect',
          'pm disable-user --user 0 com.heytap.mcs'
        );
      } else if (brand.includes('VIVO') || brand.includes('IQOO')) {
        cmds.push(
          'pm disable-user --user 0 com.vivo.daemonService',
          'pm disable-user --user 0 com.bbk.iqoo.logsystem'
        );
      } else if (brand.includes('SAMSUNG')) {
        cmds.push(
          'pm disable-user --user 0 com.samsung.android.game.gametools',
          'pm disable-user --user 0 com.samsung.android.game.gos'
        );
      }

      // Đưa các ứng dụng nhắn tin cốt lõi vào whitelist
      const essentialApps = [
        'com.zing.zalo',
        'com.facebook.katana',
        'com.facebook.orca',
        'com.google.android.gm',
        'org.telegram.messenger',
        'com.google.android.gms'
      ];

      essentialApps.forEach((pkg) => {
        cmds.push(
          `dumpsys deviceidle whitelist +${pkg}`,
          `cmd appops set ${pkg} RUN_IN_BACKGROUND allow`,
          `cmd appops set ${pkg} RUN_ANY_IN_BACKGROUND allow`,
          `cmd appops set ${pkg} WAKE_LOCK allow`,
          `am set-standby-bucket ${pkg} active`
        );
      });

      const { adbDriver } = await import('@/lib/adb/web-usb-driver');
      const res = await adbDriver.executePipeline(cmds, undefined, { title: '1-Click Tối Ưu Toàn Diện Thiết Bị' });

      if (res.success) {
        setOneClickDone(true);
        setTimeout(() => setOneClickDone(false), 5000);
      }
    } catch (e) {
      console.error('OneClick Optimizer error:', e);
    } finally {
      setIsOneClickOptimizing(false);
    }
  };



  // Trạng thái: ĐÃ KẾT NỐI - Hiển thị đúng 100% tên máy thực tế & gợi ý chuẩn xác
  return (
    <div className="relative rounded-2xl border border-emerald-500/30 bg-[#111A2E]/95 backdrop-blur-xl p-4 shadow-lg shadow-emerald-950/20 overflow-hidden space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-xs text-emerald-400 font-bold uppercase tracking-wider">Đã Kết Nối Thiết Bị</span>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            </div>
            <div className="flex items-center space-x-2 mt-0.5">
              <span className="text-base font-black text-white tracking-wide">
                {deviceNameDisplay}
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-500/15 text-[#00F0FF] border border-cyan-500/30 font-mono font-bold">
                {brandDisplay}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-1.5 shrink-0">
          <button
            onClick={() => handleRebootDevice('normal')}
            disabled={isRebooting}
            className="p-2 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 transition-all text-xs flex items-center space-x-1"
            title="Khởi động lại điện thoại (Reboot Device)"
          >
            <RotateCw className={`w-3.5 h-3.5 text-amber-400 ${isRebooting ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline text-[11px] font-bold">Khởi động lại</span>
          </button>

          {onRefresh && (
            <button
              onClick={onRefresh}
              disabled={isInspecting}
              className="p-2 rounded-xl bg-[#0A0F1D] hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/80 transition-all text-xs flex items-center space-x-1"
              title="Kiểm tra lại trạng thái kết nối"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-[#00F0FF] ${isInspecting ? 'animate-spin' : ''}`} />
              <span className="hidden sm:inline text-[11px] font-semibold">Quét lại</span>
            </button>
          )}
        </div>
      </div>

      {rebootMsg && (
        <div className="px-3 py-1.5 rounded-lg bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-semibold flex items-center space-x-1.5">
          <RotateCw className="w-3.5 h-3.5 text-amber-400 animate-spin" />
          <span>{rebootMsg}</span>
        </div>
      )}

      {/* Nút 1-Chạm Tối Ưu Toàn Diện */}
      <button
        onClick={handleOneClickAllInOne}
        disabled={isOneClickOptimizing}
        className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#00F0FF] via-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black text-xs font-black shadow-lg shadow-cyan-500/25 flex items-center justify-center space-x-2 transition-all active:scale-[0.98]"
      >
        {isOneClickOptimizing ? (
          <>
            <div className="w-3.5 h-3.5 border-2 border-black border-t-transparent rounded-full animate-spin" />
            <span>Đang Tự Động Tối Ưu Toàn Diện Cho {brandDisplay}...</span>
          </>
        ) : oneClickDone ? (
          <>
            <CheckCircle2 className="w-4 h-4 text-emerald-950" />
            <span>Hoàn Tất Tối Ưu Toàn Diện 100%!</span>
          </>
        ) : (
          <>
            <Usb className="w-4 h-4" />
            <span>⚡ 1-Click Tối Ưu Tự Động Toàn Diện Cho {brandDisplay}</span>
          </>
        )}
      </button>

      {/* BẢNG KIỂM TRA HỆ THỐNG THỰC TẾ (SYSTEM DIAGNOSTICS AUDIT) */}
      {(() => {
        const bastetBad = profiler?.bastetStatus === 'enabled';
        const powerGenieBad = profiler?.powerGenieStatus === 'enabled';
        const batteryHot = profiler?.batteryTemp !== null && profiler?.batteryTemp !== undefined && profiler.batteryTemp > 38;

        const hasRestrictions = bastetBad || powerGenieBad;
        const systemStatus = hasRestrictions ? 'Có dịch vụ chặn nền' : 'Đã tối ưu hóa nền';

        return (
          <div className="p-3.5 rounded-xl bg-[#0A0F1D] border border-cyan-500/20 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <span className="text-xs font-bold text-white uppercase tracking-wider">Khám Sức Khỏe Thiết Bị (Thực Tế 100%)</span>
              </div>
              <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold border ${
                !hasRestrictions ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
              }`}>
                {systemStatus}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
              <div className="p-2 rounded-lg bg-[#111A2E] border border-slate-800 flex items-center justify-between">
                <span className="text-slate-300">Khóa thông báo nền:</span>
                <span className={`font-semibold flex items-center space-x-1 ${!bastetBad ? 'text-emerald-400' : 'text-amber-400'}`}>
                  {!bastetBad ? <CheckCircle2 className="w-3 h-3 text-emerald-400" /> : <AlertTriangle className="w-3 h-3 text-amber-400" />}
                  <span>{!bastetBad ? 'Đã Mở Khóa' : 'Đang Bị Bóp'}</span>
                </span>
              </div>

              <div className="p-2 rounded-lg bg-[#111A2E] border border-slate-800 flex items-center justify-between">
                <span className="text-slate-300">Dịch vụ Bastet / PowerGenie:</span>
                <span className={`font-semibold ${bastetBad || powerGenieBad ? 'text-amber-400' : 'text-emerald-400'}`}>
                  {bastetBad || powerGenieBad ? 'Chạy Ngầm (Cần Tắt)' : 'Đã Đóng Băng'}
                </span>
              </div>

              <div className="p-2 rounded-lg bg-[#111A2E] border border-slate-800 flex items-center justify-between">
                <span className="text-slate-300">Nhiệt độ cell pin:</span>
                <span className={`font-mono font-semibold ${
                  profiler?.batteryTemp !== null && profiler?.batteryTemp !== undefined 
                    ? (batteryHot ? 'text-rose-400' : 'text-cyan-300') 
                    : 'text-slate-400'
                }`}>
                  {profiler?.batteryTemp !== null && profiler?.batteryTemp !== undefined 
                    ? `${profiler.batteryTemp}°C (${batteryHot ? 'Nóng' : 'Mát'})`
                    : 'Bảo mật ROM khóa'}
                </span>
              </div>

              <div className="p-2 rounded-lg bg-[#111A2E] border border-slate-800 flex items-center justify-between">
                <span className="text-slate-300">Tần số quét màn hình:</span>
                <span className="text-purple-300 font-mono font-semibold">
                  {profiler?.currentRefreshRate ? `${profiler.currentRefreshRate} Hz` : 'Tự thích ứng (LTPO)'}
                </span>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Gợi ý tính năng fix nên dùng với máy này */}
      <div className="p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-[11px] text-cyan-300 space-y-2">
        <div className="flex items-start space-x-2">
          <Smartphone className="w-3.5 h-3.5 text-[#00F0FF] shrink-0 mt-0.5" />
          <span className="leading-relaxed flex-1">{recommendedConfig.tip}</span>
        </div>
        {onSelectTab && (
          <div className="flex flex-wrap items-center gap-1.5 pt-1.5 border-t border-cyan-500/15">
            <span className="text-[10px] text-slate-400 font-medium">Chuyển nhanh:</span>
            <button
              onClick={() => onSelectTab(recommendedConfig.primaryTab)}
              className="px-2 py-0.5 rounded bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-200 border border-cyan-500/40 text-[10px] font-semibold flex items-center space-x-1 transition-all"
            >
              <span className="text-[#00F0FF] font-bold">[{recommendedConfig.primaryBadge}]</span>
              <span>{recommendedConfig.primaryLabel}</span>
            </button>
            <button
              onClick={() => onSelectTab(recommendedConfig.secondaryTab)}
              className="px-2 py-0.5 rounded bg-blue-500/20 hover:bg-blue-500/30 text-blue-200 border border-blue-500/40 text-[10px] font-semibold flex items-center space-x-1 transition-all"
            >
              <span className="text-blue-300 font-bold">[{recommendedConfig.secondaryBadge}]</span>
              <span>{recommendedConfig.secondaryLabel}</span>
            </button>
          </div>
        )}
      </div>

      {/* Nút Khởi Động Lại Điện Thoại (Reboot) */}
      <div className="pt-2 border-t border-slate-800/80 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2">
        <div className="text-[11px] text-slate-400 flex items-center space-x-1.5">
          <RotateCw className="w-3.5 h-3.5 text-purple-400 shrink-0" />
          <span>Khởi động lại điện thoại sau khi chạy kịch bản để đạt 100% hiệu quả.</span>
        </div>
        <button
          onClick={() => handleRebootDevice('normal')}
          disabled={!isConnected || isRebooting}
          className="px-3.5 py-1.5 rounded-xl bg-purple-500/20 hover:bg-purple-500/30 text-purple-200 border border-purple-500/40 text-xs font-bold flex items-center justify-center space-x-1.5 transition-all shadow-sm active:scale-95 disabled:opacity-40"
          title="Gửi lệnh khởi động lại máy qua ADB"
        >
          <RotateCw className={`w-3.5 h-3.5 ${isRebooting ? 'animate-spin' : ''}`} />
          <span>{isRebooting ? 'Đang khởi động...' : rebootDone ? '✓ Đã Gửi Lệnh Reboot!' : 'Khởi Động Lại Máy'}</span>
        </button>
      </div>
    </div>
  );
};

