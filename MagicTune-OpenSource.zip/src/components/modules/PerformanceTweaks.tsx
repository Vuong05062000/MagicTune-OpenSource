'use client';

import React, { useState, useEffect } from 'react';
import {
  Gamepad2,
  Tv,
  Maximize2,
  Zap,
  CheckCircle2,
  RotateCcw,
  Gauge
} from 'lucide-react';
import { HonorAdbScripts, DeviceProfiler } from '@/lib/adb/honor-scripts';
import { adbDriver } from '@/lib/adb/web-usb-driver';

interface PerformanceTweaksProps {
  isConnected: boolean;
  currentDensity?: number | null;
  currentRefreshRate?: number | null;
  profiler?: DeviceProfiler | null;
}

export const PerformanceTweaks: React.FC<PerformanceTweaksProps> = ({
  isConnected,
  currentDensity = null,
  currentRefreshRate = null,
  profiler = null
}) => {
  const isFoldable = Boolean(
    profiler?.model &&
    /fold|flip|magic v|mix fold|mix flip|x fold|x flip|find n|oneplus open|mate x|pocket/i.test(
      `${profiler?.marketName || ''} ${profiler?.model || ''}`
    )
  );
  const [selectedHz, setSelectedHz] = useState<60 | 90 | 120 | 144 | null>(
    currentRefreshRate && [60, 90, 120, 144].includes(currentRefreshRate)
      ? (currentRefreshRate as 60 | 90 | 120 | 144)
      : null
  );
  const [density, setDensity] = useState<number>(
    currentDensity && currentDensity >= 320 && currentDensity <= 640 ? currentDensity : 420
  );

  // Tự động đọc DPI thực tế từ thiết bị nếu chưa có
  useEffect(() => {
    if (isConnected) {
      if (!currentDensity) {
        adbDriver.executeCommand('wm density', { silent: true }).then((out) => {
          const match = out.match(/Physical density:\s*(\d+)/i) || out.match(/Override density:\s*(\d+)/i);
          if (match) {
            setDensity(parseInt(match[1], 10));
          }
        }).catch(() => {});
      } else {
        setDensity(currentDensity);
      }
      if (currentRefreshRate && [60, 90, 120, 144].includes(currentRefreshRate)) {
        setSelectedHz(currentRefreshRate as any);
      }
    }
  }, [isConnected, currentDensity, currentRefreshRate]);
  const [isGamingMode, setIsGamingMode] = useState(false);
  const [isApplying, setIsApplying] = useState(false);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);

  const notifySuccess = (msg: string) => {
    setActionSuccess(msg);
    setTimeout(() => setActionSuccess(null), 4000);
  };

  const handleApplyRefreshRate = async (hz: 60 | 90 | 120 | 144) => {
    if (!isConnected || isApplying) return;
    setIsApplying(true);
    setSelectedHz(hz);
    const cmds = HonorAdbScripts.getRefreshRateCommands(hz);
    const res = await adbDriver.executePipeline(cmds);
    setIsApplying(false);
    if (res.success) {
      notifySuccess(`Đã áp dụng và xác minh tần số quét ${hz}Hz!`);
    } else {
      notifySuccess(`Lỗi khi đặt tần số quét ${hz}Hz`);
    }
  };

  const handleResetRefreshRate = async () => {
    if (!isConnected || isApplying) return;
    setIsApplying(true);
    const cmds = HonorAdbScripts.getResetRefreshRateCommands();
    const res = await adbDriver.executePipeline(cmds);
    setIsApplying(false);
    if (res.success) {
      notifySuccess('Đã khôi phục tần số quét tự thích ứng (LTPO Tự động)');
    }
  };

  const handleApplyDpi = async () => {
    if (!isConnected || isApplying) return;
    if (density < 320 || density > 640) {
      if (typeof window !== 'undefined') {
        window.alert('⚠️ Cảnh báo an toàn: Mức DPI phải nằm trong khoảng 320 đến 640 để tránh lỗi hiển thị hoặc treo giao diện SystemUI.');
      }
      return;
    }
    setIsApplying(true);
    const cmd = HonorAdbScripts.getDpiDensityCommand(density);
    await adbDriver.executeCommand(cmd);
    // Xác minh lại thông số DPI thực tế sau khi đặt
    try {
      const densityCheck = await adbDriver.executeCommand('wm density');
      const match = densityCheck.match(/Override density:\s*(\d+)/i) || densityCheck.match(/Physical density:\s*(\d+)/i);
      const verifiedVal = match ? match[1] : `${density}`;
      notifySuccess(`Đã cập nhật & xác minh mật độ DPI: ${verifiedVal}`);
    } catch {
      notifySuccess(`Đã cập nhật mật độ điểm ảnh: ${density} DPI`);
    }
    setIsApplying(false);
  };

  const handleResetDpi = async () => {
    if (!isConnected || isApplying) return;
    setIsApplying(true);
    const cmd = HonorAdbScripts.getResetDpiCommand();
    await adbDriver.executeCommand(cmd);
    try {
      const checkOut = await adbDriver.executeCommand('wm density', { silent: true });
      const match = checkOut.match(/Physical density:\s*(\d+)/i);
      if (match) {
        const defaultVal = parseInt(match[1], 10);
        setDensity(defaultVal);
        notifySuccess(`Đã khôi phục DPI mặc định của nhà sản xuất (${defaultVal} DPI).`);
      } else {
        notifySuccess('Đã khôi phục DPI mặc định của hệ thống.');
      }
    } catch {
      notifySuccess('Đã gửi lệnh khôi phục DPI mặc định.');
    }
    setIsApplying(false);
  };

  const handleToggleGamingMode = async () => {
    if (!isConnected || isApplying) return;
    setIsApplying(true);
    const nextState = !isGamingMode;
    const cmds = HonorAdbScripts.getGamingModeCommands(nextState);
    const res = await adbDriver.executePipeline(cmds);
    setIsApplying(false);
    if (res.success) {
      setIsGamingMode(nextState);
      notifySuccess(
        nextState
          ? 'Đã bật Chế độ Hiệu Năng Cố Định (Fixed Performance Mode) để chơi game không bị bóp xung!'
          : 'Đã tắt Chế độ Hiệu Năng Chơi Game.'
      );
    } else {
      notifySuccess('Lỗi khi thiết lập Chế độ Hiệu Năng.');
    }
  };

  const handleSpeedupAnimation = async () => {
    if (!isConnected || isApplying) return;
    setIsApplying(true);
    const cmds = HonorAdbScripts.getSpeedupAnimationCommands();
    const res = await adbDriver.executePipeline(cmds);
    setIsApplying(false);
    if (res.success) {
      notifySuccess('Đã tăng tốc độ phản hồi chuyển cảnh lên 0.5x (Thao tác siêu mượt)!');
    } else {
      notifySuccess('Lỗi khi cấu hình tốc độ chuyển cảnh.');
    }
  };

  return (
    <div className="rounded-2xl border border-cyan-500/20 bg-[#111A2E]/90 backdrop-blur-xl p-6 shadow-xl relative overflow-hidden">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-cyan-500/15 gap-4">
        <div className="flex items-center space-x-2.5">
          <div className="p-2.5 rounded-xl bg-purple-500/10 border border-purple-500/30 text-purple-400">
            <Gauge className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white tracking-wide">
              Mở Khóa Tính Năng Ẩn &amp; Tối Ưu Hiệu Suất Màn Hình
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              {isFoldable
                ? 'Ép tần số quét cố định mọi tác vụ, tinh chỉnh mật độ DPI tối ưu cho tỉ lệ màn hình gập và mở khóa chế độ chơi game chuyên nghiệp'
                : 'Ép tần số quét cố định mọi tác vụ, tinh chỉnh mật độ DPI hiển thị sắc nét và mở khóa chế độ chơi game chuyên nghiệp'}
            </p>
          </div>
        </div>

        {actionSuccess && (
          <div className="px-3 py-1.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-semibold flex items-center space-x-1.5 animate-fadeIn">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{actionSuccess}</span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 my-5">
        {/* Ép tần số quét */}
        <div className="rounded-xl border border-cyan-500/15 bg-[#0A0F1D]/80 p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2 text-[#00F0FF] text-sm font-semibold">
                <Tv className="w-4 h-4" />
                <span>Ép Tần Số Quét Màn Hình</span>
              </div>
              <button
                onClick={handleResetRefreshRate}
                disabled={!isConnected || isApplying}
                className="text-[11px] text-slate-400 hover:text-white flex items-center space-x-1"
                title="Khôi phục tự động thích ứng"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Tự động</span>
              </button>
            </div>
            <p className="text-xs text-slate-400 mb-4 leading-relaxed">
              Xóa bỏ tình trạng tụt về 60Hz trên các ứng dụng như Facebook, YouTube, Google Maps bằng cách ghi đè thông số hệ thống.
            </p>
          </div>

          <div className="grid grid-cols-4 gap-1.5">
            {([60, 90, 120, 144] as const).map((hz) => (
              <button
                key={hz}
                onClick={() => handleApplyRefreshRate(hz)}
                disabled={!isConnected || isApplying}
                className={`py-2 rounded-xl text-xs font-bold transition-all border ${
                  selectedHz === hz
                    ? 'bg-[#00F0FF] text-black border-cyan-400 shadow-sm shadow-cyan-400/40'
                    : 'bg-slate-800/60 text-slate-300 border-slate-700 hover:border-slate-600'
                } disabled:opacity-40`}
              >
                {hz}Hz
              </button>
            ))}
          </div>
        </div>

        {/* Thanh trượt DPI */}
        <div className="rounded-xl border border-cyan-500/15 bg-[#0A0F1D]/80 p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2 text-purple-400 text-sm font-semibold">
                <Maximize2 className="w-4 h-4" />
                <span>Điều Chỉnh Mật Độ Điểm Ảnh (DPI)</span>
              </div>
              <button
                onClick={handleResetDpi}
                disabled={!isConnected || isApplying}
                className="text-[11px] text-slate-400 hover:text-white flex items-center space-x-1"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Mặc định</span>
              </button>
            </div>
            <p className="text-xs text-slate-400 mb-2 leading-relaxed">
              {isFoldable
                ? 'Hiển thị nhiều nội dung hơn, tối ưu không gian rộng rãi cho màn hình gập trong và ngoài.'
                : 'Cân chỉnh mật độ hiển thị DPI chuẩn xác giúp chữ viết, icon và bố cục giao diện hiển thị sắc nét, vừa vặn nhất.'}
            </p>
            <div className="flex items-center justify-between text-xs text-slate-300 font-mono mb-2">
              <span>Mật độ hiện tại:</span>
              <span className="font-bold text-purple-300">{density} DPI</span>
            </div>
            <input
              type="range"
              min="320"
              max="580"
              step="10"
              value={density}
              onChange={(e) => setDensity(Number(e.target.value))}
              className="w-full accent-purple-500 cursor-pointer"
            />
          </div>

          <button
            onClick={handleApplyDpi}
            disabled={!isConnected || isApplying}
            className="w-full mt-3 py-2 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 border border-purple-500/40 text-xs font-bold transition-all disabled:opacity-40"
          >
            Áp Dụng Mật Độ ({density} DPI)
          </button>
        </div>

        {/* Hiệu năng & Game */}
        <div className="rounded-xl border border-cyan-500/15 bg-[#0A0F1D]/80 p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center space-x-2 text-amber-400 text-sm font-semibold mb-2">
              <Gamepad2 className="w-4 h-4" />
              <span>Chế Độ Chơi Game &amp; Độ Mượt</span>
            </div>
            <p className="text-xs text-slate-400 mb-3 leading-relaxed">
              Kích hoạt chế độ phần cứng cố định để ngăn hệ điều hành tự động giảm xung nhịp khi máy ấm lên lúc đang chơi game.
            </p>
          </div>

          <div className="space-y-2">
            <button
              onClick={handleToggleGamingMode}
              disabled={!isConnected || isApplying}
              className={`w-full py-2 rounded-xl text-xs font-bold transition-all border flex items-center justify-center space-x-1.5 ${
                isGamingMode
                  ? 'bg-amber-500 text-black border-amber-400'
                  : 'bg-amber-500/10 text-amber-300 border-amber-500/30 hover:bg-amber-500/20'
              } disabled:opacity-40`}
            >
              <Zap className="w-3.5 h-3.5" />
              <span>{isGamingMode ? 'Tắt Chế Độ Game' : 'Bật Hiệu Năng Cố Định'}</span>
            </button>

            <button
              onClick={handleSpeedupAnimation}
              disabled={!isConnected || isApplying}
              className="w-full py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium border border-slate-700 transition-all disabled:opacity-40"
            >
              Tăng tốc chuyển cảnh giao diện 0.5x
            </button>
          </div>
        </div>
      </div>

      {/* TÍNH NĂNG NÂNG CẤP MỤC 3 & 7: TÙY CHỌN NHÀ PHÁT TRIỂN & MỞ KHÓA ÂM LƯỢNG */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-cyan-500/15">
        <div className="p-3.5 rounded-xl bg-[#0A0F1D] border border-cyan-500/15 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-cyan-300">Mở Khóa Giới Hạn Âm Lượng Nội Địa (Audio Limit Bypass)</span>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">Hi-Res</span>
          </div>
          <p className="text-[11px] text-slate-400">
            Gỡ bỏ mức trần âm lượng an toàn 85dB của máy nội địa, khuếch đại âm thanh tai nghe và loa Bluetooth to rõ hơn.
          </p>
          <button
            onClick={async () => {
              if (!isConnected || isApplying) return;
              setIsApplying(true);
              await adbDriver.executeCommand('settings put system volume_music_limit 0');
              await adbDriver.executeCommand('settings put system volume_music_headset_limit 0');
              setIsApplying(false);
              notifySuccess('Đã gỡ bỏ giới hạn âm lượng nội địa thành công!');
            }}
            disabled={!isConnected || isApplying}
            className="w-full py-1.5 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 text-[#00F0FF] border border-cyan-500/30 text-xs font-semibold transition-all disabled:opacity-40"
          >
            Mở Khóa Giới Hạn Âm Lượng Nhạc (Max Volume)
          </button>
        </div>

        <div className="p-3.5 rounded-xl bg-[#0A0F1D] border border-cyan-500/15 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-amber-300">Tùy Chọn Nhà Phát Triển Nhanh (Developer Options)</span>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-300 border border-amber-500/30">Quick Toggle</span>
          </div>
          <p className="text-[11px] text-slate-400">
            Bật tính năng hiển thị tần số quét Hz thực tế góc màn hình và giữ màn hình luôn thức khi đang cắm sạc.
          </p>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={async () => {
                if (!isConnected || isApplying) return;
                setIsApplying(true);
                await adbDriver.executeCommand('settings put system show_touches 1');
                await adbDriver.executeCommand('settings put system show_refresh_rate 1');
                setIsApplying(false);
                notifySuccess('Đã bật hiển thị Hz và điểm chạm màn hình!');
              }}
              disabled={!isConnected || isApplying}
              className="py-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[11px] font-semibold transition-all disabled:opacity-40"
            >
              Hiện FPS/Hz Màn Hình
            </button>
            <button
              onClick={async () => {
                if (!isConnected || isApplying) return;
                setIsApplying(true);
                await adbDriver.executeCommand('settings put global stay_on_while_plugged_in 7');
                setIsApplying(false);
                notifySuccess('Đã bật tính năng Không Khóa Màn Hình Khi Sạc!');
              }}
              disabled={!isConnected || isApplying}
              className="py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-[11px] font-semibold transition-all disabled:opacity-40"
            >
              Màn Hình Luôn Sáng Khi Sạc
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
