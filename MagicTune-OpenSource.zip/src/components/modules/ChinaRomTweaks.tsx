'use client';

import React, { useState } from 'react';
import {
  Sparkles,
  MapPin,
  EyeOff,
  MicOff,
  ShieldCheck,
  Type,
  Ban,
  CheckCircle2,
  Zap,
  Globe2,
  Home,
  PhoneCall,
  WifiHigh,
  Cpu,
  Lock,
  Info
} from 'lucide-react';
import { HonorAdbScripts } from '@/lib/adb/honor-scripts';
import { adbDriver } from '@/lib/adb/web-usb-driver';
import { recordUserActivity } from '@/lib/firebase/config';

interface ChinaRomTweaksProps {
  isConnected: boolean;
  isChinaRom?: boolean;
}

export const ChinaRomTweaks: React.FC<ChinaRomTweaksProps> = ({
  isConnected,
  isChinaRom = true
}) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const notify = (msg: string) => {
    setSuccessMessage(msg);
    setTimeout(() => setSuccessMessage(null), 4500);
  };

  const handleFixGps = async () => {
    if (!isConnected || isProcessing) return;
    setIsProcessing(true);
    const cmds = HonorAdbScripts.getFixChinaGpsCommands();
    const res = await adbDriver.executePipeline(cmds);
    let verifiedNtp = '';
    try {
      verifiedNtp = await adbDriver.executeCommand('settings get global ntp_server');
    } catch (e) {}
    setIsProcessing(false);
    if (res.success) {
      recordUserActivity('Sửa lỗi GPS bản nội địa', 'NTP Google time.google.com');
      notify(`Đã chuyển máy chủ NTP sang time.google.com${verifiedNtp.trim() ? ` (Xác minh: ${verifiedNtp.trim()})` : ''}! Định vị GPS và ứng dụng gọi xe sẽ nhận sóng nhanh hơn.`);
    } else {
      notify(`Đã chạy cấu hình GPS (${cmds.length - res.errors.length}/${cmds.length} thành công). Xem log Terminal.`);
    }
  };

  const handleDisableHiBoard = async () => {
    if (!isConnected || isProcessing) return;
    setIsProcessing(true);
    const cmds = HonorAdbScripts.getDisableHiBoardCommands();
    const res = await adbDriver.executePipeline(cmds);
    setIsProcessing(false);
    if (res.success) {
      recordUserActivity('Tắt màn hình HiBoard', 'Disable com.hihonor.hiboard');
      notify('Đã tắt màn hình tin tức nội địa HiBoard thành công!');
    } else {
      notify('Không thể tắt HiBoard. Hãy kiểm tra kết nối thiết bị.');
    }
  };

  const handleDisableYoyo = async () => {
    if (!isConnected || isProcessing) return;
    setIsProcessing(true);
    const cmds = HonorAdbScripts.getDisableYoyoQuickSearchCommands();
    const res = await adbDriver.executePipeline(cmds);
    setIsProcessing(false);
    if (res.success) {
      recordUserActivity('Đóng băng trợ lý YOYO', 'Disable YOYO & AI Search');
      notify('Đã tắt trợ lý ảo giọng nói tiếng Trung YOYO và AI QuickSearch, giúp tiết kiệm pin đáng kể!');
    } else {
      notify('Lỗi khi tắt YOYO & AI QuickSearch. Xem log Terminal.');
    }
  };

  const handleBypassSecurity = async () => {
    if (!isConnected || isProcessing) return;
    setIsProcessing(true);
    const cmds = HonorAdbScripts.getBypassInstallVerificationCommands();
    const res = await adbDriver.executePipeline(cmds);
    setIsProcessing(false);
    if (res.success) {
      recordUserActivity('Bỏ qua quét an ninh APK', 'Bypass verify non-market apps');
      notify('Đã tắt quét an ninh nội địa khi cài tệp APK từ bên ngoài!');
    } else {
      notify('Lỗi khi cấu hình bỏ qua quét an ninh.');
    }
  };

  const handleFixFont = async () => {
    if (!isConnected || isProcessing) return;
    setIsProcessing(true);
    const cmds = HonorAdbScripts.getFixVietnameseFontRenderingCommands();
    const res = await adbDriver.executePipeline(cmds);
    setIsProcessing(false);
    if (res.success) {
      recordUserActivity('Cân chỉnh Font chữ tiếng Việt', 'Optimize Unicode font scale');
      notify('Đã cân chỉnh tỷ lệ hiển thị font chữ tiếng Việt chuẩn xác!');
    } else {
      notify('Lỗi khi cân chỉnh font tiếng Việt.');
    }
  };

  const handleBlockTelemetry = async () => {
    if (!isConnected || isProcessing) return;
    setIsProcessing(true);
    const cmds = HonorAdbScripts.getBlockChinaTelemetryCommands();
    const res = await adbDriver.executePipeline(cmds);
    setIsProcessing(false);
    if (res.success) {
      recordUserActivity('Chặn quảng cáo nội địa', 'Disable ads & telemetry');
      notify('Đã chặn thành công dịch vụ quảng cáo và gửi log ngầm về máy chủ nội địa!');
    } else {
      notify('Lỗi khi chặn telemetry nội địa.');
    }
  };

  const handleUnlockLauncher = async () => {
    if (!isConnected || isProcessing) return;
    setIsProcessing(true);
    const cmds = HonorAdbScripts.getUnlockThirdPartyLauncherCommands();
    const res = await adbDriver.executePipeline(cmds);
    setIsProcessing(false);
    if (res.success) {
      recordUserActivity('Mở khóa Launcher bên thứ 3', 'Unlock third-party default home');
      notify('Đã mở khóa quyền chọn Launcher bên thứ ba (Nova, Lawnchair, Smart Launcher)!');
    } else {
      notify('Lỗi khi mở khóa Launcher bên thứ ba.');
    }
  };

  const handleFixSimPrefix = async () => {
    if (!isConnected || isProcessing) return;
    setIsProcessing(true);
    const cmds = HonorAdbScripts.getFixVietnameseSimPrefixCommands();
    const res = await adbDriver.executePipeline(cmds);
    setIsProcessing(false);
    if (res.success) {
      recordUserActivity('Sửa lỗi SIM +84 và Danh bạ', 'Country VN & Mobile data always on');
      notify('Đã tối ưu mã vùng SIM Việt Nam (+84) giúp hiển thị tên người gọi và tin nhắn ngân hàng chuẩn xác!');
    } else {
      notify('Lỗi khi cấu hình mã vùng SIM.');
    }
  };

  const handleKeepNetworkAlive = async () => {
    if (!isConnected || isProcessing) return;
    setIsProcessing(true);
    const cmds = HonorAdbScripts.getKeepNetworkAliveOnScreenOffCommands();
    const res = await adbDriver.executePipeline(cmds);
    setIsProcessing(false);
    if (res.success) {
      recordUserActivity('Giữ kết nối mạng khi tắt màn hình', 'Keep Wi-Fi & 4G awake');
      notify('Đã cấu hình Wi-Fi và 4G luôn thức khi tắt màn hình, không bị ngắt kết nối cuộc gọi Zalo/Telegram!');
    } else {
      notify('Lỗi khi cấu hình giữ mạng.');
    }
  };

  const [showLockscreenGuide, setShowLockscreenGuide] = useState(false);

  const handleKeepLockscreenNotifications = async () => {
    if (!isConnected || isProcessing) return;
    setIsProcessing(true);
    const cmds = HonorAdbScripts.getKeepLockscreenNotificationCommands();
    const res = await adbDriver.executePipeline(cmds, undefined, {
      title: 'Giữ Thông Báo Màn Khóa & Bật Lịch Sử 24h'
    });
    setIsProcessing(false);
    if (res.success) {
      recordUserActivity('Giữ thông báo Lockscreen & Lịch sử 24h', 'Lockscreen keep & notification history');
      notify('Đã cấu hình giữ thông báo trên màn hình khóa và kích hoạt Lịch sử thông báo 24 giờ thành công!');
      setShowLockscreenGuide(true);
    } else {
      notify(`Đã nạp cấu hình màn hình khóa với ${res.errors.length} cảnh báo. Xem log Terminal.`);
    }
  };

  const handleSuperChinaFix = async () => {
    if (!isConnected || isProcessing) return;
    setIsProcessing(true);
    const allCmds = [
      ...HonorAdbScripts.getFixChinaGpsCommands(),
      ...HonorAdbScripts.getDisableHiBoardCommands(),
      ...HonorAdbScripts.getDisableYoyoQuickSearchCommands(),
      ...HonorAdbScripts.getBypassInstallVerificationCommands(),
      ...HonorAdbScripts.getBlockChinaTelemetryCommands(),
      ...HonorAdbScripts.getFixVietnameseSimPrefixCommands(),
      ...HonorAdbScripts.getKeepNetworkAliveOnScreenOffCommands(),
      ...HonorAdbScripts.getUnlockThirdPartyLauncherCommands(),
      ...HonorAdbScripts.getKeepLockscreenNotificationCommands()
    ];
    const res = await adbDriver.executePipeline(allCmds, undefined, { title: '1-Chạm Tối Ưu Toàn Diện Máy Nội Địa' });
    setIsProcessing(false);
    if (res.success) {
      recordUserActivity('1-Chạm Tối Ưu Toàn Diện Máy Nội Địa (11 Hạng Mục Cực Mạnh)');
      notify('Tuyệt vời! Đã hoàn tất toàn bộ 11 hạng mục tối ưu đặc thù cho máy Honor nội địa tại Việt Nam.');
    } else {
      notify(`Đã hoàn tất tối ưu với ${res.errors.length} cảnh báo. Xem chi tiết trong Terminal.`);
    }
  };

  return (
    <div className="rounded-2xl border border-cyan-500/20 bg-[#111A2E]/90 backdrop-blur-xl p-6 shadow-xl relative overflow-hidden">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-cyan-500/15 gap-4">
        <div className="flex items-center space-x-2.5">
          <div className="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-[#00F0FF]">
            <Globe2 className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h3 className="text-lg font-bold text-white tracking-wide">
                Gói Tinh Chỉnh Đầy Đủ Cho Máy Xách Tay Nội Địa (China ROM)
              </h3>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 font-semibold">
                Chuẩn Hóa 11 Hạng Mục
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Giải quyết triệt để GPS, SIM +84, mở khóa Launcher, giữ thông báo Màn hình khóa 24h, giữ mạng Wi-Fi/4G và chặn quảng cáo ngầm
            </p>
          </div>
        </div>

        <button
          onClick={handleSuperChinaFix}
          disabled={!isConnected || isProcessing}
          className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#00F0FF] via-cyan-400 to-blue-600 hover:from-cyan-300 hover:to-blue-500 text-black font-extrabold text-xs flex items-center space-x-2 transition-all shadow-lg shadow-cyan-500/25 disabled:opacity-40 hover:scale-[1.02] active:scale-[0.98]"
        >
          <Zap className="w-4 h-4 fill-black" />
          <span>1-Chạm Tối Ưu Toàn Diện Máy Nội Địa (11 Hạng Mục)</span>
        </button>
      </div>

      {successMessage && (
        <div className="my-4 px-4 py-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-semibold flex items-center space-x-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* Khối Bí Kíp 2 Cần Gạt Để Không Bao Giờ Mất Thông Báo Màn Khóa */}
      {showLockscreenGuide && (
        <div className="my-4 p-4 rounded-xl bg-gradient-to-r from-amber-950/40 via-orange-950/30 to-[#0A0F1D] border border-amber-500/40 text-xs space-y-3 animate-in fade-in">
          <div className="flex items-center justify-between border-b border-amber-500/20 pb-2">
            <div className="font-bold text-amber-300 flex items-center space-x-2">
              <span className="text-base">📌</span>
              <span>BÍ KÍP 2 BƯỚC CÀI ĐẶT TRÊN MÁY (ĐỂ THÔNG BÁO Ở LẠI MÀN HÌNH KHÓA VĨNH VIỄN):</span>
            </div>
            <button
              onClick={() => setShowLockscreenGuide(false)}
              className="text-slate-400 hover:text-white text-xs px-2 py-0.5 rounded bg-slate-800"
            >
              ✕ Đóng
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="p-3 rounded-xl bg-[#0A0F1D]/80 border border-amber-500/20 space-y-1">
              <div className="font-bold text-white flex items-center space-x-1.5">
                <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-300 flex items-center justify-center text-[10px] font-mono">1</span>
                <span>Chỉnh Mở Khóa Gương Mặt (Quan Trọng Nhất)</span>
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                Vào <strong>Cài đặt ➔ Sinh trắc học &amp; Mật khẩu ➔ Nhận diện khuôn mặt</strong>. Tại mục <em>Mở khóa thiết bị</em>, chuyển sang <strong>&quot;Trượt để mở khóa&quot;</strong> (Slide to unlock) thay vì Mở khóa trực tiếp.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-[#0A0F1D]/80 border border-amber-500/20 space-y-1">
              <div className="font-bold text-white flex items-center space-x-1.5">
                <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-300 flex items-center justify-center text-[10px] font-mono">2</span>
                <span>Tắt Ẩn Thông Báo Thông Minh</span>
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                Cũng trong menu <em>Nhận diện khuôn mặt</em>, hãy <strong>TẮT</strong> mục <strong>&quot;Thông báo màn hình khóa thông minh&quot;</strong>. Thông báo sẽ luôn nằm nguyên trên màn hình khóa.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-[#0A0F1D]/80 border border-amber-500/20 space-y-1">
              <div className="font-bold text-white flex items-center space-x-1.5">
                <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-300 flex items-center justify-center text-[10px] font-mono">3</span>
                <span>Xem Lại Lịch Sử Thông Báo 24 Giờ</span>
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                Vào <strong>Cài đặt ➔ Thông báo ➔ Lịch sử thông báo</strong>. Toàn bộ tin nhắn/thông báo trong 24 giờ qua đều được lưu lại, đọc được cả tin nhắn bị gạt mất hoặc người gửi đã thu hồi!
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Grid 11 Tính năng chuyên sâu */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 my-5">
        {/* 1. Sửa GPS */}
        <div className="p-4 rounded-xl bg-[#0A0F1D]/80 border border-cyan-500/15 flex flex-col justify-between">
          <div>
            <div className="flex items-center space-x-2 text-[#00F0FF] font-semibold text-xs mb-1.5">
              <MapPin className="w-4 h-4" />
              <span>1. Sửa Lỗi Sóng GPS / Grab / Google Maps</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed mb-3">
              Chuyển máy chủ thời gian NTP nội địa sang Google Time, giúp định vị bắt vệ tinh GPS chuẩn xác trong 1 giây.
            </p>
          </div>
          <button
            onClick={handleFixGps}
            disabled={!isConnected || isProcessing}
            className="w-full py-2 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 text-[#00F0FF] border border-cyan-500/30 text-xs font-semibold transition-all disabled:opacity-40"
          >
            Sửa Lỗi Bắt Vị Trí GPS
          </button>
        </div>

        {/* 2. Mở khóa Launcher bên thứ 3 */}
        <div className="p-4 rounded-xl bg-[#0A0F1D]/80 border border-cyan-500/15 flex flex-col justify-between">
          <div>
            <div className="flex items-center space-x-2 text-purple-400 font-semibold text-xs mb-1.5">
              <Home className="w-4 h-4" />
              <span>2. Mở Khóa Đổi Launcher Mặc Định</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed mb-3">
              Phá vỡ giới hạn khóa của MagicOS nội địa, cho phép bạn đặt Nova Launcher, Lawnchair làm màn hình chính.
            </p>
          </div>
          <button
            onClick={handleUnlockLauncher}
            disabled={!isConnected || isProcessing}
            className="w-full py-2 rounded-lg bg-purple-500/10 hover:bg-purple-500/20 text-purple-300 border border-purple-500/30 text-xs font-semibold transition-all disabled:opacity-40"
          >
            Mở Khóa Đổi Launcher
          </button>
        </div>

        {/* 3. Sửa lỗi mã vùng SIM +84 và Danh bạ */}
        <div className="p-4 rounded-xl bg-[#0A0F1D]/80 border border-cyan-500/15 flex flex-col justify-between">
          <div>
            <div className="flex items-center space-x-2 text-emerald-400 font-semibold text-xs mb-1.5">
              <PhoneCall className="w-4 h-4" />
              <span>3. Chuẩn Hóa Mã Vùng SIM (+84) &amp; Danh Bạ</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed mb-3">
              Sửa lỗi tin nhắn ngân hàng (SMS OTP) và cuộc gọi đến không hiển thị tên người gọi do lệch đầu số +84/0.
            </p>
          </div>
          <button
            onClick={handleFixSimPrefix}
            disabled={!isConnected || isProcessing}
            className="w-full py-2 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-semibold transition-all disabled:opacity-40"
          >
            Chuẩn Hóa SIM Việt Nam
          </button>
        </div>

        {/* 4. Giữ Wi-Fi & 4G luôn thức khi tắt màn hình */}
        <div className="p-4 rounded-xl bg-[#0A0F1D]/80 border border-cyan-500/15 flex flex-col justify-between">
          <div>
            <div className="flex items-center space-x-2 text-cyan-300 font-semibold text-xs mb-1.5">
              <WifiHigh className="w-4 h-4" />
              <span>4. Giữ Mạng Wi-Fi / 4G Luôn Thức</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed mb-3">
              Ngăn hệ điều hành ngắt kết nối mạng khi tắt màn hình lâu, đảm bảo cuộc gọi Zalo/Telegram đổ chuông tức thì.
            </p>
          </div>
          <button
            onClick={handleKeepNetworkAlive}
            disabled={!isConnected || isProcessing}
            className="w-full py-2 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-xs font-semibold transition-all disabled:opacity-40"
          >
            Giữ Mạng Không Bị Ngắt
          </button>
        </div>

        {/* 5. Tắt HiBoard */}
        <div className="p-4 rounded-xl bg-[#0A0F1D]/80 border border-cyan-500/15 flex flex-col justify-between">
          <div>
            <div className="flex items-center space-x-2 text-purple-400 font-semibold text-xs mb-1.5">
              <EyeOff className="w-4 h-4" />
              <span>5. Tắt Màn Hình Tin Tức HiBoard</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed mb-3">
              Loại bỏ trang tin tức tiếng Trung cực trái màn hình chính, chống giật khung hình và ngăn quảng cáo ngầm.
            </p>
          </div>
          <button
            onClick={handleDisableHiBoard}
            disabled={!isConnected || isProcessing}
            className="w-full py-2 rounded-lg bg-purple-500/10 hover:bg-purple-500/20 text-purple-300 border border-purple-500/30 text-xs font-semibold transition-all disabled:opacity-40"
          >
            Tắt Màn Hình HiBoard
          </button>
        </div>

        {/* 6. Tắt YOYO Assistant */}
        <div className="p-4 rounded-xl bg-[#0A0F1D]/80 border border-cyan-500/15 flex flex-col justify-between">
          <div>
            <div className="flex items-center space-x-2 text-amber-400 font-semibold text-xs mb-1.5">
              <MicOff className="w-4 h-4" />
              <span>6. Tắt Trợ Lý Tiếng Trung YOYO</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed mb-3">
              Đóng băng dịch vụ lắng nghe micro ngầm và tìm kiếm nội địa gây tiêu tốn từ 8% đến 12% dung lượng pin mỗi ngày.
            </p>
          </div>
          <button
            onClick={handleDisableYoyo}
            disabled={!isConnected || isProcessing}
            className="w-full py-2 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-semibold transition-all disabled:opacity-40"
          >
            Đóng Băng Trợ Lý YOYO
          </button>
        </div>

        {/* 7. Bỏ qua quét an ninh APK */}
        <div className="p-4 rounded-xl bg-[#0A0F1D]/80 border border-cyan-500/15 flex flex-col justify-between">
          <div>
            <div className="flex items-center space-x-2 text-emerald-400 font-semibold text-xs mb-1.5">
              <ShieldCheck className="w-4 h-4" />
              <span>7. Bỏ Qua Quét Cảnh Báo Khi Cài APK</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed mb-3">
              Tắt màn hình chờ đếm ngược và cảnh báo bảo mật khi bạn cài file APK từ trình duyệt hoặc Zalo.
            </p>
          </div>
          <button
            onClick={handleBypassSecurity}
            disabled={!isConnected || isProcessing}
            className="w-full py-2 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-semibold transition-all disabled:opacity-40"
          >
            Tắt Cảnh Báo Nguồn Ngoài
          </button>
        </div>

        {/* 8. Chuẩn hóa font chữ */}
        <div className="p-4 rounded-xl bg-[#0A0F1D]/80 border border-cyan-500/15 flex flex-col justify-between">
          <div>
            <div className="flex items-center space-x-2 text-cyan-300 font-semibold text-xs mb-1.5">
              <Type className="w-4 h-4" />
              <span>8. Chuẩn Hóa Font Chữ Tiếng Việt</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed mb-3">
              Cân chỉnh tỷ lệ cỡ chữ hệ thống 1.0x giúp hạn chế hiện tượng chữ đậm chữ nhạt hoặc lỗi ngắt dòng.
            </p>
          </div>
          <button
            onClick={handleFixFont}
            disabled={!isConnected || isProcessing}
            className="w-full py-2 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-xs font-semibold transition-all disabled:opacity-40"
          >
            Cân Chỉnh Font Chữ Chuẩn
          </button>
        </div>

        {/* 9. Chặn quảng cáo nội địa */}
        <div className="p-4 rounded-xl bg-[#0A0F1D]/80 border border-cyan-500/15 flex flex-col justify-between">
          <div>
            <div className="flex items-center space-x-2 text-rose-400 font-semibold text-xs mb-1.5">
              <Ban className="w-4 h-4" />
              <span>9. Chặn Quảng Cáo &amp; Nhật Ký Ngầm</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed mb-3">
              Đóng băng các dịch vụ phân phát banner quảng cáo và gửi log ngầm về máy chủ nước ngoài.
            </p>
          </div>
          <button
            onClick={handleBlockTelemetry}
            disabled={!isConnected || isProcessing}
            className="w-full py-2 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 text-xs font-semibold transition-all disabled:opacity-40"
          >
            Chặn Thu Thập Log &amp; Banner
          </button>
        </div>

        {/* 10. Giữ Thông Báo Màn Hình Khóa & Lịch Sử 24h */}
        <div className="p-4 rounded-xl bg-[#0A0F1D]/80 border border-amber-500/30 flex flex-col justify-between shadow-lg shadow-amber-950/20">
          <div>
            <div className="flex items-center space-x-2 text-amber-300 font-semibold text-xs mb-1.5">
              <Lock className="w-4 h-4 text-amber-400" />
              <span>10. Giữ Thông Báo Màn Khóa &amp; Lịch Sử 24h</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed mb-3">
              Đặc trị hiện tượng thông báo biến mất khỏi Màn hình khóa sau khi mở khóa. Bật Lịch sử thông báo 24 giờ của Android.
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={handleKeepLockscreenNotifications}
              disabled={!isConnected || isProcessing}
              className="flex-1 py-2 rounded-lg bg-gradient-to-r from-amber-500/20 to-orange-500/20 hover:from-amber-500/30 hover:to-orange-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold transition-all disabled:opacity-40"
            >
              Kích Hoạt Ngay
            </button>
            <button
              onClick={() => setShowLockscreenGuide(!showLockscreenGuide)}
              className="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 text-xs font-bold transition-all"
              title="Xem 2 bước cài đặt Face Unlock trên điện thoại"
            >
              {showLockscreenGuide ? 'Ẩn' : 'Bí kíp'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
