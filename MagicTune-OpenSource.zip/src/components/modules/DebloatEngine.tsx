'use client';

import React, { useState } from 'react';
import {
  Trash2,
  RotateCcw,
  ShieldCheck,
  Lock,
  Search,
  Filter,
  Scan,
  CheckCircle2
} from 'lucide-react';
import debloatData from '@/data/debloat-packages.json';
import { HonorAdbScripts } from '@/lib/adb/honor-scripts';
import { adbDriver } from '@/lib/adb/web-usb-driver';
import { Pagination } from '@/components/common/Pagination';
import { deviceDataCache } from '@/lib/cache/device-data-cache';

interface DebloatEngineProps {
  isConnected: boolean;
}

const CORE_UNREMOVABLE_SYSTEM_PACKAGES = new Set([
  'android',
  'com.android.systemui',
  'com.hihonor.systemui',
  'com.android.settings',
  'com.hihonor.security',
  'com.android.phone',
  'com.android.server.telecom',
  'com.hihonor.android.launcher',
  'com.huawei.android.launcher',
  'com.miui.home',
  'com.sec.android.app.launcher',
  'com.oppo.launcher',
  'com.vivo.launcher',
  'com.hihonor.camera',
  'com.hihonor.awareness',
  'com.hihonor.trustagent',
  'com.hihonor.smartcharge',
  'com.hihonor.systemmanager',
  'com.google.android.gms',
  'com.google.android.gsf',
  'com.android.vending',
  'com.android.providers.telephony',
  'com.android.providers.settings',
  'com.android.bluetooth',
  'com.android.nfc',
  'com.android.keyguard'
]);

export const DebloatEngine: React.FC<DebloatEngineProps> = ({ isConnected }) => {
  const initialCache = deviceDataCache.getDebloatData();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterLevel, setFilterLevel] = useState<'all' | 'safe' | 'advanced'>('all');
  const [selectedPackages, setSelectedPackages] = useState<string[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [scanStatusText, setScanStatusText] = useState<string | null>(null);
  const [scanProgress, setScanProgress] = useState<number>(0);
  const [lastScannedTime, setLastScannedTime] = useState<string | null>(
    initialCache?.lastScannedTime || null
  );
  const isScanningRef = React.useRef(false);
  const hasAutoScannedRef = React.useRef(deviceDataCache.hasDebloatData());

  const [installedPackagesOnDevice, setInstalledPackagesOnDevice] = useState<string[]>(
    initialCache?.installedPackages || []
  );
  const [uninstalledPackages, setUninstalledPackages] = useState<string[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 12;

  // Khởi tạo danh sách uninstalled packages từ localStorage
  React.useEffect(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('magictune_uninstalled_pkgs');
      if (saved) {
        try {
          setUninstalledPackages(JSON.parse(saved));
        } catch (e) {}
      }
    }
  }, []);

  const saveUninstalledToStorage = (pkgs: string[]) => {
    setUninstalledPackages(pkgs);
    if (typeof window !== 'undefined') {
      localStorage.setItem('magictune_uninstalled_pkgs', JSON.stringify(pkgs));
    }
  };

  const scanRealPackages = React.useCallback(async () => {
    if (!isConnected || isScanningRef.current) return;
    isScanningRef.current = true;
    setIsScanning(true);
    setScanProgress(20);
    setScanStatusText('Đang kết nối WebADB và quét danh sách gói ứng dụng (--user 0)...');

    try {
      setScanProgress(55);
      const output = await adbDriver.executeCommand('pm list packages --user 0', { silent: true });
      
      setScanProgress(80);
      setScanStatusText('Đang phân tích và đối soát từ điển ứng dụng rác...');

      const lines = output.split('\n');
      const pkgs: string[] = [];
      lines.forEach((l) => {
        const clean = l.replace('package:', '').trim();
        if (clean && !clean.startsWith('#')) pkgs.push(clean);
      });
      setInstalledPackagesOnDevice(pkgs);

      const nowTime = new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      setLastScannedTime(nowTime);
      setScanProgress(100);
      setScanStatusText(`Đã quét xong: Tìm thấy ${pkgs.length} gói hệ thống lúc ${nowTime}`);

      // Lưu vào cache để không bị quét lại khi chuyển Tab
      deviceDataCache.setDebloatData({
        installedPackages: pkgs,
        lastScannedTime: nowTime
      });
    } catch (e: any) {
      console.error('Scan packages error', e);
      setScanStatusText(`Lỗi quét: ${e?.message || 'Không thể đọc gói'}`);
    } finally {
      setIsScanning(false);
      isScanningRef.current = false;
      setTimeout(() => {
        setScanProgress(0);
      }, 5000);
    }
  }, [isConnected]);

  // Tự động quét các gói thực tế một lần duy nhất khi kết nối cáp; nếu có cache thì giữ nguyên không quét lại
  React.useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isConnected) {
      if (deviceDataCache.hasDebloatData()) {
        const cached = deviceDataCache.getDebloatData()!;
        setInstalledPackagesOnDevice(cached.installedPackages);
        setLastScannedTime(cached.lastScannedTime);
        hasAutoScannedRef.current = true;
        return;
      }

      if (!hasAutoScannedRef.current) {
        hasAutoScannedRef.current = true;
        timer = setTimeout(() => {
          scanRealPackages();
        }, 500);
      }
    } else {
      hasAutoScannedRef.current = false;
      deviceDataCache.clearAll();
      setInstalledPackagesOnDevice([]);
      setSelectedPackages([]);
      setLastScannedTime(null);
    }
    return () => clearTimeout(timer);
  }, [isConnected, scanRealPackages]);

  // Hiển thị danh mục ứng dụng tối ưu: Chỉ hiển thị các app có khả năng gỡ bỏ an toàn, loại trừ tuyệt đối app cốt lõi
  const availablePackages = React.useMemo(() => {
    const safeBaseList = debloatData.filter(
      (item) => (item as any).level !== 'danger' && !CORE_UNREMOVABLE_SYSTEM_PACKAGES.has(item.package)
    );

    if (!isConnected || installedPackagesOnDevice.length === 0) {
      return safeBaseList;
    }

    const matchedKnown = safeBaseList.filter((item) => installedPackagesOnDevice.includes(item.package));
    const knownPkgSet = new Set(safeBaseList.map((d) => d.package));
    
    // Tạo danh mục an toàn bổ sung cho các ứng dụng thực tế trên thiết bị chưa có trong từ điển
    const additionalDevicePkgs = installedPackagesOnDevice
      .filter((pkg) => 
        !knownPkgSet.has(pkg) &&
        !CORE_UNREMOVABLE_SYSTEM_PACKAGES.has(pkg) &&
        !pkg.startsWith('com.android.internal') &&
        !pkg.startsWith('com.android.providers.') &&
        !pkg.includes('systemui') &&
        !pkg.includes('launcher') &&
        !pkg.includes('telecom') &&
        !pkg.includes('phone') &&
        !pkg.includes('settings') &&
        !pkg.includes('camera')
      )
      .map((pkg) => {
        const parts = pkg.split('.');
        const simpleName = parts[parts.length - 1] || pkg;
        const formattedName = simpleName.charAt(0).toUpperCase() + simpleName.slice(1);
        return {
          name: formattedName,
          package: pkg,
          category: 'Ứng dụng trên thiết bị',
          level: 'safe' as const,
          description: `Gói ứng dụng tìm thấy thực tế trên thiết bị (${pkg})`,
          recommendation: 'Có thể gỡ bỏ an toàn nếu bạn không có nhu cầu sử dụng ứng dụng này.'
        };
      });

    return [...matchedKnown, ...additionalDevicePkgs];
  }, [isConnected, installedPackagesOnDevice]);

  const filteredList = availablePackages.filter((item) => {
    const matchQuery =
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.package.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.category.toLowerCase().includes(searchTerm.toLowerCase());

    if (filterLevel === 'all') return matchQuery;
    return matchQuery && item.level === filterLevel;
  });

  const toggleSelect = (pkg: string) => {
    setSelectedPackages((prev) =>
      prev.includes(pkg) ? prev.filter((p) => p !== pkg) : [...prev, pkg]
    );
  };

  const handleSelectAllSafe = () => {
    const safePackages = availablePackages
      .filter((item) => item.level === 'safe')
      .map((item) => item.package);
    setSelectedPackages(safePackages);
  };

  const [uninstallNotice, setUninstallNotice] = useState<string | null>(null);

  const handleUninstallSingle = async (pkg: string) => {
    if (!isConnected || isProcessing) return;
    setIsProcessing(true);
    const cmds = HonorAdbScripts.buildDebloatDeepRemovePipeline(pkg);
    const res = await adbDriver.executePipeline(cmds, undefined, { title: `Gỡ Ứng Dụng: ${pkg}` });
    if (res.success) {
      // Làm mới launcher tức thì để icon biến mất ngay lập tức trên màn hình chính
      try {
        await adbDriver.executeCommand(
          'am force-stop com.hihonor.android.launcher 2>/dev/null || ' +
          'am force-stop com.huawei.android.launcher 2>/dev/null || ' +
          'am force-stop com.miui.home 2>/dev/null || ' +
          'am force-stop com.sec.android.app.launcher 2>/dev/null || ' +
          'am force-stop com.oppo.launcher 2>/dev/null || ' +
          'am force-stop com.vivo.launcher 2>/dev/null || true',
          { silent: true }
        );
      } catch (e) {}

      // Xác minh thực tế: Kiểm tra xem gói còn tồn tại trên user 0 không
      let verifiedGone = true;
      try {
        const verifyOut = await adbDriver.executeCommand('pm list packages --user 0', { silent: true });
        const stillInList = verifyOut.split('\n').some((l) => l.replace('package:', '').trim() === pkg);
        verifiedGone = !stillInList;
      } catch (e) {}

      const updated = [...new Set([...uninstalledPackages, pkg])];
      saveUninstalledToStorage(updated);
      if (verifiedGone) {
        setUninstallNotice(`Đã gỡ bỏ thành công gói ${pkg}! Icon đã biến mất ngay lập tức khỏi màn hình chính (Không cần khởi động lại máy).`);
      } else {
        setUninstallNotice(`Gói ${pkg} đã đóng băng và tắt hoàn toàn tiến trình ngầm tức thì.`);
      }
      await scanRealPackages();
    } else {
      setUninstallNotice(`Gỡ gói ${pkg} có ${res.errors.length} cảnh báo. Xem log trong Terminal.`);
    }
    setIsProcessing(false);
    setTimeout(() => setUninstallNotice(null), 8000);
  };

  const handleRestoreSingle = async (pkg: string) => {
    if (!isConnected || isProcessing) return;
    setIsProcessing(true);
    const cmd = HonorAdbScripts.buildDebloatRestoreCommand(pkg);
    try {
      await adbDriver.executeCommand(cmd);
      // Làm mới launcher khi khôi phục
      try {
        await adbDriver.executeCommand(
          'am force-stop com.hihonor.android.launcher 2>/dev/null || ' +
          'am force-stop com.huawei.android.launcher 2>/dev/null || ' +
          'am force-stop com.miui.home 2>/dev/null || ' +
          'am force-stop com.sec.android.app.launcher 2>/dev/null || ' +
          'am force-stop com.oppo.launcher 2>/dev/null || ' +
          'am force-stop com.vivo.launcher 2>/dev/null || true',
          { silent: true }
        );
      } catch (e) {}
      const updated = uninstalledPackages.filter((p) => p !== pkg);
      saveUninstalledToStorage(updated);
      setUninstallNotice(`Đã khôi phục thành công gói ${pkg}! Icon đã xuất hiện lại trên màn hình chính.`);
      await scanRealPackages();
    } catch (e: any) {
      setUninstallNotice(`Lỗi khôi phục gói ${pkg}: ${e?.message || 'Thất bại'}`);
    } finally {
      setIsProcessing(false);
      setTimeout(() => setUninstallNotice(null), 6000);
    }
  };

  const handleRestoreAll = async () => {
    if (!isConnected || isProcessing || uninstalledPackages.length === 0) return;
    setIsProcessing(true);
    const cmds = uninstalledPackages.map((pkg) => HonorAdbScripts.buildDebloatRestoreCommand(pkg));
    const res = await adbDriver.executePipeline(cmds, undefined, { title: 'Khôi Phục Toàn Bộ Ứng Dụng Đã Gỡ' });
    if (res.success) {
      try {
        await adbDriver.executeCommand(
          'am force-stop com.hihonor.android.launcher 2>/dev/null || ' +
          'am force-stop com.huawei.android.launcher 2>/dev/null || ' +
          'am force-stop com.miui.home 2>/dev/null || ' +
          'am force-stop com.sec.android.app.launcher 2>/dev/null || ' +
          'am force-stop com.oppo.launcher 2>/dev/null || ' +
          'am force-stop com.vivo.launcher 2>/dev/null || true',
          { silent: true }
        );
      } catch (e) {}
      saveUninstalledToStorage([]);
      setUninstallNotice('Đã khôi phục toàn bộ các ứng dụng đã gỡ! Icon đã hiển thị lại đầy đủ.');
    } else {
      setUninstallNotice(`Khôi phục hoàn tất với ${res.errors.length} lỗi. Xem log Terminal.`);
    }
    setIsProcessing(false);
    await scanRealPackages();
    setTimeout(() => setUninstallNotice(null), 8000);
  };

  const handleUninstallBatch = async () => {
    if (!isConnected || isProcessing || selectedPackages.length === 0) return;
    setIsProcessing(true);

    const count = selectedPackages.length;
    const commands: string[] = [];
    selectedPackages.forEach((pkg) => {
      commands.push(...HonorAdbScripts.buildDebloatDeepRemovePipeline(pkg));
    });

    const res = await adbDriver.executePipeline(commands, undefined, { title: `Gỡ Hàng Loạt ${count} Ứng Dụng Rác Hệ Thống` });
    if (res.success) {
      // Làm mới launcher tức thì
      try {
        await adbDriver.executeCommand(
          'am force-stop com.hihonor.android.launcher 2>/dev/null || ' +
          'am force-stop com.huawei.android.launcher 2>/dev/null || ' +
          'am force-stop com.miui.home 2>/dev/null || ' +
          'am force-stop com.sec.android.app.launcher 2>/dev/null || ' +
          'am force-stop com.oppo.launcher 2>/dev/null || ' +
          'am force-stop com.vivo.launcher 2>/dev/null || true',
          { silent: true }
        );
      } catch (e) {}

      const updated = [...new Set([...uninstalledPackages, ...selectedPackages])];
      saveUninstalledToStorage(updated);
      setSelectedPackages([]);
      setUninstallNotice(`Đã gỡ sạch ${count} ứng dụng rác! Toàn bộ icon đã biến mất ngay lập tức khỏi màn hình chính (Không cần khởi động lại máy).`);
      await scanRealPackages();
    } else {
      setUninstallNotice(`Đã gỡ ${count} ứng dụng với ${res.errors.length} cảnh báo. Xem log Terminal.`);
    }
    setIsProcessing(false);
    setTimeout(() => setUninstallNotice(null), 8000);
  };

  const renderLevelBadge = (level: string) => {
    switch (level) {
      case 'safe':
        return (
          <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
            Cấp 1 - An toàn 100%
          </span>
        );
      case 'advanced':
        return (
          <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-500/15 text-amber-300 border border-amber-500/30">
            Cấp 2 - Tiện ích nội địa
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="rounded-2xl border border-cyan-500/20 bg-[#111A2E]/90 backdrop-blur-xl p-6 shadow-xl relative overflow-hidden">
      {/* Tiêu đề */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-cyan-500/15 gap-4">
        <div className="flex items-center space-x-2.5">
          <div className="p-2.5 rounded-xl bg-purple-500/10 border border-purple-500/30 text-purple-400">
            <Trash2 className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white tracking-wide">
              Bộ Công Cụ Gỡ Ứng Dụng Rác An Toàn (Safe Debloat Engine)
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              100% ứng dụng hiển thị đều có thể gỡ sạch tức thì mà không cần khởi động lại. Đã tự động lọc bỏ toàn bộ ứng dụng cốt lõi để bảo vệ chống lỗi máy.
            </p>
          </div>
        </div>

        {/* Nút hành động */}
        <div className="flex items-center space-x-2.5 flex-wrap gap-y-2">
          {uninstalledPackages.length > 0 && (
            <button
              onClick={handleRestoreAll}
              disabled={!isConnected || isProcessing}
              className="px-3 py-1.5 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/40 text-xs font-semibold flex items-center space-x-1.5 transition-all"
              title="Khôi phục lại toàn bộ các ứng dụng đã gỡ trước đây"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Khôi phục tất cả ({uninstalledPackages.length})</span>
            </button>
          )}

          <button
            onClick={scanRealPackages}
            disabled={!isConnected || isScanning}
            className="px-3 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold flex items-center space-x-1.5 transition-all border border-slate-700 disabled:opacity-40"
            title="Quét lại các gói ứng dụng trên máy"
          >
            <Scan className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin text-[#00F0FF]' : ''}`} />
            <span>{isScanning ? `Đang quét (${scanProgress}%)...` : 'Quét Lại'}</span>
          </button>

          {lastScannedTime && !isScanning && (
            <span className="text-[11px] text-emerald-400 font-mono hidden sm:inline-flex items-center space-x-1 px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
              <span>Cập nhật: {lastScannedTime}</span>
            </span>
          )}

          <button
            onClick={handleSelectAllSafe}
            className="px-3 py-1.5 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 text-[#00F0FF] border border-cyan-500/30 text-xs font-semibold transition-all"
          >
            Chọn toàn bộ Cấp 1 (An toàn)
          </button>

          <button
            onClick={handleUninstallBatch}
            disabled={!isConnected || isProcessing || selectedPackages.length === 0}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-rose-600 to-red-700 hover:from-rose-500 hover:to-red-600 text-white text-xs font-bold flex items-center space-x-1.5 transition-all shadow-lg shadow-rose-900/30 disabled:opacity-40"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Gỡ hàng loạt ({selectedPackages.length})</span>
          </button>
        </div>
      </div>

      {uninstallNotice && (
        <div className="mt-3 p-3 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-semibold flex items-center space-x-2 animate-fadeIn">
          <span className="text-amber-400 text-sm">💡</span>
          <span>{uninstallNotice}</span>
        </div>
      )}

      {/* Bộ lọc và ô tìm kiếm */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 my-4">
        <div className="relative w-full sm:w-80 flex-1">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Tìm theo tên ứng dụng, mã gói (browser, appmarket, analytics...)..."
            className="w-full bg-[#0A0F1D] border border-cyan-500/20 rounded-xl pl-10 pr-3.5 py-2 text-xs sm:text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-400 shadow-inner"
          />
        </div>

        <div className="grid grid-cols-3 sm:flex items-center gap-1.5 w-full sm:w-auto">
          {(
            [
              { key: 'all', label: 'Tất cả app có thể gỡ' },
              { key: 'safe', label: 'Cấp 1 - An toàn 100%' },
              { key: 'advanced', label: 'Cấp 2 - Tiện ích nội địa' }
            ] as const
          ).map((item) => (
            <button
              key={item.key}
              onClick={() => setFilterLevel(item.key as any)}
              className={`px-2.5 py-1.5 rounded-xl text-xs font-medium text-center transition-all ${
                filterLevel === item.key
                  ? 'bg-[#00F0FF] text-black font-bold shadow-md shadow-cyan-500/20'
                  : 'bg-slate-800/80 text-slate-400 hover:text-white'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

      {/* Danh sách gói */}
      <div className="rounded-xl border border-cyan-500/15 overflow-hidden bg-[#0A0F1D]/80">
        {!isConnected ? (
          <div className="p-8 text-center text-slate-400 space-y-2">
            <Trash2 className="w-8 h-8 text-slate-600 mx-auto mb-2" />
            <p className="text-sm font-semibold text-slate-300">Chưa kết nối thiết bị Android</p>
            <p className="text-xs text-slate-500">
              Vui lòng kết nối cáp USB để hệ thống tự động quét các ứng dụng rác thực tế đang có trên thiết bị của bạn.
            </p>
          </div>
        ) : isScanning && filteredList.length === 0 ? (
          <div className="p-8 text-center text-cyan-400 space-y-3">
            <div className="w-7 h-7 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin mx-auto" />
            <p className="text-xs font-semibold">{scanStatusText || 'Đang quét ứng dụng thực tế trên thiết bị của bạn...'}</p>
            <div className="w-48 mx-auto bg-slate-800 rounded-full h-1.5 overflow-hidden">
              <div className="bg-cyan-400 h-1.5 transition-all duration-300" style={{ width: `${scanProgress}%` }} />
            </div>
          </div>
        ) : filteredList.length === 0 ? (
          <div className="p-8 text-center text-slate-400 space-y-2">
            <ShieldCheck className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
            <p className="text-sm font-semibold text-emerald-300">Thiết bị cực kỳ sạch sẽ!</p>
            <p className="text-xs text-slate-500">
              Hệ thống đã quét toàn bộ máy và không tìm thấy ứng dụng rác thuộc bộ lọc này hoặc bạn đã gỡ sạch trước đó.
            </p>
          </div>
        ) : (
          <div className="space-y-1">
            {/* Thanh tiến độ quét không nhấp nháy màn hình */}
            {isScanning && (
              <div className="p-2.5 mx-3 mt-3 rounded-xl bg-cyan-950/40 border border-cyan-500/30 space-y-1.5 animate-in fade-in">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center space-x-2 text-cyan-300 font-semibold">
                    <div className="w-3.5 h-3.5 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
                    <span className="text-[11px]">{scanStatusText || 'Đang đồng bộ gói ứng dụng...'}</span>
                  </div>
                  <span className="font-mono text-xs font-bold text-cyan-400">{scanProgress}%</span>
                </div>
                <div className="w-full bg-slate-800/80 rounded-full h-1 overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-cyan-400 to-blue-500 h-1 transition-all duration-300"
                    style={{ width: `${scanProgress}%` }}
                  />
                </div>
              </div>
            )}
            <div className="max-h-[380px] overflow-y-auto divide-y divide-slate-800/60">
            {filteredList
              .slice((currentPage - 1) * pageSize, currentPage * pageSize)
              .map((item) => {
              const isSelected = selectedPackages.includes(item.package);
              const isUninstalled = uninstalledPackages.includes(item.package);

              return (
                <div
                  key={item.package}
                  className="p-3.5 flex flex-col md:flex-row md:items-center justify-between gap-3 hover:bg-[#111A2E]/60 transition-all"
                >
                <div className="flex items-start space-x-3">
                  <input
                    type="checkbox"
                    checked={isSelected}
                    disabled={isUninstalled}
                    onChange={() => toggleSelect(item.package)}
                    className="mt-1 w-4 h-4 rounded bg-slate-900 border-cyan-500/30 text-cyan-500 focus:ring-0 cursor-pointer disabled:opacity-20"
                  />
                  <div>
                    <div className="flex items-center space-x-2 flex-wrap gap-y-1">
                      <span className="font-semibold text-slate-200 text-xs">{item.name}</span>
                      <span className="text-[11px] font-mono text-[#00F0FF]">{item.package}</span>
                      {renderLevelBadge(item.level)}
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">
                        {item.category}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1">{item.description}</p>
                    <p className="text-[11px] text-amber-400/90 italic mt-0.5">
                      💡 Lời khuyên: {item.recommendation}
                    </p>
                  </div>
                </div>

                {/* Nút tác vụ từng app */}
                <div className="flex items-center space-x-2 shrink-0 self-end md:self-auto">
                  {isUninstalled ? (
                    <button
                      onClick={() => handleRestoreSingle(item.package)}
                      disabled={!isConnected || isProcessing}
                      className="px-2.5 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 text-xs font-semibold flex items-center space-x-1 border border-emerald-500/40 disabled:opacity-40"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>Khôi phục nguyên bản</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => handleUninstallSingle(item.package)}
                      disabled={!isConnected || isProcessing}
                      className="px-2.5 py-1 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 text-xs font-semibold flex items-center space-x-1 border border-rose-500/30 disabled:opacity-40"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>Gỡ an toàn</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    )}

        {/* Phân trang danh sách ứng dụng gỡ rác */}
        <Pagination
          currentPage={currentPage}
          totalItems={filteredList.length}
          pageSize={pageSize}
          onPageChange={(p) => setCurrentPage(p)}
        />
      </div>
    </div>
  );
};
