'use client';

import React, { useState, useEffect } from 'react';
import {
  Flame,
  Zap,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  HardDrive,
  Cpu,
  ShieldCheck,
  FileCode,
  DownloadCloud,
  Layers,
  RotateCw,
  Power,
  Activity,
  Terminal,
  Clock,
  Sparkles
} from 'lucide-react';
import { fastbootDriver, FastbootResponse } from '@/lib/fastboot/fastboot-controller';
import {
  pickLargeFirmwareFile,
  processLargeFirmware,
  FirmwareStreamProgress,
  SelectedFirmwareFile,
  formatBytes
} from '@/lib/fastboot/firmware-streamer';
import { deviceStateManager, DeviceLifecycleState } from '@/lib/fastboot/device-state-manager';
import { adbDriver } from '@/lib/adb/web-usb-driver';
import { recordUserActivity } from '@/lib/firebase/config';

interface FastbootRescueHubProps {
  isAdbConnected: boolean;
}

export const FastbootRescueHub: React.FC<FastbootRescueHubProps> = ({ isAdbConnected }) => {
  const [deviceState, setDeviceState] = useState<DeviceLifecycleState>('DISCONNECTED');
  const [statusMessage, setStatusMessage] = useState<string>('Sẵn sàng kết nối');
  const [isConnectingFastboot, setIsConnectingFastboot] = useState(false);
  const [isRebootingToFastboot, setIsRebootingToFastboot] = useState(false);

  // Thông số thiết bị đọc từ Fastboot
  const [fastbootVars, setFastbootVars] = useState<{
    product?: string;
    unlocked?: string;
    currentSlot?: string;
    maxDownloadSize?: string;
    versionBootloader?: string;
    secure?: string;
  } | null>(null);

  // Trạng thái nạp ROM
  const [selectedFile, setSelectedFile] = useState<SelectedFirmwareFile | null>(null);
  const [selectedPartition, setSelectedPartition] = useState<string>('boot');
  const [customPartition, setCustomPartition] = useState<string>('');
  const [isFlashing, setIsFlashing] = useState<boolean>(false);
  const [flashProgress, setFlashProgress] = useState<FirmwareStreamProgress | null>(null);
  const [flashLogs, setFlashLogs] = useState<string[]>([]);
  const [abortController, setAbortController] = useState<AbortController | null>(null);
  const [flashSuccess, setFlashSuccess] = useState<boolean>(false);

  // Đăng ký listener với State Manager
  useEffect(() => {
    const unsub = deviceStateManager.onStateChange((ev) => {
      setDeviceState(ev.state);
      if (ev.message) setStatusMessage(ev.message);
    });

    return () => unsub();
  }, []);

  const addLog = (msg: string) => {
    const timestamp = new Date().toLocaleTimeString('vi-VN', { hour12: false });
    setFlashLogs((prev) => [...prev.slice(-100), `[${timestamp}] ${msg}`]);
  };

  // 1. Chuyển từ ADB sang Bootloader tự động
  const handleRebootToBootloader = async () => {
    if (!isAdbConnected || isRebootingToFastboot) return;
    setIsRebootingToFastboot(true);
    addLog('Đang gửi lệnh: adb reboot bootloader...');

    try {
      await deviceStateManager.rebootToBootloader(30);
      addLog('Đã phát hiện thiết bị Fastboot qua WebUSB! Đang đọc thông số bootloader...');
      await readFastbootVariables();
      recordUserActivity('Chuyển đổi thiết bị sang chế độ Fastboot Bootloader');
    } catch (err: any) {
      addLog(`Lỗi chuyển Bootloader: ${err.message}`);
    } finally {
      setIsRebootingToFastboot(false);
    }
  };

  // 2. Kết nối trực tiếp với thiết bị đang ở sẵn Fastboot
  const handleConnectFastbootDirect = async () => {
    if (isConnectingFastboot) return;
    setIsConnectingFastboot(true);
    addLog('Đang yêu cầu kết nối WebUSB Fastboot (Class 0xFF / Subclass 0x42 / Protocol 0x03)...');

    try {
      await fastbootDriver.connect();
      addLog('Kết nối WebUSB Fastboot thành công!');
      await readFastbootVariables();
      recordUserActivity('Kết nối trực tiếp thiết bị Fastboot');
    } catch (err: any) {
      addLog(`Lỗi kết nối Fastboot: ${err.message}`);
    } finally {
      setIsConnectingFastboot(false);
    }
  };

  // Đọc các biến Fastboot quan trọng
  const readFastbootVariables = async () => {
    try {
      const vars = await fastbootDriver.getAllVariables();
      const product = vars['product'] || 'Android Device';
      const unlocked = vars['unlocked'] || vars['secure'] || 'Không rõ';
      const currentSlot = vars['current-slot'] || vars['slot-successful:a'] ? 'A' : 'Mặc định';
      const maxDownloadSize = vars['max-download-size'] ? formatBytes(parseInt(vars['max-download-size'], 16)) : 'Không giới hạn';
      const versionBootloader = vars['version-bootloader'] || 'N/A';
      const secure = vars['secure'] || 'yes';

      setFastbootVars({
        product,
        unlocked,
        currentSlot,
        maxDownloadSize,
        versionBootloader,
        secure,
      });

      addLog(`Thiết bị: ${product} · Bootloader Unlock: ${unlocked} · Slot: ${currentSlot}`);
    } catch (e: any) {
      addLog(`Lỗi đọc biến getvar: ${e.message}`);
    }
  };

  // 3. Chọn File Firmware bằng File System Access API
  const handlePickFile = async () => {
    try {
      const picked = await pickLargeFirmwareFile();
      setSelectedFile(picked);
      addLog(`Đã chọn file: ${picked.name} (${picked.readableSize})`);
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        addLog(`Lỗi mở file: ${err.message}`);
      }
    }
  };

  // 4. Nạp phân vùng với cơ chế chống tràn RAM (Zero-OOM Streaming)
  const handleStartFlashing = async () => {
    if (!fastbootDriver.isConnected() || !selectedFile || isFlashing) return;

    const targetPartition = selectedPartition === 'custom' ? customPartition.trim() : selectedPartition;
    if (!targetPartition) {
      alert('Vui lòng nhập tên phân vùng cần nạp.');
      return;
    }

    const confirmMsg = `CẢNH BÁO: Bạn sắp nạp file [${selectedFile.name}] (${selectedFile.readableSize}) vào phân vùng [${targetPartition}]. Hành động này sẽ ghi đè dữ liệu. Bạn có chắc chắn muốn tiếp tục?`;
    if (!window.confirm(confirmMsg)) return;

    if (selectedFile.size > 500 * 1024 * 1024) {
      const largeConfirm = `LƯU Ý QUAN TRỌNG CHO TỆP LỚN (>500MB):\nTệp [${selectedFile.name}] (${selectedFile.readableSize}) cần khoảng 2–8 phút để nạp.\n\n• Vui lòng KHÔNG chuyển tab, không tắt trình duyệt.\n• Đảm bảo cắm cáp USB chắc chắn và pin điện thoại trên 50%.\n\nBạn đã sẵn sàng tiếp tục?`;
      if (!window.confirm(largeConfirm)) return;
    }

    setIsFlashing(true);
    setFlashSuccess(false);
    setFlashProgress(null);

    const controller = new AbortController();
    setAbortController(controller);

    addLog(`>>> BẮT ĐẦU NẠP PHÂN VÙNG [${targetPartition}] VỚI ENGINE CHỐNG TRÀN RAM`);
    addLog(`Dung lượng file: ${selectedFile.readableSize} · Cơ chế Backpressure: Kích hoạt (2MB Chunk)`);

    try {
      // Bước 1: Gửi lệnh download kèm kích thước file
      const hexSize = selectedFile.size.toString(16).padStart(8, '0');
      addLog(`Gửi lệnh: download:0x${hexSize}...`);
      const downloadRes = await fastbootDriver.sendCommand(`download:${hexSize}`);

      if (downloadRes.status !== 'DATA') {
        throw new Error(`Bootloader từ chối lệnh download: ${downloadRes.payload}`);
      }

      addLog(`Bootloader sẵn sàng nhận ${selectedFile.readableSize}. Bắt đầu stream dữ liệu...`);

      // Bước 2: Đọc file từng phân đoạn 2MB và truyền thẳng qua WebUSB (Zero-OOM)
      await processLargeFirmware(
        selectedFile.handle,
        async (chunk, progress) => {
          setFlashProgress(progress);
          // Gửi phân đoạn này qua Endpoint OUT
          await fastbootDriver.sendRawPayload(chunk);
        },
        {
          chunkSize: 2 * 1024 * 1024, // 2MB
          signal: controller.signal,
          onProgress: (p) => {
            setFlashProgress(p);
          },
        }
      );

      addLog('Đã stream 100% dữ liệu vào RAM thiết bị. Đang đợi xác nhận từ Bootloader...');

      // Bước 3: Đọc gói ACK sau khi hoàn tất nạp payload
      const ackRes = await fastbootDriver.readPostPayloadResponse(45000);
      if (ackRes.status !== 'OKAY') {
        throw new Error(`Xác nhận dữ liệu nạp thất bại: ${ackRes.payload}`);
      }

      addLog(`Gói tin xác nhận: OKAY. Bắt đầu ghi vào chip nhớ phân vùng [${targetPartition}]...`);

      // Bước 4: Ra lệnh ghi vào chip nhớ (flash:partition)
      const flashRes = await fastbootDriver.sendCommand(`flash:${targetPartition}`, 120000); // 2 phút cho phân vùng lớn
      if (flashRes.status !== 'OKAY') {
        throw new Error(`Ghi phân vùng [${targetPartition}] thất bại: ${flashRes.payload}`);
      }

      addLog(`✅ NẠP THÀNH CÔNG 100% PHÂN VÙNG [${targetPartition}]!`);
      setFlashSuccess(true);
      recordUserActivity('Nạp thành công phân vùng Fastboot', `${targetPartition} (${selectedFile.name})`);
    } catch (err: any) {
      addLog(`❌ LỖI NẠP FIRMWARE: ${err.message}`);
      alert(`Nạp phân vùng thất bại: ${err.message}`);
    } finally {
      setIsFlashing(false);
      setAbortController(null);
    }
  };

  const handleCancelFlashing = () => {
    if (abortController) {
      abortController.abort();
      addLog('Đã gửi yêu cầu hủy nạp firmware.');
    }
  };

  const handleRebootDevice = async (target: '' | 'bootloader' | 'recovery') => {
    try {
      addLog(`Đang gửi lệnh khởi động lại: reboot ${target}...`);
      await fastbootDriver.reboot(target);
      addLog('Thiết bị đang khởi động lại!');
    } catch (err: any) {
      addLog(`Lỗi reboot: ${err.message}`);
    }
  };

  const isFastbootConnected = fastbootDriver.isConnected();

  return (
    <div className="rounded-2xl border border-cyan-500/20 bg-[#111A2E]/90 backdrop-blur-xl p-4 sm:p-6 shadow-xl relative overflow-hidden space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-cyan-500/15 gap-4">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 rounded-xl bg-gradient-to-tr from-cyan-500/20 to-blue-500/20 border border-cyan-500/30 text-[#00F0FF]">
            <Flame className="w-5 h-5 text-[#00F0FF]" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h3 className="text-base sm:text-lg font-bold text-white tracking-wide">
                Trung Tâm Cứu Hộ Fastboot &amp; Nạp ROM (WebUSB Flash Engine)
              </h3>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-[#00F0FF] border border-cyan-500/30 font-bold uppercase">
                Anti-OOM Stream
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Giao tiếp trực tiếp bootloader qua WebUSB. Nạp ROM dung lượng lớn 3GB - 8GB chống tràn RAM 100%.
            </p>
          </div>
        </div>

        {/* Trạng thái kết nối */}
        <div className="flex items-center space-x-2">
          {isFastbootConnected ? (
            <div className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs font-bold">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>Fastboot Mode: ĐÃ KẾT NỐI</span>
            </div>
          ) : (
            <div className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-slate-800 border border-slate-700 text-slate-400 text-xs font-semibold">
              <span className="w-2 h-2 rounded-full bg-amber-500" />
              <span>{deviceState === 'WAITING_FOR_FASTBOOT' ? 'Đang đợi Fastboot...' : 'Chưa kết nối Fastboot'}</span>
            </div>
          )}
        </div>
      </div>

      {/* Grid Bước 1 & Bước 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* CỘT 1: Quản lý kết nối & Chuyển đổi trạng thái */}
        <div className="p-4 rounded-xl bg-[#0A0F1D] border border-slate-800 space-y-3">
          <div className="flex items-center space-x-2 text-white font-bold text-xs uppercase tracking-wider">
            <Zap className="w-4 h-4 text-cyan-400" />
            <span>1. Kết Nối &amp; Chuyển Đổi Chế Độ</span>
          </div>

          <p className="text-[11px] text-slate-400">
            Nếu máy đang bật nguồn ở chế độ Android bình thường, dùng nút 1-chạm bên dưới để tự động chuyển sang Bootloader:
          </p>

          <button
            onClick={handleRebootToBootloader}
            disabled={!isAdbConnected || isRebootingToFastboot || isFastbootConnected}
            className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-black font-extrabold text-xs transition-all flex items-center justify-center space-x-1.5 disabled:opacity-40 shadow-md shadow-amber-500/20"
          >
            <RotateCw className={`w-3.5 h-3.5 ${isRebootingToFastboot ? 'animate-spin' : ''}`} />
            <span>{isRebootingToFastboot ? 'Đang Chuyển Sang Fastboot (30s)...' : '⚡ 1-Click ADB Sang Fastboot'}</span>
          </button>

          <div className="relative flex py-1 items-center">
            <div className="flex-grow border-t border-slate-800"></div>
            <span className="flex-shrink mx-2 text-[10px] text-slate-500 uppercase">Hoặc</span>
            <div className="flex-grow border-t border-slate-800"></div>
          </div>

          <button
            onClick={handleConnectFastbootDirect}
            disabled={isConnectingFastboot || isFastbootConnected}
            className="w-full py-2 px-3 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 text-[#00F0FF] border border-cyan-500/30 font-bold text-xs transition-all flex items-center justify-center space-x-1.5 disabled:opacity-40"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isConnectingFastboot ? 'animate-spin' : ''}`} />
            <span>{isFastbootConnected ? 'Đã Kết Nối Fastboot' : 'Kết Nối Trực Tiếp Fastboot USB'}</span>
          </button>

          {/* Thông tin thiết bị Fastboot */}
          {fastbootVars && (
            <div className="p-3 rounded-lg bg-[#111A2E] border border-cyan-500/20 space-y-1.5 text-[11px]">
              <div className="flex justify-between">
                <span className="text-slate-400">Dòng máy:</span>
                <span className="font-bold text-white">{fastbootVars.product}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Bootloader Unlock:</span>
                <span className={`font-bold ${Boolean(fastbootVars.unlocked?.includes('yes') || fastbootVars.unlocked?.includes('1')) ? 'text-emerald-400' : 'text-amber-400'}`}>
                  {fastbootVars.unlocked}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Active Slot:</span>
                <span className="font-mono text-cyan-300 font-bold">{fastbootVars.currentSlot}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Max Download Size:</span>
                <span className="font-mono text-slate-300">{fastbootVars.maxDownloadSize}</span>
              </div>
            </div>
          )}
        </div>

        {/* CỘT 2: Chọn phân vùng & Tệp ROM lớn */}
        <div className="p-4 rounded-xl bg-[#0A0F1D] border border-slate-800 space-y-3">
          <div className="flex items-center space-x-2 text-white font-bold text-xs uppercase tracking-wider">
            <HardDrive className="w-4 h-4 text-emerald-400" />
            <span>2. Chọn Phân Vùng &amp; Tệp ROM (.img)</span>
          </div>

          <div className="space-y-1.5">
            <label className="text-[11px] font-semibold text-slate-300">Chọn phân vùng cần nạp:</label>
            <select
              value={selectedPartition}
              onChange={(e) => setSelectedPartition(e.target.value)}
              className="w-full bg-[#111A2E] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
            >
              <option value="boot">boot (Kernel / Ramdisk)</option>
              <option value="init_boot">init_boot (Magisk / KernelSU Root)</option>
              <option value="vendor_boot">vendor_boot (Driver kernel)</option>
              <option value="recovery">recovery (Custom TWRP / OrangeFox)</option>
              <option value="vbmeta">vbmeta (Vô hiệu hóa AVB / DM-Verity)</option>
              <option value="super">super (Toàn bộ Dynamic System / Vendor)</option>
              <option value="system">system (System image)</option>
              <option value="custom">-- Phân vùng tùy chỉnh khác --</option>
            </select>
          </div>

          {selectedPartition === 'custom' && (
            <input
              type="text"
              placeholder="Nhập tên phân vùng (ví dụ: dtbo, modem...)"
              value={customPartition}
              onChange={(e) => setCustomPartition(e.target.value)}
              className="w-full bg-[#111A2E] border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-400"
            />
          )}

          {/* Nút mở File System Access API */}
          <div className="space-y-2 pt-1">
            <button
              onClick={handlePickFile}
              className="w-full py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-600 text-white font-bold text-xs flex items-center justify-center space-x-2 transition-all"
            >
              <DownloadCloud className="w-4 h-4 text-[#00F0FF]" />
              <span>{selectedFile ? 'Đổi File ROM Khác' : 'Chọn File ROM (.img / .bin)'}</span>
            </button>

            {selectedFile ? (
              <div className="p-2.5 rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-xs space-y-1">
                <div className="flex items-center space-x-1.5 text-white font-semibold truncate">
                  <FileCode className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                  <span className="truncate">{selectedFile.name}</span>
                </div>
                <div className="flex justify-between text-[11px] text-cyan-300 font-mono">
                  <span>Dung lượng:</span>
                  <span className="font-bold">{selectedFile.readableSize}</span>
                </div>
                <div className="text-[10px] text-emerald-400 flex items-center space-x-1">
                  <ShieldCheck className="w-3 h-3" />
                  <span>Sẵn sàng stream 2MB Backpressure (Zero OOM)</span>
                </div>
                {selectedFile.size > 500 * 1024 * 1024 && (
                  <div className="mt-2 p-2 rounded-lg bg-amber-500/15 border border-amber-500/40 text-[10px] text-amber-200 space-y-1">
                    <div className="flex items-center space-x-1 font-bold text-amber-300">
                      <AlertTriangle className="w-3 h-3 shrink-0" />
                      <span>Tệp lớn ({selectedFile.readableSize})</span>
                    </div>
                    <p className="text-slate-300 leading-snug">
                      WebUSB stream trực tiếp qua cổng USB (khoảng 2–8 phút). Hãy giữ nguyên tab trình duyệt và đảm bảo cáp cắm ổn định.
                    </p>
                  </div>
                )}
              </div>
            ) : (
              <p className="text-[10px] text-slate-500 italic text-center">
                Hỗ trợ file ROM dung lượng lớn từ 10MB đến 12GB mà không lo tràn RAM trình duyệt.
              </p>
            )}
          </div>
        </div>

        {/* CỘT 3: Bảng điều khiển nạp & Tiến độ */}
        <div className="p-4 rounded-xl bg-[#0A0F1D] border border-slate-800 space-y-3">
          <div className="flex items-center space-x-2 text-white font-bold text-xs uppercase tracking-wider">
            <Activity className="w-4 h-4 text-purple-400" />
            <span>3. Tiến Trình Nạp ROM &amp; Flash</span>
          </div>

          {/* Nút kích hoạt nạp */}
          <button
            onClick={handleStartFlashing}
            disabled={!isFastbootConnected || !selectedFile || isFlashing}
            className="w-full py-3 px-3 rounded-xl bg-gradient-to-r from-[#00F0FF] via-cyan-400 to-blue-600 hover:from-cyan-300 hover:to-blue-500 text-black font-black text-xs shadow-lg shadow-cyan-500/25 flex items-center justify-center space-x-2 transition-all active:scale-[0.98] disabled:opacity-40"
          >
            {isFlashing ? (
              <>
                <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                <span>Đang Stream &amp; Nạp Phân Vùng...</span>
              </>
            ) : flashSuccess ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-black" />
                <span>Nạp Thành Công 100%!</span>
              </>
            ) : (
              <>
                <Zap className="w-4 h-4 fill-black" />
                <span>Bắt Đầu Nạp Phân Vùng Ngay</span>
              </>
            )}
          </button>

          {isFlashing && (
            <button
              onClick={handleCancelFlashing}
              className="w-full py-1.5 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 text-xs font-semibold transition-all"
            >
              Hủy Thao Tác Nạp
            </button>
          )}

          {/* Thanh tiến độ */}
          {flashProgress && (
            <div className="space-y-2 p-3 rounded-lg bg-[#111A2E] border border-cyan-500/20 text-xs">
              <div className="flex justify-between text-white font-semibold text-[11px]">
                <span>Tiến độ truyền:</span>
                <span className="text-[#00F0FF] font-mono font-bold">{flashProgress.percent}%</span>
              </div>

              <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-[#00F0FF] to-blue-500 transition-all duration-200"
                  style={{ width: `${flashProgress.percent}%` }}
                />
              </div>

              <div className="grid grid-cols-2 gap-1 text-[10px] text-slate-400 font-mono">
                <div>Đã gửi: {formatBytes(flashProgress.bytesProcessed)}</div>
                <div className="text-right">Tốc độ: {flashProgress.speedMBps} MB/s</div>
                <div>Chunk: #{flashProgress.chunkIndex}</div>
                <div className="text-right">Còn lại: ~{flashProgress.estimatedSecondsLeft}s</div>
              </div>
            </div>
          )}

          {/* Khởi động lại sau khi nạp */}
          <div className="pt-2 border-t border-slate-800 space-y-1.5">
            <span className="text-[11px] text-slate-400 font-semibold">Khởi động lại máy:</span>
            <div className="grid grid-cols-3 gap-1.5">
              <button
                onClick={() => handleRebootDevice('')}
                disabled={!isFastbootConnected || isFlashing}
                className="py-1.5 px-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-semibold transition-all disabled:opacity-40"
              >
                Hệ điều hành
              </button>
              <button
                onClick={() => handleRebootDevice('recovery')}
                disabled={!isFastbootConnected || isFlashing}
                className="py-1.5 px-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-semibold transition-all disabled:opacity-40"
              >
                Recovery
              </button>
              <button
                onClick={() => handleRebootDevice('bootloader')}
                disabled={!isFastbootConnected || isFlashing}
                className="py-1.5 px-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-semibold transition-all disabled:opacity-40"
              >
                Bootloader
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Terminal Log Console */}
      <div className="p-3 rounded-xl bg-[#0A0F1D] border border-slate-800 space-y-1.5">
        <div className="flex items-center justify-between text-xs text-slate-400 pb-1 border-b border-slate-800">
          <div className="flex items-center space-x-1.5 text-cyan-400 font-bold">
            <Terminal className="w-3.5 h-3.5" />
            <span>Fastboot Console Stream &amp; Hardware Diagnostics Log</span>
          </div>
          <span className="text-[10px] font-mono text-slate-500">Giao thức WebUSB</span>
        </div>

        <div className="h-28 overflow-y-auto font-mono text-[11px] space-y-1 text-slate-300 p-1">
          {flashLogs.length === 0 ? (
            <div className="text-slate-500 italic">Chưa có sự kiện nào. Hãy kết nối hoặc chọn file để bắt đầu...</div>
          ) : (
            flashLogs.map((log, idx) => (
              <div
                key={idx}
                className={`${log.includes('❌') ? 'text-rose-400' : log.includes('✅') ? 'text-emerald-400' : 'text-slate-300'}`}
              >
                {log}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
