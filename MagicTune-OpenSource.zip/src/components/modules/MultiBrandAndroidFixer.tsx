'use client';

import React, { useState } from 'react';
import {
  Smartphone,
  Cpu,
  Layers,
  Sparkles,
  Zap,
  Battery,
  ShieldAlert,
  CheckCircle2,
  Trash2,
  Terminal,
  Activity,
  Maximize2,
  Lock,
  RotateCcw,
  Volume2,
  Flame,
  Globe
} from 'lucide-react';
import { adbDriver } from '@/lib/adb/web-usb-driver';
import { recordUserActivity } from '@/lib/firebase/config';

interface BrandPreset {
  id: string;
  name: string;
  osName: string;
  logoColor: string;
  badge: string;
  description: string;
  tweaks: {
    title: string;
    description: string;
    actionLabel: string;
    commands: string[];
    risk: 'safe' | 'medium';
  }[];
}

const BRAND_PRESETS: BrandPreset[] = [
  {
    id: 'honor_huawei',
    name: 'Honor / Huawei',
    osName: 'MagicOS & EMUI / HarmonyOS',
    logoColor: 'from-[#00F0FF] to-blue-600',
    badge: 'MagicOS / EMUI',
    description: 'Chuyên gia xử lý triệt để bóp tiến trình ngầm PowerGenie, đóng băng ngắt kết nối Bastet service, mở khóa tần số quét 120Hz và gỡ app rác Honor Mall/HiHonor.',
    tweaks: [
      {
        title: 'Khóa Cưỡng Chế Bastet Service & PowerGenie (Fix Trễ Thông Báo)',
        description: 'Vô hiệu hóa tiến trình ngắt kết nối com.hihonor.bastet.service và bẻ khóa quản lý pin quá gắt com.hihonor.powergenie, đưa Zalo, Messenger, Gmail vào danh sách ngoại lệ cấp hệ thống.',
        actionLabel: '1-Chạm Bẻ Khóa Bastet & PowerGenie',
        commands: [
          'pm disable-user --user 0 com.hihonor.bastet.service',
          'pm disable-user --user 0 com.hihonor.powergenie',
          'settings put global app_standby_enabled 0',
          'dumpsys deviceidle whitelist +com.zing.zalo',
          'dumpsys deviceidle whitelist +com.facebook.katana',
          'dumpsys deviceidle whitelist +com.facebook.orca',
          'dumpsys deviceidle whitelist +com.google.android.gm',
          'cmd appops set com.zing.zalo RUN_ANY_IN_BACKGROUND allow',
          'cmd appops set com.facebook.orca RUN_ANY_IN_BACKGROUND allow'
        ],
        risk: 'safe'
      },
      {
        title: 'Gỡ Bỏ Chợ Ứng Dụng Rác & Dịch Vụ Nội Địa',
        description: 'Gỡ sạch các chợ ứng dụng nội địa (Honor Mall, Huawei AppGallery, Video, Âm nhạc) và dịch vụ quảng cáo nội địa Trung Quốc giúp máy nhẹ mượt và tiết kiệm pin.',
        actionLabel: 'Gỡ App Rác Nội Địa',
        commands: [
          'pm uninstall --user 0 com.hihonor.vmall',
          'pm uninstall --user 0 com.huawei.appmarket',
          'pm uninstall --user 0 com.hihonor.videos',
          'pm uninstall --user 0 com.hihonor.magichome',
          'pm uninstall --user 0 com.hihonor.search'
        ],
        risk: 'safe'
      },
      {
        title: 'Khóa Tần Số Quét 120Hz / 144Hz Toàn Diện Cho Mọi Ứng Dụng',
        description: 'Ngăn MagicOS tự động tụt về 60Hz khi mở ứng dụng bên thứ ba (Facebook, TikTok, Chrome).',
        actionLabel: 'Ép Khung Hình Mượt 120Hz',
        commands: [
          'settings put system min_refresh_rate 120',
          'settings put system peak_refresh_rate 120'
        ],
        risk: 'safe'
      }
    ]
  },
  {
    id: 'xiaomi',
    name: 'Xiaomi / Redmi / POCO',
    osName: 'HyperOS & MIUI',
    logoColor: 'from-orange-500 to-amber-500',
    badge: 'HyperOS / MIUI',
    description: 'Sửa lỗi trễ thông báo do Joyose & MIUI PowerKeeper, gỡ app rác MSA, Mi Video, Mi Browser và tắt tối ưu hóa MIUI gây chậm máy.',
    tweaks: [
      {
        title: 'Fix Trễ Thông Báo & Bóp Hiệu Năng (Joyose & Powerkeeper)',
        description: 'Vô hiệu hóa tiến trình com.xiaomi.joyose (chuyên hạ FPS và bóp xung khi chơi game) và tắt kiểm soát pin quá gắt com.miui.powerkeeper.',
        actionLabel: 'Đóng Băng Joyose & PowerKeeper',
        commands: [
          'pm disable-user --user 0 com.xiaomi.joyose 2>/dev/null || true',
          'pm disable-user --user 0 com.miui.powerkeeper 2>/dev/null || true',
          'cmd appops set com.miui.powerkeeper RUN_IN_BACKGROUND allow 2>/dev/null || true',
          'settings put system miui_optimization 0 2>/dev/null || true',
          'settings put global app_standby_enabled 0',
          'dumpsys deviceidle whitelist +com.zing.zalo',
          'dumpsys deviceidle whitelist +com.facebook.katana',
          'dumpsys deviceidle whitelist +com.facebook.orca'
        ],
        risk: 'safe'
      },
      {
        title: 'Gỡ Bỏ Hệ Thống Quảng Cáo & Thu Thập Dữ Liệu Xiaomi (MSA & Analytics)',
        description: 'Gỡ sạch gói quảng cáo mặc định MSA (MIUI System Ads) và tiến trình phân tích theo dõi Analytics chạy ngầm ngốn RAM.',
        actionLabel: 'Gỡ Bỏ MSA & Mi Ads Analytics',
        commands: [
          'pm uninstall --user 0 com.miui.msa.global',
          'pm uninstall --user 0 com.miui.analytics',
          'pm uninstall --user 0 com.xiaomi.mipicks',
          'pm uninstall --user 0 com.miui.hybrid',
          'pm uninstall --user 0 com.miui.cleanmaster'
        ],
        risk: 'safe'
      },
      {
        title: 'Kích Hoạt Tần Số Quét Cao 120Hz/144Hz Không Bị Tụt Khi Nóng',
        description: 'Ép màn hình chạy 120Hz mượt mà kể cả khi xem YouTube hoặc nhiệt độ máy hơi ấm.',
        actionLabel: 'Ép Cố Định 120Hz HyperOS',
        commands: [
          'settings put system peak_refresh_rate 120.0',
          'settings put system min_refresh_rate 120.0',
          'settings put secure refresh_rate_mode 2'
        ],
        risk: 'safe'
      }
    ]
  },
  {
    id: 'samsung',
    name: 'Samsung Galaxy',
    osName: 'One UI',
    logoColor: 'from-blue-600 to-indigo-600',
    badge: 'One UI',
    description: 'Tối ưu độ trễ hoạt ảnh One UI, dọn dẹp Bloatware Facebook stub, Bixby, Samsung Pay (máy xách tay) và tối ưu Game Optimizing Service (GOS).',
    tweaks: [
      {
        title: 'Tăng Tốc Giao Diện & Giảm Độ Trễ Phản Hồi One UI (Instant Anim)',
        description: 'Giảm tỷ lệ hoạt ảnh cửa sổ và chuyển cảnh từ 1.0x xuống 0.5x, kích hoạt độ nhạy cảm ứng cao giúp One UI vuốt chạm như chớp.',
        actionLabel: 'Kích Hoạt Tăng Tốc One UI',
        commands: [
          'settings put global window_animation_scale 0.5',
          'settings put global transition_animation_scale 0.5',
          'settings put global animator_duration_scale 0.5',
          'settings put system touch_sensitivity_enabled 1'
        ],
        risk: 'safe'
      },
      {
        title: 'Gỡ Bỏ Gói Ngầm Bixby & Facebook Cài Sẵn (Stub)',
        description: 'Gỡ bỏ dịch vụ trợ lý ảo Bixby và các tiến trình Facebook App Installer âm thầm chạy ngầm ăn pin của Samsung.',
        actionLabel: 'Dọn Dẹp Bixby & Facebook Stub',
        commands: [
          'pm uninstall --user 0 com.samsung.android.bixby.agent',
          'pm uninstall --user 0 com.samsung.android.bixby.wakeup',
          'pm uninstall --user 0 com.facebook.system',
          'pm uninstall --user 0 com.facebook.appmanager',
          'pm uninstall --user 0 com.samsung.android.spay'
        ],
        risk: 'safe'
      },
      {
        title: 'Tắt Bóp Hiệu Năng Game Optimizing Service (GOS)',
        description: 'Giảm tải cho CPU và GPU khi chơi game nặng, hạn chế tình trạng drop FPS đột ngột trên các dòng Galaxy S và Galaxy A.',
        actionLabel: 'Vô Hiệu Hóa GOS Giảm Nhiệt',
        commands: [
          'pm disable-user --user 0 com.samsung.android.game.gametools',
          'pm disable-user --user 0 com.samsung.android.game.gos'
        ],
        risk: 'safe'
      }
    ]
  },
  {
    id: 'oppo_realme_oneplus',
    name: 'OPPO / Realme / OnePlus',
    osName: 'ColorOS / Realme UI / OxygenOS',
    logoColor: 'from-emerald-500 to-teal-600',
    badge: 'ColorOS / OxygenOS',
    description: 'Phá vỡ giới hạn ngủ đông 5 phút của ColorOS, sửa lỗi trễ cuộc gọi Messenger/Zalo, gỡ chợ ứng dụng HeyTap & Game Center nội địa.',
    tweaks: [
      {
        title: 'Bẻ Khóa Giới Hạn Đóng Băng Tiến Trình Nền ColorOS (Doze Bypass)',
        description: 'Cấm hệ điều hành ColorOS đưa Zalo, Telegram, Facebook và Gmail vào danh sách ngủ sâu khi máy tắt màn hình.',
        actionLabel: 'Fix Giữ Mạng Nền ColorOS / OxygenOS',
        commands: [
          'settings put global app_standby_enabled 0',
          'cmd appops set com.coloros.safecenter RUN_IN_BACKGROUND allow 2>/dev/null || true',
          'cmd appops set com.coloros.oppoguardelf RUN_IN_BACKGROUND allow 2>/dev/null || true',
          'dumpsys deviceidle whitelist +com.zing.zalo',
          'dumpsys deviceidle whitelist +com.facebook.orca',
          'dumpsys deviceidle whitelist +com.google.android.gm',
          'dumpsys deviceidle whitelist +org.telegram.messenger',
          'cmd appops set com.zing.zalo RUN_ANY_IN_BACKGROUND allow',
          'cmd appops set com.facebook.orca RUN_ANY_IN_BACKGROUND allow'
        ],
        risk: 'safe'
      },
      {
        title: 'Gỡ Bỏ HeyTap & Dịch Vụ Quảng Cáo Nội Địa OPPO / Realme',
        description: 'Gỡ bỏ chợ ứng dụng HeyTap Market, HeyTap Cloud và dịch vụ thông báo rác không dùng đến tại Việt Nam.',
        actionLabel: 'Gỡ HeyTap & App Rác ColorOS',
        commands: [
          'pm uninstall --user 0 com.heytap.market',
          'pm uninstall --user 0 com.heytap.browser',
          'pm uninstall --user 0 com.heytap.cloud',
          'pm uninstall --user 0 com.coloros.gamespace',
          'pm uninstall --user 0 com.nearme.atlas'
        ],
        risk: 'safe'
      }
    ]
  },
  {
    id: 'vivo_iqoo',
    name: 'Vivo / iQOO',
    osName: 'OriginOS / FuntouchOS',
    logoColor: 'from-blue-500 to-cyan-500',
    badge: 'OriginOS / FuntouchOS',
    description: 'Đặc thù máy nội địa Vivo xách tay chạy OriginOS thường bị trễ thông báo nặng nề và chứa nhiều app V-Appstore nội địa.',
    tweaks: [
      {
        title: 'Bẻ Khóa Quản Lý Nguồn Điện OriginOS Cho Máy Nội Địa',
        description: 'Khắc phục triệt để lỗi không nhận được cuộc gọi đến Zalo & Messenger trên OriginOS khi máy tắt màn hình.',
        actionLabel: '1-Chạm Fix Thông Báo OriginOS',
        commands: [
          'cmd appops set com.vivo.abe RUN_IN_BACKGROUND allow 2>/dev/null || true',
          'cmd appops set com.vivo.pem RUN_IN_BACKGROUND allow 2>/dev/null || true',
          'dumpsys deviceidle whitelist +com.zing.zalo',
          'dumpsys deviceidle whitelist +com.facebook.katana',
          'dumpsys deviceidle whitelist +com.facebook.orca',
          'dumpsys deviceidle whitelist +com.google.android.gms',
          'cmd appops set com.zing.zalo RUN_ANY_IN_BACKGROUND allow',
          'cmd appops set com.facebook.orca RUN_ANY_IN_BACKGROUND allow',
          'settings put global auto_sync 1'
        ],
        risk: 'safe'
      },
      {
        title: 'Gỡ Bỏ V-Appstore & Dịch Vụ Trợ Lý Ảo Jovi Nội Địa',
        description: 'Gỡ bỏ chợ ứng dụng Trung Quốc V-Appstore và tính năng tìm kiếm Jovi gây ngốn pin.',
        actionLabel: 'Gỡ App Rác Vivo / iQOO',
        commands: [
          'pm uninstall --user 0 com.vivo.appstore',
          'pm uninstall --user 0 com.vivo.browser',
          'pm uninstall --user 0 com.bbk.appstore',
          'pm uninstall --user 0 com.vivo.globalsearch'
        ],
        risk: 'safe'
      }
    ]
  },
  {
    id: 'universal_android',
    name: 'Mọi Hãng Android Khác (Pixel, Sony, Asus, Moto, LG)',
    osName: 'Android (AOSP / Pixel UI)',
    logoColor: 'from-emerald-600 to-green-600',
    badge: 'Universal AOSP',
    description: 'Các công cụ tối ưu chung chạy được trên 100% mọi điện thoại và máy tính bảng Android trên toàn thế giới.',
    tweaks: [
      {
        title: 'Dọn Dẹp Bộ Nhớ Đệm & Biên Dịch Tối Ưu Toàn Bộ Ứng Dụng (Dexopt Speed)',
        description: 'Biên dịch mã bytecode thành mã máy tối ưu (Speed-profile), giúp mọi app khởi động nhanh hơn 40% và giảm sinh nhiệt.',
        actionLabel: 'Chạy Tối Ưu Dexopt Toàn Sàn',
        commands: [
          'cmd package compile -m speed-profile -a',
          'pm trim-caches 99999999999'
        ],
        risk: 'safe'
      },
      {
        title: 'Mở Khóa Tần Số Quét & Tốc Độ Chuyển Cảnh Mượt Mà',
        description: 'Tăng tốc phản hồi cảm ứng và giảm thời gian chờ hoạt ảnh giao diện Android.',
        actionLabel: 'Tăng Tốc Phản Hồi Màn Hình',
        commands: [
          'settings put global window_animation_scale 0.5',
          'settings put global transition_animation_scale 0.5',
          'settings put global animator_duration_scale 0.5'
        ],
        risk: 'safe'
      },
      {
        title: 'Tắt Thu Thập Dữ Liệu Chẩn Đoán & Tiết Kiệm Pin Tối Đa',
        description: 'Tắt gửi thống kê chẩn đoán về máy chủ Google và chặn dịch vụ quảng cáo theo dõi ẩn.',
        actionLabel: 'Chặn Đo Lường Từ Xa & Tiết Kiệm Pin',
        commands: [
          'settings put secure send_action_app_error 0',
          'settings put secure anr_debugging_mechanism 0'
        ],
        risk: 'safe'
      },
      {
        title: 'Công Nghệ Hybrid Eco: Tiết Kiệm Pin Tối Đa Nhưng Không Trễ Thông Báo (0s Delay)',
        description: 'Đặc trị cho mọi máy Android: Dập tắt tiến trình ngốn pin chạy ngầm, kích hoạt Adaptive Battery thông minh và đưa FB, Zalo, Gmail, Telegram vào Whitelist nổ chuông tức thì.',
        actionLabel: 'Kích Hoạt Hybrid Eco Pin & Chuông 0s',
        commands: [
          'cmd package compile -m speed-profile -a',
          'pm trim-caches 99999999999',
          'settings put global adaptive_battery_management_enabled 1',
          'settings put global app_standby_enabled 1',
          'settings put global auto_sync 1',
          'dumpsys deviceidle whitelist +com.facebook.katana',
          'dumpsys deviceidle whitelist +com.facebook.orca',
          'dumpsys deviceidle whitelist +com.zing.zalo',
          'dumpsys deviceidle whitelist +com.google.android.gm',
          'dumpsys deviceidle whitelist +org.telegram.messenger',
          'dumpsys deviceidle whitelist +com.google.android.gms',
          'cmd appops set com.facebook.orca RUN_IN_BACKGROUND allow',
          'cmd appops set com.zing.zalo RUN_IN_BACKGROUND allow',
          'cmd appops set com.google.android.gm RUN_IN_BACKGROUND allow',
          'settings put global wifi_sleep_policy 2',
          'settings put global mobile_data_always_on 1'
        ],
        risk: 'safe'
      }
    ]
  }
];

interface MultiBrandAndroidFixerProps {
  isConnected: boolean;
  detectedBrandId?: string; // Tự động phát hiện hãng (honor_huawei, xiaomi, samsung, oppo_realme_oneplus, vivo_iqoo, universal_android)
}

export const MultiBrandAndroidFixer: React.FC<MultiBrandAndroidFixerProps> = ({
  isConnected,
  detectedBrandId
}) => {
  const [selectedBrand, setSelectedBrand] = useState<string>(detectedBrandId || 'honor_huawei');
  const [showAllBrands, setShowAllBrands] = useState<boolean>(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [activeTweakTitle, setActiveTweakTitle] = useState<string | null>(null);
  const [successNote, setSuccessNote] = useState<string | null>(null);

  // Tự động chuyển sang hãng tương ứng khi thiết bị kết nối
  React.useEffect(() => {
    if (detectedBrandId) {
      setSelectedBrand(detectedBrandId);
      setShowAllBrands(false);
    }
  }, [detectedBrandId]);

  const brand = BRAND_PRESETS.find((b) => b.id === selectedBrand) || BRAND_PRESETS[0];

  const handleExecuteTweak = async (tweak: BrandPreset['tweaks'][0]) => {
    if (!isConnected || isProcessing) return;
    setIsProcessing(true);
    setActiveTweakTitle(tweak.title);

    try {
      const result = await adbDriver.executePipeline(tweak.commands, undefined, { title: `${brand.name}: ${tweak.title}` });
      if (result.errors.length === 0) {
        recordUserActivity(`Tối ưu đa hãng: ${brand.name}`, tweak.title);
        setSuccessNote(`Thành công! Đã áp dụng: ${tweak.title} cho thiết bị ${brand.name}.`);
      } else {
        setSuccessNote(`Đã thực thi ${tweak.title} (${tweak.commands.length - result.errors.length}/${tweak.commands.length} lệnh thành công). Xem chi tiết trong Terminal.`);
      }
      setTimeout(() => setSuccessNote(null), 5000);
    } catch (e: any) {
      console.error(e);
      setSuccessNote(`Lỗi khi thực thi: ${e?.message || 'Không thể gửi lệnh'}`);
      setTimeout(() => setSuccessNote(null), 5000);
    } finally {
      setIsProcessing(false);
      setActiveTweakTitle(null);
    }
  };

  return (
    <div className="rounded-2xl border border-cyan-500/30 bg-[#111A2E]/90 backdrop-blur-xl p-6 shadow-xl relative overflow-hidden space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-cyan-500/20 gap-4">
        <div className="flex items-center space-x-3">
          <div className="p-3 rounded-xl bg-gradient-to-tr from-cyan-500/20 to-blue-600/20 border border-cyan-500/30 text-[#00F0FF]">
            <Smartphone className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h3 className="text-lg font-bold text-white tracking-wide">
                {!showAllBrands && detectedBrandId
                  ? `Trung Tâm Tối Ưu Chuyên Sâu: ${brand.name}`
                  : 'Trung Tâm Fix & Tối Ưu Đa Hãng Android (Multi-Brand Hub)'}
              </h3>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-gradient-to-r from-orange-500/20 to-blue-500/20 text-cyan-300 font-bold border border-cyan-500/30">
                {!showAllBrands && detectedBrandId ? brand.badge : 'Toàn Diện Android'}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              {!showAllBrands && detectedBrandId
                ? brand.description
                : 'Hỗ trợ chuyên sâu cho Honor/Huawei (MagicOS), Xiaomi (HyperOS), Samsung (One UI), OPPO/Realme/OnePlus (ColorOS), Vivo/iQOO (OriginOS) & Google Pixel'}
            </p>
          </div>
        </div>
      </div>

      {/* Thông báo thành công */}
      {successNote && (
        <div className="p-3.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-semibold flex items-center space-x-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{successNote}</span>
        </div>
      )}

      {/* Banner Tự Động Nhận Diện Hãng Thiết Bị & Lọc Tính Năng */}
      {isConnected && detectedBrandId && (
        <div className="p-3.5 rounded-2xl bg-gradient-to-r from-cyan-950/40 via-blue-950/30 to-[#0A0F1D] border border-cyan-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-xl bg-cyan-500/20 text-[#00F0FF] border border-cyan-500/30">
              <Sparkles className="w-4 h-4 text-[#00F0FF]" />
            </div>
            <div>
              <div className="text-xs font-bold text-white flex items-center space-x-2">
                <span>Đã Tự Động Nhận Diện Thiết Bị:</span>
                <span className="text-cyan-300 font-extrabold uppercase bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/30">
                  {brand.name}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                {showAllBrands
                  ? 'Đang hiển thị toàn bộ preset của tất cả các hãng Android.'
                  : 'Đã ẩn các tính năng của hãng khác, chỉ hiển thị đúng các mục tối ưu đặc thù cho máy của bạn.'}
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowAllBrands(!showAllBrands)}
            className="px-3 py-1.5 rounded-xl bg-[#0A0F1D] hover:bg-slate-800 text-xs text-cyan-300 border border-cyan-500/30 font-bold transition-all shrink-0"
          >
            {showAllBrands ? 'Ẩn Hãng Khác (Chỉ Hiện Máy Này)' : 'Xem Preset Các Hãng Khác'}
          </button>
        </div>
      )}

      {/* Lưới Chọn Thương Hiệu (Brand Selector Grid) - Ẩn bớt các hãng khác khi đã nhận diện để giao diện cực kỳ gọn gàng */}
      {(!isConnected || !detectedBrandId || showAllBrands) && (
        <div className="grid grid-cols-1 xs:grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 gap-2 sm:gap-2.5">
          {BRAND_PRESETS.map((b) => {
            const isSelected = selectedBrand === b.id;
            return (
              <button
                key={b.id}
                onClick={() => setSelectedBrand(b.id)}
                className={`p-3 rounded-2xl text-xs font-bold transition-all flex flex-col items-start justify-between border min-w-0 text-left ${
                  isSelected
                    ? 'bg-gradient-to-r from-[#00F0FF] to-blue-600 text-black border-cyan-300 shadow-md shadow-cyan-500/25 scale-[1.02]'
                    : 'bg-[#0A0F1D] text-slate-300 border-slate-700/80 hover:border-slate-500 hover:bg-[#111A2E]'
                }`}
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <span className="font-extrabold truncate text-[11px] sm:text-xs">{b.name}</span>
                  <span
                    className={`text-[9px] px-1.5 py-0.2 rounded-md font-mono shrink-0 ml-1 ${
                      isSelected ? 'bg-black/30 text-white' : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {b.badge}
                  </span>
                </div>
                <span className={`text-[10px] truncate w-full block font-medium ${
                  isSelected ? 'text-black/80 font-semibold' : 'text-slate-400'
                }`}>
                  {b.osName}
                </span>
              </button>
            );
          })}
        </div>
      )}

      {/* Chi tiết thương hiệu đang chọn */}
      <div className="p-4 rounded-xl bg-[#0A0F1D]/80 border border-slate-800 space-y-1">
        <div className="flex items-center space-x-2">
          <span className="text-xs font-bold text-white uppercase tracking-wider">
            Gói Tối Ưu Đặc Thù: {brand.name}
          </span>
          <span className="text-[10px] text-cyan-400 font-mono">({brand.osName})</span>
        </div>
        <p className="text-xs text-slate-400 leading-relaxed">{brand.description}</p>
      </div>

      {/* Danh sách các tác vụ fix cho hãng đang chọn */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {brand.tweaks.map((tweak, index) => {
          const isThisExecuting = isProcessing && activeTweakTitle === tweak.title;
          return (
            <div
              key={index}
              className="p-5 rounded-2xl bg-[#0A0F1D]/80 border border-slate-800 hover:border-cyan-500/30 transition-all flex flex-col justify-between space-y-4"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-white tracking-wide flex items-center space-x-1.5">
                    <Zap className="w-3.5 h-3.5 text-amber-400" />
                    <span>{tweak.title}</span>
                  </h4>
                  <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 font-semibold">
                    An Toàn
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">{tweak.description}</p>

                {/* Danh sách lệnh sẽ thực thi */}
                <div className="p-2.5 rounded-lg bg-black/50 border border-slate-900 font-mono text-[10px] text-slate-400 space-y-1">
                  <span className="text-slate-500 block font-sans font-semibold">Tập lệnh ADB tự động:</span>
                  {tweak.commands.slice(0, 3).map((cmd, i) => (
                    <div key={i} className="truncate text-cyan-300/80">
                      $ {cmd}
                    </div>
                  ))}
                  {tweak.commands.length > 3 && (
                    <div className="text-[9px] text-slate-500 italic">
                      + thêm {tweak.commands.length - 3} lệnh tối ưu khác...
                    </div>
                  )}
                </div>
              </div>

              <button
                onClick={() => handleExecuteTweak(tweak)}
                disabled={!isConnected || isProcessing}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-500/20 to-blue-500/20 hover:from-cyan-500/30 hover:to-blue-500/30 text-cyan-300 border border-cyan-500/40 text-xs font-bold flex items-center justify-center space-x-2 transition-all disabled:opacity-40 hover:scale-[1.01] active:scale-[0.99]"
              >
                {isThisExecuting ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
                    <span>Đang nạp tập lệnh tối ưu...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5 text-[#00F0FF]" />
                    <span>{tweak.actionLabel}</span>
                  </>
                )}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};
