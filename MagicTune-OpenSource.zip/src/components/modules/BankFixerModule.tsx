'use client';

import React, { useState } from 'react';
import {
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  Lock,
  Unlock,
  Key,
  Smartphone,
  Sparkles,
  Zap,
  Info,
  Layers,
  Activity
} from 'lucide-react';
import { adbDriver } from '@/lib/adb/web-usb-driver';
import { recordUserActivity } from '@/lib/firebase/config';

interface BankFixerModuleProps {
  isConnected: boolean;
}

interface BankSecurityReport {
  buildTags: string;
  isTestKeys: boolean;
  debuggable: string;
  isDebuggable: boolean;
  bootloaderLocked: string;
  isBootloaderUnlocked: boolean;
  mockLocation: string;
  isMockLocationOn: boolean;
  foundRootPackages: string[];
  recommendations: string[];
}

export const BankFixerModule: React.FC<BankFixerModuleProps> = ({ isConnected }) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [securityReport, setSecurityReport] = useState<BankSecurityReport | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const notify = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(null), 5000);
  };

  const handleScanBankSecurity = async () => {
    if (!isConnected || isScanning) return;
    setIsScanning(true);
    try {
      const buildTags = (await adbDriver.executeCommand('getprop ro.build.tags')).trim();
      const debuggable = (await adbDriver.executeCommand('getprop ro.debuggable')).trim();
      const bootloaderLocked = (await adbDriver.executeCommand('getprop ro.boot.flash.locked')).trim();
      const mockLocation = (await adbDriver.executeCommand('settings get secure mock_location')).trim();

      const pkgsToCheck = [
        'com.topjohnwu.magisk',
        'io.github.vvb2060.magisk',
        'me.weishu.kernelsu',
        'io.github.a13e300.ksu'
      ];
      const foundRootPackages: string[] = [];
      for (const pkg of pkgsToCheck) {
        try {
          const res = await adbDriver.executeCommand(`pm path ${pkg}`);
          if (res.includes('package:')) {
            foundRootPackages.push(pkg);
          }
        } catch (e) {}
      }

      const isTestKeys = buildTags.includes('test-keys');
      const isDebuggable = debuggable === '1';
      const isBootloaderUnlocked = bootloaderLocked === '0';
      const isMockLocationOn = mockLocation === '1';

      const recs: string[] = [];
      if (isTestKeys) {
        recs.push('Firmware đang sử dụng bản build test-keys không chính thức (Custom ROM). Nên cập nhật ROM chính thức của hãng.');
      }
      if (isDebuggable) {
        recs.push('Hệ thống đang chạy cờ debuggable = 1. Các ứng dụng tài chính & bảo mật cao có thể từ chối mở.');
      }
      if (isBootloaderUnlocked) {
        recs.push('Bootloader đang Mở Khóa (Unlocked). Khuyến nghị khóa lại bootloader nếu bạn cần chứng thực Play Protect và tiêu chuẩn bảo mật cấp cao.');
      }
      if (isMockLocationOn) {
        recs.push('Đang bật Vị trí giả lập (Mock Location). Hãy bấm nút "Ẩn Chế Độ Nhà Phát Triển" bên dưới để tắt.');
      }
      if (foundRootPackages.length > 0) {
        recs.push(`Phát hiện gói root/mod: ${foundRootPackages.join(', ')}. Hãy cấu hình ẩn ứng dụng.`);
      }
      if (recs.length === 0) {
        recs.push('Hệ thống của bạn đạt tiêu chuẩn an toàn cao cho các ứng dụng bảo mật & tài chính!');
      }

      setSecurityReport({
        buildTags,
        isTestKeys,
        debuggable,
        isDebuggable,
        bootloaderLocked,
        isBootloaderUnlocked,
        mockLocation,
        isMockLocationOn,
        foundRootPackages,
        recommendations: recs
      });
      recordUserActivity('Quét chẩn đoán an toàn ứng dụng bảo mật');
      notify('Đã hoàn tất quét chẩn đoán bảo mật hệ thống!');
    } catch (e: any) {
      notify('Lỗi khi quét chẩn đoán bảo mật.');
    } finally {
      setIsScanning(false);
    }
  };

  // 1. Tắt cờ gỡ lỗi USB tạm thời & ẩn quyền trợ năng Accessibility Service
  const handleHideDeveloperMode = async () => {
    if (!isConnected || isProcessing) return;
    setIsProcessing(true);
    // Hầu hết ứng dụng tài chính & bảo mật kiểm tra: adb_enabled = 1, development_settings_enabled = 1
    const cmds = [
      'settings put global development_settings_enabled 0',
      'settings put global adb_wifi_enabled 0',
      'settings put secure mock_location 0',
      'settings put secure accessibility_enabled 0'
    ];
    const res = await adbDriver.executePipeline(cmds, undefined, { title: 'Tắt Vị Trí Giả & Tùy Chọn Nhà Phát Triển (Fix Bank)' });
    // Kiểm tra và xác minh trạng thái mock_location sau khi thực thi
    let verifiedMock = '0';
    try {
      const out = await adbDriver.executeCommand('settings get secure mock_location');
      verifiedMock = out.trim();
    } catch (e) {}

    recordUserActivity('Sửa lỗi app ngân hàng phát hiện chế độ nhà phát triển & Accessibility');
    setIsProcessing(false);
    if (res.success && verifiedMock === '0') {
      notify('Đã ẩn trạng thái Nhà Phát Triển & tắt Mock Location (Xác minh: 0)! Giờ bạn có thể mở các ứng dụng ngân hàng an toàn.');
    } else {
      notify('Đã áp dụng cấu hình bảo vệ ứng dụng ngân hàng.');
    }
  };

  // 2. Ẩn ứng dụng Root / Magisk / Shizuku khỏi tầm quét của app ngân hàng
  const handleHideRootSignatures = async () => {
    if (!isConnected || isProcessing) return;
    setIsProcessing(true);
    // Chặn quyền QUERY_ALL_PACKAGES cho các app ngân hàng phổ biến để chúng không thể quét tìm app root/mod
    const bankPkgs = [
      'com.VCB',
      'com.mbmobile',
      'com.techcombank.bb.app',
      'com.vnpay.bidv',
      'com.vietinbank.ipay',
      'com.acb.mobile',
      'com.vpb.vpbank',
      'com.tpb.mb.gprsandroid',
      'com.mservice.momopay'
    ];
    const cmds = bankPkgs.map(
      (pkg) => `cmd appops set ${pkg} GET_INSTALLED_APPS ignore`
    );
    const res = await adbDriver.executePipeline(cmds, undefined, { title: 'Chặn App Ngân Hàng Quét Danh Sách Ứng Dụng' });
    recordUserActivity('Chặn app ngân hàng quét danh sách ứng dụng (Query All Packages)');
    setIsProcessing(false);
    if (res.success) {
      notify('Đã chặn quyền quét toàn bộ ứng dụng của các App Ngân Hàng! App ngân hàng sẽ không còn phát hiện Shizuku, MicroG hay tool mod.');
    } else {
      notify(`Đã áp dụng chặn quét ứng dụng (${cmds.length - res.errors.length}/${cmds.length} thành công). Xem log Terminal.`);
    }
  };

  // 3. Sửa lỗi chứng chỉ mạng ngân hàng (SSL Pinning Bypass / DNS Google)
  const handleFixNetworkSecurity = async () => {
    if (!isConnected || isProcessing) return;
    setIsProcessing(true);
    const cmds = [
      'settings put global private_dns_mode hostname',
      'settings put global private_dns_specifier dns.google',
      'settings put global captive_portal_mode 0',
      'settings put global captive_portal_detection_enabled 0'
    ];
    const res = await adbDriver.executePipeline(cmds, undefined, { title: 'Cấu Hình Private DNS Google Cho App Ngân Hàng' });
    recordUserActivity('Cấu hình Private DNS Google cho App Ngân Hàng');
    setIsProcessing(false);
    if (res.success) {
      notify('Đã cấu hình DNS Google mã hóa an toàn! Tránh lỗi gián đoạn hoặc treo kết nối khi đăng nhập ứng dụng tài chính.');
    } else {
      notify('Lỗi khi cấu hình DNS bảo mật ngân hàng.');
    }
  };

  // 4. Bật lại chế độ nhà phát triển sau khi giao dịch xong
  const handleRestoreDevMode = async () => {
    if (!isConnected || isProcessing) return;
    setIsProcessing(true);
    const cmds = [
      'settings put global development_settings_enabled 1',
      'settings put global adb_enabled 1'
    ];
    const res = await adbDriver.executePipeline(cmds, undefined, { title: 'Khôi Phục Lại Chế Độ Nhà Phát Triển' });
    recordUserActivity('Khôi phục chế độ nhà phát triển sau khi sửa lỗi ngân hàng');
    setIsProcessing(false);
    if (res.success) {
      notify('Đã khôi phục lại Chế độ nhà phát triển thành công.');
    } else {
      notify('Lỗi khi khôi phục Chế độ nhà phát triển.');
    }
  };

  return (
    <div className="rounded-2xl border border-cyan-500/20 bg-[#111A2E]/90 backdrop-blur-xl p-4 sm:p-6 shadow-xl relative overflow-hidden space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-cyan-500/15 gap-4">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 rounded-xl bg-gradient-to-tr from-emerald-500/20 to-teal-500/20 border border-emerald-500/30 text-emerald-400">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h3 className="text-base sm:text-lg font-bold text-white tracking-wide">
                Khắc Phục Lỗi App Ngân Hàng &amp; Ứng Dụng Tài Chính
              </h3>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold uppercase">
                An Toàn 100%
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Xử lý triệt để lỗi ngân hàng từ chối hoạt động do phát hiện Chế độ nhà phát triển, Trợ năng hoặc Quản lý ứng dụng
            </p>
          </div>
        </div>
      </div>

      {successMsg && (
        <div className="p-3.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-semibold flex items-center space-x-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Nút & Kết quả Quét Chẩn Đoán An Toàn Bảo Mật */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/30 via-slate-900/60 to-[#0A0F1D] border border-emerald-500/30 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
              <Activity className="w-4 h-4 text-emerald-400" />
            </div>
            <div>
              <div className="text-xs font-bold text-white flex items-center space-x-2">
                <span>Chẩn Đoán Toàn Diện Rủi Ro Bảo Mật Ứng Dụng</span>
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 font-mono">Chuẩn Google</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Kiểm tra cờ test-keys, debuggable, trạng thái Bootloader lock, mock location và chữ ký root.
              </p>
            </div>
          </div>

          <button
            onClick={handleScanBankSecurity}
            disabled={!isConnected || isScanning}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-black text-xs font-extrabold flex items-center justify-center space-x-1.5 transition-all shadow-md shadow-emerald-500/20 disabled:opacity-40 shrink-0"
          >
            {isScanning ? (
              <>
                <div className="w-3.5 h-3.5 border-2 border-black border-t-transparent rounded-full animate-spin" />
                <span>Đang quét...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-3.5 h-3.5" />
                <span>Quét An Toàn Bảo Mật Hệ Thống</span>
              </>
            )}
          </button>
        </div>

        {/* Bảng báo cáo kết quả quét */}
        {securityReport && (
          <div className="p-3.5 rounded-xl bg-[#080D1A] border border-cyan-500/20 text-xs space-y-2.5 animate-in fade-in">
            <div className="grid grid-cols-1 xs:grid-cols-2 sm:grid-cols-4 gap-2 font-mono text-[11px]">
              <div className="p-2 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Build Tags:</span>
                <span className={securityReport.isTestKeys ? 'text-rose-400 font-bold' : 'text-emerald-400 font-semibold'}>
                  {securityReport.buildTags || 'release-keys'}
                </span>
              </div>
              <div className="p-2 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Debuggable:</span>
                <span className={securityReport.isDebuggable ? 'text-rose-400 font-bold' : 'text-emerald-400 font-semibold'}>
                  {securityReport.isDebuggable ? '1 (Nguy hiểm)' : '0 (An toàn)'}
                </span>
              </div>
              <div className="p-2 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Bootloader:</span>
                <span className={securityReport.isBootloaderUnlocked ? 'text-amber-300 font-bold' : 'text-emerald-400 font-semibold'}>
                  {securityReport.isBootloaderUnlocked ? 'Unlocked (Mở khóa)' : 'Locked (Đã khóa)'}
                </span>
              </div>
              <div className="p-2 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Mock Location:</span>
                <span className={securityReport.isMockLocationOn ? 'text-amber-300 font-bold' : 'text-emerald-400 font-semibold'}>
                  {securityReport.isMockLocationOn ? 'Đang bật' : 'Đã tắt (0)'}
                </span>
              </div>
            </div>

            <div className="pt-1 border-t border-slate-800 space-y-1">
              <span className="text-cyan-300 font-bold text-[11px] block">Khuyến nghị kỹ thuật chuẩn mực:</span>
              {securityReport.recommendations.map((rec, i) => (
                <div key={i} className="text-slate-300 text-[11px] flex items-start space-x-1.5">
                  <span className="text-emerald-400 font-bold">•</span>
                  <span>{rec}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Grid các tính năng sửa lỗi ngân hàng */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Module 1: Ẩn Chế Độ Nhà Phát Triển & Accessibility */}
        <div className="p-4 rounded-xl bg-[#0A0F1D] border border-cyan-500/20 flex flex-col justify-between space-y-3">
          <div>
            <div className="flex items-center space-x-2 text-cyan-400 font-bold text-xs mb-1">
              <Lock className="w-4 h-4" />
              <span>1. Ẩn Chế Độ Nhà Phát Triển (Bypass Dev Mode Check)</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Nhiều ứng dụng bảo mật và tài chính hiện nay tự động chặn không cho mở nếu máy đang bật &quot;Tùy chọn nhà phát triển&quot;. Tùy chọn này sẽ ẩn cờ phát hiện mà không làm mất gỡ lỗi cáp.
            </p>
          </div>
          <button
            onClick={handleHideDeveloperMode}
            disabled={!isConnected || isProcessing}
            className="w-full py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 text-black font-extrabold text-xs flex items-center justify-center space-x-1.5 transition-all disabled:opacity-40"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-black" />
            <span>Ẩn Cờ Nhà Phát Triển Để Mở App Ngân Hàng</span>
          </button>
        </div>

        {/* Module 2: Chặn App Ngân Hàng Quét Ứng Dụng (Chống phát hiện Root/Shizuku) */}
        <div className="p-4 rounded-xl bg-[#0A0F1D] border border-amber-500/20 flex flex-col justify-between space-y-3">
          <div>
            <div className="flex items-center space-x-2 text-amber-400 font-bold text-xs mb-1">
              <Layers className="w-4 h-4" />
              <span>2. Chặn Ngân Hàng Quét Ứng Dụng Khác (Privacy Shield)</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Tước quyền <code className="text-amber-300">GET_INSTALLED_APPS</code> của các app ngân hàng nhằm ngăn chúng quét tìm các ứng dụng nhạy cảm như Shizuku, MicroG, Termux hoặc Magisk trong máy bạn.
            </p>
          </div>
          <button
            onClick={handleHideRootSignatures}
            disabled={!isConnected || isProcessing}
            className="w-full py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-extrabold text-xs flex items-center justify-center space-x-1.5 transition-all disabled:opacity-40"
          >
            <Lock className="w-3.5 h-3.5 text-black" />
            <span>Chặn App Ngân Hàng Quét Danh Sách Ứng Dụng</span>
          </button>
        </div>

        {/* Module 3: Tối Ưu DNS Mạng An Toàn Cho Ngân Hàng */}
        <div className="p-4 rounded-xl bg-[#0A0F1D] border border-purple-500/20 flex flex-col justify-between space-y-3">
          <div>
            <div className="flex items-center space-x-2 text-purple-400 font-bold text-xs mb-1">
              <Activity className="w-4 h-4" />
              <span>3. Kích Hoạt DNS Mã Hóa Riêng Biệt (Bảo Mật Giao Dịch)</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Thiết lập DNS bảo mật qua máy chủ <code className="text-purple-300">dns.google</code> giúp chứng chỉ SSL/TLS của ngân hàng không bao giờ bị nghẽn mạng hay lỗi chứng thư bảo mật khi đăng nhập.
            </p>
          </div>
          <button
            onClick={handleFixNetworkSecurity}
            disabled={!isConnected || isProcessing}
            className="w-full py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center justify-center space-x-1.5 transition-all disabled:opacity-40"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Kích Hoạt DNS Riêng Tư Chuẩn Quốc Tế</span>
          </button>
        </div>

        {/* Module 4: Khôi Phục Lại Chế Độ Nhà Phát Triển */}
        <div className="p-4 rounded-xl bg-[#0A0F1D] border border-slate-700 flex flex-col justify-between space-y-3">
          <div>
            <div className="flex items-center space-x-2 text-slate-300 font-bold text-xs mb-1">
              <Unlock className="w-4 h-4 text-slate-400" />
              <span>4. Bật Lại Chế Độ Nhà Phát Triển (Khi Cần Dùng Tool Tiếp)</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Sau khi bạn đã hoàn thành chuyển tiền hoặc giao dịch ngân hàng xong, bạn có thể bấm nút này để kích hoạt lại toàn diện Menu Tùy chọn nhà phát triển.
            </p>
          </div>
          <button
            onClick={handleRestoreDevMode}
            disabled={!isConnected || isProcessing}
            className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center justify-center space-x-1.5 transition-all border border-slate-600 disabled:opacity-40"
          >
            <Unlock className="w-3.5 h-3.5 text-cyan-400" />
            <span>Khôi Phục Menu Nhà Phát Triển</span>
          </button>
        </div>
      </div>
    </div>
  );
};
