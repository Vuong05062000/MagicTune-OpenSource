'use client';

import React, { useState } from 'react';
import {
  Car,
  BatteryCharging,
  LayoutGrid,
  Wifi,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Gauge,
  Flame,
  Zap
} from 'lucide-react';
import { HonorAdbScripts } from '@/lib/adb/honor-scripts';
import { adbDriver } from '@/lib/adb/web-usb-driver';
import { recordUserActivity } from '@/lib/firebase/config';

interface GlobalBugFixerProps {
  isConnected: boolean;
}

export const GlobalBugFixer: React.FC<GlobalBugFixerProps> = ({ isConnected }) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const notify = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(null), 5000);
  };

  // 1. Sửa lỗi Android Auto
  const handleFixAndroidAuto = async () => {
    if (!isConnected || isProcessing) return;
    setIsProcessing(true);
    const cmds = HonorAdbScripts.getFixAndroidAutoCommands();
    const res = await adbDriver.executePipeline(cmds);
    setIsProcessing(false);
    if (res.success) {
      recordUserActivity('Sửa lỗi kết nối Android Auto trên ô tô');
      notify('Đã cấp quyền chạy ngầm vĩnh viễn và đưa Android Auto vào whitelist của MagicOS! Hãy cắm lại cáp ô tô để kiểm tra.');
    } else {
      notify(`Cấu hình Android Auto hoàn tất với ${res.errors.length} cảnh báo. Xem log Terminal.`);
    }
  };

  // 2. Sửa lỗi hao pin & nóng máy sau cập nhật (bg-dexopt)
  const handleFixBatteryDrain = async () => {
    if (!isConnected || isProcessing) return;
    setIsProcessing(true);
    const cmds = HonorAdbScripts.getFixPostUpdateBatteryDrainCommands();
    const res = await adbDriver.executePipeline(cmds);
    setIsProcessing(false);
    if (res.success) {
      recordUserActivity('Kích hoạt Dexopt tối ưu hao pin sau cập nhật MagicOS');
      notify('Đã kích hoạt biên dịch tối ưu Dexopt và dọn dẹp bộ quản lý nguồn! Máy sẽ hạ nhiệt và pin ổn định trở lại sau vài phút.');
    } else {
      notify('Lỗi khi kích hoạt biên dịch tối ưu Dexopt.');
    }
  };

  // 3. Sửa giật lag Launcher & thanh thông báo
  const handleFixLauncher = async () => {
    if (!isConnected || isProcessing) return;
    setIsProcessing(true);
    const cmds = HonorAdbScripts.getFixLauncherStutterCommands();
    const res = await adbDriver.executePipeline(cmds);
    setIsProcessing(false);
    if (res.success) {
      recordUserActivity('Tối ưu bộ nhớ đệm MagicOS Launcher');
      notify('Đã dọn dẹp bộ nhớ đệm và gán ưu tiên tối đa cho Launcher MagicOS! Giao diện vuốt về Home và Trung tâm điều khiển sẽ cực mượt.');
    } else {
      notify('Lỗi khi dọn dẹp bộ nhớ đệm Launcher.');
    }
  };

  // 4. Sửa lỗi mạng di động & Wi-Fi chập chờn
  const handleFixNetwork = async () => {
    if (!isConnected || isProcessing) return;
    setIsProcessing(true);
    const cmds = HonorAdbScripts.getFixNetworkInstabilityCommands();
    const res = await adbDriver.executePipeline(cmds);
    setIsProcessing(false);
    if (res.success) {
      recordUserActivity('Tối ưu kết nối mạng Wi-Fi và 4G/5G');
      notify('Đã tối ưu hóa kết nối mạng, loại bỏ kiểm tra captive portal làm chậm mạng và giữ kết nối 4G/5G liên tục!');
    } else {
      notify('Lỗi khi tối ưu kết nối mạng.');
    }
  };

  // 1-Chạm sửa toàn bộ 4 lỗi phổ biến
  const handleFixAllGlobalBugs = async () => {
    if (!isConnected || isProcessing) return;
    setIsProcessing(true);
    const allCmds = [
      ...HonorAdbScripts.getFixAndroidAutoCommands(),
      ...HonorAdbScripts.getFixPostUpdateBatteryDrainCommands(),
      ...HonorAdbScripts.getFixLauncherStutterCommands(),
      ...HonorAdbScripts.getFixNetworkInstabilityCommands()
    ];
    const res = await adbDriver.executePipeline(allCmds);
    setIsProcessing(false);
    if (res.success) {
      recordUserActivity('1-Chạm Khắc Phục Lỗi Toàn Cầu MagicOS (Android Auto, Hao Pin, Lag Launcher)');
      notify('Hoàn tất! Đã xử lý toàn bộ các lỗi: Android Auto ngắt kết nối, hao pin sau cập nhật, lag launcher và chập chờn mạng.');
    } else {
      notify(`Đã chạy 1-chạm sửa lỗi toàn cầu với ${res.errors.length} cảnh báo. Xem log Terminal.`);
    }
  };

  return (
    <div className="rounded-2xl border border-cyan-500/20 bg-[#111A2E]/90 backdrop-blur-xl p-4 sm:p-6 shadow-xl relative overflow-hidden">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-cyan-500/15 gap-4">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 rounded-xl bg-gradient-to-tr from-amber-500/20 to-rose-500/20 border border-amber-500/30 text-amber-400">
            <Flame className="w-5 h-5 text-amber-400" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h3 className="text-base sm:text-lg font-bold text-white tracking-wide">
                Đặc Trị Các Lỗi Hệ Thống Android &amp; ROM Nội Địa Phổ Biến
              </h3>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 font-semibold">
                XDA &amp; Reddit
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Giải quyết triệt để lỗi Android Auto ô tô, hao pin nóng máy sau update, giật lag Launcher và rớt mạng Wi-Fi/4G
            </p>
          </div>
        </div>

        <button
          onClick={handleFixAllGlobalBugs}
          disabled={!isConnected || isProcessing}
          className="w-full md:w-auto px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 via-orange-500 to-rose-500 hover:from-amber-300 hover:to-rose-400 text-black font-extrabold text-xs flex items-center justify-center space-x-2 transition-all shadow-lg shadow-amber-500/20 disabled:opacity-40 hover:scale-[1.02] active:scale-[0.98]"
        >
          <Zap className="w-4 h-4 fill-black" />
          <span>1-Chạm Khắc Phục Toàn Diện 4 Lỗi</span>
        </button>
      </div>

      {successMsg && (
        <div className="my-4 px-4 py-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-semibold flex items-center space-x-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Grid danh sách 4 tính năng */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 my-5">
        {/* 1. Android Auto */}
        <div className="p-4 rounded-xl bg-[#0A0F1D]/80 border border-cyan-500/15 flex flex-col justify-between">
          <div>
            <div className="flex items-center space-x-2 text-cyan-400 font-semibold text-xs mb-1.5">
              <Car className="w-4 h-4 text-[#00F0FF]" />
              <span>1. Sửa Lỗi Android Auto Mất Kết Nối / Văng Xe Hơi</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed mb-3">
              MagicOS thường ngắt tiến trình ngầm <code className="text-cyan-300 font-mono">gearhead</code> khiến xe hơi không nhận màn hình hoặc chập chờn không dây. Lệnh này sẽ đưa app vào Whitelist vĩnh viễn và ép mức ưu tiên ACTIVE.
            </p>
          </div>
          <button
            onClick={handleFixAndroidAuto}
            disabled={!isConnected || isProcessing}
            className="w-full py-2 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 text-[#00F0FF] border border-cyan-500/30 text-xs font-semibold transition-all disabled:opacity-40"
          >
            Sửa Kết Nối Android Auto
          </button>
        </div>

        {/* 2. Hao pin & Nóng máy sau cập nhật */}
        <div className="p-4 rounded-xl bg-[#0A0F1D]/80 border border-cyan-500/15 flex flex-col justify-between">
          <div>
            <div className="flex items-center space-x-2 text-amber-400 font-semibold text-xs mb-1.5">
              <BatteryCharging className="w-4 h-4 text-amber-400" />
              <span>2. Đặc Trị Hao Pin &amp; Nóng Máy Sau Khi Cập Nhật Hệ Thống / ROM</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed mb-3">
              Sau khi nâng cấp ROM, máy thường tụt pin do hệ thống chạy ngầm biên dịch bytecode. Kích hoạt <code className="text-amber-300 font-mono">bg-dexopt-job</code> dọn dẹp cache nguồn ngầm, giúp máy mát lạnh và tiết kiệm pin mà <strong>không làm chậm thông báo</strong>.
            </p>
          </div>
          <button
            onClick={handleFixBatteryDrain}
            disabled={!isConnected || isProcessing}
            className="w-full py-2 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-semibold transition-all disabled:opacity-40"
          >
            Tối Ưu Pin &amp; Làm Mát Không Chậm Thông Báo
          </button>
        </div>

        {/* 3. Giật lag Launcher & Trung tâm điều khiển */}
        <div className="p-4 rounded-xl bg-[#0A0F1D]/80 border border-cyan-500/15 flex flex-col justify-between">
          <div>
            <div className="flex items-center space-x-2 text-purple-400 font-semibold text-xs mb-1.5">
              <LayoutGrid className="w-4 h-4 text-purple-400" />
              <span>3. Khắc Phục Đơ / Giật Lag Launcher &amp; Thư Mục Lớn</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed mb-3">
              Khắc phục lỗi giật khung hình khi vuốt trở về màn hình chính hoặc khi mở thanh Control Center lúc đang xem video toàn màn hình. Cân chỉnh tỷ lệ hiệu ứng mượt mà 1.0x.
            </p>
          </div>
          <button
            onClick={handleFixLauncher}
            disabled={!isConnected || isProcessing}
            className="w-full py-2 rounded-lg bg-purple-500/10 hover:bg-purple-500/20 text-purple-300 border border-purple-500/30 text-xs font-semibold transition-all disabled:opacity-40"
          >
            Tối Ưu Mượt Màn Hình Chính
          </button>
        </div>

        {/* 4. Mạng Wi-Fi & 4G/5G chập chờn */}
        <div className="p-4 rounded-xl bg-[#0A0F1D]/80 border border-cyan-500/15 flex flex-col justify-between">
          <div>
            <div className="flex items-center space-x-2 text-emerald-400 font-semibold text-xs mb-1.5">
              <Wifi className="w-4 h-4 text-emerald-400" />
              <span>4. Sửa Lỗi Rớt Mạng Wi-Fi &amp; Chậm Dữ Liệu Di Động</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed mb-3">
              Vô hiệu hóa việc hệ thống tự kiểm tra Captive Portal Trung Quốc gây độ trễ tải mạng, đồng thời duy trì kết nối sóng di động liên tục không bị ngắt lúc tắt màn hình.
            </p>
          </div>
          <button
            onClick={handleFixNetwork}
            disabled={!isConnected || isProcessing}
            className="w-full py-2 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-semibold transition-all disabled:opacity-40"
          >
            Ổn Định Sóng &amp; Tốc Độ Mạng
          </button>
        </div>
      </div>
    </div>
  );
};
