'use client';

import React, { useState } from 'react';
import {
  Sparkles,
  Smartphone,
  PhoneCall,
  BellRing,
  Globe,
  ShieldCheck,
  CheckCircle2,
  Copy,
  ExternalLink,
  Layers,
  Settings,
  Battery,
  AlertTriangle,
  Zap,
  ArrowRight
} from 'lucide-react';
import { recordUserActivity } from '@/lib/firebase/config';

export const DirectOnDeviceFixer: React.FC = () => {
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [successNote, setSuccessNote] = useState<string | null>(null);

  const handleCopyCode = (code: string, label: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setSuccessNote(`Đã sao chép mã ${label}! Hãy mở ứng dụng Điện Thoại (Bàn phím quay số) và dán mã.`);
    setTimeout(() => setCopiedCode(null), 3000);
    setTimeout(() => setSuccessNote(null), 5000);
  };

  const handleDialCode = (code: string, label: string) => {
    window.location.href = `tel:${encodeURIComponent(code)}`;
    setSuccessNote(`Đang mở ứng dụng Điện Thoại với mã ${label} (${code})...`);
    setTimeout(() => setSuccessNote(null), 4000);
  };

  const handleOpenAppInfo = (pkg: string, name: string) => {
    window.location.href = `intent:#Intent;action=android.settings.APPLICATION_DETAILS_SETTINGS;data=package:${pkg};end`;
    setSuccessNote(`Đang mở trang cài đặt chi tiết cho ${name} để bạn cấu hình Pin & Thông Báo...`);
    setTimeout(() => setSuccessNote(null), 4000);
  };

  const handleOpenBatterySettings = () => {
    window.location.href = 'intent:#Intent;action=android.settings.IGNORE_BATTERY_OPTIMIZATION_SETTINGS;end';
  };

  const handleOpenNotificationSettings = () => {
    window.location.href = 'intent:#Intent;action=android.settings.ALL_APPS_NOTIFICATION_SETTINGS;end';
  };

  return (
    <div className="rounded-2xl border border-emerald-500/30 bg-[#111A2E]/90 backdrop-blur-xl p-6 shadow-xl relative overflow-hidden space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-emerald-500/20 gap-4">
        <div className="flex items-center space-x-3">
          <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
            <Sparkles className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h3 className="text-lg font-bold text-white tracking-wide">
                Fix Trực Tiếp Trên Thiết Bị (Không Cần Bật Nhà Phát Triển / ADB)
              </h3>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
                1-Chạm Trên Máy
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Dành cho người dùng thông thường, người lớn tuổi hoặc khi không có sẵn máy tính cáp kết nối
            </p>
          </div>
        </div>
      </div>

      {successNote && (
        <div className="p-3.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-semibold flex items-center space-x-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{successNote}</span>
        </div>
      )}

      {/* Giải thích kỹ thuật & Cơ chế hoạt động */}
      <div className="p-4 rounded-xl bg-cyan-950/30 border border-cyan-500/20 text-xs space-y-2">
        <div className="flex items-center space-x-2 text-cyan-300 font-bold">
          <AlertTriangle className="w-4 h-4 text-cyan-400 shrink-0" />
          <span>Nguyên lý hoạt động của chế độ &quot;Fix Trực Tiếp Không ADB&quot;:</span>
        </div>
        <p className="text-slate-300 text-[11px] leading-relaxed">
          Theo tiêu chuẩn bảo mật <strong>Android Sandbox</strong>, không một website hay ứng dụng thông thường nào được phép tự ý thay đổi cài đặt hệ thống ngầm nếu không có quyền ADB hoặc Shizuku. Vì vậy, các nút bên dưới hoạt động qua giao thức <strong>Deep Link Intent cấp hệ thống</strong>: đưa bạn tới đúng trang cài đặt của từng app (Zalo, Messenger, Gmail) hoặc mở sẵn bàn phím gọi mã USSD chỉ với <strong>1 cú chạm</strong>.
        </p>
        <div className="text-[10px] text-amber-300 font-mono">
          💡 Muốn MagicTune tự động chạy lệnh ngầm 100% không cần thao tác tay? Hãy dùng <strong>Mục 3: Cầu Nối Shizuku</strong> hoặc kết nối cáp USB với máy tính.
        </div>
      </div>

      {/* Grid 4 Module Fix Trực Tiếp */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Module 1: Mã Secret Code Mở Menu Kỹ Thuật (Project Menu) */}
        <div className="p-5 rounded-2xl bg-[#0A0F1D]/80 border border-cyan-500/20 space-y-3 flex flex-col justify-between">
          <div>
            <div className="flex items-center space-x-2 text-cyan-400 font-bold text-sm mb-1.5">
              <PhoneCall className="w-4 h-4" />
              <span>1. Mã Lệnh Kỹ Thuật Honor Project Menu</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed mb-3">
              Mở trực tiếp bảng điều khiển phần cứng ẩn của Honor để kiểm tra sóng, mở khóa VoLTE / VoWiFi và chẩn đoán pin.
            </p>
            <div className="p-3 rounded-xl bg-[#111A2E] border border-cyan-500/30 font-mono text-cyan-300 text-sm flex items-center justify-between">
              <span>*#*#2846579#*#*</span>
              <div className="flex items-center space-x-1.5">
                <button
                  onClick={() => handleDialCode('*#*#2846579#*#*', 'Project Menu')}
                  className="px-2.5 py-1 rounded-lg bg-gradient-to-r from-[#00F0FF] to-blue-500 text-black text-xs font-sans font-extrabold flex items-center space-x-1 active:scale-95 transition-all"
                >
                  <PhoneCall className="w-3 h-3 text-black" />
                  <span>Gọi Mã</span>
                </button>
                <button
                  onClick={() => handleCopyCode('*#*#2846579#*#*', 'Project Menu')}
                  className="px-2 py-1 rounded-lg bg-slate-800 text-slate-300 text-xs font-sans font-bold hover:bg-slate-700 transition-all"
                >
                  {copiedCode === '*#*#2846579#*#*' ? <CheckCircle2 className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                </button>
              </div>
            </div>
          </div>
          <div className="text-[11px] text-slate-400 italic">
            👉 <strong>Cách làm:</strong> Bấm nút <em>Gọi Mã</em> &gt; Điện thoại mở bàn phím gọi &gt; Chọn <em>Background Settings &gt; USB Ports Settings</em>.
          </div>
        </div>

        {/* Module 2: Mở Khóa Khởi Chạy Tự Động & Chạy Ngầm (Auto-launch Lock) */}
        <div className="p-5 rounded-2xl bg-[#0A0F1D]/80 border border-amber-500/20 space-y-3 flex flex-col justify-between">
          <div>
            <div className="flex items-center space-x-2 text-amber-400 font-bold text-sm mb-1.5">
              <BellRing className="w-4 h-4" />
              <span>2. Fix Thông Báo &quot;Khởi Chạy Ứng Dụng&quot; (App Launch)</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed mb-2">
              Chuyển quản lý pin của ứng dụng sang &quot;Không hạn chế&quot; để MagicOS không bao giờ tiêu diệt tiến trình nhận tin nhắn:
            </p>
            
            {/* 1-Tap App Settings Quick Launch */}
            <div className="space-y-1.5">
              <span className="text-[10px] text-amber-300 font-bold uppercase tracking-wider block">
                Mở nhanh trang cài đặt pin &amp; thông báo từng App:
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                <button
                  onClick={() => handleOpenAppInfo('com.zing.zalo', 'Zalo')}
                  className="p-1.5 rounded-lg bg-blue-600/20 border border-blue-500/40 text-blue-300 text-[11px] font-bold hover:bg-blue-600/30 active:scale-95 transition-all text-center"
                >
                  Zalo
                </button>
                <button
                  onClick={() => handleOpenAppInfo('com.facebook.orca', 'Messenger')}
                  className="p-1.5 rounded-lg bg-cyan-600/20 border border-cyan-500/40 text-cyan-300 text-[11px] font-bold hover:bg-cyan-600/30 active:scale-95 transition-all text-center"
                >
                  Messenger
                </button>
                <button
                  onClick={() => handleOpenAppInfo('com.facebook.katana', 'Facebook')}
                  className="p-1.5 rounded-lg bg-indigo-600/20 border border-indigo-500/40 text-indigo-300 text-[11px] font-bold hover:bg-indigo-600/30 active:scale-95 transition-all text-center"
                >
                  Facebook
                </button>
                <button
                  onClick={() => handleOpenAppInfo('com.google.android.gm', 'Gmail')}
                  className="p-1.5 rounded-lg bg-rose-600/20 border border-rose-500/40 text-rose-300 text-[11px] font-bold hover:bg-rose-600/30 active:scale-95 transition-all text-center"
                >
                  Gmail
                </button>
                <button
                  onClick={() => handleOpenAppInfo('org.telegram.messenger', 'Telegram')}
                  className="p-1.5 rounded-lg bg-sky-600/20 border border-sky-500/40 text-sky-300 text-[11px] font-bold hover:bg-sky-600/30 active:scale-95 transition-all text-center"
                >
                  Telegram
                </button>
                <button
                  onClick={handleOpenNotificationSettings}
                  className="p-1.5 rounded-lg bg-purple-600/20 border border-purple-500/40 text-purple-300 text-[11px] font-bold hover:bg-purple-600/30 active:scale-95 transition-all text-center"
                >
                  Tất Cả App
                </button>
              </div>
            </div>
          </div>

          <button
            onClick={handleOpenBatterySettings}
            className="w-full py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center justify-center space-x-2 active:scale-95 transition-all"
          >
            <Battery className="w-3.5 h-3.5" />
            <span>Mở Cài Đặt Tối Ưu Hóa Pin Toàn Hệ Thống</span>
          </button>
        </div>

        {/* Module 3: Khóa Đa Nhiệm Màn Hình Recents (App Lock) */}
        <div className="p-5 rounded-2xl bg-[#0A0F1D]/80 border border-purple-500/20 space-y-3 flex flex-col justify-between">
          <div>
            <div className="flex items-center space-x-2 text-purple-400 font-bold text-sm mb-1.5">
              <Layers className="w-4 h-4" />
              <span>3. Khóa Ứng Dụng Trong Trình Đa Nhiệm (Lock App)</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed mb-3">
              Tránh tình trạng khi bạn bấm nút &quot;Dọn dẹp rác&quot; hoặc &quot;Đóng tất cả ứng dụng&quot; làm tắt luôn Zalo, Telegram, Messenger.
            </p>
            <div className="p-3 rounded-xl bg-[#111A2E] border border-purple-500/30 text-xs text-purple-200 space-y-1">
              <p>1. Vuốt từ dưới lên giữ 1 giây để mở danh sách ứng dụng gần đây.</p>
              <p>2. Tìm thẻ Zalo / Facebook / Telegram.</p>
              <p>3. <strong>Vuốt nhẹ thẻ app xuống dưới</strong> để biểu tượng <strong className="text-amber-400">Ổ Khóa 🔒</strong> xuất hiện ở góc trên.</p>
            </div>
          </div>
          <div className="text-[11px] text-slate-400 italic">
            Khi có biểu tượng ổ khóa, hệ thống MagicOS sẽ không bao giờ tiêu diệt tiến trình nhận tin nhắn của bạn.
          </div>
        </div>

        {/* Module 4: Tắt Kiểm Tra Bảo Mật Cài APK Ngoài */}
        <div className="p-5 rounded-2xl bg-[#0A0F1D]/80 border border-rose-500/20 space-y-3 flex flex-col justify-between">
          <div>
            <div className="flex items-center space-x-2 text-rose-400 font-bold text-sm mb-1.5">
              <ShieldCheck className="w-4 h-4" />
              <span>4. Bỏ Qua Kiểm Tra Bảo Mật Nội Địa Khi Cài APK</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed mb-3">
              Máy Honor bản Trung thường cảnh báo &quot;Ứng dụng nguồn không xác định&quot; và đòi nhập mật khẩu Honor ID mỗi khi cài app.
            </p>
            <div className="p-3 rounded-xl bg-[#111A2E] border border-rose-500/30 text-xs text-slate-300 space-y-1">
              <p>1. Vào <strong>Cài đặt &gt; Bảo mật &gt; Cài đặt khác</strong>.</p>
              <p>2. Chọn <strong>Cài đặt ứng dụng từ nguồn bên ngoài</strong>.</p>
              <p>3. Chọn trình duyệt (Chrome / Cốc Cốc) &gt; Bật <strong>Cho phép</strong>.</p>
              <p>4. Tắt tùy chọn <strong>Kiểm tra an toàn ứng dụng</strong>.</p>
            </div>
          </div>

          <button
            onClick={() => {
              window.location.href = 'intent:#Intent;action=android.settings.SECURITY_SETTINGS;end';
            }}
            className="w-full py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 text-xs font-bold flex items-center justify-center space-x-2 active:scale-95 transition-all"
          >
            <Settings className="w-3.5 h-3.5" />
            <span>Mở Cài Đặt Bảo Mật Thiết Bị</span>
          </button>
        </div>
      </div>

      {/* Module 5: Mã Tra Cứu Thông Tin Phần Cứng Nhanh */}
      <div className="p-4 rounded-xl bg-[#0A0F1D] border border-slate-800 space-y-3">
        <h4 className="text-xs font-bold text-white flex items-center space-x-2">
          <Zap className="w-4 h-4 text-[#00F0FF]" />
          <span>Danh Mục Mã USSD Quay Số Nhanh Hỗ Trợ Mọi Dòng Máy:</span>
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
          <div className="p-3 rounded-xl bg-[#111A2E] border border-slate-700 flex items-center justify-between">
            <div>
              <span className="font-mono text-cyan-300 text-xs font-bold block">*#06#</span>
              <span className="text-[11px] text-slate-400">Kiểm tra IMEI &amp; SN</span>
            </div>
            <button
              onClick={() => handleDialCode('*#06#', 'Tra Cứu IMEI')}
              className="px-2.5 py-1 rounded-lg bg-cyan-500/20 text-cyan-300 text-xs font-bold active:scale-95 transition-all flex items-center space-x-1"
            >
              <PhoneCall className="w-3 h-3" />
              <span>Gọi</span>
            </button>
          </div>

          <div className="p-3 rounded-xl bg-[#111A2E] border border-slate-700 flex items-center justify-between">
            <div>
              <span className="font-mono text-purple-300 text-xs font-bold block">*#*#0000#*#*</span>
              <span className="text-[11px] text-slate-400">Phiên bản MagicOS</span>
            </div>
            <button
              onClick={() => handleDialCode('*#*#0000#*#*', 'Phiên Bản MagicOS')}
              className="px-2.5 py-1 rounded-lg bg-purple-500/20 text-purple-300 text-xs font-bold active:scale-95 transition-all flex items-center space-x-1"
            >
              <PhoneCall className="w-3 h-3" />
              <span>Gọi</span>
            </button>
          </div>

          <div className="p-3 rounded-xl bg-[#111A2E] border border-slate-700 flex items-center justify-between">
            <div>
              <span className="font-mono text-emerald-300 text-xs font-bold block">*#*#6130#*#*</span>
              <span className="text-[11px] text-slate-400">Thông tin sóng mạng &amp; Pin</span>
            </div>
            <button
              onClick={() => handleDialCode('*#*#6130#*#*', 'Thông Tin Mạng & Pin')}
              className="px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 text-xs font-bold active:scale-95 transition-all flex items-center space-x-1"
            >
              <PhoneCall className="w-3 h-3" />
              <span>Gọi</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
