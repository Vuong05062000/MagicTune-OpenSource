'use client';

import React, { useState } from 'react';
import {
  UploadCloud,
  FileCode,
  CheckCircle2,
  AlertTriangle,
  FolderOpen,
  Play,
  RotateCcw,
  ShieldCheck,
  FileCheck,
  Smartphone,
  Cpu,
  Layers,
  Sparkles
} from 'lucide-react';
import { adbDriver } from '@/lib/adb/web-usb-driver';
import { recordUserActivity } from '@/lib/firebase/config';
import { Pagination } from '@/components/common/Pagination';

interface WebApkInstallerProps {
  isConnected: boolean;
}

export const WebApkInstaller: React.FC<WebApkInstallerProps> = ({ isConnected }) => {
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [filePage, setFilePage] = useState(1);
  const filePageSize = 5;
  const [isInstalling, setIsInstalling] = useState(false);
  const [installProgress, setInstallProgress] = useState<string | null>(null);
  const [installLogs, setInstallLogs] = useState<string[]>([]);
  const [grantPermissions, setGrantPermissions] = useState(true);
  const [allowDowngrade, setAllowDowngrade] = useState(true);
  const [bypassVerification, setBypassVerification] = useState(true);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files).filter(
        (f) => f.name.endsWith('.apk') || f.name.endsWith('.apks') || f.name.endsWith('.xapk')
      );
      setSelectedFiles(files);
      setFilePage(1);
      setInstallLogs([]);
      setInstallProgress(null);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files) {
      const files = Array.from(e.dataTransfer.files).filter(
        (f) => f.name.endsWith('.apk') || f.name.endsWith('.apks') || f.name.endsWith('.xapk')
      );
      setSelectedFiles(files);
      setFilePage(1);
      setInstallLogs([]);
      setInstallProgress(null);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const startInstall = async () => {
    if (!isConnected) {
      setInstallProgress('Vui lòng kết nối điện thoại qua cáp USB trước khi cài đặt!');
      setTimeout(() => setInstallProgress(null), 5000);
      return;
    }
    if (selectedFiles.length === 0) {
      setInstallProgress('Vui lòng chọn ít nhất 1 tệp APK hoặc APKS từ máy tính!');
      setTimeout(() => setInstallProgress(null), 5000);
      return;
    }

    setIsInstalling(true);
    setInstallLogs([]);

    const flags = [];
    if (grantPermissions) flags.push('-g'); // Cấp tất cả quyền runtime
    if (allowDowngrade) flags.push('-d'); // Cho phép hạ phiên bản
    flags.push('-r'); // Giữ lại dữ liệu hiện có nếu nâng cấp

    const flagStr = flags.join(' ');

    for (let i = 0; i < selectedFiles.length; i++) {
      const file = selectedFiles[i];
      setInstallProgress(`Đang xử lý gói: ${file.name} (${i + 1}/${selectedFiles.length})...`);
      
      const isSplitApks = file.name.endsWith('.apks') || file.name.endsWith('.xapk');

      try {
        // Chuẩn hóa tên file an toàn cho đường dẫn Linux Android
        const safeFileName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
        const remotePath = `/data/local/tmp/${safeFileName}`;

        // Đẩy tệp nhị phân thực tế vào Android
        setInstallLogs((prev) => [
          ...prev,
          `[Nạp tệp] Đang đẩy tệp ${file.name} (${(file.size / (1024 * 1024)).toFixed(2)} MB) vào ${remotePath}...`
        ]);

        await adbDriver.pushFile(file, remotePath, (loaded, total) => {
          const percent = Math.round((loaded / total) * 100);
          setInstallProgress(`Đang tải lên ${file.name}: ${percent}% (${(loaded / (1024 * 1024)).toFixed(1)} / ${(total / (1024 * 1024)).toFixed(1)} MB)...`);
        });

        if (bypassVerification) {
          await adbDriver.executeCommand('settings put global verifier_verify_adb_installs 0');
          await adbDriver.executeCommand('settings put global package_verifier_enable 0');
        }

        // Tùy theo APK đơn lẻ hay Split APKs
        if (isSplitApks) {
          setInstallLogs((prev) => [
            ...prev,
            `[Cài đặt đa gói] pm install-create ${flagStr}...`
          ]);
          await adbDriver.executeCommand(`pm install-create ${flagStr}`);
          await adbDriver.executeCommand(`pm install-write 1 base "${remotePath}"`);
          await adbDriver.executeCommand(`pm install-commit 1`);
          setInstallLogs((prev) => [...prev, `[Kết quả] Cài đặt Split package hoàn tất!`]);
        } else {
          setInstallLogs((prev) => [
            ...prev,
            `[Cài đặt] Thực thi: pm install ${flagStr} "${remotePath}"`
          ]);
          const result = await adbDriver.executeCommand(`pm install ${flagStr} "${remotePath}"`);
          setInstallLogs((prev) => [...prev, `[Kết quả]: ${result || 'Thành công (Success)'}`]);
        }

        // Dọn dẹp tệp tạm sau khi cài
        await adbDriver.executeCommand(`rm -f "${remotePath}"`);

        // Làm mới launcher tức thì để icon ứng dụng vừa cài xuất hiện ngay lập tức trên màn hình chính (Không cần reboot)
        try {
          await adbDriver.executeCommand(
            'am force-stop com.hihonor.android.launcher 2>/dev/null || ' +
            'am force-stop com.huawei.android.launcher 2>/dev/null || ' +
            'am force-stop com.miui.home 2>/dev/null || ' +
            'am force-stop com.sec.android.app.launcher 2>/dev/null || ' +
            'am force-stop com.oppo.launcher 2>/dev/null || ' +
            'am force-stop com.vivo.launcher 2>/dev/null || true',
            { silent: true }
          );
        } catch (e) {}

        recordUserActivity('Cài đặt APK/APKS qua WebADB', file.name);
      } catch (err: any) {
        const errMsg = err.message || 'Cài đặt thất bại';
        let friendlyReason = errMsg;
        if (errMsg.includes('INSTALL_FAILED_ALREADY_EXISTS')) {
          friendlyReason = 'Ứng dụng đã tồn tại trên thiết bị nhưng có chữ ký khác hoặc xung đột dữ liệu cũ.';
        } else if (errMsg.includes('INSTALL_FAILED_INVALID_APK')) {
          friendlyReason = 'Tệp APK không hợp lệ, bị lỗi cấu trúc hoặc thiếu thư viện CPU (ABI) tương thích.';
        } else if (errMsg.includes('INSTALL_FAILED_OLDER_SDK')) {
          friendlyReason = 'Phiên bản Android trên điện thoại thấp hơn mức Android tối thiểu của tệp APK này.';
        } else if (errMsg.includes('INSTALL_FAILED_INSUFFICIENT_STORAGE')) {
          friendlyReason = 'Bộ nhớ trong của điện thoại đã đầy, không đủ dung lượng để cài đặt.';
        }
        setInstallLogs((prev) => [...prev, `[Lỗi] ${file.name}: ${friendlyReason}`]);
      }
    }

    setIsInstalling(false);
    setInstallProgress('Cài đặt hoàn tất! Ứng dụng đã xuất hiện ngay trên màn hình chính (Không cần khởi động lại máy).');
  };

  return (
    <div className="rounded-2xl border border-cyan-500/20 bg-[#111A2E]/90 backdrop-blur-xl p-4 sm:p-6 shadow-xl relative overflow-hidden space-y-6">
      {/* Tiêu đề */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-cyan-500/15 gap-4">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 rounded-xl bg-gradient-to-tr from-cyan-500/20 to-blue-500/20 border border-cyan-500/30 text-[#00F0FF]">
            <UploadCloud className="w-5 h-5 text-[#00F0FF]" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h3 className="text-base sm:text-lg font-bold text-white tracking-wide">
                Cài Tệp Từ Máy Tính (Trình Cài Đặt APK / APKS / XAPK Trực Tuyến)
              </h3>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-[#00F0FF] border border-cyan-500/30 font-bold uppercase">
                WebADB Direct
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Kéo thả hoặc chọn tệp .apk, .apks từ máy tính để cài trực tiếp vào điện thoại không cần phần mềm trung gian
            </p>
          </div>
        </div>
      </div>

      {/* Khu vực Drag & Drop */}
      <div
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        className="rounded-2xl border-2 border-dashed border-cyan-500/30 bg-[#0A0F1D]/80 hover:bg-[#0A0F1D] p-8 text-center transition-all cursor-pointer relative group"
      >
        <input
          type="file"
          multiple
          accept=".apk,.apks,.xapk"
          onChange={handleFileChange}
          className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
        />
        <div className="w-14 h-14 rounded-2xl bg-cyan-500/10 border border-cyan-500/25 text-[#00F0FF] flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform">
          <UploadCloud className="w-7 h-7" />
        </div>
        <h4 className="text-sm font-bold text-white mb-1">
          Kéo thả tệp APK hoặc nhấp để duyệt từ máy tính
        </h4>
        <p className="text-xs text-slate-400">
          Hỗ trợ cài đặt đơn lẻ hoặc hàng loạt tệp <span className="text-cyan-300 font-mono">.apk</span>, <span className="text-purple-300 font-mono">.apks</span> (Split APKs), <span className="text-emerald-300 font-mono">.xapk</span>
        </p>

        {selectedFiles.length > 0 && (
          <div className="mt-4 pt-4 border-t border-slate-800 text-left">
            <div className="text-xs font-bold text-cyan-300 mb-2 flex items-center justify-between">
              <span>Đã chọn {selectedFiles.length} tệp:</span>
              <span className="text-slate-400 font-normal">
                Tổng: {(selectedFiles.reduce((acc, f) => acc + f.size, 0) / (1024 * 1024)).toFixed(2)} MB
              </span>
            </div>
            <div className="space-y-1.5 font-mono text-xs">
              {selectedFiles
                .slice((filePage - 1) * filePageSize, filePage * filePageSize)
                .map((file, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between px-3 py-1.5 rounded-lg bg-[#111A2E] border border-slate-800 text-slate-200"
                >
                  <span className="truncate pr-2">{file.name}</span>
                  <span className="text-slate-400 text-[11px] shrink-0">
                    {(file.size / (1024 * 1024)).toFixed(1)} MB
                  </span>
                </div>
              ))}
            </div>

            <Pagination
              currentPage={filePage}
              totalItems={selectedFiles.length}
              pageSize={filePageSize}
              onPageChange={(page) => setFilePage(page)}
              className="mt-2"
            />
          </div>
        )}
      </div>

      {/* Tùy chọn cài đặt cấp cao */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 rounded-xl bg-[#0A0F1D] border border-slate-800 text-xs">
        <label className="flex items-center space-x-2.5 cursor-pointer text-slate-300">
          <input
            type="checkbox"
            checked={grantPermissions}
            onChange={(e) => setGrantPermissions(e.target.checked)}
            className="w-4 h-4 accent-cyan-400 cursor-pointer"
          />
          <div>
            <div className="font-semibold text-white">Tự cấp quyền runtime (-g)</div>
            <div className="text-[10px] text-slate-500">Tự bật thông báo, bộ nhớ, camera</div>
          </div>
        </label>

        <label className="flex items-center space-x-2.5 cursor-pointer text-slate-300">
          <input
            type="checkbox"
            checked={allowDowngrade}
            onChange={(e) => setAllowDowngrade(e.target.checked)}
            className="w-4 h-4 accent-cyan-400 cursor-pointer"
          />
          <div>
            <div className="font-semibold text-white">Cho phép hạ phiên bản (-d)</div>
            <div className="text-[10px] text-slate-500">Cài đè không cần gỡ bản mới hơn</div>
          </div>
        </label>

        <label className="flex items-center space-x-2.5 cursor-pointer text-slate-300">
          <input
            type="checkbox"
            checked={bypassVerification}
            onChange={(e) => setBypassVerification(e.target.checked)}
            className="w-4 h-4 accent-cyan-400 cursor-pointer"
          />
          <div>
            <div className="font-semibold text-white">Tắt quét an ninh nội địa</div>
            <div className="text-[10px] text-slate-500">Tránh Google/ROM chặn tệp mod</div>
          </div>
        </label>
      </div>

      {/* Nút hành động */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
        <div className="text-xs text-slate-400">
          {installProgress && (
            <span className="font-bold text-cyan-300 flex items-center space-x-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>{installProgress}</span>
            </span>
          )}
        </div>

        <button
          onClick={startInstall}
          disabled={!isConnected || isInstalling || selectedFiles.length === 0}
          className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#00F0FF] via-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-extrabold text-xs flex items-center justify-center space-x-2 shadow-lg shadow-cyan-500/20 disabled:opacity-40 transition-all"
        >
          {isInstalling ? (
            <>
              <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
              <span>Đang cài đặt vào điện thoại...</span>
            </>
          ) : (
            <>
              <Play className="w-4 h-4 fill-black" />
              <span>Bắt Đầu Cài Vào Điện Thoại</span>
            </>
          )}
        </button>
      </div>

      {/* Console log kết quả */}
      {installLogs.length > 0 && (
        <div className="rounded-xl bg-[#0A0F1D] border border-slate-800 p-3.5 font-mono text-[11px] text-cyan-300 space-y-1 max-h-48 overflow-y-auto">
          {installLogs.map((log, i) => (
            <div key={i}>{log}</div>
          ))}
        </div>
      )}
    </div>
  );
};
