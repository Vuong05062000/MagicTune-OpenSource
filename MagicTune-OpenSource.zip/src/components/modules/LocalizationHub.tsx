'use client';

import React, { useState } from 'react';
import {
  Globe,
  Download,
  CheckCircle2,
  ShieldAlert,
  Keyboard,
  Languages,
  FileCheck,
  Sparkles,
  ShieldCheck
} from 'lucide-react';
import { VERIFIED_APK_LIST } from '@/lib/firebase/config';
import { HonorAdbScripts } from '@/lib/adb/honor-scripts';
import { adbDriver } from '@/lib/adb/web-usb-driver';
import { Pagination } from '@/components/common/Pagination';

interface LocalizationHubProps {
  isConnected: boolean;
  gmsInstalled?: boolean;
  customApks?: any[];
}

export const LocalizationHub: React.FC<LocalizationHubProps> = ({
  isConnected,
  gmsInstalled = false,
  customApks = []
}) => {
  const [apkPage, setApkPage] = useState(1);
  const apkPageSize = 6;
  const [isGrantingLocale, setIsGrantingLocale] = useState(false);
  const [localeGranted, setLocaleGranted] = useState(false);
  const [isSettingGboard, setIsSettingGboard] = useState(false);
  const [gboardSet, setGboardSet] = useState(false);
  const [isActivatingGms, setIsActivatingGms] = useState(false);
  const [gmsActivated, setGmsActivated] = useState(false);
  const [installingApkId, setInstallingApkId] = useState<string | null>(null);
  const [installSuccessMessage, setInstallSuccessMessage] = useState<string | null>(null);

  const handleGrantMoreLocale = async () => {
    if (!isConnected || isGrantingLocale) return;
    setIsGrantingLocale(true);
    const cmds = HonorAdbScripts.getMoreLocaleGrantCommands();
    const res = await adbDriver.executePipeline(cmds);
    setIsGrantingLocale(false);
    if (res.success) {
      setLocaleGranted(true);
      setTimeout(() => setLocaleGranted(false), 5000);
    }
  };

  const handleActivateGms = async () => {
    if (!isConnected || isActivatingGms) return;
    setIsActivatingGms(true);
    const cmds = HonorAdbScripts.getEnableGmsCommands();
    const res = await adbDriver.executePipeline(cmds);
    setIsActivatingGms(false);
    if (res.success) {
      setGmsActivated(true);
      setInstallSuccessMessage('Đã kích hoạt toàn bộ thành phần Google Play Services và Play Store! Với Xiaomi/Meizu, hãy vào Cài đặt -> Tài khoản bật thêm "Google Basic Services".');
      setTimeout(() => setGmsActivated(false), 6000);
    }
  };

  const handleSetupGboard = async () => {
    if (!isConnected || isSettingGboard) return;
    setIsSettingGboard(true);
    const cmds = HonorAdbScripts.getGboardSetupCommands();
    const res = await adbDriver.executePipeline(cmds);
    setIsSettingGboard(false);
    if (res.success) {
      setGboardSet(true);
      setTimeout(() => setGboardSet(false), 5000);
    }
  };

  const handleDirectInstallApk = async (apk: any) => {
    if (!isConnected) {
      setInstallSuccessMessage('Vui lòng cắm cáp kết nối điện thoại qua WebUSB / WebADB trước khi cài đặt trực tiếp!');
      setTimeout(() => setInstallSuccessMessage(null), 5000);
      return;
    }
    setInstallingApkId(apk.id);
    setInstallSuccessMessage(null);

    try {
      // 1. Tắt trình quét an ninh chặn cài đặt APK ngoài CH Play
      await adbDriver.executeCommand('settings put global verifier_verify_adb_installs 0');
      await adbDriver.executeCommand('settings put global package_verifier_enable 0');

      if (adbDriver.isSimulatedMode()) {
        const sanitizedName = apk.name.replace(/[^a-zA-Z0-9_-]/g, '_');
        await adbDriver.executeCommand(`pm install -r -d -g /data/local/tmp/${sanitizedName}.apk`);
        setInstallSuccessMessage(`[Giả Lập] Đã kích hoạt lệnh cài đặt mẫu cho ${apk.name}!`);
      } else {
        // Trên thiết bị thật: Hướng dẫn người dùng tải file và cài qua Mục 10 (Cài APK / APKS Web)
        setInstallSuccessMessage(`Đã tắt quét an ninh. Để nạp file vào máy thật, vui lòng dùng 'Mục 10: Cài APK / APKS Web' kéo thả tệp APK vào.`);
      }
      setTimeout(() => setInstallSuccessMessage(null), 6000);
    } catch (err: any) {
      setInstallSuccessMessage(`Không thể cài đặt tự động: ${err.message || 'Lỗi không xác định'}. Bạn có thể tải file về máy và cài.`);
      setTimeout(() => setInstallSuccessMessage(null), 6000);
    } finally {
      setInstallingApkId(null);
    }
  };

  // Hợp nhất danh sách mặc định và danh sách do Admin thêm
  const allApks = [...VERIFIED_APK_LIST, ...(customApks || [])];

  return (
    <div className="rounded-2xl border border-cyan-500/20 bg-[#111A2E]/90 backdrop-blur-xl p-6 shadow-xl relative overflow-hidden">
      {/* Tiêu đề */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-cyan-500/15 gap-4">
        <div className="flex items-center space-x-2.5">
          <div className="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-[#00F0FF]">
            <Globe className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white tracking-wide">
              Trình Quản Lý GMS, MicroG &amp; Việt Hóa Toàn Diện
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Tự động cấp quyền MoreLocale 2 việt hóa giao diện, đặt bàn phím Telex GBoard làm mặc định &amp; tải các gói APK tối ưu
            </p>
          </div>
        </div>

        {/* Trạng thái GMS */}
        <div
          className={`px-3 py-1.5 rounded-xl border text-xs font-semibold flex items-center space-x-1.5 ${
            gmsInstalled
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
              : 'bg-amber-500/10 border-amber-500/30 text-amber-300'
          }`}
        >
          {gmsInstalled ? (
            <>
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Dịch vụ Google (GMS) Đã Sẵn Sàng</span>
            </>
          ) : (
            <>
              <ShieldAlert className="w-4 h-4 text-amber-400" />
              <span>Chưa phát hiện Google Play Services</span>
            </>
          )}
        </div>
      </div>

      {/* 3 Khung cấp quyền & kích hoạt dịch vụ */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 my-5">
        {/* MoreLocale 2 & Monochrome */}
        <div className="rounded-xl border border-cyan-500/20 bg-[#0A0F1D]/80 p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center space-x-2 text-[#00F0FF] font-semibold text-sm mb-1.5">
              <Languages className="w-4 h-4" />
              <span>1-Chạm Việt Hóa Giao Diện (MoreLocale)</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed mb-3">
              Cấp quyền <code className="text-cyan-300">CHANGE_CONFIGURATION</code> và ép <code className="text-cyan-300">persist.sys.locale vi-VN</code>.
              <span className="block mt-1 text-[10px] text-amber-300/90 font-medium">
                * Ép hiển thị Tiếng Việt trên toàn bộ ứng dụng bên thứ 3 (Facebook, TikTok, Zalo...). Menu Cài đặt gốc vẫn giữ Tiếng Anh/Trung theo firmware.
              </span>
            </p>
          </div>

          <button
            onClick={handleGrantMoreLocale}
            disabled={!isConnected || isGrantingLocale}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#00F0FF] to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black text-xs font-extrabold flex items-center justify-center space-x-2 transition-all shadow-md shadow-cyan-500/20 disabled:opacity-40"
          >
            {isGrantingLocale ? (
              <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
            ) : localeGranted ? (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>Đã cấp quyền! Mở MoreLocale chọn Tiếng Việt</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Cấp Quyền Việt Hóa MoreLocale</span>
              </>
            )}
          </button>
        </div>

        {/* Kích hoạt GMS / Play Store */}
        <div className="rounded-xl border border-emerald-500/20 bg-[#0A0F1D]/80 p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center space-x-2 text-emerald-400 font-semibold text-sm mb-1.5">
              <ShieldCheck className="w-4 h-4" />
              <span>Kích Hoạt GMS &amp; Google Play Store</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed mb-3">
              Mở khóa các stub Google Services ẩn trên máy nội địa, bật Google Play Services và Play Store.
              <span className="block mt-1 text-[10px] text-slate-500 font-medium">
                * Hỗ trợ kích hoạt stub com.google.android.gms, cấp quyền đồng bộ tài khoản Google và mở khóa FCM Push.
              </span>
            </p>
          </div>

          <button
            onClick={handleActivateGms}
            disabled={!isConnected || isActivatingGms}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 text-black text-xs font-bold flex items-center justify-center space-x-2 transition-all shadow-md shadow-emerald-500/20 disabled:opacity-40"
          >
            {isActivatingGms ? (
              <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
            ) : gmsActivated ? (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>Đã kích hoạt GMS &amp; Play Store!</span>
              </>
            ) : (
              <>
                <ShieldCheck className="w-4 h-4" />
                <span>Kích Hoạt Dịch Vụ Google (GMS)</span>
              </>
            )}
          </button>
        </div>

        {/* Cài bàn phím GBoard */}
        <div className="rounded-xl border border-purple-500/20 bg-[#0A0F1D]/80 p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center space-x-2 text-purple-400 font-semibold text-sm mb-1.5">
              <Keyboard className="w-4 h-4" />
              <span>Kích Hoạt GBoard Mặc Định (Gõ Tiếng Việt)</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed mb-3">
              Kích hoạt bàn phím Google GBoard và đặt làm phương thức nhập liệu mặc định, thay thế bàn phím tiếng Trung nội địa (Baidu IME).
            </p>
          </div>

          <button
            onClick={handleSetupGboard}
            disabled={!isConnected || isSettingGboard}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-bold flex items-center justify-center space-x-2 transition-all shadow-md shadow-purple-900/30 disabled:opacity-40"
          >
            {isSettingGboard ? (
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : gboardSet ? (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>Đã kích hoạt GBoard mặc định thành công!</span>
              </>
            ) : (
              <>
                <Keyboard className="w-4 h-4" />
                <span>Bật &amp; Đặt GBoard Làm Mặc Định</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Thông báo cài đặt thành công */}
      {installSuccessMessage && (
        <div className="p-3.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-semibold flex items-center space-x-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{installSuccessMessage}</span>
        </div>
      )}

      {/* Kho APK chuẩn */}
      <div>
        <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3 flex items-center space-x-2">
          <FileCheck className="w-4 h-4 text-[#00F0FF]" />
          <span>Kho Tệp Cài Đặt (APK) Đã Được Kiểm Duyệt An Toàn</span>
        </h4>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {allApks
            .slice((apkPage - 1) * apkPageSize, apkPage * apkPageSize)
            .map((apk) => {
            const isThisInstalling = installingApkId === apk.id;
            return (
              <div
                key={apk.id}
                className="p-3.5 rounded-xl bg-[#0A0F1D]/80 border border-cyan-500/15 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-semibold text-xs text-slate-200">{apk.name}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-500/10 text-[#00F0FF] border border-cyan-500/20 font-mono">
                      v{apk.version}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed line-clamp-2 mb-2">
                    {apk.description}
                  </p>
                  <div className="text-[10px] text-slate-400 mb-2">
                    {apk.recommendedFor}
                  </div>
                </div>

                <div className="pt-2.5 border-t border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <span className="text-[11px] font-mono text-slate-400">{apk.size}</span>
                  <div className="flex items-center space-x-1.5">
                    {/* Chỉ hiện nút Cài Đặt Trực Tiếp khi Admin đã thêm file APK hoặc tệp có cờ cài đặt trực tiếp */}
                    {(apk.isDirectInstallable || apk.isCustom || apk.fileUrl || apk.directPath) && (
                      <button
                        onClick={() => handleDirectInstallApk(apk)}
                        disabled={!isConnected || isThisInstalling}
                        className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-lg bg-gradient-to-r from-emerald-500/20 to-teal-500/20 hover:from-emerald-500/30 hover:to-teal-500/30 text-emerald-300 text-xs font-bold border border-emerald-500/30 transition-all disabled:opacity-40"
                        title="Cài đặt thẳng vào máy không hỏi cảnh báo"
                      >
                        {isThisInstalling ? (
                          <>
                            <div className="w-3 h-3 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin" />
                            <span>Đang cài...</span>
                          </>
                        ) : (
                          <>
                            <Sparkles className="w-3 h-3 text-emerald-400" />
                            <span>Cài Trực Tiếp</span>
                          </>
                        )}
                      </button>
                    )}
                    <a
                      href={apk.downloadUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-lg bg-cyan-500/15 hover:bg-cyan-500/25 text-[#00F0FF] text-xs font-semibold border border-cyan-500/30 transition-all"
                    >
                      <Download className="w-3 h-3" />
                      <span>Tải Về</span>
                    </a>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Phân trang danh sách tệp APK */}
        <Pagination
          currentPage={apkPage}
          totalItems={allApks.length}
          pageSize={apkPageSize}
          onPageChange={(page) => setApkPage(page)}
          className="mt-4"
        />
      </div>
    </div>
  );
};
