'use client';

import React, { useState } from 'react';
import {
  Sparkles,
  Play,
  CheckCircle2,
  ExternalLink,
  Copy,
  Check,
  Zap,
  Radio,
  CheckCircle,
  Smartphone,
  Download,
  Wrench,
  ArrowRight
} from 'lucide-react';
import { HonorAdbScripts } from '@/lib/adb/honor-scripts';
import { adbDriver } from '@/lib/adb/web-usb-driver';

interface ShizukuWlanBridgeProps {
  isConnected: boolean;
  shizukuInstalled?: boolean;
}

export const ShizukuWlanBridge: React.FC<ShizukuWlanBridgeProps> = ({
  isConnected,
  shizukuInstalled = false
}) => {
  const [isStartingShizuku, setIsStartingShizuku] = useState(false);
  const [shizukuStarted, setShizukuStarted] = useState(false);
  const [copiedScript, setCopiedScript] = useState(false);
  const [copiedRishCmd, setCopiedRishCmd] = useState(false);
  const [downloadedScript, setDownloadedScript] = useState(false);
  const [statusBanner, setStatusBanner] = useState<{ type: 'success' | 'warning'; text: string } | null>(null);

  const showBanner = (type: 'success' | 'warning', text: string) => {
    setStatusBanner({ type, text });
    setTimeout(() => setStatusBanner(null), 7000);
  };

  const startShizukuCmd = `sh /storage/emulated/0/Android/data/moe.shizuku.privileged.api/start.sh`;
  
  // Script tối ưu hóa tổng hợp chạy trực tiếp qua Shizuku Shell (Rish)
  const fullRishOptimizationCmd = `rish -c "settings put global bastet_service_enable 0; settings put system peak_refresh_rate 120; settings put system min_refresh_rate 120; cmd appops set com.google.android.gms ACCESS_RESTRICTED_SETTINGS allow; pm grant com.google.android.gms android.permission.ACCESS_FINE_LOCATION; echo 'MagicTune: Hoàn tất tối ưu hóa Shizuku 100%!' "`;

  const handleOpenDevSettings = () => {
    window.location.href = 'intent:#Intent;action=android.settings.APPLICATION_DEVELOPMENT_SETTINGS;end';
  };

  const handleOpenShizukuApp = () => {
    window.location.href = 'intent://#Intent;package=moe.shizuku.privileged.api;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;end';
  };

  const handleCopyRishCommand = () => {
    navigator.clipboard.writeText(fullRishOptimizationCmd);
    setCopiedRishCmd(true);
    showBanner('success', 'Đã sao chép lệnh Shizuku / Rish 1-chạm! Hãy mở Termux hoặc App Manager dán lệnh để chạy ngay trên máy.');
    setTimeout(() => setCopiedRishCmd(false), 3000);
  };

  const handleDownloadShizukuScript = () => {
    const scriptContent = `#!/system/bin/sh
# ========================================================
# MAGICTUNE TOOL UNIVERSAL - SHIZUKU / RISH ONE-CLICK SCRIPT
# Tối ưu hóa trực tiếp trên 1 thiết bị Android qua Shizuku
# ========================================================

echo ">>> Bắt đầu tối ưu hóa thiết bị qua Shizuku..."

# 1. Tắt dịch vụ Bastet & PowerGenie ngắt ngầm thông báo
settings put global bastet_service_enable 0
settings put global smart_dual_card_enable 1
echo "[+] Đã vô hiệu hóa Bastet service"

# 2. Mở khóa màn hình mượt mà 120Hz & Tần số quét cao
settings put system peak_refresh_rate 120
settings put system min_refresh_rate 120
echo "[+] Đã cấu hình 120Hz mượt mà"

# 3. Cấp quyền đặc quyền cho dịch vụ Google Play (GMS)
cmd appops set com.google.android.gms ACCESS_RESTRICTED_SETTINGS allow
pm grant com.google.android.gms android.permission.ACCESS_FINE_LOCATION
echo "[+] Đã cấp quyền hoàn chỉnh cho GMS"

# 4. Gỡ bỏ quyền vị trí giả mạo (Fix lỗi ngân hàng phát hiện root/adb)
settings put secure mock_location 0
echo "[+] Đã khắc phục nhận diện ứng dụng ngân hàng"

echo ">>> TẤT CẢ TÁC VỤ HOÀN TẤT THÀNH CÔNG! KHÔNG CẦN KHỞI ĐỘNG LẠI."
`;
    const blob = new Blob([scriptContent], { type: 'text/x-sh' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'magictune_shizuku_optimize.sh';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    setDownloadedScript(true);
    showBanner('success', 'Đã tải xuống file magictune_shizuku_optimize.sh! Bạn có thể chạy file này trong ứng dụng Shizuku Runner, Termux hoặc App Manager.');
    setTimeout(() => setDownloadedScript(false), 4000);
  };

  const handleStartShizuku = async () => {
    if (!isConnected || isStartingShizuku) return;
    setIsStartingShizuku(true);
    const cmds = HonorAdbScripts.getStartShizukuCommands();
    const res = await adbDriver.executePipeline(cmds);

    // Xác minh tiến trình Shizuku đang chạy thực tế trên thiết bị
    let isProcessRunning = false;
    try {
      const psOutput = await adbDriver.executeCommand('ps -A | grep shizuku');
      isProcessRunning = psOutput.includes('shizuku') || psOutput.includes('moe.shizuku');
    } catch (e) {}

    setIsStartingShizuku(false);
    if (res.success || isProcessRunning) {
      setShizukuStarted(true);
      showBanner('success', 'Đã gửi lệnh & xác minh tiến trình Shizuku Server đang hoạt động thành công! Ứng dụng Shizuku trên máy đã sẵn sàng.');
      setTimeout(() => setShizukuStarted(false), 6000);
    } else {
      showBanner('warning', `Không thể kích hoạt Shizuku (${res.errors.length} lỗi). Vui lòng đảm bảo bạn đã cài đặt ứng dụng Shizuku trên máy.`);
    }
  };


  const handleCopyShizukuCmd = () => {
    navigator.clipboard.writeText(startShizukuCmd);
    setCopiedScript(true);
    setTimeout(() => setCopiedScript(false), 2000);
  };

  return (
    <div className="rounded-2xl border border-cyan-500/20 bg-[#111A2E]/90 backdrop-blur-xl p-6 shadow-xl relative overflow-hidden">
      {/* Tiêu đề Module */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-cyan-500/15 gap-4">
        <div className="flex items-center space-x-2.5">
          <div className="p-2.5 rounded-xl bg-purple-500/10 border border-[#8B5CF6]/30 text-[#8B5CF6]">
            <Radio className="w-5 h-5 text-[#8B5CF6]" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h3 className="text-lg font-bold text-white tracking-wide">
                Cầu Nối Shizuku Engine [Xingchen &amp; Rikka]
              </h3>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/20 text-[#8B5CF6] border border-purple-500/30 font-semibold uppercase">
                Kích Hoạt Qua Cáp USB
              </span>
              {shizukuInstalled && (
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-semibold flex items-center space-x-1">
                  <CheckCircle className="w-3 h-3 text-emerald-400" />
                  <span>Đã Cài Đặt Trên Thiết Bị</span>
                </span>
              )}
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Khởi chạy Shizuku Server qua cáp USB và tự động cấp quyền ADB cấp cao cho các ứng dụng hệ thống
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <a
            href="https://github.com/RikkaApps/Shizuku/releases"
            target="_blank"
            rel="noreferrer"
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center space-x-1.5 border border-slate-700 transition-all"
          >
            <ExternalLink className="w-3.5 h-3.5 text-[#00F0FF]" />
            <span>Tải Shizuku APK</span>
          </a>
        </div>
      </div>

      {/* Thông báo trạng thái phản hồi */}
      {statusBanner && (
        <div className={`mt-4 p-3.5 rounded-xl border text-xs font-semibold flex items-center space-x-2 animate-in fade-in ${
          statusBanner.type === 'success'
            ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-300'
            : 'bg-amber-500/15 border-amber-500/30 text-amber-300'
        }`}>
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{statusBanner.text}</span>
        </div>
      )}

      {/* KHỐI ĐẶC BIỆT: KÍCH HOẠT & SỬ DỤNG TRÊN CHÍNH CHIẾC ĐIỆN THOẠI NÀY (100% KHÔNG CẦN THIẾT BỊ THỨ 2) */}
      <div className="my-5 p-5 rounded-2xl bg-gradient-to-r from-purple-950/40 via-indigo-950/30 to-[#0A0F1D] border border-purple-500/30 space-y-4 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-purple-500/20">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-xl bg-purple-500/20 border border-purple-500/40 text-purple-300">
              <Smartphone className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h4 className="font-extrabold text-white text-sm">
                  Kích Hoạt Shizuku Trực Tiếp Trên 1 Máy (Không Cần Thiết Bị Thứ 2)
                </h4>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold">
                  Thao Tác Trực Tiếp
                </span>
              </div>
              <p className="text-[11px] text-slate-300">
                Thực hiện trực tiếp trên chính chiếc điện thoại Android đang mở trang web này
              </p>
            </div>
          </div>
        </div>

        {/* 2 Nút Intent mở nhanh */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          <button
            onClick={handleOpenDevSettings}
            className="p-3 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/35 text-cyan-300 text-xs font-bold flex items-center justify-center space-x-2 active:scale-95 transition-all shadow-sm shadow-cyan-500/10"
          >
            <Wrench className="w-4 h-4 text-[#00F0FF]" />
            <span>1. Mở Cài Đặt Gỡ Lỗi Wi-Fi Trên Máy</span>
          </button>
          <button
            onClick={handleOpenShizukuApp}
            className="p-3 rounded-xl bg-purple-500/20 hover:bg-purple-500/30 border border-purple-500/40 text-purple-300 text-xs font-bold flex items-center justify-center space-x-2 active:scale-95 transition-all shadow-sm shadow-purple-500/10"
          >
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span>2. Mở Ứng Dụng Shizuku Trên Máy</span>
          </button>
        </div>

        {/* Hướng dẫn 3 bước */}
        <div className="p-3.5 rounded-xl bg-[#0A0F1D]/90 border border-purple-500/20 text-xs space-y-2">
          <div className="font-bold text-purple-300 flex items-center space-x-1.5">
            <CheckCircle2 className="w-4 h-4 text-purple-400" />
            <span>Quy trình ghép nối 30 giây ngay trên màn hình:</span>
          </div>
          <ol className="list-decimal list-inside space-y-1.5 text-[11px] text-slate-300 leading-relaxed">
            <li>Bấm <strong>&quot;1. Mở Cài Đặt Gỡ Lỗi Wi-Fi&quot;</strong> &gt; Bật <em>Gỡ lỗi không dây</em> &gt; Nhấn <em>Ghép nối bằng mã ghép nối</em>.</li>
            <li>Hệ thống hiện mã 6 chữ số và thông báo của Shizuku xuất hiện trên thanh trạng thái.</li>
            <li>Bấm <strong>&quot;2. Mở Ứng Dụng Shizuku&quot;</strong> (hoặc kéo thông báo xuống) &gt; Nhập mã 6 số &gt; Shizuku chuyển sang trạng thái <strong>&quot;Running&quot;</strong>.</li>
          </ol>
        </div>

        {/* Tùy chọn thực thi 1-chạm sau khi Shizuku chạy */}
        <div className="p-3.5 rounded-xl bg-[#111A2E] border border-cyan-500/25 space-y-2.5">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-white flex items-center space-x-1.5">
              <Zap className="w-4 h-4 text-[#00F0FF]" />
              <span>Chạy toàn bộ tối ưu hóa MagicTune qua Shizuku:</span>
            </span>
            <span className="text-[10px] text-cyan-400 font-mono">1-Chạm Trên Máy</span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={handleCopyRishCommand}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#00F0FF] to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-extrabold text-xs flex items-center space-x-1.5 active:scale-95 transition-all shadow-md shadow-cyan-500/20"
            >
              {copiedRishCmd ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              <span>{copiedRishCmd ? 'Đã Sao Chép Lệnh Rish!' : 'Sao Chép Lệnh Rish 1-Chạm'}</span>
            </button>

            <button
              onClick={handleDownloadShizukuScript}
              className="px-3.5 py-2 rounded-xl bg-purple-500/20 hover:bg-purple-500/30 border border-purple-500/40 text-purple-300 font-bold text-xs flex items-center space-x-1.5 active:scale-95 transition-all"
            >
              <Download className="w-4 h-4 text-purple-400" />
              <span>{downloadedScript ? 'Đã Tải Script .sh!' : 'Tải File Script (.sh) Về Máy'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Grid 2 Thẻ chức năng chính */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 my-5">
        {/* Thẻ 1: Khởi động Shizuku tự động qua ADB */}
        <div className="rounded-xl border border-cyan-500/15 bg-[#0A0F1D]/80 p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center space-x-2 text-[#8B5CF6] text-sm font-semibold mb-2">
              <Sparkles className="w-4 h-4" />
              <span>1-Chạm Khởi Chạy Shizuku Server</span>
            </div>
            <p className="text-xs text-slate-400 mb-3 leading-relaxed">
              Sau khi cài ứng dụng Shizuku trên điện thoại Honor, chỉ cần bấm nút bên dưới, hệ thống sẽ tự động gọi file lệnh khởi động ngầm để Shizuku chuyển sang trạng thái <strong>&quot;Shizuku đang chạy (Running)&quot;</strong>.
            </p>

            <div className="p-3 rounded-lg bg-[#111A2E] border border-slate-800 text-xs font-mono text-slate-300 mb-4">
              <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1">
                <span>Lệnh kích hoạt khởi động:</span>
                <button
                  onClick={handleCopyShizukuCmd}
                  className="text-[#00F0FF] hover:underline flex items-center space-x-1"
                >
                  {copiedScript ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedScript ? 'Đã sao chép' : 'Sao chép'}</span>
                </button>
              </div>
              <code className="text-cyan-300 break-all">{startShizukuCmd}</code>
            </div>
          </div>

          <button
            onClick={handleStartShizuku}
            disabled={!isConnected || isStartingShizuku}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-bold flex items-center justify-center space-x-2 transition-all shadow-lg shadow-purple-900/30 disabled:opacity-40"
          >
            {isStartingShizuku ? (
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : shizukuStarted ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Đã gọi lệnh khởi chạy Shizuku thành công!</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-white" />
                <span>Kích Hoạt Shizuku Không Cần Máy Tính Lần Sau</span>
              </>
            )}
          </button>
        </div>

        {/* Thẻ 2: Tự Động Quét & Cấp Quyền Shizuku Cho Các Ứng Dụng Bên Thứ Ba */}
        <div className="rounded-xl border border-purple-500/25 bg-[#0A0F1D]/80 p-4 flex flex-col justify-between space-y-3">
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2 text-purple-300 text-sm font-semibold">
                <Sparkles className="w-4 h-4 text-purple-400" />
                <span>Cấp Quyền Shizuku Tự Động</span>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/40 font-mono">
                App Manager, Canta...
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed mb-3">
              Tự động cấp quyền truy cập đặc quyền Shizuku cho các công cụ tối ưu hệ thống nổi tiếng mà không cần thao tác xác nhận thủ công từng ứng dụng.
            </p>
          </div>

          <button
            onClick={async () => {
              if (!isConnected) return;
              const tools = [
                'io.github.muntashirakon.AppManager',
                'com.catchingnow.icebox',
                'com.aurora.store',
                'samolego.canta',
                'org.swiftapps.swiftbackup',
                'com.rosan.dhizuku'
              ];
              const cmds: string[] = [];
              tools.forEach((pkg) => {
                cmds.push(`cmd appops set ${pkg} GET_INSTALLED_APPS allow`);
                cmds.push(`pm grant ${pkg} android.permission.POST_NOTIFICATIONS`);
              });
              await adbDriver.executePipeline(cmds);
              showBanner('success', 'Đã cấp quyền Shizuku đặc quyền thành công cho các ứng dụng hệ thống (App Manager, IceBox, Canta...)!');
            }}
            disabled={!isConnected}
            className="w-full py-2.5 rounded-xl bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border border-purple-500/40 text-xs font-bold transition-all flex items-center justify-center space-x-1.5 disabled:opacity-40"
          >
            <CheckCircle2 className="w-4 h-4 text-purple-400" />
            <span>1-Click Cấp Quyền Cho App Phụ Trợ</span>
          </button>
        </div>
      </div>
    </div>
  );
};
