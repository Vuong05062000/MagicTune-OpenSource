'use client';

import React, { useState } from 'react';
import {
  BellRing,
  Zap,
  CheckCircle2,
  RotateCcw,
  RotateCw,
  Check,
  Shield,
  Activity,
  Layers,
  Search,
  Scan,
  Sparkles,
  Flame,
  Filter,
  Leaf,
  BatteryCharging,
  AlertTriangle,
  AlertCircle,
  Smartphone,
  Cpu,
  ShieldCheck,
  Crown,
  Info,
  CreditCard
} from 'lucide-react';
import { COMMONLY_USED_VN_APPS, HonorAdbScripts, AppPackageInfo } from '@/lib/adb/honor-scripts';
import { adbDriver, PipelineResult } from '@/lib/adb/web-usb-driver';
import { Pagination } from '@/components/common/Pagination';
import { recordUserActivity } from '@/lib/firebase/config';
import { deviceDataCache } from '@/lib/cache/device-data-cache';

const isBankingApp = (pkg: string, name: string): boolean => {
  const lower = `${pkg} ${name}`.toLowerCase();
  return (
    lower.includes('bank') ||
    lower.includes('vcb') ||
    lower.includes('mb') ||
    lower.includes('bidv') ||
    lower.includes('techcom') ||
    lower.includes('vietin') ||
    lower.includes('acb') ||
    lower.includes('tpb') ||
    lower.includes('momo') ||
    lower.includes('zalopay')
  );
};

const isSocialApp = (pkg: string, name: string): boolean => {
  const lower = `${pkg} ${name}`.toLowerCase();
  return (
    lower.includes('facebook') ||
    lower.includes('orca') ||
    lower.includes('zalo') ||
    lower.includes('telegram') ||
    lower.includes('tiktok') ||
    lower.includes('whatsapp') ||
    lower.includes('viber') ||
    lower.includes('discord') ||
    lower.includes('teams') ||
    lower.includes('skype')
  );
};

interface NotificationFixerProps {
  isConnected: boolean;
  detectedBrandId?: string;
  isAdmin?: boolean;
}

export const NotificationFixer: React.FC<NotificationFixerProps> = ({ isConnected, detectedBrandId, isAdmin = false }) => {
  const initialCache = deviceDataCache.getNotificationData();
  const [appsList, setAppsList] = useState<AppPackageInfo[]>(
    initialCache?.appsList && initialCache.appsList.length > 0 ? initialCache.appsList : COMMONLY_USED_VN_APPS
  );
  const [selectedApps, setSelectedApps] = useState<string[]>(
    initialCache?.selectedApps || COMMONLY_USED_VN_APPS.filter((a) => a.isImportant).map((a) => a.package)
  );
  const [classificationTab, setClassificationTab] = useState<'user' | 'system'>('user');
  const [disableBastet, setDisableBastet] = useState(true);
  const [isFixing, setIsFixing] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [scanStatusText, setScanStatusText] = useState<string | null>(null);
  const [scanProgress, setScanProgress] = useState<number>(0);
  const [lastScannedTime, setLastScannedTime] = useState<string | null>(
    initialCache?.lastScannedTime || null
  );
  const isScanningRef = React.useRef(false);
  const hasAutoScannedRef = React.useRef(deviceDataCache.hasNotificationData());

  interface ExecutionProgressState {
    current: number;
    total: number;
    cmd: string;
    label?: string;
    pkg?: string;
    percent: number;
    successCount: number;
    failCount: number;
    warningCount: number;
    modeName: string;
  }

  const [execProgress, setExecProgress] = useState<ExecutionProgressState | null>(null);
  const [lastResult, setLastResult] = useState<PipelineResult | null>(null);
  const [showResultDetails, setShowResultDetails] = useState<boolean>(false);
  const [fixSuccess, setFixSuccess] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'important' | 'banking' | 'social'>('all');
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 36;
  const [isWhitelistingBattery, setIsWhitelistingBattery] = useState(false);
  const [feedbackNote, setFeedbackNote] = useState<{ type: 'success' | 'warning' | 'error'; text: string } | null>(null);
  const [isRebooting, setIsRebooting] = useState(false);
  const [rebootDone, setRebootDone] = useState(false);
  const [isMasterFixing, setIsMasterFixing] = useState(false);
  const [masterFixSuccess, setMasterFixSuccess] = useState(false);
  const [showGuideCenter, setShowGuideCenter] = useState(false);
  const [activeGuideTab, setActiveGuideTab] = useState<'facebook' | 'banking' | 'lockscreen' | 'honor' | 'gentle'>('facebook');
  const [showAdvancedFixes, setShowAdvancedFixes] = useState(false);
  const [isVipFixing, setIsVipFixing] = useState(false);
  const [vipFixSuccess, setVipFixSuccess] = useState(false);
  const [showVipGuide, setShowVipGuide] = useState(false);
  const [isMetaFixing, setIsMetaFixing] = useState(false);
  const [metaFixSuccess, setMetaFixSuccess] = useState(false);
  const [showMetaGuide, setShowMetaGuide] = useState(false);
  const [isBankFixing, setIsBankFixing] = useState(false);
  const [bankFixSuccess, setBankFixSuccess] = useState(false);
  const [showBankGuide, setShowBankGuide] = useState(false);
  const [isLockscreenFixing, setIsLockscreenFixing] = useState(false);
  const [lockscreenSuccess, setLockscreenSuccess] = useState(false);
  const [showLockscreenGuide, setShowLockscreenGuide] = useState(false);

  const handleKeepLockscreenNotifications = async () => {
    if (!isConnected || isLockscreenFixing) return;
    setIsLockscreenFixing(true);
    setLockscreenSuccess(false);
    try {
      const cmds = HonorAdbScripts.getKeepLockscreenNotificationCommands();
      const res = await adbDriver.executePipeline(cmds, undefined, {
        title: 'Giữ Thông Báo Màn Khóa & Bật Lịch Sử 24h'
      });
      if (res.success) {
        setLockscreenSuccess(true);
        setShowLockscreenGuide(true);
        recordUserActivity('Giữ thông báo Màn hình khóa & Lịch sử 24h (0s)');
        showFeedback('success', 'Đã cấu hình giữ thông báo trên Màn hình khóa & Bật Lịch sử thông báo 24 giờ thành công!');
      } else {
        showFeedback('warning', `Đã nạp lệnh màn hình khóa với ${res.errors.length} cảnh báo. Xem log Terminal.`);
      }
    } catch (e: any) {
      showFeedback('error', `Lỗi cấu hình màn hình khóa: ${e?.message || 'Thất bại'}`);
    } finally {
      setIsLockscreenFixing(false);
    }
  };

  const handleRebootDevice = async () => {
    if (!isConnected || isRebooting) return;
    setIsRebooting(true);
    setRebootDone(false);
    try {
      await adbDriver.rebootDevice();
      setRebootDone(true);
      showFeedback('success', 'Đã gửi lệnh khởi động lại thiết bị thành công! Máy đang reboot...');
    } catch (e: any) {
      showFeedback('warning', 'Lệnh khởi động lại đã gửi tới thiết bị.');
    } finally {
      setIsRebooting(false);
    }
  };

  /**
   * TỐI ƯU HÓA SIÊU TỐC: BIẾN ĐỘNG SỐ DƯ & MÃ OTP APP NGÂN HÀNG VIỆT NAM (0S)
   * Tự động mở Standby Bucket ACTIVE, Exact Alarms, NetPolicy Whitelist & Importance Level 4
   */
  const handleRunVnBankingFastPush = async () => {
    if (!isConnected || isBankFixing || isMetaFixing || isVipFixing || isFixing || isEcoFixing) return;
    setIsBankFixing(true);
    setBankFixSuccess(false);
    setLastResult(null);

    const actualInstalled = appsList.map((a) => a.package);
    const pipeline = HonorAdbScripts.buildVnBankingFastPushPipeline(actualInstalled);

    const res = await adbDriver.executePipeline(pipeline, (current, total, cmd, extra) => {
      setExecProgress({
        current,
        total,
        cmd,
        label: extra?.label,
        pkg: extra?.pkg,
        percent: extra?.percent ?? Math.round((current / total) * 100),
        successCount: extra?.successCount ?? 0,
        failCount: extra?.failCount ?? 0,
        warningCount: extra?.warningCount ?? 0,
        modeName: 'Tăng Tốc Biến Động Số Dư & OTP Ngân Hàng 0s'
      });
    });

    recordUserActivity('Kích hoạt Tăng Tốc Biến Động Số Dư & OTP Ngân Hàng Việt Nam (0s)');
    setIsBankFixing(false);
    setExecProgress(null);
    setLastResult(res);

    if (res.failCount === 0) {
      setBankFixSuccess(true);
      setShowBankGuide(true);
      showFeedback('success', `ĐÃ TỐI ƯU NGÂN HÀNG THÀNH CÔNG TRONG ${(res.durationMs / 1000).toFixed(1)}s! (${res.successCount} thành công, ${res.warningCount} bỏ qua an toàn). Biến động số dư & mã OTP sẽ nổ chuông và hiện pop-up tức thì 0s.`);
      setTimeout(() => setBankFixSuccess(false), 12000);
    } else {
      showFeedback('warning', `Đã áp dụng với ${res.successCount} thành công, ${res.warningCount} bỏ qua và ${res.failCount} lỗi. Xem chi tiết bảng kết quả.`);
    }
  };

  const showFeedback = (type: 'success' | 'warning' | 'error', text: string) => {
    setFeedbackNote({ type, text });
    setTimeout(() => setFeedbackNote(null), 8000);
  };

  const handleScanDeviceApps = React.useCallback(async () => {
    if (!isConnected || isScanningRef.current) return;
    isScanningRef.current = true;
    setIsScanning(true);
    setScanProgress(15);
    setScanStatusText('Đang kết nối WebADB và truy vấn danh sách gói ứng dụng...');

    try {
      setScanProgress(40);
      const output = await adbDriver.executeCommand(HonorAdbScripts.getScanInstalledAppsCommand(), { silent: true });
      
      setScanProgress(75);
      setScanStatusText('Đang phân loại: App Người Dùng & Dịch Vụ Google vs App Hệ Thống...');

      // 1. Phân tách danh sách theo các mốc đánh dấu từ shell
      let userRaw = '';
      let googleRaw = '';
      let systemRaw = '';

      if (output.includes('===USER_PKGS===')) {
        const getSec = (startTag: string, endTag: string): string => {
          const s = output.indexOf(startTag);
          if (s === -1) return '';
          const cs = s + startTag.length;
          const e = output.indexOf(endTag, cs);
          return e === -1 ? output.slice(cs).trim() : output.slice(cs, e).trim();
        };

        userRaw = getSec('===USER_PKGS===', '===GOOGLE_PKGS===');
        googleRaw = getSec('===GOOGLE_PKGS===', '===SYSTEM_PKGS===');
        systemRaw = getSec('===SYSTEM_PKGS===', '===END_PKGS===');
      } else {
        userRaw = output;
      }

      const parsePackages = (text: string): string[] => {
        return text
          .split('\n')
          .map((l) => l.replace('package:', '').trim())
          .filter((l) => l && !l.startsWith('#') && !l.startsWith('==='));
      };

      const userPackageList = parsePackages(userRaw);
      const googlePackageList = parsePackages(googleRaw);
      const systemPackageList = parsePackages(systemRaw);

      const userPkgsSet = new Set<string>(userPackageList);
      const googlePkgsSet = new Set<string>(googlePackageList);
      const systemPkgsSet = new Set<string>(systemPackageList);

      // Toàn bộ dịch vụ Google (GMS, Gmail, Play Store...) luôn đưa vào nhóm Người Dùng để fix thông báo
      googlePkgsSet.forEach((pkg) => {
        userPkgsSet.add(pkg);
        systemPkgsSet.delete(pkg);
      });

      const realApps: AppPackageInfo[] = [];
      const matchedSet = new Set<string>();

      // Nhóm 1: Ưu tiên đưa các app OTT/MXH/Google phổ biến lên đầu
      COMMONLY_USED_VN_APPS.forEach((preset) => {
        if (userPkgsSet.has(preset.package)) {
          realApps.push({
            ...preset,
            appType: 'user'
          });
          matchedSet.add(preset.package);
        }
      });

      // Nhóm 2: Các ứng dụng người dùng khác được cài thêm
      userPkgsSet.forEach((pkg) => {
        if (!matchedSet.has(pkg)) {
          const isGoogle = pkg.startsWith('com.google.android.') || pkg === 'com.android.vending';
          const parts = pkg.split('.');
          const appLabel = parts[parts.length - 1].toUpperCase();
          const isBank = isBankingApp(pkg, appLabel);
          const isSocial = isSocialApp(pkg, appLabel);
          const isImp = isBank || isSocial || isGoogle;

          realApps.push({
            id: pkg,
            name: isGoogle ? `Google ${appLabel}` : appLabel,
            package: pkg,
            icon: 'Smartphone',
            isImportant: isImp,
            category: isGoogle ? 'Dịch vụ Google FCM' : isBank ? 'Ngân hàng / Ví' : isSocial ? 'Mạng xã hội' : 'Ứng dụng cài thêm',
            appType: 'user',
            isGoogle
          });
          matchedSet.add(pkg);
        }
      });

      // Nhóm 3: Các ứng dụng hệ thống nội địa (ROM) - Không cần fix thông báo
      systemPkgsSet.forEach((pkg) => {
        if (!matchedSet.has(pkg)) {
          const parts = pkg.split('.');
          const lastPart = parts[parts.length - 1] || pkg;
          const formattedName = lastPart.charAt(0).toUpperCase() + lastPart.slice(1);

          realApps.push({
            id: pkg,
            name: `${formattedName} (Hệ thống)`,
            package: pkg,
            icon: 'Cpu',
            isImportant: false,
            category: 'Hệ thống ROM nội địa',
            appType: 'system',
            isGoogle: false
          });
          matchedSet.add(pkg);
        }
      });

      setScanProgress(95);
      setAppsList(realApps);

      // QUAN TRỌNG: Mặc định CHỈ TỰ ĐỘNG CHỌN các app người dùng & Google quan trọng!
      // Tuyệt đối KHÔNG chọn app hệ thống nội địa để tránh tốn pin vô ích.
      const autoSelected = realApps
        .filter((a) => a.appType === 'user' && a.isImportant)
        .map((a) => a.package);
      setSelectedApps(autoSelected);

      const nowTime = new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      setLastScannedTime(nowTime);
      setScanProgress(100);

      const userCount = realApps.filter((a) => a.appType === 'user').length;
      const sysCount = realApps.filter((a) => a.appType === 'system').length;
      setScanStatusText(`Đã quét xong: Phân loại ${userCount} App Người Dùng/Google & ${sysCount} App Hệ Thống lúc ${nowTime}`);

      // Lưu vào cache phiên làm việc
      deviceDataCache.setNotificationData({
        appsList: realApps,
        selectedApps: autoSelected,
        lastScannedTime: nowTime
      });
    } catch (e: any) {
      console.error('Scan apps error', e);
      setScanStatusText(`Không thể quét ứng dụng: ${e?.message || 'Lỗi ADB'}`);
    } finally {
      setIsScanning(false);
      isScanningRef.current = false;
      setTimeout(() => {
        setScanProgress(0);
      }, 5000);
    }
  }, [isConnected]);

  // Khi kết nối thành công: kiểm tra cache trước để giữ nguyên trạng thái khi đổi tab
  React.useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isConnected) {
      if (deviceDataCache.hasNotificationData()) {
        const cached = deviceDataCache.getNotificationData()!;
        setAppsList(cached.appsList);
        setSelectedApps(cached.selectedApps);
        setLastScannedTime(cached.lastScannedTime);
        hasAutoScannedRef.current = true;
        return;
      }

      if (!hasAutoScannedRef.current) {
        hasAutoScannedRef.current = true;
        if (appsList.length === 0) {
          setAppsList(COMMONLY_USED_VN_APPS);
          setSelectedApps(COMMONLY_USED_VN_APPS.filter((a) => a.isImportant).map((a) => a.package));
        }
        timer = setTimeout(() => {
          handleScanDeviceApps();
        }, 500);
      }
    } else {
      hasAutoScannedRef.current = false;
      deviceDataCache.clearAll();
      setAppsList(COMMONLY_USED_VN_APPS);
      setSelectedApps(COMMONLY_USED_VN_APPS.filter((a) => a.isImportant).map((a) => a.package));
      setLastScannedTime(null);
    }
    return () => clearTimeout(timer);
  }, [isConnected, handleScanDeviceApps]);

  const toggleApp = (pkg: string) => {
    setSelectedApps((prev) =>
      prev.includes(pkg) ? prev.filter((p) => p !== pkg) : [...prev, pkg]
    );
  };

  const userApps = React.useMemo(() => appsList.filter((a) => a.appType === 'user'), [appsList]);
  const systemApps = React.useMemo(() => appsList.filter((a) => a.appType === 'system'), [appsList]);

  const handleSelectAll = () => {
    if (classificationTab === 'user') {
      const allUserPkgs = userApps.map((a) => a.package);
      setSelectedApps(allUserPkgs);
      showFeedback('success', `Đã chọn toàn bộ ${allUserPkgs.length} ứng dụng người dùng & Google (Bỏ qua hoàn toàn app hệ thống nội địa).`);
    } else {
      const allSysPkgs = systemApps.map((a) => a.package);
      setSelectedApps(allSysPkgs);
      showFeedback('warning', `Đã chọn ${allSysPkgs.length} ứng dụng hệ thống nội địa. Lưu ý: App hệ thống nội địa không cần fix thông báo.`);
    }
  };

  const handleSelectImportantOnly = () => {
    const importantPkgs = userApps.filter((a) => a.isImportant).map((a) => a.package);
    setSelectedApps(importantPkgs);
    setClassificationTab('user');
    setActiveFilter('important');
    showFeedback('success', `Đã chọn ${importantPkgs.length} ứng dụng quan trọng nhất (Zalo, Messenger, FB, Telegram, Gmail...).`);
  };

  const handleDeselectAll = () => {
    setSelectedApps([]);
  };

  /**
   * Bộ lọc nghiêm ngặt: Chỉ áp dụng fix thông báo cho App Người Dùng & Dịch Vụ Google
   * Tuyệt đối không can thiệp vào App Hệ Thống Nội Địa Trung Quốc
   */
  const getTargetUserAppsToFix = (pkgs: string[]): string[] => {
    return pkgs.filter((pkg) => {
      const found = appsList.find((a) => a.package === pkg);
      return !found || found.appType === 'user';
    });
  };

  const [isEcoFixing, setIsEcoFixing] = useState(false);
  const [ecoFixSuccess, setEcoFixSuccess] = useState(false);

  /**
   * SIÊU KỊCH BẢN MASTER TỔNG LỰC 1-CHẠM:
   * Bẻ khóa toàn diện 0s cho Facebook, Messenger, Zalo, Gmail, Telegram, Ngân Hàng, Lockscreen & Mạng 24/7
   * Không còn bất kỳ xung đột nào giữa các nút bấm!
   */
  const handleRunMasterAllInOneFix = async () => {
    if (!isConnected || isMasterFixing || isFixing || isEcoFixing || isVipFixing || isMetaFixing || isBankFixing) return;

    setIsMasterFixing(true);
    setMasterFixSuccess(false);
    setLastResult(null);

    // Thu thập các app thực tế cài trên máy kết hợp danh sách đã chọn
    const targetPkgs = getTargetUserAppsToFix(selectedApps);
    const actualInstalled = appsList.map((a) => a.package);
    const combinedPkgs = Array.from(new Set([...targetPkgs, ...actualInstalled]));

    const pipeline = HonorAdbScripts.buildMasterAllInOnePushPipeline(combinedPkgs, detectedBrandId);

    const res = await adbDriver.executePipeline(pipeline, (current, total, cmd, extra) => {
      setExecProgress({
        current,
        total,
        cmd,
        label: extra?.label,
        pkg: extra?.pkg,
        percent: extra?.percent ?? Math.round((current / total) * 100),
        successCount: extra?.successCount ?? 0,
        failCount: extra?.failCount ?? 0,
        warningCount: extra?.warningCount ?? 0,
        modeName: '1-Chạm Bẻ Khóa Toàn Bộ 0 Giây (All-In-One Super Push)'
      });
    }, { title: '1-Chạm Bẻ Khóa Toàn Bộ 0 Giây (All-In-One Super Push)' });

    recordUserActivity('Kích hoạt Siêu Bẻ Khóa Master All-in-One 0s', `Áp dụng ${combinedPkgs.length} ứng dụng`);
    setIsMasterFixing(false);
    setExecProgress(null);
    setLastResult(res);

    if (res.failCount === 0) {
      setMasterFixSuccess(true);
      showFeedback('success', `ĐÃ BẺ KHÓA TOÀN BỘ 0 GIÂY THÀNH CÔNG TRONG ${(res.durationMs / 1000).toFixed(1)}s! (${res.successCount} thành công, ${res.warningCount} bỏ qua an toàn). Facebook, Zalo, Gmail, Telegram & Ngân hàng đã sẵn sàng nổ chuông 0s. Hãy KHỞI ĐỘNG LẠI MÁY để kích hoạt 100%!`);
      setTimeout(() => setMasterFixSuccess(false), 15000);
    } else {
      showFeedback('warning', `Đã bẻ khóa với ${res.successCount} thành công, ${res.warningCount} bỏ qua và ${res.failCount} lỗi. Xem chi tiết bảng kết quả.`);
    }
  };

  /**
   * CƠ CHẾ ĐỘT PHÁ: HYBRID ECO BATTERY - TIẾT KIỆM PIN SIÊU TỐC NHƯNG THÔNG BÁO TỨC THÌ (0S)
   */
  const handleRunSmartEcoBatteryFix = async () => {
    if (!isConnected || isEcoFixing) return;

    const targetPkgs = getTargetUserAppsToFix(selectedApps);
    if (targetPkgs.length === 0) {
      showFeedback('warning', 'Vui lòng chọn ít nhất 1 ứng dụng người dùng hoặc dịch vụ Google cần fix thông báo!');
      return;
    }

    setIsEcoFixing(true);
    setEcoFixSuccess(false);
    setLastResult(null);

    const pipeline = HonorAdbScripts.getSmartEcoBatteryWithZeroLagPushCommands(targetPkgs);

    const res = await adbDriver.executePipeline(pipeline, (current, total, cmd, extra) => {
      setExecProgress({
        current,
        total,
        cmd,
        label: extra?.label,
        pkg: extra?.pkg,
        percent: extra?.percent ?? Math.round((current / total) * 100),
        successCount: extra?.successCount ?? 0,
        failCount: extra?.failCount ?? 0,
        warningCount: extra?.warningCount ?? 0,
        modeName: 'Hybrid Eco Battery: Tiết Kiệm Pin & Nổ Chuông 0s'
      });
    }, { title: 'Hybrid Eco Battery: Tiết Kiệm Pin & Nổ Chuông 0s' });

    recordUserActivity('Kích hoạt Hybrid Eco Battery (Tiết kiệm pin & Nổ chuông 0s)', `Áp dụng cho ${targetPkgs.length} app người dùng/Google`);
    setIsEcoFixing(false);
    setExecProgress(null);
    setLastResult(res);

    if (res.failCount === 0) {
      setEcoFixSuccess(true);
      showFeedback('success', `ĐÃ HOÀN TẤT SIÊU TỐC TRONG ${(res.durationMs / 1000).toFixed(1)}s! (${res.successCount} thành công, ${res.warningCount} bỏ qua an toàn). Đã dọn dẹp RAM, tối ưu pin và mở kênh nổ chuông 0s.`);
      setTimeout(() => setEcoFixSuccess(false), 8000);
    } else {
      showFeedback('warning', `Đã áp dụng với ${res.successCount} thành công, ${res.warningCount} bỏ qua và ${res.failCount} lỗi. Xem chi tiết bảng kết quả bên dưới.`);
    }
  };

  /**
   * ⚡ ĐẶC TRỊ BỘ BA CỨNG ĐẦU: FACEBOOK + TELEGRAM + GMAIL (HONOR 0S CHUÔNG)
   */
  const handleRunHonorVipTripleAppFix = async () => {
    if (!isConnected || isVipFixing) return;
    setIsVipFixing(true);
    setVipFixSuccess(false);
    setLastResult(null);

    const actualInstalled = appsList.map((a) => a.package);
    const pipeline = HonorAdbScripts.getHonorVipTripleAppFixCommands(actualInstalled);

    const res = await adbDriver.executePipeline(pipeline, (current, total, cmd, extra) => {
      setExecProgress({
        current,
        total,
        cmd,
        label: extra?.label,
        pkg: extra?.pkg,
        percent: extra?.percent ?? Math.round((current / total) * 100),
        successCount: extra?.successCount ?? 0,
        failCount: extra?.failCount ?? 0,
        warningCount: extra?.warningCount ?? 0,
        modeName: 'VIP Đặc Trị: Facebook · Telegram · Gmail (Honor 0s)'
      });
    }, { title: 'VIP Đặc Trị: Facebook · Telegram · Gmail (Honor 0s)' });

    recordUserActivity('Kích hoạt VIP Đặc Trị Facebook + Telegram + Gmail (Honor MagicOS)');
    setIsVipFixing(false);
    setExecProgress(null);
    setLastResult(res);

    if (res.failCount === 0) {
      setVipFixSuccess(true);
      setShowVipGuide(true);
      showFeedback('success', `ĐÃ ĐẶC TRỊ THÀNH CÔNG TRONG ${(res.durationMs / 1000).toFixed(1)}s! (${res.successCount} thao tác thành công, ${res.warningCount} cảnh báo an toàn). Facebook, Telegram & Gmail đã sẵn sàng.`);
      setTimeout(() => setVipFixSuccess(false), 10000);
    } else {
      showFeedback('warning', `Đã thực thi với ${res.successCount} thành công, ${res.warningCount} bỏ qua và ${res.failCount} lỗi. Xem chi tiết bảng kết quả bên dưới.`);
    }
  };

  /**
   * ĐẶC TRỊ CHUYÊN SÂU: FACEBOOK & MESSENGER NỔ CHUÔNG 0S (META DEEP PUSH PIPELINE)
   * Tự động bẻ khóa 8 lớp: NetPolicy, Khởi chạy liên kết, AppOps, MQTT Socket, Doze Whitelist & Level 4
   */
  const handleRunMetaFacebookDeepPush = async () => {
    if (!isConnected || isMetaFixing || isVipFixing || isFixing || isEcoFixing) return;
    setIsMetaFixing(true);
    setMetaFixSuccess(false);
    setLastResult(null);

    const actualInstalled = appsList.map((a) => a.package);
    const pipeline = HonorAdbScripts.buildMetaFacebookDeepPushPipeline(actualInstalled);

    const res = await adbDriver.executePipeline(pipeline, (current, total, cmd, extra) => {
      setExecProgress({
        current,
        total,
        cmd,
        label: extra?.label,
        pkg: extra?.pkg,
        percent: extra?.percent ?? Math.round((current / total) * 100),
        successCount: extra?.successCount ?? 0,
        failCount: extra?.failCount ?? 0,
        warningCount: extra?.warningCount ?? 0,
        modeName: 'Đặc Trị Chuyên Sâu Meta Facebook & Messenger 0s'
      });
    }, { title: 'Đặc Trị Chuyên Sâu Meta Facebook & Messenger 0s' });

    recordUserActivity('Kích hoạt Đặc Trị Chuyên Sâu Facebook & Messenger 0s (Meta Deep Push Pipeline)');
    setIsMetaFixing(false);
    setExecProgress(null);
    setLastResult(res);

    if (res.failCount === 0) {
      setMetaFixSuccess(true);
      setShowMetaGuide(true);
      showFeedback('success', `ĐÃ ĐẶC TRỊ META PUSH THÀNH CÔNG TRONG ${(res.durationMs / 1000).toFixed(1)}s! (${res.successCount} thành công, ${res.warningCount} bỏ qua an toàn). Facebook & Messenger đã được bẻ khóa dữ liệu nền và mở socket MQTT 0s.`);
      setTimeout(() => setMetaFixSuccess(false), 12000);
    } else {
      showFeedback('warning', `Đã áp dụng với ${res.successCount} thành công, ${res.warningCount} bỏ qua và ${res.failCount} lỗi. Xem chi tiết bảng kết quả.`);
    }
  };

  /**
   * CƠ CHẾ FIX THẬT MẠNH TAY CHO CÁC APP CỨNG ĐẦU
   */
  const handleRunUltraHardcoreFix = async () => {
    if (!isConnected || isFixing) return;

    const targetPkgs = getTargetUserAppsToFix(selectedApps);
    if (targetPkgs.length === 0) {
      showFeedback('warning', 'Vui lòng chọn ít nhất 1 ứng dụng người dùng hoặc dịch vụ Google cần fix thông báo!');
      return;
    }

    setIsFixing(true);
    setFixSuccess(false);
    setLastResult(null);

    // Gọi pipeline tối ưu cực đoan bẻ khóa toàn diện
    const pipeline = HonorAdbScripts.buildUltraHardcorePushPipeline(targetPkgs, disableBastet, detectedBrandId);

    const res = await adbDriver.executePipeline(pipeline, (current, total, cmd, extra) => {
      setExecProgress({
        current,
        total,
        cmd,
        label: extra?.label,
        pkg: extra?.pkg,
        percent: extra?.percent ?? Math.round((current / total) * 100),
        successCount: extra?.successCount ?? 0,
        failCount: extra?.failCount ?? 0,
        warningCount: extra?.warningCount ?? 0,
        modeName: `Bẻ Khóa 5 Lớp Cực Đoan (${targetPkgs.length} App)`
      });
    }, { title: `Bẻ Khóa 5 Lớp Cực Đoan (${targetPkgs.length} Ứng Dụng)` });

    recordUserActivity('Chạy 1-Chạm Bẻ Khóa Cực Đoan Fix Thông Báo', `${targetPkgs.length} ứng dụng`);
    setIsFixing(false);
    setExecProgress(null);
    setLastResult(res);

    if (res.failCount === 0) {
      setFixSuccess(true);
      showFeedback('success', `ĐÃ BẺ KHÓA THÀNH CÔNG TRONG ${(res.durationMs / 1000).toFixed(1)}s! (${res.successCount} thành công, ${res.warningCount} bỏ qua an toàn). Đã cấp quyền 5 lớp cho ${targetPkgs.length} app.`);
      setTimeout(() => setFixSuccess(false), 8000);
    } else {
      showFeedback('warning', `Đã bẻ khóa với ${res.successCount} thành công, ${res.warningCount} bỏ qua và ${res.failCount} lỗi. Xem chi tiết bảng kết quả.`);
    }
  };

  const handleResetToDefault = async () => {
    if (!isConnected || selectedApps.length === 0) return;
    setIsFixing(true);
    const pipeline = HonorAdbScripts.buildPushNotificationResetPipeline(selectedApps);
    const res = await adbDriver.executePipeline(pipeline);
    setIsFixing(false);
    if (res.success) {
      setFixSuccess(true);
      showFeedback('success', `Đã khôi phục cài đặt quản lý pin và thông báo gốc cho ${selectedApps.length} ứng dụng.`);
      setTimeout(() => setFixSuccess(false), 5000);
    } else {
      showFeedback('warning', `Khôi phục hoàn tất với ${res.errors.length} lỗi.`);
    }
  };

  const handleBatchWhitelistBattery = async () => {
    if (!isConnected || isWhitelistingBattery) return;

    const targetPkgs = getTargetUserAppsToFix(selectedApps);
    if (targetPkgs.length === 0) {
      showFeedback('warning', 'Vui lòng chọn ít nhất 1 ứng dụng người dùng hoặc dịch vụ Google cần cấp quyền pin!');
      return;
    }

    setIsWhitelistingBattery(true);

    const cmds: string[] = [];
    targetPkgs.forEach((pkg) => {
      cmds.push(`cmd deviceidle whitelist +${pkg} 2>/dev/null || dumpsys deviceidle whitelist +${pkg} 2>/dev/null || true`);
      cmds.push(`cmd appops set ${pkg} RUN_IN_BACKGROUND allow 2>/dev/null || true`);
      cmds.push(`cmd appops set ${pkg} RUN_ANY_IN_BACKGROUND allow 2>/dev/null || true`);
      cmds.push(`cmd appops set ${pkg} START_FOREGROUND allow 2>/dev/null || true`);
    });

    const res = await adbDriver.executePipeline(cmds);
    recordUserActivity('Cấp quyền bỏ qua tối ưu pin hàng loạt', `${targetPkgs.length} ứng dụng`);
    setIsWhitelistingBattery(false);
    if (res.success) {
      setFixSuccess(true);
      showFeedback('success', `Đã đưa ${targetPkgs.length} ứng dụng vào DeviceIdle Whitelist và cấp quyền chạy ngầm thành công!`);
      setTimeout(() => setFixSuccess(false), 5000);
    } else {
      showFeedback('warning', `Đã cấp quyền với ${res.errors.length} cảnh báo. Xem log trong Terminal.`);
    }
  };

  const displayedApps = classificationTab === 'user' ? userApps : systemApps;

  const filteredApps = displayedApps.filter((a) => {
    const match =
      a.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.package.toLowerCase().includes(searchQuery.toLowerCase());
    if (classificationTab === 'user') {
      if (activeFilter === 'important') return match && a.isImportant;
      if (activeFilter === 'banking') return match && isBankingApp(a.package, a.name);
      if (activeFilter === 'social') return match && isSocialApp(a.package, a.name);
    }
    return match;
  });

  return (
    <div className="rounded-2xl border border-cyan-500/20 bg-[#111A2E]/90 backdrop-blur-xl p-6 shadow-xl relative overflow-hidden">
      {/* Header */}
      <div className="flex flex-col pb-4 border-b border-cyan-500/15 gap-4">
        <div className="w-full">
          <div className="flex items-start space-x-3">
            <div className="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-[#00F0FF] shrink-0">
              <BellRing className="w-5 h-5" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="text-base sm:text-lg font-bold text-white tracking-wide leading-snug">
                  Engine Khắc Phục Trễ Thông Báo Cực Mạnh (Hardcore Push Fixer)
                </h3>
                <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 font-semibold flex items-center space-x-1 shrink-0">
                  <Flame className="w-3 h-3 text-rose-400" />
                  <span>Cưỡng Chế 5 Lớp</span>
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Đặc trị cho <strong>Facebook, Gmail, Zalo, Telegram</strong>: Đảm bảo có chuông thông báo tức thì trên mọi thiết bị Android nội địa
              </p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleScanDeviceApps}
            disabled={!isConnected || isScanning}
            className="px-3 py-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold flex items-center space-x-1.5 transition-all border border-slate-700 disabled:opacity-40"
            title="Quét danh sách ứng dụng đã cài đặt trên máy"
          >
            <Scan className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin text-[#00F0FF]' : ''}`} />
            <span>{isScanning ? `Đang quét (${scanProgress}%)...` : 'Quét App Trên Máy'}</span>
          </button>

          {lastScannedTime && !isScanning && (
            <span className="text-[11px] text-emerald-400 font-mono hidden sm:inline-flex items-center space-x-1 px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
              <span>Cập nhật: {lastScannedTime}</span>
            </span>
          )}

          <button
            onClick={handleResetToDefault}
            disabled={!isConnected || isFixing || isEcoFixing}
            className="px-3 py-2 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 hover:text-white text-xs font-semibold flex items-center space-x-1.5 transition-all border border-slate-700 disabled:opacity-40"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Khôi phục</span>
          </button>

          {/* NÚT ĐẶC TRỊ: TIẾT KIỆM PIN NHƯNG THÔNG BÁO TỨC THÌ (HYBRID ECO) */}
          <button
            onClick={handleRunSmartEcoBatteryFix}
            disabled={!isConnected || isEcoFixing || isFixing}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-400 via-teal-400 to-cyan-500 hover:from-emerald-300 hover:to-cyan-400 text-black text-xs font-black flex items-center space-x-1.5 transition-all shadow-lg shadow-emerald-500/25 disabled:opacity-40 hover:scale-[1.02] active:scale-[0.98]"
            title="Công nghệ Hybrid Eco: Vừa tiết kiệm pin sâu, hạ nhiệt mát lạnh, vừa đảm bảo chuông thông báo nổ tức thì 0 giây"
          >
            {isEcoFixing ? (
              <>
                <div className="w-3.5 h-3.5 border-2 border-black border-t-transparent rounded-full animate-spin" />
                <span>Đang kích hoạt Hybrid Eco...</span>
              </>
            ) : ecoFixSuccess ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-black" />
                <span>Đã Tối Ưu Tiết Kiệm Pin &amp; Nổ Chuông 0s!</span>
              </>
            ) : (
              <>
                <Leaf className="w-4 h-4 fill-black text-black" />
                <span>Tiết Kiệm Pin + Nổ Chuông 0s (Hybrid Eco)</span>
              </>
            )}
          </button>

          <button
            onClick={handleRunUltraHardcoreFix}
            disabled={!isConnected || isFixing || isEcoFixing || isVipFixing || selectedApps.length === 0}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#00F0FF] via-cyan-400 to-blue-600 hover:from-cyan-300 hover:to-blue-500 text-black text-xs font-extrabold flex items-center space-x-1.5 transition-all shadow-lg shadow-cyan-500/30 disabled:opacity-40 hover:scale-[1.02] active:scale-[0.98]"
          >
            {isFixing ? (
              <>
                <div className="w-3.5 h-3.5 border-2 border-black border-t-transparent rounded-full animate-spin" />
                <span>Đang bẻ khóa 5 lớp...</span>
              </>
            ) : fixSuccess ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-black" />
                <span>Đã cưỡng chế đẩy thành công!</span>
              </>
            ) : (
              <>
                <Flame className="w-4 h-4 fill-black" />
                <span>Bẻ Khóa Cực Đoan ({selectedApps.length} App)</span>
              </>
            )}
          </button>

          {/* NÚT ĐẶC TRỊ VIP: FACEBOOK + TELEGRAM + GMAIL */}
          <button
            onClick={handleRunHonorVipTripleAppFix}
            disabled={!isConnected || isVipFixing || isFixing || isEcoFixing || isMetaFixing}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 via-orange-400 to-rose-500 hover:from-amber-300 hover:to-orange-300 text-black text-xs font-black flex items-center space-x-1.5 transition-all shadow-lg shadow-amber-500/30 disabled:opacity-40 hover:scale-[1.02] active:scale-[0.98]"
            title="Giải quyết triệt để 100%: Facebook không nổ chuông, Gmail ngủ qua đêm và Telegram bị ngắt socket ngầm trên máy Honor & máy nội địa!"
          >
            {isVipFixing ? (
              <>
                <div className="w-3.5 h-3.5 border-2 border-black border-t-transparent rounded-full animate-spin" />
                <span>Đang Chạy Kịch Bản Đặc Trị...</span>
              </>
            ) : vipFixSuccess ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-black" />
                <span>✓ Đã Trị Xong FB + Telegram + Gmail!</span>
              </>
            ) : (
              <>
                <Crown className="w-4 h-4 fill-black text-black" />
                <span>Đặc Trị: FB + Telegram + Gmail (Miễn Phí 100%)</span>
              </>
            )}
          </button>

          {/* NÚT ĐẶC TRỊ CHUYÊN SÂU: FACEBOOK & MESSENGER 0S (META DEEP PUSH) */}
          <button
            onClick={handleRunMetaFacebookDeepPush}
            disabled={!isConnected || isMetaFixing || isVipFixing || isFixing || isEcoFixing}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white text-xs font-black flex items-center space-x-1.5 transition-all shadow-lg shadow-blue-500/30 disabled:opacity-40 hover:scale-[1.02] active:scale-[0.98]"
            title="Đặc trị chuyên sâu: Facebook & Messenger nổ chuông 0 giây (Bẻ khóa NetPolicy, Khởi chạy liên kết & MQTT Push Daemon)!"
          >
            {isMetaFixing ? (
              <>
                <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>Đang Bẻ Khóa Meta 0s...</span>
              </>
            ) : metaFixSuccess ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-white" />
                <span>✓ Đã Trị Xong Facebook 0s!</span>
              </>
            ) : (
              <>
                <Zap className="w-4 h-4 fill-cyan-300 text-cyan-300" />
                <span>⚡ Đặc Trị Facebook 0s (Meta Deep Push)</span>
              </>
            )}
          </button>

          {/* NÚT TĂNG TỐC APP NGÂN HÀNG VIỆT NAM (OTP & BIẾN ĐỘNG SỐ DƯ 0S) */}
          <button
            onClick={handleRunVnBankingFastPush}
            disabled={!isConnected || isBankFixing || isMetaFixing || isVipFixing || isFixing || isEcoFixing}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 text-black text-xs font-black flex items-center space-x-1.5 transition-all shadow-lg shadow-emerald-500/30 disabled:opacity-40 hover:scale-[1.02] active:scale-[0.98]"
            title="Tăng tốc thông báo biến động số dư và mã OTP của các ứng dụng tài chính &amp; thanh toán"
          >
            {isBankFixing ? (
              <>
                <div className="w-3.5 h-3.5 border-2 border-black border-t-transparent rounded-full animate-spin" />
                <span>Đang Tăng Tốc OTP...</span>
              </>
            ) : bankFixSuccess ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-black" />
                <span>✓ Đã Trị Xong VN Banks 0s!</span>
              </>
            ) : (
              <>
                <CreditCard className="w-4 h-4 fill-black text-black" />
                <span>⚡ Tăng Tốc OTP &amp; Tiền Về (VN Banks 0s)</span>
              </>
            )}
          </button>

          {/* NÚT ĐẶC TRỊ: GIỮ THÔNG BÁO MÀN HÌNH KHÓA & BẬT LỊCH SỬ 24H */}
          <button
            onClick={handleKeepLockscreenNotifications}
            disabled={!isConnected || isLockscreenFixing}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white text-xs font-black flex items-center space-x-1.5 transition-all shadow-lg shadow-purple-900/30 disabled:opacity-40 hover:scale-[1.02] active:scale-[0.98]"
            title="Đặc trị hiện tượng thông báo biến mất khỏi Màn hình khóa sau khi mở khóa. Kích hoạt Lịch sử thông báo 24 giờ của Android"
          >
            {isLockscreenFixing ? (
              <>
                <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>Đang Cấu Hình...</span>
              </>
            ) : lockscreenSuccess ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-white" />
                <span>✓ Đã Giữ Thông Báo Lockscreen!</span>
              </>
            ) : (
              <>
                <ShieldCheck className="w-4 h-4 text-purple-300" />
                <span>⚡ Giữ Thông Báo Màn Khóa (24h)</span>
              </>
            )}
          </button>

          {/* NÚT KHỞI ĐỘNG LẠI MÁY (1-CLICK REBOOT) */}
          <button
            onClick={handleRebootDevice}
            disabled={!isConnected || isRebooting}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-red-600 via-rose-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white text-xs font-black flex items-center space-x-1.5 transition-all shadow-lg shadow-red-900/30 disabled:opacity-40 hover:scale-[1.02] active:scale-[0.98]"
            title="Khởi động lại điện thoại ngay lập tức để hệ điều hành nạp lại toàn bộ chính sách chạy ngầm mới"
          >
            {isRebooting ? (
              <>
                <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>Đang Reboot Máy...</span>
              </>
            ) : rebootDone ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-white" />
                <span>✓ Đã Gửi Lệnh Reboot!</span>
              </>
            ) : (
              <>
                <RotateCw className="w-4 h-4 text-white" />
                <span>Khởi Động Lại Máy (Reboot)</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Thông báo kết quả và xác minh sau thực thi */}
      {feedbackNote && (
        <div className={`mt-4 p-3.5 rounded-xl border text-xs font-semibold flex items-center space-x-2 animate-in fade-in ${
          feedbackNote.type === 'success'
            ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-300'
            : 'bg-amber-500/15 border-amber-500/30 text-amber-300'
        }`}>
          {feedbackNote.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          ) : (
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
          )}
          <span>{feedbackNote.text}</span>
        </div>
      )}

      {/* BANNER ĐẶC TRỊ: GIỮ THÔNG BÁO MÀN HÌNH KHÓA & BẬT LỊCH SỬ 24H */}
      <div className="mt-4 p-4 rounded-2xl bg-gradient-to-r from-purple-950/50 via-indigo-950/40 to-[#0A0F1D] border border-purple-500/40 shadow-xl relative overflow-hidden space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start space-x-3">
            <div className="p-2.5 rounded-xl bg-purple-500/20 text-purple-300 border border-purple-500/30 shrink-0">
              <ShieldCheck className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <div className="text-xs font-black text-white flex items-center space-x-2">
                <span>⚡ ĐẶC TRỊ: GIỮ THÔNG BÁO MÀN HÌNH KHÓA &amp; BẬT LỊCH SỬ 24H</span>
                <span className="text-[9px] px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/40 font-mono font-bold">
                  LOCKSCREEN PERSISTENCE
                </span>
              </div>
              <p className="text-[11px] text-slate-300 mt-1 leading-relaxed">
                Khắc phục 100% hiện tượng <strong>thông báo biến mất khỏi Màn hình khóa sau khi mở khóa máy</strong> (Face Unlock liếc qua là mất sạch). Kích hoạt cờ <strong>Lịch sử thông báo 24 giờ của Android</strong> giúp đọc lại tin nhắn cũ hoặc tin nhắn bị thu hồi!
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2 shrink-0 self-start sm:self-center">
            <button
              onClick={handleKeepLockscreenNotifications}
              disabled={!isConnected || isLockscreenFixing}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-purple-500 via-indigo-500 to-blue-500 hover:from-purple-400 hover:to-blue-400 text-white text-xs font-black shadow-md shadow-purple-500/25 active:scale-95 disabled:opacity-40 transition-all flex items-center space-x-1.5"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-white" />
              <span>{isLockscreenFixing ? 'Đang kích hoạt...' : '1-Chạm Giữ Thông Báo'}</span>
            </button>
            <button
              onClick={() => setShowLockscreenGuide(!showLockscreenGuide)}
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-purple-300 border border-purple-500/30 text-xs font-bold transition-all flex items-center space-x-1"
            >
              <Info className="w-3.5 h-3.5" />
              <span>{showLockscreenGuide ? 'Thu Gọn Bí Kíp' : 'Bí Kíp Cài Đặt'}</span>
            </button>
          </div>
        </div>

        {/* Khối Giải Thích & 3 Bước Cài Đặt Face Unlock */}
        {showLockscreenGuide && (
          <div className="pt-3 border-t border-purple-500/20 space-y-2.5 animate-in fade-in text-xs">
            <div className="font-bold text-purple-300 flex items-center space-x-1.5">
              <span>🛡️ 3 Bước Thiết Lập Trên Điện Thoại Để Thông Báo Ở Lại Màn Khóa Vĩnh Viễn:</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5">
              <div className="p-3 rounded-xl bg-[#0A0F1D]/80 border border-purple-500/20 space-y-1">
                <div className="font-bold text-white flex items-center space-x-1.5">
                  <span className="w-5 h-5 rounded-full bg-purple-500/20 text-purple-300 flex items-center justify-center text-[10px] font-mono">1</span>
                  <span>Chỉnh Face Unlock (Quan trọng nhất)</span>
                </div>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  Vào <strong>Cài đặt ➔ Sinh trắc học &amp; Mật khẩu ➔ Nhận diện khuôn mặt</strong>. Chuyển sang <strong>&quot;Trượt để mở khóa&quot;</strong> (thay vì Mở khóa trực tiếp). Máy quét mặt chỉ để mở nội dung tin nhắn đọc riêng tư, không nhảy vào home, thông báo sẽ <strong>nằm vĩnh viễn trên màn hình khóa</strong>!
                </p>
              </div>

              <div className="p-3 rounded-xl bg-[#0A0F1D]/80 border border-purple-500/20 space-y-1">
                <div className="font-bold text-white flex items-center space-x-1.5">
                  <span className="w-5 h-5 rounded-full bg-purple-500/20 text-purple-300 flex items-center justify-center text-[10px] font-mono">2</span>
                  <span>Tắt Ẩn Thông Báo Thông Minh</span>
                </div>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  Cũng trong menu <em>Nhận diện khuôn mặt</em>, hãy <strong>TẮT</strong> mục <strong>&quot;Thông báo màn hình khóa thông minh&quot;</strong>. Thông báo sẽ luôn nằm nguyên trên màn hình khóa.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-[#0A0F1D]/80 border border-purple-500/20 space-y-1">
                <div className="font-bold text-white flex items-center space-x-1.5">
                  <span className="w-5 h-5 rounded-full bg-purple-500/20 text-purple-300 flex items-center justify-center text-[10px] font-mono">3</span>
                  <span>Xem Lại Lịch Sử Thông Báo 24h</span>
                </div>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  Sau khi chạy tool, tính năng đã được kích hoạt. Hãy vào <strong>Cài đặt ➔ Thông báo ➔ Lịch sử thông báo</strong>. Toàn bộ tin nhắn trong ngày đều lưu tại đây kể cả khi bị xóa nhầm hoặc người gửi đã thu hồi!
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* BANNER ĐẶC TRỊ CHUYÊN SÂU: FACEBOOK & MESSENGER 0S (META DEEP PUSH PIPELINE) */}
      <div className="mt-4 p-4 rounded-2xl bg-gradient-to-r from-blue-950/50 via-indigo-950/40 to-[#0A0F1D] border border-blue-500/40 shadow-xl relative overflow-hidden space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start space-x-3">
            <div className="p-2.5 rounded-xl bg-blue-500/20 text-blue-300 border border-blue-500/30 shrink-0">
              <Zap className="w-5 h-5 text-blue-400 fill-blue-400" />
            </div>
            <div>
              <div className="text-xs font-black text-white flex items-center space-x-2">
                <span>⚡ ĐẶC TRỊ CHUYÊN SÂU: FACEBOOK &amp; MESSENGER NỔ CHUÔNG 0S</span>
                <span className="text-[9px] px-2 py-0.5 rounded-full bg-gradient-to-r from-blue-500/20 to-cyan-500/20 text-cyan-300 border border-cyan-500/35 font-mono font-bold">
                  META DEEP PUSH PIPELINE (8 LỚP ADB TỰ ĐỘNG)
                </span>
              </div>
              <p className="text-[11px] text-slate-300 mt-1 leading-relaxed">
                Giải quyết triệt để 100% nguyên nhân <strong>Facebook không bao giờ nổ thông báo trên MagicOS &amp; máy nội địa</strong> (kể cả khi các app khác đã có chuông): Meta sử dụng socket MQTT riêng biệt. Khi tắt màn hình, hệ điều hành <strong>chặn NetPolicy dữ liệu nền</strong>, <strong>cấm Khởi chạy liên kết (Associated Start)</strong> và <strong>trảm tiến trình ngốn RAM</strong>. WebADB sẽ tự động nạp toàn bộ 8 lớp ADB bẻ khóa mà khách hàng không cần phải tự thao tác chỉnh tay thủ công bất kỳ cài đặt nào!
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2 shrink-0 self-start sm:self-center">
            <button
              onClick={handleRunMetaFacebookDeepPush}
              disabled={!isConnected || isMetaFixing || isVipFixing || isFixing || isEcoFixing}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-blue-500 via-indigo-500 to-cyan-400 hover:from-blue-400 hover:to-cyan-300 text-white text-xs font-black shadow-md shadow-blue-500/25 active:scale-95 disabled:opacity-40 transition-all flex items-center space-x-1.5"
            >
              <Zap className="w-3.5 h-3.5 fill-white" />
              <span>{isMetaFixing ? 'Đang chạy 8 lớp ADB...' : '1-Chạm Bẻ Khóa Meta Push'}</span>
            </button>
            <button
              onClick={() => setShowMetaGuide(!showMetaGuide)}
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-blue-500/30 text-xs font-bold transition-all flex items-center space-x-1"
            >
              <Info className="w-3.5 h-3.5" />
              <span>{showMetaGuide ? 'Thu Gọn Cơ Chế' : 'Cơ Chế 8 Lớp ADB'}</span>
            </button>
          </div>
        </div>

        {/* Khối giải thích chi tiết 8 Lớp ADB tự động cho Facebook */}
        {showMetaGuide && (
          <div className="pt-3 border-t border-blue-500/20 space-y-2.5 animate-in fade-in text-xs">
            <div className="font-bold text-cyan-300 flex items-center space-x-1.5">
              <span>🛡️ Chi Tiết 8 Lớp Lệnh ADB Tự Động Được Nạp Vào Thiết Bị (Không Cần Thao Tác Thủ Công):</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2.5">
              <div className="p-2.5 rounded-xl bg-[#0A0F1D]/80 border border-blue-500/20 space-y-1">
                <div className="font-bold text-white text-[11px] flex items-center space-x-1">
                  <span className="w-4 h-4 rounded-full bg-blue-500/20 text-cyan-300 flex items-center justify-center text-[9px] font-mono">1</span>
                  <span>NetPolicy Dữ Liệu Nền</span>
                </div>
                <p className="text-[10px] text-slate-300 leading-relaxed">
                  Lệnh <code className="text-cyan-300">netpolicy restrict-background-whitelist</code>: Cấp dữ liệu 4G/Wi-Fi không giới hạn cho Facebook, Messenger &amp; GMS xuyên suốt màn hình tắt.
                </p>
              </div>

              <div className="p-2.5 rounded-xl bg-[#0A0F1D]/80 border border-blue-500/20 space-y-1">
                <div className="font-bold text-white text-[11px] flex items-center space-x-1">
                  <span className="w-4 h-4 rounded-full bg-blue-500/20 text-cyan-300 flex items-center justify-center text-[9px] font-mono">2</span>
                  <span>Khởi Chạy Liên Kết</span>
                </div>
                <p className="text-[10px] text-slate-300 leading-relaxed">
                  Cấp <code className="text-cyan-300">ASSOCIATED_START allow</code> &amp; <code className="text-cyan-300">AUTO_START allow</code>: Cho phép Google Play Services trực tiếp đánh thức Facebook khi có ping.
                </p>
              </div>

              <div className="p-2.5 rounded-xl bg-[#0A0F1D]/80 border border-blue-500/20 space-y-1">
                <div className="font-bold text-white text-[11px] flex items-center space-x-1">
                  <span className="w-4 h-4 rounded-full bg-blue-500/20 text-cyan-300 flex items-center justify-center text-[9px] font-mono">3</span>
                  <span>Bật Daemon Meta MQTT</span>
                </div>
                <p className="text-[10px] text-slate-300 leading-relaxed">
                  Cưỡng chế <code className="text-cyan-300">pm enable MqttPushService</code> &amp; <code className="text-cyan-300">FcmListenerService</code> luôn hoạt động ngầm đón tin nhắn mới.
                </p>
              </div>

              <div className="p-2.5 rounded-xl bg-[#0A0F1D]/80 border border-blue-500/20 space-y-1">
                <div className="font-bold text-white text-[11px] flex items-center space-x-1">
                  <span className="w-4 h-4 rounded-full bg-blue-500/20 text-cyan-300 flex items-center justify-center text-[9px] font-mono">4</span>
                  <span>Kênh Thông Báo Cấp 4</span>
                </div>
                <p className="text-[10px] text-slate-300 leading-relaxed">
                  Thiết lập <code className="text-cyan-300">notification set_importance 4</code>: Mức ưu tiên cao nhất — Reo chuông và hiển thị banner pop-up đầu màn hình tức thì.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* BANNER TĂNG TỐC BIẾN ĐỘNG SỐ DƯ & MÃ OTP APP NGÂN HÀNG VIỆT NAM */}
      <div className="mt-4 p-4 rounded-2xl bg-gradient-to-r from-emerald-950/50 via-teal-950/40 to-[#0A0F1D] border border-emerald-500/40 shadow-xl relative overflow-hidden space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start space-x-3">
            <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 shrink-0">
              <CreditCard className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <div className="text-xs font-black text-white flex flex-wrap items-center gap-2">
                <span>💳 TĂNG TỐC THÔNG BÁO &amp; MÃ OTP ỨNG DỤNG TÀI CHÍNH (0S)</span>
                <span className="text-[9px] px-2 py-0.5 rounded-full bg-gradient-to-r from-emerald-500/20 to-teal-500/20 text-emerald-300 border border-emerald-500/35 font-mono font-bold">
                  TÀI CHÍNH · THANH TOÁN · OTP · VÍ ĐIỆN TỬ
                </span>
              </div>
              <p className="text-[11px] text-slate-300 mt-1 leading-relaxed">
                Khắc phục tình trạng <strong>thông báo biến động số dư đến chậm 5 - 15 phút</strong> hoặc <strong>mã OTP bị trễ đến mức hết hạn</strong>: Do người dùng không mở ứng dụng thường xuyên, Android tự hạ Standby Bucket xuống mức RARE và chặn quyền <code className="text-emerald-300">SCHEDULE_EXACT_ALARM</code>. Kịch bản ADB này cưỡng chế đưa ứng dụng vào Standby Bucket <strong>ACTIVE</strong>, cấp dữ liệu nền NetPolicy và bật <strong>Notification Importance Cấp 4</strong> để chuông nổ to kèm pop-up banner ngay lập tức 0s!
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2 shrink-0 self-start sm:self-center">
            <button
              onClick={handleRunVnBankingFastPush}
              disabled={!isConnected || isBankFixing || isMetaFixing || isVipFixing || isFixing || isEcoFixing}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-400 to-teal-400 hover:from-emerald-300 hover:to-teal-300 text-black text-xs font-black shadow-md shadow-emerald-500/25 active:scale-95 disabled:opacity-40 transition-all flex items-center space-x-1.5"
            >
              <Zap className="w-3.5 h-3.5 fill-black" />
              <span>{isBankFixing ? 'Đang tăng tốc...' : '1-Chạm Tăng Tốc OTP 0s'}</span>
            </button>
            <button
              onClick={() => setShowBankGuide(!showBankGuide)}
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-emerald-500/30 text-xs font-bold transition-all flex items-center space-x-1"
            >
              <Info className="w-3.5 h-3.5" />
              <span>{showBankGuide ? 'Thu Gọn Cơ Chế' : 'Cơ Chế ADB'}</span>
            </button>
          </div>
        </div>

        {/* Khối giải thích chi tiết cơ chế cho App Ngân Hàng */}
        {showBankGuide && (
          <div className="pt-3 border-t border-emerald-500/20 space-y-2.5 animate-in fade-in text-xs">
            <div className="font-bold text-emerald-300 flex items-center space-x-1.5">
              <span>🛡️ Các Lớp Bảo Đảm Tự Động Cho Ứng Dụng Ngân Hàng &amp; Ví Điện Tử:</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2.5">
              <div className="p-2.5 rounded-xl bg-[#0A0F1D]/80 border border-emerald-500/20 space-y-1">
                <div className="font-bold text-white text-[11px] flex items-center space-x-1">
                  <span className="w-4 h-4 rounded-full bg-emerald-500/20 text-emerald-300 flex items-center justify-center text-[9px] font-mono">1</span>
                  <span>Standby Bucket ACTIVE</span>
                </div>
                <p className="text-[10px] text-slate-300 leading-relaxed">
                  Lệnh <code className="text-emerald-300">am set-standby-bucket active</code>: Cấm hệ điều hành đẩy app ngân hàng vào trạng thái ngủ đông RARE do ít mở.
                </p>
              </div>

              <div className="p-2.5 rounded-xl bg-[#0A0F1D]/80 border border-emerald-500/20 space-y-1">
                <div className="font-bold text-white text-[11px] flex items-center space-x-1">
                  <span className="w-4 h-4 rounded-full bg-emerald-500/20 text-emerald-300 flex items-center justify-center text-[9px] font-mono">2</span>
                  <span>Báo Thức Chính Xác (OTP)</span>
                </div>
                <p className="text-[10px] text-slate-300 leading-relaxed">
                  Cấp <code className="text-emerald-300">SCHEDULE_EXACT_ALARM allow</code>: Bảo đảm đồng hồ đếm ngược OTP và nhận mã bảo mật kịp thời không bị trễ.
                </p>
              </div>

              <div className="p-2.5 rounded-xl bg-[#0A0F1D]/80 border border-emerald-500/20 space-y-1">
                <div className="font-bold text-white text-[11px] flex items-center space-x-1">
                  <span className="w-4 h-4 rounded-full bg-emerald-500/20 text-emerald-300 flex items-center justify-center text-[9px] font-mono">3</span>
                  <span>NetPolicy Dữ Liệu Nền</span>
                </div>
                <p className="text-[10px] text-slate-300 leading-relaxed">
                  Lệnh <code className="text-emerald-300">netpolicy restrict-background-whitelist</code>: Mở cổng Wi-Fi/4G đón thông báo biến động số dư tức khắc khi màn hình tắt.
                </p>
              </div>

              <div className="p-2.5 rounded-xl bg-[#0A0F1D]/80 border border-emerald-500/20 space-y-1">
                <div className="font-bold text-white text-[11px] flex items-center space-x-1">
                  <span className="w-4 h-4 rounded-full bg-emerald-500/20 text-emerald-300 flex items-center justify-center text-[9px] font-mono">4</span>
                  <span>Pop-up Banner Cấp 4</span>
                </div>
                <p className="text-[10px] text-slate-300 leading-relaxed">
                  Ép <code className="text-emerald-300">notification set_importance 4</code>: Khi có tiền chuyển tới, màn hình sáng lên và hiện pop-up banner ngay đỉnh màn hình.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* BANNER ĐẶC TRỊ BỘ BA CỨNG ĐẦU: FACEBOOK + TELEGRAM + GMAIL (HONOR VIP) */}
      <div className="mt-4 p-4 rounded-2xl bg-gradient-to-r from-amber-950/40 via-purple-950/30 to-[#0A0F1D] border border-amber-500/40 shadow-xl relative overflow-hidden space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start space-x-3">
            <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/30 shrink-0">
              <Crown className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <div className="text-xs font-black text-white flex flex-wrap items-center gap-2">
                <span>⚡ ĐẶC TRỊ BỘ BA CỨNG ĐẦU: FACEBOOK · TELEGRAM · GMAIL</span>
                <span className="text-[9px] px-2 py-0.5 rounded-full bg-gradient-to-r from-amber-500/20 to-rose-500/20 text-amber-300 border border-amber-500/35 font-mono font-bold">
                  HONOR MAGICOS CHUYÊN SÂU
                </span>
                <span className="text-[9px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-mono font-bold">
                  MIỄN PHÍ 100%
                </span>
              </div>
              <p className="text-[11px] text-slate-300 mt-1 leading-relaxed">
                Khắc phục 100% hiện tượng: <strong>Messenger có chuông nhưng Facebook tịt hoàn toàn</strong>, <strong>Gmail ngủ qua đêm phải mở app buổi sáng mới sync</strong>, và <strong>Telegram bị Bastet đóng socket ngầm</strong>. Kịch bản tự động bẻ khóa Bastet, cấp quyền Exact Alarms, gán Standby Bucket Active và giữ WiFi/4G liên tục 24/7!
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2 shrink-0 self-start sm:self-center">
            <button
              onClick={handleRunHonorVipTripleAppFix}
              disabled={!isConnected || isVipFixing}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-400 to-orange-400 hover:from-amber-300 hover:to-orange-300 text-black text-xs font-black shadow-md shadow-amber-500/25 active:scale-95 disabled:opacity-40 transition-all flex items-center space-x-1.5"
            >
              <Zap className="w-3.5 h-3.5 fill-black" />
              <span>{isVipFixing ? 'Đang chạy kịch bản...' : '1-Chạm Fix Triệt Để'}</span>
            </button>
            <button
              onClick={() => setShowVipGuide(!showVipGuide)}
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 text-xs font-bold transition-all flex items-center space-x-1"
            >
              <Info className="w-3.5 h-3.5" />
              <span>{showVipGuide ? 'Ẩn Hướng Dẫn' : '3 Bước Bổ Trợ'}</span>
            </button>
          </div>
        </div>

        {/* Khối Hướng Dẫn Bổ Trợ 3 Bước Cho Máy Honor */}
        {showVipGuide && (
          <div className="pt-3 border-t border-amber-500/20 space-y-2.5 animate-in fade-in text-xs">
            <div className="font-bold text-amber-300 flex items-center space-x-1.5">
              <span>📌 3 Bước Thiết Lập Bổ Trợ Trên Máy Honor (Để Đạt 100% Hiệu Quả Không Bao Giờ Trễ):</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5">
              <div className="p-3 rounded-xl bg-[#0A0F1D]/80 border border-amber-500/20 space-y-1.5">
                <div className="font-bold text-white flex items-center space-x-1.5">
                  <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-300 flex items-center justify-center text-[10px] font-mono">1</span>
                  <span>Khởi Chạy Ứng Dụng (App Launch)</span>
                </div>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  Vào <strong>Cài đặt ➔ Ứng dụng ➔ Khởi chạy ứng dụng</strong>. Tìm <strong>Facebook, Telegram, Gmail</strong>, gạt tắt &quot;Quản lý tự động&quot; sang <strong>Quản lý thủ công</strong> và <strong>BẬT CẢ 3 CẦN GẠT</strong> (Tự khởi chạy, Khởi chạy liên kết, Chạy trong nền).
                </p>
              </div>

              <div className="p-3 rounded-xl bg-[#0A0F1D]/80 border border-amber-500/20 space-y-1.5">
                <div className="font-bold text-white flex items-center space-x-1.5">
                  <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-300 flex items-center justify-center text-[10px] font-mono">2</span>
                  <span>Cài Đặt Nền Telegram</span>
                </div>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  Trong ứng dụng Telegram: Vào <strong>Settings ➔ Notifications and Sounds</strong>, cuộn xuống bật: <strong>Keep-Alive Service</strong> (Dịch vụ duy trì) và <strong>Background Connection</strong> (Kết nối nền).
                </p>
              </div>

              <div className="p-3 rounded-xl bg-[#0A0F1D]/80 border border-amber-500/20 space-y-1.5">
                <div className="font-bold text-white flex items-center space-x-1.5">
                  <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-300 flex items-center justify-center text-[10px] font-mono">3</span>
                  <span>Khởi Động Lại Điện Thoại</span>
                </div>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  Bấm nút <strong>Khởi Động Lại Ngay</strong> qua ADB ở bên dưới hoặc dùng phím nguồn điện thoại. Toàn bộ thiết lập socket FCM và App Standby Bucket Active mới bắt đầu có hiệu lực 100%!
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Banner giới thiệu công nghệ Hybrid Eco Battery */}
      <div className="mt-4 p-3.5 rounded-2xl bg-gradient-to-r from-emerald-950/40 via-teal-950/30 to-[#0A0F1D] border border-emerald-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-start space-x-3">
          <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 shrink-0 mt-0.5 sm:mt-0">
            <BatteryCharging className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs font-bold text-white flex items-center space-x-1.5">
              <span>Công Nghệ Đột Phá: Hybrid Eco Battery (Tiết Kiệm Pin Siêu Cấp &amp; Nổ Chuông 0s)</span>
              <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-mono">
                Android
              </span>
            </div>
            <p className="text-[11px] text-slate-300 mt-0.5 leading-relaxed">
              Giải quyết triệt để bài toán hóc búa: <strong>Vừa không ngốn pin, vừa nhận thông báo tức thì</strong>. Cơ chế tự động dập tắt 100% các daemon thu thập log chạy ngầm vô bổ, đưa app rác vào Deep Sleep, và chỉ ưu tiên mở kênh nhận thông báo đặc quyền cho FB, Zalo, Gmail, Telegram trên mọi thiết bị Honor, Xiaomi, Vivo, Oppo, Samsung!
            </p>
          </div>
        </div>
      </div>

      {/* TIẾN TRÌNH THỰC THI TRỰC TIẾP (LIVE TURBO PROGRESS BAR) */}
      {(isMasterFixing || isFixing || isEcoFixing || isVipFixing || isMetaFixing || isBankFixing) && execProgress && (
        <div className="mt-4 p-4 rounded-2xl bg-gradient-to-r from-slate-900 via-cyan-950/60 to-[#0A0F1D] border border-cyan-500/40 shadow-xl space-y-3 animate-in fade-in">
          {/* Header tiến trình */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
              <span className="text-xs font-black text-cyan-300 uppercase tracking-wide">
                {execProgress.modeName}
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-200 border border-cyan-500/30 font-mono font-bold flex items-center space-x-1">
                <Zap className="w-2.5 h-2.5 text-cyan-400 fill-cyan-400" />
                <span>TURBO ADB ENGINE</span>
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
              <span className="text-emerald-400 font-bold flex items-center space-x-1 bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Thành công: {execProgress.successCount}</span>
              </span>
              {execProgress.warningCount > 0 && (
                <span className="text-amber-400 font-bold flex items-center space-x-1 bg-amber-500/10 px-2 py-0.5 rounded-md border border-amber-500/20">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>Bỏ qua: {execProgress.warningCount}</span>
                </span>
              )}
              {execProgress.failCount > 0 && (
                <span className="text-rose-400 font-bold flex items-center space-x-1 bg-rose-500/10 px-2 py-0.5 rounded-md border border-rose-500/20">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>Lỗi: {execProgress.failCount}</span>
                </span>
              )}
              <span className="text-white font-bold bg-slate-800 px-2 py-0.5 rounded-md border border-slate-700">
                {execProgress.current} / {execProgress.total} ({execProgress.percent}%)
              </span>
            </div>
          </div>

          {/* Tác vụ hiện tại */}
          <div className="p-2.5 rounded-xl bg-slate-950/80 border border-cyan-500/20 flex items-center justify-between gap-2">
            <div className="truncate text-xs text-slate-200 flex items-center space-x-2">
              <span className="text-cyan-400 font-bold shrink-0">Đang tối ưu:</span>
              <span className="font-semibold text-white truncate font-sans">
                {execProgress.label || execProgress.cmd}
              </span>
            </div>
            {execProgress.pkg && (
              <span className="text-[10px] text-cyan-400/80 font-mono hidden md:inline shrink-0">
                {execProgress.pkg}
              </span>
            )}
          </div>

          {/* Thanh Tiến Trình Đa Sắc */}
          <div className="w-full bg-slate-800/80 h-3 rounded-full overflow-hidden p-0.5 border border-slate-700">
            <div
              className="bg-gradient-to-r from-cyan-400 via-teal-300 to-emerald-400 h-full rounded-full transition-all duration-150 shadow-md shadow-cyan-500/50"
              style={{ width: `${Math.max(execProgress.percent, 4)}%` }}
            />
          </div>
        </div>
      )}

      {/* BẢNG TỔNG KẾT KẾT QUẢ THỰC THI CHI TIẾT (POST-EXECUTION SUMMARY) */}
      {lastResult && !isMasterFixing && !isFixing && !isEcoFixing && !isVipFixing && !isMetaFixing && !isBankFixing && (
        <div className="mt-4 p-5 rounded-2xl bg-gradient-to-r from-[#0C1427] via-[#0E1A33] to-[#0A0F1D] border border-cyan-500/35 shadow-2xl space-y-4 animate-in fade-in">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-cyan-500/20 gap-3">
            <div className="flex items-start space-x-3">
              <div className={`p-2.5 rounded-xl shrink-0 ${
                lastResult.failCount === 0
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                  : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
              }`}>
                {lastResult.failCount === 0 ? <CheckCircle2 className="w-5 h-5" /> : <AlertTriangle className="w-5 h-5" />}
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <h4 className="text-sm font-black text-white">
                    BÁO CÁO KẾT QUẢ FIX THÔNG BÁO
                  </h4>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-mono font-bold">
                    Hoàn thành trong {(lastResult.durationMs / 1000).toFixed(1)}s (Tối ưu Turbo)
                  </span>
                </div>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                  {lastResult.failCount === 0
                    ? '100% các lớp bẻ khóa thông báo, Standby Bucket Active và giữ kết nối mạng xuyên đêm đã được thiết bị tiếp nhận thành công!'
                    : `Tiến trình đã hoàn tất với ${lastResult.successCount} thành công, ${lastResult.warningCount} bỏ qua an toàn và ${lastResult.failCount} lỗi.`}
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-2 shrink-0 self-end sm:self-center">
              <button
                onClick={() => setShowResultDetails(!showResultDetails)}
                className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-500/30 text-xs font-bold transition-all flex items-center space-x-1.5"
              >
                <Layers className="w-3.5 h-3.5" />
                <span>{showResultDetails ? 'Thu Gọn Chi Tiết' : 'Xem Chi Tiết Từng App / Lệnh'}</span>
              </button>
              <button
                onClick={() => setLastResult(null)}
                className="px-2.5 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white text-xs transition-all"
                title="Đóng bảng kết quả"
              >
                ✕
              </button>
            </div>
          </div>

          {/* BANNER BẮT BUỘC KHỞI ĐỘNG LẠI MÁY ĐỂ KÍCH HOẠT THÔNG BÁO */}
          <div className="p-4 rounded-xl bg-gradient-to-r from-amber-500/25 via-orange-500/20 to-rose-500/25 border-2 border-amber-400/80 shadow-lg shadow-amber-500/15 flex flex-col sm:flex-row sm:items-center justify-between gap-3 animate-pulse">
            <div className="flex items-start sm:items-center space-x-3">
              <div className="p-2.5 rounded-xl bg-amber-500/30 text-amber-300 shrink-0">
                <RotateCw className="w-6 h-6 animate-spin text-amber-300" />
              </div>
              <div>
                <div className="text-sm font-black text-amber-200 flex items-center space-x-2">
                  <span>⚡ BƯỚC BẮT BUỘC ĐỂ NHẢY THÔNG BÁO: KHỞI ĐỘNG LẠI ĐIỆN THOẠI!</span>
                </div>
                <p className="text-xs text-amber-100/90 mt-1 leading-relaxed">
                  Lệnh ADB đã nạp thành công vào hệ điều hành. Bạn <strong className="text-white underline font-bold">BẮT BUỘC PHẢI KHỞI ĐỘNG LẠI ĐIỆN THOẠI</strong> để kernel Android kích hoạt Doze Whitelist &amp; Standby Bucket 0s cho <strong>Facebook, Zalo, Gmail, Telegram X</strong> và các app ngân hàng!
                </p>
              </div>
            </div>

            <button
              onClick={handleRebootDevice}
              disabled={!isConnected || isRebooting}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 hover:from-amber-300 hover:to-orange-400 text-black font-black text-xs shadow-md shadow-amber-500/30 flex items-center justify-center space-x-2 shrink-0 transition-all cursor-pointer disabled:opacity-50 active:scale-95"
            >
              <RotateCw className={`w-4 h-4 ${isRebooting ? 'animate-spin' : ''}`} />
              <span>{isRebooting ? 'Đang gửi lệnh Reboot...' : rebootDone ? '✓ Đang Khởi Động Lại...' : 'Khởi Động Lại Ngay (1-Click)'}</span>
            </button>
          </div>

          {/* 3 Thẻ Thống Kê Số Lượng Rõ Ràng */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* Thành công */}
            <div className="p-3.5 rounded-xl bg-emerald-950/30 border border-emerald-500/30 flex items-center justify-between">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 rounded-lg bg-emerald-500/20 text-emerald-400">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-[11px] text-emerald-300/80 uppercase font-bold tracking-wider">Thành Công</div>
                  <div className="text-base font-black text-emerald-300 font-mono">{lastResult.successCount} thao tác</div>
                </div>
              </div>
              <span className="text-xs text-emerald-400 font-mono font-bold bg-emerald-500/15 px-2 py-0.5 rounded-md">
                {Math.round((lastResult.successCount / (lastResult.total || 1)) * 100)}%
              </span>
            </div>

            {/* Cảnh báo / Bỏ qua an toàn */}
            <div className="p-3.5 rounded-xl bg-amber-950/30 border border-amber-500/30 flex items-center justify-between">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 rounded-lg bg-amber-500/20 text-amber-400">
                  <AlertTriangle className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-[11px] text-amber-300/80 uppercase font-bold tracking-wider">Bỏ Qua An Toàn</div>
                  <div className="text-base font-black text-amber-300 font-mono">{lastResult.warningCount} cảnh báo</div>
                </div>
              </div>
              <span className="text-[10px] text-amber-300/80 max-w-[85px] text-right font-sans">
                (Gói không có trên ROM)
              </span>
            </div>

            {/* Lỗi thất bại */}
            <div className="p-3.5 rounded-xl bg-rose-950/30 border border-rose-500/30 flex items-center justify-between">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 rounded-lg bg-rose-500/20 text-rose-400">
                  <AlertCircle className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-[11px] text-rose-300/80 uppercase font-bold tracking-wider">Lỗi Cần Lưu Ý</div>
                  <div className="text-base font-black text-rose-300 font-mono">{lastResult.failCount} lỗi</div>
                </div>
              </div>
              <span className="text-[10px] text-rose-300/80 max-w-[85px] text-right font-sans font-bold">
                {lastResult.failCount === 0 ? '✓ Hoàn hảo 0 lỗi' : 'Kiểm tra cáp'}
              </span>
            </div>
          </div>

          {/* Danh Sách Chi Tiết Accordion */}
          {showResultDetails && (
            <div className="pt-3 border-t border-slate-700/50 space-y-2 animate-in fade-in">
              <div className="text-xs font-bold text-slate-300 flex items-center justify-between">
                <span>📋 Danh sách từng thao tác ({lastResult.details.length} mục):</span>
                <span className="text-[11px] text-slate-400">
                  <span className="text-emerald-400">●</span> Thành công · <span className="text-amber-400">●</span> Bỏ qua an toàn · <span className="text-rose-400">●</span> Lỗi
                </span>
              </div>
              <div className="max-h-64 overflow-y-auto space-y-1.5 pr-1 custom-scrollbar">
                {lastResult.details.map((detail, idx) => (
                  <div
                    key={idx}
                    className={`p-2.5 rounded-xl text-xs flex items-start justify-between border ${
                      detail.error
                        ? 'bg-rose-950/25 border-rose-500/30 text-rose-300'
                        : detail.isWarning
                        ? 'bg-amber-950/20 border-amber-500/25 text-amber-300'
                        : 'bg-slate-900/70 border-emerald-500/25 text-slate-200'
                    }`}
                  >
                    <div className="flex items-start space-x-2.5 overflow-hidden mr-2">
                      {detail.error ? (
                        <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                      ) : detail.isWarning ? (
                        <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                      ) : (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      )}
                      <div className="truncate">
                        <div className="font-bold text-white text-xs">
                          {detail.label || (isAdmin ? detail.cmd : 'Tối ưu ứng dụng')}
                        </div>
                        {isAdmin && detail.pkg && (
                          <div className="text-[10px] text-cyan-400 font-mono mt-0.5">{detail.pkg}</div>
                        )}
                        {isAdmin && detail.output && !detail.error && (
                          <div className="text-[10px] text-slate-400 truncate mt-0.5 font-mono">
                            {detail.output}
                          </div>
                        )}
                        {detail.error && (
                          <div className="text-[10px] text-rose-400 font-mono mt-0.5 font-semibold">
                            {isAdmin ? detail.error : 'Vui lòng kiểm tra lại cáp kết nối và mở khóa màn hình'}
                          </div>
                        )}
                      </div>
                    </div>

                    <span className={`text-[10px] px-2 py-0.5 rounded-md font-bold font-mono shrink-0 ${
                      detail.error
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                        : detail.isWarning
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                        : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    }`}>
                      {detail.error ? 'LỖI' : detail.isWarning ? 'BỎ QUA' : 'OK ✓'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Thông tin 5 lớp bảo đảm */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 my-5">
        <div className="p-3.5 rounded-xl bg-[#0A0F1D]/80 border border-cyan-500/10">
          <div className="flex items-center space-x-2 text-xs font-semibold text-[#00F0FF] mb-1">
            <Shield className="w-4 h-4" />
            <span>1. Danh Sách Trắng Doze &amp; FCM</span>
          </div>
          <p className="text-[11px] text-slate-400 leading-relaxed">
            Miễn trừ Android Doze và cưỡng chế cổng Google Play Services (<code className="text-cyan-300">com.google.android.gms</code>) luôn online để nhận thông báo Gmail &amp; Facebook.
          </p>
        </div>

        <div className="p-3.5 rounded-xl bg-[#0A0F1D]/80 border border-cyan-500/10">
          <div className="flex items-center space-x-2 text-xs font-semibold text-purple-400 mb-1">
            <Activity className="w-4 h-4" />
            <span>2. AppOps Khóa Quyền Nền</span>
          </div>
          <p className="text-[11px] text-slate-400 leading-relaxed">
            Mở toàn bộ quyền <code className="text-purple-300">RUN_ANY_IN_BACKGROUND</code>, <code className="text-purple-300">WAKE_LOCK</code>, <code className="text-purple-300">START_FOREGROUND</code>, cấm hệ điều hành thu hồi.
          </p>
        </div>

        <div className="p-3.5 rounded-xl bg-[#0A0F1D]/80 border border-cyan-500/10">
          <div className="flex items-center space-x-2 text-xs font-semibold text-rose-400 mb-1">
            <Layers className="w-4 h-4" />
            <span>3. Đóng Băng Bastet Socket Killer</span>
          </div>
          <p className="text-[11px] text-slate-400 leading-relaxed">
            Đóng băng tiến trình Bastet Service (chuyên gia tự ý ngắt TCP socket của Zalo, Telegram và Facebook khi máy tắt màn hình).
          </p>
        </div>
      </div>

      {/* Bộ Chọn Phân Loại 2 Nhóm App Rõ Ràng: Người Dùng & Dịch Vụ Google vs App Hệ Thống Nội Địa */}
      <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-2.5 p-1.5 rounded-2xl bg-[#0A0F1D]/80 border border-cyan-500/20">
        <button
          onClick={() => { setClassificationTab('user'); setCurrentPage(1); }}
          className={`p-3 rounded-xl flex items-center justify-between text-left transition-all ${
            classificationTab === 'user'
              ? 'bg-gradient-to-r from-cyan-500/25 to-blue-500/25 border border-cyan-400 text-white shadow-md shadow-cyan-500/10 ring-1 ring-cyan-400/40'
              : 'hover:bg-slate-800/60 text-slate-400 border border-transparent'
          }`}
        >
          <div className="flex items-center space-x-3">
            <div className={`p-2.5 rounded-xl ${classificationTab === 'user' ? 'bg-cyan-500 text-black' : 'bg-slate-800 text-cyan-400'}`}>
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-white flex items-center space-x-1.5">
                <span>1. App Người Dùng &amp; Dịch Vụ Google</span>
                <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-mono font-bold">
                  CẦN FIX THÔNG BÁO
                </span>
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                Zalo, Facebook, Messenger, Telegram, Ngân hàng, Gmail, Google Services...
              </div>
            </div>
          </div>
          <span className="font-mono text-xs font-bold text-cyan-300 px-2.5 py-1 rounded-lg bg-cyan-950/80 border border-cyan-500/30">
            {userApps.length} App
          </span>
        </button>

        <button
          onClick={() => { setClassificationTab('system'); setCurrentPage(1); }}
          className={`p-3 rounded-xl flex items-center justify-between text-left transition-all ${
            classificationTab === 'system'
              ? 'bg-gradient-to-r from-purple-500/25 to-slate-800 border border-purple-400 text-white shadow-md shadow-purple-500/10 ring-1 ring-purple-400/40'
              : 'hover:bg-slate-800/60 text-slate-400 border border-transparent'
          }`}
        >
          <div className="flex items-center space-x-3">
            <div className={`p-2.5 rounded-xl ${classificationTab === 'system' ? 'bg-purple-500 text-white' : 'bg-slate-800 text-purple-400'}`}>
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-white flex items-center space-x-1.5">
                <span>2. App Hệ Thống Nội Địa (ROM Gốc)</span>
                <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-slate-800 text-slate-400 border border-slate-700 font-mono">
                  KHÔNG CẦN FIX
                </span>
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                Honor Mall, HiSearch, Game Center, YOYO, Theme Store nội địa...
              </div>
            </div>
          </div>
          <span className="font-mono text-xs font-bold text-purple-300 px-2.5 py-1 rounded-lg bg-purple-950/80 border border-purple-500/30">
            {systemApps.length} App
          </span>
        </button>
      </div>

      {/* Banner Khuyến Nghị Khi Đang Xem Từng Tab */}
      {classificationTab === 'system' ? (
        <div className="mt-3 p-3.5 rounded-2xl bg-gradient-to-r from-purple-950/30 via-slate-900/60 to-[#0A0F1D] border border-purple-500/30 text-xs text-purple-200 flex items-start space-x-2.5">
          <ShieldCheck className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold text-purple-300">💡 Tại sao không cần fix thông báo cho App Hệ Thống Nội Địa?</span>
            <p className="text-[11px] text-slate-300 mt-0.5 leading-relaxed">
              Các ứng dụng hệ thống nội địa Trung Quốc (Honor Mall, Theme Store, Game Center, YOYO, Cửa hàng ứng dụng của hãng...) không phải là ứng dụng liên lạc hay công việc hàng ngày. <strong>Tuyệt đối không cần bật chạy ngầm cho các app này</strong> để máy tiết kiệm pin tối đa, chạy mát và không bị spam thông báo rác từ thị trường nội địa!
            </p>
          </div>
        </div>
      ) : (
        <div className="mt-3 p-3.5 rounded-2xl bg-gradient-to-r from-cyan-950/30 via-slate-900/60 to-[#0A0F1D] border border-cyan-500/30 text-xs text-cyan-200 flex items-start space-x-2.5">
          <CheckCircle2 className="w-4 h-4 text-[#00F0FF] shrink-0 mt-0.5" />
          <div>
            <span className="font-bold text-[#00F0FF]">Tập Trung Fix Thông Báo 100% Cho App Người Dùng &amp; Dịch Vụ Google</span>
            <p className="text-[11px] text-slate-300 mt-0.5 leading-relaxed">
              Toàn bộ chuông thông báo bị trễ trên điện thoại nội địa chỉ xảy ra ở các ứng dụng nhắn tin OTT (Zalo, Messenger, Telegram), Mạng xã hội, Email và Ngân hàng. Hệ thống đã chọn sẵn các ứng dụng quan trọng, bạn chỉ cần bấm nút <strong>Fix Thông Báo</strong> ở trên.
            </p>
          </div>
        </div>
      )}

      {/* Search and Filter Presets */}
      <div className="mt-4">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 mb-3">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full">
            <div className="relative w-full sm:w-72 md:w-80">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={
                  classificationTab === 'user'
                    ? "Tìm app người dùng (Zalo, FB, bank, mail...)..."
                    : "Tìm app hệ thống nội địa (Honor, Huawei, Miui...)..."
                }
                className="w-full bg-[#0A0F1D] border border-cyan-500/20 rounded-xl pl-10 pr-3.5 py-2 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 shadow-inner"
              />
            </div>

            {classificationTab === 'user' ? (
              <div className="grid grid-cols-2 xs:grid-cols-4 sm:flex items-center gap-1.5 w-full sm:w-auto">
                <button
                  onClick={() => setActiveFilter('important')}
                  className={`px-2.5 py-1.5 rounded-xl text-xs font-medium text-center transition-all ${
                    activeFilter === 'important'
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  Quan Trọng
                </button>
                <button
                  onClick={() => setActiveFilter('social')}
                  className={`px-2.5 py-1.5 rounded-xl text-xs font-medium text-center transition-all ${
                    activeFilter === 'social'
                      ? 'bg-cyan-500/20 text-[#00F0FF] border border-cyan-500/40 font-bold'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  Mạng Xã Hội
                </button>
                <button
                  onClick={() => setActiveFilter('banking')}
                  className={`px-2.5 py-1.5 rounded-xl text-xs font-medium text-center transition-all ${
                    activeFilter === 'banking'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  Ngân Hàng
                </button>
                <button
                  onClick={() => setActiveFilter('all')}
                  className={`px-2.5 py-1.5 rounded-xl text-xs font-medium text-center transition-all ${
                    activeFilter === 'all'
                      ? 'bg-[#00F0FF] text-black font-bold'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  Tất Cả ({userApps.length})
                </button>
              </div>
            ) : (
              <div className="text-xs text-slate-400 font-mono flex items-center px-2 py-1 bg-slate-900/60 rounded-xl border border-slate-800">
                <span>Hiển thị {filteredApps.length} ứng dụng hệ thống (Mặc định không chọn để tiết kiệm pin)</span>
              </div>
            )}
          </div>

          <div className="flex items-center space-x-2 text-xs self-end sm:self-auto flex-wrap gap-y-1">
            {classificationTab === 'user' && (
              <>
                <button
                  onClick={handleBatchWhitelistBattery}
                  disabled={!isConnected || selectedApps.length === 0 || isWhitelistingBattery}
                  className="px-2.5 py-1 rounded-lg bg-teal-500/20 hover:bg-teal-500/30 text-teal-300 border border-teal-500/40 font-semibold flex items-center space-x-1 transition-all disabled:opacity-40"
                  title="Cấp quyền bỏ qua hạn chế pin và cho phép chạy ngầm vĩnh viễn"
                >
                  <BatteryCharging className="w-3 h-3 text-teal-300" />
                  <span>Cấp Quyền Không Giới Hạn Pin ({selectedApps.filter(p => userApps.some(u => u.package === p)).length})</span>
                </button>
                <span className="text-slate-600 hidden sm:inline">•</span>
                <button
                  onClick={handleSelectImportantOnly}
                  className="text-amber-400 hover:text-amber-300 hover:underline font-semibold"
                >
                  Chọn Quan Trọng
                </button>
                <span className="text-slate-600">•</span>
              </>
            )}
            <button
              onClick={handleSelectAll}
              className="text-[#00F0FF] hover:underline"
            >
              {classificationTab === 'user' ? 'Chọn toàn bộ App Người Dùng' : 'Chọn App Hệ Thống'}
            </button>
            <span className="text-slate-600">•</span>
            <button
              onClick={handleDeselectAll}
              className="text-slate-400 hover:text-slate-300 hover:underline"
            >
              Bỏ chọn
            </button>
          </div>
        </div>

        {/* Danh sách thẻ app */}
        {!isConnected ? (
          <div className="p-8 text-center text-slate-400 space-y-2 rounded-xl border border-cyan-500/10 bg-[#0A0F1D]/60">
            <Scan className="w-8 h-8 text-slate-600 mx-auto mb-2" />
            <p className="text-sm font-semibold text-slate-300">Chưa kết nối thiết bị Android</p>
            <p className="text-xs text-slate-500">
              Vui lòng cắm cáp USB và nhấn &quot;Kết Nối Cáp&quot; để hệ thống tự động phân loại ứng dụng trên máy bạn.
            </p>
          </div>
        ) : isScanning && filteredApps.length === 0 ? (
          <div className="p-8 text-center text-cyan-400 space-y-3 rounded-xl border border-cyan-500/10 bg-[#0A0F1D]/60">
            <div className="w-7 h-7 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin mx-auto" />
            <p className="text-xs font-semibold">{scanStatusText || 'Đang quét và phân loại ứng dụng trên thiết bị qua WebADB...'}</p>
            <div className="w-48 mx-auto bg-slate-800 rounded-full h-1.5 overflow-hidden">
              <div className="bg-cyan-400 h-1.5 transition-all duration-300" style={{ width: `${scanProgress}%` }} />
            </div>
          </div>
        ) : filteredApps.length === 0 ? (
          <div className="p-8 text-center text-slate-400 space-y-2 rounded-xl border border-cyan-500/10 bg-[#0A0F1D]/60">
            <p className="text-xs text-slate-500">
              Không tìm thấy ứng dụng phù hợp trong nhóm này. Hãy nhấn &quot;Quét App Trên Máy&quot; để quét lại.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {/* Thanh tiến độ quét mượt mà ở trên cùng */}
            {isScanning && (
              <div className="p-2.5 rounded-xl bg-cyan-950/40 border border-cyan-500/30 space-y-1.5 animate-in fade-in">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center space-x-2 text-cyan-300 font-semibold">
                    <div className="w-3.5 h-3.5 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
                    <span className="text-[11px]">{scanStatusText || 'Đang đồng bộ danh sách ứng dụng...'}</span>
                  </div>
                  <span className="font-mono text-xs font-bold text-cyan-400">{scanProgress}%</span>
                </div>
                <div className="w-full bg-slate-800/80 rounded-full h-1 overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-cyan-400 to-blue-500 h-1 transition-all duration-300"
                    style={{ width: `${scanProgress}%` }}
                  />
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2.5 max-h-[340px] overflow-y-auto p-1">
              {filteredApps
                .slice((currentPage - 1) * pageSize, currentPage * pageSize)
                .map((app) => {
                const isSelected = selectedApps.includes(app.package);
                const isUserType = app.appType === 'user';

                return (
                  <button
                    key={app.id}
                    onClick={() => toggleApp(app.package)}
                    className={`flex items-center justify-between p-2.5 rounded-xl border text-xs transition-all text-left ${
                      isSelected
                        ? isUserType
                          ? 'bg-cyan-500/15 border-cyan-500/40 text-white shadow-sm shadow-cyan-500/10'
                          : 'bg-purple-500/15 border-purple-500/40 text-purple-200'
                        : isUserType
                          ? 'bg-[#0A0F1D]/60 border-slate-800 text-slate-300 hover:border-slate-700'
                          : 'bg-[#0A0F1D]/40 border-slate-900 text-slate-500 hover:border-slate-800 opacity-80'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5 min-w-0 pr-1">
                      <div
                        className={`w-2 h-2 rounded-full shrink-0 ${
                          isSelected
                            ? isUserType ? 'bg-[#00F0FF] shadow-sm shadow-cyan-400' : 'bg-purple-400'
                            : 'bg-slate-700'
                        }`}
                      />
                      <div className="min-w-0">
                        <div className="font-semibold truncate text-xs">{app.name}</div>
                        <div className="flex items-center space-x-1.5 mt-0.5 flex-wrap gap-y-0.5">
                          <span className={`text-[9px] font-mono truncate max-w-[120px] ${isUserType ? 'text-cyan-400' : 'text-slate-500'}`}>
                            {app.package}
                          </span>
                          {app.isGoogle ? (
                            <span className="text-[8px] px-1 py-0.2 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-semibold shrink-0">
                              Google FCM
                            </span>
                          ) : app.isImportant ? (
                            <span className="text-[8px] px-1 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 font-semibold shrink-0">
                              Quan Trọng
                            </span>
                          ) : !isUserType ? (
                            <span className="text-[8px] px-1 py-0.2 rounded bg-slate-800 text-slate-400 border border-slate-700 shrink-0">
                              ROM Nội Địa
                            </span>
                          ) : null}
                        </div>
                      </div>
                    </div>
                    {isSelected && (
                      <Check className={`w-3.5 h-3.5 shrink-0 ml-1 ${isUserType ? 'text-[#00F0FF]' : 'text-purple-400'}`} />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Phân trang danh sách ứng dụng thông báo */}
            <Pagination
              currentPage={currentPage}
              totalItems={filteredApps.length}
              pageSize={pageSize}
              onPageChange={(p) => setCurrentPage(p)}
            />
          </div>
        )}

        {/* Toggle Bastet */}
        <div className="mt-4 pt-3 border-t border-cyan-500/10 flex items-center space-x-2.5">
          <input
            type="checkbox"
            id="disableBastet"
            checked={disableBastet}
            onChange={(e) => setDisableBastet(e.target.checked)}
            className="w-4 h-4 rounded bg-slate-900 border-cyan-500/30 text-cyan-500 focus:ring-0 focus:ring-offset-0 cursor-pointer"
          />
          <label htmlFor="disableBastet" className="text-xs text-slate-300 cursor-pointer select-none">
            {detectedBrandId === 'xiaomi' ? (
              <>Khóa cưỡng chế tiến trình ngắt kết nối <strong className="text-amber-300 font-mono">com.xiaomi.joyose &amp; PowerKeeper</strong> (Bắt buộc để Zalo, FB, Gmail nổ chuông 0s)</>
            ) : detectedBrandId === 'samsung' ? (
              <>Khóa cưỡng chế tiến trình <strong className="text-amber-300 font-mono">Game Optimizing Service (GOS)</strong> (Bắt buộc để Zalo, FB, Gmail nổ chuông 0s)</>
            ) : detectedBrandId === 'oppo_realme_oneplus' ? (
              <>Bẻ khóa giới hạn Doze ColorOS &amp; <strong className="text-amber-300 font-mono">com.oppo.qualityprotect</strong> (Bắt buộc để Zalo, FB, Gmail nổ chuông 0s)</>
            ) : detectedBrandId === 'vivo_iqoo' ? (
              <>Khóa cưỡng chế tiến trình <strong className="text-amber-300 font-mono">com.vivo.daemonService</strong> (Bắt buộc để Zalo, FB, Gmail nổ chuông 0s)</>
            ) : (
              <>Khóa cưỡng chế tiến trình ngắt kết nối <strong className="text-amber-300 font-mono">com.hihonor.bastet.service &amp; PowerGenie</strong> (Bắt buộc để Facebook &amp; Gmail không bao giờ trễ)</>
            )}
          </label>
        </div>
      </div>
    </div>
  );
};
