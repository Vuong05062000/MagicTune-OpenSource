'use client';

import React, { useState } from 'react';
import {
  X,
  User,
  Mail,
  Smartphone,
  ShieldCheck,
  Crown,
  KeyRound,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  Calendar,
  Clock,
  Activity,
  Layers,
  Sparkles,
  QrCode
} from 'lucide-react';
import { UserActivityLog, formatVietnamDateTime, getRelativeTimeString } from '@/lib/firebase/config';
import { Pagination } from '@/components/common/Pagination';

interface UserDetailModalProps {
  user: {
    userId: string;
    displayName?: string;
    email?: string;
    phone?: string;
    photoURL?: string;
    role: 'admin' | 'registered';
    emailVerified?: boolean;
    primaryProvider?: string;
    linkedProviders?: string[];
    providerDetails?: any[];
    deviceModel?: string;
    actionCount: number;
    lastActive: string;
    lastAction: string;
    lastLoginAt?: number;
    createdAt?: number;
    lastActiveTimestamp?: number;
    historyLogs?: UserActivityLog[];
  };
  onClose: () => void;
  isSuperAdmin: boolean;
  isCurrentAdmin: boolean;
  isVip: boolean;
  onToggleVip: () => void;
  onToggleAdmin: () => void;
}

export const UserDetailModal: React.FC<UserDetailModalProps> = ({
  user,
  onClose,
  isSuperAdmin,
  isCurrentAdmin,
  isVip,
  onToggleVip,
  onToggleAdmin
}) => {
  const [copiedUid, setCopiedUid] = useState(false);
  const [historyPage, setHistoryPage] = useState(1);
  const historyPageSize = 5;

  const handleCopyUid = () => {
    navigator.clipboard.writeText(user.userId);
    setCopiedUid(true);
    setTimeout(() => setCopiedUid(false), 2000);
  };

  const displayName = user.displayName && user.displayName.trim() && user.displayName !== 'Chưa cập nhật tên'
    ? user.displayName
    : (user.email ? user.email.split('@')[0] : 'Chưa cập nhật họ tên');

  const linkedList = user.linkedProviders || [];
  const isGoogleLinked = linkedList.some(p => p.includes('google'));
  const isFacebookLinked = linkedList.some(p => p.includes('facebook'));
  const isPhoneLinked = linkedList.some(p => p.includes('phone')) || Boolean(user.phone);
  const isPasswordLinked = linkedList.some(p => p.includes('password'));

  const lastDevice = user.deviceModel && user.deviceModel.trim() && user.deviceModel !== 'HONOR Device'
    ? user.deviceModel
    : 'Không rõ';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-3xl max-h-[92vh] flex flex-col rounded-3xl border border-cyan-500/30 bg-[#0F172A]/95 shadow-2xl shadow-cyan-950/60 overflow-hidden">
        {/* Header Modal */}
        <div className="p-5 sm:p-6 border-b border-slate-800 bg-gradient-to-r from-[#111A2E] via-[#0E1B38] to-[#13112E] flex items-start justify-between gap-4">
          <div className="flex items-center space-x-4">
            {user.photoURL ? (
              <img
                src={user.photoURL}
                alt={displayName}
                className="w-14 h-14 rounded-2xl border-2 border-cyan-400 object-cover shadow-lg shrink-0"
              />
            ) : (
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-cyan-500 via-indigo-600 to-purple-600 flex items-center justify-center text-xl font-black text-white shrink-0 shadow-lg border border-cyan-400/40">
                {(displayName || 'U')[0].toUpperCase()}
              </div>
            )}
            <div className="min-w-0">
              <div className="flex items-center space-x-2 flex-wrap gap-y-1">
                <h3 className="text-base sm:text-lg font-black text-white truncate">{displayName}</h3>
                {isVip && (
                  <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-black uppercase flex items-center space-x-1 shadow-sm">
                    <Crown className="w-3 h-3 text-amber-400" />
                    <span>VIP Trọn Đời</span>
                  </span>
                )}
                {isSuperAdmin ? (
                  <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-bold flex items-center space-x-1">
                    <ShieldCheck className="w-3 h-3 text-amber-400" />
                    <span>Super Admin</span>
                  </span>
                ) : isCurrentAdmin ? (
                  <span className="px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-[10px] font-bold flex items-center space-x-1">
                    <ShieldCheck className="w-3 h-3 text-cyan-400" />
                    <span>Quản Trị Viên</span>
                  </span>
                ) : (
                  <span className="px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30 text-[10px] font-bold">
                    Thành Viên Đăng Ký
                  </span>
                )}
              </div>

              <div className="flex items-center space-x-2 text-xs text-slate-400 mt-1 flex-wrap">
                <span className="text-cyan-300 font-mono">{user.email || user.phone || 'Chưa có thông tin liên hệ'}</span>
                {user.emailVerified && (
                  <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-1.5 py-0.2 rounded border border-emerald-500/30 font-semibold">
                    Đã xác minh email
                  </span>
                )}
              </div>

              <div className="flex items-center space-x-2 mt-1.5">
                <span className="text-[10px] text-slate-500 font-mono">UID: {user.userId}</span>
                <button
                  onClick={handleCopyUid}
                  className="p-1 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-all text-[10px] flex items-center space-x-1"
                  title="Sao chép UID"
                >
                  {copiedUid ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedUid ? 'Đã chép' : 'Chép UID'}</span>
                </button>
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-all shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Nội dung chi tiết cuộn */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6 flex-1 text-slate-200 text-xs">
          {/* KHỐI 1: PHƯƠNG THỨC ĐĂNG NHẬP & LIÊN KẾT */}
          <div className="rounded-2xl bg-[#111A2E]/80 border border-cyan-500/20 p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="font-bold text-white text-xs uppercase tracking-wider flex items-center space-x-2">
                <KeyRound className="w-4 h-4 text-[#00F0FF]" />
                <span>Phương Thức Đăng Nhập &amp; Tài Khoản Đã Liên Kết</span>
              </span>
              <span className="text-[10px] text-slate-400 font-mono">
                Chính: <strong className="text-cyan-300 uppercase">{user.primaryProvider || 'Email/Password'}</strong>
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              {/* Google */}
              <div className={`p-3 rounded-xl border flex items-center justify-between ${
                isGoogleLinked
                  ? 'bg-red-500/10 border-red-500/30 text-white'
                  : 'bg-slate-900/60 border-slate-800 text-slate-500'
              }`}>
                <div className="flex items-center space-x-2.5">
                  <div className={`w-7 h-7 rounded-lg flex items-center justify-center font-black text-xs ${
                    isGoogleLinked ? 'bg-red-500 text-white shadow-md shadow-red-500/30' : 'bg-slate-800 text-slate-400'
                  }`}>
                    G
                  </div>
                  <div>
                    <div className="font-bold text-xs">Tài khoản Google</div>
                    <div className="text-[10px] text-slate-400">
                      {isGoogleLinked ? (user.email?.includes('@gmail.com') ? user.email : 'Đã liên kết thành công') : 'Chưa liên kết'}
                    </div>
                  </div>
                </div>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  isGoogleLinked ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-500'
                }`}>
                  {isGoogleLinked ? '✓ Đã Kết Nối' : 'Chưa'}
                </span>
              </div>

              {/* Facebook */}
              <div className={`p-3 rounded-xl border flex items-center justify-between ${
                isFacebookLinked
                  ? 'bg-blue-500/10 border-blue-500/30 text-white'
                  : 'bg-slate-900/60 border-slate-800 text-slate-500'
              }`}>
                <div className="flex items-center space-x-2.5">
                  <div className={`w-7 h-7 rounded-lg flex items-center justify-center font-black text-xs ${
                    isFacebookLinked ? 'bg-blue-600 text-white shadow-md shadow-blue-500/30' : 'bg-slate-800 text-slate-400'
                  }`}>
                    f
                  </div>
                  <div>
                    <div className="font-bold text-xs">Tài khoản Facebook</div>
                    <div className="text-[10px] text-slate-400">
                      {isFacebookLinked ? 'Đã liên kết Facebook ID' : 'Chưa liên kết'}
                    </div>
                  </div>
                </div>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  isFacebookLinked ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-500'
                }`}>
                  {isFacebookLinked ? '✓ Đã Kết Nối' : 'Chưa'}
                </span>
              </div>

              {/* Số điện thoại (SMS OTP) */}
              <div className={`p-3 rounded-xl border flex items-center justify-between ${
                isPhoneLinked
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-white'
                  : 'bg-slate-900/60 border-slate-800 text-slate-500'
              }`}>
                <div className="flex items-center space-x-2.5">
                  <div className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs ${
                    isPhoneLinked ? 'bg-emerald-500 text-black shadow-md shadow-emerald-500/30 font-bold' : 'bg-slate-800 text-slate-400'
                  }`}>
                    <Smartphone className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-bold text-xs">Số điện thoại (SMS OTP)</div>
                    <div className="text-[10px] text-slate-400">
                      {user.phone || (isPhoneLinked ? 'Đã xác thực OTP' : 'Chưa liên kết')}
                    </div>
                  </div>
                </div>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  isPhoneLinked ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-500'
                }`}>
                  {isPhoneLinked ? '✓ Đã Xác Thực' : 'Chưa'}
                </span>
              </div>

              {/* Mật khẩu tĩnh */}
              <div className={`p-3 rounded-xl border flex items-center justify-between ${
                isPasswordLinked
                  ? 'bg-purple-500/10 border-purple-500/30 text-white'
                  : 'bg-slate-900/60 border-slate-800 text-slate-500'
              }`}>
                <div className="flex items-center space-x-2.5">
                  <div className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs ${
                    isPasswordLinked ? 'bg-purple-500 text-white shadow-md shadow-purple-500/30' : 'bg-slate-800 text-slate-400'
                  }`}>
                    <KeyRound className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-bold text-xs">Email &amp; Mật khẩu tĩnh</div>
                    <div className="text-[10px] text-slate-400">
                      {isPasswordLinked ? 'Đã thiết lập mật khẩu đăng nhập' : 'Dùng OAuth / Không có pass'}
                    </div>
                  </div>
                </div>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  isPasswordLinked ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-500'
                }`}>
                  {isPasswordLinked ? '✓ Đã Thiết Lập' : 'Chưa'}
                </span>
              </div>
            </div>
          </div>

          {/* KHỐI 2: THIẾT BỊ CUỐI & MỐC THỜI GIAN */}
          <div className="rounded-2xl bg-[#111A2E]/80 border border-slate-800 p-4 space-y-3">
            <div className="border-b border-slate-800 pb-2">
              <span className="font-bold text-white text-xs uppercase tracking-wider flex items-center space-x-2">
                <Smartphone className="w-4 h-4 text-emerald-400" />
                <span>Thông Tin Thiết Bị Cuối &amp; Phiên Kết Nối</span>
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              <div className="p-3 rounded-xl bg-[#0A0F1D] border border-slate-800">
                <div className="text-slate-400 text-[10px] mb-1">Thiết bị sử dụng cuối cùng:</div>
                <div className={`font-mono font-bold text-sm ${
                  lastDevice === 'Không rõ' ? 'text-slate-500 italic' : 'text-cyan-300'
                }`}>
                  {lastDevice}
                </div>
                <div className="text-[10px] text-slate-500 mt-1">Ghi nhận qua WebUSB / ADB Handshake</div>
              </div>

              <div className="p-3 rounded-xl bg-[#0A0F1D] border border-slate-800">
                <div className="text-slate-400 text-[10px] mb-1">Lần hoạt động gần nhất:</div>
                <div className="text-white font-semibold text-xs flex items-center space-x-1.5 flex-wrap">
                  <span>{user.lastActive || 'Không rõ'}</span>
                  {Boolean(user.lastActiveTimestamp && user.lastActiveTimestamp > 0) && (
                    <span className="text-[10px] text-cyan-400 font-mono">
                      ({getRelativeTimeString(user.lastActiveTimestamp)})
                    </span>
                  )}
                </div>
                <div className="text-[10px] text-purple-300 font-mono mt-1 truncate" title={user.lastAction}>
                  {user.lastAction || 'Đăng ký tài khoản'}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-[#0A0F1D] border border-slate-800">
                <div className="text-slate-400 text-[10px] mb-1">Thời điểm tham gia hệ thống:</div>
                <div className="text-white font-semibold text-xs">
                  {user.createdAt ? formatVietnamDateTime(user.createdAt) : 'Mới đây'}
                </div>
                <div className="text-[10px] text-slate-500 mt-1">
                  Đăng nhập: {user.lastLoginAt ? formatVietnamDateTime(user.lastLoginAt) : (user.lastActiveTimestamp ? getRelativeTimeString(user.lastActiveTimestamp) : 'Gần đây')}
                </div>
              </div>
            </div>
          </div>

          {/* KHỐI 3: THAO TÁC QUẢN TRỊ VIÊN ĐỐI VỚI TÀI KHOẢN NÀY */}
          <div className="rounded-2xl bg-[#111A2E]/80 border border-amber-500/30 p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="font-bold text-white text-xs uppercase tracking-wider flex items-center space-x-2 text-amber-400">
                <Crown className="w-4 h-4" />
                <span>Quyền Hạn &amp; Hành Động Cấp Phép Của Quản Trị Viên</span>
              </span>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
              <div>
                <div className="text-xs font-bold text-white">
                  Trạng thái VIP: {isVip ? <span className="text-amber-300 font-black">ĐÃ MỞ KHÓA TOÀN BỘ (VIP)</span> : <span className="text-slate-400 font-semibold">Tài khoản thường (Chưa nâng cấp)</span>}
                </div>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  VIP được sử dụng không giới hạn: Fix trễ 0s cực đoan, Debloat ROM nội địa, GMS Google Play, Khắc phục lỗi toàn cầu.
                </p>
              </div>

              <div className="flex items-center space-x-2">
                {!isSuperAdmin && (
                  <button
                    onClick={onToggleVip}
                    className={`px-3.5 py-1.5 rounded-xl font-bold text-xs transition-all flex items-center space-x-1.5 ${
                      isVip
                        ? 'bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 shadow-sm'
                        : 'bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold shadow-md shadow-emerald-500/25'
                    }`}
                  >
                    <Crown className="w-3.5 h-3.5" />
                    <span>{isVip ? 'Thu Hồi Quyền VIP' : 'Cấp Quyền VIP Ngay'}</span>
                  </button>
                )}

                {user.email && !isSuperAdmin && (
                  <button
                    onClick={onToggleAdmin}
                    className={`px-3.5 py-1.5 rounded-xl font-bold text-xs transition-all flex items-center space-x-1.5 ${
                      isCurrentAdmin
                        ? 'bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40'
                        : 'bg-purple-500 hover:bg-purple-400 text-white shadow-md shadow-purple-500/25'
                    }`}
                  >
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>{isCurrentAdmin ? 'Hạ Quyền Admin' : 'Bổ Nhiệm Quản Trị Viên'}</span>
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* KHỐI 4: LỊCH SỬ THAO TÁC TRỌNG YẾU ĐÃ GHI NHẬN */}
          <div className="rounded-2xl bg-[#111A2E]/80 border border-slate-800 p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="font-bold text-white text-xs uppercase tracking-wider flex items-center space-x-2">
                <Activity className="w-4 h-4 text-purple-400" />
                <span>Nhật Ký Hành Động Trọng Yếu Của Tài Khoản Này ({user.historyLogs?.length || 0} thao tác)</span>
              </span>
            </div>

            {(!user.historyLogs || user.historyLogs.length === 0) ? (
              <div className="py-6 text-center text-slate-500 italic text-xs bg-slate-900/40 rounded-xl">
                Chưa có thao tác can thiệp sâu nào được ghi nhận ngoài đăng nhập &amp; đồng bộ tài khoản.
              </div>
            ) : (
              <div className="space-y-2 font-mono text-xs">
                {(user.historyLogs || [])
                  .slice((historyPage - 1) * historyPageSize, historyPage * historyPageSize)
                  .map((log) => (
                  <div
                    key={log.id}
                    className="p-2.5 rounded-xl bg-[#0A0F1D] border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                  >
                    <div>
                      <div className="font-sans font-bold text-white text-xs">{log.action}</div>
                      {log.details && (
                        <div className="text-[11px] text-slate-400 font-sans mt-0.5">{log.details}</div>
                      )}
                    </div>
                    <div className="text-right shrink-0">
                      <div className="text-[10px] text-slate-400 font-mono flex items-center space-x-1 justify-end">
                        <span>{formatVietnamDateTime(log.createdAt || log.timestamp)}</span>
                        {(log.createdAt || log.timestamp) && (
                          <span className="text-slate-500 text-[9px]">({getRelativeTimeString(log.createdAt || log.timestamp)})</span>
                        )}
                      </div>
                      {log.deviceModel && (
                        <div className="text-[9px] text-cyan-400 font-bold">{log.deviceModel}</div>
                      )}
                    </div>
                  </div>
                ))}

                {/* Phân trang lịch sử hành động */}
                <Pagination
                  currentPage={historyPage}
                  totalItems={user.historyLogs?.length || 0}
                  pageSize={historyPageSize}
                  onPageChange={(page) => setHistoryPage(page)}
                  className="mt-2"
                />
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-[#0A0F1D] flex items-center justify-between">
          <div className="text-[11px] text-slate-400 font-mono">
            Dữ liệu đồng bộ trực tiếp từ Cloud Firestore Live Database
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition-all"
          >
            Đóng Cửa Sổ
          </button>
        </div>
      </div>
    </div>
  );
};
