'use client';

import React, { useState, useEffect, useRef } from 'react';
import { Share2, Check, Copy, Send, MessageCircle } from 'lucide-react';

interface QuickShareButtonProps {
  className?: string;
  compact?: boolean;
  fullWidth?: boolean;
}

export function QuickShareButton({
  className = '',
  compact = false,
  fullWidth = false
}: QuickShareButtonProps) {
  const [copied, setCopied] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [currentUrl, setCurrentUrl] = useState('https://magictune.web.app');
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      setCurrentUrl(window.location.origin);
    }
  }, []);

  useEffect(() => {
    if (!isOpen) return;
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen]);
  const shareData = {
    title: 'MagicTune - Bộ công cụ WebADB tối ưu Android & Đa Hệ Điều Hành',
    text: 'Sửa triệt để trễ thông báo Facebook, Gmail, Zalo, debloat và làm mượt điện thoại Android nội địa cực dễ dàng!',
    url: currentUrl,
  };

  const handleShare = async () => {
    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        await navigator.share(shareData);
        return;
      } catch (err) {
        // Người dùng hủy share hoặc browser không hỗ trợ
      }
    }
    setIsOpen(!isOpen);
  };

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(currentUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Không thể copy', err);
    }
  };

  const shareFacebook = () => {
    const url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(currentUrl)}`;
    window.open(url, '_blank', 'width=600,height=450');
  };

  const shareTelegram = () => {
    const url = `https://t.me/share/url?url=${encodeURIComponent(currentUrl)}&text=${encodeURIComponent(shareData.text)}`;
    window.open(url, '_blank', 'width=600,height=450');
  };

  const shareZalo = () => {
    const url = `https://zalo.me/share?url=${encodeURIComponent(currentUrl)}`;
    window.open(url, '_blank', 'width=600,height=450');
  };

  return (
    <div ref={containerRef} className={`relative ${fullWidth ? 'block w-full' : 'inline-block shrink-0'} ${className}`}>
      <button
        type="button"
        onClick={handleShare}
        className={`flex items-center justify-center gap-1.5 rounded-xl bg-[#111A2E] hover:bg-slate-800 text-slate-300 hover:text-white border border-cyan-500/20 font-bold transition-all active:scale-95 whitespace-nowrap shrink-0 ${
          fullWidth
            ? 'w-full py-2.5 px-3 text-xs'
            : compact
            ? 'min-w-9 h-9 px-2.5 text-[11px]'
            : 'h-9 px-3 text-xs'
        }`}
        title="Chia sẻ MagicTune tới bạn bè hoặc hội nhóm mạng xã hội"
        aria-label="Chia sẻ MagicTune"
      >
        <Share2 className="w-3.5 h-3.5 text-[#00F0FF] shrink-0" />
        <span className={compact ? 'hidden xl:inline' : fullWidth ? 'inline' : 'hidden sm:inline'}>Chia Sẻ</span>
      </button>

      {/* Dropdown Menu chia sẻ mạng xã hội */}
      {isOpen && (
        <div className="absolute right-0 mt-2 w-56 rounded-2xl bg-[#0D1629] border border-cyan-500/30 p-2.5 shadow-2xl z-50 text-slate-100 animate-in fade-in zoom-in-95 duration-150">
            <div className="px-2 py-1 mb-2 border-b border-slate-800">
              <p className="text-[11px] font-bold text-cyan-400">Chia sẻ MagicTune</p>
              <p className="text-[10px] text-slate-400">Giúp đỡ cộng đồng dùng Honor</p>
            </div>

            <div className="space-y-1">
              <button
                onClick={shareFacebook}
                className="w-full flex items-center space-x-2.5 px-2.5 py-1.5 rounded-lg hover:bg-blue-600/20 text-blue-400 hover:text-blue-300 text-xs transition-colors"
              >
                <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                </svg>
                <span>Chia sẻ Facebook</span>
              </button>

              <button
                onClick={shareTelegram}
                className="w-full flex items-center space-x-2.5 px-2.5 py-1.5 rounded-lg hover:bg-cyan-600/20 text-cyan-400 hover:text-cyan-300 text-xs transition-colors"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Gửi qua Telegram</span>
              </button>

              <button
                onClick={shareZalo}
                className="w-full flex items-center space-x-2.5 px-2.5 py-1.5 rounded-lg hover:bg-blue-500/20 text-sky-400 hover:text-sky-300 text-xs transition-colors"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>Gửi qua Zalo</span>
              </button>

              <button
                onClick={handleCopyLink}
                className="w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-xs font-medium transition-colors"
              >
                <span className="flex items-center space-x-2">
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
                  <span>{copied ? 'Đã sao chép link!' : 'Sao chép liên kết'}</span>
                </span>
                {copied && <span className="text-[10px] text-emerald-400 font-bold">Xong</span>}
              </button>
            </div>
          </div>
      )}
    </div>
  );
}
