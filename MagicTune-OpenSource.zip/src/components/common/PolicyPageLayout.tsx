'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { ArrowLeft, Moon, Sun, Zap, ShieldCheck, FileText, Info, Mail } from 'lucide-react';
import { APP_RELEASE_VERSION } from '@/lib/version';

interface PolicyPageLayoutProps {
  title: string;
  subtitle: string;
  activePath: '/about/' | '/privacy/' | '/terms/' | '/contact/';
  children: React.ReactNode;
}

const NAV_ITEMS = [
  { href: '/about/' as const, label: 'Giới Thiệu', icon: Info },
  { href: '/privacy/' as const, label: 'Bảo Mật', icon: ShieldCheck },
  { href: '/terms/' as const, label: 'Điều Khoản', icon: FileText },
  { href: '/contact/' as const, label: 'Liên Hệ', icon: Mail },
];

export function PolicyPageLayout({
  title,
  subtitle,
  activePath,
  children,
}: PolicyPageLayoutProps) {
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const saved = localStorage.getItem('magictune_theme') as 'dark' | 'light' | null;
    if (saved === 'light') {
      setTheme('light');
      document.documentElement.classList.add('light');
      document.body.classList.add('light');
    } else {
      setTheme('dark');
      document.documentElement.classList.remove('light');
      document.body.classList.remove('light');
    }
  }, []);

  const toggleTheme = () => {
    const next = theme === 'dark' ? 'light' : 'dark';
    setTheme(next);
    if (typeof window !== 'undefined') {
      localStorage.setItem('magictune_theme', next);
      if (next === 'light') {
        document.documentElement.classList.add('light');
        document.body.classList.add('light');
      } else {
        document.documentElement.classList.remove('light');
        document.body.classList.remove('light');
      }
    }
  };

  return (
    <div
      className={`min-h-screen flex flex-col transition-colors duration-200 ${
        theme === 'light'
          ? 'bg-[#F1F5F9] text-slate-900'
          : 'bg-[#0A0F1D] text-slate-100'
      }`}
    >
      <header
        className={`sticky top-0 z-40 border-b backdrop-blur-xl transition-colors ${
          theme === 'light'
            ? 'border-slate-200 bg-white/95 shadow-sm'
            : 'border-cyan-500/20 bg-[#0A0F1D]/95'
        }`}
      >
        <div className="max-w-5xl mx-auto px-3 sm:px-6 py-2.5 min-h-14 sm:min-h-16 flex flex-wrap sm:flex-nowrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 shrink-0">
            <Link
              href="/"
              className="flex items-center gap-2 hover:opacity-90 transition-opacity"
            >
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-[#00F0FF] to-[#8B5CF6] p-0.5 flex items-center justify-center shadow-md shadow-cyan-500/20 shrink-0">
                <div
                  className={`w-full h-full rounded-[9px] flex items-center justify-center ${
                    theme === 'light' ? 'bg-white border border-slate-200' : 'bg-[#0A0F1D]'
                  }`}
                >
                  <Zap className="w-4 h-4 text-[#00F0FF]" />
                </div>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-mono font-bold text-cyan-400">
                  magictune.web.app
                </span>
                <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-cyan-500/15 text-[#00F0FF] border border-cyan-500/30 font-mono font-bold">
                  {APP_RELEASE_VERSION}
                </span>
              </div>
            </Link>
          </div>

          <nav
            aria-label="Điều hướng chính sách"
            className="flex items-center gap-1.5 flex-wrap sm:flex-nowrap shrink-0"
          >
            <Link
              href="/"
              className="h-9 px-2.5 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 text-[#00F0FF] border border-cyan-500/30 text-[11px] font-bold inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
            >
              <ArrowLeft className="w-3.5 h-3.5 shrink-0" />
              <span>Công Cụ</span>
            </Link>

            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const isActive = activePath === item.href;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`h-9 px-2.5 rounded-xl border text-[11px] font-bold inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 transition-all ${
                    isActive
                      ? 'bg-gradient-to-r from-[#00F0FF] to-blue-600 text-black border-cyan-400'
                      : theme === 'light'
                      ? 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
                      : 'bg-[#111A2E] hover:bg-slate-800 text-slate-300 border-slate-700'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-black' : 'text-cyan-400'}`} />
                  <span className="hidden md:inline">{item.label}</span>
                </Link>
              );
            })}

            <button
              type="button"
              onClick={toggleTheme}
              className={`h-9 w-9 rounded-xl border inline-flex items-center justify-center shrink-0 transition-all ${
                theme === 'light'
                  ? 'bg-amber-100 text-amber-700 border-amber-300'
                  : 'bg-[#111A2E] text-amber-300 border-cyan-500/20'
              }`}
              title={theme === 'light' ? 'Chuyển sang nền Tối' : 'Chuyển sang nền Sáng'}
              aria-label={theme === 'light' ? 'Chuyển sang nền Tối' : 'Chuyển sang nền Sáng'}
            >
              {theme === 'light' ? (
                <Moon className="w-3.5 h-3.5 text-amber-600" />
              ) : (
                <Sun className="w-3.5 h-3.5 text-amber-400" />
              )}
            </button>
          </nav>
        </div>
      </header>

      <main className="flex-1 max-w-4xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        <div
          className={`rounded-3xl border p-6 sm:p-8 space-y-6 ${
            theme === 'light'
              ? 'bg-white border-slate-200 shadow-sm'
              : 'bg-[#111A2E]/90 border-cyan-500/20 shadow-xl'
          }`}
        >
          <div className="space-y-2 border-b border-cyan-500/15 pb-5">
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              {title}
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              {subtitle}
            </p>
          </div>

          <div className="space-y-6 text-sm leading-relaxed text-slate-300">
            {children}
          </div>
        </div>
      </main>

      <footer
        className={`border-t py-6 text-xs ${
          theme === 'light'
            ? 'border-slate-200 bg-white text-slate-600'
            : 'border-cyan-500/15 bg-[#070B16] text-slate-400'
        }`}
      >
        <div className="max-w-5xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="font-semibold">
            MagicTune ({APP_RELEASE_VERSION}) — https://magictune.web.app
          </div>
          <div className="flex flex-wrap items-center justify-center gap-4">
            <Link href="/" className="hover:text-[#00F0FF] transition-colors">
              Trang Chủ
            </Link>
            <Link href="/about/" className="hover:text-[#00F0FF] transition-colors">
              Giới Thiệu
            </Link>
            <Link href="/privacy/" className="hover:text-[#00F0FF] transition-colors">
              Chính Sách Bảo Mật
            </Link>
            <Link href="/terms/" className="hover:text-[#00F0FF] transition-colors">
              Điều Khoản
            </Link>
            <Link href="/contact/" className="hover:text-[#00F0FF] transition-colors">
              Liên Hệ
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
