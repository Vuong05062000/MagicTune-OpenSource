'use client';

import React, { useState, useEffect } from 'react';
import { Download, Smartphone, Check, X, Share2, HelpCircle } from 'lucide-react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export function InstallPwaButton() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [showIosGuide, setShowIosGuide] = useState(false);
  const [isIOS, setIsIOS] = useState(false);

  useEffect(() => {
    // Kiểm tra xem đã cài PWA chưa
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsInstalled(true);
    }

    // Nhận biết hệ điều hành iOS (Safari không hỗ trợ beforeinstallprompt)
    const userAgent = window.navigator.userAgent.toLowerCase();
    const isAppleDevice = /iphone|ipad|ipod/.test(userAgent);
    setIsIOS(isAppleDevice);

    const handleBeforeInstall = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);

    window.addEventListener('appinstalled', () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    });

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
    };
  }, []);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      await deferredPrompt.prompt();
      const choiceResult = await deferredPrompt.userChoice;
      if (choiceResult.outcome === 'accepted') {
        setIsInstalled(true);
      }
      setDeferredPrompt(null);
    } else if (isIOS) {
      setShowIosGuide(true);
    } else {
      // Trường hợp trình duyệt Chrome máy tính hoặc Chrome Android không phát event prompt ngay
      setShowIosGuide(true);
    }
  };

  if (isInstalled) {
    return (
      <div className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold">
        <Check className="w-3.5 h-3.5" />
        <span className="hidden sm:inline">Đã Cài Vào Màn Hình</span>
      </div>
    );
  }

  return (
    <>
      <button
        onClick={handleInstallClick}
        className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-cyan-500/20 to-blue-500/20 hover:from-cyan-500/30 hover:to-blue-500/30 text-cyan-300 border border-cyan-500/40 text-xs font-bold transition-all shadow-sm shadow-cyan-500/10 hover:scale-[1.02] active:scale-[0.98]"
        title="Thêm MagicTune vào màn hình chính điện thoại hoặc máy tính"
      >
        <Download className="w-3.5 h-3.5 text-[#00F0FF] animate-bounce shrink-0" />
        <span className="hidden sm:inline">Cài App</span>
      </button>

      {/* Modal Hướng dẫn cài đặt thủ công nếu trình duyệt không tự nảy popup */}
      {showIosGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-md rounded-2xl bg-[#0D1629] border border-cyan-500/30 p-6 shadow-2xl relative text-slate-100">
            <button
              onClick={() => setShowIosGuide(false)}
              className="absolute top-4 right-4 p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center">
                <Smartphone className="w-5 h-5 text-[#00F0FF]" />
              </div>
              <div>
                <h3 className="font-bold text-base text-white">Cài MagicTune vào màn hình chính</h3>
                <p className="text-xs text-slate-400">Dùng như một ứng dụng độc lập không cần mở trình duyệt</p>
              </div>
            </div>

            <div className="space-y-3 text-xs bg-[#0A0F1D] p-4 rounded-xl border border-slate-800">
              <div className="flex items-start space-x-2.5">
                <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-[#00F0FF] font-bold flex items-center justify-center shrink-0 text-[11px]">1</span>
                <p className="text-slate-300">
                  <span className="font-bold text-white">Trên điện thoại Android (Chrome/Honor Browser):</span> Bấm vào dấu <strong>3 chấm (⋮)</strong> ở góc trên bên phải màn hình, chọn <strong>&quot;Cài đặt ứng dụng&quot;</strong> hoặc <strong>&quot;Thêm vào Màn hình chính&quot;</strong>.
                </p>
              </div>

              <div className="flex items-start space-x-2.5">
                <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-[#00F0FF] font-bold flex items-center justify-center shrink-0 text-[11px]">2</span>
                <p className="text-slate-300">
                  <span className="font-bold text-white">Trên iPhone / iPad (Safari):</span> Bấm nút <strong>Chia sẻ (biểu tượng mũi tên hướng lên)</strong>, sau đó cuộn xuống chọn <strong>&quot;Thêm vào MH chính (Add to Home Screen)&quot;</strong>.
                </p>
              </div>

              <div className="flex items-start space-x-2.5">
                <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-[#00F0FF] font-bold flex items-center justify-center shrink-0 text-[11px]">3</span>
                <p className="text-slate-300">
                  <span className="font-bold text-white">Trên máy tính (Chrome/Edge/Cốc Cốc):</span> Bấm vào biểu tượng <strong>Cài đặt</strong> hình máy tính có mũi tên tải xuống ở thanh nhập địa chỉ URL.
                </p>
              </div>
            </div>

            <button
              onClick={() => setShowIosGuide(false)}
              className="w-full mt-5 py-2.5 rounded-xl bg-cyan-500 text-black font-extrabold text-xs shadow-lg shadow-cyan-500/25 hover:bg-cyan-400 transition-all"
            >
              Tôi Đã Hiểu
            </button>
          </div>
        </div>
      )}
    </>
  );
}
