'use client';

import React, { useEffect, useState } from 'react';
import { Zap, ShieldCheck, Cpu } from 'lucide-react';

interface SplashScreenProps {
  onComplete: () => void;
  appName?: string;
  appSlogan?: string;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({
  onComplete,
  appName = 'MagicTune',
  appSlogan = 'Bộ công cụ WebADB tối ưu hóa & Fix lỗi đa hệ điều hành Android.'
}) => {
  const [progress, setProgress] = useState(0);
  const [phaseText, setPhaseText] = useState('Đang khởi động hệ thống WebADB...');

  // Chuẩn hóa tên ứng dụng & slogan: Triệt để loại bỏ tàn dư chữ "MagicOS" từ bộ nhớ đệm cũ của người dùng
  const displayAppName = (appName || 'MagicTune')
    .replace(/MagicOS/gi, 'Android')
    .replace(/Honor Tool Hub/gi, 'MagicTune');
  const displayAppSlogan = (appSlogan || 'Bộ công cụ WebADB tối ưu hóa & Fix lỗi đa hệ điều hành Android.')
    .replace(/Honor & MagicOS/gi, 'Mọi Thiết Bị Android')
    .replace(/cho MagicOS/gi, 'cho Android Đa Hãng')
    .replace(/MagicOS/gi, 'Android');

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          setTimeout(onComplete, 400);
          return 100;
        }
        const next = prev + 15;
        if (next > 30 && next < 60) setPhaseText('Đang nạp bộ điều khiển WebUSB & Shizuku Bridge...');
        if (next >= 60 && next < 90) setPhaseText('Đang nạp tập lệnh tối ưu đa hệ điều hành Android...');
        if (next >= 90) setPhaseText('Sẵn sàng kết nối thiết bị!');
        return next;
      });
    }, 180);

    return () => clearInterval(timer);
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-50 bg-[#0A0F1D] flex flex-col items-center justify-center p-6 select-none overflow-hidden">
      {/* Background Glow */}
      <div className="absolute w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute w-80 h-80 bg-purple-500/10 rounded-full blur-3xl pointer-events-none -bottom-10" />

      {/* Center Branding */}
      <div className="relative flex flex-col items-center text-center max-w-sm">
        <div className="relative mb-6">
          <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-[#00F0FF] via-[#8B5CF6] to-blue-600 p-0.5 shadow-2xl shadow-cyan-500/30 animate-pulse">
            <div className="w-full h-full bg-[#0A0F1D] rounded-[22px] overflow-hidden flex items-center justify-center">
              <img src="/icon.png" alt="MagicTune Logo" className="w-full h-full object-cover" />
            </div>
          </div>
          <div className="absolute -bottom-2 -right-2 p-1.5 rounded-xl bg-[#111A2E] border border-cyan-500/30 text-[#00F0FF] shadow-lg">
            <ShieldCheck className="w-4 h-4" />
          </div>
        </div>

        <h1 className="text-3xl font-black text-white tracking-wider mb-2">
          {displayAppName}
        </h1>
        <p className="text-xs text-slate-400 font-medium leading-relaxed mb-8">
          {displayAppSlogan}
        </p>

        {/* Progress Bar */}
        <div className="w-full bg-[#111A2E] h-2 rounded-full overflow-hidden border border-cyan-500/20 mb-3">
          <div
            className="h-full bg-gradient-to-r from-[#00F0FF] to-[#8B5CF6] transition-all duration-200"
            style={{ width: `${progress}%` }}
          />
        </div>

        {/* Phase Text */}
        <div className="flex items-center justify-between w-full text-[11px] text-slate-500 font-mono">
          <span className="truncate">{phaseText}</span>
          <span className="text-[#00F0FF] font-bold ml-2">{progress}%</span>
        </div>
      </div>

      {/* Watermark / Commercial Ready */}
      <div className="absolute bottom-6 text-center text-[10px] text-slate-600 font-mono flex items-center space-x-2">
        <Cpu className="w-3.5 h-3.5 text-cyan-500" />
        <span>Universal Android WebADB Engine v3.0 Pro • Multi-Brand &amp; Shizuku Ready</span>
      </div>
    </div>
  );
};
