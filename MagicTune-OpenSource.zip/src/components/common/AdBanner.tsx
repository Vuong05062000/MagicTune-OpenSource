'use client';

import React, { useEffect, useRef } from 'react';

const LEGACY_PLACEHOLDER_SLOTS = new Set(['9798404511', '9798404512']);

interface AdBannerProps {
  client?: string;
  slot?: string;
  format?: 'auto' | 'fluid' | 'rectangle' | 'horizontal';
  className?: string;
}

export const AdBanner: React.FC<AdBannerProps> = ({
  client = 'ca-pub-4256214784202059',
  slot,
  format = 'auto',
  className = ''
}) => {
  const insRef = useRef<HTMLModElement>(null);
  const trimmedSlot = slot?.trim() || '';
  const hasRealSlot = Boolean(trimmedSlot && !LEGACY_PLACEHOLDER_SLOTS.has(trimmedSlot));

  useEffect(() => {
    // Chỉ khởi tạo khi có mã đơn vị quảng cáo hợp lệ và phần tử đang hiển thị trong DOM
    if (!hasRealSlot || typeof window === 'undefined') return;

    const timer = setTimeout(() => {
      const el = insRef.current;
      if (!el || !el.isConnected || el.offsetWidth === 0 || el.getAttribute('data-adsbygoogle-status')) return;
      try {
        const adsbygoogle = (window as any).adsbygoogle || [];
        adsbygoogle.push({});
        (window as any).adsbygoogle = adsbygoogle;
      } catch (err) {
        console.debug('AdSense placement initialized:', err);
      }
    }, 200);

    return () => clearTimeout(timer);
  }, [hasRealSlot]);

  // Khi chưa cấu hình Slot ID thật (dùng Auto Ads trong <head>), không hiển thị khung trống để tránh lỗi HTTP 400 và giữ bố cục sạch sẽ
  if (!hasRealSlot) {
    return null;
  }

  return (
    <div
      className={`relative overflow-hidden rounded-2xl border border-[var(--border-color)] bg-[var(--bg-card)] transition-colors duration-200 p-3.5 text-center my-4 ${className}`}
    >
      <div className="flex items-center justify-between text-[10px] text-[var(--text-muted)] mb-2 font-mono uppercase tracking-wider">
        <span className="font-semibold text-[var(--text-muted)]">Tài trợ • Quảng cáo liên kết</span>
        <span className="font-bold text-[var(--text-primary)]">Google AdSense</span>
      </div>

      <div className="min-h-[100px] flex items-center justify-center w-full max-w-full overflow-hidden rounded-xl bg-[var(--bg-primary)] border border-[var(--border-color)] p-2">
        <ins
          ref={insRef}
          className="adsbygoogle max-w-full"
          style={{ display: 'block', width: '100%', minHeight: '90px' }}
          data-ad-client={client || 'ca-pub-4256214784202059'}
          data-ad-slot={trimmedSlot}
          data-ad-format={format}
          data-full-width-responsive="true"
        />
      </div>

      <div className="text-[10px] text-[var(--text-muted)] mt-2 font-medium italic">
        Quảng cáo giúp duy trì máy chủ &amp; phát triển các bản vá tối ưu Android phi lợi nhuận
      </div>
    </div>
  );
};
