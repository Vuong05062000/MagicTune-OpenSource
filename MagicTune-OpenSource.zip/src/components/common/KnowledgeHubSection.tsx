import React from 'react';
import {
  BookOpen,
  HelpCircle,
  ShieldCheck,
  Zap,
  Smartphone,
  Cpu,
  Layers,
  CheckCircle2,
  BellRing,
  Globe,
  Settings,
  ChevronDown
} from 'lucide-react';

export const KnowledgeHubSection: React.FC = () => {
  return (
    <section className="mt-12 space-y-8 border-t border-cyan-500/15 pt-8 text-left">
      {/* Tiêu đề & Giới thiệu Chuyên môn */}
      <div className="space-y-3">
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/25 text-[#00F0FF] text-xs font-bold">
          <BookOpen className="w-3.5 h-3.5" />
          <span>Cẩm Nang Kỹ Thuật &amp; Kiến Thức Chuyên Sâu</span>
        </div>
        <h2 className="text-xl sm:text-2xl font-black text-white tracking-wide">
          Hướng Dẫn Tối Ưu Hóa &amp; Khắc Phục Triệt Để Trễ Thông Báo Android Toàn Diện
        </h2>
        <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-4xl">
          Tìm hiểu nguyên lý vận hành của bộ quản lý pin Android Doze Mode, cơ chế bảo vệ pin độc quyền của các dòng máy xách tay nội địa Trung Quốc (MagicOS, HyperOS, OriginOS, ColorOS), và phương pháp giải quyết dứt điểm tình trạng chậm thông báo 0 giây thông qua WebADB chuẩn Google.
        </p>
      </div>

      {/* Grid 3 Khối Nội Dung Chuyên Môn Giá Trị Cao */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Khối 1: Nguyên nhân trễ thông báo */}
        <article className="rounded-2xl bg-[#0F172A]/90 border border-cyan-500/20 p-5 space-y-3.5 hover:border-cyan-500/40 transition-colors">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-[#00F0FF]">
            <BellRing className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-bold text-white">
            1. Tại Sao Điện Thoại Android Thường Xuyên Trễ Thông Báo?
          </h3>
          <div className="text-xs text-slate-300 space-y-2 leading-relaxed">
            <p>
              Từ phiên bản Android 6.0 Marshmallow, Google tích hợp cơ chế <strong>Doze Mode</strong> và <strong>App Standby Buckets</strong> nhằm kéo dài thời lượng pin bằng cách đưa CPU và kết nối mạng của ứng dụng vào trạng thái ngủ đông khi tắt màn hình.
            </p>
            <p>
              Đối với các dòng máy xách tay nội địa (China ROM) như Honor, Xiaomi, Vivo, Oppo, nhà sản xuất còn cài đặt thêm các daemon tối ưu pin tích cực (như <em>PowerGenie, Bastet, Joyose</em>). Các daemon này tự động ngắt kết nối socket ngầm của Facebook, Zalo, Telegram và chặn Google FCM (Firebase Cloud Messaging) khi màn hình tắt quá 5 phút.
            </p>
          </div>
        </article>

        {/* Khối 2: Công nghệ bẻ khóa 0 giây */}
        <article className="rounded-2xl bg-[#0F172A]/90 border border-cyan-500/20 p-5 space-y-3.5 hover:border-cyan-500/40 transition-colors">
          <div className="w-10 h-10 rounded-xl bg-purple-500/15 border border-purple-500/30 flex items-center justify-center text-purple-300">
            <Zap className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-bold text-white">
            2. Cơ Chế Bẻ Khóa Báo Động 0s Của MagicTune
          </h3>
          <div className="text-xs text-slate-300 space-y-2 leading-relaxed">
            <p>
              MagicTune can thiệp trực tiếp qua chuẩn giao tiếp ADB (Android Debug Bridge) chính thức mà không yêu cầu can thiệp Root máy:
            </p>
            <ul className="list-disc list-inside space-y-1 text-slate-400">
              <li><strong className="text-slate-200">DeviceIdle Whitelist:</strong> Đưa các app nhắn tin và ngân hàng vào danh sách miễn trừ Doze Mode.</li>
              <li><strong className="text-slate-200">Standby Bucket ACTIVE:</strong> Khóa mức độ ưu tiên tiến trình ở cấp cao nhất vĩnh viễn.</li>
              <li><strong className="text-slate-200">Cấp quyền POST_NOTIFICATIONS:</strong> Mở khóa thông báo chuẩn xác từ Android 13 đến Android 17.</li>
              <li><strong className="text-slate-200">Khóa Giữ Mạng 24/7:</strong> Duy trì socket FCM đón biến động số dư và tin nhắn tức thời.</li>
            </ul>
          </div>
        </article>

        {/* Khối 3: Cầu nối Shizuku & An toàn dữ liệu */}
        <article className="rounded-2xl bg-[#0F172A]/90 border border-cyan-500/20 p-5 space-y-3.5 hover:border-cyan-500/40 transition-colors">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-300">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-bold text-white">
            3. Tiêu Chuẩn Bảo Mật &amp; Không Mất Dữ Liệu
          </h3>
          <div className="text-xs text-slate-300 space-y-2 leading-relaxed">
            <p>
              Toàn bộ thao tác chạy trực tiếp giữa trình duyệt web và thiết bị của bạn thông qua WebUSB API chuẩn mở của Google Chrome/Edge.
            </p>
            <p>
              Hệ thống không thu thập bất kỳ dữ liệu cá nhân, tin nhắn, ảnh chụp hay mật khẩu nào của người dùng. Các lệnh gửi đi là những chỉ thị hệ thống hợp chuẩn của Android Open Source Project (AOSP), hoàn toàn giữ nguyên dữ liệu điện thoại và đảm bảo điều kiện bảo hành thiết bị.
            </p>
          </div>
        </article>
      </div>

      {/* Mục Hỏi & Đáp Thường Gặp (FAQ - Chuẩn Cấu Trúc Schema Google) */}
      <div className="rounded-2xl bg-[#0B1120] border border-cyan-500/20 p-6 space-y-4">
        <div className="flex items-center space-x-2 text-white font-bold text-base">
          <HelpCircle className="w-5 h-5 text-[#00F0FF]" />
          <h3>Câu Hỏi Thường Gặp Khi Tối Ưu Thiết Bị (FAQ)</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-300">
          <div className="p-4 rounded-xl bg-[#0F172A] border border-slate-800 space-y-1.5">
            <h4 className="font-bold text-cyan-300">
              Q: Dùng công cụ này điện thoại của tôi có bị mất dữ liệu không?
            </h4>
            <p className="text-slate-400 leading-relaxed">
              Không. Các lệnh tối ưu chỉ cấu hình lại cờ quản lý tiến trình và phân bổ tài nguyên pin trong hệ điều hành Android, không xóa hoặc can thiệp vào kho dữ liệu cá nhân của người dùng.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-[#0F172A] border border-slate-800 space-y-1.5">
            <h4 className="font-bold text-cyan-300">
              Q: Sau khi chạy tối ưu có cần khởi động lại máy không?
            </h4>
            <p className="text-slate-400 leading-relaxed">
              Có. Khởi động lại (Reboot) điện thoại giúp hệ thống nạp lại danh sách Standby Buckets mới và áp dụng cờ cấu hình mạng một cách trơn tru, đồng bộ nhất.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-[#0F172A] border border-slate-800 space-y-1.5">
            <h4 className="font-bold text-cyan-300">
              Q: Thiết bị cập nhật OTA lên phiên bản Android mới có bị mất thiết lập không?
            </h4>
            <p className="text-slate-400 leading-relaxed">
              Hầu hết các giá trị cấu hình hệ thống (Settings Global/Secure) được giữ nguyên sau khi cập nhật OTA thông thường. Nếu nâng cấp lên phiên bản Android lớn (Major OS Upgrade), bạn chỉ cần kết nối lại cáp và nhấn 1-chạm để thiết lập lại trong vòng 30 giây.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-[#0F172A] border border-slate-800 space-y-1.5">
            <h4 className="font-bold text-cyan-300">
              Q: Tôi có cần cắm cáp máy tính mỗi lần dùng không?
            </h4>
            <p className="text-slate-400 leading-relaxed">
              Sau khi cắm cáp kích hoạt Shizuku lần đầu, bạn có thể ngắt cáp và tiếp tục sử dụng các quyền hạn cấp cao trực tiếp trên điện thoại qua Wi-Fi nội bộ mà không cần phụ thuộc máy tính.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
