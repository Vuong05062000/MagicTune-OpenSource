'use client';

import React, { useState, useEffect } from 'react';
import {
  X,
  Mail,
  Lock,
  Phone,
  KeyRound,
  CheckCircle2,
  AlertCircle,
  QrCode,
  Smartphone,
  RefreshCw
} from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import {
  auth,
  googleProvider,
  facebookProvider,
  recordUserActivity,
  createQrLoginSession,
  listenQrLoginSession
} from '@/lib/firebase/config';
import {
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  RecaptchaVerifier,
  signInWithPhoneNumber,
  ConfirmationResult
} from 'firebase/auth';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccessfulLogin?: (user: any) => void;
  isMobileDevice?: boolean;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onSuccessfulLogin,
  isMobileDevice
}) => {
  const isMobile = isMobileDevice ?? (typeof window !== 'undefined' ? window.innerWidth < 768 : false);
  const [tab, setTab] = useState<'login' | 'register' | 'phone' | 'qr'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('+84');
  const [verificationCode, setVerificationCode] = useState('');
  const [confirmationResult, setConfirmationResult] = useState<ConfirmationResult | null>(null);

  // QR Auth state
  const [qrUrl, setQrUrl] = useState<string>('');
  const [qrSessionId, setQrSessionId] = useState<string>('');
  const [isQrLoading, setIsQrLoading] = useState(false);
  const [qrStatusText, setQrStatusText] = useState('Đang tạo mã QR bảo mật...');

  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Khởi tạo mã QR khi chuyển sang tab 'qr'
  const generateNewQr = async () => {
    setIsQrLoading(true);
    setErrorMsg(null);
    setQrStatusText('Đang tạo phiên đăng nhập QR...');
    try {
      const { sessionId, qrUrl } = await createQrLoginSession();
      setQrSessionId(sessionId);
      setQrUrl(qrUrl);
      setQrStatusText('Mở camera hoặc trình quét mã trên điện thoại đã đăng nhập');
    } catch (e: any) {
      setErrorMsg('Không thể tạo mã QR đăng nhập. Kiểm tra kết nối mạng.');
    } finally {
      setIsQrLoading(false);
    }
  };

  useEffect(() => {
    if (isMobile && tab === 'qr') {
      setTab('login');
    }
  }, [isMobile, tab]);

  useEffect(() => {
    if (isOpen && tab === 'qr' && !isMobile) {
      generateNewQr();
    }
  }, [isOpen, tab, isMobile]);

  // Lắng nghe duyệt QR từ điện thoại
  useEffect(() => {
    if (!qrSessionId || tab !== 'qr') return;

    const unsubscribe = listenQrLoginSession(
      qrSessionId,
      (userData) => {
        setSuccessMsg(`Quét QR thành công! Chào mừng ${userData.displayName || userData.email || 'bạn'}.`);
        recordUserActivity('Đăng nhập nhanh qua QR Code trên PC', `Email: ${userData.email}`);
        if (onSuccessfulLogin) onSuccessfulLogin(userData);
        setTimeout(onClose, 1200);
      },
      () => {
        setQrStatusText('Mã QR đã hết hạn. Vui lòng bấm làm mới mã.');
      }
    );

    return () => unsubscribe();
  }, [qrSessionId, tab, onClose, onSuccessfulLogin]);

  useEffect(() => {
    if (!isOpen) {
      setErrorMsg(null);
      setSuccessMsg(null);
      setConfirmationResult(null);
      setVerificationCode('');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  // 1. Google Gmail
  const handleGoogleSignIn = async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      const res = await signInWithPopup(auth, googleProvider);
      recordUserActivity('Đăng nhập qua Google', `Email: ${res.user.email}`);
      setSuccessMsg(`Chào mừng ${res.user.displayName || res.user.email}!`);
      if (onSuccessfulLogin) onSuccessfulLogin(res.user);
      setTimeout(onClose, 1200);
    } catch (err: any) {
      setErrorMsg(err.message || 'Không thể đăng nhập bằng Google.');
    } finally {
      setLoading(false);
    }
  };

  // 2. Facebook
  const handleFacebookSignIn = async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      const res = await signInWithPopup(auth, facebookProvider);
      recordUserActivity('Đăng nhập qua Facebook', `User: ${res.user.displayName}`);
      setSuccessMsg(`Chào mừng ${res.user.displayName || 'bạn'}!`);
      if (onSuccessfulLogin) onSuccessfulLogin(res.user);
      setTimeout(onClose, 1200);
    } catch (err: any) {
      setErrorMsg(err.message || 'Không thể đăng nhập bằng Facebook.');
    } finally {
      setLoading(false);
    }
  };

  // 3. Email
  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg(null);

    try {
      if (tab === 'register') {
        if (password !== confirmPassword) {
          setErrorMsg('Mật khẩu xác nhận không trùng khớp.');
          setLoading(false);
          return;
        }
        const res = await createUserWithEmailAndPassword(auth, email.trim(), password);
        recordUserActivity('Đăng ký tài khoản Email', `Email: ${res.user.email}`);
        setSuccessMsg('Đăng ký thành công!');
        if (onSuccessfulLogin) onSuccessfulLogin(res.user);
      } else {
        const res = await signInWithEmailAndPassword(auth, email.trim(), password);
        recordUserActivity('Đăng nhập qua Email', `Email: ${res.user.email}`);
        setSuccessMsg('Đăng nhập thành công!');
        if (onSuccessfulLogin) onSuccessfulLogin(res.user);
      }
      setTimeout(onClose, 1200);
    } catch (err: any) {
      setErrorMsg(err.message || 'Thao tác thất bại. Vui lòng kiểm tra lại thông tin.');
    } finally {
      setLoading(false);
    }
  };

  // 4. SMS OTP
  const handleSendPhoneOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg(null);

    try {
      if (!(window as any).recaptchaVerifier) {
        (window as any).recaptchaVerifier = new RecaptchaVerifier(
          auth,
          'recaptcha-container',
          { size: 'invisible' }
        );
      }
      const appVerifier = (window as any).recaptchaVerifier;
      const formattedPhone = phoneNumber.startsWith('0')
        ? '+84' + phoneNumber.slice(1)
        : phoneNumber;

      const confirmation = await signInWithPhoneNumber(auth, formattedPhone, appVerifier);
      setConfirmationResult(confirmation);
      setSuccessMsg(`Đã gửi mã xác nhận 6 số đến ${formattedPhone}!`);
    } catch (err: any) {
      setErrorMsg(err.message || 'Không thể gửi SMS OTP. Vui lòng kiểm tra số điện thoại.');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!confirmationResult) return;
    setLoading(true);
    setErrorMsg(null);

    try {
      const res = await confirmationResult.confirm(verificationCode.trim());
      recordUserActivity('Đăng nhập qua SMS OTP', `SĐT: ${res.user.phoneNumber}`);
      setSuccessMsg('Xác minh số điện thoại thành công!');
      if (onSuccessfulLogin) onSuccessfulLogin(res.user);
      setTimeout(onClose, 1200);
    } catch (err: any) {
      setErrorMsg('Mã OTP không đúng hoặc đã hết hạn.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div 
      className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md"
      onClick={onClose}
    >
      <div id="recaptcha-container" />
      <div 
        className="relative w-full max-w-md rounded-2xl border border-cyan-500/30 bg-[#111A2E] p-6 shadow-2xl shadow-cyan-950/40"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute right-4 top-4 p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-all text-xs"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="text-center mb-4">
          <h3 className="text-lg font-bold text-white tracking-wide">
            {tab === 'qr'
              ? 'Đăng Nhập Nhanh Bằng Mã QR'
              : tab === 'phone'
              ? 'Đăng Nhập Qua SMS OTP'
              : tab === 'register'
              ? 'Tạo Tài Khoản Mới'
              : 'Đăng Nhập Thành Viên'}
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            Không bắt buộc đăng nhập để sử dụng các tính năng tối ưu thiết bị Android
          </p>
        </div>

        {errorMsg && (
          <div className="mb-3 p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center space-x-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span className="break-all">{errorMsg}</span>
          </div>
        )}
        {successMsg && (
          <div className="mb-3 p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center space-x-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Tab chuyển đổi: Email | Đăng Ký | SMS OTP | Quét QR (chỉ hiện trên PC) */}
        <div className={`grid ${isMobile ? 'grid-cols-3' : 'grid-cols-4'} rounded-xl bg-[#0A0F1D] p-1 border border-cyan-500/10 mb-4 text-xs font-semibold`}>
          <button
            type="button"
            onClick={() => setTab('login')}
            className={`py-1.5 rounded-lg transition-all ${
              tab === 'login' ? 'bg-[#00F0FF] text-black font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            Email
          </button>
          <button
            type="button"
            onClick={() => setTab('register')}
            className={`py-1.5 rounded-lg transition-all ${
              tab === 'register' ? 'bg-[#00F0FF] text-black font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            Đăng Ký
          </button>
          <button
            type="button"
            onClick={() => setTab('phone')}
            className={`py-1.5 rounded-lg transition-all ${
              tab === 'phone' ? 'bg-[#00F0FF] text-black font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            SMS OTP
          </button>
          {!isMobile && (
            <button
              type="button"
              onClick={() => setTab('qr')}
              className={`py-1.5 rounded-lg transition-all flex items-center justify-center space-x-1 ${
                tab === 'qr' ? 'bg-[#00F0FF] text-black font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              <QrCode className="w-3.5 h-3.5" />
              <span>Mã QR</span>
            </button>
          )}
        </div>

        {/* 1. TAB QUÉT QR CODE (ĐĂNG NHẬP NHANH TRÊN PC BẰNG ĐIỆN THOẠI) */}
        {tab === 'qr' && (
          <div className="flex flex-col items-center justify-center py-2 space-y-4">
            <div className="p-3 rounded-2xl bg-white shadow-2xl shadow-cyan-500/20 border-2 border-[#00F0FF]">
              {qrUrl ? (
                <QRCodeSVG value={qrUrl} size={180} level="M" />
              ) : (
                <div className="w-[180px] h-[180px] flex items-center justify-center">
                  <div className="w-8 h-8 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin" />
                </div>
              )}
            </div>

            <div className="text-center space-y-1">
              <div className="text-xs font-bold text-white flex items-center justify-center space-x-1.5">
                <Smartphone className="w-4 h-4 text-[#00F0FF]" />
                <span>Quét mã bằng điện thoại đã đăng nhập</span>
              </div>
              <p className="text-[11px] text-slate-400 max-w-xs">{qrStatusText}</p>
            </div>

            <button
              onClick={generateNewQr}
              disabled={isQrLoading}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center space-x-1 transition-all"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isQrLoading ? 'animate-spin text-[#00F0FF]' : ''}`} />
              <span>Làm mới mã QR</span>
            </button>
          </div>
        )}

        {/* 2. TAB EMAIL ĐĂNG NHẬP / ĐĂNG KÝ */}
        {(tab === 'login' || tab === 'register') && (
          <div>
            {/* Google & Facebook Fast Auth Buttons */}
            <div className="grid grid-cols-2 gap-2.5 mb-4">
              <button
                type="button"
                onClick={handleGoogleSignIn}
                disabled={loading}
                className="flex items-center justify-center space-x-1.5 py-2 px-3 rounded-xl bg-[#0A0F1D] border border-cyan-500/20 hover:border-cyan-400 text-xs text-white font-medium transition-all"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span>Gmail Google</span>
              </button>

              <button
                type="button"
                onClick={handleFacebookSignIn}
                disabled={loading}
                className="flex items-center justify-center space-x-1.5 py-2 px-3 rounded-xl bg-[#1877F2]/10 border border-[#1877F2]/30 hover:border-[#1877F2] text-xs text-white font-medium transition-all"
              >
                <svg className="w-4 h-4 fill-[#1877F2]" viewBox="0 0 24 24">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                </svg>
                <span>Facebook</span>
              </button>
            </div>

            <form onSubmit={handleEmailAuth} className="space-y-3">
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Địa chỉ Email:</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="email@gmail.com"
                    className="w-full bg-[#0A0F1D] border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Mật khẩu:</label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Ít nhất 6 ký tự"
                    className="w-full bg-[#0A0F1D] border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                    required
                  />
                </div>
              </div>

              {tab === 'register' && (
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">Nhập lại mật khẩu:</label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="Xác nhận mật khẩu"
                      className="w-full bg-[#0A0F1D] border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                      required
                    />
                  </div>
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full mt-2 py-2.5 rounded-xl bg-gradient-to-r from-[#00F0FF] to-blue-600 hover:from-cyan-400 text-black font-extrabold text-xs transition-all shadow-md shadow-cyan-500/20"
              >
                {loading ? 'Đang xử lý...' : tab === 'register' ? 'Tạo Tài Khoản' : 'Đăng Nhập'}
              </button>
            </form>
          </div>
        )}

        {/* 3. TAB SMS OTP SỐ ĐIỆN THOẠI */}
        {tab === 'phone' && (
          <div>
            {!confirmationResult ? (
              <form onSubmit={handleSendPhoneOtp} className="space-y-3.5">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">Số điện thoại nhận OTP:</label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="tel"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      placeholder="+84 393 368 007"
                      className="w-full bg-[#0A0F1D] border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-cyan-400"
                      required
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 text-white font-bold text-xs transition-all shadow-md shadow-purple-900/30"
                >
                  {loading ? 'Đang gửi mã...' : 'Gửi Mã SMS OTP'}
                </button>
              </form>
            ) : (
              <form onSubmit={handleVerifyOtp} className="space-y-3.5">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">Nhập mã 6 chữ số gửi về điện thoại:</label>
                  <div className="relative">
                    <KeyRound className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={verificationCode}
                      onChange={(e) => setVerificationCode(e.target.value)}
                      placeholder="123456"
                      maxLength={6}
                      className="w-full bg-[#0A0F1D] border border-cyan-500/30 rounded-xl pl-9 pr-3 py-2 text-xs text-white font-mono tracking-widest text-center focus:outline-none focus:border-cyan-400"
                      required
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#00F0FF] to-blue-600 hover:from-cyan-400 text-black font-extrabold text-xs transition-all shadow-md shadow-cyan-500/20"
                >
                  {loading ? 'Đang xác minh...' : 'Xác Nhận & Đăng Nhập'}
                </button>

                <button
                  type="button"
                  onClick={() => setConfirmationResult(null)}
                  className="w-full text-center text-xs text-slate-400 hover:text-white"
                >
                  Gửi lại số khác
                </button>
              </form>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
