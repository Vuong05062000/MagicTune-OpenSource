import { initializeApp, getApps, getApp } from "firebase/app";
import {
  getAuth,
  GoogleAuthProvider,
  FacebookAuthProvider
} from "firebase/auth";
import {
  getFirestore,
  collection,
  getDocs,
  query,
  orderBy,
  limit,
  doc,
  setDoc,
  getDoc,
  onSnapshot,
  writeBatch,
  where,
  deleteDoc
} from "firebase/firestore";
import { getStorage } from "firebase/storage";

// Cấu hình Firebase chính thức từ người dùng
export const firebaseConfig = {
  apiKey: "AIzaSyBQd5lzdb-ttasM224anMpTAjfjqsROkA0",
  authDomain: "phn-mm-ha-n.firebaseapp.com",
  projectId: "phn-mm-ha-n",
  storageBucket: "phn-mm-ha-n.firebasestorage.app",
  messagingSenderId: "979840451154",
  appId: "1:979840451154:web:c9c1bddeeac47ab001558b"
};

export const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);

export const googleProvider = new GoogleAuthProvider();
export const facebookProvider = new FacebookAuthProvider();

// Khóa Web Push Certificate (VAPID Key) do người dùng cung cấp
export const FCM_VAPID_KEY = "BFEPvBCMCoEp68upwpv7uSpua58bt1YInaxfDhRjMq_DSvSowUNM9OoguGrjXuCHG35BHxMw_iXiIAc1Ub-XQ0s";

export const SUPER_ADMIN_EMAILS = [
  "vuongdhkmhn@gmail.com"
];

export const SUPER_ADMIN_PHONES = [
  "0393368007",
  "+84393368007"
];

export interface UserActivityLog {
  id: string;
  timestamp: string;
  userId: string;
  userType: 'anonymous' | 'registered' | 'admin';
  userEmail?: string;
  phoneNumber?: string;
  action: string;
  details?: string;
  deviceModel?: string;
  createdAt?: any;
}

export interface AdbErrorReport {
  id: string;
  timestamp: string;
  createdAt: number;
  dateKey?: string; // YYYY-MM-DD
  userId?: string;
  userEmail?: string;
  userType?: 'anonymous' | 'registered' | 'admin';
  deviceModel?: string;
  manufacturer?: string;
  androidVersion?: string;
  command: string;
  errorMessage: string;
  outputSnippet?: string;
  sourceModule?: string;
  count?: number; // Số lần xảy ra lỗi này
  lastOccurredAt?: number;
}

export interface AppGlobalSettings {
  appName: string;
  appSlogan: string;
  appDomain: string;
  avatarUrl: string;
  // SEO & Verification
  seo: {
    metaTitle: string;
    metaDescription: string;
    metaKeywords: string;
    googleSiteVerification: string;
    bingSiteVerification: string;
    customHeadTags: string;
    adsTxtContent: string;
    googleAdsenseClient: string;
    adSlotSidebar?: string;
    adSlotBottom?: string;
  };
  // Push Notification (FCM)
  fcm: {
    vapidKey: string;
    autoPrompt: boolean;
    welcomePushTitle: string;
    welcomePushBody: string;
  };
  // Monetization
  monetization: {
    enabled: boolean;
    pricePerFixVnd: number;
    vipMembershipVnd: number;
    bankInfo: {
      bankName: string;
      accountNumber: string;
      accountHolder: string;
    };
  };
  features: {
    chinaRomFixLocked: boolean;
    globalBugsLocked: boolean;
    ultraFixPushLocked: boolean;
    shizukuBridgeLocked: boolean;
    debloatLocked: boolean;
    localizationLocked: boolean;
    performanceLocked: boolean;
    noAdbLocked?: boolean;
    multiBrandLocked?: boolean;
    apkInstallLocked?: boolean;
    hardwareLocked?: boolean;
    bankFixLocked?: boolean;
    mirrorLocked?: boolean;
    aiAssistantLocked?: boolean;
  };
  featurePrices: {
    chinaRomFix: number;
    globalBugs: number;
    ultraFixPush: number;
    shizukuBridge: number;
    debloat: number;
    localization: number;
    performance: number;
    noAdb?: number;
    multiBrand?: number;
    apkInstall?: number;
    hardware?: number;
    bankFix?: number;
    mirror?: number;
    aiAssistant?: number;
  };
  // Tùy chỉnh chân trang (Footer Customization)
  footer: {
    showFooter: boolean;
    showDisclaimer: boolean;
    customDisclaimerText: string;
    customCopyrightText: string;
    contactInfo: string;
  };
  // Tùy chỉnh phạm vi hệ điều hành hỗ trợ (Android & MagicOS Version Scope)
  androidSupport?: {
    supportedAndroidRange: string; // Ví dụ: "Android 8.0 - 17+ (2026 Ready)"
    supportedMagicOsRange: string; // Ví dụ: "MagicOS 7.0 - 11+ & Đa Hãng 2026"
    supportedOsListText: string;   // Ví dụ: "MagicOS, HyperOS, One UI, ColorOS, OriginOS, Pixel"
  };
  adminList: string[];
  // Cho phép Admin ẩn/hiện tab thông tin Admin trên Dialog Chat AI
  showSupportAdminTab?: boolean;
  // Quản lý cấp quyền thành viên VIP & mở khóa tính năng sau khi thanh toán
  vipUsers?: string[]; // Danh sách email hoặc UID đã mua gói VIP trọn đời
  grantedFeatures?: Record<string, string[]>; // Map [emailOrUid]: ['chinaRomFix', 'ultraFixPush', 'debloat', ...]
  // Quản lý kho tệp APK trực tuyến do Admin tải lên cho người dùng cài trực tiếp
  customApkList?: ApkPackageItem[];
  // Link tải App MagicTune APK (có thể chỉnh sửa từ trang Quản trị)
  magicTuneApkUrl?: string;
  magicTuneGithubApkUrl?: string;
  magicTuneGithubRepoUrl?: string;
  // Cấu hình Groq AI Assistant thông minh (Llama 3.3 70B)
  groqConfig?: {
    apiKey?: string;
    model?: string;
    systemPrompt?: string;
  };
}

export const DEFAULT_APP_SETTINGS: AppGlobalSettings = {
  appName: "MagicTune",
  appSlogan: "Bộ công cụ WebADB tối ưu hóa & Fix lỗi đa hệ điều hành Android.",
  appDomain: "magictune.web.app",
  avatarUrl: "/icon.png",
  magicTuneApkUrl: "https://drive.google.com/drive/folders/1WLsS-OlxvKFUWzMPxnkrNn8kmlVIY6-k?usp=sharing",
  magicTuneGithubApkUrl: "https://github.com/Vuong05062000/MagicTune-OpenSource/releases",
  magicTuneGithubRepoUrl: "https://github.com/Vuong05062000/MagicTune-OpenSource",
  showSupportAdminTab: true,
  groqConfig: {
    apiKey: process.env.NEXT_PUBLIC_GROQ_API_KEY || "",
    model: "llama-3.3-70b-versatile",
    systemPrompt: `Bạn là trợ lý ảo hỗ trợ khách hàng và chuyên viên kỹ thuật chuyên nghiệp, nhiệt tình của MagicTune (bộ công cụ WebADB tối ưu hóa Android trực tuyến hàng đầu tại https://magictune.web.app).
Phong cách trò chuyện:
- Trò chuyện tự nhiên, xưng hô thân thiện, lịch thiệp như một con người thật đang hỗ trợ 1-1 ("mình - bạn" hoặc "tôi - bạn").
- Trả lời ngắn gọn, đúng trọng tâm, dễ hiểu, giàu chuyên môn nhưng không máy móc.
- Kiến thức chuyên sâu về: kết nối WebADB, bật Gỡ lỗi USB, nút "⚡ Ép Hiện Bảng Cho Phép (RSA Mới)" để xóa chứng chỉ RSA cũ trong IndexedDB và sinh cặp khóa RSA-2048 mới ép Android bật sáng màn hình hiện bảng hỏi quyền, fix trễ thông báo Facebook, Messenger, Gmail, Zalo (bằng lệnh loại bỏ Doze Mode, cấp quyền FCM Push ngầm), kích hoạt Shizuku Engine, gỡ ứng dụng rác (debloat), cài đặt Google Play (GMS) và đa hệ điều hành (HyperOS, OriginOS, ColorOS, MagicOS, One UI).
- Hiện tại trang web MagicTune trên máy tính đang MIỄN PHÍ 100% toàn bộ tính năng. Trên điện thoại có app APK di động cho phép dùng thử miễn phí.`
  },
  vipUsers: ["vuongdhkmhn@gmail.com"],
  grantedFeatures: {},
  customApkList: [],
  androidSupport: {
    supportedAndroidRange: "Android",
    supportedMagicOsRange: "MagicOS",
    supportedOsListText: "Universal Android Support (Optimized for MagicOS, HyperOS, OriginOS, ColorOS, One UI & more)"
  },
  seo: {
    metaTitle: "MagicTune - Modern WebADB Toolkit for Android",
    metaDescription: "Bộ công cụ WebADB trực tuyến chuyên khắc phục trễ thông báo Facebook, Gmail, Zalo, debloat và tinh chỉnh thiết bị Android đa hệ điều hành không cần cài đặt phần mềm.",
    metaKeywords: "MagicTune, MagicOS, Honor, fix trễ thông báo, fix thông báo facebook honor, fix gmail honor, Shizuku, WebADB",
    googleSiteVerification: "",
    bingSiteVerification: "",
    customHeadTags: "",
    adsTxtContent: "google.com, pub-4256214784202059, DIRECT, f08c47fec0942fa0",
    googleAdsenseClient: "ca-pub-4256214784202059",
    adSlotSidebar: "",
    adSlotBottom: ""
  },
  fcm: {
    vapidKey: FCM_VAPID_KEY,
    autoPrompt: true,
    welcomePushTitle: "MagicTune đã sẵn sàng!",
    welcomePushBody: "Thiết bị Android của bạn đã sẵn sàng nhận thông báo theo thời gian thực."
  },
  monetization: {
    enabled: false,
    pricePerFixVnd: 50000,
    vipMembershipVnd: 199000,
    bankInfo: {
      bankName: "MB Bank",
      accountNumber: "",
      accountHolder: "BAN QUAN TRI MAGICTUNE"
    }
  },
  features: {
    chinaRomFixLocked: false,
    globalBugsLocked: false,
    ultraFixPushLocked: false,
    shizukuBridgeLocked: false,
    debloatLocked: false,
    localizationLocked: false,
    performanceLocked: false,
    noAdbLocked: false,
    multiBrandLocked: false,
    apkInstallLocked: false,
    hardwareLocked: false,
    bankFixLocked: false
  },
  featurePrices: {
    chinaRomFix: 30000,
    globalBugs: 30000,
    ultraFixPush: 50000,
    shizukuBridge: 20000,
    debloat: 20000,
    localization: 20000,
    performance: 20000,
    noAdb: 50000,
    multiBrand: 50000,
    apkInstall: 20000,
    hardware: 20000,
    bankFix: 30000
  },
  footer: {
    showFooter: true,
    showDisclaimer: true,
    customDisclaimerText: "MagicTune là dự án mã nguồn mở phi lợi nhuận do cộng đồng người dùng phát triển nhằm mục đích hỗ trợ kỹ thuật và tối ưu hóa trải nghiệm thiết bị. MagicTune hoàn toàn độc lập, không trực thuộc, không được ủy quyền, tài trợ hoặc có bất kỳ liên kết chính thức nào với Honor Device Co., Ltd hay tập đoàn Huawei. Tên gọi \"MagicOS\", \"Honor\" và các nhãn hiệu liên quan thuộc quyền sở hữu độc quyền của các đơn vị sở hữu tương ứng.",
    customCopyrightText: "MagicTune — magictune.web.app • Không Giới Hạn Tính Năng",
    contactInfo: "Hệ thống hỗ trợ trực tuyến 24/7 qua Trợ lý MagicTune AI"
  },
  adminList: ["vuongdhkmhn@gmail.com"]
};

/**
 * Bộ lọc xác minh: Chỉ ghi nhận các hoạt động trọng yếu & rõ ràng
 * Loại bỏ các hoạt động vãng lai, chuyển đổi giao diện, click xem thử
 */
export const isImportantMajorAction = (action: string, details: string = ''): boolean => {
  if (!action || typeof action !== 'string') return false;
  const act = action.trim().toLowerCase();
  const det = (details || '').trim().toLowerCase();

  // Bỏ qua các hoạt động vãng lai, chuyển đổi UI, mở setting chung
  const ignoredKeywords = [
    'chuyển giao diện',
    'đổi giao diện',
    'yêu cầu kết nối',
    'sao chép mã',
    'ngắt kết nối',
    'mở cài đặt',
    'xem trang',
    'click'
  ];
  if (ignoredKeywords.some(k => act.includes(k))) {
    return false;
  }

  // Danh mục hoạt động thực tế quan trọng cần lưu trữ
  const importantKeywords = [
    'đăng nhập', 'đăng ký', 'đăng xuất', 'tài khoản', 'mật khẩu', 'liên kết',
    'vip', 'thanh toán', 'chuyển khoản', 'cấp vip',
    'fix thông báo', 'thông báo', 'pin', 'bẻ khóa', 'hybrid', 'tối ưu',
    'gỡ', 'debloat', 'khôi phục',
    'nội địa', 'china', 'hiboard', 'yoyo', 'font', 'sim', 'launcher', 'gps',
    'android auto', 'dexopt', 'lag', 'kết nối mạng',
    'bảo mật', 'an toàn', 'chẩn đoán', 'tài chính',
    'google', 'gms', 'việt hóa', 'morelocale',
    'apk', 'shizuku', 'wlan', 'wireless', 'terminal', 'dpi', 'tần số quét',
    'kết nối thiết bị adb'
  ];

  return importantKeywords.some(k => act.includes(k) || det.includes(k));
};

export interface RealUserProfile {
  userId: string;
  email?: string;
  phone?: string;
  displayName?: string;
  photoURL?: string;
  role: 'admin' | 'registered';
  emailVerified?: boolean;
  primaryProvider?: string;
  linkedProviders?: string[];
  providerDetails?: Array<{
    providerId: string;
    email?: string;
    displayName?: string;
    phoneNumber?: string;
  }>;
  lastDeviceModel?: string;
  lastActive: number | string;
  lastLoginAt?: number;
  createdAt?: number;
}

/**
 * Chuyển đổi mọi định dạng thời gian (number ms, Firestore Timestamp, ISO string, chuỗi vi-VN) sang Epoch Milliseconds chuẩn xác
 */
export const parseToEpochMs = (val: any): number => {
  if (!val) return 0;
  if (typeof val === 'number') {
    if (isNaN(val) || val <= 0) return 0;
    // Nếu là timestamp tính bằng giây (10 chữ số) thay vì mili giây (13 chữ số)
    return val < 10000000000 ? val * 1000 : val;
  }
  // Nếu là Firestore Timestamp object
  if (typeof val === 'object') {
    if (typeof val.toMillis === 'function') {
      try { return val.toMillis(); } catch {}
    }
    if (typeof val.toDate === 'function') {
      try { return val.toDate().getTime(); } catch {}
    }
    if (typeof val.seconds === 'number') {
      return val.seconds * 1000 + Math.floor((val.nanoseconds || 0) / 1000000);
    }
    if (typeof val._seconds === 'number') {
      return val._seconds * 1000;
    }
  }
  // Nếu là chuỗi
  if (typeof val === 'string') {
    const trimmed = val.trim();
    if (!trimmed) return 0;
    // Thử Date.parse trước (ISO string, RFC, etc.)
    const parsed = Date.parse(trimmed);
    if (!isNaN(parsed) && parsed > 0) return parsed;

    // Bóc tách định dạng phổ biến của toLocaleString('vi-VN'):
    // Dạng 1: "14:23:31 14/11/2026" hoặc "14:23:31, 14/11/2026"
    const matchTimeFirst = trimmed.match(/(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?[\s,]+(\d{1,2})\/(\d{1,2})\/(\d{4})/);
    if (matchTimeFirst) {
      const [, hour, min, sec, day, month, year] = matchTimeFirst;
      const d = new Date(Number(year), Number(month) - 1, Number(day), Number(hour), Number(min), Number(sec || 0));
      if (!isNaN(d.getTime())) return d.getTime();
    }

    // Dạng 2: "14/11/2026, 14:23:31" hoặc "14/11/2026 14:23:31"
    const matchDateFirst = trimmed.match(/(\d{1,2})\/(\d{1,2})\/(\d{4})[\s,]+(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?/);
    if (matchDateFirst) {
      const [, day, month, year, hour, min, sec] = matchDateFirst;
      const d = new Date(Number(year), Number(month) - 1, Number(day), Number(hour), Number(min), Number(sec || 0));
      if (!isNaN(d.getTime())) return d.getTime();
    }
  }
  return 0;
};

/**
 * Định dạng mốc thời gian sang định dạng Tiếng Việt chuẩn 24h: HH:mm:ss DD/MM/YYYY
 */
export const formatVietnamDateTime = (val: any): string => {
  const ms = parseToEpochMs(val);
  if (!ms || ms <= 0) return 'Chưa rõ';
  const d = new Date(ms);
  if (isNaN(d.getTime())) return 'Chưa rõ';
  return d.toLocaleString('vi-VN', { hour12: false });
};

/**
 * Tính thời gian tương đối thân thiện (VD: Vừa xong, 5 phút trước, 2 giờ trước, Hôm qua)
 */
export const getRelativeTimeString = (val: any): string => {
  const ms = parseToEpochMs(val);
  if (!ms || ms <= 0) return '';
  const now = Date.now();
  const diffSec = Math.floor((now - ms) / 1000);
  if (diffSec < 0 || diffSec < 10) return 'Vừa xong';
  if (diffSec < 60) return `${diffSec}s trước`;
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin} phút trước`;
  const diffHours = Math.floor(diffMin / 60);
  if (diffHours < 24) return `${diffHours} giờ trước`;
  const diffDays = Math.floor(diffHours / 24);
  if (diffDays === 1) return 'Hôm qua';
  if (diffDays < 30) return `${diffDays} ngày trước`;
  return `${Math.floor(diffDays / 30)} tháng trước`;
};

// Bộ nhớ đệm chống ghi thừa profile (debounce 10 phút / user)
const lastUserProfileSyncMap = new Map<string, number>();

/**
 * Đồng bộ hồ sơ tài khoản người dùng thật vào collection 'users' trên Firestore
 * Tự động debounce 10 phút để tiết kiệm chi phí Cloud Firestore cho Admin
 */
export const syncUserProfileToFirestore = async (
  user: any,
  extraData: { lastDeviceModel?: string; primaryProvider?: string } = {},
  forceSync: boolean = false
) => {
  if (!user || user.isAnonymous) return;

  const now = Date.now();
  const lastSync = lastUserProfileSyncMap.get(user.uid) || 0;

  // Nếu đã sync trong vòng 10 phút và không bị ép buộc (forceSync = false)
  // và không có model máy mới, bỏ qua để cắt giảm 80% số lượt ghi Firestore
  if (!forceSync && now - lastSync < 10 * 60 * 1000 && !extraData.lastDeviceModel) {
    return;
  }

  try {
    const userDocRef = doc(db, 'users', user.uid);
    const emailLower = (user.email || '').toLowerCase();
    const isAdmin = SUPER_ADMIN_EMAILS.includes(emailLower) || (user.phoneNumber && SUPER_ADMIN_PHONES.includes(user.phoneNumber));

    const providers = Array.isArray(user.providerData)
      ? user.providerData.map((p: any) => ({
          providerId: p.providerId || '',
          email: p.email || '',
          displayName: p.displayName || '',
          phoneNumber: p.phoneNumber || ''
        }))
      : [];

    const providerIds = providers.map((p: any) => p.providerId);
    let primaryProvider = extraData.primaryProvider;
    if (!primaryProvider) {
      if (providerIds.includes('google.com')) primaryProvider = 'google';
      else if (providerIds.includes('facebook.com')) primaryProvider = 'facebook';
      else if (providerIds.includes('phone')) primaryProvider = 'phone';
      else if (providerIds.includes('password')) primaryProvider = 'password';
      else primaryProvider = user.email ? 'email' : 'google';
    }

    const now = Date.now();
    const creationTime = user.metadata?.creationTime ? parseToEpochMs(user.metadata.creationTime) : undefined;
    const lastSignInTime = user.metadata?.lastSignInTime ? parseToEpochMs(user.metadata.lastSignInTime) : undefined;

    const payload: any = {
      uid: user.uid,
      email: user.email || '',
      displayName: user.displayName || (user.email ? user.email.split('@')[0] : 'Chưa cập nhật tên'),
      phoneNumber: user.phoneNumber || '',
      photoURL: user.photoURL || '',
      emailVerified: Boolean(user.emailVerified),
      role: isAdmin ? 'admin' : 'registered',
      primaryProvider,
      linkedProviders: providerIds,
      providerDetails: providers,
      lastActiveAt: now
    };

    if (lastSignInTime && !isNaN(lastSignInTime) && lastSignInTime > 0) {
      payload.lastLoginAt = lastSignInTime;
    }
    if (creationTime && !isNaN(creationTime) && creationTime > 0) {
      payload.createdAt = creationTime;
    }

    if (extraData.lastDeviceModel && extraData.lastDeviceModel !== 'HONOR Device') {
      payload.lastDeviceModel = extraData.lastDeviceModel;
    }

    await setDoc(userDocRef, payload, { merge: true });
    lastUserProfileSyncMap.set(user.uid, now);
  } catch (e) {
    console.warn('Lỗi đồng bộ hồ sơ user lên Firestore:', e);
  }
};

/**
 * Lấy danh sách tài khoản người dùng thật từ bộ sưu tập 'users' với đầy đủ thông tin chi tiết
 */
export const fetchRealUsersFromFirestore = async (): Promise<RealUserProfile[]> => {
  try {
    const qUsers = query(collection(db, 'users'), limit(200));
    const snap = await getDocs(qUsers);
    if (!snap.empty) {
      return snap.docs.map(d => {
        const data = d.data();
        const parsedCreatedAt = parseToEpochMs(data.createdAt || data.lastActiveAt);
        const parsedLastLogin = parseToEpochMs(data.lastLoginAt);
        const parsedLastActive = parseToEpochMs(data.lastActiveAt || data.lastActive || data.lastLoginAt || data.createdAt);

        return {
          userId: d.id,
          email: data.email || '',
          phone: data.phoneNumber || '',
          displayName: data.displayName || '',
          photoURL: data.photoURL || '',
          role: (data.role === 'admin' ? 'admin' : 'registered') as 'admin' | 'registered',
          emailVerified: Boolean(data.emailVerified),
          primaryProvider: data.primaryProvider || '',
          linkedProviders: Array.isArray(data.linkedProviders) ? data.linkedProviders : [],
          providerDetails: Array.isArray(data.providerDetails) ? data.providerDetails : [],
          lastDeviceModel: data.lastDeviceModel || '',
          lastActive: parsedLastActive,
          lastLoginAt: parsedLastLogin || undefined,
          createdAt: parsedCreatedAt || undefined
        };
      });
    }
  } catch (e) {
    console.warn('Lỗi lấy danh sách user từ Firestore:', e);
  }
  return [];
};

// Queue đệm ghi batch và chống spam nhật ký hoạt động
const recentActivityMap = new Map<string, number>();
const activityLogBuffer: UserActivityLog[] = [];
let bufferFlushTimeout: any = null;

/**
 * Đẩy toàn bộ log đang chờ trong hàng đợi lên Firestore bằng writeBatch (1 request duy nhất)
 */
export const flushPendingActivityLogs = async (): Promise<void> => {
  if (bufferFlushTimeout) {
    clearTimeout(bufferFlushTimeout);
    bufferFlushTimeout = null;
  }
  if (activityLogBuffer.length === 0) return;

  const itemsToFlush = activityLogBuffer.splice(0, 50);
  try {
    const batch = writeBatch(db);
    const logsCol = collection(db, 'activity_logs');
    itemsToFlush.forEach(log => {
      const docRef = doc(logsCol);
      batch.set(docRef, log);
    });
    await batch.commit();
  } catch (err) {
    console.warn('Lỗi ghi batch activity_logs lên Firestore:', err);
    // Nếu có lỗi mạng, hoàn lại vào hàng đợi nếu chưa đầy
    if (activityLogBuffer.length < 100) {
      activityLogBuffer.unshift(...itemsToFlush);
    }
  }
};

// Flush tự động khi người dùng rời trang hoặc chuyển tab
if (typeof window !== 'undefined') {
  window.addEventListener('beforeunload', () => {
    if (activityLogBuffer.length > 0) {
      flushPendingActivityLogs();
    }
  });
  window.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden' && activityLogBuffer.length > 0) {
      flushPendingActivityLogs();
    }
  });
}

/**
 * Ghi nhận hành động người dùng TRỰC TIẾP LÊN CLOUD FIRESTORE
 * TÍCH HỢP HÀNG ĐỢI GHI THEO LÔ (BATCHING) + CHỐNG TRÙNG LẶP LIÊN TIẾP TRONG 30S
 */
export const recordUserActivity = async (
  action: string,
  details: string = '',
  deviceModel: string = 'HONOR Device'
) => {
  if (typeof window === 'undefined') return;

  const currentAuthUser = auth.currentUser;

  // 1. Chỉ ghi nhận người dùng thật đã đăng nhập, LOẠI BỎ TRIỆT ĐỂ khách ẩn danh
  if (!currentAuthUser || currentAuthUser.isAnonymous) {
    return;
  }

  // 2. Không ghi lại các hoạt động mơ hồ/vô nghĩa, chỉ ghi lại hoạt động chính
  if (!isImportantMajorAction(action, details)) {
    return;
  }

  const userId = currentAuthUser.uid;
  const now = Date.now();

  // 3. Chống ghi trùng lặp liên tiếp trong 30 giây cho cùng một tác vụ
  const actionKey = `${userId}:${action}:${details}`;
  const lastActionTime = recentActivityMap.get(actionKey);
  if (lastActionTime && now - lastActionTime < 30 * 1000) {
    return;
  }
  recentActivityMap.set(actionKey, now);

  // Thu dọn bộ nhớ tạm chống spam nếu vượt quá 200 bản ghi
  if (recentActivityMap.size > 200) {
    const cutoff = now - 60 * 1000;
    for (const [k, v] of recentActivityMap.entries()) {
      if (v < cutoff) recentActivityMap.delete(k);
    }
  }

  const userEmail = currentAuthUser.email || undefined;
  const phoneNumber = currentAuthUser.phoneNumber || undefined;
  const emailLower = (currentAuthUser.email || '').toLowerCase();

  let userType: 'registered' | 'admin' = 'registered';
  let adminList = DEFAULT_APP_SETTINGS.adminList;
  const saved = localStorage.getItem('magictune_admin_settings');
  if (saved) {
    try {
      adminList = JSON.parse(saved).adminList || adminList;
    } catch (e) {}
  }

  if (
    SUPER_ADMIN_EMAILS.includes(emailLower) ||
    adminList.includes(emailLower) ||
    (currentAuthUser.phoneNumber && SUPER_ADMIN_PHONES.includes(currentAuthUser.phoneNumber))
  ) {
    userType = 'admin';
  } else {
    userType = 'registered';
  }

  // Đồng bộ user vào collection users (đã được debounce 10 phút bên trong)
  syncUserProfileToFirestore(currentAuthUser);

  const logEntry: UserActivityLog = {
    id: Math.random().toString(36).substring(2, 11),
    timestamp: new Date().toLocaleString('vi-VN', { hour12: false }),
    userId,
    userType,
    userEmail: userEmail || '',
    phoneNumber: phoneNumber || '',
    action,
    details,
    deviceModel,
    createdAt: now
  };

  // Lưu nhanh vào LocalStorage để UI tức thời có lịch sử
  try {
    const existingLogsStr = localStorage.getItem('magictune_activity_logs');
    const existingLogs: UserActivityLog[] = existingLogsStr ? JSON.parse(existingLogsStr) : [];
    existingLogs.unshift(logEntry);
    localStorage.setItem('magictune_activity_logs', JSON.stringify(existingLogs.slice(0, 500)));
  } catch (e) {}

  // Đưa vào hàng đợi ghi Firestore
  activityLogBuffer.push(logEntry);

  // Các sự kiện tài chính, VIP, cấp quyền, đăng ký/nhập thì ghi ngay lập tức
  const isHighPriority = /vip|thanh toán|chuyển khoản|cấp vip|đăng ký|đăng nhập|mật khẩu/i.test(action + details);

  if (isHighPriority || activityLogBuffer.length >= 3) {
    await flushPendingActivityLogs();
  } else {
    // Tự động gom lô và flush sau 15 giây nếu chưa đủ 3 sự kiện
    if (!bufferFlushTimeout) {
      bufferFlushTimeout = setTimeout(() => {
        flushPendingActivityLogs();
      }, 15000);
    }
  }
};

/**
 * Lấy cài đặt hệ thống từ Firestore
 */
export const fetchLiveSettingsFromFirestore = async (): Promise<AppGlobalSettings> => {
  try {
    const docRef = doc(db, 'system_config', 'global_settings');
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      const data = docSnap.data();
      const safeAdminList = Array.isArray(data.adminList)
        ? data.adminList.map((a: any) => (typeof a === 'object' && a !== null ? (a.actorRole || a.email || JSON.stringify(a)) : String(a)))
        : DEFAULT_APP_SETTINGS.adminList;
      return { ...DEFAULT_APP_SETTINGS, ...data, adminList: safeAdminList } as AppGlobalSettings;
    }
  } catch (e) {
    console.warn('Lấy config Firestore lỗi, dùng cache:', e);
  }

  if (typeof window !== 'undefined') {
    const saved = localStorage.getItem('magictune_admin_settings');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        const safeAdminList = Array.isArray(parsed.adminList)
          ? parsed.adminList.map((a: any) => (typeof a === 'object' && a !== null ? (a.actorRole || a.email || JSON.stringify(a)) : String(a)))
          : DEFAULT_APP_SETTINGS.adminList;
        return { ...DEFAULT_APP_SETTINGS, ...parsed, adminList: safeAdminList };
      } catch (err) {}
    }
  }
  return DEFAULT_APP_SETTINGS;
};

/**
 * Lưu cài đặt hệ thống lên Firestore
 */
export const saveLiveSettingsToFirestore = async (settings: AppGlobalSettings): Promise<boolean> => {
  try {
    const docRef = doc(db, 'system_config', 'global_settings');
    await setDoc(docRef, settings, { merge: true });
    if (typeof window !== 'undefined') {
      localStorage.setItem('magictune_admin_settings', JSON.stringify(settings));
    }
    return true;
  } catch (e) {
    console.warn('Lỗi lưu cấu hình lên Firestore:', e);
    if (typeof window !== 'undefined') {
      localStorage.setItem('magictune_admin_settings', JSON.stringify(settings));
    }
    return true;
  }
};

/**
 * Lấy mốc thời gian 00:00:00 đầu ngày hôm nay (Local time)
 */
export const getStartOfTodayTimestamp = (): number => {
  const now = new Date();
  return new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0).getTime();
};

/**
 * Lấy chuỗi định dạng ngày hôm nay (YYYY-MM-DD)
 */
export const getTodayDateKey = (): string => {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

/**
 * Lấy danh sách Logs từ Firestore - CHỈ LẤY DỮ LIỆU TRONG NGÀY HÔM NAY để tiết kiệm tối đa chi phí đọc Firebase
 * Tự động loại bỏ hoàn toàn nhật ký người dùng ẩn danh
 */
export const fetchLiveActivityLogsFromFirestore = async (onlyToday: boolean = true): Promise<UserActivityLog[]> => {
  const startOfToday = getStartOfTodayTimestamp();
  try {
    const logsCol = collection(db, 'activity_logs');
    let snapshot;
    try {
      const q = onlyToday
        ? query(logsCol, where('createdAt', '>=', startOfToday), orderBy('createdAt', 'desc'), limit(300))
        : query(logsCol, orderBy('createdAt', 'desc'), limit(300));
      snapshot = await getDocs(q);
    } catch {
      // Fallback khi chưa có composite index hoặc offline
      const qFallback = query(logsCol, orderBy('createdAt', 'desc'), limit(300));
      snapshot = await getDocs(qFallback);
    }

    if (!snapshot.empty) {
      const items: UserActivityLog[] = [];
      const toSafeStr = (val: any): string => {
        if (val == null) return '';
        if (typeof val === 'object') {
          if (val.actorRole) return String(val.actorRole);
          if (val.name) return String(val.name);
          if (val.label) return String(val.label);
          return JSON.stringify(val);
        }
        return String(val);
      };

      snapshot.forEach((d) => {
        const raw = d.data() || {};
        let safeUserType: 'anonymous' | 'registered' | 'admin' = 'anonymous';
        if (typeof raw.userType === 'object' && raw.userType !== null) {
          safeUserType = (raw.userType.actorRole || raw.userType.role || 'anonymous') as any;
        } else if (typeof raw.userType === 'string') {
          safeUserType = raw.userType as any;
        }

        const createdAt = typeof raw.createdAt === 'number' ? raw.createdAt : Date.now();
        // Lọc nghiêm ngặt: Chỉ nạp dữ liệu phát sinh trong ngày hôm nay
        if (onlyToday && createdAt < startOfToday) {
          return;
        }

        // CHỈ LẤY NGƯỜI DÙNG THẬT (registered hoặc admin), LOẠI BỎ ẨN DANH
        if (safeUserType === 'registered' || safeUserType === 'admin') {
          const uid = toSafeStr(raw.userId);
          if (!uid.startsWith('anon_')) {
            items.push({
              id: d.id,
              timestamp: toSafeStr(raw.timestamp) || new Date(createdAt).toLocaleString('vi-VN'),
              userId: uid || d.id,
              userType: safeUserType,
              userEmail: toSafeStr(raw.userEmail),
              phoneNumber: toSafeStr(raw.phoneNumber),
              action: toSafeStr(raw.action) || 'Hoạt động',
              details: toSafeStr(raw.details),
              deviceModel: toSafeStr(raw.deviceModel),
              createdAt
            });
          }
        }
      });
      return items;
    }
  } catch (e) {
    console.warn('Lấy logs Firestore lỗi, dùng cache local:', e);
  }

  if (typeof window !== 'undefined') {
    const saved = localStorage.getItem('magictune_activity_logs');
    if (saved) {
      try {
        const parsed: UserActivityLog[] = JSON.parse(saved);
        return parsed.filter(l => (l.userType === 'registered' || l.userType === 'admin') && !l.userId?.startsWith('anon_') && (!onlyToday || l.createdAt >= startOfToday));
      } catch (err) {}
    }
  }
  return [];
};

/**
 * Tạo phiên quét mã QR Đăng Nhập (QR Auth Session)
 */
export const createQrLoginSession = async (): Promise<{ sessionId: string; qrUrl: string }> => {
  const sessionId = 'qr_auth_' + Math.random().toString(36).substring(2, 12);
  const sessionRef = doc(db, 'qr_sessions', sessionId);
  
  await setDoc(sessionRef, {
    sessionId,
    status: 'pending', // pending -> approved -> expired
    createdAt: Date.now(),
    expiresAt: Date.now() + 5 * 60 * 1000 // 5 phút
  });

  const appOrigin = typeof window !== 'undefined' ? window.location.origin : 'https://magictune.web.app';
  const qrUrl = `${appOrigin}/auth/qr-confirm?session=${sessionId}`;

  return { sessionId, qrUrl };
};

/**
 * Đăng ký lắng nghe trạng thái quét mã QR từ điện thoại
 */
export const listenQrLoginSession = (
  sessionId: string,
  onApproved: (userData: any) => void,
  onExpired: () => void
): (() => void) => {
  const sessionRef = doc(db, 'qr_sessions', sessionId);
  const unsubscribe = onSnapshot(sessionRef, (docSnap) => {
    if (docSnap.exists()) {
      const data = docSnap.data();
      if (data.status === 'approved' && data.userData) {
        onApproved(data.userData);
      } else if (data.status === 'expired' || Date.now() > data.expiresAt) {
        onExpired();
      }
    }
  });
  return unsubscribe;
};

/**
 * Xác nhận duyệt phiên QR từ điện thoại di động đã đăng nhập
 */
export const approveQrLoginSession = async (sessionId: string, user: any): Promise<boolean> => {
  try {
    const sessionRef = doc(db, 'qr_sessions', sessionId);
    await setDoc(sessionRef, {
      status: 'approved',
      approvedAt: Date.now(),
      userData: {
        uid: user.uid,
        email: user.email || '',
        displayName: user.displayName || '',
        phoneNumber: user.phoneNumber || ''
      }
    }, { merge: true });
    return true;
  } catch (e) {
    console.error('Lỗi duyệt QR session:', e);
    return false;
  }
};

// Bộ nhớ đệm chống spam báo cáo lỗi ADB (chống gửi lặp cùng 1 lỗi trong 10s)
const recentErrorReportMap = new Map<string, number>();

/**
 * Tự động ghi nhận và đẩy báo cáo lỗi lệnh ADB (lệnh đỏ) về Firestore collection `adb_error_reports`
 * Phục vụ cho Ban Quản Trị theo dõi, sửa lỗi và nâng cấp website/driver.
 */
export const reportAdbCommandFailure = async (report: Omit<AdbErrorReport, 'id' | 'timestamp' | 'createdAt'>): Promise<boolean> => {
  if (typeof window === 'undefined') return false;

  const now = Date.now();
  const dateObj = new Date(now);
  const dateKey = `${dateObj.getFullYear()}-${String(dateObj.getMonth() + 1).padStart(2, '0')}-${String(dateObj.getDate()).padStart(2, '0')}`;
  
  // Tạo mã băm nhận diện lỗi duy nhất (Error Signature) kết hợp: Lệnh + Mã lỗi + Dòng máy + Ngày
  const cleanCmd = (report.command || '').trim().replace(/\s+/g, ' ');
  const cleanMsg = (report.errorMessage || '').trim().slice(0, 150);
  const cleanModel = (report.deviceModel || 'General').trim();
  
  const rawSignature = `${cleanCmd}|${cleanMsg}|${cleanModel}`;
  // Hàm băm chuỗi nhanh an toàn
  let hash = 0;
  for (let i = 0; i < rawSignature.length; i++) {
    hash = ((hash << 5) - hash) + rawSignature.charCodeAt(i);
    hash |= 0;
  }
  const errorSignature = `err_${Math.abs(hash).toString(36)}`;
  // ID tài liệu trên Firestore gom nhóm theo Ngày + Signature: Tránh sinh hàng triệu bản ghi trùng lặp!
  const docId = `${dateKey}_${errorSignature}`;

  // Chống ghi liên tiếp trong 15 giây cho cùng một client
  const dedupKey = `${docId}`;
  const lastReported = recentErrorReportMap.get(dedupKey);
  if (lastReported && now - lastReported < 15000) {
    return false;
  }
  recentErrorReportMap.set(dedupKey, now);

  if (recentErrorReportMap.size > 100) {
    const cutoff = now - 60000;
    for (const [k, v] of recentErrorReportMap.entries()) {
      if (v < cutoff) recentErrorReportMap.delete(k);
    }
  }

  try {
    const currentAuthUser = auth.currentUser;
    const isAuth = Boolean(currentAuthUser && !currentAuthUser.isAnonymous);
    const userId = currentAuthUser?.uid || 'guest_' + Math.random().toString(36).substring(2, 9);
    const userEmail = currentAuthUser?.email || undefined;
    const userType: 'anonymous' | 'registered' | 'admin' = isAuth
      ? (SUPER_ADMIN_EMAILS.includes((userEmail || '').toLowerCase()) ? 'admin' : 'registered')
      : 'anonymous';

    const fullReport: AdbErrorReport = {
      id: docId,
      timestamp: new Date().toLocaleString('vi-VN', { hour12: false }),
      createdAt: now,
      dateKey,
      userId: report.userId || userId,
      userEmail: report.userEmail || userEmail,
      userType: report.userType || userType,
      deviceModel: cleanModel,
      manufacturer: report.manufacturer || 'Android',
      androidVersion: report.androidVersion || '',
      command: cleanCmd,
      errorMessage: cleanMsg,
      outputSnippet: report.outputSnippet ? report.outputSnippet.slice(0, 500) : '',
      sourceModule: report.sourceModule || 'ADB Console',
      count: 1,
      lastOccurredAt: now
    };

    // 1. Lưu bộ nhớ cục bộ để Admin xem ngay lập tức
    try {
      const cacheStr = localStorage.getItem('magictune_adb_error_reports');
      const cached: AdbErrorReport[] = cacheStr ? JSON.parse(cacheStr) : [];
      const existingIdx = cached.findIndex(e => e.id === docId || (e.command === cleanCmd && e.errorMessage === cleanMsg && e.dateKey === dateKey));
      if (existingIdx >= 0) {
        cached[existingIdx].count = (cached[existingIdx].count || 1) + 1;
        cached[existingIdx].lastOccurredAt = now;
        cached[existingIdx].timestamp = fullReport.timestamp;
      } else {
        cached.unshift(fullReport);
      }
      localStorage.setItem('magictune_adb_error_reports', JSON.stringify(cached.slice(0, 200)));
    } catch (e) {
      console.debug('[Cache local error report]', e);
    }

    // 2. Đẩy thông minh lên Firestore (Sử dụng setDoc merge để tăng count và cập nhật thời gian mới nhất, không sinh trùng)
    const docRef = doc(db, 'adb_error_reports', docId);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      const existingData = docSnap.data();
      await setDoc(docRef, {
        ...fullReport,
        count: (existingData.count || 1) + 1,
        lastOccurredAt: now,
        timestamp: fullReport.timestamp
      }, { merge: true });
    } else {
      await setDoc(docRef, fullReport);
    }
    return true;
  } catch (err) {
    console.warn('[ADB Error Report] Không thể gửi báo cáo lỗi lên Cloud Firestore:', err);
    return false;
  }
};

/**
 * Lấy danh sách báo cáo lỗi lệnh ADB từ Firestore - CHỈ LẤY DỮ LIỆU TRONG NGÀY HÔM NAY để tiết kiệm chi phí
 */
export const fetchAdbErrorReportsFromFirestore = async (onlyToday: boolean = true): Promise<AdbErrorReport[]> => {
  const todayKey = getTodayDateKey();
  const startOfToday = getStartOfTodayTimestamp();
  try {
    const errorCol = collection(db, 'adb_error_reports');
    let snapshot;
    try {
      const q = onlyToday
        ? query(errorCol, where('dateKey', '==', todayKey), limit(200))
        : query(errorCol, orderBy('createdAt', 'desc'), limit(150));
      snapshot = await getDocs(q);
    } catch {
      const qFallback = query(errorCol, orderBy('createdAt', 'desc'), limit(150));
      snapshot = await getDocs(qFallback);
    }

    if (!snapshot.empty) {
      const items: AdbErrorReport[] = [];
      snapshot.forEach((d) => {
        const raw = d.data() as AdbErrorReport;
        const itemCreatedAt = raw.createdAt || Date.now();
        const itemDateKey = raw.dateKey || (raw.createdAt ? new Date(raw.createdAt).toISOString().split('T')[0] : todayKey);

        // Lọc nghiêm ngặt: Chỉ nạp dữ liệu lỗi phát sinh trong ngày hôm nay
        if (onlyToday && itemDateKey !== todayKey && itemCreatedAt < startOfToday) {
          return;
        }

        items.push({
          id: d.id,
          timestamp: raw.timestamp || new Date(itemCreatedAt).toLocaleString('vi-VN'),
          createdAt: itemCreatedAt,
          dateKey: itemDateKey,
          userId: raw.userId || '',
          userEmail: raw.userEmail || '',
          userType: raw.userType || 'anonymous',
          deviceModel: raw.deviceModel || 'Thiết bị Android',
          manufacturer: raw.manufacturer || '',
          androidVersion: raw.androidVersion || '',
          command: raw.command || '',
          errorMessage: raw.errorMessage || '',
          outputSnippet: raw.outputSnippet || '',
          sourceModule: raw.sourceModule || 'ADB Console',
          count: raw.count || 1,
          lastOccurredAt: raw.lastOccurredAt || raw.createdAt || Date.now()
        });
      });
      return items;
    }
  } catch (e) {
    console.warn('Lấy lỗi ADB từ Firestore thất bại, dùng cache local:', e);
  }

  if (typeof window !== 'undefined') {
    const cacheStr = localStorage.getItem('magictune_adb_error_reports');
    if (cacheStr) {
      try {
        const parsed: AdbErrorReport[] = JSON.parse(cacheStr);
        return parsed.filter(e => !onlyToday || e.dateKey === todayKey || (e.createdAt && e.createdAt >= startOfToday));
      } catch (e) {}
    }
  }
  return [];
};

export interface PurgeResult {
  activityLogsDeleted: number;
  adbErrorsDeleted: number;
  qrSessionsDeleted: number;
  success: boolean;
  message: string;
}

/**
 * DỌN SẠCH DỮ LIỆU CÁC NGÀY CŨ TRÊN FIREBASE (Cloud Firestore Storage & Read Optimizer)
 * Chỉ giữ lại dữ liệu trong ngày hôm nay cho các danh sách tạm thời (activity_logs, adb_error_reports, qr_sessions).
 * Giúp tiết kiệm tối đa hạn mức miễn phí (Free Tier) và chi phí lưu trữ/đọc ghi Firestore.
 */
export const purgeOldFirebaseData = async (): Promise<PurgeResult> => {
  const startOfToday = getStartOfTodayTimestamp();
  const todayKey = getTodayDateKey();
  let activityLogsDeleted = 0;
  let adbErrorsDeleted = 0;
  let qrSessionsDeleted = 0;

  try {
    // 1. Dọn dẹp activity_logs cũ (trước ngày hôm nay)
    try {
      const logsCol = collection(db, 'activity_logs');
      const oldLogsSnap = await getDocs(query(logsCol, where('createdAt', '<', startOfToday), limit(400)));
      if (!oldLogsSnap.empty) {
        const batch = writeBatch(db);
        oldLogsSnap.docs.forEach((docSnap) => {
          batch.delete(docSnap.ref);
          activityLogsDeleted++;
        });
        await batch.commit();
      }
    } catch (err) {
      console.warn('Lỗi dọn dẹp activity_logs cũ:', err);
    }

    // 2. Dọn dẹp adb_error_reports cũ (khác ngày hôm nay)
    try {
      const errCol = collection(db, 'adb_error_reports');
      const allErrSnap = await getDocs(query(errCol, limit(400)));
      if (!allErrSnap.empty) {
        const batch = writeBatch(db);
        let count = 0;
        allErrSnap.docs.forEach((docSnap) => {
          const data = docSnap.data();
          const isOld = (data.dateKey && data.dateKey < todayKey) || (data.createdAt && data.createdAt < startOfToday);
          if (isOld) {
            batch.delete(docSnap.ref);
            adbErrorsDeleted++;
            count++;
          }
        });
        if (count > 0) {
          await batch.commit();
        }
      }
    } catch (err) {
      console.warn('Lỗi dọn dẹp adb_error_reports cũ:', err);
    }

    // 3. Dọn dẹp qr_sessions cũ hoặc hết hạn
    try {
      const qrCol = collection(db, 'qr_sessions');
      const allQrSnap = await getDocs(query(qrCol, limit(200)));
      if (!allQrSnap.empty) {
        const batch = writeBatch(db);
        let count = 0;
        allQrSnap.docs.forEach((docSnap) => {
          const data = docSnap.data();
          const isExpired = (data.expiresAt && Date.now() > data.expiresAt) || (data.createdAt && data.createdAt < startOfToday);
          if (isExpired) {
            batch.delete(docSnap.ref);
            qrSessionsDeleted++;
            count++;
          }
        });
        if (count > 0) {
          await batch.commit();
        }
      }
    } catch (err) {
      console.warn('Lỗi dọn dẹp qr_sessions cũ:', err);
    }

    // 4. Dọn dẹp LocalStorage bộ nhớ đệm
    if (typeof window !== 'undefined') {
      try {
        const cachedLogs = localStorage.getItem('magictune_activity_logs');
        if (cachedLogs) {
          const parsed: UserActivityLog[] = JSON.parse(cachedLogs);
          const filtered = parsed.filter(l => l.createdAt >= startOfToday);
          localStorage.setItem('magictune_activity_logs', JSON.stringify(filtered));
        }

        const cachedErrors = localStorage.getItem('magictune_adb_error_reports');
        if (cachedErrors) {
          const parsed: AdbErrorReport[] = JSON.parse(cachedErrors);
          const filtered = parsed.filter(e => e.dateKey === todayKey || (e.createdAt && e.createdAt >= startOfToday));
          localStorage.setItem('magictune_adb_error_reports', JSON.stringify(filtered));
        }
      } catch (e) {}
    }

    const total = activityLogsDeleted + adbErrorsDeleted + qrSessionsDeleted;
    return {
      activityLogsDeleted,
      adbErrorsDeleted,
      qrSessionsDeleted,
      success: true,
      message: total > 0
        ? `Đã dọn sạch thành công ${total} mục dữ liệu cũ (${activityLogsDeleted} nhật ký, ${adbErrorsDeleted} lỗi ADB, ${qrSessionsDeleted} phiên QR) để tiết kiệm tối đa chi phí Firestore!`
        : 'Toàn bộ dữ liệu Firestore và bộ nhớ cục bộ đã được tối ưu hóa chỉ giữ dữ liệu hôm nay!'
    };
  } catch (e: any) {
    return {
      activityLogsDeleted,
      adbErrorsDeleted,
      qrSessionsDeleted,
      success: false,
      message: `Lỗi trong quá trình dọn dẹp: ${e.message || e}`
    };
  }
};

/**
 * Đăng ký Web Push Notification (FCM)
 */
export const requestPushNotificationPermission = async (): Promise<string | null> => {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return null;
  }
  try {
    const permission = await Notification.requestPermission();
    if (permission === 'granted') {
      new Notification('MagicTune Push System', {
        body: 'Thông báo đẩy đã được kích hoạt thành công trên thiết bị!',
        icon: '/icon.png'
      });
      return 'granted';
    }
    return permission;
  } catch (e) {
    console.warn('Lỗi xin quyền Push Notification:', e);
    return null;
  }
};

export interface ApkPackageItem {
  id: string;
  name: string;
  version: string;
  category: 'Shizuku' | 'MicroG' | 'Google Services' | 'Keyboard' | 'Utility';
  description: string;
  size: string;
  downloadUrl: string;
  sha256: string;
  recommendedFor: string;
}

export const VERIFIED_APK_LIST: ApkPackageItem[] = [
  {
    id: 'shizuku-manager',
    name: 'Shizuku Manager (Rikka / Xingchen)',
    version: '13.5.4',
    category: 'Shizuku',
    description: 'Cầu nối thực thi lệnh ADB trực tiếp trên máy không cần cắm cáp máy tính, hỗ trợ kích hoạt qua Gỡ lỗi không dây (Wireless debugging).',
    size: '3.9 MB',
    downloadUrl: 'https://github.com/RikkaApps/Shizuku/releases',
    sha256: '98fa10b98273645c11029abde44901fbc65721a9987634f120e83fa1c94410f92b',
    recommendedFor: 'Tất cả các dòng MagicOS 7.0 - 11+'
  },
  {
    id: 'microg-services-hw',
    name: 'MicroG Services Core (Huawei/Honor Edition)',
    version: '0.3.5.240913-hw',
    category: 'MicroG',
    description: 'Bản vá đặc biệt tương thích cơ chế Signature Spoofing và push GCM/FCM cho thiết bị Honor không cài sẵn GMS.',
    size: '28.4 MB',
    downloadUrl: 'https://github.com/microg/GmsCore/releases',
    sha256: 'e83fa1c94410f92b7c07b66c0d6f43e129aa24bb9e34e101f3014a9089e1cfa2',
    recommendedFor: 'Honor China ROM (MagicOS 7.0 - 11+)'
  },
  {
    id: 'microg-companion',
    name: 'MicroG Companion (Services Framework Proxy)',
    version: '0.1.0-honor',
    category: 'MicroG',
    description: 'Thư viện cầu nối giúp các app ngân hàng và game nhận diện Google Play Services giả lập.',
    size: '1.8 MB',
    downloadUrl: 'https://github.com/microg',
    sha256: '992abef71a24d5e9821a0021c38fa1b490f023ab9012a45610bc98371a56e012',
    recommendedFor: 'Tất cả thiết bị chạy MicroG'
  },
  {
    id: 'google-play-store',
    name: 'Google Play Store (Phonesky Stub)',
    version: '40.8.22',
    category: 'Google Services',
    description: 'Cửa hàng ứng dụng Google chính thức kích hoạt tài khoản tải ứng dụng gốc.',
    size: '59.2 MB',
    downloadUrl: 'https://www.apkmirror.com/apk/google-inc/google-play-store/',
    sha256: 'a12bc54e38901f45610ab98273645c11029abde44901fbc65721a9987634f120',
    recommendedFor: 'Honor MagicOS 8/9/10/11 có sẵn Google Framework'
  },
  {
    id: 'gboard-keyboard',
    name: 'Google GBoard (Bàn phím tiếng Việt Telex chuẩn)',
    version: '14.1.08',
    category: 'Keyboard',
    description: 'Bàn phím gõ tiếng Việt mượt mà, gợi ý từ thông minh, thay thế bàn phím Baidu/Honor nội địa.',
    size: '42.1 MB',
    downloadUrl: 'https://www.apkmirror.com/apk/google-inc/gboard/',
    sha256: '5908ef1a34b22c091d8e77a11f90a2c3451029ba880911feec093418aa1290bb',
    recommendedFor: 'Tất cả các dòng Honor máy xách tay'
  },
  {
    id: 'morelocale-2',
    name: 'MoreLocale 2 (Kích hoạt Tiếng Việt)',
    version: '2.4.1',
    category: 'Utility',
    description: 'Công cụ ép hệ thống và ứng dụng hiển thị ngôn ngữ Tiếng Việt (vi-VN).',
    size: '1.2 MB',
    downloadUrl: 'https://www.apkmirror.com/apk/c-lis-heritage/morelocale-2/',
    sha256: '4470fab1029c011e4f55a120b66cd81023aae1009bb4102938472910abbcc301',
    recommendedFor: 'Honor bản nội địa Trung Quốc chỉ có tiếng Anh/Hoa'
  }
];
