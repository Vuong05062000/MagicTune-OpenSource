/**
 * Cache lưu trữ dữ liệu thiết bị giữa các lần chuyển Tab (Session Device Cache)
 * Giải quyết triệt để vấn đề: Chuyển qua lại giữa các tab bị quét lại từ đầu
 * Giữ nguyên trạng thái đã quét (Ứng dụng, Gỡ rác, Phần cứng) trong suốt phiên kết nối
 */

export interface CachedNotificationData {
  appsList: any[];
  selectedApps: string[];
  lastScannedTime: string | null;
}

export interface CachedDebloatData {
  installedPackages: string[];
  lastScannedTime: string | null;
}

export interface CachedHardwareData {
  hwData: any;
  lastScannedTime: string | null;
}

class DeviceDataCacheManager {
  private notificationData: CachedNotificationData | null = null;
  private debloatData: CachedDebloatData | null = null;
  private hardwareData: CachedHardwareData | null = null;
  private currentDeviceId: string | null = null;

  /**
   * Thiết lập ID thiết bị hiện tại để quản lý vòng đời cache
   */
  public setCurrentDevice(deviceId: string | null) {
    if (this.currentDeviceId !== deviceId) {
      // Khi đổi sang thiết bị khác hoặc rút cáp, reset cache để tránh nhầm dữ liệu
      this.clearAll();
      this.currentDeviceId = deviceId;
    }
  }

  // === 1. NOTIFICATION FIXER CACHE ===
  public setNotificationData(data: CachedNotificationData) {
    this.notificationData = data;
  }

  public getNotificationData(): CachedNotificationData | null {
    return this.notificationData;
  }

  public hasNotificationData(): boolean {
    return this.notificationData !== null && this.notificationData.appsList.length > 0;
  }

  // === 2. DEBLOAT ENGINE CACHE ===
  public setDebloatData(data: CachedDebloatData) {
    this.debloatData = data;
  }

  public getDebloatData(): CachedDebloatData | null {
    return this.debloatData;
  }

  public hasDebloatData(): boolean {
    return this.debloatData !== null && this.debloatData.installedPackages.length > 0;
  }

  // === 3. HARDWARE DIAGNOSTICS CACHE ===
  public setHardwareData(data: CachedHardwareData) {
    this.hardwareData = data;
  }

  public getHardwareData(): CachedHardwareData | null {
    return this.hardwareData;
  }

  public hasHardwareData(): boolean {
    return this.hardwareData !== null && this.hardwareData.hwData !== null;
  }

  /**
   * Xóa toàn bộ dữ liệu khi rút thiết bị ra
   */
  public clearAll() {
    this.notificationData = null;
    this.debloatData = null;
    this.hardwareData = null;
  }
}

export const deviceDataCache = new DeviceDataCacheManager();
