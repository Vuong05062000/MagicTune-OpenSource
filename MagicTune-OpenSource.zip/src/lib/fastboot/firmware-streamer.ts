/**
 * MagicTune - Anti-Crash Memory Management & Large ROM Streaming Engine
 * Xử lý luồng file firmware dung lượng siêu lớn (3GB - 12GB) chống tràn RAM (Zero-OOM)
 * Sử dụng File System Access API & Streams API chuẩn W3C
 */

export interface FirmwareStreamProgress {
  /** Phần trăm hoàn tất (0 - 100) */
  percent: number;
  /** Tổng số byte đã đọc & xử lý */
  bytesProcessed: number;
  /** Tổng dung lượng file gốc (bytes) */
  totalBytes: number;
  /** Tốc độ truyền tải thực tế (Megabytes per second) */
  speedMBps: number;
  /** Số thứ tự chunk đang xử lý */
  chunkIndex: number;
  /** Ước lượng thời gian còn lại (giây) */
  estimatedSecondsLeft: number;
}

export interface FirmwareStreamOptions {
  /** Dung lượng mỗi phân đoạn đọc từ ổ đĩa (Mặc định: 2MB = 2 * 1024 * 1024 bytes) */
  chunkSize?: number;
  /** Bộ điều khiển hủy luồng */
  signal?: AbortSignal;
  /** Callback cập nhật tiến độ cho giao diện (UI) */
  onProgress?: (progress: FirmwareStreamProgress) => void;
  /**
   * Hook xử lý phân đoạn dữ liệu trước khi đẩy ra USB (Ví dụ: WebAssembly Sparse Unpacker)
   * Nhận vào chunk thô và trả về chunk đã được giải nén / biến đổi
   */
  transformChunk?: (chunk: Uint8Array, chunkIndex: number) => Promise<Uint8Array> | Uint8Array;
}

export interface SelectedFirmwareFile {
  handle: FileSystemFileHandle;
  file: File;
  name: string;
  size: number;
  readableSize: string;
}

/**
 * Mở hộp thoại chọn file ROM/Firmware sử dụng File System Access API
 * Không bao giờ nạp toàn bộ file vào RAM trình duyệt
 */
export async function pickLargeFirmwareFile(): Promise<SelectedFirmwareFile> {
  if (typeof window === 'undefined' || !('showOpenFilePicker' in window)) {
    throw new Error(
      'Trình duyệt không hỗ trợ File System Access API (showOpenFilePicker). Vui lòng sử dụng Google Chrome hoặc Microsoft Edge trên máy tính.'
    );
  }

  const [handle] = await (window as any).showOpenFilePicker({
    types: [
      {
        description: 'Android Firmware & Partition Images (.img, .bin, .sparse)',
        accept: {
          'application/octet-stream': ['.img', '.bin', '.sparse', '.sin', '.raw'],
        },
      },
    ],
    multiple: false,
    excludeAcceptAllOption: false,
  });

  const file = await handle.getFile();
  const readableSize = formatBytes(file.size);

  return {
    handle,
    file,
    name: file.name,
    size: file.size,
    readableSize,
  };
}

/**
 * Đọc và xử lý luồng file dung lượng lớn (3GB - 12GB) theo cơ chế Backpressure
 * Đảm bảo mức chiếm dụng RAM của Web App luôn ổn định dưới 20MB
 *
 * @param file Đối tượng File hoặc FileSystemFileHandle
 * @param consumerFn Hàm nhận dữ liệu (Ví dụ: fastboot.transferOut qua WebUSB)
 * @param options Cấu hình phân đoạn, timeout và callback
 */
export async function processLargeFirmware(
  file: File | FileSystemFileHandle,
  consumerFn: (chunk: Uint8Array, progress: FirmwareStreamProgress) => Promise<void>,
  options: FirmwareStreamOptions = {}
): Promise<{ totalProcessed: number; durationMs: number }> {
  const targetFile: File = file instanceof File ? file : await (file as FileSystemFileHandle).getFile();
  const totalBytes = targetFile.size;
  const chunkSize = options.chunkSize || 2 * 1024 * 1024; // Mặc định 2MB

  if (totalBytes === 0) {
    throw new Error('Tệp firmware rỗng (0 bytes). Vui lòng kiểm tra lại file đã chọn.');
  }

  const startTime = performance.now();
  let bytesProcessed = 0;
  let chunkIndex = 0;
  let lastProgressUpdateTime = startTime;
  let bytesSinceLastUpdate = 0;
  let currentSpeedMBps = 0;

  // Lấy luồng đọc chuẩn Web Streams API
  const rawStream = targetFile.stream() as ReadableStream<Uint8Array>;
  const reader = rawStream.getReader();

  // Bộ đệm tích lũy nội bộ để đảm bảo mỗi chunk gửi đi luôn đạt đúng kích thước chunkSize
  const pendingBuffer = new Uint8Array(chunkSize);
  let pendingLength = 0;

  try {
    while (true) {
      // 1. Kiểm tra tín hiệu hủy ngang từ người dùng
      if (options.signal?.aborted) {
        await reader.cancel('Thao tác nạp ROM đã bị người dùng hủy bỏ.');
        throw new DOMException('Thao tác bị hủy bởi người dùng.', 'AbortError');
      }

      // 2. Đọc phân đoạn kế tiếp từ ổ đĩa
      const { done, value } = await reader.read();

      if (done) {
        // Gửi nốt phần dữ liệu còn sót lại trong pendingBuffer
        if (pendingLength > 0) {
          const finalChunk = pendingBuffer.subarray(0, pendingLength);
          
          // =========================================================================
          // [ĐIỂM NEO WEBASSEMBLY]: Hook giải nén Android Sparse Image (.sparse -> .raw)
          // =========================================================================
          const processedChunk = options.transformChunk
            ? await options.transformChunk(finalChunk, chunkIndex)
            : finalChunk;

          bytesProcessed += pendingLength;
          chunkIndex++;

          // Áp dụng Backpressure: Đợi consumer hoàn tất ghi ra thiết bị trước khi tiếp tục
          await consumerFn(processedChunk, {
            percent: 100,
            bytesProcessed,
            totalBytes,
            speedMBps: currentSpeedMBps,
            chunkIndex,
            estimatedSecondsLeft: 0,
          });
        }
        break;
      }

      // Gom dữ liệu vào pendingBuffer
      let valueOffset = 0;
      while (valueOffset < value.byteLength) {
        const spaceLeft = chunkSize - pendingLength;
        const bytesToCopy = Math.min(spaceLeft, value.byteLength - valueOffset);

        pendingBuffer.set(value.subarray(valueOffset, valueOffset + bytesToCopy), pendingLength);
        pendingLength += bytesToCopy;
        valueOffset += bytesToCopy;

        // Khi buffer đầy đúng kích thước chunk yêu cầu (2MB):
        if (pendingLength === chunkSize) {
          const chunkToSend = pendingBuffer.slice(); // Tạo bản sao snapshot cho chunk này

          // =========================================================================
          // [ĐIỂM NEO WEBASSEMBLY]: Hook chèn module WASM Unsparse / Decompress
          // Module WebAssembly biên dịch từ libsparse (C/C++) sẽ unpack chunk tại đây:
          // const unsparseChunk = await wasmSparseEngine.processChunk(chunkToSend);
          // =========================================================================
          const processedChunk = options.transformChunk
            ? await options.transformChunk(chunkToSend, chunkIndex)
            : chunkToSend;

          bytesProcessed += chunkSize;
          bytesSinceLastUpdate += chunkSize;
          chunkIndex++;

          // Tính toán tốc độ & thời gian ước lượng
          const now = performance.now();
          const elapsedSec = (now - lastProgressUpdateTime) / 1000;
          if (elapsedSec >= 0.5) { // Cập nhật tốc độ mỗi 500ms
            currentSpeedMBps = Number(((bytesSinceLastUpdate / (1024 * 1024)) / elapsedSec).toFixed(2));
            lastProgressUpdateTime = now;
            bytesSinceLastUpdate = 0;
          }

          const percent = Math.min(99.9, Number(((bytesProcessed / totalBytes) * 100).toFixed(1)));
          const remainingBytes = totalBytes - bytesProcessed;
          const estimatedSecondsLeft = currentSpeedMBps > 0
            ? Math.round(remainingBytes / (currentSpeedMBps * 1024 * 1024))
            : 0;

          const progressData: FirmwareStreamProgress = {
            percent,
            bytesProcessed,
            totalBytes,
            speedMBps: currentSpeedMBps,
            chunkIndex,
            estimatedSecondsLeft,
          };

          if (options.onProgress) {
            options.onProgress(progressData);
          }

          // BACKPRESSURE: Đợi hoàn tất truyền gói qua USB trước khi đọc tiếp từ đĩa
          await consumerFn(processedChunk, progressData);

          // Reset độ dài bộ đệm để nạp chu kỳ tiếp theo (cho phép Garbage Collector dọn dẹp)
          pendingLength = 0;
        }
      }
    }
  } finally {
    reader.releaseLock();
  }

  const durationMs = performance.now() - startTime;
  return {
    totalProcessed: bytesProcessed,
    durationMs,
  };
}

/**
 * Định dạng số bytes thành chuỗi dung lượng trực quan (MB, GB)
 */
export function formatBytes(bytes: number, decimals = 2): string {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
}
