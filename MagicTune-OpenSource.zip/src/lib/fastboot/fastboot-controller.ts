/**
 * MagicTune - Fastboot WebUSB Controller (Engine Cấp Thấp)
 * Giao tiếp trực tiếp với bootloader Android qua WebUSB Interface (0xFF / 0x42 / 0x03)
 * Tuân thủ chuẩn AOSP Fastboot Protocol Specification
 */

export interface FastbootResponse {
  /** Trạng thái gói kết thúc */
  status: 'OKAY' | 'FAIL' | 'DATA';
  /** Nội dung thông điệp đi kèm OKAY hoặc lý do lỗi của FAIL */
  payload: string;
  /** Tập hợp dữ liệu từ các gói INFO đi trước (nếu có) */
  infoMessages: string[];
  /** Dung lượng dữ liệu thiết bị yêu cầu nạp (chỉ xuất hiện khi status === 'DATA') */
  dataSize?: number;
}

export class FastbootError extends Error {
  constructor(message: string, public readonly code?: string) {
    super(message);
    this.name = 'FastbootError';
  }
}

export class FastbootDevice {
  private device: USBDevice | null = null;
  private interfaceNumber: number | null = null;
  private endpointIn: number | null = null;
  private endpointOut: number | null = null;
  private maxPacketSize: number = 64;

  private readonly textEncoder = new TextEncoder();
  private readonly textDecoder = new TextDecoder('utf-8');

  // Bộ lọc Fastboot chuẩn Android Open Source Project (AOSP)
  public static readonly FASTBOOT_FILTER: USBDeviceFilter = {
    classCode: 0xff,
    subclassCode: 0x42,
    protocolCode: 0x03,
  };

  /**
   * Khởi tạo kết nối WebUSB, quét tìm Interface & Endpoint tương ứng
   * @param preSelectedDevice Thiết bị USB đã có sẵn (từ event connect hoặc navigator.usb.getDevices)
   */
  public async connect(preSelectedDevice?: USBDevice): Promise<void> {
    try {
      if (preSelectedDevice) {
        this.device = preSelectedDevice;
      } else {
        if (!navigator.usb) {
          throw new FastbootError('Trình duyệt hiện tại không hỗ trợ WebUSB API. Vui lòng dùng Chrome, Edge hoặc Brave trên PC.', 'WEBUSB_UNSUPPORTED');
        }
        // Kích hoạt hộp thoại cấp quyền trình duyệt nếu chưa có device handle
        this.device = await navigator.usb.requestDevice({
          filters: [FastbootDevice.FASTBOOT_FILTER],
        });
      }

      if (!this.device) {
        throw new FastbootError('Không có thiết bị USB nào được chọn.', 'NO_DEVICE');
      }

      // Mở thiết bị nếu chưa mở
      if (!this.device.opened) {
        await this.device.open();
      }

      // 1. Quản lý cấu hình (Configuration)
      if (this.device.configuration === null) {
        await this.device.selectConfiguration(1);
      }

      // 2. Quét Interface và Alternate Setting phù hợp với Fastboot
      let targetInterface: USBInterface | null = null;
      let targetAlternate: USBAlternateInterface | null = null;

      for (const iface of this.device.configuration!.interfaces) {
        for (const alt of iface.alternates) {
          if (
            alt.interfaceClass === FastbootDevice.FASTBOOT_FILTER.classCode &&
            alt.interfaceSubclass === FastbootDevice.FASTBOOT_FILTER.subclassCode &&
            alt.interfaceProtocol === FastbootDevice.FASTBOOT_FILTER.protocolCode
          ) {
            targetInterface = iface;
            targetAlternate = alt;
            break;
          }
        }
        if (targetInterface) break;
      }

      if (!targetInterface || !targetAlternate) {
        throw new FastbootError(
          'Không tìm thấy USB Interface hợp lệ mang định danh Fastboot Protocol (0xFF/0x42/0x03).',
          'INTERFACE_NOT_FOUND'
        );
      }

      this.interfaceNumber = targetInterface.interfaceNumber;

      // 3. Claim Interface để độc quyền kiểm soát bus dữ liệu
      await this.device.claimInterface(this.interfaceNumber);

      // Nếu alternate setting khác 0, gán rõ ràng
      if (targetInterface.alternate.alternateSetting !== targetAlternate.alternateSetting) {
        await this.device.selectAlternateInterface(
          this.interfaceNumber,
          targetAlternate.alternateSetting
        );
      }

      // 4. Định vị Endpoint IN (Device -> Host) và OUT (Host -> Device)
      for (const endpoint of targetAlternate.endpoints) {
        if (endpoint.direction === 'in') {
          this.endpointIn = endpoint.endpointNumber;
          this.maxPacketSize = endpoint.packetSize;
        } else if (endpoint.direction === 'out') {
          this.endpointOut = endpoint.endpointNumber;
        }
      }

      if (this.endpointIn === null || this.endpointOut === null) {
        throw new FastbootError(
          'Thiếu Endpoint IN hoặc OUT trên Interface Fastboot.',
          'ENDPOINT_MISSING'
        );
      }
    } catch (err: any) {
      await this.disconnect();
      if (err.name === 'NotFoundError') {
        throw new FastbootError('Người dùng đã đóng hộp thoại chọn thiết bị USB.', 'USER_CANCELLED');
      }
      if (err.name === 'SecurityError') {
        throw new FastbootError('Quyền truy cập WebUSB bị chặn bởi chính sách bảo mật trình duyệt.', 'SECURITY_RESTRICTION');
      }
      throw new FastbootError(`Kết nối Fastboot thất bại: ${err.message}`, 'CONNECT_FAILED');
    }
  }

  /**
   * Gửi chuỗi lệnh Fastboot và chờ đợi phản hồi hoàn chỉnh
   * @param command Lệnh Fastboot cần gửi (ví dụ: "getvar:version", "reboot", "flash:boot")
   * @param timeoutMs Giới hạn thời gian chờ phản hồi (mặc định 15 giây)
   */
  public async sendCommand(command: string, timeoutMs: number = 15000): Promise<FastbootResponse> {
    this.assertConnected();

    const infoMessages: string[] = [];
    const commandBytes = this.textEncoder.encode(command);

    // 1. Truyền lệnh thô ra Endpoint OUT
    try {
      const outResult = await this.device!.transferOut(this.endpointOut!, commandBytes);
      if (outResult.status !== 'ok') {
        throw new FastbootError(
          `Gửi dữ liệu qua Endpoint OUT thất bại: status = ${outResult.status}`,
          'TRANSFER_OUT_FAILED'
        );
      }
    } catch (err: any) {
      throw new FastbootError(`Lỗi USB khi gửi lệnh [${command}]: ${err.message}`, 'USB_TRANSFER_ERROR');
    }

    // 2. Vòng lặp nhận phản hồi từ Endpoint IN
    const startTime = Date.now();

    while (true) {
      if (Date.now() - startTime > timeoutMs) {
        throw new FastbootError(
          `Hết thời gian chờ phản hồi (${timeoutMs}ms) cho lệnh: ${command}`,
          'COMMAND_TIMEOUT'
        );
      }

      let inResult: USBInTransferResult;
      try {
        inResult = await this.device!.transferIn(this.endpointIn!, Math.max(512, this.maxPacketSize));
      } catch (err: any) {
        throw new FastbootError(`Mất kết nối hoặc lỗi bus USB khi đọc phản hồi: ${err.message}`, 'USB_READ_ERROR');
      }

      if (inResult.status !== 'ok' || !inResult.data || inResult.data.byteLength < 4) {
        throw new FastbootError('Gói tin phản hồi không hợp lệ hoặc rỗng từ thiết bị.', 'MALFORMED_RESPONSE');
      }

      const rawBytes = new Uint8Array(inResult.data.buffer, inResult.data.byteOffset, inResult.data.byteLength);
      const prefix = this.textDecoder.decode(rawBytes.subarray(0, 4));
      const message = this.textDecoder.decode(rawBytes.subarray(4)).trim();

      switch (prefix) {
        case 'INFO':
          infoMessages.push(message);
          break;

        case 'OKAY':
          return {
            status: 'OKAY',
            payload: message,
            infoMessages,
          };

        case 'FAIL':
          return {
            status: 'FAIL',
            payload: message || 'Lỗi không xác định từ bootloader',
            infoMessages,
          };

        case 'DATA': {
          const hexSize = message.slice(0, 8);
          const dataSize = parseInt(hexSize, 16);
          if (isNaN(dataSize) || dataSize < 0) {
            throw new FastbootError(`Giá trị kích thước gói DATA không hợp lệ: "${hexSize}"`, 'INVALID_DATA_SIZE');
          }
          return {
            status: 'DATA',
            payload: message,
            infoMessages,
            dataSize,
          };
        }

        default:
          throw new FastbootError(
            `Tiền tố phản hồi không đúng chuẩn Fastboot: "${prefix}" (Raw: "${this.textDecoder.decode(rawBytes)}")`,
            'PROTOCOL_VIOLATION'
          );
      }
    }
  }

  /**
   * Đọc biến hệ thống Fastboot (ví dụ: product, unlocked, current-slot, max-download-size)
   */
  public async getVariable(varName: string): Promise<string> {
    const res = await this.sendCommand(`getvar:${varName}`);
    if (res.status === 'OKAY') {
      return res.payload || (res.infoMessages.length > 0 ? res.infoMessages[0] : '');
    }
    throw new FastbootError(`Không đọc được biến ${varName}: ${res.payload}`, 'GETVAR_FAILED');
  }

  /**
   * Đọc toàn bộ biến hệ thống (getvar all)
   */
  public async getAllVariables(): Promise<Record<string, string>> {
    const res = await this.sendCommand('getvar:all');
    const vars: Record<string, string> = {};

    res.infoMessages.forEach((line) => {
      const colonIdx = line.indexOf(':');
      if (colonIdx !== -1) {
        const key = line.slice(0, colonIdx).trim();
        const value = line.slice(colonIdx + 1).trim();
        vars[key] = value;
      }
    });

    return vars;
  }

  /**
   * Đẩy khối dữ liệu nhị phân (raw binary payload) vào thiết bị khi nhận được trạng thái DATA
   * @param payload Dữ liệu phân đoạn (chunk buffer)
   * @param onProgress Callback thông báo số byte đã gửi
   */
  public async sendRawPayload(
    payload: Uint8Array,
    onProgress?: (bytesWritten: number, totalBytes: number) => void
  ): Promise<void> {
    this.assertConnected();

    const CHUNK_SIZE = 1024 * 1024; // 1MB chunking tối ưu bus USB
    let offset = 0;
    const total = payload.byteLength;

    while (offset < total) {
      const sliceEnd = Math.min(offset + CHUNK_SIZE, total);
      const chunk = payload.subarray(offset, sliceEnd);

      const result = await this.device!.transferOut(this.endpointOut!, chunk as BufferSource);
      if (result.status !== 'ok') {
        throw new FastbootError(
          `Gửi nhị phân gián đoạn tại offset ${offset}/${total} (status: ${result.status})`,
          'TRANSFER_OUT_STREAM_FAILED'
        );
      }

      offset = sliceEnd;
      if (onProgress) {
        onProgress(offset, total);
      }
    }
  }

  /**
   * Nạp dữ liệu vào một phân vùng (download + flash)
   * @param partition Tên phân vùng (boot, recovery, init_boot, vbmeta, super...)
   * @param data Dữ liệu Uint8Array
   * @param onProgress Tiến độ nạp
   */
  public async flashBuffer(
    partition: string,
    data: Uint8Array,
    onProgress?: (percent: number, bytesWritten: number, totalBytes: number) => void
  ): Promise<void> {
    this.assertConnected();

    // 1. Gửi lệnh download kèm kích thước hex 8 ký tự
    const hexSize = data.byteLength.toString(16).padStart(8, '0');
    const downloadRes = await this.sendCommand(`download:${hexSize}`);

    if (downloadRes.status !== 'DATA') {
      throw new FastbootError(`Bootloader từ chối nhận file: ${downloadRes.payload}`, 'DOWNLOAD_REJECTED');
    }

    // 2. Gửi raw payload
    await this.sendRawPayload(data, (sent, total) => {
      if (onProgress) {
        onProgress(Math.round((sent / total) * 100), sent, total);
      }
    });

    // 3. Đọc xác nhận hoàn tất tải
    const ackRes = await this.readPostPayloadResponse();
    if (ackRes.status !== 'OKAY') {
      throw new FastbootError(`Lỗi nạp buffer vào RAM thiết bị: ${ackRes.payload}`, 'BUFFER_ACK_FAILED');
    }

    // 4. Ghi phân vùng vào flash (flash:partition)
    const flashRes = await this.sendCommand(`flash:${partition}`, 60000); // 60s timeout cho flash chip
    if (flashRes.status !== 'OKAY') {
      throw new FastbootError(`Ghi phân vùng [${partition}] thất bại: ${flashRes.payload}`, 'FLASH_WRITE_FAILED');
    }
  }

  /**
   * Đọc gói phản hồi sau khi hoàn tất nạp payload nhị phân
   */
  public async readPostPayloadResponse(timeoutMs: number = 30000): Promise<FastbootResponse> {
    this.assertConnected();
    const infoMessages: string[] = [];
    const startTime = Date.now();

    while (true) {
      if (Date.now() - startTime > timeoutMs) {
        throw new FastbootError('Quá thời gian chờ phản hồi xác nhận sau khi nạp payload.', 'PAYLOAD_ACK_TIMEOUT');
      }

      const inResult = await this.device!.transferIn(this.endpointIn!, Math.max(512, this.maxPacketSize));
      if (!inResult.data || inResult.data.byteLength < 4) continue;

      const rawBytes = new Uint8Array(inResult.data.buffer, inResult.data.byteOffset, inResult.data.byteLength);
      const prefix = this.textDecoder.decode(rawBytes.subarray(0, 4));
      const message = this.textDecoder.decode(rawBytes.subarray(4)).trim();

      if (prefix === 'INFO') {
        infoMessages.push(message);
        continue;
      }

      if (prefix === 'OKAY' || prefix === 'FAIL') {
        return {
          status: prefix,
          payload: message,
          infoMessages,
        };
      }
    }
  }

  /**
   * Khởi động lại thiết bị từ Fastboot
   */
  public async reboot(target: 'bootloader' | 'recovery' | 'fastboot' | '' = ''): Promise<void> {
    this.assertConnected();
    const cmd = target ? `reboot-${target}` : 'reboot';
    await this.sendCommand(cmd);
    await this.disconnect();
  }

  /**
   * Giải phóng Interface và đóng kết nối WebUSB an toàn
   */
  public async disconnect(): Promise<void> {
    if (this.device && this.device.opened) {
      try {
        if (this.interfaceNumber !== null) {
          await this.device.releaseInterface(this.interfaceNumber);
        }
        await this.device.close();
      } catch {
        // Bỏ qua lỗi ngắt kết nối do rút cáp vật lý
      }
    }

    this.device = null;
    this.interfaceNumber = null;
    this.endpointIn = null;
    this.endpointOut = null;
  }

  public isConnected(): boolean {
    return Boolean(this.device && this.device.opened && this.endpointIn !== null && this.endpointOut !== null);
  }

  public getRawDevice(): USBDevice | null {
    return this.device;
  }

  private assertConnected(): void {
    if (!this.isConnected()) {
      throw new FastbootError('Thiết bị chưa được kết nối hoặc đã ngắt kết nối USB Fastboot.', 'NOT_CONNECTED');
    }
  }
}

// Singleton Fastboot instance
export const fastbootDriver = new FastbootDevice();
