/**
 * MagicTune - Device State Machine & Hardware Lifecycle Manager
 * Quản lý vòng đời trạng thái thiết bị giữa ADB, Fastboot và ngắt kết nối
 * Tự động chuyển đổi giao thức khi thực hiện lệnh Reboot to Bootloader
 */

import { adbDriver } from '@/lib/adb/web-usb-driver';
import { FastbootDevice, fastbootDriver } from './fastboot-controller';

export type DeviceLifecycleState =
  | 'DISCONNECTED'
  | 'ADB_MODE'
  | 'WAITING_FOR_FASTBOOT'
  | 'FASTBOOT_MODE'
  | 'ERROR_STATE';

export interface DeviceStateEvent {
  state: DeviceLifecycleState;
  previousState: DeviceLifecycleState;
  device?: USBDevice;
  message?: string;
  error?: Error;
}

export type StateChangeCallback = (event: DeviceStateEvent) => void;

export class DeviceStateManager {
  private currentState: DeviceLifecycleState = 'DISCONNECTED';
  private listeners: Set<StateChangeCallback> = new Set();
  private fastbootWaitTimer: NodeJS.Timeout | null = null;
  private isListeningUsb: boolean = false;

  private onFastbootFoundResolve: ((device: USBDevice) => void) | null = null;
  private onFastbootFoundReject: ((error: Error) => void) | null = null;

  constructor() {
    this.initGlobalUsbListeners();
  }

  /**
   * Khởi tạo các listener toàn cục trên navigator.usb
   */
  private initGlobalUsbListeners(): void {
    if (typeof window === 'undefined' || !navigator.usb) return;
    if (this.isListeningUsb) return;

    this.isListeningUsb = true;

    // Lắng nghe sự kiện thiết bị cắm vào cổng USB
    navigator.usb.addEventListener('connect', async (event: USBConnectionEvent) => {
      await this.handleUsbDeviceConnected(event.device);
    });

    // Lắng nghe sự kiện thiết bị bị rút khỏi cổng USB
    navigator.usb.addEventListener('disconnect', (event: USBConnectionEvent) => {
      this.handleUsbDeviceDisconnected(event.device);
    });
  }

  /**
   * Xử lý khi thiết bị USB vừa được cắm vào hoặc khởi động lại
   */
  private async handleUsbDeviceConnected(device: USBDevice): Promise<void> {
    const isFastboot = this.isFastbootDevice(device);

    if (this.currentState === 'WAITING_FOR_FASTBOOT') {
      if (isFastboot) {
        // Hủy bộ đếm timeout 30 giây
        this.clearFastbootTimer();

        try {
          // Tự động kết nối và claim interface Fastboot
          await fastbootDriver.connect(device);
          this.transitionTo('FASTBOOT_MODE', {
            device,
            message: `Đã phát hiện và kết nối thành công với thiết bị Fastboot (${device.productName || 'Android Bootloader'})`,
          });

          if (this.onFastbootFoundResolve) {
            this.onFastbootFoundResolve(device);
            this.onFastbootFoundResolve = null;
            this.onFastbootFoundReject = null;
          }
        } catch (err: any) {
          this.transitionTo('ERROR_STATE', {
            device,
            error: err,
            message: `Lỗi kết nối interface Fastboot: ${err.message}`,
          });
          if (this.onFastbootFoundReject) {
            this.onFastbootFoundReject(err);
            this.onFastbootFoundResolve = null;
            this.onFastbootFoundReject = null;
          }
        }
      }
      return;
    }

    // Trường hợp kết nối thông thường
    if (isFastboot) {
      this.transitionTo('FASTBOOT_MODE', { device, message: 'Thiết bị Fastboot đã sẵn sàng.' });
    } else {
      // Có thể là thiết bị ADB
      if (adbDriver.getState().connectionState === 'connected') {
        this.transitionTo('ADB_MODE', { device, message: 'Thiết bị ADB đang kết nối.' });
      }
    }
  }

  /**
   * Xử lý khi thiết bị USB bị ngắt kết nối
   */
  private handleUsbDeviceDisconnected(device: USBDevice): void {
    if (this.currentState === 'WAITING_FOR_FASTBOOT') {
      // Khi đang chờ khởi động lại vào Bootloader, sự kiện ngắt kết nối là hoàn toàn bình thường
      // Ta không chuyển sang DISCONNECTED mà tiếp tục giữ WAITING_FOR_FASTBOOT cho đến khi thiết bị cắm lại
      return;
    }

    if (this.currentState === 'FASTBOOT_MODE') {
      fastbootDriver.disconnect().catch(() => {});
      this.transitionTo('DISCONNECTED', {
        device,
        message: 'Thiết bị Fastboot đã ngắt kết nối USB.',
      });
      return;
    }

    if (this.currentState === 'ADB_MODE') {
      this.transitionTo('DISCONNECTED', {
        device,
        message: 'Thiết bị ADB đã ngắt kết nối USB.',
      });
      return;
    }

    this.transitionTo('DISCONNECTED', { device, message: 'Thiết bị đã ngắt kết nối.' });
  }

  /**
   * Kiểm tra thông số USB Descriptor xem có phải giao thức Fastboot không
   */
  public isFastbootDevice(device: USBDevice): boolean {
    if (!device.configuration) return false;
    for (const iface of device.configuration.interfaces) {
      for (const alt of iface.alternates) {
        if (
          alt.interfaceClass === FastbootDevice.FASTBOOT_FILTER.classCode &&
          alt.interfaceSubclass === FastbootDevice.FASTBOOT_FILTER.subclassCode &&
          alt.interfaceProtocol === FastbootDevice.FASTBOOT_FILTER.protocolCode
        ) {
          return true;
        }
      }
    }
    return false;
  }

  /**
   * Phương thức chuyên biệt: Gửi lệnh Reboot Bootloader qua ADB và tự động bắt chuyển đổi sang Fastboot Mode
   *
   * @param timeoutSeconds Thời gian tối đa chờ thiết bị vào Fastboot (mặc định 30 giây)
   */
  public async rebootToBootloader(timeoutSeconds: number = 30): Promise<FastbootDevice> {
    // 1. Kiểm tra trạng thái ADB hiện tại
    if (adbDriver.getState().connectionState !== 'connected') {
      throw new Error('Cần kết nối thiết bị qua cổng ADB trước khi gửi lệnh chuyển sang Bootloader.');
    }

    // 2. Chuyển trạng thái sang WAITING_FOR_FASTBOOT
    this.transitionTo('WAITING_FOR_FASTBOOT', {
      message: `Đang gửi lệnh khởi động lại vào Bootloader... Vui lòng giữ cáp kết nối (Thời gian chờ: ${timeoutSeconds}s).`,
    });

    // 3. Khởi tạo Promise và kích hoạt bộ đếm thời gian Timeout
    const fastbootPromise = new Promise<USBDevice>((resolve, reject) => {
      this.onFastbootFoundResolve = resolve;
      this.onFastbootFoundReject = reject;

      this.fastbootWaitTimer = setTimeout(() => {
        this.clearFastbootTimer();
        const timeoutErr = new Error(
          `Hết thời gian chờ (${timeoutSeconds}s): Không phát hiện thiết bị khởi động lại vào chế độ Fastboot. Vui lòng kiểm tra lại cáp hoặc driver USB.`
        );
        this.transitionTo('ERROR_STATE', {
          error: timeoutErr,
          message: timeoutErr.message,
        });
        if (this.onFastbootFoundReject) {
          this.onFastbootFoundReject(timeoutErr);
          this.onFastbootFoundResolve = null;
          this.onFastbootFoundReject = null;
        }
      }, timeoutSeconds * 1000);
    });

    // 4. Gửi lệnh qua ADB
    try {
      await adbDriver.executeCommand('reboot bootloader');
    } catch (err: any) {
      // Một số máy ngắt bus USB ngay tức thì trước khi adb phản hồi 'Rebooting'
      console.warn('Lệnh reboot bootloader ngắt kết nối USB nhanh hơn phản hồi:', err);
    }

    // Đợi thiết bị ngắt kết nối và nhận diện lại qua WebUSB connect event
    await fastbootPromise;

    return fastbootDriver;
  }

  /**
   * Đăng ký lắng nghe thay đổi trạng thái
   */
  public onStateChange(callback: StateChangeCallback): () => void {
    this.listeners.add(callback);
    // Bắn trạng thái hiện tại ngay khi đăng ký
    callback({
      state: this.currentState,
      previousState: this.currentState,
      message: 'Đăng ký theo dõi trạng thái thiết bị thành công.',
    });

    return () => {
      this.listeners.delete(callback);
    };
  }

  /**
   * Chuyển trạng thái nội bộ và thông báo cho toàn bộ subscribers
   */
  private transitionTo(
    newState: DeviceLifecycleState,
    details: { device?: USBDevice; message?: string; error?: Error } = {}
  ): void {
    const previousState = this.currentState;
    this.currentState = newState;

    const event: DeviceStateEvent = {
      state: newState,
      previousState,
      device: details.device,
      message: details.message,
      error: details.error,
    };

    this.listeners.forEach((listener) => {
      try {
        listener(event);
      } catch (e) {
        console.error('Lỗi listener trong DeviceStateManager:', e);
      }
    });
  }

  private clearFastbootTimer(): void {
    if (this.fastbootWaitTimer) {
      clearTimeout(this.fastbootWaitTimer);
      this.fastbootWaitTimer = null;
    }
  }

  public getState(): DeviceLifecycleState {
    return this.currentState;
  }

  public setAdbConnected(device?: USBDevice): void {
    this.transitionTo('ADB_MODE', { device, message: 'Đã kết nối qua ADB.' });
  }

  public setDisconnected(): void {
    this.clearFastbootTimer();
    this.transitionTo('DISCONNECTED', { message: 'Đã ngắt kết nối.' });
  }
}

// Singleton State Manager
export const deviceStateManager = new DeviceStateManager();
