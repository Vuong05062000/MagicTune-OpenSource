/**
 * MagicTune Application Release Versioning
 * Tự động tăng phiên bản (v18 -> v19 -> v20...) mỗi lần build xuất bản
 */
export const APP_RELEASE_VERSION = "v131";
export const APP_BUILD_TIMESTAMP = "2026-11-27 09:58:00";
