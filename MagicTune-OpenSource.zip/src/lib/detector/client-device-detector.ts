/**
 * MagicTune - Bộ Nhận Diện Thiết Bị Khách Thông Minh (Client Browser Device Detector)
 * Tự động phát hiện chính xác Hãng, Dòng máy và Hệ điều hành khi người dùng truy cập web bằng điện thoại
 * Giúp tăng 100% độ uy tín, chuyên nghiệp và tạo sự tin tưởng tuyệt đối ngay từ lần đầu truy cập!
 */

export interface DetectedClientDevice {
  brand: 'HONOR' | 'HUAWEI' | 'XIAOMI' | 'SAMSUNG' | 'VIVO' | 'OPPO' | 'REALME' | 'ONEPLUS' | 'GOOGLE' | 'SONY' | 'APPLE' | 'ANDROID_GENERIC' | 'PC';
  brandName: string;
  modelName: string;
  osName: string;
  osVersion: string;
  isMobile: boolean;
  gpuRenderer?: string;
  brandColor: string;
  brandBadge: string;
  recommendation: string;
}

export async function detectClientDevice(): Promise<DetectedClientDevice> {
  if (typeof window === 'undefined') {
    return {
      brand: 'ANDROID_GENERIC',
      brandName: 'Android Device',
      modelName: 'Thiết Bị Android',
      osName: 'Android OS',
      osVersion: 'Android',
      isMobile: true,
      brandColor: '#00F0FF',
      brandBadge: 'Android',
      recommendation: 'Hệ thống đã sẵn sàng kịch bản tối ưu hóa thông báo và pin cho thiết bị của bạn.'
    };
  }

  const ua = navigator.userAgent || '';
  const isDesktopOS = /Windows NT|Macintosh|Mac OS X|Linux x86_64|X11|CrOS/i.test(ua) && !/Android|iPhone|iPod|iPad|Mobile/i.test(ua);

  // 1. Nếu là máy tính PC/Laptop
  if (isDesktopOS) {
    let pcOs = 'Máy Tính (PC/Laptop)';
    if (/Windows/i.test(ua)) pcOs = 'Windows PC';
    else if (/Macintosh|Mac OS/i.test(ua)) pcOs = 'Apple Mac';
    else if (/Linux/i.test(ua)) pcOs = 'Linux PC';

    return {
      brand: 'PC',
      brandName: pcOs,
      modelName: 'Máy Tính Điều Khiển',
      osName: pcOs,
      osVersion: 'Desktop Environment',
      isMobile: false,
      brandColor: '#38BDF8',
      brandBadge: 'Trạm Máy Tính',
      recommendation: 'Tuyệt vời! Kết nối cáp USB với điện thoại Android để thực thi toàn bộ quyền hạn cao nhất.'
    };
  }

  // 2. Thử truy xuất Client Hints API (Chromium Android) để lấy Model phần cứng chính xác
  let rawModel = '';
  try {
    const navAny = navigator as any;
    if (navAny.userAgentData && typeof navAny.userAgentData.getHighEntropyValues === 'function') {
      const entropy = await navAny.userAgentData.getHighEntropyValues(['model', 'platform', 'platformVersion']);
      if (entropy && entropy.model) {
        rawModel = entropy.model;
      }
    }
  } catch (e) {
    // Không hỗ trợ Client Hints, dùng UserAgent fallback
  }

  // 3. Phân tích UserAgent chuỗi
  const fullScan = `${ua} ${rawModel}`.toUpperCase();

  // Đọc Android Version
  let androidVer = 'Android';
  const verMatch = ua.match(/Android\s+([0-9.]+)/i);
  if (verMatch) {
    androidVer = `Android ${verMatch[1]}`;
  }

  // Thử đọc GPU WebGL để đoán chipset
  let gpuInfo = '';
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
    if (gl) {
      const debugInfo = (gl as any).getExtension('WEBGL_debug_renderer_info');
      if (debugInfo) {
        gpuInfo = (gl as any).getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) || '';
      }
    }
  } catch (e) {}

  // 4. BỘ NHẬN DIỆN THƯƠNG HIỆU THÔNG MINH (BRAND RESOLUTION)

  // === HONOR ===
  if (
    fullScan.includes('HONOR') ||
    fullScan.includes('HMA-') ||
    fullScan.includes('BVL-') ||
    fullScan.includes('PGT-') ||
    fullScan.includes('FRI-') ||
    fullScan.includes('ANY-') ||
    fullScan.includes('ELP-') ||
    fullScan.includes('FCP-') ||
    fullScan.includes('RMO-') ||
    fullScan.includes('WKG-') ||
    fullScan.includes('CLK-') ||
    fullScan.includes('VER-')
  ) {
    let friendlyModel = 'Honor Magic / X Series';
    if (fullScan.includes('BVL')) friendlyModel = 'Honor Magic6 Series';
    else if (fullScan.includes('PGT')) friendlyModel = 'Honor Magic5 Series';
    else if (fullScan.includes('FRI')) friendlyModel = 'Honor 90 / 200 Series';
    else if (fullScan.includes('VER')) friendlyModel = 'Honor Magic V2 / V3';
    else if (rawModel) friendlyModel = `Honor ${rawModel}`;

    return {
      brand: 'HONOR',
      brandName: 'Honor',
      modelName: friendlyModel,
      osName: 'MagicOS (Android)',
      osVersion: androidVer,
      isMobile: true,
      gpuRenderer: gpuInfo,
      brandColor: '#00F0FF',
      brandBadge: 'MagicOS Chuyên Biệt',
      recommendation: 'Hệ thống đã nhận diện điện thoại Honor của bạn! Đã chuẩn bị kịch bản bẻ khóa PowerGenie & Bastet Service giúp Zalo, Messenger, Gmail nổ chuông tức thì 0s.'
    };
  }

  // === HUAWEI ===
  if (fullScan.includes('HUAWEI') || fullScan.includes('HARMONYOS') || fullScan.includes('ALN-') || fullScan.includes('BRA-') || fullScan.includes('NOH-')) {
    return {
      brand: 'HUAWEI',
      brandName: 'Huawei',
      modelName: rawModel ? `Huawei ${rawModel}` : 'Huawei Mate / P Series',
      osName: 'HarmonyOS / EMUI',
      osVersion: androidVer,
      isMobile: true,
      gpuRenderer: gpuInfo,
      brandColor: '#EF4444',
      brandBadge: 'HarmonyOS & EMUI',
      recommendation: 'Phát hiện thiết bị Huawei! Hệ thống đã sẵn sàng kịch bản cài đặt Google GMS và khắc phục trễ thông báo triệt để.'
    };
  }

  // === XIAOMI / REDMI / POCO ===
  if (
    fullScan.includes('XIAOMI') ||
    fullScan.includes('REDMI') ||
    fullScan.includes('POCO') ||
    fullScan.includes('23116PN5BC') ||
    fullScan.includes('24031PN0DC') ||
    fullScan.includes('2210132C') ||
    fullScan.includes('23127PN0CC') ||
    fullScan.includes('M20') ||
    fullScan.includes('M21')
  ) {
    let xName = 'Xiaomi / Redmi';
    if (fullScan.includes('POCO')) xName = 'POCO Phone';
    else if (fullScan.includes('REDMI')) xName = 'Redmi Phone';
    else if (rawModel) xName = `Xiaomi ${rawModel}`;

    return {
      brand: 'XIAOMI',
      brandName: 'Xiaomi',
      modelName: xName,
      osName: 'Xiaomi HyperOS / MIUI',
      osVersion: androidVer,
      isMobile: true,
      gpuRenderer: gpuInfo,
      brandColor: '#FF6900',
      brandBadge: 'HyperOS / MIUI',
      recommendation: 'Hệ thống đã nhận diện điện thoại Xiaomi của bạn! Đã chuẩn bị kịch bản chống đóng băng tiến trình ngầm và bỏ qua hạn chế pin MIUI.'
    };
  }

  // === SAMSUNG ===
  if (fullScan.includes('SAMSUNG') || fullScan.includes('SM-') || fullScan.includes('GALAXY')) {
    let sModel = 'Samsung Galaxy';
    if (fullScan.includes('SM-S928')) sModel = 'Galaxy S24 Ultra';
    else if (fullScan.includes('SM-S918')) sModel = 'Galaxy S23 Ultra';
    else if (fullScan.includes('SM-F946') || fullScan.includes('SM-F956')) sModel = 'Galaxy Z Fold Series';
    else if (rawModel) sModel = `Samsung ${rawModel}`;

    return {
      brand: 'SAMSUNG',
      brandName: 'Samsung',
      modelName: sModel,
      osName: 'Samsung One UI',
      osVersion: androidVer,
      isMobile: true,
      gpuRenderer: gpuInfo,
      brandColor: '#2563EB',
      brandBadge: 'One UI Tối Ưu',
      recommendation: 'Phát hiện thiết bị Samsung Galaxy! Đã sẵn sàng bộ công cụ tối ưu hóa tần số quét màn hình và ngăn One UI đưa app vào Deep Sleep.'
    };
  }

  // === VIVO / IQOO ===
  if (fullScan.includes('VIVO') || fullScan.includes('IQOO') || fullScan.includes('V23') || fullScan.includes('V22') || fullScan.includes('V24')) {
    let vName = 'Vivo / iQOO';
    if (fullScan.includes('IQOO')) vName = 'iQOO Flagship';
    else if (rawModel) vName = `Vivo ${rawModel}`;

    return {
      brand: 'VIVO',
      brandName: 'Vivo / iQOO',
      modelName: vName,
      osName: 'OriginOS / Funtouch OS',
      osVersion: androidVer,
      isMobile: true,
      gpuRenderer: gpuInfo,
      brandColor: '#415FFF',
      brandBadge: 'OriginOS Chuyên Sâu',
      recommendation: 'Hệ thống đã nhận diện điện thoại Vivo / iQOO của bạn! Đã sẵn sàng kịch bản mở khóa quyền tự khởi chạy và fix trễ thông báo OriginOS nội địa.'
    };
  }

  // === OPPO / REALME / ONEPLUS ===
  if (
    fullScan.includes('OPPO') ||
    fullScan.includes('REALME') ||
    fullScan.includes('ONEPLUS') ||
    fullScan.includes('CPH') ||
    fullScan.includes('RMX') ||
    fullScan.includes('PGF') ||
    fullScan.includes('PGU')
  ) {
    let oName = 'Oppo / OnePlus / Realme';
    if (fullScan.includes('ONEPLUS')) oName = 'OnePlus Flagship';
    else if (fullScan.includes('REALME')) oName = 'Realme Phone';
    else if (rawModel) oName = `Oppo ${rawModel}`;

    return {
      brand: 'OPPO',
      brandName: 'Oppo / OnePlus',
      modelName: oName,
      osName: 'ColorOS / OxygenOS',
      osVersion: androidVer,
      isMobile: true,
      gpuRenderer: gpuInfo,
      brandColor: '#10B981',
      brandBadge: 'ColorOS Tối Ưu',
      recommendation: 'Phát hiện thiết bị Oppo / Realme / OnePlus! Đã nạp sẵn kịch bản mở khóa AppOps và đưa app vào danh sách không bị đóng băng trên ColorOS.'
    };
  }

  // === GOOGLE PIXEL ===
  if (fullScan.includes('PIXEL')) {
    return {
      brand: 'GOOGLE',
      brandName: 'Google Pixel',
      modelName: rawModel || 'Google Pixel Phone',
      osName: 'Pixel Stock Android',
      osVersion: androidVer,
      isMobile: true,
      gpuRenderer: gpuInfo,
      brandColor: '#34A853',
      brandBadge: 'Google Pixel',
      recommendation: 'Thiết bị Google Pixel thuần khiết! Sẵn sàng các công cụ tinh chỉnh hệ thống và nạp firmware Fastboot an toàn.'
    };
  }

  // === IPHONE / IPAD ===
  if (/iPhone|iPad|iPod/i.test(ua)) {
    return {
      brand: 'APPLE',
      brandName: 'Apple iOS',
      modelName: /iPad/i.test(ua) ? 'Apple iPad' : 'Apple iPhone',
      osName: 'iOS Environment',
      osVersion: 'iOS Safari',
      isMobile: true,
      brandColor: '#A855F7',
      brandBadge: 'Apple iOS',
      recommendation: 'Bạn đang truy cập từ iPhone/iPad! Để can thiệp vào máy Android, vui lòng mở trang web trên Máy tính (PC/Laptop) hoặc dùng trực tiếp trên điện thoại Android.'
    };
  }

  // MẶC ĐỊNH ANDROID KHÁC
  return {
    brand: 'ANDROID_GENERIC',
    brandName: rawModel ? `Android (${rawModel})` : 'Android Phone',
    modelName: rawModel || 'Điện Thoại Android',
    osName: 'Android OS',
    osVersion: androidVer,
    isMobile: true,
    gpuRenderer: gpuInfo,
    brandColor: '#00F0FF',
    brandBadge: 'Android Thông Minh',
    recommendation: 'Hệ thống đã nhận diện thiết bị Android của bạn và sẵn sàng bộ công cụ tối ưu hóa chuyên sâu.'
  };
}
