/**
 * MagicTune - MagicOS All-in-One Utility Platform
 * Danh mục tập lệnh ADB chuyên sâu cho Honor & MagicOS (từ 7.0 đến 11+)
 * Tối ưu hóa đặc thù cho máy xách tay nội địa Trung Quốc (China ROM) dùng tại Việt Nam
 */

import { PipelineCommandItem } from './web-usb-driver';

export interface DeviceProfiler {
  model: string;
  marketName: string;
  magicosVersion: string;
  androidVersion: string;
  region: 'CN' | 'GLOBAL_EEA' | 'GLOBAL_MEAF' | 'GLOBAL_LA' | 'UNKNOWN';
  chipset: 'Snapdragon' | 'MediaTek' | 'Kirin' | 'Unknown';
  batteryLevel: number | null;
  batteryTemp: number | null;
  gmsInstalled: boolean;
  powerGenieStatus: 'enabled' | 'disabled' | 'not_found';
  bastetStatus: 'enabled' | 'disabled' | 'not_found';
  shizukuInstalled: boolean;
  currentDensity: number | null;
  currentRefreshRate: number | null;
}

export interface AppPackageInfo {
  id: string;
  package: string;
  name: string;
  icon?: string;
  isImportant?: boolean;
  category?: string;
  appType: 'user' | 'system';
  isGoogle?: boolean;
}

export const COMMONLY_USED_VN_APPS: AppPackageInfo[] = [
  { id: 'facebook', name: 'Facebook', package: 'com.facebook.katana', icon: 'Facebook', isImportant: true, appType: 'user', category: 'Mạng xã hội' },
  { id: 'messenger', name: 'Messenger', package: 'com.facebook.orca', icon: 'MessageSquare', isImportant: true, appType: 'user', category: 'Nhắn tin OTT' },
  { id: 'zalo', name: 'Zalo', package: 'com.zing.zalo', icon: 'MessageCircle', isImportant: true, appType: 'user', category: 'Nhắn tin OTT' },
  { id: 'gmail', name: 'Gmail', package: 'com.google.android.gm', icon: 'Mail', isImportant: true, appType: 'user', isGoogle: true, category: 'Email & Google' },
  { id: 'telegram', name: 'Telegram', package: 'org.telegram.messenger', icon: 'Send', isImportant: true, appType: 'user', category: 'Nhắn tin OTT' },
  { id: 'telegram_x', name: 'Telegram X (TDLib)', package: 'org.thunderdog.challegram', icon: 'Send', isImportant: true, appType: 'user', category: 'Nhắn tin OTT' },
  { id: 'gms', name: 'Google Play Services (FCM Push)', package: 'com.google.android.gms', icon: 'Shield', isImportant: true, appType: 'user', isGoogle: true, category: 'Dịch vụ lõi Google' },
  { id: 'shopee', name: 'Shopee', package: 'com.shopee.vn', icon: 'ShoppingBag', isImportant: false, appType: 'user', category: 'Mua sắm' },
  { id: 'tiktok', name: 'TikTok', package: 'com.zhiliaoapp.musically', icon: 'Video', isImportant: false, appType: 'user', category: 'Mạng xã hội' },
  { id: 'teams', name: 'MS Teams', package: 'com.microsoft.teams', icon: 'Users', isImportant: false, appType: 'user', category: 'Công việc' },
  { id: 'outlook', name: 'MS Outlook', package: 'com.microsoft.office.outlook', icon: 'Mail', isImportant: false, appType: 'user', category: 'Email' },
  { id: 'discord', name: 'Discord', package: 'com.discord', icon: 'Headphones', isImportant: false, appType: 'user', category: 'Cộng đồng' },
  { id: 'whatsapp', name: 'WhatsApp', package: 'com.whatsapp', icon: 'Phone', isImportant: false, appType: 'user', category: 'Nhắn tin OTT' },
  { id: 'viber', name: 'Viber', package: 'com.viber.voip', icon: 'PhoneCall', isImportant: false, appType: 'user', category: 'Nhắn tin OTT' }
];

export function getFriendlyAppName(pkg: string): string {
  const found = COMMONLY_USED_VN_APPS.find((a) => a.package === pkg);
  if (found) return found.name;
  if (pkg === 'com.google.android.gms') return 'Google Play Services';
  if (pkg === 'com.google.android.gsf') return 'Google Services Framework';
  if (pkg === 'com.google.android.gm') return 'Gmail';
  if (pkg === 'com.facebook.katana') return 'Facebook';
  if (pkg === 'com.facebook.orca') return 'Messenger';
  if (pkg === 'com.facebook.services') return 'Facebook Background Services';
  if (pkg === 'com.facebook.system') return 'Facebook System Service';
  if (pkg === 'com.facebook.appmanager') return 'Facebook App Manager';
  if (pkg === 'org.telegram.messenger') return 'Telegram Official';
  if (pkg === 'org.telegram.messenger.web') return 'Telegram Web';
  if (pkg === 'org.telegram.plus') return 'Telegram Plus';
  if (pkg === 'org.thunderdog.challegram') return 'Telegram X';
  if (pkg === 'com.zing.zalo') return 'Zalo';
  if (pkg.startsWith('com.google.android.')) {
    const sub = pkg.replace('com.google.android.', '');
    return `Google ${sub.charAt(0).toUpperCase() + sub.slice(1)}`;
  }
  const parts = pkg.split('.');
  const last = parts[parts.length - 1];
  return last.charAt(0).toUpperCase() + last.slice(1);
}

export class HonorAdbScripts {
  static getDeviceInfoCommands(): string[] {
    return [
      'getprop ro.product.model',
      'getprop ro.config.marketing_name',
      'getprop ro.build.version.magic',
      'getprop ro.build.display.id',
      'getprop ro.build.version.release',
      'getprop ro.product.device',
      'getprop ro.board.platform',
      'getprop ro.hardware',
      'getprop ro.product.locale',
      'getprop ro.boot.hwc',
      'dumpsys battery | grep -E "level|temperature"',
      'pm list packages | grep com.google.android.gms',
      'pm list packages | grep moe.shizuku.privileged.api',
      'pm list packages -d | grep powergenie',
      'pm list packages -d | grep bastet',
      'wm density',
      'settings get system peak_refresh_rate'
    ];
  }

  static getScanInstalledAppsCommand(): string {
    // Quét phân loại 2 nhóm: Ứng dụng người dùng (3rd-party + Google) và Ứng dụng hệ thống nội địa
    return 'echo "===USER_PKGS==="; pm list packages -3; echo "===GOOGLE_PKGS==="; pm list packages com.google.android.gms; pm list packages com.google.android.gsf; pm list packages com.google.android.gm; pm list packages com.android.vending; echo "===SYSTEM_PKGS==="; pm list packages -s; echo "===END_PKGS===";';
  }

  /**
   * SIÊU KỊCH BẢN MASTER TỔNG LỰC: 1-CHẠM FIX TẤT CẢ 0 GIÂY TOÀN DIỆN (ALL-IN-ONE SUPER PUSH PIPELINE)
   * Khắc phục 100% mọi vấn đề: Facebook, Zalo, Gmail, Telegram/Telegram X, WhatsApp & Toàn bộ Ngân hàng VN
   * 
   * CÁC NGUYÊN TẮC AN TOÀN TUYỆT ĐỐI (TRÁNH XUNG ĐỘT GÂY TRỄ/LỘN XỘN THÔNG BÁO):
   * 1. KHÔNG BAO GIỜ set app_standby_enabled 1 (luôn luôn khóa = 0).
   * 2. KHÔNG BAO GIỜ gọi pm trim-caches (tránh làm vỡ chỉ mục SQLite tin nhắn của Facebook).
   * 3. Đồng bộ chuẩn giờ quốc tế (auto_time 1, auto_time_zone 1, pool.ntp.org) để FB xếp đúng thứ tự thời gian.
   * 4. KHÔNG BAO GIỜ gọi am start-foreground-service vào các package ngoài (tránh crash process).
   * 5. Chỉ dùng broadcast đánh thức an toàn (ACTION_FB_PUSH_WAKE, GCM_RECONNECT, CONNECTIVITY_CHANGE).
   * 6. Cưỡng chế 15 đặc quyền AppOps + Standby Bucket ACTIVE + Doze Whitelist + NetPolicy + Importance Level 4.
   * 7. Giữ kết nối Wi-Fi/4G luôn thức 24/7 và đóng băng vĩnh viễn Bastet / PowerGenie.
   * 8. Cấu hình giữ thông báo màn hình khóa và kích hoạt Lịch sử thông báo 24h của Android.
   */
  static buildMasterAllInOnePushPipeline(
    selectedOrInstalledPackages: string[] = [],
    brandId?: string
  ): PipelineCommandItem[] {
    const commands: PipelineCommandItem[] = [];

    // Lớp 1: Dập tắt toàn bộ Daemon diệt tiến trình ngầm độc quyền (Bastet / PowerGenie / Joyose)
    let killerCmd = 'pm disable-user --user 0 com.hihonor.bastet.service 2>/dev/null; pm disable-user --user 0 com.hihonor.bastet 2>/dev/null; pm disable-user --user 0 com.hihonor.powergenie 2>/dev/null; pm disable-user --user 0 com.huawei.powergenie 2>/dev/null; pm disable-user --user 0 com.hihonor.android.pgm 2>/dev/null; pm disable-user --user 0 com.hihonor.logupload 2>/dev/null; pm disable-user --user 0 com.hihonor.analytics 2>/dev/null; settings put global bastet_service_enable 0 2>/dev/null; settings put system bastet_service_enable 0 2>/dev/null';
    if (brandId === 'xiaomi') {
      killerCmd += '; pm disable-user --user 0 com.xiaomi.joyose 2>/dev/null; pm disable-user --user 0 com.miui.powerkeeper 2>/dev/null';
    } else if (brandId === 'samsung') {
      killerCmd += '; pm disable-user --user 0 com.samsung.android.game.gos 2>/dev/null';
    } else if (brandId === 'oppo_realme_oneplus') {
      killerCmd += '; pm disable-user --user 0 com.oppo.qualityprotect 2>/dev/null; pm disable-user --user 0 com.heytap.mcs 2>/dev/null';
    } else if (brandId === 'vivo_iqoo') {
      killerCmd += '; pm disable-user --user 0 com.vivo.daemonService 2>/dev/null';
    }
    killerCmd += '; echo "SUCCESS:DAEMONS"';

    commands.push({
      cmd: killerCmd,
      label: 'Lớp 1: Dập tắt toàn bộ daemon diệt tiến trình ngầm độc quyền (Bastet / PowerGenie)',
      category: 'Hệ thống'
    });

    // Lớp 2: Khóa Mạng Wi-Fi/4G 24/7, Chuẩn hóa Đồng hồ NTP & Tự động đồng bộ GMS
    commands.push({
      cmd: 'settings put global wifi_sleep_policy 2 2>/dev/null; settings put global mobile_data_always_on 1 2>/dev/null; settings put global app_standby_enabled 0 2>/dev/null; settings put global forced_app_standby_enabled 0 2>/dev/null; settings put global smart_power_management 0 2>/dev/null; settings put secure sleep_mode 0 2>/dev/null; settings put system super_power_save 0 2>/dev/null; settings put global auto_sync 1 2>/dev/null; settings put global master_sync_automatically 1 2>/dev/null; cmd account set-sync-automatically --user 0 true 2>/dev/null; cmd account set-sync-automatically --user 0 --account-type com.google true 2>/dev/null; settings put global auto_time 1 2>/dev/null; settings put global auto_time_zone 1 2>/dev/null; settings put global ntp_server pool.ntp.org 2>/dev/null; echo "SUCCESS:NETWORK_NTP_SYNC"',
      label: 'Lớp 2: Khóa mạng Wi-Fi/4G luôn thức 24/7, Chuẩn hóa đồng hồ NTP & Tự động đồng bộ Google',
      category: 'Mạng & Đồng bộ'
    });

    // Lớp 3: Cố định thông báo Màn hình khóa, Triệt tiêu Thông Báo Nhẹ Nhàng (Gentle) & Bật Toàn Bộ Biểu Ngữ (Heads-Up Banner)
    commands.push({
      cmd: 'settings put secure lock_screen_show_notifications 1 2>/dev/null; settings put secure lock_screen_allow_private_notifications 1 2>/dev/null; settings put secure show_notification_details_on_lockscreen 1 2>/dev/null; settings put system lockscreen_notifications_keep 1 2>/dev/null; settings put secure lock_screen_notification_style 0 2>/dev/null; settings put secure notification_history_enabled 1 2>/dev/null; settings put secure notification_badging 1 2>/dev/null; settings put global heads_up_notifications_enabled 1 2>/dev/null; settings put secure heads_up_notifications_enabled 1 2>/dev/null; settings put system heads_up_notifications_enabled 1 2>/dev/null; settings put global notification_bubbles 1 2>/dev/null; settings put secure notification_bubbles 1 2>/dev/null; echo "SUCCESS:LOCKSCREEN_BANNERS"',
      label: 'Lớp 3: Cố định màn hình khóa, Tắt thông báo nhẹ nhàng & Bật đầy đủ Biểu ngữ (Banners) + Bong bóng',
      category: 'Màn hình & Biểu ngữ'
    });

    // Gom danh sách tất cả ứng dụng trọng yếu thiết yếu
    const defaultCoreApps = [
      // Meta & Mạng xã hội
      'com.facebook.katana',
      'com.facebook.orca',
      'com.facebook.services',
      'com.instagram.android',
      // OTT Nhắn tin gọi điện
      'com.zing.zalo',
      'org.telegram.messenger',
      'org.thunderdog.challegram',
      'com.whatsapp',
      'com.viber.voip',
      'com.google.android.gm',
      'com.google.android.gms',
      'com.google.android.gsf',
      // Toàn bộ Ngân hàng Việt Nam & Ví điện tử
      'com.VCB',
      'com.mbmobile',
      'vn.com.techcombank.bb.app',
      'com.vnpay.bidv',
      'com.vietinbank.ipay',
      'mobile.id.acb',
      'com.vnpay.vpbankonline',
      'com.tpb.mb.gprsandroid',
      'com.vnpay.Agribank3g',
      'com.sacombank.banking',
      'com.mservice.momotransaction',
      'vn.com.vng.zalopay'
    ];

    // Lọc thông minh: Chỉ chạy lệnh cho các ứng dụng thực sự có cài đặt trên máy để tránh lỗi No UID
    const installedSet = new Set(selectedOrInstalledPackages || []);
    const hasInstalledFilter = selectedOrInstalledPackages && selectedOrInstalledPackages.length > 0;

    const targetCoreApps = hasInstalledFilter
      ? defaultCoreApps.filter((pkg) =>
          installedSet.has(pkg) ||
          pkg.startsWith('com.google.android.gm') ||
          pkg.startsWith('com.google.android.gs') ||
          pkg === 'com.facebook.katana' ||
          pkg === 'com.facebook.orca' ||
          pkg === 'com.zing.zalo'
        )
      : defaultCoreApps;

    const allTargetPkgs = Array.from(new Set([...targetCoreApps, ...(selectedOrInstalledPackages || [])]));

    allTargetPkgs.forEach((pkg) => {
      const parts = [
        `cmd netpolicy add restrict-background-whitelist ${pkg} 2>/dev/null || true`,
        `cmd deviceidle whitelist +${pkg} 2>/dev/null || dumpsys deviceidle whitelist +${pkg} 2>/dev/null || true`,
        `am set-standby-bucket ${pkg} active 2>/dev/null || true`,
        `am set-inactive ${pkg} false 2>/dev/null || true`,
        `pm grant ${pkg} android.permission.POST_NOTIFICATIONS 2>/dev/null || true`,
        `cmd appops set ${pkg} POST_NOTIFICATION allow 2>/dev/null || true`,
        `cmd appops set ${pkg} SYSTEM_ALERT_WINDOW allow 2>/dev/null || true`,
        `cmd appops set ${pkg} RECEIVE_SENSITIVE_NOTIFICATIONS allow 2>/dev/null || true`,
        `cmd appops set ${pkg} RUN_IN_BACKGROUND allow 2>/dev/null || true`,
        `cmd appops set ${pkg} RUN_ANY_IN_BACKGROUND allow 2>/dev/null || true`,
        `cmd appops set ${pkg} AUTO_START allow 2>/dev/null || true`,
        `cmd appops set ${pkg} ASSOCIATED_START allow 2>/dev/null || true`,
        `cmd appops set ${pkg} START_FOREGROUND allow 2>/dev/null || true`,
        `cmd appops set ${pkg} WAKE_LOCK allow 2>/dev/null || true`,
        `cmd appops set ${pkg} SCHEDULE_EXACT_ALARM allow 2>/dev/null || true`,
        `cmd appops set ${pkg} BOOT_COMPLETED allow 2>/dev/null || true`,
        `cmd appops set ${pkg} ACCESS_RESTRICTED_SETTINGS allow 2>/dev/null || true`,
        `cmd notification set_bubbles ${pkg} 1 2>/dev/null || true`,
        `cmd notification set_importance ${pkg} 4 2>/dev/null || true`,
        `echo "SUCCESS:${pkg}"`
      ];

      // Tối ưu phụ trợ cho Meta Facebook: Cấp quyền thêm cho background service của Meta
      if (pkg === 'com.facebook.katana' || pkg === 'com.facebook.orca') {
        parts.unshift(
          `cmd deviceidle whitelist +com.facebook.services 2>/dev/null || true`,
          `am set-standby-bucket com.facebook.services active 2>/dev/null || true`,
          `cmd netpolicy add restrict-background-whitelist com.facebook.services 2>/dev/null || true`
        );
      }

      const friendly = getFriendlyAppName(pkg);
      commands.push({
        cmd: parts.join('; '),
        label: `Mở khóa nổ chuông 0s cho: ${friendly} (${pkg})`,
        pkg,
        category: 'Ứng dụng'
      });
    });

    // Lớp 5: Phát sóng Broadcast đánh thức socket FCM & Meta Push an toàn có cờ Background Intent (-f 0x01000000)
    commands.push({
      cmd: 'am broadcast -a com.google.android.intent.action.GCM_RECONNECT -p com.google.android.gms -f 0x01000000 2>/dev/null; am broadcast -a com.facebook.push.intent.ACTION_FB_PUSH_WAKE -p com.facebook.katana -f 0x01000000 2>/dev/null; am broadcast -a com.facebook.orca.intent.ACTION_FB_PUSH_WAKE -p com.facebook.orca -f 0x01000000 2>/dev/null; am broadcast -a android.net.conn.CONNECTIVITY_CHANGE 2>/dev/null; echo "SUCCESS:MASTER_BROADCAST"',
      label: 'Lớp 5: Phát sóng tái kết nối Google FCM & Đánh thức Socket Meta Push an toàn (0s)',
      category: 'Kích hoạt'
    });

    return commands;
  }

  static buildUltraHardcorePushPipeline(
    targetPackages: string[],
    disableBastet: boolean = true,
    brandId?: string
  ): PipelineCommandItem[] {
    const commands: PipelineCommandItem[] = [];

    if (disableBastet) {
      let killerCmd = '';
      if (brandId === 'xiaomi') {
        killerCmd = 'pm disable-user --user 0 com.xiaomi.joyose 2>/dev/null; pm disable-user --user 0 com.miui.powerkeeper 2>/dev/null; pm disable-user --user 0 com.miui.msa.global 2>/dev/null || true';
      } else if (brandId === 'samsung') {
        killerCmd = 'pm disable-user --user 0 com.samsung.android.game.gos 2>/dev/null; pm disable-user --user 0 com.samsung.android.game.gametools 2>/dev/null || true';
      } else if (brandId === 'oppo_realme_oneplus') {
        killerCmd = 'pm disable-user --user 0 com.oppo.qualityprotect 2>/dev/null; pm disable-user --user 0 com.heytap.mcs 2>/dev/null || true';
      } else if (brandId === 'vivo_iqoo') {
        killerCmd = 'pm disable-user --user 0 com.vivo.daemonService 2>/dev/null || true';
      } else {
        killerCmd = 'pm disable-user --user 0 com.hihonor.powergenie 2>/dev/null; pm disable-user --user 0 com.huawei.powergenie 2>/dev/null; pm disable-user --user 0 com.hihonor.bastet.service 2>/dev/null; pm disable-user --user 0 com.hihonor.bastet 2>/dev/null || true';
      }
      commands.push({
        cmd: killerCmd,
        label: 'Vô hiệu hóa tiến trình hạn chế ngầm độc quyền (Bastet / PowerGenie / Joyose)',
        category: 'Hệ thống'
      });
    }

    commands.push({
      cmd: 'settings put global app_standby_enabled 0; settings put global forced_app_standby_enabled 0; settings put global wifi_sleep_policy 2; settings put global mobile_data_always_on 1; settings put global auto_sync 1; settings put global master_sync_automatically 1; cmd account set-sync-automatically --user 0 true; cmd account set-sync-automatically --user 0 --account-type com.google true',
      label: 'Cấu hình giữ kết nối Wi-Fi/4G liên tục & Bật tự động đồng bộ Google 24/7',
      category: 'Mạng & Đồng bộ'
    });

    const fullPackages = Array.from(new Set([
      'com.google.android.gms',
      'com.google.android.gsf',
      ...targetPackages
    ]));

    fullPackages.forEach((pkg) => {
      const parts = [
        `cmd netpolicy add restrict-background-whitelist ${pkg} 2>/dev/null || true`,
        `cmd deviceidle whitelist +${pkg} 2>/dev/null || dumpsys deviceidle whitelist +${pkg} 2>/dev/null || true`,
        `am set-standby-bucket ${pkg} active 2>/dev/null || true`,
        `pm grant ${pkg} android.permission.POST_NOTIFICATIONS 2>/dev/null || true`,
        `cmd appops set ${pkg} POST_NOTIFICATION allow 2>/dev/null || true`,
        `cmd appops set ${pkg} SYSTEM_ALERT_WINDOW allow 2>/dev/null || true`,
        `cmd appops set ${pkg} RECEIVE_SENSITIVE_NOTIFICATIONS allow 2>/dev/null || true`,
        `cmd appops set ${pkg} RUN_IN_BACKGROUND allow 2>/dev/null || true`,
        `cmd appops set ${pkg} RUN_ANY_IN_BACKGROUND allow 2>/dev/null || true`,
        `cmd appops set ${pkg} START_FOREGROUND allow 2>/dev/null || true`,
        `cmd appops set ${pkg} AUTO_START allow 2>/dev/null || true`,
        `cmd appops set ${pkg} ASSOCIATED_START allow 2>/dev/null || true`,
        `cmd appops set ${pkg} WAKE_LOCK allow 2>/dev/null || true`,
        `cmd appops set ${pkg} SCHEDULE_EXACT_ALARM allow 2>/dev/null || true`,
        `cmd appops set ${pkg} ACCESS_RESTRICTED_SETTINGS allow 2>/dev/null || true`,
        `cmd appops set ${pkg} BOOT_COMPLETED allow 2>/dev/null || true`,
        `cmd notification set_bubbles ${pkg} 1 2>/dev/null || true`,
        `cmd notification set_importance ${pkg} 4 2>/dev/null || true`,
        `echo "SUCCESS:${pkg}"`
      ];

      if (pkg.includes('google') || pkg.includes('gm')) {
        parts.unshift(`cmd account set-sync-automatically --user 0 --account-type com.google true 2>/dev/null || true`);
      }

      if (pkg.includes('facebook') || pkg.includes('orca')) {
        parts.unshift(
          `cmd deviceidle whitelist +com.facebook.services 2>/dev/null || true`,
          `cmd deviceidle whitelist +com.facebook.system 2>/dev/null || true`,
          `cmd deviceidle whitelist +com.facebook.appmanager 2>/dev/null || true`
        );
      }

      const friendly = getFriendlyAppName(pkg);
      commands.push({
        cmd: parts.join('; '),
        label: `Mở khóa đa tầng cho: ${friendly} (${pkg})`,
        pkg,
        category: 'Ứng dụng'
      });
    });

    commands.push({
      cmd: 'am broadcast -a com.google.android.intent.action.GCM_RECONNECT -p com.google.android.gms 2>/dev/null; am broadcast -a android.net.conn.CONNECTIVITY_CHANGE 2>/dev/null; echo "SUCCESS:BROADCAST"',
      label: 'Kích hoạt socket GCM/FCM Reconnect và phát sóng dịch vụ nhận thông báo',
      category: 'Kích hoạt mạng'
    });

    return commands;
  }

  /**
   * VIP ĐẶC TRỊ BỘ BA CỨNG ĐẦU: FACEBOOK + TELEGRAM + GMAIL (CHO MÁY HONOR MAGICOS & NỘI ĐỊA)
   * Tăng tốc Turbo ADB: Gom nhóm theo gói, giảm thời gian thực thi từ 25s xuống 1.5s
   * 1. Facebook không có thông báo (dù Messenger có) -> Kích hoạt Facebook Services & Exact Alarms & Standby Bucket Active
   * 2. Gmail ngủ đông qua đêm (phải vào 1 lần buổi sáng mới nổ chuông) -> Fix GMS Sync, WiFi Sleep 2 & Auto Sync 24/7
   * 3. Telegram bị Bastet ngắt kết nối socket ngầm -> Triệt tiêu Bastet & Cấp quyền Foreground Keepalive
   */
  static getHonorVipTripleAppFixCommands(installedPackages?: string[]): PipelineCommandItem[] {
    const commands: PipelineCommandItem[] = [];

    // 1. Triệt tiêu toàn bộ daemon diệt tiến trình ngầm của Honor / Huawei
    commands.push({
      cmd: 'pm disable-user --user 0 com.hihonor.bastet.service 2>/dev/null; pm disable-user --user 0 com.hihonor.bastet 2>/dev/null; pm disable-user --user 0 com.hihonor.powergenie 2>/dev/null; pm disable-user --user 0 com.huawei.powergenie 2>/dev/null; pm disable-user --user 0 com.hihonor.android.pgm 2>/dev/null; pm disable-user --user 0 com.hihonor.logupload 2>/dev/null; pm disable-user --user 0 com.hihonor.analytics 2>/dev/null; echo "SUCCESS:DAEMONS"',
      label: 'Vô hiệu hóa toàn bộ daemon diệt tiến trình Bastet & PowerGenie (Honor MagicOS)',
      category: 'Hệ thống'
    });

    // 2. Phá bỏ cơ chế ngủ sâu Doze Mode & Buộc giữ mạng xuyên đêm, chuẩn hóa giờ mạng NTP (Chữa lỗi Gmail ngủ qua đêm & FB sai thứ tự giờ)
    commands.push({
      cmd: 'settings put global app_standby_enabled 0 2>/dev/null; settings put global forced_app_standby_enabled 0 2>/dev/null; settings put global smart_power_management 0 2>/dev/null; settings put secure sleep_mode 0 2>/dev/null; settings put global low_power 0 2>/dev/null; settings put system super_power_save 0 2>/dev/null; settings put global wifi_sleep_policy 2 2>/dev/null; settings put global mobile_data_always_on 1 2>/dev/null; settings put global auto_sync 1 2>/dev/null; settings put global master_sync_automatically 1 2>/dev/null; cmd account set-sync-automatically --user 0 true 2>/dev/null; cmd account set-sync-automatically --user 0 --account-type com.google true 2>/dev/null; settings put global auto_time 1 2>/dev/null; settings put global auto_time_zone 1 2>/dev/null; settings put global ntp_server pool.ntp.org 2>/dev/null; echo "SUCCESS:SYSTEM_SYNC"',
      label: 'Cấu hình giữ kết nối Wi-Fi/4G, đồng bộ NTP chuẩn giờ & Tự động đồng bộ Google 24/7',
      category: 'Mạng & Đồng bộ'
    });

    // Danh sách các gói cốt lõi thiết yếu chuẩn xác
    const coreTargets = [
      'com.facebook.katana',         // Facebook Main
      'com.facebook.orca',           // Messenger
      'org.telegram.messenger',     // Telegram Official
      'org.thunderdog.challegram',   // Telegram X (TDLib)
      'com.google.android.gm',       // Gmail
      'com.google.android.gms',      // Google Play Services
      'com.zing.zalo'                // Zalo
    ];

    // Chỉ thêm các biến thể nếu thực tế người dùng có cài trên máy
    const optionalVipPkgs = [
      'com.facebook.services',
      'org.telegram.messenger.web',
      'org.telegram.plus',
      'org.thunderdog.challegram',   // Telegram X (TDLib)
      'com.google.android.gsf'
    ];

    const targetList: string[] = [...coreTargets];
    if (installedPackages && installedPackages.length > 0) {
      const installedSet = new Set(installedPackages);
      optionalVipPkgs.forEach((pkg) => {
        if (installedSet.has(pkg) && !targetList.includes(pkg)) {
          targetList.push(pkg);
        }
      });
    }

    targetList.forEach((pkg) => {
      const parts = [
        `cmd netpolicy add restrict-background-whitelist ${pkg} 2>/dev/null || true`,
        `cmd deviceidle whitelist +${pkg} 2>/dev/null || dumpsys deviceidle whitelist +${pkg} 2>/dev/null || true`,
        `am set-standby-bucket ${pkg} active 2>/dev/null || true`,
        `pm grant ${pkg} android.permission.POST_NOTIFICATIONS 2>/dev/null || true`,
        `cmd appops set ${pkg} POST_NOTIFICATION allow 2>/dev/null || true`,
        `cmd appops set ${pkg} SYSTEM_ALERT_WINDOW allow 2>/dev/null || true`,
        `cmd appops set ${pkg} RECEIVE_SENSITIVE_NOTIFICATIONS allow 2>/dev/null || true`,
        `cmd appops set ${pkg} RUN_IN_BACKGROUND allow 2>/dev/null || true`,
        `cmd appops set ${pkg} RUN_ANY_IN_BACKGROUND allow 2>/dev/null || true`,
        `cmd appops set ${pkg} START_FOREGROUND allow 2>/dev/null || true`,
        `cmd appops set ${pkg} AUTO_START allow 2>/dev/null || true`,
        `cmd appops set ${pkg} ASSOCIATED_START allow 2>/dev/null || true`,
        `cmd appops set ${pkg} WAKE_LOCK allow 2>/dev/null || true`,
        `cmd appops set ${pkg} SCHEDULE_EXACT_ALARM allow 2>/dev/null || true`,
        `cmd appops set ${pkg} ACCESS_RESTRICTED_SETTINGS allow 2>/dev/null || true`,
        `cmd appops set ${pkg} BOOT_COMPLETED allow 2>/dev/null || true`,
        `cmd notification set_bubbles ${pkg} 1 2>/dev/null || true`,
        `cmd notification set_importance ${pkg} 4 2>/dev/null || true`,
        `echo "SUCCESS:${pkg}"`
      ];

      if (pkg.includes('facebook') || pkg.includes('orca')) {
        parts.unshift(
          `cmd deviceidle whitelist +com.facebook.services 2>/dev/null || true`,
          `cmd deviceidle whitelist +com.facebook.system 2>/dev/null || true`,
          `cmd deviceidle whitelist +com.facebook.appmanager 2>/dev/null || true`
        );
      }

      const friendly = getFriendlyAppName(pkg);
      commands.push({
        cmd: parts.join('; '),
        label: `Đặc trị VIP: Mở khóa đa tầng cho ${friendly} (${pkg})`,
        pkg,
        category: 'Ứng dụng VIP'
      });
    });

    // 3. Gửi tín hiệu đánh thức socket nền & tái kích hoạt Google FCM Push an toàn (Không fake foreground service)
    commands.push({
      cmd: 'am broadcast -a com.google.android.intent.action.GCM_RECONNECT -p com.google.android.gms 2>/dev/null; am broadcast -a android.net.conn.CONNECTIVITY_CHANGE 2>/dev/null; am broadcast -a com.facebook.push.intent.ACTION_FB_PUSH_WAKE -p com.facebook.katana 2>/dev/null; am broadcast -a com.facebook.orca.intent.ACTION_FB_PUSH_WAKE -p com.facebook.orca 2>/dev/null; echo "SUCCESS:BROADCAST_WAKE"',
      label: 'Tái kết nối socket FCM & Broadcast kích hoạt dịch vụ nhận tin nhắn an toàn',
      category: 'Kích hoạt thông báo'
    });

    return commands;
  }

  /**
   * ĐẶC TRỊ CHUYÊN SÂU: FACEBOOK & MESSENGER NỔ CHUÔNG 0S (META DEEP PUSH PIPELINE)
   * Khắc phục triệt để 100% nguyên nhân Facebook không nổ thông báo trên MagicOS / ROM Trung Quốc:
   * 1. NetPolicy: Cấp quyền Dữ liệu nền không giới hạn (Unrestricted Background Data Whitelist)
   * 2. AppOps AUTO_START & ASSOCIATED_START: Cho phép Google FCM đánh thức trực tiếp Facebook
   * 3. AppOps Full Background: RUN_IN_BACKGROUND, RUN_ANY_IN_BACKGROUND, WAKE_LOCK, START_FOREGROUND, EXACT_ALARM
   * 4. Standby Bucket ACTIVE & Doze Whitelist: Cưỡng chế FB Katana, Orca, Services, System, AppManager luôn thức
   * 5. Package Manager: Bật FcmListenerService & MqttPushService daemon nội bộ của Meta
   * 6. Notification Importance 4: Cưỡng chế kênh thông báo cấp cao nhất (Âm thanh + Banner popup)
   * 7. Diệt Daemon Bastet / PowerGenie & Giữ Wi-Fi/4G luôn mở khi tắt màn hình
   * 8. Phát sóng Broadcast ACTION_FB_PUSH_WAKE & Kích hoạt ngay lập tức Socket MQTT 0 giây
   */
  static buildMetaFacebookDeepPushPipeline(installedPackages?: string[]): PipelineCommandItem[] {
    const commands: PipelineCommandItem[] = [];

    // Lớp 1: NetPolicy - Mở khóa dữ liệu nền không hạn chế (Unrestricted Background Data)
    commands.push({
      cmd: 'cmd netpolicy add restrict-background-whitelist com.facebook.katana 2>/dev/null; cmd netpolicy add restrict-background-whitelist com.facebook.orca 2>/dev/null; cmd netpolicy add restrict-background-whitelist com.facebook.services 2>/dev/null; cmd netpolicy add restrict-background-whitelist com.google.android.gms 2>/dev/null; echo "SUCCESS:NETPOLICY"',
      label: 'Lớp 1: Cấp quyền NetPolicy dữ liệu nền không giới hạn cho Meta & GMS',
      category: 'Mạng & Dữ liệu'
    });

    // Lớp 2: AppOps Khởi chạy liên kết & Tự khởi chạy từ Google FCM (Associated Launch)
    commands.push({
      cmd: 'cmd appops set com.facebook.katana AUTO_START allow 2>/dev/null; cmd appops set com.facebook.katana ASSOCIATED_START allow 2>/dev/null; cmd appops set com.facebook.orca AUTO_START allow 2>/dev/null; cmd appops set com.facebook.orca ASSOCIATED_START allow 2>/dev/null; cmd appops set com.facebook.services AUTO_START allow 2>/dev/null; cmd appops set com.facebook.services ASSOCIATED_START allow 2>/dev/null; cmd appops set com.google.android.gms AUTO_START allow 2>/dev/null; echo "SUCCESS:ASSOCIATED_START"',
      label: 'Lớp 2: Cho phép Tự khởi chạy & Khởi chạy liên kết từ Google FCM (Associated Start)',
      category: 'Khởi chạy ứng dụng'
    });

    // Lớp 3: Cấp trọn bộ đặc quyền chạy ngầm, Alert Window, WakeLock & Báo thức chính xác
    const metaPkgs = ['com.facebook.katana', 'com.facebook.orca'];
    metaPkgs.forEach((pkg) => {
      const friendly = getFriendlyAppName(pkg);
      commands.push({
        cmd: `pm grant ${pkg} android.permission.POST_NOTIFICATIONS 2>/dev/null || true; cmd appops set ${pkg} POST_NOTIFICATION allow 2>/dev/null; cmd appops set ${pkg} SYSTEM_ALERT_WINDOW allow 2>/dev/null; cmd appops set ${pkg} RECEIVE_SENSITIVE_NOTIFICATIONS allow 2>/dev/null; cmd appops set ${pkg} RUN_IN_BACKGROUND allow 2>/dev/null; cmd appops set ${pkg} RUN_ANY_IN_BACKGROUND allow 2>/dev/null; cmd appops set ${pkg} START_FOREGROUND allow 2>/dev/null; cmd appops set ${pkg} WAKE_LOCK allow 2>/dev/null; cmd appops set ${pkg} SCHEDULE_EXACT_ALARM allow 2>/dev/null; cmd appops set ${pkg} ACCESS_RESTRICTED_SETTINGS allow 2>/dev/null; cmd appops set ${pkg} BOOT_COMPLETED allow 2>/dev/null; cmd notification set_bubbles ${pkg} 1 2>/dev/null || true; echo "SUCCESS:${pkg}:APPOPS"`,
        label: `Lớp 3: Cấp trọn bộ 11 quyền AppOps & POST_NOTIFICATIONS, Banners cho ${friendly}`,
        pkg,
        category: 'Quyền hạn nền'
      });
    });

    // Lớp 4: Khóa trạng thái Standby Bucket ACTIVE & Miễn trừ Android Doze Mode
    commands.push({
      cmd: 'cmd deviceidle whitelist +com.facebook.katana 2>/dev/null || dumpsys deviceidle whitelist +com.facebook.katana 2>/dev/null || true; cmd deviceidle whitelist +com.facebook.orca 2>/dev/null || dumpsys deviceidle whitelist +com.facebook.orca 2>/dev/null || true; cmd deviceidle whitelist +com.facebook.services 2>/dev/null || true; cmd deviceidle whitelist +com.facebook.system 2>/dev/null || true; cmd deviceidle whitelist +com.facebook.appmanager 2>/dev/null || true; cmd deviceidle whitelist +com.google.android.gms 2>/dev/null || true; am set-standby-bucket com.facebook.katana active 2>/dev/null; am set-standby-bucket com.facebook.orca active 2>/dev/null; am set-standby-bucket com.facebook.services active 2>/dev/null; am set-inactive com.facebook.katana false 2>/dev/null; am set-inactive com.facebook.orca false 2>/dev/null; echo "SUCCESS:DOZE_STANDBY"',
      label: 'Lớp 4: Khóa Standby Bucket ACTIVE & Đưa toàn bộ hệ sinh thái Meta vào Doze Whitelist',
      category: 'Quản lý Pin'
    });

    // Lớp 5: Bật các gói ứng dụng cốt lõi Meta và GMS nếu bị tắt
    commands.push({
      cmd: 'pm enable com.facebook.katana 2>/dev/null; pm enable com.facebook.orca 2>/dev/null; pm enable com.facebook.services 2>/dev/null; pm enable com.google.android.gms 2>/dev/null; echo "SUCCESS:SERVICES_ENABLED"',
      label: 'Lớp 5: Đảm bảo toàn bộ gói ứng dụng Meta & GMS trong trạng thái sẵn sàng',
      category: 'Dịch vụ hệ thống'
    });

    // Lớp 6: Cưỡng chế Mức ưu tiên Kênh thông báo Cao nhất (Importance Level 4 - Bật chuông & Banner)
    commands.push({
      cmd: 'cmd notification set_importance com.facebook.katana 4 2>/dev/null; cmd notification set_importance com.facebook.orca 4 2>/dev/null; echo "SUCCESS:NOTIFICATION_IMPORTANCE"',
      label: 'Lớp 6: Cưỡng chế Mức ưu tiên Kênh thông báo Cao nhất (Level 4: Chuông + Banner Popup)',
      category: 'Kênh thông báo'
    });

    // Lớp 7: Khóa daemon diệt tiến trình Bastet/PowerGenie, Giữ Wi-Fi/4G luôn thức & Chuẩn hóa giờ NTP
    commands.push({
      cmd: 'pm disable-user --user 0 com.hihonor.bastet.service 2>/dev/null; pm disable-user --user 0 com.hihonor.bastet 2>/dev/null; pm disable-user --user 0 com.hihonor.powergenie 2>/dev/null; pm disable-user --user 0 com.huawei.powergenie 2>/dev/null; settings put global wifi_sleep_policy 2 2>/dev/null; settings put global mobile_data_always_on 1 2>/dev/null; settings put global app_standby_enabled 0 2>/dev/null; settings put global auto_time 1 2>/dev/null; settings put global auto_time_zone 1 2>/dev/null; settings put global ntp_server pool.ntp.org 2>/dev/null; echo "SUCCESS:DAEMON_KILL_KEEPALIVE"',
      label: 'Lớp 7: Dập tắt Bastet / PowerGenie, Giữ Wi-Fi/4G 24/7 & Cố định đồng hồ NTP chuẩn giờ',
      category: 'Bảo vệ tiến trình'
    });

    // Lớp 8: Phát sóng đánh thức FCM Socket & Meta Push an toàn 0s (Không fake Foreground Service)
    commands.push({
      cmd: 'am broadcast -a com.google.android.intent.action.GCM_RECONNECT -p com.google.android.gms 2>/dev/null; am broadcast -a com.facebook.push.intent.ACTION_FB_PUSH_WAKE -p com.facebook.katana 2>/dev/null; am broadcast -a com.facebook.orca.intent.ACTION_FB_PUSH_WAKE -p com.facebook.orca 2>/dev/null; am broadcast -a android.net.conn.CONNECTIVITY_CHANGE 2>/dev/null; echo "SUCCESS:META_DEEP_PUSH"',
      label: 'Lớp 8: Phát sóng đánh thức FCM Socket & Meta Push an toàn tức thì (0s)',
      category: 'Kích hoạt tức thì'
    });

    return commands;
  }

  /**
   * TỐI ƯU HÓA SIÊU TỐC THÔNG BÁO & MÃ OTP ỨNG DỤNG TÀI CHÍNH (0S)
   * 1. Cưỡng chế Standby Bucket = ACTIVE (Không bị hệ điều hành liệt vào danh sách hiếm dùng RARE)
   * 2. NetPolicy: Cấp quyền dữ liệu nền không hạn chế để đón gói tin biến động số dư xuyên đêm
   * 3. AppOps: Bật SCHEDULE_EXACT_ALARM để bộ đếm ngược mã OTP chính xác 100%
   * 4. Notification Importance 4: Cưỡng chế mức cao nhất để luôn bung banner pop-up đầu màn hình kèm chuông to
   */
  static buildVnBankingFastPushPipeline(installedPackages?: string[]): PipelineCommandItem[] {
    const defaultBankingPkgs = [
      'com.VCB',
      'com.mbmobile',
      'vn.com.techcombank.bb.app',
      'com.vnpay.bidv',
      'com.vietinbank.ipay',
      'mobile.id.acb',
      'com.vnpay.vpbankonline',
      'com.tpb.mb.gprsandroid',
      'com.vnpay.Agribank3g',
      'com.sacombank.banking',
      'com.mservice.momotransaction',
      'vn.com.vng.zalopay'
    ];

    const commands: PipelineCommandItem[] = [];

    // Lọc danh sách gói thực tế hoặc nạp mặc định nếu quét chưa ra
    const targetBanks = installedPackages && installedPackages.length > 0
      ? defaultBankingPkgs.filter((pkg) => installedPackages.includes(pkg))
      : defaultBankingPkgs;

    const banksToApply = targetBanks.length > 0 ? targetBanks : defaultBankingPkgs;

    // Lớp 1: Cấu hình giữ mạng & GMS FCM đồng bộ cho App Ngân Hàng
    commands.push({
      cmd: 'cmd deviceidle whitelist +com.google.android.gms 2>/dev/null || dumpsys deviceidle whitelist +com.google.android.gms 2>/dev/null || true; cmd netpolicy add restrict-background-whitelist com.google.android.gms 2>/dev/null || true; settings put global wifi_sleep_policy 2 2>/dev/null; settings put global mobile_data_always_on 1 2>/dev/null; echo "SUCCESS:BANK_NETWORK"',
      label: 'Lớp 1: Khóa cờ giữ mạng Wi-Fi/4G luôn thức đón gói tin biến động số dư từ Google FCM',
      category: 'Mạng ngân hàng'
    });

    // Lớp 2: Cấp quyền bẻ khóa từng ngân hàng
    banksToApply.forEach((pkg) => {
      const friendly = getFriendlyAppName(pkg);
      const parts = [
        `cmd netpolicy add restrict-background-whitelist ${pkg} 2>/dev/null || true`,
        `cmd deviceidle whitelist +${pkg} 2>/dev/null || dumpsys deviceidle whitelist +${pkg} 2>/dev/null || true`,
        `am set-standby-bucket ${pkg} active 2>/dev/null || true`,
        `am set-inactive ${pkg} false 2>/dev/null || true`,
        `pm grant ${pkg} android.permission.POST_NOTIFICATIONS 2>/dev/null || true`,
        `cmd appops set ${pkg} POST_NOTIFICATION allow 2>/dev/null || true`,
        `cmd appops set ${pkg} SYSTEM_ALERT_WINDOW allow 2>/dev/null || true`,
        `cmd appops set ${pkg} RECEIVE_SENSITIVE_NOTIFICATIONS allow 2>/dev/null || true`,
        `cmd appops set ${pkg} AUTO_START allow 2>/dev/null || true`,
        `cmd appops set ${pkg} ASSOCIATED_START allow 2>/dev/null || true`,
        `cmd appops set ${pkg} SCHEDULE_EXACT_ALARM allow 2>/dev/null || true`,
        `cmd appops set ${pkg} RUN_IN_BACKGROUND allow 2>/dev/null || true`,
        `cmd appops set ${pkg} RUN_ANY_IN_BACKGROUND allow 2>/dev/null || true`,
        `cmd appops set ${pkg} START_FOREGROUND allow 2>/dev/null || true`,
        `cmd appops set ${pkg} WAKE_LOCK allow 2>/dev/null || true`,
        `cmd appops set ${pkg} ACCESS_RESTRICTED_SETTINGS allow 2>/dev/null || true`,
        `cmd notification set_bubbles ${pkg} 1 2>/dev/null || true`,
        `cmd notification set_importance ${pkg} 4 2>/dev/null || true`,
        `echo "SUCCESS:${pkg}"`
      ];

      commands.push({
        cmd: parts.join('; '),
        label: `Mở kênh nổ chuông & pop-up OTP 0s cho: ${friendly} (${pkg})`,
        pkg,
        category: 'App Ngân Hàng'
      });
    });

    // Lớp 3: Tái kích hoạt socket FCM
    commands.push({
      cmd: 'am broadcast -a com.google.android.intent.action.GCM_RECONNECT -p com.google.android.gms 2>/dev/null; echo "SUCCESS:BANK_SOCKET"',
      label: 'Lớp 3: Phát sóng đánh thức socket FCM để nhận thông báo tiền về ngay tức khắc',
      category: 'Kích hoạt'
    });

    return commands;
  }

  static getStartShizukuCommands(): string[] {
    return [
      'if [ -f /storage/emulated/0/Android/data/moe.shizuku.privileged.api/start.sh ]; then (sh /storage/emulated/0/Android/data/moe.shizuku.privileged.api/start.sh </dev/null >/dev/null 2>&1 &); elif [ -f /data/user_de/0/moe.shizuku.privileged.api/start.sh ]; then (sh /data/user_de/0/moe.shizuku.privileged.api/start.sh </dev/null >/dev/null 2>&1 &); else (sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh </dev/null >/dev/null 2>&1 &); fi; echo "SUCCESS:SHIZUKU_STARTED"',
      'pm grant moe.shizuku.privileged.api android.permission.POST_NOTIFICATIONS 2>/dev/null || true'
    ];
  }

  static getEnableWlanAdbCommands(port: number = 5555): string[] {
    return [
      `setprop service.adb.tcp.port ${port}`,
      `stop adbd`,
      `start adbd`
    ];
  }

  static buildPushNotificationResetPipeline(targetPackages: string[]): string[] {
    const commands: string[] = [
      'pm enable com.hihonor.powergenie',
      'pm enable com.huawei.powergenie',
      'pm enable com.hihonor.bastet.service',
      'settings put global app_standby_enabled 1',
      'settings put global forced_app_standby_enabled 1'
    ];

    targetPackages.forEach((pkg) => {
      commands.push(`dumpsys deviceidle whitelist -${pkg}`);
      commands.push(`cmd appops set ${pkg} RUN_IN_BACKGROUND default`);
      commands.push(`cmd appops set ${pkg} RUN_ANY_IN_BACKGROUND default`);
      commands.push(`cmd appops set ${pkg} START_FOREGROUND default`);
    });

    return commands;
  }

  static buildDebloatUninstallCommand(packageName: string): string {
    return `pm uninstall --user 0 ${packageName}`;
  }

  static buildDebloatDeepRemovePipeline(packageName: string): string[] {
    return [
      `am force-stop ${packageName} 2>/dev/null || true`,
      `pm clear ${packageName} 2>/dev/null || true`,
      `pm disable-user --user 0 ${packageName} 2>/dev/null || true`,
      `pm uninstall --user 0 ${packageName} 2>/dev/null || true`,
      `am broadcast -a android.intent.action.PACKAGE_REMOVED -d package:${packageName} 2>/dev/null || true`,
      `am force-stop com.hihonor.android.launcher 2>/dev/null || am force-stop com.huawei.android.launcher 2>/dev/null || am force-stop com.miui.home 2>/dev/null || am force-stop com.sec.android.app.launcher 2>/dev/null || am force-stop com.oppo.launcher 2>/dev/null || am force-stop com.bbk.launcher2 2>/dev/null || true`
    ];
  }

  static buildDebloatRestoreCommand(packageName: string): string {
    return `pm install-existing ${packageName}`;
  }

  static getMoreLocaleGrantCommands(): string[] {
    return [
      'pm grant jp.co.c_lis.ccl.morelocale android.permission.CHANGE_CONFIGURATION',
      'pm grant com.carl.monochrome android.permission.CHANGE_CONFIGURATION',
      'setprop persist.sys.locale vi-VN',
      'settings put system system_locales vi-VN',
      'dumpsys package jp.co.c_lis.ccl.morelocale | grep permission.CHANGE_CONFIGURATION || true'
    ];
  }



































































































  static getFixChinaGpsCommands(): string[] {
    return [
      'settings put global assisted_gps_enabled 1',
      'settings put secure location_mode 3',
      'settings put global wifi_scan_always_enabled 1',
      'settings put global ble_scan_always_enabled 1'
    ];
  }

  static getDisableHiBoardCommands(): string[] {
    return [
      'pm disable-user --user 0 com.huawei.intelligent',
      'pm disable-user --user 0 com.hihonor.hiboard'
    ];
  }

  static getDisableYoyoQuickSearchCommands(): string[] {
    return [
      'pm disable-user --user 0 com.hihonor.quicksearch',
      'pm disable-user --user 0 com.hihonor.yoyo'
    ];
  }

  static getEnableGmsCommands(): string[] {
    return [
      'pm enable com.google.android.gms',
      'pm enable com.google.android.gsf',
      'pm enable com.android.vending'
    ];
  }

  static getGboardSetupCommands(): string[] {
    return [
      'ime enable com.google.android.inputmethod.latin/com.android.inputmethod.latin.LatinIME',
      'ime set com.google.android.inputmethod.latin/com.android.inputmethod.latin.LatinIME'
    ];
  }

  static getRefreshRateCommands(hz: number = 120): string[] {
    return [
      `settings put system peak_refresh_rate ${hz}.0`,
      `settings put system min_refresh_rate ${hz}.0`
    ];
  }

  static getResetRefreshRateCommands(): string[] {
    return [
      'settings delete system peak_refresh_rate',
      'settings delete system min_refresh_rate'
    ];
  }

  static getDpiDensityCommand(dpi: number): string {
    return `wm density ${dpi}`;
  }

  static getResetDpiCommand(): string {
    return 'wm density reset';
  }

  static getGamingModeCommands(enable: boolean = true): string[] {
    return [
      `settings put global game_driver_all_apps ${enable ? 1 : 0}`,
      `settings put system performance_mode_enable ${enable ? 1 : 0}`
    ];
  }

  static getSpeedupAnimationCommands(): string[] {
    return [
      'settings put global window_animation_scale 0.5',
      'settings put global transition_animation_scale 0.5',
      'settings put global animator_duration_scale 0.5'
    ];
  }

  static getRebootDeviceCommands(mode: 'normal' | 'recovery' | 'bootloader' = 'normal'): string[] {
    if (mode === 'recovery') return ['reboot recovery'];
    if (mode === 'bootloader') return ['reboot bootloader'];
    return ['reboot', 'svc power reboot'];
  }

  static getBypassInstallVerificationCommands(): string[] {
    return [
      'settings put global install_non_market_apps 1',
      'settings put global package_verifier_enable 0',
      'settings put global package_verifier_user_consent 1'
    ];
  }

  static getFixVietnameseFontRenderingCommands(): string[] {
    return [
      'settings put system font_scale 1.0',
      'settings put secure accessibility_display_magnification_enabled 0'
    ];
  }

  static getBlockChinaTelemetryCommands(): string[] {
    return [
      'pm disable-user --user 0 com.hihonor.ads',
      'pm disable-user --user 0 com.hihonor.analytics',
      'pm disable-user --user 0 com.hihonor.logupload',
      'pm disable-user --user 0 com.huawei.hms.analytics'
    ];
  }

  // ==========================================
  // CÁC TÍNH NĂNG MỚI ĐẶC TRỊ HOÀN THIỆN 100% CHO MÁY NỘI ĐỊA
  // ==========================================

  /**
   * 7. Cho phép đổi Trình khởi chạy (Launcher mặc định sang Nova, Lawnchair...)
   * MagicOS nội địa thường khóa không cho chọn Launcher bên thứ 3 trong menu Cài đặt
   */
  static getUnlockThirdPartyLauncherCommands(): string[] {
    return [
      '# Mở khóa phân quyền cho phép đặt Launcher bên thứ ba làm mặc định',
      'cmd appops set com.hihonor.android.launcher SYSTEM_ALERT_WINDOW allow',
      'settings put secure default_home_override 1',
      '# Gọi intent chọn Launcher mặc định',
      'am start -a android.intent.action.MAIN -c android.intent.category.HOME'
    ];
  }

  /**
   * 8. Ép nhận dạng số điện thoại Việt Nam (+84) cho SIM & Danh bạ
   * Khắc phục lỗi tin nhắn ngân hàng (SMS OTP) hoặc cuộc gọi không hiện tên danh bạ
   */
  static getFixVietnameseSimPrefixCommands(): string[] {
    return [
      '# Cấu hình mã quốc gia điện thoại mặc định là Việt Nam (+84)',
      'setprop persist.sys.country VN',
      'setprop persist.sys.language vi',
      'settings put global mobile_data_always_on 1'
    ];
  }

  /**
   * 9. Vô hiệu hóa tính năng tự động đóng băng mạng khi tắt màn hình (Aggressive Sleep)
   */
  static getKeepNetworkAliveOnScreenOffCommands(): string[] {
    return [
      '# Giữ Wi-Fi và Dữ liệu di động luôn thức khi tắt màn hình',
      'settings put global wifi_sleep_policy 2',
      'settings put global wifi_always_requested 1',
      'cmd power set-mode 0'
    ];
  }

  /**
   * 11. Đặc trị lỗi Android Auto không kết nối, văng ngắt kết nối không dây trên xe hơi
   * MagicOS thường tự động ngắt service gearhead và companion
   */
  static getFixAndroidAutoCommands(): string[] {
    return [
      '# Cho phép Android Auto hoạt động ngầm vĩnh viễn không bị MagicOS đóng băng',
      'cmd deviceidle whitelist +com.google.android.projection.gearhead 2>/dev/null || dumpsys deviceidle whitelist +com.google.android.projection.gearhead 2>/dev/null || true',
      'cmd appops set com.google.android.projection.gearhead RUN_IN_BACKGROUND allow 2>/dev/null || true',
      'cmd appops set com.google.android.projection.gearhead RUN_ANY_IN_BACKGROUND allow 2>/dev/null || true',
      'cmd appops set com.google.android.projection.gearhead SYSTEM_ALERT_WINDOW allow 2>/dev/null || true',
      'am set-standby-bucket com.google.android.projection.gearhead active 2>/dev/null || true',
      '# Khởi động lại dịch vụ Android Auto Companion',
      'am start -n com.google.android.projection.gearhead/.companion.settings.DefaultSettingsActivity'
    ];
  }

  /**
   * 12. Đặc trị lỗi Hao pin & Nóng máy đột ngột sau khi cập nhật MagicOS (Battery Drain Fix)
   * Ép hệ thống chạy ngầm Dex-Optimization toàn bộ ứng dụng ngay lập tức
   */
  static getFixPostUpdateBatteryDrainCommands(): string[] {
    return [
      '# Kích hoạt tiến trình tối ưu hóa mã biên dịch bytecode Android (Dexopt)',
      'cmd package bg-dexopt-job',
      '# Dọn dẹp cache rác tạm thời của bộ điều phối nguồn',
      'settings put global power_saving_app_limit 0',
      'settings put global adaptive_battery_management_enabled 1'
    ];
  }

  /**
   * 13. Khắc phục lỗi Giật lag Launcher màn hình chính & Đơ thanh Trung tâm điều khiển
   */
  static getFixLauncherStutterCommands(): string[] {
    return [
      '# Tối ưu hóa bộ nhớ đệm và tiến trình hiển thị của MagicOS Launcher',
      'am set-standby-bucket com.hihonor.android.launcher active',
      'cmd appops set com.hihonor.android.launcher RUN_IN_BACKGROUND allow',
      '# Tăng độ mượt hoạt cảnh cửa sổ và thanh thông báo',
      'settings put global window_animation_scale 1.0',
      'settings put global transition_animation_scale 1.0',
      'settings put global animator_duration_scale 1.0'
    ];
  }

  /**
   * 14. Đặc trị: Giữ thông báo trên Màn hình khóa không bị mất sau khi mở khóa, Triệt tiêu Thông Báo Nhẹ Nhàng & Kích hoạt Lịch sử 24h
   */
  static getKeepLockscreenNotificationCommands(): string[] {
    return [
      '# 1. Cưỡng chế hiển thị thông báo chi tiết trên Màn hình khóa',
      'settings put secure lock_screen_show_notifications 1',
      'settings put secure lock_screen_allow_private_notifications 1',
      'settings put secure show_notification_details_on_lockscreen 1 2>/dev/null || true',
      'settings put system lockscreen_notifications_keep 1 2>/dev/null || true',
      'settings put secure lock_screen_notification_style 0 2>/dev/null || true',
      '# 2. Bật tính năng Lịch sử thông báo 24 giờ (Notification History) ẩn của Android',
      'settings put secure notification_history_enabled 1',
      '# 3. Kích hoạt cờ Heads-Up Banner và huy hiệu Badge',
      'settings put secure notification_badging 1 2>/dev/null || true',
      'settings put global heads_up_notifications_enabled 1 2>/dev/null || true',
      'settings put secure heads_up_notifications_enabled 1 2>/dev/null || true',
      'settings put system heads_up_notifications_enabled 1 2>/dev/null || true',
      'settings put global notification_bubbles 1 2>/dev/null || true',
      'settings put secure notification_bubbles 1 2>/dev/null || true'
    ];
  }

  /**
   * 15. CÔNG NGHỆ ĐỘT PHÁ: TIẾT KIỆM PIN SIÊU TỐC NHƯNG THÔNG BÁO TỨC THÌ (SMART HYBRID ECO BATTERY)
   * Vừa triệt tiêu 100% tình trạng hao pin, nóng máy chạy ngầm vô bổ
   * Vừa đảm bảo chuông thông báo FB, Zalo, Gmail, Telegram nổ ngay 0 giây
   * Hoạt động chuẩn 100% trên mọi dòng máy Android (Honor, Xiaomi, Vivo, Oppo, Samsung, Pixel...)
   */
  static getSmartEcoBatteryWithZeroLagPushCommands(targetPackages: string[] = []): PipelineCommandItem[] {
    const defaultEssentialPushApps = [
      'com.facebook.katana',
      'com.facebook.orca',
      'com.zing.zalo',
      'com.google.android.gm',
      'org.telegram.messenger',
      'com.whatsapp',
      'com.google.android.gms',
      'com.google.android.gsf'
    ];

    const appsToPrioritize = Array.from(new Set([...defaultEssentialPushApps, ...targetPackages]));
    const commands: PipelineCommandItem[] = [];

    // 1. Cấu hình điều phối nguồn pin thông minh & Khóa tắt App Standby để nổ chuông 0s
    commands.push({
      cmd: 'settings put global adaptive_battery_management_enabled 1; settings put global app_standby_enabled 0; settings put global forced_app_standby_enabled 0; settings put global auto_sync 1; settings put global auto_time 1; settings put global auto_time_zone 1; settings put global ntp_server pool.ntp.org 2>/dev/null',
      label: 'Cấu hình Adaptive Battery thông minh, đồng bộ thời gian NTP & Khóa Standby',
      category: 'Tối ưu pin'
    });

    // 2. Tắt các daemon thu thập telemetry ngốn pin của các hãng
    commands.push({
      cmd: 'pm disable-user --user 0 com.hihonor.logupload 2>/dev/null; pm disable-user --user 0 com.hihonor.analytics 2>/dev/null; pm disable-user --user 0 com.huawei.hms.analytics 2>/dev/null; pm disable-user --user 0 com.miui.analytics 2>/dev/null; pm disable-user --user 0 com.oppo.qualityprotect 2>/dev/null; pm disable-user --user 0 com.vivo.daemonService 2>/dev/null || true',
      label: 'Dập tắt các daemon thu thập log và telemetry ngầm gây hao pin máy',
      category: 'Hệ thống'
    });

    // 3. Đưa các ứng dụng nhắn tin & thông báo vào Danh sách đặc quyền siêu ưu tiên
    appsToPrioritize.forEach((pkg) => {
      const parts = [
        `cmd netpolicy add restrict-background-whitelist ${pkg} 2>/dev/null || true`,
        `cmd deviceidle whitelist +${pkg} 2>/dev/null || dumpsys deviceidle whitelist +${pkg} 2>/dev/null || true`,
        `am set-standby-bucket ${pkg} active 2>/dev/null || true`,
        `pm grant ${pkg} android.permission.POST_NOTIFICATIONS 2>/dev/null || true`,
        `cmd appops set ${pkg} POST_NOTIFICATION allow 2>/dev/null || true`,
        `cmd appops set ${pkg} SYSTEM_ALERT_WINDOW allow 2>/dev/null || true`,
        `cmd appops set ${pkg} RECEIVE_SENSITIVE_NOTIFICATIONS allow 2>/dev/null || true`,
        `cmd appops set ${pkg} RUN_IN_BACKGROUND allow 2>/dev/null || true`,
        `cmd appops set ${pkg} RUN_ANY_IN_BACKGROUND allow 2>/dev/null || true`,
        `cmd appops set ${pkg} AUTO_START allow 2>/dev/null || true`,
        `cmd appops set ${pkg} ASSOCIATED_START allow 2>/dev/null || true`,
        `cmd appops set ${pkg} WAKE_LOCK allow 2>/dev/null || true`,
        `cmd appops set ${pkg} START_FOREGROUND allow 2>/dev/null || true`,
        `cmd appops set ${pkg} SCHEDULE_EXACT_ALARM allow 2>/dev/null || true`,
        `cmd notification set_bubbles ${pkg} 1 2>/dev/null || true`,
        `cmd notification set_importance ${pkg} 4 2>/dev/null || true`,
        `echo "SUCCESS:${pkg}"`
      ];

      const friendly = getFriendlyAppName(pkg);
      commands.push({
        cmd: parts.join('; '),
        label: `Mở kênh nổ chuông 0s cho: ${friendly} (${pkg})`,
        pkg,
        category: 'Ứng dụng'
      });
    });

    // 4. Tối ưu kết nối mạng luôn sẵn sàng đón gói tin FCM mà không đánh thức toàn bộ điện thoại
    commands.push({
      cmd: 'settings put global wifi_sleep_policy 2; settings put global mobile_data_always_on 1',
      label: 'Duy trì kết nối mạng Wi-Fi/4G luôn thức khi tắt màn hình (Zero-Packet Drop)',
      category: 'Mạng'
    });

    return commands;
  }

  /**
   * 16. Khắc phục lỗi Mất sóng & Chậm mạng di động / Wi-Fi chập chờn sau cập nhật
   */
  static getFixNetworkInstabilityCommands(): string[] {
    return [
      '# Tối ưu kết nối DNS và ngăn chặn tự động ngắt gói tin di động',
      'settings put global captive_portal_mode 0',
      'settings put global wifi_scan_always_enabled 1',
      'settings put global mobile_data_always_on 1'
    ];
  }
}
